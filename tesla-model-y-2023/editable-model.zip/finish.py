"""Details visible in the 2023 walkaround, component photos and factory service diagrams."""
from scipy.spatial import ConvexHull
from mathutils import Matrix
def reparent(o,g):
 bpy.context.view_layer.update()
 world=o.matrix_world.copy();o.parent=groups[g][0];o.matrix_world=world
def move_family(parent,g,prefixes):
 for obj in list(groups[parent][0].children):
  if obj.name.startswith(tuple(prefixes)):reparent(obj,g)

move_family('Cabin','Console',['Covered console','Armrest','Console ','Cup recess','Sliding cover','Charging mat'])
move_family('Cabin','CabinFloor',['Passenger tray','Carpeted front','Rear seat riser'])
move_family('Cabin','Body',['Inner A-pillar'])
move_family('Body','Cargo',['Rear trunk','Rear load-space trim'])
move_family('Body','Frunk',['Molded front trunk','Cowl service'])
# Convert a set of measured surface vertices into a local tangent-plane height query.
def surface_map(g,m,axes,out,selection=lambda p:np.ones(len(p),bool)):
 p=np.vstack(surfaces[g,m]);p=p[selection(p)];xy=p[:,axes];tree=cKDTree(xy)
 def evaluate(a,b):
  d,idx=tree.query([a,b],k=min(12,len(p)));local=xy[idx]-[a,b];w=1/(d+.0008)
  plane,*_=np.linalg.lstsq(np.c_[local,np.ones(len(local))]*w[:,None],p[idx,out]*w,rcond=None)
  return np.clip(plane[-1],p[idx,out].min()-.002,p[idx,out].max()+.002)
 return evaluate
def rect_outline(poly):
 pts=np.asarray(poly);return pts[ConvexHull(pts).vertices]
def radial(poly,center,angle):
 # Ray to an arbitrary convex panel outline, in its local plane.
 v=np.array([math.cos(angle),math.sin(angle)]);best=np.inf;poly=np.array(poly)
 for a,b in zip(poly,np.roll(poly,-1,axis=0)):
  u=b-a;den=v[0]*u[1]-v[1]*u[0]
  if abs(den)<1e-8:continue
  w=a-center;t=(w[0]*u[1]-w[1]*u[0])/den;s=(w[0]*v[1]-w[1]*v[0])/den
  if t>0 and -.00001<=s<=1.00001:best=min(best,t)
 return center+best*v
def flat_ring(label,g,rings,m,smooth=True):
 n=len(rings[0]);vs=np.vstack(rings)
 faces=[(k*n+i,k*n+(i+1)%n,(k+1)*n+(i+1)%n,(k+1)*n+i) for k in range(len(rings)-1) for i in range(n)]
 obj=faced(label,g,vs,faces,m)
 for poly in obj.data.polygons:poly.use_smooth=smooth
 return obj
def polyline(label,g,points,r,m):
 cu=bpy.data.curves.new(label,'CURVE');cu.dimensions='3D';cu.bevel_depth=r;cu.bevel_resolution=2
 sp=cu.splines.new('POLY');sp.points.add(len(points)-1)
 for p,v in zip(sp.points,points):p.co=(*blender(np.asarray(v)-groups[g][1]),1)
 ob=bpy.data.objects.new(label,cu);bpy.context.collection.objects.link(ob);ob.parent=groups[g][0];cu.materials.append(materials[m])
def local_text(label,txt,g,location,right,up,size,m,depth=.0004):
 cu=bpy.data.curves.new(label,'FONT');cu.body=txt;cu.size=size;cu.extrude=depth;cu.bevel_depth=.00012;cu.resolution_u=5;cu.align_x='CENTER';cu.align_y='CENTER'
 ob=bpy.data.objects.new(label,cu);bpy.context.collection.objects.link(ob);ob.parent=groups[g][0]
 x=Vector(blender(np.array(right))).normalized();y=Vector(blender(np.array(up))).normalized();z=x.cross(y)
 ob.rotation_euler=Matrix((x,y,z)).transposed().to_euler();ob.location=blender(np.asarray(location)-groups[g][1]);cu.materials.append(materials[m])

hood_y=surface_map('Hood',paint,[0,2],1);hp=np.vstack(surfaces['Hood',paint]);perim=rect_outline(hp[:,[0,2]])
center=np.array([0,1.65]);angles=np.linspace(0,math.tau,120,endpoint=False)
outer=[radial(perim,center,a) for a in angles]
# The underhood apron reaches the painted opening and seals against the hood.
def tub_lip(a):
 c,s=math.cos(a),math.sin(a);x=.553*np.sign(c)*abs(c)**.51;z=.345*np.sign(s)*abs(s)**.51
 return [x*(1-.07*z/.345),.887-z*.26,1.63+z]
edge=[[x,hood_y(x,z)-.024,z] for x,z in outer]
inside=[tub_lip(a) for a in angles]
flat_ring('Molded underhood apron','Frunk',[edge,(np.array(edge)*.52+np.array(inside)*.48),inside],arch)
polyline('Front trunk weather seal','Frunk',inside+[inside[0]],.008,trim)
# Shallow corrugations, fixing points, washer access and cowl intake.
for x in np.linspace(-.345,.345,19):
 length=.152+.031*(1-(x/.355)**4)
 pipe('Front trunk floor rib','Frunk',[[x,.540,1.66-length],[x,.537,1.66],[x,.538,1.66+length]],.0045,trim)
for j in range(6):
 z=1.086+j*.022
 width=.437+.031*math.sin(j*math.pi/6)
 box('Cowl inlet louver','Frunk',[0,hood_y(0,z)-.024,z],[width*2,.006,.014],wheelwell,.003)
for x in (-.31,-.15,0,.15,.31):box('Cowl intake divider','Frunk',[x,.962,1.14],[.007,.013,.118],arch,.003,-.12)
cylinder_between('Washer fluid cap','Frunk',[-.519,.933,1.25],[-.519,.947,1.25],.027,trim,40)
for x in (-.47,.47):
 y=hood_y(x,1.96)-.021;cylinder_between('Apron mounting pin','Frunk',[x,y-.006,1.96],[x,y,1.96],.015,trim,18)
# Hem and inner stamping follow the underside of the same crowned hood skin.
rings=[]
for mult,drop in [(1,.004),(.985,.015),(.941,.021),(.923,.014),(.88,.011)]:
 ring=[]
 for x,z in outer:
  x,z=center+mult*(np.array([x,z])-center);ring.append([x,hood_y(x,z)-drop,z])
 rings.append(ring)
flat_ring('Hemmed hood reinforcement','Hood',rings,paint)
for sg in (-1,1):
 for path in [[(.49,1.29),(.38,1.47),(.27,1.66),(.10,1.89)],[(.54,1.66),(.36,1.72),(.18,1.86),(.09,2.00)]]:
  pipe('Stamped hood web','Hood',[[sg*x,hood_y(sg*x,z)-.018,z] for x,z in path],.012,paint)
 pipe('Hood hinge strap','Hood',[[sg*.48,1.032,1.12],[sg*.48,.994,1.18],[sg*.47,hood_y(sg*.47,1.30)-.022,1.30]],.011,metal)
pipe('Hood latch loop','Hood',[[-.033,.758,2.094],[-.032,.731,2.094],[.032,.731,2.094],[.033,.758,2.094]],.0045,metal)

# Stamp the inner returns and the rubber seals from each skin's actual side silhouette.
for side,sg in [('Left',1),('Right',-1)]:
 for row in ('Front','Rear'):
  g='Door'+row+side;p=np.vstack(surfaces[g,paint]);h=rect_outline(p[:,[2,1]])
  cy=(h.min(0)+h.max(0))/2;ext=surface_map(g,paint,[2,1],0)
  dirs=[radial(h,cy,a) for a in np.linspace(0,math.tau,112,endpoint=False)]
  rings=[]
  for scale_,inset in [(1,.004),(.996,.017),(.977,.045),(.942,.083),(.918,.087)]:
   ring=[]
   for z,y in dirs:
    z,y=cy+scale_*(np.array([z,y])-cy);ring.append([ext(z,y)-sg*inset,y,z])
   rings.append(ring)
  flat_ring(g+' hem and shut face',g,rings,paint)
  polyline(g+' perimeter seal',g,rings[-1]+[rings[-1][0]],.006,trim)
  # Recessed door bin with a rolled pocket opening and a dark molded cavity.
  zc=.27 if row=='Front' else -.79;xi=sg*.716
  for sc,xx,name,m in [(1,xi,'Door bin edge',trim),(.938,xi-.003*sg,'Recessed door bin',wheelwell)]:
   outline=[]
   for a in np.linspace(0,math.tau,60,endpoint=False):
    c,s=math.cos(a),math.sin(a);outline.append((zc+sc*.255*np.sign(c)*abs(c)**.65,.52+sc*(.079*s+.025*c)))
   poly_plate(name,g,outline,xx,.002*sg,m)
  for zz in ([.73,.66] if row=='Front' else [-.425,-.48]):
   box('Window switch paddle',g,[sg*.674,.721,zz],[.018,.006,.028],pad,.003)
  # A narrow painted sill and striker remain on the fixed opening when the door lifts away.
  if row=='Front':
   poly_plate('B pillar door jamb','Body',[(-.211,1.080),(-.292,1.10),(-.309,.29),(-.19,.29)],sg*.796,.045*sg,trim)
   pipe('Door latch striker','Body',[[sg*.829,.72,-.252],[sg*.852,.72,-.252],[sg*.852,.742,-.252],[sg*.829,.742,-.252]],.0038,metal)
 # Fixed wheel housings now have inboard walls at the real tire radius.
 for row,z0 in [('Front',1.445),('Rear',-1.445)]:
  arcs=np.linspace(-.17,math.pi+.17,76);rings=[]
  for x,r in [(.548,.379),(.60,.408),(.753,.425),(.853,.419),(.893,.405)]:
   rings.append([[sg*x,.356+r*math.sin(a),z0+r*math.cos(a)] for a in arcs])
  verts=np.vstack(rings);n=len(arcs);faces=[(i*n+j,i*n+j+1,(i+1)*n+j+1,(i+1)*n+j) for i in range(len(rings)-1) for j in range(n-1)]
  obj=faced('Formed '+row.lower()+' wheel liner','Underbody',verts,faces,wheelwell)
  for face in obj.data.polygons:face.use_smooth=True
  for a in (.24,.92,1.56,2.25,2.91):
   x=sg*.85;y=.356+.418*math.sin(a);z=z0+.418*math.cos(a)
   cylinder_between('Liner retaining pin','Underbody',[x,y,z],[x+sg*.004,y,z],.0075,trim,12)
 # Camera pod and lens inside the curved triangular fender repeater.
 g='Fender'+side;arr=np.vstack(surfaces[g,50]);pt=arr[np.argmax(np.abs(arr[:,0]))];xx=abs(pt[0]);y,z=arr[:,1].mean(),arr[:,2].mean()
 zz=arr[:,2].max()-.040; yy=y-.014
 sample=arr[np.argmin(((arr[:,1]-yy)**2+(arr[:,2]-zz)**2))]
 xx=abs(sample[0]);c=[sg*(xx+.001),yy,zz]
 cylinder_between('Repeater lens bezel',g,c,[sg*(xx+.004),yy,zz],.009,trim,32)
 cylinder_between('Camera front element',g,[sg*(xx+.004),yy,zz],[sg*(xx+.005),yy,zz],.0051,smoke,32)
 cylinder_between('Camera aperture',g,[sg*(xx+.005),yy,zz],[sg*(xx+.0055),yy,zz],.0023,projector,24)
 near=arr[np.argsort(-arr[:,1])[:max(6,len(arr)//12)]];zlo,zhi=np.percentile(near[:,2],[15,85])
 pp=[]
 for z1 in np.linspace(zlo,zhi,8):
  v=near[np.argmin(abs(near[:,2]-z1))];pp.append([v[0]+sg*.0014,v[1]-.003,v[2]])
 polyline('Fender repeater light strip',g,pp,.0018,smoke)

# Clear upper windshield with a ceramic camera housing fitted beneath the glass.
wind_y=surface_map('Windshield',93,[0,2],1)
stations=[(.242,.055),(.278,.092),(.368,.111),(.448,.112),(.493,.085)]
vs=[]
for z,ww in stations:
 for x,drop in [(-ww,.008),(-ww*.84,.030),(0,.047),(ww*.84,.030),(ww,.008)]:
  vs.append((x,wind_y(x,z)-drop,z))
faces=[(i*5+j,i*5+j+1,(i+1)*5+j+1,(i+1)*5+j) for i in range(len(stations)-1) for j in range(4)]
faced('Forward camera housing','Windshield',vs,faces,trim,.003)
pipe('Rearview mirror stem','Windshield',[[0,wind_y(0,.32)-.025,.32],[0,1.456,.296],[0,1.412,.170],[0,1.403,.12]],.014,trim)
for x in (-.027,0,.027):
 z=.423;y=wind_y(x,z)
 cylinder_between('Windshield camera optic','Windshield',[x,y-.018,z],[x,y-.006,z+.004],.009,projector,24)
# The rear screen heating grid sits on the inner face of the moving liftgate.
rear_y=surface_map('Liftgate',privacy,[0,2],1)
rear_pts=np.vstack(surfaces['Liftgate',privacy])
for z in np.linspace(-2.10,-1.54,12):
 near=rear_pts[np.abs(rear_pts[:,2]-z)<.022]
 if len(near)<3:continue
 width=min(abs(near[:,0].min()),abs(near[:,0].max()))-.023
 pts=[[x,rear_y(x,z)-.002,z] for x in np.linspace(-width,width,17)]
 polyline('Rear screen heater trace','Liftgate',pts,.00085,coverDark)

# Rear license mount and model designation lie on the curved lower liftgate panel.
rear_z=surface_map('Liftgate',paint,[0,1],2,lambda p:(p[:,2]<-2.15)&(p[:,1]<.97))
py=.823;pz=float(rear_z(0,py))
box('Plate mounting plinth','Liftgate',[0,py,pz-.010],[.320,.166,.017],trim,.008)
plate=mat('Registration plate enamel',(.69,.71,.70),.26,.36)
box('Studio registration plate','Liftgate',[0,py,pz-.022],[.3048,.1524,.005],plate,.006)
local_text('Studio plate lettering','MODEL Y','Liftgate',[0,py,pz-.026],[-1,0,0],[0,1,0],.045,trim)
for x in (-.0889,.0889):
 cylinder_between('Plate screw','Liftgate',[x,py+.058,pz-.025],[x,py+.058,pz-.029],.004,metal,16)
bx=-.413;by=.754;bz=rear_z(bx,by)
local_text('Rear drive badge','D U A L   M O T O R','Liftgate',[bx,by,bz-.004],[-.979,0,.204],[0,1,0],.0125,chrome)
# Dark backing closes the original grille between the fascia and crash structure.
box('Lower intake air duct','FrontFascia',[0,.360,2.107],[1.185,.20,.064],wheelwell,.045)
# Black charge inlet sits just inside the separate driver's-side taillight flap.
g='TailLampLeft';flap=np.vstack([v for v,f,n in buffers['ChargeDoor',liner]])
mid=(flap.min(0)+flap.max(0))/2;normal=np.array([.90,0,-.43]);along=np.array([.43,0,.90]);vertical=np.array([0,1,0])
def inlet_shape(label,station,m):
 verts=[]
 for radius,offset in station:
  for i in range(48):
   a=math.tau*i/48
   verts.append(mid+normal*offset+along*radius*math.cos(a)+vertical*(radius*.91)*math.sin(a))
 faces=[(r*48+i,r*48+(i+1)%48,(r+1)*48+(i+1)%48,(r+1)*48+i) for r in range(len(station)-1) for i in range(48)]
 faced(label,g,verts,faces,m)
inlet_shape('Charge socket bezel',[(.053,-.020),(.051,-.007),(.034,-.007),(.032,-.014),(.001,-.014)],trim)
for a,b,rad in [(-.015,.013,.009),(.015,.013,.009),(0,-.012,.007),(-.013,-.023,.003),(.013,-.023,.003)]:
 p=mid+along*a+vertical*b-normal*.016
 cylinder_between('Socket contact surround',g,p,p+normal*.003,rad,alloy,28)
 cylinder_between('Socket contact recess',g,p+normal*.003,p+normal*.0033,rad*.78,trim,28)
# Charge door is hinged independently; the overview keeps it with the complete inlet.
reparent(groups['ChargeDoor'][0],'TailLampLeft')

exec(compile((HERE/'body_structure.py').read_text(),str(HERE/'body_structure.py'),'exec'))
exec(compile((HERE/'running_gear.py').read_text(),str(HERE/'running_gear.py'),'exec'))
exec(compile((HERE/'trim_detail.py').read_text(),str(HERE/'trim_detail.py'),'exec'))
