"""Export the detailed editable master as a compact, material-batched web model.
blender -b 2023_Model_Y.blend -P export.py -- model-y.glb
"""
import bpy,sys,json,math
import numpy as np
from pathlib import Path
base=Path(__file__).resolve().parent
out=Path(sys.argv[sys.argv.index('--')+1]).resolve() if '--' in sys.argv else base/'model-y.glb'
scene=bpy.context.scene
scene['source_model']='Tesla Model Y 2021 by 763468712, CC BY 4.0'
scene['source_url']='https://sketchfab.com/3d-models/tesla-model-y-2021-c0a86cac582d4b33aba0fb1b1912d970'
scene['license']='https://creativecommons.org/licenses/by/4.0/'
scene['adaptation']='2023 five-seat US Long Range AWD, Gemini wheels and caps, individual closures, optics, glazing, interior, suspension, battery and electric drives.'
bpy.ops.object.select_all(action='DESELECT')
for obj in scene.objects:
 if obj.type in ('MESH','FONT','CURVE'):obj.select_set(True)
bpy.context.view_layer.objects.active=next(o for o in scene.objects if o.select_get())
bpy.ops.object.convert(target='MESH')
bpy.ops.object.select_all(action='DESELECT')
batches={}
for obj in list(scene.objects):
 if obj.type=='MESH':
  mat=obj.data.materials[0] if obj.data.materials else None
  batches.setdefault((obj.parent,mat),[]).append(obj)
for (parent,material),objects in batches.items():
 if len(objects)>1:
  for obj in objects:obj.select_set(True)
  bpy.context.view_layer.objects.active=objects[0]
  bpy.ops.object.join()
  objects[0].select_set(False)
 objects[0].name=parent.name+' • '+(material.name if material else 'Surface')
# Use actual vertices for camera fitting. A small set of extreme points describes
# each assembly in the glTF world frame and includes X/Y/Z extrema exactly.
directions=[]
for elevation in np.linspace(-math.pi/2,math.pi/2,15):
 for yaw in np.linspace(0,math.tau,32,endpoint=False):
  directions.append([math.cos(elevation)*math.sin(yaw),math.sin(elevation),math.cos(elevation)*math.cos(yaw)])
D=np.array(directions+[[a,b,c] for a in (-1,1) for b in (-1,1) for c in (-1,1)],dtype=np.float32)
points={}
for obj in scene.objects:
 if obj.type!='MESH':continue
 top=obj
 while top.parent:top=top.parent
 data=np.empty(len(obj.data.vertices)*3,np.float32);obj.data.vertices.foreach_get('co',data);mat=np.array(obj.matrix_world)
 p=data.reshape(-1,3)@mat[:3,:3].T+mat[:3,3];p=p[:,[0,2,1]];p[:,2]*=-1
 points.setdefault(top.name,[]).append(p)
support={}
for name,chunks in points.items():
 p=np.vstack(chunks).astype(np.float32);selected=[]
 for ax in np.array_split(D,20):selected.extend(np.argmax(p@ax.T,axis=0))
 support[name]=np.unique(p[selected].round(4),axis=0).astype('float64').round(4).tolist()
(base/'assembly-hulls.json').write_text(json.dumps(support,separators=(',',':')))
print('ASSEMBLIES',len(support),'WEB PRIMITIVES',len(batches),'TRIANGLES',sum(len(o.data.loop_triangles) for o in scene.objects if o.type=='MESH'),flush=True)
bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',export_apply=True,export_yup=True,export_extras=True,export_animations=False,export_draco_mesh_compression_enable=True,export_draco_mesh_compression_level=6,export_draco_position_quantization=16,export_draco_normal_quantization=12,export_copyright='Adapted from Tesla Model Y 2021 by 763468712 under CC BY 4.0. See review.html for attribution and changes.')
