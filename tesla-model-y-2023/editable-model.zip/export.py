"""Run in desktop Blender after building the master to compress the web delivery."""
import bpy,sys
from pathlib import Path
base=Path(__file__).resolve().parent
out=Path(sys.argv[sys.argv.index('--')+1]).resolve() if '--' in sys.argv else base.parents[1]/'site/tesla-model-y-2023/model-y.glb'
for mesh in bpy.data.meshes:
 mesh.validate(clean_customdata=False)
s=bpy.context.scene
s['source_model']='Tesla Model Y 2021 by 763468712, CC BY 4.0'
s['source_url']='https://sketchfab.com/3d-models/tesla-model-y-2021-c0a86cac582d4b33aba0fb1b1912d970'
s['license']='https://creativecommons.org/licenses/by/4.0/'
s['adaptation']='2023 US Long Range; dimensioned body and running gear, Gemini covers, hinged closures, cabin, display and drive assemblies.'
bpy.ops.wm.save_as_mainfile(filepath=str(base/'2023_Model_Y.blend'),compress=True)
bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',export_apply=True,export_yup=True,export_extras=True,export_animations=False,export_draco_mesh_compression_enable=True,export_draco_mesh_compression_level=6,export_draco_position_quantization=16,export_draco_normal_quantization=12,export_copyright='Adapted from Tesla Model Y 2021 by 763468712 under CC BY 4.0. See review.html for attribution and changes.')
