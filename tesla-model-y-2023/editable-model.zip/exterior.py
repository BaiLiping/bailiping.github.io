"""Exterior, closures and glazing in the source's assembled coordinate frame."""
from collections import defaultdict
from scipy.spatial import cKDTree

privacy=mat('Mat_Rear_Privacy_Glass',(.007,.018,.026),.16,.13,.60)
frit=mat('Ceramic glass border',(.008,.010,.013),.09,.21)
projector=mat('Projector optics',(.05,.10,.16),.35,.05)
guide=mat('Pearl daytime light guide',(.92,.95,.98),.10,.18)
amber=mat('Amber side marker',(.66,.16,.008),.18,.24)
smoke=mat('Dark optical baffle',(.010,.012,.015),.22,.30)
redguide=mat('Red tail light guide',(.62,.010,.016),.18,.18)
tail_smoke_refl=mat('Smoked tail reflector',(.11,.012,.016),.55,.24)
wheelwell=mat('Wheel housing liner',(.015,.017,.019),0,.88)
machined=mat('Turned brake rotor',(.30,.32,.33),.79,.34)
alloy=mat('Gemini alloy graphite',(.13,.15,.165),.69,.32)
lugmetal=mat('Wheel hardware',(.21,.22,.23),.86,.29)

for name,origin in {
 'Body':[0,0,0],'Underbody':[0,.24,0],'Cabin':[0,.92,.52],'CabinFloor':[0,.32,0],
 'Console':[0,.51,.07],'FrontSeatLeft':[.405,.38,-.1],'FrontSeatRight':[-.405,.38,-.1],
 'RearSeat':[0,.40,-1.01],'FrontDrive':[0,.36,1.445],'RearDrive':[0,.36,-1.445],
 'FrontCarrier':[0,.30,1.445],'RearCarrier':[0,.29,-1.445],'Pack':[0,.25,0],
 'RoofGlass':[0,1.57,-.53],'Windshield':[0,1.3,.69],
 'Hood':[0,1.03,1.14],'Liftgate':[0,1.44,-1.37],'FrontFascia':[0,.55,2.03],
 'ChargeDoor':[.729,1.095,-1.99],'RearFascia':[0,.57,-2.15],'Frunk':[0,.67,1.60],'Cargo':[0,.58,-1.73]
}.items():group(name,origin)
for side,sg in [('Left',1),('Right',-1)]:
 group('Headlamp'+side,[sg*.71,.79,1.91]);group('TailLamp'+side,[sg*.71,.98,-2.06])
 group('Fender'+side,[sg*.78,.73,1.55])
 for row,z in [('Front',1.445),('Rear',-1.445)]:
  for prefix in ('Wheel','Brake','Cover'):group(prefix+row+side,[.818*sg,.356,z])
 for row,z in [('Front',.91),('Rear',-.30)]:group('Door'+row+side,[sg*.855,.78,z])

def door(x,z):return 'Door'+('Front' if z>-.22 else 'Rear')+('Left' if x>0 else 'Right')
def panel_id(lo,hi):
 x,y,z=(lo+hi)/2;side='Left' if x>0 else 'Right'
 if lo[2]>.34 and hi[0]-lo[0]>.4:return 'FrontFascia'
 if lo[2]<-.78 and hi[1]<.173 and hi[2]>-.68:return 'RearFascia'
 if lo[2]>.12 and hi[2]>.47 and hi[0]-lo[0]<.18:return 'Fender'+side
 if lo[2]>.19 and lo[1]>.10:return 'Hood'
 if hi[2]<-.49 and lo[1]>.075 and hi[0]-lo[0]>.23:return 'Liftgate'
 return 'Body'

buffers=defaultdict(list)
def add(g,m,v,f,normals=None):
 buffers[g,m].append((np.asarray(v),np.asarray(f),None if normals is None else np.asarray(normals)))
def patch(g,m,v,f):add(g,m,v,f)
surfaces=defaultdict(list)
def emit(g,m,vs,ff,n,store_surface=True):
 coords=body(vs)
 normals=n/scale
 if g=='Liftgate' and m in (redguide,tailLens):
  # The illuminated inner tips in the 2023 orbit sit 85 mm farther out than the
  # donor guide. Fit the guide and its ruby insert inside the original clear lens.
  # The outer end stays on the liftgate seam. Coordinates are left, up, forward.
  span=.570-.335
  u=np.clip((np.abs(coords[:,0])-.335)/span,0.,1.)
  taper=1.-u*u*(3.-2.*u)
  slope=-6.*u*(1.-u)/span
  lateral=np.sign(coords[:,0])
  coords+=taper[:,None]*np.column_stack((.085*lateral,np.full(len(vs),.025),np.full(len(vs),.017)))
  # Transform the authored normals with the inverse transpose of the local warp.
  normals=normals.copy()
  normals[:,0]=(normals[:,0]-slope*lateral*(.025*normals[:,1]+.017*normals[:,2]))/(1.+.085*slope)
 add(g,m,coords,ff,normals)
 if g in ('Hood','Liftgate','Windshield','FrontSeatLeft','FrontSeatRight','RearSeat') or g.startswith('Door') and m==paint and store_surface:
  surfaces[g,m].append(coords)
def glass_border(g,coords,ff,n,wide=.025):
 # Measure distance on the pane to its real perimeter. Interpolate a band even on sparse glass.
 mesh=trimesh.Trimesh(coords,ff,process=True)
 idx,counts=np.unique(mesh.edges_sorted,axis=0,return_counts=True)
 edges=idx[counts==1]
 if len(edges)<3:return
 center=coords.mean(0)
 # A continuous strip on the inward face follows the curved perimeter in 3D.
 verts=[];faces=[]
 for a,b in mesh.vertices[edges]:
  start=len(verts)
  for p in [a,b]:
   inward=center-p;inward/=np.linalg.norm(inward)
   verts.extend([p+[0,-.0015,0],p+inward*wide+[0,-.0015,0]])
  faces.extend([(start,start+2,start+1),(start+1,start+2,start+3)])
 add(g,frit,verts,faces)

opal=mat('Opal headlamp diffuser',(.70,.74,.75),.01,.49)
dark_optic=mat('Vacuum-metalized lamp channel',(.022,.026,.032),.55,.26)
exec(compile((HERE/'optics.py').read_text(),str(HERE/'optics.py'),'exec'))
divider=mat('Metallized reflector dividers',(.016,.019,.023),.42,.32)
paint_arrays=[]
for name,v,f,n in source_meshes():
 id=int(name.split('_')[0]);matname=name.split('_',1)[1].rsplit('_',1)[0]
 if id==103:
  paint_arrays.append((v,f,n));continue
 if id in (37,41,45,83,92,88,90):continue
 if id<=33:
  if id>=26:continue # Replace the larger donor rims and tires with the 19-inch package.
  c=(v.min(0)+v.max(0))/2
  side='Left' if c[0]>0 else 'Right';row='Front' if c[2]>0 else 'Rear'
  g='Brake'+row+side;hub=groups[g][1]
  oldhub=np.array([.214 if c[0]>0 else -.2205,.022,.2815 if c[2]>0 else -.5285])
  dims=np.array([2.85,2.90,2.90]) if row=='Front' else np.array([2.85,3.02,3.02]);vv=(v-oldhub)*dims+hub
  add(g,machined if 'dsk' in name else (alloy if 'caliper' in name else lugmetal),vv,f,n/dims);continue
 # Component boundaries, including the liftgate half of each lamp, are authored seams.
 tags=components(v,f)
 for t in np.unique(tags):
  inds,ind=np.unique(f[tags==t],return_inverse=True);vs=v[inds];ff=ind.reshape(-1,3);ns=n[inds]
  lo,hi=vs.min(0),vs.max(0);x,y,z=(lo+hi)/2;side='Left' if x>0 else 'Right'
  g='Body';m=trim
  if id==43:
   if t in [0,22,23,27,32,33,39,41]:continue
   continue  # The 2023 photographed upholstery is rebuilt in seats.py.
  elif id==46:g='RoofGlass';m=roof
  elif id==93:g='Windshield';m=window
  elif id==36:g='Liftgate';m=privacy
  elif id==47:
   if z>-.22:g=door(x,z);m=door_glass
   elif z>-.46:g=door(x,z);m=privacy
   else:g='Body';m=quarter_glass
  elif id in (44,80,85,97,98):
   g=door(x,z);m=paint if id in (80,98) else (side_mirror_glass if id==85 else trim)
  elif id==102:
   if hi[1]<.25:g=door(x,z)
  elif id==101:
   m=arch
   if hi[0]-lo[0]>.44:g='RearFascia'
   elif z>.40:g='FrontFascia'
   elif z>.22:g='Fender'+side
  elif id==48:g='Underbody';m=wheelwell
  elif id in (49,54):g='Windshield';m=cabin_rearview_mat if id==49 else trim
  elif id in (51,55,56):g='Body';m=trim
  elif id in (52,53,57,58,76,81,84,86,87,89,99):
   g='FrontFascia';m={52:wheelwell,53:wheelwell,86:fog_lens,87:smoke,89:amber,57:smoke}.get(id,trim)
  elif id in (59,68,69,70,71,72,73,74,77,78,79,82,100):
   g='Headlamp'+side
   m={59:lens,68:dark_optic,69:guide,70:smoke,71:smoke,72:smoke,73:liner,74:smoke,77:dark_optic,78:smoke,79:dark_optic,82:smoke,100:metal}[id]
  elif id in (34,35,40,61,62,63,64,65,67,94,96):
   g='Liftgate' if hi[2]<-.727 and abs(x+.0034)<.155 else 'TailLamp'+side
   m={34:rear,35:liner,40:tail_clear_lens,61:tail_smoke_refl,62:amber,63:tailLens,64:liner,65:smoke,67:tailLens,94:tail_clear_lens,96:redguide}[id]
   if side=='Left' and (id in (34,35,67) or id==94 and lo[2]>-.718):g='ChargeDoor'
  elif id in (38,39,95):g='RearFascia';m=rear if id==38 else tailLens
  elif id in (60,66):g='Liftgate';m=chrome if id==66 else trim
  elif id==91:g='Hood';m=chrome
  elif id==50:g='Fender'+side
  if id==100:
   opal_diffuser(g,body(vs));continue
  if id in (68,77,79):m=dark_optic
  if id in (72,74,78):m=divider
  emit(g,m,vs,ff,ns,id!=80)
  if id in (50,59,93):surfaces[g,id].append(body(vs))
  if id in (47,98):surfaces['Side envelope',side].append(body(vs))
  if id in (46,93,36,47):glass_border(g,body(vs),ff,ns,.030 if id in (46,93,36) else .010)

v=np.vstack([v for v,f,n in paint_arrays]);n=np.vstack([n for v,f,n in paint_arrays])
offset=0;faces=[]
for vs,ff,ns in paint_arrays:faces.append(ff+offset);offset+=len(vs)
f=np.vstack(faces);tags=components(v,f)
for t in np.unique(tags):
 inds,ind=np.unique(f[tags==t],return_inverse=True);vs=v[inds]
 emit(panel_id(vs.min(0),vs.max(0)),paint,vs,ind.reshape(-1,3),n[inds])

exec(compile((HERE/'gemini.py').read_text(),str(HERE/'gemini.py'),'exec'))
# Preserve the split vertex normals on every original panel, lens and reflector.
# Generated parts without authored normals have shared rims and smooth cross-sections.
for (g,m),items in buffers.items():
 for authored in (True,False):
  chunks=[item for item in items if (item[2] is not None)==authored]
  if not chunks:continue
  vs=np.vstack([v for v,f,n in chunks]);ff=[];k=0
  for v,f,n in chunks:ff.append(f+k);k+=len(v)
  faces=np.vstack(ff);me=bpy.data.meshes.new(g+' '+m)
  me.from_pydata(blender(vs-groups[g][1]).tolist(),[],faces.tolist());me.update();me.materials.append(materials[m])
  me.polygons.foreach_set('use_smooth',np.ones(len(me.polygons),dtype=bool))
  if authored:
   normals=blender(np.vstack([n for v,f,n in chunks]));normals/=np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-9)
   me.use_auto_smooth=True;me.normals_split_custom_set_from_vertices(normals.tolist())
  ob=bpy.data.objects.new(me.name,me);bpy.context.collection.objects.link(ob);ob.parent=groups[g][0]
