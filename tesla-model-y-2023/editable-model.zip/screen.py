"""Create an original schematic of the period landscape touchscreen for the model."""
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
root=Path(__file__).resolve().parent
im=Image.new('RGB',(672,410),'#e2e5e4');d=ImageDraw.Draw(im)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def t(x,y,text,size,col='#34404b'):
 d.text((x,y),text,font=ImageFont.truetype(font,size),fill=col)
d.rectangle((0,0,220,384),fill='#f3f4f5');t(19,16,'P',25);t(57,24,'R   N   D',12,'#808990');t(132,25,'78%',13)
d.rounded_rectangle((218,0,672,384),3,fill='#dfe2de')
for x,y in [(225,25),(375,270),(526,40)]:d.rounded_rectangle((x,y,x+95,y+79),radius=10,fill='#b4c8b1')
for m in range(-320,700,47):d.line([(m+260,0),(m+340,150),(m+535,380)],fill='#fafaf8',width=5)
for yy in range(-70,470,51):d.line([(220,yy+18),(435,yy),(672,yy-69)],fill='white',width=5)
d.line([(228,368),(310,310),(411,262),(462,198),(555,156),(672,115)],fill='#fafaf7',width=18)
d.line([(229,368),(310,310),(411,262),(462,198),(555,156),(672,115)],fill='#e9c37b',width=9)
d.rounded_rectangle((239,19,438,56),radius=13,fill='#f7f7f7');t(259,27,'Navigate',16)
d.polygon([(449,176),(439,205),(450,198),(458,204)],fill='#3679b0')
# Three-quarter silhouette of the blue crossover in the left status region.
d.ellipse((29,197,197,235),fill='#c3c8c9');d.polygon([(34,202),(47,181),(68,171),(94,143),(136,139),(162,149),(177,167),(192,178),(189,204),(161,218),(48,218)],fill='#28445f')
d.polygon([(75,170),(99,146),(132,144),(153,151),(162,161),(134,170)],fill='#94aab6')
d.polygon([(34,200),(82,205),(175,185),(188,179),(186,200),(152,214),(49,218)],fill='#355b80')
for x,y in [(60,214),(161,205)]:
 d.ellipse((x-9,y-13,x+8,y+8),fill='#29333a');d.ellipse((x-5,y-8,x+4,y+4),fill='#abb1b3')
d.rounded_rectangle((26,275,191,313),12,fill='#e9ecee');t(57,284,'Model Y',17)
d.rectangle((0,370,672,410),fill='#262a2c')
for i,mark in enumerate(['●','20°','‹','▦','♫','◉','›','20°']):t(20+i*82,378,mark,18,'#e8ebed')
im.save(root/'display.png')
