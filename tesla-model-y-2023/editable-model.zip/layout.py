"""Place complete, unscaled assemblies on an oblique exploded drawing.
Project the physical envelopes to leave a clear line of sight to each component.
"""
from pathlib import Path
import numpy as np,json,math
base=Path(__file__).resolve().parent
site=base.parents[1]/'site/tesla-model-y-2023'
if not site.is_dir():site=base
cfg=json.loads((site/'studio.json').read_text())
hulls=json.loads((base/'assembly-hulls.json').read_text())
groups={
 'Body and glass':{'Body':'Fixed body shell','Hood':'Hood and inner stamping','Windshield':'Windshield and cameras','RoofGlass':'Panoramic roof glass','Liftgate':'Liftgate and rear glass','FrontFascia':'Front bumper fascia','RearFascia':'Rear bumper fascia','FenderLeft':'Left front fender','FenderRight':'Right front fender','HeadlampLeft':'Left headlamp','HeadlampRight':'Right headlamp','TailLampLeft':'Left taillight and charge inlet','TailLampRight':'Right taillight'},
 'Doors':{},'Cabin and luggage':{'Frunk':'Front trunk and apron','Cabin':'Dashboard and steering column','Console':'Center console','FrontSeatLeft':'Driver seat','FrontSeatRight':'Front passenger seat','RearSeat':'Rear bench','CabinFloor':'Cabin floor and pedals','Cargo':'Luggage compartment'},
 'Wheels and suspension':{'Underbody':'Underbody and wheel liners','FrontCarrier':'Front suspension and subframe','RearCarrier':'Rear suspension and subframe'},
 'Battery and drives':{'Pack':'Battery tray','Lid':'Battery lid','AncillaryCover':'Electronics service cover','AncillaryBay':'Rear electronics bay','HighVoltage':'High-voltage harness','FrontDrive':'Front induction drive','RearDrive':'Rear permanent-magnet drive'}}
for row in ('Front','Rear'):
 for side in ('Left','Right'):
  key=row+side;adj=f'{side.lower()} {row.lower()}';groups['Doors']['Door'+key]=adj.capitalize()+' door'
  for prefix,desc in [('Cover','Gemini cover'),('Wheel','wheel and tire'),('Brake','brake and hub')]:groups['Wheels and suspension'][prefix+key]=adj.capitalize()+' '+desc
for i in range(1,5):groups['Battery and drives']['Module'+str(i)]='Battery module '+str(i)
assert set(hulls)==set(n for items in groups.values() for n in items),(set(hulls),set(n for v in groups.values() for n in v))
# Front parts sit to the left of the shell and rear parts to the right.
wide=[
 'CoverFrontRight WheelFrontRight BrakeFrontRight HeadlampRight FenderRight DoorFrontRight Windshield RoofGlass DoorRearRight TailLampRight BrakeRearRight WheelRearRight CoverRearRight',
 'FrontFascia Hood Frunk Body Cargo Liftgate RearFascia',
 'HeadlampLeft FenderLeft DoorFrontLeft Cabin FrontSeatLeft FrontSeatRight Console RearSeat DoorRearLeft TailLampLeft',
 'CoverFrontLeft WheelFrontLeft BrakeFrontLeft FrontCarrier FrontDrive Underbody RearDrive RearCarrier BrakeRearLeft WheelRearLeft CoverRearLeft',
 'HighVoltage CabinFloor Lid AncillaryCover Module1 Module2 Module3 Module4 AncillaryBay Pack']
portrait=[
 'HeadlampRight FenderRight DoorFrontRight DoorRearRight TailLampRight',
 'FrontFascia Hood Windshield RoofGlass',
 'Frunk Body Cargo Liftgate RearFascia',
 'HeadlampLeft FenderLeft DoorFrontLeft DoorRearLeft TailLampLeft',
 'Cabin FrontSeatLeft FrontSeatRight Console RearSeat',
 'CoverFrontRight WheelFrontRight BrakeFrontRight Underbody BrakeRearRight WheelRearRight CoverRearRight',
 'CoverFrontLeft WheelFrontLeft BrakeFrontLeft FrontCarrier RearCarrier BrakeRearLeft WheelRearLeft CoverRearLeft',
 'FrontDrive CabinFloor RearDrive',
 'HighVoltage Lid AncillaryCover',
 'Module1 Module2 Module3 Module4',
 'AncillaryBay Pack']
q=np.array([1,.69,.76]);q=q/np.linalg.norm(q)
right=np.cross([0,1,0],q);right/=np.linalg.norm(right);up=np.cross(q,right)
axes=np.stack([right,up,q],axis=1)
def layout(rows):
 rows=[r.split() for r in rows]
 assert len([i for row in rows for i in row])==len(hulls) and {i for row in rows for i in row}==set(hulls)
 bounds={}
 for n,p in hulls.items():
  dots=np.array(p)@axes;bounds[n]=np.stack((dots.min(0),dots.max(0)))
 offsets={};bottom=.16
 for row in reversed(rows):
  width=sum(np.diff(bounds[n],axis=0)[0,0] for n in row)+.26*(len(row)-1)
  x=-width/2;rowheight=max(np.diff(bounds[n],axis=0)[0,1] for n in row)
  for n in row:
   lo,hi=bounds[n];mid=(lo+hi)/2;span=hi-lo
   # A small trace of installed depth preserves near/far parallax on orbit.
   dest=np.array([x+span[0]/2,bottom+rowheight/2,mid[2]*.28])
   offsets[n]=axes@(dest-mid);x+=span[0]+.26
  bottom+=rowheight+.28
 # Raise the whole drawing uniformly above the original tire contact plane.
 raise_by=.12-min(np.min(np.array(hulls[n])[:,1])+v[1] for n,v in offsets.items())
 for off in offsets.values():off[1]+=raise_by
 return {n:v.round(5).tolist() for n,v in offsets.items()}
w=layout(wide);p=layout(portrait)
cfg['parts']=[dict(node=n,label=text,system=system,offset=w[n],portraitOffset=p[n]) for system,items in groups.items() for n,text in items.items()]
# Local displacements in the focus view expose the parts that normally nest.
for part in cfg['parts']:
 name=part['node'];sg=-1 if name.endswith('Right') or name=='RearDrive' else 1
 if name.startswith('Wheel'):part['detail']={'Tire':[0,.16,-.49],'Alloy':[sg*.30,.09,.45]}
 elif name.startswith('Brake'):part['detail']={'Caliper':[sg*.19,.10,.24],'Rotor':[0,0,-.09]}
 elif name in ('FrontDrive','RearDrive'):
  part['detail']={'Motor':[-sg*.35,.12,.04],'Reduction':[sg*.12,.09,0],'Inverter':[0,.61,0],'Cooler':[sg*.15,.19,sg*.44],'ShaftLeft':[.77,-.24,.025],'ShaftRight':[-.77,-.24,-.025]}
cfg['model']='model-y.glb'
cfg['assemblyDrawing']={'direction':q.round(6).tolist(),'envelopes':'assembly-hulls.json','narrowAspect':1.16,'introHold':4000,'introDuration':2800}
cfg['home']=[5.9,1.91,4.39];cfg['target']=[0,.76,0];cfg['exteriorFov']=19
cfg['lighting']=dict(image='studio-light.webp',rotation=3.2,intensity=.61,ambient=.48,key=.92,fill=.38)
cfg['actions']=[a for a in cfg['actions'] if a['label']!='Open charge port']
next(a for a in cfg['actions'] if a['label']=='Raise hood')['nodes'][0]['degrees']=-66
cfg['actions'].append({'label':'Open charge port','nodes':[{'node':'ChargeLink','axis':'z','degrees':145},{'node':'ChargeHinge','axis':'z','degrees':-59}]})
pack=['Pack','Lid','AncillaryCover','AncillaryBay']+['Module'+str(i) for i in range(1,5)]
wheels=[n for n in hulls if n.startswith(('Brake','Wheel','Cover'))]
for rec in cfg['inspections']:
 if rec['id']=='electric-drive':rec['show']=pack+['FrontDrive','RearDrive','HighVoltage','FrontCarrier','RearCarrier']+wheels
 elif rec['id']=='battery':rec['show']=pack
 elif rec['id']=='battery-modules':rec['show']=[n for n in pack if n not in ('Lid','AncillaryCover')]
(site/'studio.json').write_text(json.dumps(cfg,indent=2)+'\n')
(site/'assembly-hulls.json').write_text((base/'assembly-hulls.json').read_text())
