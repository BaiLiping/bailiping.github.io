"""Fit inner stampings, door caps and luggage trim to the installed panel envelopes."""
from scipy.ndimage import gaussian_filter1d
import cv2
# Installed fixed reinforcements must stay inboard of the curved glass and outer skins.
bpy.context.view_layer.update()
for side,sg in [('Left',1),('Right',-1)]:
 ref=np.vstack(surfaces['Side envelope',side]);tree=cKDTree(ref[:,[1,2]])
 for obj in groups['Body'][0].children:
  if obj.type!='MESH' or not obj.name.startswith(('B pillar','Rear wheelhouse pillar','Lower A pillar')):continue
  M=np.array(obj.matrix_world);mi=np.linalg.inv(M)
  for v in obj.data.vertices:
   world=M@np.r_[v.co,1.];x,y,z=world[0],world[2],-world[1]
   if x*sg<=0:continue
   _,ii=tree.query([y,z],k=36);skin=np.quantile(abs(ref[ii,0]),.70)
   world[0]=sg*min(abs(x),skin-.048);v.co=(mi@world)[:3]
  obj.data.update()
 for row in ('Front','Rear'):
  g='Door'+row+side;coords=np.vstack(surfaces[g,paint]);tri=next((o for o in groups[g][0].children if o.name.startswith(g+' '+paint)),None)
  for ob in list(groups[g][0].children):
   if ob.name.startswith((g+' hem and',g+' perimeter seal',g+' inner beltline',g+' top rail')):bpy.data.objects.remove(ob,do_unlink=True)
  # Trace the stamped door in its side plane, preserving the rear wheel notch.
  loc=groups[g][1];arr=np.array([v.co[:] for v in tri.data.vertices]);world=arr[:,[0,2,1]]*[1,1,-1]+loc
  keep=(sg*world[:,0]<.985)&(world[:,1]<1.18)
  yz=world[:,[2,1]];bbox=yz[keep].min(0)-.01;pix=np.rint((yz-bbox)*650).astype('int32')
  mask=np.zeros((int(pix[keep,1].max()+10),int(pix[keep,0].max()+10)),np.uint8)
  tri.data.calc_loop_triangles()
  for f in tri.data.loop_triangles:
   inds=list(f.vertices)
   if np.all(keep[inds]):cv2.fillConvexPoly(mask,pix[inds],255)
  contour=max(cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)[0],key=cv2.contourArea).reshape(-1,2)/650+bbox
  contour=contour[::max(1,len(contour)//220)];cz,cy=np.mean(contour,axis=0);ctree=cKDTree(coords[:,[2,1]])
  inds=ctree.query(contour,k=18)[1];xabs=gaussian_filter1d(np.median(abs(coords[inds,0]),axis=1),2,mode='wrap')
  rings=[]
  for inset,scale_ in [(.013,.996),(.030,.988),(.052,.978),(.066,.966)]:
   rings.append([[sg*(x-inset),cy+(y-cy)*scale_-.003,cz+(z-cz)*scale_] for x,(z,y) in zip(xabs,contour)])
  flat_ring('Painted inner door return',g,rings,paint)
  polyline('Lower door weatherstrip',g,rings[-1]+[rings[-1][0]],.0045,trim)
  # Taper the padded sill into both ends of the frameless window.
  zmin,zmax=coords[:,2].min(),coords[:,2].max()
  zs=np.linspace(zmin+.056,zmax-.075,42);levels=[];outer=[]
  for z in zs:
   band=coords[np.abs(coords[:,2]-z)<.029]
   if len(band)<8:band=coords[np.argsort(abs(coords[:,2]-z))[:32]]
   yy=np.quantile(band[:,1],.97);top=band[band[:,1]>yy-.025]
   levels.append(yy);outer.append(np.median(abs(top[:,0])))
  levels=gaussian_filter1d(levels,2);outer=gaussian_filter1d(outer,2);rings=[]
  for z,y,x in zip(zs,levels,outer):
   rings.append([[sg*xx,yy,z] for xx,yy in [(x-.010,y+.006),(x-.026,y+.010),(x-.044,y+.008),(.728,y-.003),(.704,y-.023),(.706,y-.056),(.732,y-.071),(x-.018,y-.040)]])
  closed_sweep('Padded upper inner door rail',g,rings,cabin)
 # Close the inboard side of each liner, leaving the real suspension within the wheelhouse.
 for row,z0 in [('Front',1.445),('Rear',-1.445)]:
  xx=sg*.544;arc=[[xx,.356+.40*math.sin(a),z0+.40*math.cos(a)] for a in np.linspace(-.15,math.pi+.15,67)]
  faced('Inboard wheelhouse shield','Underbody',arc+[[xx,.259,z0-.39],[xx,.259,z0+.39]],[tuple(range(len(arc)+2))],wheelwell)

# Roof-height reinforcement and trim loop finish the liftgate opening around the load floor.
half=np.array([[0,1.431,-1.522],[.27,1.424,-1.538],[.496,1.381,-1.594],[.576,1.309,-1.689],[.635,1.194,-1.821],[.664,1.053,-1.975],[.661,.884,-2.101],[.645,.765,-2.163],[.601,.694,-2.191],[.524,.648,-2.208],[.345,.634,-2.217],[0,.633,-2.219]])
outline=np.vstack([half,half[-2:0:-1]*[-1,1,1]])
inner=outline.copy();inner[:,0]*=.949;inner[:,1]=1.011+(inner[:,1]-1.011)*.942;inner[:,2]+=.024
flat_ring('Liftgate opening inner return','Body',[outline,(outline+inner)/2+[0,0,.005],inner],ecoat)
polyline('Liftgate aperture weather seal','Body',list(inner)+[inner[0]],.010,trim)
for ob in list(groups['Cargo'][0].children):
 if ob.name.startswith(('Rear load-space trim','Rear trunk load floor','Rear trunk threshold')):bpy.data.objects.remove(ob,do_unlink=True)
floor_outline=[(-.55,-1.135),(-.608,-1.234),(-.609,-1.90),(-.57,-2.139),(-.492,-2.181),(.492,-2.181),(.57,-2.139),(.609,-1.90),(.608,-1.234),(.55,-1.135)]
extrusion('Carpeted removable load floor','Cargo',floor_outline,.582,.047,carpet,.014)
for side,sg in [('Left',1),('Right',-1)]:
 zs=np.linspace(-2.15,-1.16,35);rings=[]
 for z in zs:
  bulge=np.exp(-((z+1.48)/.29)**2);rise=.90+.12*bulge-.11*np.exp(-((z+2.15)/.12)**2)
  rings.append([[sg*x,y,z] for x,y in [(.655,.585),(.575-.095*bulge,.625),(.564-.13*bulge,.684),(.583-.089*bulge,.792),(.601, rise-.041),(.630,rise),(.674,rise-.008),(.684,.704)]])
 closed_sweep('Carpeted wheel arch and side bin','Cargo',rings,carpet)
 box('Cargo hook','Cargo',[sg*.589,.765,-1.99],[.014,.034,.032],trim,.006)
box('Liftgate scuff plate','Cargo',[0,.636,-2.162],[1.03,.026,.106],trim,.012)
for x in np.linspace(-.435,.435,13):box('Scuff plate molded groove','Cargo',[x,.650,-2.164],[.004,.002,.069],stitch,.001)
box('Load floor pull handle','Cargo',[0,.631,-2.067],[.084,.007,.021],trim,.005)
# Rear-facing kick plate and factory anchor marking on the second row.
for x in (-.47,.47):
 box('Child restraint upper anchor cover','RearSeat',[x,.961,-1.277],[.054,.067,.015],trim,.006,-.20)
# Turn the donor's side reflector backing into a recessed charging well.
flap_back=[(v,f) for v,f,n in buffers['ChargeDoor',liner]]
for v,f in flap_back:
 ob=faced('Charging well rear liner','TailLampLeft',v-normal*.017,f.tolist(),trim)
 for face in ob.data.polygons:face.use_smooth=True
for offset in (-.062,.060):
 pp=mid+along*offset+vertical*.025
 box('Charge door hinge arm','ChargeDoor',pp+[.005,.012,0],[.014,.052,.019],trim,.004)
# Liftgate inner liner caps the back of the optics and folds in with the hatch.
section=[(.621,-2.176,.514),(.663,-2.181,.564),(.752,-2.186,.599),(.867,-2.197,.626),(.990,-2.188,.636),(1.081,-2.161,.617),(1.138,-2.156,.590),(1.190,-2.098,.535)]
rings=[]
for yy,zz,ww in section:
 rings.append([[u*ww,yy-.015*u*u,zz+.111*abs(u)**3] for u in np.linspace(-1,1,43)])
n=43;faces=[(k*n+j,k*n+j+1,(k+1)*n+j+1,(k+1)*n+j) for k in range(len(rings)-1) for j in range(n-1)]
o=faced('Liftgate molded interior panel','Liftgate',np.vstack(rings),faces,cabin)
for face in o.data.polygons:face.use_smooth=True
box('Liftgate latch access cover','Liftgate',[0,.699,-2.152],[.148,.067,.010],trim,.012)
# Build KD-tree of painted exterior body skin so interior quarter/A-pillar trim never pokes outside.
_body_paint_pts = np.vstack([v for v, f, n in buffers['Body', paint]])
_body_tree = {
 1: cKDTree(_body_paint_pts[_body_paint_pts[:, 0] > 0.25][:, [1, 2]]),
 -1: cKDTree(_body_paint_pts[_body_paint_pts[:, 0] < -0.25][:, [1, 2]]),
}
_body_side_pts = {
 1: _body_paint_pts[_body_paint_pts[:, 0] > 0.25],
 -1: _body_paint_pts[_body_paint_pts[:, 0] < -0.25],
}
def clamp_inboard(sg, x_abs, y, z, margin=0.028):
 _, ii = _body_tree[sg].query([y, z], k=min(24, len(_body_side_pts[sg])))
 skin_x = float(np.quantile(np.abs(_body_side_pts[sg][ii, 0]), 0.35))
 return min(x_abs, max(0.45, skin_x - margin))

for sg in (-1,1):
 # Quarter trim covers the reverse of the fixed light outside the liftgate seam — strictly clamped inside exterior skin!
 rows=[]
 for z,x,y in [(-2.19,.53,1.10),(-2.05,.58,1.15),(-1.88,.62,1.175),(-1.65,.645,1.18),(-1.43,.665,1.165),(-1.28,.685,1.135)]:
  pts_row = [
   (x+.010, .67), (x-.016, .786), (x-.004, y-.069), (x+.006, y), (x+.018, y+.008)
  ]
  rows.append([[sg*clamp_inboard(sg, xx, yy, z, 0.028), yy, z] for xx, yy in pts_row])
 faces=[(k*5+j,k*5+j+1,(k+1)*5+j+1,(k+1)*5+j) for k in range(len(rows)-1) for j in range(4)]
 ob=faced('Cargo quarter liner','Cargo',np.vstack(rows),faces,carpet)
 for poly in ob.data.polygons:poly.use_smooth=True

# 2023 Model Y 4-panel folding cargo privacy parcel shelf resting on rear side ledges
for idx, (z_f, z_b) in enumerate([(-1.28, -1.445), (-1.452, -1.615), (-1.622, -1.785), (-1.792, -1.96)]):
 z_mid = 0.5 * (z_f + z_b)
 half_w = 0.575 - 0.015 * idx
 box(f'Cargo parcel shelf panel {idx+1}', 'Cargo', [0.0, 0.904, z_mid], [half_w * 2.0, 0.014, abs(z_f - z_b) - 0.005], carpet, 0.004)
for sg in (-1, 1):
 box('Cargo parcel shelf side rail', 'Cargo', [sg * 0.585, 0.892, -1.62], [0.026, 0.018, 0.72], trim, 0.005)
for sg in (-1,1):
 # Rails remain below the bonded glass and terminate in the cargo side lining.
 pillar_pts=[[sg*.603,1.50,-.33],[sg*.638,1.407,-.33],[sg*.684,1.27,-.33],[sg*.738,1.092,-.31]]
 vv=[]
 for x,y,z in pillar_pts:
  for dz in (-.037,.037):vv.append([x-sg*.020,y,z+dz])
 ob=faced('Upper seat belt pillar trim','Body',vv,[(i*2,i*2+1,i*2+3,i*2+2) for i in range(3)],headliner,.006)
 for kind,data in [('Front',[(.685,1.269,-.315),(.721,1.092,-.312),(.727,.845,-.320),(.725,.449,-.322)]),('Rear',[(.637,1.256,-1.41),(.650,1.116,-1.329),(.666,.915,-1.21),(.669,.635,-1.10)])]:
  vv=[]
  for x,y,z in data:
   vv.extend([[sg*x,y,z-.020],[sg*x,y,z+.020]])
  faced(kind+' outer seatbelt webbing','Body',vv,[(k*2,k*2+1,k*2+3,k*2+2) for k in range(len(data)-1)],pad)
 box('Folded sun visor','Body',[sg*.319,1.480,.273],[.376,.028,.139],headliner,.013,-.19)
# Recess the inner hatch weatherstrip below the sheet metal at the back of the roof.
for obj in groups['Body'][0].children:
 if obj.name.startswith(('Liftgate aperture weather seal','Liftgate opening inner return')):obj.location+=Vector([0,-.038,-.019])

# Trace the bonded windshield and roof at each cross section. Both sides of the
# rail sit under the exterior skin. The dark backing faces the glass.
for obj in list(groups['Cabin'][0].children):
 if obj.name.startswith('A-pillar fabric trim'):bpy.data.objects.remove(obj,do_unlink=True)
glazing=[]
for name,mat_ in [('Windshield',window),('RoofGlass',roof),('Liftgate',privacy)]:
 for vs,ff,_ in buffers[name,mat_]:
  tri=vs[ff];glazing.append(np.stack((tri,np.roll(tri,-1,axis=1)),axis=2).reshape(-1,2,3))
edges=np.vstack(glazing)
for sg in (-1,1):
 rail=[];zs=np.linspace(1.059,-1.515,94)
 for z in zs:
  section=edges[(edges[:,0,2]<z)!=(edges[:,1,2]<z)]
  cross=section[:,0]+(section[:,1]-section[:,0])*((z-section[:,0,2])/(section[:,1,2]-section[:,0,2]))[:,None]
  if not len(cross):continue
  datum=cross[np.argmax(sg*cross[:,0])]
  # Slightly wider inner A-pillar fabric flange along windshield (z>0.15) to seal exterior paint bleed inside cabin
  a_ext = 0.016 if z > 0.15 else 0.0
  cross_profile=[(-.030,-.021),(-.010,-.024),(.003,-.033),(.014,-.047),(.022+a_ext,-.066),(.010+a_ext*0.6,-.070),(-.014,-.054),(-.030,-.038),(-.034,-.030)]
  rail.append([[sg*clamp_inboard(sg, abs(datum[0]+sg*dx), datum[1]+dy, z, 0.008) if dx > 0 else datum[0]+sg*dx, datum[1]+dy, z] for dx,dy in cross_profile])
 n=len(rail[0]);verts=np.vstack(rail)
 for label,indices,material in [('Roof rail fabric lining',range(4,8),headliner),('Roof rail outer wrap',[8,0,1,2,3],trim)]:
  faces=[(k*n+i,k*n+(i+1)%n,(k+1)*n+(i+1)%n,(k+1)*n+i) for k in range(len(rail)-1) for i in indices]
  ob=faced(label,'Body',verts,faces,material)
  for poly in ob.data.polygons:poly.use_smooth=True
# The circular tow-eye access cover follows the curvature of the front bumper.
fascia=np.vstack([v for v,f,n in buffers['FrontFascia',paint]])
nose=fascia[(fascia[:,2]>2.00)&(fascia[:,1]>.38)&(fascia[:,1]<.83)]
tree=cKDTree(nose[:,:2])
def nose_depth(x,y):
 d,ind=tree.query([x,y],k=18);local=nose[ind];weights=1/(d+.001)
 c,*_=np.linalg.lstsq(np.c_[local[:,0]-x,local[:,1]-y,np.ones(len(ind))]*weights[:,None],local[:,2]*weights,rcond=None)
 return c[-1]
cx,cy=.539,.561;r=.037
rings=[]
for size,depth in [(r+.001,.0018),(r,.0021),(r-.0011,.0018)]:
 ring=[]
 for a in np.linspace(0,math.tau,66,endpoint=False):
  x=cx+size*math.cos(a);y=cy+size*math.sin(a);ring.append([x,y,nose_depth(x,y)+depth])
 rings.append(ring)
flat_ring('Front bumper tow-eye cover seam','FrontFascia',rings,trim)

# A padded common rear seat frame remains behind the three split folding backrests.
rings=[]
for y,w,z,d in [(.545,.619,-1.185,.042),(.566,.670,-1.182,.051),(.627,.684,-1.199,.051),(.791,.679,-1.235,.042),(.984,.656,-1.285,.040),(1.052,.609,-1.297,.036),(1.074,.531,-1.302,.022)]:
 rings.append([[w*np.sign(math.cos(a))*abs(math.cos(a))**.42,y,z+d*np.sign(math.sin(a))*abs(math.sin(a))**.73] for a in np.linspace(0,math.tau,68,endpoint=False)])
closed_sweep('Split bench upholstered backing','RearSeat',rings,seatleather)
for sg in (-1,1):
 rings=[]
 for y,x,w,z,d in [(.546,.603,.028,-1.055,.116),(.580,.631,.045,-1.057,.125),(.709,.648,.041,-1.112,.112),(.902,.654,.037,-1.182,.109),(1.063,.643,.040,-1.242,.065),(1.120,.617,.025,-1.253,.040)]:
  rings.append([[sg*(x+w*math.cos(a)),y,z+d*math.sin(a)] for a in np.linspace(0,math.tau,38,endpoint=False)])
 closed_sweep('Outer rear seat bolster','RearSeat',rings,seatleather)
# The U.S. charge flap pivots about its inclined upper edge, ahead of a recessed
# graphite panel. Fit that panel to the complete lens opening.
from scipy.spatial import Delaunay
from mathutils import Quaternion
g='TailLampLeft'
for ob in list(groups[g][0].children):
 if ob.name.startswith(('Charging well rear liner','Charge socket bezel','Socket contact','Charge door hinge arm')):bpy.data.objects.remove(ob,do_unlink=True)
for ob in list(groups['ChargeDoor'][0].children):
 if ob.name.startswith('Charge door hinge arm'):bpy.data.objects.remove(ob,do_unlink=True)
normal=np.array([.925,0,-.380]);normal/=np.linalg.norm(normal);along=np.array([-normal[2],0,normal[0]]);vertical=np.array([0.,1.,0.])
flap=np.vstack([v for v,f,n in buffers['ChargeDoor',tail_clear_lens]])
xy=np.stack([flap@along,flap[:,1]],axis=1);depth=flap@normal
hull=ConvexHull(xy);edge=xy[hull.vertices];center=(edge.min(0)+edge.max(0))/2
# Use the forward percentile in each cell to fit the curved outer skin. A
# continuous quadratic avoids ripples from the stamped inner face of the flap.
uv0=xy-center
bins=np.floor(uv0/.008).astype(int)
samples=[]
for cell in np.unique(bins,axis=0):
 keep=np.all(bins==cell,axis=1);samples.append([*uv0[keep].mean(0),np.percentile(depth[keep],83)])
samples=np.asarray(samples)
def terms(u,v):return np.stack([np.ones_like(u),u,v,u*u,u*v,v*v],axis=-1)
coef=np.linalg.lstsq(terms(samples[:,0],samples[:,1]),samples[:,2],rcond=None)[0]
def outside_depth(u,v):return terms(u-center[0],v-center[1])@coef
def in_well(u,v,relief=0.):
 return along*u+vertical*v+normal*(outside_depth(u,v)-.018+relief)
perimeter=np.array([radial(edge,center,a) for a in np.linspace(0,math.tau,108,endpoint=False)])
grid_x,grid_y=np.meshgrid(np.linspace(edge[:,0].min(),edge[:,0].max(),35),np.linspace(edge[:,1].min(),edge[:,1].max(),22));grid=np.c_[grid_x.ravel(),grid_y.ravel()]
uv=np.vstack([perimeter,grid[(grid@hull.equations[:,:2].T+hull.equations[:,2]<-.0014).all(1)]])
verts=[in_well(*v) for v in uv];wellmat=mat('Charge recess molded graphite',(.069,.075,.078),.08,.59)
ob=faced('Molded charge port back panel',g,verts,Delaunay(uv).simplices.tolist(),wellmat)
for poly in ob.data.polygons:poly.use_smooth=True
flat_ring('Charging well edge return',g,[[in_well(*v,d) for v in perimeter] for d in [0,.005,.014]],trim)
# Fit an oblong brow around the two charge contacts and three signal contacts.
u,v=center+[-.008,-.010]
# Evaluate the shallow bezel on one local tangent plane to keep the socket planar.
c=in_well(u,v,.0035)
def point(dx,dy,d):return c+along*dx+vertical*dy+normal*d
rings=[]
for rx,ry,d in [(.026,.025,0),(.0265,.0257,.0018),(.0235,.0235,.0040),(.021,.021,.0034),(.0198,.0198,.0017),(.0001,.0001,.0017)]:
 ring=[]
 for a in np.linspace(0,math.tau,60,endpoint=False):
  cs,sn=math.cos(a),math.sin(a);ring.append(point(rx*np.sign(cs)*abs(cs)**.82*(1+.09*sn),ry*np.sign(sn)*abs(sn)**.85,d))
 rings.append(ring)
flat_ring('North American charge inlet bezel',g,rings,trim)
for a,b,r in [(-.009,.0085,.0054),(.009,.0085,.0054),(0,-.0065,.0038),(-.009,-.011,.0018),(.009,-.011,.0018)]:
 o=point(a,b,.0024)
 cylinder_between('Inlet contact surround',g,o,o+normal*.0015,r,alloy,28)
 cylinder_between('Inlet contact cavity',g,o+normal*.0015,o+normal*.0017,r*.77,trim,28)
mark=mat('Charge status lens',(.63,.75,.80),.12,.34)
for poly in [[(-.006,.002),(-.002,.0036),(.002,.0036),(.006,.002),(.004,.001),(0,.002),(-.004,.001)],[(-.004,.001),(0,.0018),(.004,.001),(.001,0),(0,-.006),(-.001,0)]]:
 vv=[in_well(u+.066+dx,v+.019+dy,.0009) for dx,dy in poly];faced('Charge status T',g,vv,[(0,k,k+1) for k in range(1,len(vv)-1)],mark)
# The two short links lift the flap clear of the well as the lid levels out.
# Both pivots follow the fore-aft incline of the quarter panel. The fixed ends
# stay on mounting pads inside the aperture in both positions.
u_mid=center[0]
top=edge[:,1].max()
anchor=in_well(u_mid,top-.032,.007)
mount=anchor-vertical*.046+normal*.011
group('ChargeHingeFrame',anchor);group('ChargeLink',anchor);group('ChargeHinge',mount)
reparent(groups['ChargeHingeFrame'][0],g)
frame=groups['ChargeHingeFrame'][0];frame.rotation_euler.z=math.atan2(along[0],along[2])
link=groups['ChargeLink'][0];link.parent=frame;link.location=(0,0,0);link.rotation_euler=(0,0,0)
pivot=groups['ChargeHinge'][0];reparent(pivot,'ChargeLink');pivot.rotation_euler=(0,0,0)
reparent(groups['ChargeDoor'][0],'ChargeHinge')
for du in [.056,-.053]:
 pin=anchor+along*du;pin2=mount+along*du
 base_pt=in_well(u_mid+du,top-.035,.0002)
 pipe('Charge flap bracket',g,[base_pt,pin-vertical*.003,pin],.006,trim)
 cylinder_between('Fixed flap pivot pin',g,pin-along*.011,pin+along*.011,.006,alloy,24)
 rings=[]
 for point,half,thick in [(pin,.007,.005),(pin*.91+pin2*.09,.012,.006),(pin*.50+pin2*.5+normal*.005,.010,.0045),(pin*.10+pin2*.90,.010,.005),(pin2,.007,.005)]:
  rings.append([point+along*x+normal*y for x,y in [(-half+.001,-thick),(half-.001,-thick),(half,-thick+.002),(half,thick-.002),(half-.001,thick),(-half+.001,thick),(-half,thick-.002),(-half,-thick+.002)]])
 arm=closed_sweep('Charge flap lifting link',g,rings,trim);reparent(arm,'ChargeLink')
 shoe=cylinder_between('Moving flap pivot pin',g,pin2-along*.011,pin2+along*.011,.0052,lugmetal,24)
 # The mounting ear bonds the flap rear face to its moving pivot.
 ear=closed_sweep('Bonded flap pivot ear',g,[[pt+along*a+vertical*b for a,b in [(-.011,-.007),(.011,-.007),(.011,.007),(-.011,.007)]] for pt in [pin2,in_well(u_mid+du,mount[1],.018)]],trim)
 reparent(ear,'ChargeDoor')
 reparent(shoe,'ChargeLink')
