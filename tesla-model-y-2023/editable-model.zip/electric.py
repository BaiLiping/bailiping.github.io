"""Non-structural four-module pack, 3DU-family drive units and HV connections.
Enclosure and castings trace the shape in Tesla's service illustrations.
Cell and winding geometry, capacities and serial-specific dimensions are unmodeled.
"""
module=mat('Module cover',(.66,.64,.52),.38,.42)
aluminum=mat('Stamped aluminium',(.47,.48,.47),.71,.34)
cast=mat('Cast housing',(.32,.341,.35),.74,.38)
orange=mat('HV connector insulation',(.77,.118,.008),.09,.41)
insulator=mat('Module edge insulation',(.61,.477,.107),.1,.46)
board=mat('Module control board',(.022,.152,.052),.18,.45)
bus=mat('Busbar shield',(.048,.052,.056),.11,.39)
lid=mat('Battery lid',(.020,.021,.024),.30,.40)
group('Lid',[0,.30,-.065])
group('AncillaryCover',[0,.408,-.933])
group('HighVoltage',[0,.30,0])
# Plan-form corners follow the scalloped service drawing. The hinge-side end is
# deeper under the second row for the electrical compartment.
outline=[(-.65,1.061),(-.76,.96),(-.772,.82),(-.758,.62),(-.766,.55),(-.772,-.92),(-.73,-1.04),(-.651,-1.156),(-.57,-1.18),(.57,-1.18),(.651,-1.156),(.73,-1.04),(.772,-.92),(.772,.55),(.758,.62),(.772,.82),(.76,.96),(.65,1.061)]
def extrusion(label,g,outline,y,h,m,bevel=.008):
 n=len(outline);verts=[(x,level,z) for level in (y,y+h) for x,z in outline]
 faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(k,(k+1)%n,n+(k+1)%n,n+k) for k in range(n)]
 return faced(label,g,verts,faces,m,bevel)
extrusion('Sealed lower tray','Pack',outline,.167,.039,arch)
# Side walls remain visible when the lid is removed.
for k,a in enumerate(outline):
 b=outline[(k+1)%len(outline)];segments=[a,b,(b[0]*.978,b[1]*.985),(a[0]*.978,a[1]*.985)]
 extrusion('Tray wall','Pack',segments,.204,.087,cast,.004)
extrusion('Perimeter lid gasket','Lid',outline,.289,.005,trim,.003)
extrusion('Stamped pack top','Lid',[(.993*x,.999*z) for x,z in outline],.294,.012,lid)
for index,x in enumerate((-.54,-.18,.18,.54)):
 length=1.99 if index in (0,3) else 2.13
 box('Module '+str(index+1),'Pack',[x,.246,-.023],[.335,.077,length],module,.015)
 for dx in np.linspace(-.106,.106,8):
  box('Longitudinal cover rib','Pack',[x+dx,.287,.067],[.007,.004,length-.255],aluminum,.0015)
 for dx in (-.15,.15):
  box('Insulating edge','Pack',[x+dx,.286,-.024],[.014,.005,length-.043],insulator,.003)
 box('Module monitoring board','Pack',[x,.291,-length/2+.11],[.146,.009,.130],board,.002)
 for j in (-1,1):
  cylinder_between('Module terminal','Pack',[x+j*.087,.284,-length/2+.044],[x+j*.087,.299,-length/2+.044],.014,metal,12)
 for z in [-.57,.03,.64]:
  box('Lid embossing','Lid',[x,.309,z],[.295,.011,.45],lid,.018)
for sg in (-1,1):
 box('Reinforced sill rail','Pack',[sg*.756,.230,-.065],[.029,.082,1.89],cast,.009)
 for z in np.linspace(-.92,.90,9):
  x=sg*.777
  extrusion('Side flange','Pack',[(x-.023,z-.039),(x+.023,z-.039),(x+.028,z-.022),(x+.028,z+.022),(x+.022,z+.039),(x-.023,z+.039)],.263,.012,cast,.006)
  cylinder_between('Flange bolt','Pack',[x,.274,z],[x,.281,z],.010,metal,8)
for z in (-1.04,-.64,-.22,.24,.70,.96):
 for x in [-.65,0,.65]:
  cylinder_between('Lid fastener','Lid',[x,.306,z],[x,.312,z],.007,metal,8)
# Rear ancillary bay has a separate service cover above the main plate.
bay=[(-.685,-.722),(-.646,-.686),(.646,-.686),(.685,-.722),(.68,-.991),(.595,-1.105),(.466,-1.127),(-.466,-1.127),(-.595,-1.105),(-.68,-.991)]
extrusion('Ancillary bay floor','Pack',bay,.309,.028,cast)
n=len(bay)
for i,(x,z) in enumerate(bay):
 x1,z1=bay[(i+1)%n];extrusion('Bay lip','Pack',[(x,z),(x1,z1),(.982*x1,-.91+(z1+.91)*.957),(.982*x,-.91+(z+.91)*.957)],.336,.092,lid,.006)
extrusion('Ancillary bay gasket','AncillaryCover',bay,.425,.008,trim,.004)
extrusion('Electronics service cover','AncillaryCover',[(x*.996,z) for x,z in bay],.433,.016,aluminum,.008)
# The central transverse embosses and paired diagonal channels follow the bare
# cover in the INL teardown (Figs. 7–8). They are separate from the fasteners.
for z in (-1.034,-.987,-.938,-.887,-.839):
 box('Central embossed channel','AncillaryCover',[0,.452,z],[.22,.013,.019],aluminum,.007)
for side in (-1,1):
 for z in (-.961,-.89):
  cylinder_between('Diagonal cover emboss','AncillaryCover',[side*.275,.451,z+.067],[side*.537,.451,z-.061],.009,aluminum,12)
 for x,z in ((.23,-.802),(.23,-1.037),(.52,-.776)):
  cylinder_between('Stamped boss','AncillaryCover',[side*x,.446,z],[side*x,.46,z],.027,aluminum)
  cylinder_between('Service bolt','AncillaryCover',[side*x,.46,z],[side*x,.466,z],.010,metal,8)
for i in (0,1,2,3,4,5,6,7,8,9):
 x,z=bay[i]
 cylinder_between('Cover rim fastener','AncillaryCover',[x*.968,.448,-.91+(z+.91)*.92],[x*.968,.456,-.91+(z+.91)*.92],.008,metal,8)
box('Blanked HV inlet','AncillaryCover',[.585,.461,-.878],[.063,.023,.052],orange,.012)
cylinder_between('Sealed charge port connection','AncillaryCover',[.579,.446,-.974],[.579,.469,-.974],.023,orange)
cylinder_between('Bay breather','AncillaryCover',[.371,.449,-.824],[.371,.46,-.824],.027,bus)
box('Low voltage socket','AncillaryCover',[-.543,.457,-.898],[.043,.02,.026],bus,.006)
box('Power conversion enclosure','Pack',[-.095,.378,-.917],[.683,.080,.296],aluminum,.022)
for x in (-.503,.48):
 box('Switching assembly','Pack',[x,.379,-.903],[.164,.07,.145],bus,.016)
 for z in (-.958,-.855):cylinder_between('Contact terminal','Pack',[x,.411,z],[x,.419,z],.016,metal,8)
box('Ancillary terminal shield','Pack',[.486,.423,-.91],[.192,.037,.143],orange,.019)
box('Electronics cover','Pack',[-.325,.424,-.836],[.219,.023,.135],trim,.012)
def pipe(label,g,path,r,m):
 cu=bpy.data.curves.new(label,'CURVE');cu.dimensions='3D';cu.resolution_u=8;cu.bevel_resolution=3;cu.bevel_depth=r
 sp=cu.splines.new('BEZIER');sp.bezier_points.add(len(path)-1)
 for bp,v in zip(sp.bezier_points,path):bp.co=blender(np.array(v)-groups[g][1]);bp.handle_left_type='AUTO';bp.handle_right_type='AUTO'
 ob=bpy.data.objects.new(label,cu);bpy.context.collection.objects.link(ob);ob.parent=groups[g][0];cu.materials.append(materials[m])
pipe('Insulated bay connection','Pack',[[.49,.414,-.99],[.48,.441,-1.019],[.36,.436,-1.002],[.31,.416,-.934],[.150,.417,-.905]],.009,orange)
# Different front and rear casings use distinct motor length, end bosses, rib planes
# and orientations. The gearbox transfers torque from an offset motor axis.
def ring_housing(g,label,stations,material):
 n=24;verts=[]
 for x,cy,cz,ry,rz in stations:
  for k in range(n):
   a=math.tau*k/n
   verts.append([x,cy+ry*np.sin(a),cz+rz*np.cos(a)])
 faces=[tuple(range(n-1,-1,-1)),tuple(range((len(stations)-1)*n,len(stations)*n))]+[(j*n+k,j*n+(k+1)%n,(j+1)*n+(k+1)%n,(j+1)*n+k) for j in range(len(stations)-1) for k in range(n)]
 ob=faced(label,g,verts,faces,material,.003)
 for poly in list(ob.data.polygons)[2:]:poly.use_smooth=True
def drive(g,z,sg,motor_len,depth,rad):
 # Transverse motor, a flared bolted joint and offset reduction casting, mounted at the axle.
 motorz=z+depth
 ring_housing(g,'Electric motor casing',[(sg*x,.393,motorz,ry,rz) for x,ry,rz in [(-motor_len-.039,rad*.64,rad*.64),(-motor_len-.024,rad*.91,rad*.91),(-motor_len,rad,rad),(-.092,rad,rad),(-.078,rad*1.04,rad*1.04)]],cast)
 ring_housing(g,'Reduction and differential housing',[(sg*x,cy,cz,ry,rz) for x,cy,cz,ry,rz in [(-.092,.378,z+depth*.73,rad*1.04,rad*1.21),(-.05,.369,z+depth*.65,rad*1.09,rad*1.41),(.11,.37,z+depth*.45,rad*1.03,rad*1.46),(.208,.369,z+depth*.3,rad*.93,rad*1.10),(.263,.36,z,rad*.64,rad*.71)]],cast)
 for k in range(10):
  a=math.tau*k/10;yy=.37+.119*np.sin(a);zz=z+depth*.64+.157*np.cos(a)
  cylinder_between('Raised casting rib',g,[sg*.247,.36+.053*np.sin(a),z+.052*np.cos(a)],[sg*.081,yy,zz],.008,aluminum,7)
  cylinder_between('Case bolt',g,[sg*.088,yy,zz],[sg*.103,yy,zz],.010,metal,6)
 for k in range(7):
  a=math.tau*k/7
  cylinder_between('Motor shell rib',g,[-sg*(motor_len+.013),.393+.96*rad*np.sin(a),motorz+.96*rad*np.cos(a)],[-sg*.09,.393+rad*np.sin(a),motorz+rad*np.cos(a)],.005,cast,7)
 # Inverter and stacked-plate coolant exchanger.
 shift=.075 if g=='FrontDrive' else -.05
 box('Inverter enclosure',g,[sg*shift,.491,z+depth+.025],[.307,.112,.217],cast,.026)
 for x in np.linspace(-.128,.128,6):
  cylinder_between('Diagonal web',g,[sg*(shift+x),.548,z+depth-.059],[sg*(shift+x+.027),.548,z+depth+.106],.005,aluminum,7)
 for k in range(11):
  box('Coolant heat exchanger plate',g,[sg*.137,.395+k*.0039,z-.151],[.132,.003,.068],aluminum,.004)
 box('High voltage inlet',g,[sg*.095,.48,z+depth-.11],[.088,.063,.051],orange,.012)
 pipe('Coolant hose',g,[[sg*.159,.438,z-.14],[sg*.196,.473,z-.12],[sg*.191,.495,z+depth-.059]],.012,trim)
 for sx in (-1,1):
  for k in range(5):
   xx=sx*(.631+k*.013);cylinder_between('Outer CV boot',g,[xx,.356,z],[xx+sx*.011,.356,z],.033+.003*k,trim)
  cylinder_between('Halfshaft',g,[sx*.22,.361,z],[sx*.754,.356,z],.014,metal)
  cylinder_between('Inner CV joint',g,[sx*.24,.36,z],[sx*.34,.36,z],.041,trim)
  cylinder_between('Output flange',g,[sx*.234,.36,z],[sx*.255,.36,z],.054,aluminum)
  mx=sx*.303
  cylinder_between('Mount arm',g,[sx*.161,.468,z+depth*.64],[mx,.482,z+depth*.77],.023,cast)
  cylinder_between('Rubber mount',g,[mx-.021,.485,z+depth*.77],[mx+.021,.485,z+depth*.77],.038,trim)
drive('FrontDrive',1.445,1,.275,-.088,.124)
drive('RearDrive',-1.445,-1,.323,.088,.146)
pipe('Forward HV cable','HighVoltage',[[-.62,.32,-.88],[-.71,.308,-.72],[-.716,.298,.91],[-.61,.331,1.14],[-.29,.435,1.25],[.085,.475,1.25]],.012,orange)
pipe('Rear HV cable','HighVoltage',[[.38,.392,-.997],[.52,.407,-1.09],[.461,.428,-1.25],[.20,.453,-1.41],[-.095,.480,-1.461]],.014,orange)

exec(compile((HERE/'drive_detail.py').read_text(),str(HERE/'drive_detail.py'),'exec'))
