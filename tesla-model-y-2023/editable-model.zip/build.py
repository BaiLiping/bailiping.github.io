"""Adapt a CC BY 4.0 early Model Y to the 2023 US Long Range with Gemini covers.
Run with Python containing bpy, trimesh, scipy, numpy, OpenCV and Pillow.
Input URL and attribution are in the public review. Coordinates below are glTF XYZ.
"""
from pathlib import Path
from collections import defaultdict
import math,json,sys
import numpy as np
import trimesh,bpy
from mathutils import Vector
sys.path.insert(0,str(Path(__file__).resolve().parent))
from components import source_meshes,components
HERE=Path(__file__).resolve().parent
bpy.ops.wm.read_factory_settings(use_empty=True)
# Scale the welded body to the service manual. Keep the tire round and its nominal
# section size separately, then place its hub on the service manual track datum.
source_center=np.array([-.0035,-.082,-.1235])
scale=np.array([3.66,1.624/.442,2.890/.810])
def body(v):
 p=(v-source_center)*scale
 # Align bumper extremities and mirrors without moving either axle or beltline.
 for axis,sign,lo,hi,new_hi in [(0,1,.8,1.046,1.0645),(0,-1,.8,1.046,1.0645),(2,1,1.445,2.357,2.320),(2,-1,1.445,2.405,2.431)]:
  d=sign*p[:,axis]
  weight=np.clip((d-lo)/(hi-lo),0,1)
  p[:,axis]+=sign*(new_hi-hi)*weight
 return p

materials={}
def mat(name,rgb,metal,rough,alpha=1):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,alpha);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF')
 for k,v in [('Base Color',(*rgb,1)),('Metallic',metal),('Roughness',rough),('Alpha',alpha)]:p.inputs[k].default_value=v
 if name=='PPSB Deep Blue Metallic':
  p.inputs['Coat Weight' if 'Coat Weight' in p.inputs else 'Clearcoat'].default_value=.55;p.inputs['Coat Roughness' if 'Coat Roughness' in p.inputs else 'Clearcoat Roughness'].default_value=.19
 if alpha<1:m.blend_method='BLEND';m.show_transparent_back=False
 materials[name]=m;return name
paint=mat('PPSB Deep Blue Metallic',(.009,.058,.225),.61,.245)
rubber=mat('Tire rubber',(.017,.019,.021),.02,.73)
trim=mat('Satin black trim',(.009,.012,.016),.15,.39)
arch=mat('Wheel arch and rocker',(.022,.025,.029),.05,.56)
metal=mat('Brushed alloy',(.46,.49,.51),.83,.32)
chrome=mat('Reflector',(.78,.83,.89),.94,.17)
rear=mat('Ruby reflector',(.44,.004,.012),.45,.23)
liner=mat('Lamp housing',(.012,.014,.017),.15,.34)
window=mat('Smoked window',(.026,.049,.070),.14,.12,.33)
roof=mat('Solar glass',(.009,.017,.022),.19,.115,.88)
lens=mat('Headlamp cover',(.45,.56,.64),.01,.105,.12)
tailLens=mat('Tail lens',(.39,.012,.018),.06,.14,.30)
cabin=mat('Charcoal upholstery',(.018,.021,.025),.01,.62)
wood=mat('Open pore wood',(.26,.165,.098),.02,.49)
screen=mat('Display glass',(.013,.018,.025),.2,.17)
cover=mat('Gemini satin silver',(.61,.62,.60),.44,.39)
coverDark=mat('Gemini carbon',(.058,.064,.071),.34,.35)
white=mat('Daytime running light',(.82,.84,.83),.15,.23)
# Group origins use assembled glTF coordinates in metres.
groups={}
def blender(v):return np.stack([v[...,0],-v[...,2],v[...,1]],axis=-1)
def group(name,origin):
 e=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(e);e.location=blender(np.array(origin));e.empty_display_size=.10
 groups[name]=(e,np.array(origin))
exec(compile((HERE/'exterior.py').read_text(),str(HERE/'exterior.py'),'exec'))
# Cabin geometry in the source includes a seat shell and a one-piece dash. Add the
# freestanding touchscreen and the horizontal wood fascia seen in the Tesla reference.
def box(label,g,position,size,material,bevel,tilt=0):
 bpy.ops.mesh.primitive_cube_add(size=1)
 o=bpy.context.object;o.name=label;o.dimensions=blender(np.array(size))*[1,-1,1]
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 o.parent=groups[g][0];o.location=blender(np.array(position)-groups[g][1]);o.rotation_euler.x=tilt
 o.data.materials.append(materials[material]);mod=o.modifiers.new('Edge radius','BEVEL');mod.width=bevel;mod.segments=4
 o.data.use_auto_smooth=True
 normals=o.modifiers.new('Face normals','WEIGHTED_NORMAL')
 return o
def dash_surface(label,sections,matname):
 # Replicate a transverse fascia which curves into the A pillars at each end.
 verts=[];faces=[]
 for x in np.linspace(-.79,.79,23):
  setback=.093*(abs(x)/.79)**1.8
  for z,y in sections:verts.append((x,y-.018*(x/.79)**2,z+setback))
 n=len(sections)
 for i in range(22):
  for j in range(n):
   a=i*n+j;b=i*n+(j+1)%n;faces.append((a,b,b+n,a+n))
 faces+=[tuple(range(n-1,-1,-1)),tuple(range(22*n,23*n))]
 me=bpy.data.meshes.new(label);me.from_pydata(blender(np.array(verts)-groups['Cabin'][1]).tolist(),[],faces);me.materials.append(materials[matname])
 ob=bpy.data.objects.new(label,me);bpy.context.collection.objects.link(ob);ob.parent=groups['Cabin'][0]
 mod=ob.modifiers.new('Trim edges','BEVEL');mod.width=.007;mod.segments=3;me.use_auto_smooth=True
dash_surface('Dashboard upper pad',[(.535,1.07),(.74,1.08),(.99,1.025),(.97,.94),(.55,1.015)],cabin)
dash_surface('Cross-car vent',[(.545,1.016),(.558,.982),(.78,.946),(.77,1.018)],trim)
dash_surface('Dashboard wood inlay',[(.537,.979),(.525,.929),(.545,.921),(.574,.973)],wood)
dash_surface('Glovebox fascia',[(.539,.92),(.569,.69),(.69,.60),(.88,.60),(.92,.955)],cabin)
box('Center display bezel','Cabin',[0,.998,.447],[.354,.221,.021],trim,.015,.16)
box('Center display face','Cabin',[0,.997,.435],[.338,.205,.004],screen,.008,.16)
box('Covered console bin','Cabin',[0,.591,.285],[.265,.13,.52],cabin,.05,-.14)
box('Armrest','Cabin',[0,.615,-.20],[.261,.113,.36],cabin,.048)

# A driver-facing three-spoke wheel is angled back from vertical.
def cabin_coord(v):return blender(np.asarray(v)-groups['Cabin'][1])
bpy.ops.mesh.primitive_torus_add(major_radius=.163,minor_radius=.0175,major_segments=88,minor_segments=16)
steer=bpy.context.object;steer.name='Steering wheel rim';steer.parent=groups['Cabin'][0];steer.location=cabin_coord([.371,1.023,.378]);steer.rotation_euler.x=math.radians(108)
steer.data.materials.append(materials[cabin]);[setattr(f,'use_smooth',True) for f in steer.data.polygons]
box('Display mount','Cabin',[0,.945,.51],[.080,.10,.105],trim,.02)
# Small Tesla T composed of its arcing upper blade and tapered stem.
def tesla_mark():
 verts=[(-.019,.010),(-.009,.014),(0,.015),(.009,.014),(.019,.010),(.014,.007),(0,.011),(-.014,.007),(-.015,.005),(-.005,.007),(0,.005),(.005,.007),(.015,.005),(.004,.001),(0,-.021),(-.004,.001)]
 faces=[(0,1,2,3,4,5,6,7),(8,9,10,11,12,13,14,15)]
 me=bpy.data.meshes.new('Wheel badge');me.from_pydata([tuple(cabin_coord([.371+x,1.027+y,.3375+y*.32])) for x,y in verts],[],faces);me.materials.append(materials[metal]);ob=bpy.data.objects.new('Wheel badge',me);bpy.context.collection.objects.link(ob);ob.parent=groups['Cabin'][0]
tesla_mark()
exec(compile((HERE/'interior.py').read_text(),str(HERE/'interior.py'),'exec'))
exec(compile((HERE/'finish.py').read_text(),str(HERE/'finish.py'),'exec'))
exec(compile((HERE/'subassemblies.py').read_text(),str(HERE/'subassemblies.py'),'exec'))
bpy.context.view_layer.update()
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(HERE/'2023_Model_Y.blend'),compress=True)
# The desktop Blender exporter writes the compact GLB from this master.
