"""Adapt a CC BY 4.0 early Model Y to the 2023 US Long Range with Gemini covers.
Run with Python containing bpy, trimesh, scipy, numpy and fast_simplification.
Input URL and attribution are in the public review. Coordinates below are glTF XYZ.
"""
from pathlib import Path
from collections import defaultdict
import math,json,os,sys
import numpy as np
import trimesh,fast_simplification,bpy
from mathutils import Vector
sys.path.insert(0,str(Path(__file__).resolve().parent))
from components import inputs,components
HERE=Path(__file__).resolve().parent
site_dir=HERE.parents[1]/'site/tesla-model-y-2023'
OUT=Path(os.environ.get('TESLA_EXPORT_DIR',site_dir if site_dir.is_dir() else HERE/'export'))
OUT.mkdir(exist_ok=True,parents=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
# Scale the welded body to the service manual. Keep the tire round and its nominal
# section size separately, then place its hub on the service manual track datum.
source_center=np.array([-.0035,-.082,-.1235])
scale=np.array([3.66,1.624/.442,2.890/.810])
def body(v):
 p=(v-source_center)*scale
 # Align bumper extremities and mirrors without moving either axle or beltline.
 for axis,sign,lo,hi,new_hi in [(0,1,.8,1.046,1.0645),(0,-1,.8,1.046,1.0645),(2,1,1.445,2.357,2.320),(2,-1,1.445,2.405,2.431)]:
  d=sign*p[:,axis]
  weight=np.clip((d-lo)/(hi-lo),0,1)
  p[:,axis]+=sign*(new_hi-hi)*weight
 return p

materials={}
def mat(name,rgb,metal,rough,alpha=1):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgb,alpha);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF')
 for k,v in [('Base Color',(*rgb,1)),('Metallic',metal),('Roughness',rough),('Alpha',alpha)]:p.inputs[k].default_value=v
 if name=='PPSB Deep Blue Metallic':
  p.inputs['Coat Weight' if 'Coat Weight' in p.inputs else 'Clearcoat'].default_value=.55;p.inputs['Coat Roughness' if 'Coat Roughness' in p.inputs else 'Clearcoat Roughness'].default_value=.19
 if alpha<1:m.blend_method='BLEND';m.show_transparent_back=False
 materials[name]=m;return name
paint=mat('PPSB Deep Blue Metallic',(.014,.078,.278),.72,.26)
rubber=mat('Tire rubber',(.017,.019,.021),.02,.73)
trim=mat('Satin black trim',(.009,.012,.016),.15,.39)
arch=mat('Wheel arch and rocker',(.022,.025,.029),.05,.56)
metal=mat('Brushed alloy',(.46,.49,.51),.83,.32)
chrome=mat('Reflector',(.78,.83,.89),.94,.17)
rear=mat('Ruby reflector',(.44,.004,.012),.45,.23)
liner=mat('Lamp housing',(.012,.014,.017),.15,.34)
window=mat('Smoked window',(.025,.039,.045),.10,.16,.46)
roof=mat('Solar glass',(.008,.014,.020),.24,.15,.92)
lens=mat('Headlamp cover',(.062,.076,.086),.09,.16,.31)
tailLens=mat('Tail lens',(.33,.013,.024),.07,.12,.30)
cabin=mat('Charcoal upholstery',(.018,.021,.025),.01,.62)
wood=mat('Open pore wood',(.24,.135,.071),.05,.52)
screen=mat('Display glass',(.013,.018,.025),.2,.17)
cover=mat('Gemini satin silver',(.42,.43,.44),.58,.32)
coverDark=mat('Gemini carbon',(.095,.102,.108),.45,.38)
white=mat('Daytime running light',(.82,.84,.83),.15,.23)
# Each top-level empty is a physical hinge, wheel center or exploded assembly.
groups={}; buffers=defaultdict(list); geo_stats={}
def blender(v):return np.stack([v[...,0],-v[...,2],v[...,1]],axis=-1)
def group(name,origin):
 e=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(e);e.location=blender(np.array(origin));e.empty_display_size=.10
 groups[name]=(e,np.array(origin))
group('Body',[0,0,0]);group('Cabin',[0,.3,0]);group('FrontDrive',[0,.36,1.445]);group('RearDrive',[0,.36,-1.445]);group('Pack',[0,.25,0])
group('Hood',[0,1.03,1.14]); group('Liftgate',[0,1.44,-1.37])
for side,sg in [('Left',1),('Right',-1)]:
 for row,z in [('Front',1.445),('Rear',-1.445)]:
  group('Wheel'+row+side,[.818*sg,.356,z]);group('Brake'+row+side,[.818*sg,.356,z])
 for row,z in [('Front',.91),('Rear',-.30)]:group('Door'+row+side,[sg*.855,.78,z])
def add(g,m,v,f):buffers[g,m].append((v,f))
def door(x,z):return 'Door'+('Front' if z>-.22 else 'Rear')+('Left' if x>0 else 'Right')
def skin_group(lo,hi):
 c=(lo+hi)/2
 if (hi[0]-lo[0])>.23:
  if hi[2]>.50 and lo[2]>.19 and lo[1]>.10:return 'Hood'
  if hi[2]<-.49 and lo[1]>.075:return 'Liftgate'
 return 'Body'
pts=[];fac=[];nv=0
for name,v,f in inputs():
 id=int(name.split('_')[0]);matname=name.split('_',1)[1].rsplit('_',1)[0]
 if id==103:
  pts.append(v);fac.append(f+nv);nv+=len(v);continue
 if id in (37,41,45,83,92):continue # Remove duplicate opaque glass backing surfaces.
 if id<=33:
  c=(v.min(0)+v.max(0))/2
  side='Left' if c[0]>0 else 'Right';row='Front' if c[2]>0 else 'Rear'
  isWheel=26<=id<=33
  g=('Wheel' if isWheel else 'Brake')+row+side;hub=groups[g][1]
  oldhub=np.array([(.214 if c[0]>0 else -.2205),.022,(.2815 if c[2]>0 else -.5285)])
  # Use 255/45R19 dimensions. Retain original tire tread and brake castings.
  vv=(v-oldhub)*np.array([3.06,3.43,3.43])+hub
  if id in (26,27,28,29):continue # The reference uses aero covers over the 19-inch wheel.
  m=rubber if id>=30 else (metal if 'dsk' in name or 'alum' in name else trim)
  add(g,m,vv,f);continue
 m=({'body':paint,'fenders':arch,'brakedsk':metal,'chrome_rear_lights':rear,
 'chrome_rear_2':rear,'black2':liner,'interior':cabin,'glass_body':window,
 'chrome':chrome,'metal':trim,'black':trim,'alum':metal,'glass_front_lights':white,
 'chrome_dark':trim,'glass_lights':lens}).get(matname,trim)
 if id in [94,95,67,63,40,39]:m=tailLens
 if id in [44,52,53,57,58,81,84,87,88,90,99]:m=trim
 if id in [69,70,71,72,74,77,78,79,82,100]:m=metal
 if id==46:m=roof
 if id in (72,74,77,78,82):m=trim
 if id==46:m=roof
 subdivide=id in (43,44,47,80,85,97,98,102)
 tags=components(v,f) if subdivide else np.zeros(len(f),dtype=int)
 for tag in np.unique(tags):
  faces=f[tags==tag]; used,ff=np.unique(faces,return_inverse=True);vs=v[used];ff=ff.reshape(-1,3)
  lo,hi=vs.min(0),vs.max(0);x,y,z=(lo+hi)/2;g='Body'
  if id==98 or id in [44,80,85,97] or (id==47 and z>-.465) or (id==102 and hi[1]<.25):g=door(x,z)
  if id in [36,60,66]:g='Liftgate'
  if id in [40,61,62,63,64,65,94,96]:
   # The straight vertical edge by the hatch seam divides the fixed lamp from its inner tailgate portion.
   cent=vs[ff].mean(axis=1);on_gate=(abs(cent[:,0]+.0035)<.151) & (cent[:,2]<-.70)
   if np.any(on_gate):add('Liftgate',m,body(vs),ff[on_gate])
   ff=ff[~on_gate]
   if not len(ff):continue
  if id in [43,45,49,54,83]:g='Cabin'
  if id==91:g='Hood'
  if id==43 and tag in [0,22,23,27,32,33,39,41]:continue
  # Mirror faces get polished metal; the original outer door trim and handles were chrome.
  add(g,m,body(vs),ff)
v=np.vstack(pts);f=np.vstack(fac);tags=components(v,f)
for tag in np.unique(tags):
 used,ff=np.unique(f[tags==tag],return_inverse=True);vs=v[used];add(skin_group(vs.min(0),vs.max(0)),paint,body(vs),ff.reshape(-1,3))
def patch(g,m,v,f):add(g,m,np.array(v),np.array(f))
def lathe_x(g,m,hub,sg,profile,n=72):
 v=[];f=[]
 for r,x in profile:
  for j in range(n):
   a=math.tau*j/n;v.append(hub+np.array([sg*x,math.cos(a)*r,math.sin(a)*r]))
 for i in range(len(profile)-1):
  for j in range(n):
   a=i*n+j;b=i*n+(j+1)%n;f.extend([[a,b,b+n],[a,b+n,a+n]])
 patch(g,m,v,f)
for row in ['Front','Rear']:
 for side,sg in [('Left',1),('Right',-1)]:
  g='Wheel'+row+side;hub=groups[g][1]
  # The perimeter dimensions follow the 19-inch rim. Open slots reveal the brake disk.
  lathe_x(g,coverDark,hub,sg,[(.224,.104),(.239,.110),(.242,.090),(.241,-.071),(.224,-.081)],n=112)
  lathe_x(g,cover,hub,sg,[(.231,.114),(.241,.112),(.243,.109)],n=112)
  lathe_x(g,cover,hub,sg,[(.001,.144),(.023,.145),(.031,.141),(.043,.141),(.052,.134)],n=112)
  lathe_x(g,coverDark,hub,sg,[(.028,.144),(.031,.141)],n=112)
  for j in range(7):
   a=math.tau*j/7
   # Faceted vane running from the domed center into the large silver outer shoulder.
   rings=[(.037,-.39,.37,.137,.144),(.069,-.29,.27,.135,.144),(.13,-.19,.32,.128,.140),(.20,-.12,.37,.119,.129),(.237,-.12,.37,.112,.119)]
   vs=[]
   for r,aa,bb,edge,ridge in rings:
    for beta,x in [(aa,edge),(aa*.66+bb*.34,ridge),(bb,edge+.002)]:
     vs.append(hub+np.array([sg*x,r*math.cos(a+sg*beta),r*math.sin(a+sg*beta)]))
   faces=[]
   for k in range(4):
    for col in (0,1):
     t=k*3+col;faces.extend([[t,t+3,t+4],[t,t+4,t+1]])
   patch(g,cover,vs,faces)
   pts=[]
   for r,aa,bb,x in [(.050,.27,.41,.132),(.14,.33,.52,.111),(.232,.38,.55,.103)]:
    for theta in (aa,bb):
     pts.append(hub+np.array([sg*x,r*math.cos(a+sg*theta),r*math.sin(a+sg*theta)]))
   patch(g,coverDark,pts,[[0,2,3],[0,3,1],[2,4,5],[2,5,3]])
# Build from indexed arrays, then reduce web meshes with edge collapse. No per-view warping.
for (g,m),items in buffers.items():
 vs=[];ff=[];k=0
 for v,f in items:
  vs.append(v);ff.append(f+k);k+=len(v)
 v=np.vstack(vs);f=np.vstack(ff)
 mesh=trimesh.Trimesh(v,f,process=True,validate=False)
 if len(mesh.faces)>4000:
  keep=.67 if m==paint else (.20 if m in (rubber,rear,chrome) else .35)
  mesh=mesh.simplify_quadric_decimation(face_count=int(len(mesh.faces)*keep))
 vs=blender(mesh.vertices-groups[g][1]);me=bpy.data.meshes.new(g+' '+m)
 me.from_pydata(vs.tolist(),[],mesh.faces.tolist());me.update();me.materials.append(materials[m])
 me.polygons.foreach_set('use_smooth',np.ones(len(me.polygons),dtype=bool))
 ob=bpy.data.objects.new(me.name,me);bpy.context.collection.objects.link(ob);ob.parent=groups[g][0]
 bpy.context.view_layer.update();geo_stats[g]=geo_stats.get(g,0)+len(me.polygons)
# Cabin geometry in the source includes a seat shell and a one-piece dash. Add the
# freestanding touchscreen and the horizontal wood fascia seen in the Tesla reference.
def box(label,g,position,size,material,bevel,tilt=0):
 bpy.ops.mesh.primitive_cube_add(size=1)
 o=bpy.context.object;o.name=label;o.dimensions=blender(np.array(size))*[1,-1,1]
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 o.parent=groups[g][0];o.location=blender(np.array(position)-groups[g][1]);o.rotation_euler.x=tilt
 o.data.materials.append(materials[material]);mod=o.modifiers.new('Edge radius','BEVEL');mod.width=bevel;mod.segments=4
 o.data.use_auto_smooth=True
 normals=o.modifiers.new('Face normals','WEIGHTED_NORMAL')
 return o
def dash_surface(label,sections,matname):
 # Replicate a transverse fascia which curves into the A pillars at each end.
 verts=[];faces=[]
 for x in np.linspace(-.79,.79,23):
  setback=.093*(abs(x)/.79)**1.8
  for z,y in sections:verts.append((x,y-.018*(x/.79)**2,z+setback))
 n=len(sections)
 for i in range(22):
  for j in range(n):
   a=i*n+j;b=i*n+(j+1)%n;faces.append((a,b,b+n,a+n))
 faces+=[tuple(range(n-1,-1,-1)),tuple(range(22*n,23*n))]
 me=bpy.data.meshes.new(label);me.from_pydata(blender(np.array(verts)-groups['Cabin'][1]).tolist(),[],faces);me.materials.append(materials[matname])
 ob=bpy.data.objects.new(label,me);bpy.context.collection.objects.link(ob);ob.parent=groups['Cabin'][0]
 mod=ob.modifiers.new('Trim edges','BEVEL');mod.width=.007;mod.segments=3;me.use_auto_smooth=True
dash_surface('Dashboard upper pad',[(.535,1.07),(.74,1.08),(.99,1.025),(.97,.94),(.55,1.015)],cabin)
dash_surface('Cross-car vent',[(.545,1.016),(.558,.982),(.78,.946),(.77,1.018)],trim)
dash_surface('Dashboard wood inlay',[(.537,.979),(.525,.929),(.545,.921),(.574,.973)],wood)
dash_surface('Glovebox fascia',[(.539,.92),(.569,.69),(.69,.60),(.88,.60),(.92,.955)],cabin)
box('Center display bezel','Cabin',[0,.998,.447],[.354,.221,.021],trim,.015,.16)
box('Center display face','Cabin',[0,.997,.435],[.338,.205,.004],screen,.008,.16)
box('Covered console bin','Cabin',[0,.591,.285],[.265,.13,.52],cabin,.05,-.14)
box('Armrest','Cabin',[0,.615,-.20],[.261,.113,.36],cabin,.048)
box('Grille backing','Body',[0,.353,2.123],[1.09,.19,.042],trim,.027)
# A driver-facing three-spoke wheel is angled back from vertical.
def cabin_coord(v):return blender(np.asarray(v)-groups['Cabin'][1])
bpy.ops.mesh.primitive_torus_add(major_radius=.163,minor_radius=.0175,major_segments=88,minor_segments=16)
steer=bpy.context.object;steer.name='Steering wheel rim';steer.parent=groups['Cabin'][0];steer.location=cabin_coord([.371,1.023,.378]);steer.rotation_euler.x=math.radians(108)
steer.data.materials.append(materials[cabin]);[setattr(f,'use_smooth',True) for f in steer.data.polygons]
box('Display mount','Cabin',[0,.945,.51],[.080,.10,.105],trim,.02)
# Small Tesla T composed of its arcing upper blade and tapered stem.
def tesla_mark():
 verts=[(-.019,.010),(-.009,.014),(0,.015),(.009,.014),(.019,.010),(.014,.007),(0,.011),(-.014,.007),(-.015,.005),(-.005,.007),(0,.005),(.005,.007),(.015,.005),(.004,.001),(0,-.021),(-.004,.001)]
 faces=[(0,1,2,3,4,5,6,7),(8,9,10,11,12,13,14,15)]
 me=bpy.data.meshes.new('Wheel badge');me.from_pydata([tuple(cabin_coord([.371+x,1.027+y,.3375+y*.32])) for x,y in verts],[],faces);me.materials.append(materials[metal]);ob=bpy.data.objects.new('Wheel badge',me);bpy.context.collection.objects.link(ob);ob.parent=groups['Cabin'][0]
tesla_mark()
exec(compile((HERE/'interior.py').read_text(),str(HERE/'interior.py'),'exec'))
bpy.context.view_layer.update()
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(HERE/'2023_Model_Y.blend'),compress=True)
bpy.ops.export_scene.gltf(filepath=str(OUT/'model-y.glb'),export_format='GLB',export_apply=True,export_extras=True,export_draco_mesh_compression_enable=True,export_draco_mesh_compression_level=6)
(HERE/'groups.json').write_text(json.dumps(geo_stats,indent=2))
