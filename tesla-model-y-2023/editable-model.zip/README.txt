2023 Tesla Model Y Long Range AWD | Deep Blue Metallic
Open 2023_Model_Y.blend in Blender 5.2 or later. Geometry uses metres. The
master includes all materials and the packed center-display texture. The named
door, hood and liftgate objects rotate about their hinges. studio.json contains
the web cameras, driver eye position, exploded offsets and EV inspection views.

The generation-shared exterior and seat geometry derive from “Tesla Model Y
2021” by 763468712. Used and adapted under CC BY 4.0.
https://sketchfab.com/3d-models/tesla-model-y-2021-c0a86cac582d4b33aba0fb1b1912d970
https://creativecommons.org/licenses/by/4.0/
Changes include body scale, door and hatch separation, 2023 black trim, glass,
Gemini wheel covers, the front dashboard, touchscreen and steering wheel, door
cards, luggage spaces and an illustrative non-structural EV drivetrain.

To rebuild, place the source file c0a86cac582d4b33aba0fb1b1912d970.glb beside
build.py. The CC-licensed original is also archived by Objaverse at
https://huggingface.co/datasets/allenai/objaverse/resolve/main/glbs/000-124/c0a86cac582d4b33aba0fb1b1912d970.glb

Run python build.py with bpy 4.0, numpy, scipy, trimesh, Pillow and
fast-simplification installed. This produces the authoring master and an
uncompressed glTF export. For the compact website asset, run
blender -b 2023_Model_Y.blend -P export.py -- model-y.glb
The scripts include the parked display artwork and its generator. A previously
saved Blender file may be backed up by Blender before the compressed export.

Model and reference measurements, assembly assumptions and credits are at
https://bailiping.com/tesla-model-y-2023/review.html
