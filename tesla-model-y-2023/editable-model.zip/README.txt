2023 Tesla Model Y Long Range AWD, five seats, U.S. specification
Deep Blue Metallic with 19-inch silver Gemini wheel covers and a non-structural four-module battery.

Open 2023_Model_Y.blend in Blender 4.0 or later. The master uses metres and retains individual editable objects, materials, trim textures and hinge pivots. The complete assembly consists of 51 top-level units. Wheels, brakes and both drive units also contain nested service components.

The body surfaces, lamp optics, glazings and brakes derive from “Tesla Model Y 2021” by 763468712, CC BY 4.0. The adaptations include original Gemini wheels and tires, split closures and lamps, new five-seat upholstery, trim, compartments, suspension, axles, high-voltage equipment, 2023 finishes and assembly placement.
https://sketchfab.com/3d-models/tesla-model-y-2021-c0a86cac582d4b33aba0fb1b1912d970
https://creativecommons.org/licenses/by/4.0/

The Blender file is self-contained. To regenerate it from the original source, download c0a86cac582d4b33aba0fb1b1912d970.glb beside build.py from the archive below. Run python build.py with bpy 4.0, NumPy, SciPy, trimesh, OpenCV and Pillow installed. Run the compact exporter with desktop Blender 5.2 or later.
https://huggingface.co/datasets/allenai/objaverse/resolve/main/glbs/000-124/c0a86cac582d4b33aba0fb1b1912d970.glb

python build.py
blender -b 2023_Model_Y.blend -P export.py -- model-y.glb
python layout.py

studio.json contains the comparison cameras, hinge actions, and exploded coordinates for wide and narrow viewports. assembly-hulls.json is generated from the assembled mesh for camera fitting. The website uses Studio Small 08 by Poly Haven, CC0.
https://polyhaven.com/a/studio_small_08

Photographs, inspection notes and the measured factory dimensions are indexed in reference-index.json and the public photo comparisons. The electric-drive castings, internal mounting points and upholstery contours are approximate.
https://bailiping.com/tesla-model-y-2023/review.html
