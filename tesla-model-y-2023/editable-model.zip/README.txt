2023 Tesla Model Y Long Range AWD · editable Blender master

Open 2023_Model_Y_master.blend to edit the full-scale model in metres. Its display
and cabin trim textures are packed. To generate the interactive 1:18 scale rig and
Draco-compressed GLB, run this command from the extracted folder with Blender
5.2.1 LTS:

blender -b 2023_Model_Y_master.blend -P export_gt3.py -- out/model-y.glb

The exporter writes 2023_Model_Y_rig_1to18.blend, out/model-y.glb and
out/export_report.json. In glTF coordinates +X is forward, +Y is up and +Z
is vehicle right. One viewer unit represents 18 mm on the full-size vehicle.
export_report.json records measured dimensions of the packaged revision.
tesla-views.json contains saved photo cameras and source image links.
model-y-config.js contains viewer part names, hinges and exploded offsets.

To regenerate the master from its mesh input, download the file below to this
folder using the basename c0a86cac582d4b33aba0fb1b1912d970.glb.
https://huggingface.co/datasets/allenai/objaverse/resolve/main/glbs/000-124/c0a86cac582d4b33aba0fb1b1912d970.glb
SHA-256: fd7826c5e61c7bb601073589ea9bd1c1baabcc466ea6706c7ccb655c5fb46422

Use Python 3.10, install the pinned build dependencies, then run:
python -m pip install -r requirements.txt
python build.py

Base body, glazing, lamp and brake geometry derive from Tesla Model Y 2021 by
763468712 under Creative Commons Attribution 4.0 International.
https://sketchfab.com/3d-models/tesla-model-y-2021-c0a86cac582d4b33aba0fb1b1912d970
https://creativecommons.org/licenses/by/4.0/

The adaptation models the 2023 Long Range's wheels, closures, lights, cabin,
cargo compartments, suspension and electric drive, with hinge and assembly
pivots for interaction. Internal fit and concealed components are approximate.
The independent 2021 model in the Car_Photos collection served as a visual
reference. Vehicle proportions and surface details are compared to photographs
and the original-generation Model Y manuals.

https://bailiping.com/tesla-model-y-2023/
https://www.tesla.com/ownersmanual/2020_2024_modely/en_us/GUID-E47C4A6D-528E-419C-8C57-FD3864644C34.html
