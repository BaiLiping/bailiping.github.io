"""Internal EV drive-unit mechanics (stator, windings, rotor, offset helical reduction
gearset, open differential, SiC inverter power electronics) and 2170 battery cooling
ribbons / busbars for the 2023 Tesla Model Y.
Executed inside build.py after electric.py / drive_detail.py.
"""
import math
import numpy as np
import bpy

copper = mat("Mat_Copper_Winding", (0.74, 0.31, 0.11), 0.92, 0.28)
laminated = mat("Mat_Laminated_Steel", (0.24, 0.26, 0.28), 0.85, 0.36)
gearsteel = mat("Mat_Gear_Steel", (0.68, 0.70, 0.72), 0.94, 0.20)
magnet = mat("Mat_Neodymium_Magnet", (0.14, 0.16, 0.19), 0.78, 0.32)
pcb_green = mat("Mat_Inverter_PCB", (0.018, 0.18, 0.065), 0.22, 0.42)
capacitor = mat("Mat_Capacitor_Block", (0.045, 0.048, 0.054), 0.12, 0.46)
cooling_ribbon = mat("Mat_Cooling_Ribbon", (0.56, 0.60, 0.63), 0.82, 0.30)


def helical_gear(label, g, center_x, cy, cz, pitch_r, width, teeth, helix_rad=0.22, bore_r=0.018, material=gearsteel):
    """Build a crisp extruded helical gear mesh centered on an X-parallel axis."""
    n_prof = teeth * 4
    r_root = pitch_r * 0.88
    r_tip = pitch_r * 1.07
    verts = []
    # Two axial faces with helical twist + bore rings
    for s_idx, (dx, twist) in enumerate([(-width * 0.5, -helix_rad * 0.5), (width * 0.5, helix_rad * 0.5)]):
        for k in range(n_prof):
            ang = math.tau * k / n_prof + twist
            phase = k % 4
            r = r_tip if phase in (1, 2) else r_root
            verts.append([center_x + dx, cy + r * math.sin(ang), cz + r * math.cos(ang)])
    for dx in (-width * 0.5, width * 0.5):
        for k in range(n_prof):
            ang = math.tau * k / n_prof
            verts.append([center_x + dx, cy + bore_r * math.sin(ang), cz + bore_r * math.cos(ang)])

    faces = []
    o0, o1 = 0, n_prof
    i0, i1 = 2 * n_prof, 3 * n_prof
    for k in range(n_prof):
        kn = (k + 1) % n_prof
        # Outer tooth flank
        faces.append((o0 + k, o0 + kn, o1 + kn, o1 + k))
        # Inner bore wall
        faces.append((i0 + kn, i0 + k, i1 + k, i1 + kn))
        # Left annular web
        faces.append((i0 + k, i0 + kn, o0 + kn, o0 + k))
        # Right annular web
        faces.append((o1 + k, o1 + kn, i1 + kn, i1 + k))

    ob = faced(label, g, verts, faces, material)
    for poly in ob.data.polygons:
        poly.use_smooth = False
    return ob


def hollow_ring_x(label, g, x0, x1, cy, cz, r_in, r_out, segments=32, material=laminated):
    """Hollow cylindrical ring aligned along the transverse X axis."""
    verts = []
    for x in (x0, x1):
        for r in (r_out, r_in):
            for k in range(segments):
                a = math.tau * k / segments
                verts.append([x, cy + r * math.sin(a), cz + r * math.cos(a)])
    n = segments
    o0, i0, o1, i1 = 0, n, 2 * n, 3 * n
    faces = []
    for k in range(n):
        kn = (k + 1) % n
        faces.append((o0 + k, o0 + kn, o1 + kn, o1 + k))
        faces.append((i0 + kn, i0 + k, i1 + k, i1 + kn))
        faces.append((i0 + k, i0 + kn, o0 + kn, o0 + k))
        faces.append((o1 + k, o1 + kn, i1 + kn, i1 + k))
    ob = faced(label, g, verts, faces, material)
    for poly in ob.data.polygons[: 2 * n]:
        poly.use_smooth = True
    return ob


def build_drive_internals(g, z_axle, sg, motor_len, depth, rad, is_rear=False):
    """Populate stator, copper windings, rotor, offset helical reduction gear train,
    open differential, and SiC inverter board inside FrontDrive / RearDrive.
    """
    motorz = z_axle + depth
    cy_motor = 0.393
    # Motor core axial span strictly inside Electric motor casing [-motor_len, -0.092]
    x_outer = sg * (-motor_len + 0.022)
    x_inner = sg * (-0.112)
    xa, xb = min(x_outer, x_inner), max(x_outer, x_inner)

    r_stator_out = rad * 0.84
    r_stator_in = rad * 0.61
    r_rotor_out = rad * 0.565
    r_shaft = 0.017 if not is_rear else 0.020

    # 1. Laminated stator core + internal teeth + copper end-windings
    hollow_ring_x("Stator_Core_Lamination", g, xa, xb, cy_motor, motorz, r_stator_in, r_stator_out, 36, laminated)
    # Copper end-windings protruding from both axial ends of stator
    for x_end in (xa - 0.018, xb + 0.018):
        hollow_ring_x(
            "Stator_Core_Copper_Winding",
            g,
            min(x_end, (xa + xb) * 0.5) if x_end < xa else xb,
            xa if x_end < xa else x_end,
            cy_motor,
            motorz,
            r_stator_in * 1.03,
            r_stator_out * 0.94,
            32,
            copper,
        )
    # Individual copper hairpin coil loops around end-turns for unmistakable EV detail
    n_coils = 24
    for k in range(n_coils):
        a = math.tau * k / n_coils
        r_mid = (r_stator_in + r_stator_out) * 0.5
        yy = cy_motor + r_mid * math.sin(a)
        zz = motorz + r_mid * math.cos(a)
        cylinder_between("Stator_Core_Hairpin", g, [xa - 0.021, yy, zz], [xb + 0.021, yy, zz], 0.0055, copper, 8)

    # 2. Rotor assembly (Induction squirrel-cage in Front, Permanent-Magnet in Rear)
    hollow_ring_x("Rotor_Core_Stack", g, xa + 0.005, xb - 0.005, cy_motor, motorz, r_shaft, r_rotor_out, 32, laminated)
    # Rotor steel shaft extending into the gearbox input pinion
    x_pinion = sg * (-0.015)
    cylinder_between(
        "Rotor_Core_Shaft",
        g,
        [sg * (-motor_len + 0.005), cy_motor, motorz],
        [sg * 0.045, cy_motor, motorz],
        r_shaft,
        gearsteel,
        20,
    )
    if not is_rear:
        # Front AC induction rotor: copper/aluminum squirrel-cage end rings & conductor bars
        for xe in (xa - 0.006, xb + 0.006):
            hollow_ring_x("Rotor_Core_EndRing", g, xe - 0.006, xe + 0.006, cy_motor, motorz, r_rotor_out * 0.65, r_rotor_out * 0.96, 24, aluminum)
        for k in range(18):
            a = math.tau * k / 18
            yy = cy_motor + r_rotor_out * 0.92 * math.sin(a)
            zz = motorz + r_rotor_out * 0.92 * math.cos(a)
            cylinder_between("Rotor_Core_Bar", g, [xa, yy, zz], [xb, yy, zz], 0.004, copper, 6)
    else:
        # Rear PMSRM rotor: 8 V-arranged interior neodymium magnet poles
        for k in range(8):
            a = math.tau * k / 8
            for da in (-0.11, 0.11):
                r_m = r_rotor_out * 0.78
                yy = cy_motor + r_m * math.sin(a + da)
                zz = motorz + r_m * math.cos(a + da)
                cylinder_between("Rotor_Core_PM_Pole", g, [xa + 0.004, yy, zz], [xb - 0.004, yy, zz], 0.0075, magnet, 6)

    # 3. Single-speed offset helical reduction gear train (Input Pinion -> Countershaft -> Bull Ring Gear)
    # Stage 1: Input pinion on motor axis (cy_motor, motorz) -> Intermediate gear on countershaft
    r_pin1 = 0.029 if not is_rear else 0.033
    r_int = 0.072 if not is_rear else 0.082
    dist1 = r_pin1 + r_int
    # Place countershaft slightly above/between motor and axle so it clears both and fits inside Reduction housing
    cy_mid = 0.378
    # Solve countershaft Z along axle-to-motor offset direction
    dz_1 = math.sqrt(max(0.001, dist1 * dist1 - (cy_mid - cy_motor) ** 2))
    z_mid = motorz - math.copysign(dz_1 * 0.55, depth)
    # Recompute exact center distance to axle for Stage 2
    cy_axle = 0.360
    dist2 = math.hypot(cy_mid - cy_axle, z_mid - z_axle)
    r_pin2 = max(0.024, dist2 * 0.28)
    r_ring = max(0.070, dist2 - r_pin2)

    helical_gear("Pinion_Input_Gear", g, x_pinion, cy_motor, motorz, r_pin1, 0.032, 16, 0.20, r_shaft, gearsteel)
    helical_gear("Reduction_Gear_Intermediate", g, x_pinion, cy_mid, z_mid, r_int, 0.030, 38, -0.20, 0.016, gearsteel)

    # Countershaft + Stage 2 pinion
    x_stage2 = sg * 0.055
    cylinder_between("Reduction_Gear_Countershaft", g, [sg * (-0.048), cy_mid, z_mid], [sg * 0.095, cy_mid, z_mid], 0.015, gearsteel, 16)
    helical_gear("Reduction_Gear_Stage2_Pinion", g, x_stage2, cy_mid, z_mid, r_pin2, 0.034, 15, 0.22, 0.015, gearsteel)

    # Final-drive bull ring gear + Open Differential on axle centerline (cy_axle, z_axle)
    helical_gear("Diff_Gear_Ring", g, x_stage2, cy_axle, z_axle, r_ring, 0.034, 46, -0.22, r_ring * 0.64, gearsteel)

    # Differential carrier cage, cross-pin & spider bevel gears
    x_diff = sg * 0.118
    hollow_ring_x("Diff_Gear_Carrier", g, min(x_stage2, x_diff) - 0.012, max(x_stage2, x_diff) + 0.032, cy_axle, z_axle, r_ring * 0.34, r_ring * 0.56, 20, cast)
    # Cross pin & 2 spider gears
    cylinder_between("Diff_Gear_CrossPin", g, [x_diff, cy_axle - r_ring * 0.48, z_axle], [x_diff, cy_axle + r_ring * 0.48, z_axle], 0.009, gearsteel, 12)
    for dy_s in (-r_ring * 0.26, r_ring * 0.26):
        cylinder_between("Diff_Gear_Spider", g, [x_diff, cy_axle + dy_s - 0.010, z_axle], [x_diff, cy_axle + dy_s + 0.010, z_axle], 0.020, gearsteel, 14)
    for dx_s in (-0.024, 0.024):
        helical_gear("Diff_Gear_SideBevel", g, x_diff + dx_s, cy_axle, z_axle, 0.026, 0.014, 14, 0.0, 0.013, gearsteel)

    # 4. SiC Inverter power electronics (inside Inverter enclosure, revealed when Inverter_Cover lifts)
    shift = 0.075 if not is_rear else -0.05
    cx_inv = sg * shift
    cz_inv = z_axle + depth + 0.025
    # Main gate-driver & logic PCB
    box("Inverter_SiC_PCB", g, [cx_inv, 0.478, cz_inv], [0.255, 0.010, 0.168], pcb_green, 0.003)
    # DC-link film capacitor brick
    box("Inverter_DC_Capacitor", g, [cx_inv - sg * 0.045, 0.456, cz_inv - 0.035], [0.135, 0.028, 0.072], capacitor, 0.005)
    # 3-phase copper busbars connecting SiC MOSFET modules down to stator terminals
    for idx, dx_b in enumerate((-0.052, 0.0, 0.052)):
        box(f"Busbar_Phase_{idx+1}", g, [cx_inv + dx_b, 0.491, cz_inv + 0.025], [0.024, 0.008, 0.092], copper, 0.002)
        cylinder_between(
            f"Busbar_Terminal_{idx+1}",
            g,
            [cx_inv + dx_b, 0.488, cz_inv + 0.055],
            [cx_inv + dx_b, 0.445, motorz],
            0.006,
            copper,
            8,
        )
    # 6 SiC power module packages
    for ix in (-0.075, -0.025, 0.025, 0.075):
        box("Inverter_SiC_Module", g, [cx_inv + ix, 0.487, cz_inv - 0.042], [0.034, 0.009, 0.042], trim, 0.002)


def add_battery_cooling_and_busbars():
    """Add aluminum serpentine cooling ribbons, cell-top busbar collector plates,
    and rear penthouse pyro-fuse / contactors inside the 4-module 2170 battery pack.
    """
    for index, x in enumerate((-0.54, -0.18, 0.18, 0.54)):
        g = "Module" + str(index + 1)
        length = 1.99 if index in (0, 3) else 2.13
        # Serpentine thermal cooling ribbon manifolds along module flanks & front end
        for dx in (-0.136, -0.045, 0.045, 0.136):
            box("Battery_Cooling_Ribbon", g, [x + dx, 0.2895, 0.02], [0.011, 0.0035, length - 0.16], cooling_ribbon, 0.001)
        # Front thermal manifold bridge & coolant barb
        box("Battery_Cooling_Manifold", g, [x, 0.284, length * 0.5 - 0.06], [0.30, 0.012, 0.024], cooling_ribbon, 0.003)
        # Copper/nickel collector busbar bridge at rear of module
        box("Battery_Cell_Busbar", g, [x, 0.292, -length * 0.5 + 0.045], [0.21, 0.005, 0.028], copper, 0.001)
    # Inter-module orange HV busbar links inside the rear of the pack
    for x0, x1 in [(-0.54, -0.18), (-0.18, 0.18), (0.18, 0.54)]:
        pipe(
            "Battery_InterModule_Busbar",
            "Pack",
            [[x0, 0.295, -0.96], [(x0 + x1) * 0.5, 0.302, -1.02], [x1, 0.295, -0.96]],
            0.008,
            orange,
        )
    # Pyro-fuse & copper HV busbar rails inside AncillaryBay (penthouse)
    cylinder_between("Penthouse_Pyro_Fuse", "AncillaryBay", [0.22, 0.405, -0.89], [0.36, 0.405, -0.89], 0.018, orange, 16)
    for dz in (-0.94, -0.86):
        box("Penthouse_HV_Busbar", "AncillaryBay", [0.18, 0.415, dz], [0.42, 0.006, 0.018], copper, 0.0015)


build_drive_internals("FrontDrive", 1.445, 1, 0.275, -0.088, 0.124, is_rear=False)
build_drive_internals("RearDrive", -1.445, -1, 0.323, 0.088, 0.146, is_rear=True)
add_battery_cooling_and_busbars()
