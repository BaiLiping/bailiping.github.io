"""Convert the 1:1m editable master (2023_Model_Y_master.blend) into a GT3-standard
1:18-scale mm (+X fwd, +Y up, +Z right) interactive Pivot_* rig with semantic MY_*
mesh names, Mat_* material contract, curvature-preserving donor optimization, and
Draco-compressed GLB export.

Usage:
  blender -b 2023_Model_Y_master.blend -P export_gt3.py -- out/model-y.glb
"""
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path

import bmesh
import bpy
from mathutils import Matrix, Vector
import numpy as np

HERE = Path(__file__).resolve().parent
OUT_GLB = Path(sys.argv[sys.argv.index("--") + 1]).resolve() if "--" in sys.argv else (HERE / "out" / "model-y.glb")
OUT_GLB.parent.mkdir(parents=True, exist_ok=True)
RIG_BLEND = HERE / "2023_Model_Y_rig_1to18.blend"

SCALE_1_18 = 1000.0 / 18.0  # 1 model unit = 18 real mm

# Legacy Blender coords: +X left, +Y aft, +Z up (metres)
# Target Blender coords (for glTF Y-up export -> +X fwd, +Y up, +Z right in 1:18 mm):
#   X_b_new = -Y_b_old * SCALE_1_18  (glTF +X forward)
#   Y_b_new = +X_b_old * SCALE_1_18  (glTF -Z left, +Z right)
#   Z_b_new = +Z_b_old * SCALE_1_18  (glTF +Y up)
# Pure RotZ(+90 deg) * uniform scale (det > 0, no mirroring, preserves outward normals!)
T_TO_1_18 = Matrix.Scale(SCALE_1_18, 4) @ Matrix.Rotation(math.radians(90.0), 4, "Z")


def legacy_bl_to_1_18_bl(pt):
    v = T_TO_1_18 @ Vector(pt)
    return v


def convert_all_to_meshes():
    """Evaluate curves, fonts, and modifiers (bevel, weighted normals) into clean meshes."""
    scene = bpy.context.scene
    bpy.ops.object.select_all(action="DESELECT")
    targets = [o for o in scene.objects if o.type in ("MESH", "CURVE", "FONT", "SURFACE")]
    for obj in targets:
        obj.select_set(True)
    if targets:
        bpy.context.view_layer.objects.active = targets[0]
        bpy.ops.object.convert(target="MESH")
    bpy.ops.object.select_all(action="DESELECT")


def top_group_of(obj):
    cur = obj
    while cur.parent:
        cur = cur.parent
    return cur.name


def immediate_parent_name(obj):
    return obj.parent.name if obj.parent else ""


def classify_object(obj):
    """Map every master object to (target_pivot, semantic_role_name, decimate_target_ratio).
    Semantic names are designed to match every regex in model-y-config.js:
      - computePartOffset
      - NAME_PATTERNS (exteriorRe, shadowCasterRe, shadowReceiverRe, glassRe, doorGlassRe,
        enclosedDrivetrainRe, chargeHitRe)
      - PART_CATALOG (hover callouts)
    """
    top = top_group_of(obj)
    par = immediate_parent_name(obj)
    nm = obj.name
    mat_name = obj.data.materials[0].name if (obj.data and obj.data.materials and obj.data.materials[0]) else "Default"
    loc_w = obj.matrix_world.translation

    # --- 1. Closures under Pivot_Body_Assembly ---
    if top.startswith("Door"):
        # DoorFrontLeft -> FL, DoorRearRight -> RR
        row_c = "F" if "Front" in top else "R"
        side_c = "L" if "Left" in top else "R"
        code = row_c + side_c
        piv = f"Pivot_Door_{code}"
        if mat_name in ("Mat_Door_Glass", "Mat_Rear_Privacy_Glass"):
            return piv, f"MY_Glass_Door_{code}", 1.0
        if mat_name == "Ceramic glass border":
            return piv, f"MY_Glass_Door_{code}_Frit", 1.0
        if mat_name == "Mat_Side_Mirror_Glass":
            return piv, f"MY_Mirror_Glass_{code}", 1.0
        if mat_name.startswith(("Mat_Deep_Blue_Metallic", "Mat_Body_Paint")):
            return piv, f"MY_Door_Shell_{code}", 1.0
        if "wood accent" in nm.lower() or mat_name == "Open pore wood":
            return piv, f"MY_Door_Wood_Trim_{code}", 1.0
        if "inner card" in nm.lower() or "armrest" in nm.lower() or "pull handle" in nm.lower() or "door bin" in nm.lower() or "switch" in nm.lower() or "upper inner" in nm.lower():
            return piv, f"MY_Door_Card_{code}", 0.50
        return piv, f"MY_Door_Trim_{code}", 0.22

    if top == "Hood":
        if mat_name == "Reflector":
            return "Pivot_Front_Lid", "MY_Front_Lid_Badge", 1.0
        if "hinge" in nm.lower() or "latch" in nm.lower():
            return "Pivot_Front_Lid", "MY_Front_Lid_Hinges", 1.0
        return "Pivot_Front_Lid", "MY_Front_Lid_Hood", 1.0

    if top == "Liftgate":
        if mat_name == "Mat_Rear_Privacy_Glass":
            return "Pivot_Liftgate", "MY_Glass_Liftgate", 1.0
        if mat_name == "Ceramic glass border" or "heater trace" in nm.lower():
            return "Pivot_Liftgate", "MY_Glass_Liftgate_Frit", 1.0
        if mat_name in ("Mat_Taillamp_Clear_Lens", "Mat_Taillamp_Ruby_Lens", "Red tail light guide", "Ruby reflector", "Lamp housing", "Smoked tail reflector", "Amber side marker", "Dark optical baffle"):
            return "Pivot_Liftgate", "MY_Liftgate_Taillamp_Inner", 0.12
        if "plate" in nm.lower() or "screw" in nm.lower():
            return "Pivot_Liftgate", "MY_Liftgate_License_Plate", 1.0
        if "badge" in nm.lower() or mat_name == "Reflector":
            return "Pivot_Liftgate", "MY_Liftgate_Badge", 0.40
        if "interior panel" in nm.lower() or "latch access" in nm.lower():
            return "Pivot_Liftgate", "MY_Liftgate_Interior_Trim", 1.0
        return "Pivot_Liftgate", "MY_Liftgate_Shell", 1.0

    # ChargeDoor is nested under TailLampLeft in master!
    if par in ("ChargeDoor", "ChargeLink", "ChargeHinge") or "ChargeDoor" in nm or "flap" in nm.lower():
        if "bracket" in nm.lower() or "Fixed flap" in nm:
            return "Pivot_Body_Assembly", "MY_Charge_Inlet_Hardware", 1.0
        return "Pivot_Charge_Port", "MY_Charge_Port_Flap", 0.16

    # --- 2. Fixed exterior under Pivot_Body_Assembly ---
    if top == "Body":
        if mat_name == "Mat_Quarter_Glass":
            return "Pivot_Body_Assembly", "MY_Quarter_Glass", 1.0
        if mat_name == "Ceramic glass border":
            return "Pivot_Body_Assembly", "MY_Quarter_Glass_Frit", 0.55
        if mat_name == "Wheel arch and rocker":
            return "Pivot_Body_Assembly", "MY_Body_Rocker_Trim", 0.25
        if mat_name in ("Body inner e-coat", "Light grey woven headliner", "Grained steering wheel and charging mat", "Brushed alloy"):
            return "Pivot_Body_Assembly", "MY_Body_Inner_Structure", 0.45
        if mat_name.startswith(("Mat_Deep_Blue_Metallic", "Mat_Body_Paint")):
            return "Pivot_Body_Assembly", "MY_Body_Shell", 1.0
        return "Pivot_Body_Assembly", "MY_Body_Trim", 0.20

    if top == "Windshield":
        if mat_name == "Mat_Cabin_Rearview":
            return "Pivot_Body_Assembly", "MY_Cabin_Rearview", 1.0
        if mat_name == "Mat_Windshield_Glass":
            return "Pivot_Body_Assembly", "MY_Glass_Windshield", 1.0
        if mat_name == "Ceramic glass border":
            return "Pivot_Body_Assembly", "MY_Glass_Windshield_Frit", 1.0
        if "camera" in nm.lower() or "mirror stem" in nm.lower():
            return "Pivot_Body_Assembly", "MY_Autopilot_Camera_Pod", 1.0
        return "Pivot_Body_Assembly", "MY_Wipers", 1.0

    if top == "RoofGlass":
        if mat_name == "Mat_Roof_Glass":
            return "Pivot_Body_Assembly", "MY_Glass_Roof", 1.0
        return "Pivot_Body_Assembly", "MY_Glass_Roof_Frit", 1.0

    if top == "FrontFascia":
        if mat_name in ("Mat_Fog_Lens", "Amber side marker", "Dark optical baffle"):
            return "Pivot_Body_Assembly", "MY_Fog_Lamp_Front", 0.25
        if mat_name in ("Wheel housing liner", "Satin black trim"):
            return "Pivot_Body_Assembly", "MY_Front_Grille", 0.20
        return "Pivot_Body_Assembly", "MY_Front_Fascia", 1.0

    if top == "RearFascia":
        if mat_name in ("Wheel arch and rocker",):
            return "Pivot_Body_Assembly", "MY_Rear_Diffuser", 0.22
        if mat_name in ("Ruby reflector", "Mat_Taillamp_Ruby_Lens"):
            return "Pivot_Body_Assembly", "MY_Rear_Fascia_Reflector", 0.14
        return "Pivot_Body_Assembly", "MY_Rear_Fascia", 1.0

    if top in ("FenderLeft", "FenderRight"):
        side_c = "FL" if top.endswith("Left") else "FR"
        if "repeater" in nm.lower() or "camera" in nm.lower() or mat_name in ("Satin black trim", "Dark optical baffle", "Projector optics"):
            return "Pivot_Body_Assembly", f"MY_Camera_Repeater_{side_c}", 1.0
        if mat_name == "Wheel arch and rocker":
            return "Pivot_Body_Assembly", f"MY_Fender_Arch_{side_c}", 0.40
        return "Pivot_Body_Assembly", f"MY_Fender_{side_c}", 1.0

    if top in ("HeadlampLeft", "HeadlampRight"):
        side_c = "L" if top.endswith("Left") else "R"
        if mat_name == "Mat_Headlight_Clear_Lens":
            return "Pivot_Body_Assembly", f"MY_Headlamp_Clear_Lens_{side_c}", 1.0
        return "Pivot_Body_Assembly", f"MY_Headlamp_{side_c}", 0.30

    if top in ("TailLampLeft", "TailLampRight"):
        side_c = "L" if top.endswith("Left") else "R"
        if any(k in nm.lower() for k in ("charge", "inlet", "socket", "well")):
            return "Pivot_Body_Assembly", "MY_Charge_Inlet", 1.0
        return "Pivot_Body_Assembly", f"MY_Taillamp_Outer_{side_c}", 0.10

    # --- 3. Chassis, Suspension & Corners ---
    if top == "Underbody":
        return "Pivot_Drivetrain_Chassis", "MY_Underbody_Aero_Shield", 1.0

    if top == "HighVoltage":
        return "Pivot_Drivetrain_Chassis", "MY_HV_Harness_Cables", 1.0

    if top in ("FrontCarrier", "RearCarrier"):
        is_front = top == "FrontCarrier"
        row_c = "F" if is_front else "R"
        if nm.startswith(("Upright casting", "Hub carrier")):
            side_c = "L" if loc_w.x >= 0 else "R"
            return f"Pivot_Corner_{row_c}{side_c}", f"MY_Knuckle_{row_c}{side_c}", 1.0
        if is_front:
            if any(k in nm for k in ("Damper", "Spring", "coil")):
                return "Pivot_Drivetrain_Chassis", "MY_Front_Dampers_Springs", 1.0
            if any(k in nm for k in ("wishbone", "Lower lateral", "Tie rod", "tie rod", "bushing")):
                return "Pivot_Drivetrain_Chassis", "MY_Front_Suspension_Wishbones", 1.0
            return "Pivot_Drivetrain_Chassis", "MY_Front_Subframe", 1.0
        else:
            if any(k in nm for k in ("Damper", "Spring", "coil")):
                return "Pivot_Drivetrain_Chassis", "MY_Rear_Dampers_Springs", 1.0
            if any(k in nm for k in ("link", "bushing")):
                return "Pivot_Drivetrain_Chassis", "MY_Rear_Suspension_Links", 1.0
            return "Pivot_Drivetrain_Chassis", "MY_Rear_Subframe_Megacasting", 1.0

    if top.startswith("Brake"):
        row_c = "F" if "Front" in top else "R"
        side_c = "L" if "Left" in top else "R"
        code = row_c + side_c
        piv = f"Pivot_Corner_{code}"
        if "Caliper" in par or mat_name == "Gemini alloy graphite":
            return piv, f"MY_Caliper_{code}", 0.08
        return piv, f"MY_Brake_Rotor_{code}", 0.12

    if top.startswith("Wheel"):
        row_c = "F" if "Front" in top else "R"
        side_c = "L" if "Left" in top else "R"
        code = row_c + side_c
        piv = f"Pivot_WheelSpin_{code}"
        if "Tire" in par or mat_name in ("Tire rubber", "Molded sidewall", "Tread grooves"):
            return piv, f"MY_Tire_{code}", 0.65 if mat_name != "Tire rubber" else 0.72
        if mat_name == "Wheel hardware":
            return piv, f"MY_Lug_Nuts_{code}", 0.65
        return piv, f"MY_Alloy_{code}", 0.60

    if top.startswith("Cover"):
        row_c = "F" if "Front" in top else "R"
        side_c = "L" if "Left" in top else "R"
        code = row_c + side_c
        return f"Pivot_WheelSpin_{code}", f"MY_Gemini_Cover_{code}", 0.65

    # --- 4. Battery Pack ---
    if top == "Pack":
        if "Busbar" in nm:
            return "Pivot_Battery_Pack", "MY_Battery_Busbar", 1.0
        return "Pivot_Battery_Pack", "MY_Battery_Tray", 1.0
    if top == "Lid":
        return "Pivot_Battery_Pack", "MY_Battery_Lid", 1.0
    if top == "AncillaryCover":
        return "Pivot_Battery_Pack", "MY_Ancillary_Cover", 1.0
    if top == "AncillaryBay":
        if "Busbar" in nm or "Pyro" in nm or "Switching" in nm or "Contact" in nm:
            return "Pivot_Battery_Pack", "MY_Battery_Contactor_Bay", 1.0
        return "Pivot_Battery_Pack", "MY_Battery_Penthouse", 1.0
    if top.startswith("Module"):
        idx = top[-1]
        if "Cooling" in nm:
            return "Pivot_Battery_Pack", f"MY_Battery_Module_{idx}_Cooling", 1.0
        if "Busbar" in nm:
            return "Pivot_Battery_Pack", f"MY_Battery_Module_{idx}_Busbar", 1.0
        return "Pivot_Battery_Pack", f"MY_Battery_Module_{idx}", 1.0

    # --- 5. Front & Rear Electric Drive Units ---
    if top in ("FrontDrive", "RearDrive"):
        piv = "Pivot_Front_Drive" if top == "FrontDrive" else "Pivot_Rear_Drive"
        pfx = "MY_FrontDrive" if top == "FrontDrive" else "MY_RearDrive"
        if par.endswith("Case") or nm.startswith("Drive_Case_"):
            return piv, f"{pfx}_Case", 1.0
        if par.endswith("InverterCover") or nm.startswith("Inverter_Cover"):
            return piv, f"{pfx}_Inverter_Cover", 1.0
        if par.endswith("Stator") or nm.startswith("Stator_Core"):
            return piv, f"{pfx}_Stator_Core", 1.0
        if par.endswith("Rotor") or nm.startswith("Rotor_Core"):
            return piv, f"{pfx}_Rotor_Core", 1.0
        if par.endswith("ReductionGears") or nm.startswith(("Pinion_", "Reduction_Gear_")):
            return piv, f"{pfx}_Reduction_Gear", 1.0
        if par.endswith("DiffGears") or nm.startswith("Diff_Gear_"):
            return piv, f"{pfx}_Diff_Gear", 1.0
        if par.endswith("Inverter") or nm.startswith(("Inverter_", "Busbar_")):
            if "Busbar" in nm or "PCB" in nm or "Capacitor" in nm or "SiC" in nm:
                return piv, f"{pfx}_Busbar_Inverter", 1.0
            return piv, f"{pfx}_Inverter_Base", 1.0
        if par.endswith("Cooler") or "Coolant" in nm or "exchanger" in nm.lower():
            return piv, f"{pfx}_Cooler", 1.0
        if "Shaft" in par or "Halfshaft" in nm or "CV" in nm or "flange" in nm.lower():
            return piv, f"{pfx}_Halfshafts", 1.0
        return piv, f"{pfx}_Lower_Housing", 1.0

    # --- 6. Interior Cabin, Seats, Frunk & Cargo ---
    if top == "Cabin":
        if any(k in nm for k in ("Steering", "Airbag", "Spoke", "Lower spoke", "Scroll", "Column", "Stalk", "Wheel badge")):
            return "Pivot_Interior_Cabin", "MY_SteeringWheel_Assembly", 1.0
        if any(k in nm for k in ("display", "Display", "screen", "Screen")):
            return "Pivot_Interior_Cabin", "MY_Display_Touchscreen", 1.0
        if "wood" in nm.lower() or mat_name == "Open pore wood":
            return "Pivot_Interior_Cabin", "MY_Wood_Trim_Dash", 1.0
        return "Pivot_Interior_Cabin", "MY_Dash_Panel", 1.0

    if top == "Console":
        return "Pivot_Interior_Cabin", "MY_Console_Center", 0.50
    if top == "CabinFloor":
        if "Pedal" in nm:
            return "Pivot_Interior_Cabin", "MY_Pedals", 0.65
        return "Pivot_Interior_Cabin", "MY_Cabin_Floor", 0.55
    if top == "Frunk":
        return "Pivot_Interior_Cabin", "MY_Frunk_Tub", 0.45
    if top == "Cargo":
        if "parcel shelf" in nm.lower():
            return "Pivot_Interior_Cabin", "MY_Cargo_Parcel_Shelf", 0.70
        return "Pivot_Interior_Cabin", "MY_Cargo_Compartment", 0.50

    if top in ("FrontSeatLeft", "FrontSeatRight"):
        side_c = "L" if top.endswith("Left") else "R"
        if "cushion" in nm.lower() or "Cushion" in nm:
            return "Pivot_Interior_Cabin", f"MY_Seat_Front_{side_c}_Cushion", 0.50
        return "Pivot_Interior_Cabin", f"MY_Seat_Front_{side_c}_Backrest", 0.50

    if top == "RearSeat":
        if "cushion" in nm.lower() or "Cushion" in nm:
            return "Pivot_Interior_Cabin", "MY_Seat_Rear_Cushion", 0.45
        return "Pivot_Interior_Cabin", "MY_Seat_Rear_Bench", 0.45

    return "Pivot_Body_Assembly", f"MY_Misc_{top}", 1.0


def decimate_mesh_safe(obj, ratio):
    """Apply clean collapse decimation ONLY on non-painted bloated donor sub-meshes (lamps/brakes/trim),
    clearing stale custom split normals and recalculating smooth outward normals to prevent black artifacts.
    Painted exterior body panels always stay at ratio=1.0 (100% original smooth split normals!).
    """
    if ratio >= 0.99 or len(obj.data.polygons) < 400:
        return
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    # Clear custom split normals before collapse decimation so Blender recomputes clean smooth normals
    try:
        bpy.ops.mesh.customdata_custom_splitnormals_clear()
    except Exception:
        pass
    mod = obj.modifiers.new("AuditDecimate", "DECIMATE")
    mod.decimate_type = "COLLAPSE"
    mod.ratio = float(ratio)
    mod.use_collapse_triangulate = True
    bpy.ops.object.modifier_apply(modifier=mod.name)
    # Recalculate consistent outward face normals + smooth shading
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.polygons.foreach_set("use_smooth", np.ones(len(obj.data.polygons), dtype=bool))
    obj.data.update()
    obj.select_set(False)


def build_gt3_rig_and_export():
    convert_all_to_meshes()
    scene = bpy.context.scene

    # Record world-space ChargeDoor upper-outboard hinge before unparenting
    cd_pts = []
    for obj in scene.objects:
        if obj.type != "MESH":
            continue
        if immediate_parent_name(obj) in ("ChargeDoor", "ChargeLink", "ChargeHinge") or "ChargeDoor" in obj.name:
            if "bracket" not in obj.name.lower() and "Fixed flap" not in obj.name:
                M = np.array(obj.matrix_world)
                co = np.empty(len(obj.data.vertices) * 3)
                obj.data.vertices.foreach_get("co", co)
                w = co.reshape(-1, 3) @ M[:3, :3].T + M[:3, 3]
                cd_pts.append(w)
    if cd_pts:
        cd_all = np.vstack(cd_pts)
        # Upper-outboard edge in legacy Blender coords (+X left, +Y rear, +Z up)
        charge_hinge_bl = (float(cd_all[:, 0].max()), float(cd_all[:, 1].mean()), float(cd_all[:, 2].max()))
    else:
        charge_hinge_bl = (0.775, 1.94, 1.092)

    # Pivot definitions in legacy Blender coordinates (metres), converted via T_TO_1_18!
    pivot_specs = {
        "ModelY_Interactive_Rig": (None, (0.0, 0.0, 0.0)),
        "Pivot_Body_Assembly": ("ModelY_Interactive_Rig", (0.0, 0.0, 0.0)),
        "Pivot_Door_FL": ("Pivot_Body_Assembly", (0.855, -0.910, 0.780)),
        "Pivot_Door_FR": ("Pivot_Body_Assembly", (-0.855, -0.910, 0.780)),
        "Pivot_Door_RL": ("Pivot_Body_Assembly", (0.855, 0.300, 0.780)),
        "Pivot_Door_RR": ("Pivot_Body_Assembly", (-0.855, 0.300, 0.780)),
        "Pivot_Front_Lid": ("Pivot_Body_Assembly", (0.0, -1.140, 1.030)),
        "Pivot_Liftgate": ("Pivot_Body_Assembly", (0.0, 1.370, 1.440)),
        "Pivot_Charge_Port": ("Pivot_Body_Assembly", charge_hinge_bl),
        "Pivot_Drivetrain_Chassis": ("ModelY_Interactive_Rig", (0.0, 0.0, 0.0)),
        "Pivot_Battery_Pack": ("ModelY_Interactive_Rig", (0.0, 0.0, 0.0)),
        "Pivot_Front_Drive": ("ModelY_Interactive_Rig", (0.0, -1.445, 0.360)),
        "Pivot_Rear_Drive": ("ModelY_Interactive_Rig", (0.0, 1.445, 0.360)),
        "Pivot_Interior_Cabin": ("ModelY_Interactive_Rig", (0.0, 0.0, 0.0)),
        "Pivot_Corner_FL": ("ModelY_Interactive_Rig", (0.818, -1.445, 0.356)),
        "Pivot_Corner_FR": ("ModelY_Interactive_Rig", (-0.818, -1.445, 0.356)),
        "Pivot_Corner_RL": ("ModelY_Interactive_Rig", (0.818, 1.445, 0.356)),
        "Pivot_Corner_RR": ("ModelY_Interactive_Rig", (-0.818, 1.445, 0.356)),
        "Pivot_WheelSpin_FL": ("Pivot_Corner_FL", (0.818, -1.445, 0.356)),
        "Pivot_WheelSpin_FR": ("Pivot_Corner_FR", (-0.818, -1.445, 0.356)),
        "Pivot_WheelSpin_RL": ("Pivot_Corner_RL", (0.818, 1.445, 0.356)),
        "Pivot_WheelSpin_RR": ("Pivot_Corner_RR", (-0.818, 1.445, 0.356)),
    }

    # Classify every existing mesh object BEFORE touching hierarchy
    mesh_objs = [o for o in list(scene.objects) if o.type == "MESH" and len(o.data.vertices) > 0]
    buckets = defaultdict(list)  # (pivot_name, role_name, mat_name) -> [(obj, ratio)]
    for obj in mesh_objs:
        piv, role, ratio = classify_object(obj)
        mat = obj.data.materials[0] if obj.data.materials else None
        mat_key = mat.name if mat else "None"
        buckets[(piv, role, mat_key)].append((obj, ratio))

    # Create the clean GT3 Pivot_* Empty hierarchy in 1:18 Blender coords (identity rot/scale!)
    pivot_world_1_18 = {k: legacy_bl_to_1_18_bl(pos) for k, (_, pos) in pivot_specs.items()}
    piv_objs = {}
    for name, (parent_name, _) in pivot_specs.items():
        e = bpy.data.objects.new(name, None)
        scene.collection.objects.link(e)
        e.empty_display_size = 6.0 if name != "ModelY_Interactive_Rig" else 12.0
        if parent_name:
            e.parent = piv_objs[parent_name]
            e.location = pivot_world_1_18[name] - pivot_world_1_18[parent_name]
        else:
            e.location = pivot_world_1_18[name]
        e.rotation_euler = (0.0, 0.0, 0.0)
        e.scale = (1.0, 1.0, 1.0)
        piv_objs[name] = e

    bpy.context.view_layer.update()

    # Bake every mesh into 1:18 coords relative to its new Pivot_* parent, join within (piv, role, mat), and decimate
    created_meshes = []
    old_empties = [o for o in list(scene.objects) if o.type == "EMPTY" and o.name not in piv_objs]

    # Count materials per (piv, role) so unique role names don't collide when a role has multiple materials
    mats_per_role = defaultdict(set)
    for piv, role, mat_key in buckets:
        mats_per_role[(piv, role)].add(mat_key)

    for (piv, role, mat_key), items in sorted(buckets.items()):
        piv_origin = pivot_world_1_18[piv]
        joined_objs = []
        ratio = min(r for _, r in items)

        for obj, _ in items:
            # Transform vertex coordinates directly into target pivot's 1:18 local frame
            M_world_old = obj.matrix_world.copy()
            M_local_new = Matrix.Translation(-piv_origin) @ T_TO_1_18 @ M_world_old
            obj.parent = None
            obj.matrix_world = Matrix.Identity(4)
            obj.data.transform(M_local_new)
            obj.data.update()
            joined_objs.append(obj)

        bpy.ops.object.select_all(action="DESELECT")
        if len(joined_objs) > 1:
            for o in joined_objs:
                o.select_set(True)
            bpy.context.view_layer.objects.active = joined_objs[0]
            bpy.ops.object.join()
            merged = joined_objs[0]
            merged.select_set(False)
        else:
            merged = joined_objs[0]

        # Clean semantic name preserving role prefix (for regex matching in model-y-config.js!)
        if len(mats_per_role[(piv, role)]) > 1:
            mat_slug = re.sub(r"[^A-Za-z0-9]+", "_", mat_key).strip("_")
            final_name = f"{role}_{mat_slug}"
        else:
            final_name = role

        merged.name = final_name
        merged.data.name = final_name
        merged.parent = piv_objs[piv]
        merged.location = (0.0, 0.0, 0.0)
        merged.rotation_euler = (0.0, 0.0, 0.0)
        merged.scale = (1.0, 1.0, 1.0)

        # Targeted decimation on bloated donor meshes
        decimate_mesh_safe(merged, ratio)
        created_meshes.append(merged)

    # Remove old legacy empties & unused orphan data
    for e in old_empties:
        bpy.data.objects.remove(e, do_unlink=True)
    for o in list(scene.objects):
        if o.type == "MESH" and len(o.data.vertices) == 0:
            bpy.data.objects.remove(o, do_unlink=True)

    bpy.context.view_layer.update()

    # Exact ground-plane snap: shift root so lowest tire vertex sits at Z_blender = 0.0000 (glTF Y = 0)
    z_min = 1e9
    for o in created_meshes:
        if o.name.startswith("MY_Tire_") and o.name in scene.objects and o.data and len(o.data.vertices):
            co = np.empty(len(o.data.vertices) * 3)
            o.data.vertices.foreach_get("co", co)
            M = np.array(o.matrix_world)
            w = co.reshape(-1, 3) @ M[:3, :3].T + M[:3, 3]
            z_min = min(z_min, float(w[:, 2].min()))
    if abs(z_min) > 1e-5:
        piv_objs["ModelY_Interactive_Rig"].location.z -= z_min
        bpy.context.view_layer.update()

    # Set glTF metadata extras
    scene["source_model"] = "Adapted from Tesla Model Y 2021 by 763468712 (CC BY 4.0)"
    scene["source_url"] = "https://sketchfab.com/3d-models/tesla-model-y-2021-c0a86cac582d4b33aba0fb1b1912d970"
    scene["license"] = "https://creativecommons.org/licenses/by/4.0/"
    scene["adaptation"] = "2023 US Model Y Long Range AWD (5-seat, 1:18 GT3 rig, Pivot_* assemblies, internal EV drive gearsets/stators/rotors, 2023 Matrix LED optics, 172mm nominal clearance, flush 19-inch Gemini)."

    # Save 1:18 rigged blend for inspection/debugging
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(RIG_BLEND), compress=True)

    # Export Draco-compressed GLB
    bpy.ops.export_scene.gltf(
        filepath=str(OUT_GLB),
        export_format="GLB",
        export_apply=True,
        export_yup=True,
        export_extras=True,
        export_animations=False,
        export_draco_mesh_compression_enable=True,
        export_draco_mesh_compression_level=6,
        export_draco_position_quantization=14,
        export_draco_normal_quantization=10,
        export_copyright="Adapted from Tesla Model Y 2021 by 763468712 under CC BY 4.0.",
    )

    # Automated verification report
    total_tris = 0
    total_verts = 0
    all_w = []
    non_wheel_w = []
    tire_w = []
    cover_w = []
    lowest_nonwheel = (float("inf"), "")
    for o in scene.objects:
        if o.type != "MESH":
            continue
        o.data.calc_loop_triangles()
        total_tris += len(o.data.loop_triangles)
        total_verts += len(o.data.vertices)
        co = np.empty(len(o.data.vertices) * 3)
        o.data.vertices.foreach_get("co", co)
        M = np.array(o.matrix_world)
        w = co.reshape(-1, 3) @ M[:3, :3].T + M[:3, 3]
        all_w.append(w)
        if not (o.parent and o.parent.name.startswith("Pivot_WheelSpin_")):
            non_wheel_w.append(w)
            lowest_nonwheel = min(lowest_nonwheel, (float(w[:, 2].min()), o.name))
        elif o.name.startswith("MY_Tire_"):
            tire_w.append(w)
        elif o.name.startswith("MY_Gemini_Cover_"):
            cover_w.append(w)

    aw = np.vstack(all_w)
    nw = np.vstack(non_wheel_w)
    lo, hi = aw.min(0), aw.max(0)
    span = hi - lo
    # Body width excluding mirrors (Z_blender < 0.93 * SCALE_1_18 = 51.67)
    nm_mask = nw[:, 2] < 51.67
    body_w_u = float(nw[nm_mask, 1].max() - nw[nm_mask, 1].min())
    tires = np.vstack(tire_w)
    covers = np.vstack(cover_w)
    ground = float(tires[:, 2].min())
    clear_u = lowest_nonwheel[0] - ground
    cover_w_u = np.ptp(covers[:, 1])
    tire_w_u = np.ptp(tires[:, 1])
    hubs = {corner: piv_objs["Pivot_WheelSpin_" + corner].matrix_world.translation
            for corner in ("FL", "FR", "RL", "RR")}

    size_mb = OUT_GLB.stat().st_size / (1024 * 1024)
    summary = {
        "glb_path": str(OUT_GLB),
        "glb_mb": round(size_mb, 2),
        "mesh_count": sum(1 for o in scene.objects if o.type == "MESH"),
        "pivot_count": sum(1 for o in scene.objects if o.name.startswith("Pivot_")),
        "total_verts": total_verts,
        "total_tris": total_tris,
        "bounds_1_18_blender_XYZ_fwd_left_up": {
            "min": lo.round(3).tolist(),
            "max": hi.round(3).tolist(),
            "span_L_W_H": span.round(3).tolist(),
        },
        "verified_real_mm": {
            "length_mm": round(float(span[0] * 18.0), 1),
            "mirror_width_mm": round(float(span[1] * 18.0), 1),
            "body_width_excl_mirrors_mm": round(body_w_u * 18.0, 1),
            "gemini_cover_width_mm": round(cover_w_u * 18.0, 1),
            "width_across_tire_sidewalls_mm": round(float(tire_w_u * 18.0), 1),
            "min_cover_recess_from_sidewall_mm": round(float(min(
                tires[:, 1].max() - covers[:, 1].max(), covers[:, 1].min() - tires[:, 1].min()
            ) * 18.0), 1),
            "wheelbase_mm": round(18.0 * (hubs["FL"].x - hubs["RL"].x), 1),
            "front_track_mm": round(18.0 * (hubs["FL"].y - hubs["FR"].y), 1),
            "rear_track_mm": round(18.0 * (hubs["RL"].y - hubs["RR"].y), 1),
            "height_mm": round(float((hi[2] - ground) * 18.0), 1),
            "min_nonwheel_clearance_mm": round(clear_u * 18.0, 1),
            "lateral_asymmetry_mm": round(float((hi[1] + lo[1]) * 18.0), 2),
        },
        "lowest_nonwheel_mesh": lowest_nonwheel[1],
        "pivots": sorted(o.name for o in scene.objects if o.name.startswith("Pivot_")),
        "materials": sorted(m.name for m in bpy.data.materials if m.users > 0),
    }
    (HERE / "out" / "export_report.json").write_text(json.dumps(summary, indent=2))
    print("=== GT3 EXPORT VERIFICATION ===", flush=True)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    build_gt3_rig_and_export()
