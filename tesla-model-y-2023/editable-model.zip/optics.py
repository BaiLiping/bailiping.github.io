"""Reconstruct the 2023 Model Y smoked Matrix LED headlamp optics:
- Sleek bright pearl-white upper DRL brow blade
- Distinct outboard circular Matrix LED projector lens module + dark satin shroud
- Subtle inner secondary optical pod
Executed inside exterior.py for each headlamp side.
"""
from scipy.spatial import Delaunay, ConvexHull


def opal_diffuser(g, coords):
    """Build a crisp, sleek 2023 upper DRL light blade along the top brow of the headlamp
    (replacing the overly wide milky 2021 diffuser) plus the outboard Matrix LED projector.
    """
    # 1. Keep only the sleek upper 35% of the diffuser field for the crisp Tesla DRL brow
    y_cut = np.percentile(coords[:, 1], 58)
    brow = coords[coords[:, 1] >= y_cut]
    if len(brow) < 12:
        brow = coords
    center = brow.mean(0)
    _, _, basis = np.linalg.svd(brow - center, full_matrices=False)
    u, v, n = basis
    if n @ np.array([0.0, 0.8, 1.0]) < 0:
        n = -n
    flat = (brow - center) @ np.array([u, v]).T
    z = (brow - center) @ n
    hull = ConvexHull(flat)
    outline = flat[hull.vertices]
    xx, yy = np.meshgrid(
        np.linspace(flat[:, 0].min(), flat[:, 0].max(), 22),
        np.linspace(flat[:, 1].min(), flat[:, 1].max(), 10),
    )
    grid = np.c_[xx.ravel(), yy.ravel()]
    grid = grid[(grid @ hull.equations[:, :2].T + hull.equations[:, 2] < -0.0003).all(1)]
    xy = np.vstack((outline, grid))

    def design(a):
        x, y = a.T
        return np.c_[np.ones(len(x)), x, y, x * x, x * y, y * y]

    c, *_ = np.linalg.lstsq(design(flat), z, rcond=None)
    skin = design(xy) @ c + np.percentile(z - design(flat) @ c, 85) + 0.001
    vertices = center + xy[:, 0:1] * u + xy[:, 1:2] * v + skin[:, None] * n
    faces = Delaunay(xy).simplices
    normals = np.cross(
        u + (c[1] + 2 * c[3] * xy[:, 0] + c[4] * xy[:, 1])[:, None] * n,
        v + (c[2] + c[4] * xy[:, 0] + 2 * c[5] * xy[:, 1])[:, None] * n,
    )
    if normals[0] @ n < 0:
        normals = -normals
    if np.cross(vertices[faces[0, 1]] - vertices[faces[0, 0]], vertices[faces[0, 2]] - vertices[faces[0, 0]]) @ n < 0:
        faces = faces[:, ::-1]
    add(g, guide, vertices, faces, normals)

    # 2. 2023 Matrix LED outboard projector lens + dark satin shroud (glTF coords)
    sg = 1.0 if g.endswith("Left") else -1.0
    # Outboard corner of headlamp cavity: x ~ ±0.742, y ~ 0.808, z ~ 1.878
    # Aim forward (+Z) and slightly outboard (+sg*X)
    fwd = np.array([sg * 0.24, -0.04, 0.97])
    fwd /= np.linalg.norm(fwd)
    up = np.array([0.0, 1.0, 0.0])
    right = np.cross(up, fwd)
    right /= np.linalg.norm(right)
    up = np.cross(fwd, right)

    proj_c = np.array([sg * 0.728, 0.805, 1.912])

    def build_lathe_optic(mat_name, stations, segs=28):
        vs = []
        for depth_f, r_x, r_y in stations:
            for k in range(segs):
                a = math.tau * k / segs
                p = proj_c + fwd * depth_f + right * (r_x * math.cos(a)) + up * (r_y * math.sin(a))
                vs.append(p)
        ff = [
            (j * segs + k, j * segs + (k + 1) % segs, (j + 1) * segs + (k + 1) % segs, (j + 1) * segs + k)
            for j in range(len(stations) - 1)
            for k in range(segs)
        ]
        add(g, mat_name, np.asarray(vs), np.asarray(ff))

    # Dark satin shroud around Matrix projector
    build_lathe_optic(
        smoke,
        [(-0.042, 0.036, 0.034), (-0.012, 0.035, 0.033), (0.008, 0.030, 0.028), (0.010, 0.024, 0.023), (-0.008, 0.023, 0.022)],
        28,
    )
    # Glossy bluish-dark convex Matrix projector lens dome
    build_lathe_optic(
        projector,
        [(-0.005, 0.023, 0.022), (0.006, 0.021, 0.020), (0.014, 0.014, 0.013), (0.018, 0.005, 0.005), (0.019, 0.0005, 0.0005)],
        24,
    )
    # Subtle silver-chrome trim ring catching light around the projector barrel
    build_lathe_optic(
        dark_optic,
        [(0.004, 0.0265, 0.0255), (0.009, 0.0255, 0.0245), (0.009, 0.0235, 0.0225)],
        28,
    )
