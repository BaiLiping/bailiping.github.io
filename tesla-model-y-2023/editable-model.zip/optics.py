"""Reconstruct the smooth upper diffuser over the donor's tessellated reflector field."""
from scipy.spatial import Delaunay
from scipy.spatial import ConvexHull
def opal_diffuser(g,coords):
 # Extract the aperture perimeter in its own tilted plane. A quadratic fit
 # retains its crown and smooths the prismatic texture beneath the opal cover.
 center=coords.mean(0);_,_,basis=np.linalg.svd(coords-center,full_matrices=False)
 u,v,n=basis
 if n@np.array([0,.8,1.0])<0:n=-n
 flat=(coords-center)@np.array([u,v]).T;z=(coords-center)@n
 hull=ConvexHull(flat)
 outline=flat[hull.vertices];xx,yy=np.meshgrid(np.linspace(flat[:,0].min(),flat[:,0].max(),32),np.linspace(flat[:,1].min(),flat[:,1].max(),18))
 grid=np.c_[xx.ravel(),yy.ravel()]
 grid=grid[(grid@hull.equations[:,:2].T+hull.equations[:,2]<-.0003).all(1)]
 xy=np.vstack((outline,grid))
 def design(a):
  x,y=a.T;return np.c_[np.ones(len(x)),x,y,x*x,x*y,y*y]
 c,*_=np.linalg.lstsq(design(flat),z,rcond=None)
 skin=design(xy)@c+np.percentile(z-design(flat)@c,90)+.001
 vertices=center+xy[:,0:1]*u+xy[:,1:2]*v+skin[:,None]*n
 faces=Delaunay(xy).simplices
 normals=np.cross(u+(c[1]+2*c[3]*xy[:,0]+c[4]*xy[:,1])[:,None]*n,v+(c[2]+c[4]*xy[:,0]+2*c[5]*xy[:,1])[:,None]*n)
 if normals[0]@n<0:normals=-normals
 if np.cross(vertices[faces[0,1]]-vertices[faces[0,0]],vertices[faces[0,2]]-vertices[faces[0,0]])@n<0:faces=faces[:,::-1]
 add(g,opal,vertices,faces,normals)
