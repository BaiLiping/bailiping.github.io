"""Cabin trim, optic inserts, molded markings and wood-grain material."""
from PIL import Image,ImageFilter
# Open-pore wood strips have a continuous, longitudinal grain across the dash.
rng=np.random.default_rng(2023);w,h=768,128
def grain_band(width,height):
 im=Image.fromarray(np.uint8(rng.random((height,width))*255)).resize((w,h),Image.Resampling.BICUBIC)
 return (np.asarray(im).astype(float)/255-.5)
grain=(grain_band(12,106)*.38+grain_band(29,36)*.22+grain_band(7,8)*.20)
base=np.array([138,109,82]);img=np.clip(base+grain[:,:,None]*[89,78,67],0,255).astype('uint8')
img_path=HERE/'ash-grain.png';Image.fromarray(img).save(img_path)
woodmat=materials[wood];nt=woodmat.node_tree;shader=nt.nodes.get('Principled BSDF')
tx=nt.nodes.new('ShaderNodeTexImage');tx.image=bpy.data.images.load(str(img_path));tx.image.pack();nt.links.new(tx.outputs['Color'],shader.inputs['Base Color'])
for ob in bpy.context.scene.objects:
 if ob.type!='MESH' or not any(m==woodmat for m in ob.data.materials):continue
 me=ob.data;uv=me.uv_layers.new(name='Longitudinal grain')
 verts=np.array([v.co[:] for v in me.vertices]);axis=np.argmax(np.ptp(verts,axis=0));lo=verts.min(0);span=np.maximum(np.ptp(verts,axis=0),1e-4)
 for loop in me.loops:
  pos=(verts[loop.vertex_index]-lo)/span;uv.data[loop.index].uv=(pos[axis],pos[2])
# Rear console vent grille, two USB-Cs, and belt receivers beside the real seat cushions.
box('Rear console vent housing','Console',[0,.521,-.433],[.248,.164,.077],cabin,.022)
box('Rear air outlet recess','Console',[0,.540,-.475],[.209,.057,.005],trim,.007)
for j in range(4):box('Rear outlet horizontal blade','Console',[0,.522+j*.011,-.480],[.202,.0028,.009],stitch,.0014)
for x in (-.063,-.030,.030,.063):box('Rear outlet divider','Console',[x,.54,-.481],[.0025,.046,.007],trim,.001)
for x in (-.062,.062):
 box('USB-C socket','Console',[x,.474,-.475],[.011,.004,.006],metal,.0018)
 box('USB-C tongue','Console',[x,.474,-.479],[.008,.002,.001],trim,.001)
for side,sg in [('Left',1),('Right',-1)]:
 g='FrontSeat'+side
 for x in (.245,.535):
  box('Steel seat adjustment rail',g,[sg*x,.385,-.12],[.031,.033,.445],pcoat,.007)
  for z in (.066,-.296):cylinder_between('Seat anchor bolt',g,[sg*x,.396,z],[sg*x,.407,z],.011,lugmetal,6)
 box('Recline control',g,[sg*.644,.512,-.257],[.014,.040,.021],trim,.007,-.28)
 box('Seat position switch',g,[sg*.645,.487,-.150],[.014,.017,.065],trim,.008)
 box('Front belt receiver',g,[sg*.184,.580,-.324],[.047,.061,.039],trim,.009,-.24)
 box('Red buckle release',g,[sg*.184,.608,-.325],[.031,.009,.026],rear,.003,-.24)
# Pedal pads and transverse grooves face the left-hand driver's seat.
for x,y,z,width,height in [(.366,.595,.837,.097,.066),(.230,.540,.856,.047,.107)]:
 box('Pedal pad','CabinFloor',[x,y,z],[width,height,.021],trim,.008,-.19)
 for j in range(5):
  dy=(j-2)*height*.145;box('Pedal grip rib','CabinFloor',[x,y+dy,z-.013+dy*.18],[width*.83,.0025,.003],wheelwell,.001,-.19)
# The thick white upper optical guide in the pre-refresh headlamp follows the lens sweep.
for side,sg in [('Left',1),('Right',-1)]:
 # The sizing mark stays with the tire when the aero cover is removed.
 for row in ('Front','Rear'):
  wg='Wheel'+row+side;hub=groups[wg][1];txt='255/45 R19';radius=.279
  for i,ch in enumerate(txt):
   a=(i-(len(txt)-1)/2)*.037-.48
   pos=hub+[sg*.1257,radius*math.cos(a),-sg*radius*math.sin(a)]
   local_text('Molded tire size',ch,wg,pos,[0,-math.sin(a),-sg*math.cos(a)],[0,math.cos(a),-sg*math.sin(a)],.014,sidewall if 'sidewall' in globals() else 'Molded sidewall',.00035)

exec(compile((HERE/'seats.py').read_text(),str(HERE/'seats.py'),'exec'))
exec(compile((HERE/'cabin_fit.py').read_text(),str(HERE/'cabin_fit.py'),'exec'))
