"""Interior finish, cargo spaces and simplified drive layout for the 2023 Model Y."""
# Executed inside build.py after the main assemblies have been built.
def faced(label,g,verts,faces,material,radius=0):
 me=bpy.data.meshes.new(label);me.from_pydata(blender(np.array(verts)-groups[g][1]).tolist(),[],faces)
 me.materials.append(materials[material]);me.update();o=bpy.data.objects.new(label,me);bpy.context.collection.objects.link(o);o.parent=groups[g][0]
 if radius:
  mod=o.modifiers.new('Edge radius','BEVEL');mod.width=radius;mod.segments=3;me.use_auto_smooth=True
 return o
def poly_plate(label,g,profile,x,thickness,material):
 verts=[(x0,y,z) for x0 in (x,x+thickness) for z,y in profile];n=len(profile)
 faces=[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]+[(k,(k+1)%n,n+(k+1)%n,n+k) for k in range(n)]
 return faced(label,g,verts,faces,material,.012)
# Display face uses a flat, UV mapped panel inset slightly ahead of the glass.
verts=[(.167,.997-.099,.427-.099*.16),(-.167,.997-.099,.427-.099*.16),(-.167,.997+.099,.427+.099*.16),(.167,.997+.099,.427+.099*.16)]
ob=faced('Parked screen illustration','Cabin',verts,[(0,1,2,3)],screen);me=ob.data
uv=me.uv_layers.new(name='Screen UV')
for li,coords in enumerate([(0,0),(1,0),(1,1),(0,1)]):uv.data[li].uv=coords
lcd=bpy.data.materials.new('Parked touchscreen');lcd.use_nodes=True;nodes=lcd.node_tree.nodes
tex=nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(HERE/'display.png'));tex.image.pack()
shader=nodes.get('Principled BSDF');shader.inputs['Roughness'].default_value=.49
lcd.node_tree.links.new(tex.outputs['Color'],shader.inputs['Base Color'])
lcd.node_tree.links.new(tex.outputs['Color'],shader.inputs['Emission Color']);shader.inputs['Emission Strength'].default_value=.33
ob.data.materials.clear();ob.data.materials.append(lcd)
# Follow the photographed drop of the inboard door card towards the sill.
for side,sg in [('Left',1),('Right',-1)]:
 for row,z0,z1 in [('Front',.85,-.29),('Rear',-.31,-1.25)]:
  g='Door'+row+side;x=.729*sg;mid=(z0+z1)*.5
  poly_plate(g+' inner card',g,[(z0,.96),(z0-.05,1),(z1+.025,1.044),(z1,.86),(z1+.08,.31),(z0-.015,.32)],x,.041*sg,cabin)
  poly_plate(g+' inner beltline',g,[(z0-.025,1.032),(z1+.03,1.085),(z1+.035,1.035),(z0-.028,.992)],x+.005*sg,.026*sg,trim)
  poly_plate(g+' top rail',g,[(z0-.02,1.001),(z1+.03,1.047),(z1+.035,1.007),(z0-.028,.969)],x-.007*sg,.02*sg,trim)
  poly_plate(g+' wood accent',g,[(z0-.06,.971),(mid-.05,1.006),(mid+.03,.974),(z0-.065,.943)],x-.009*sg,.007*sg,wood)
  poly_plate(g+' armrest',g,[(z0-.12,.717),(mid-.16,.708),(z1+.10,.756),(z1+.095,.700),(mid-.13,.651),(z0-.12,.660)],x-.066*sg,.073*sg,trim)
  poly_plate(g+' pull handle',g,[(mid+.12,.936),(mid+.066,.924),(mid-.14,.735),(mid-.09,.713)],x-.050*sg,.047*sg,cabin)
  box(g+' window switch',g,[x-.042*sg,.717,mid+.045],[.022,.010,.043],trim,.003)
  # The driver's inner card carries the mirror and window controls on the front armrest.
carpet=mat('Dark cabin carpet',(.014,.016,.019),0,.92)
box('Passenger tray and carpeting','Cabin',[0,.352,-.057],[1.55,.047,2.275],carpet,.025)
for side in (-1,1):
 poly_plate('Carpeted front toe board','Cabin',[(.63,.373),(.987,.61),(1.05,.76),(1.07,.735),(1.02,.56),(.68,.35)],.019*side,.712*side,carpet)
box('Rear seat riser over battery bay','Cabin',[0,.453,-.908],[1.38,.09,.48],carpet,.035)

box('Rear trunk load floor','Body',[0,.608,-1.73],[1.33,.065,.90],cabin,.042)
box('Rear trunk threshold','Body',[0,.671,-2.15],[1.18,.047,.085],trim,.020)
for sg in (-1,1):
 box('Rear load-space trim','Body',[sg*.638,.80,-1.70],[.084,.37,.88],cabin,.051)
# Front tub tapers between rounded quadrilaterals, recessed below the hood.
vs=[];n=64
for w,l,cy,cz in [(.56,.35,.88,1.63),(.51,.31,.875,1.64),(.49,.29,.835,1.65),(.408,.212,.557,1.66),(.377,.185,.533,1.66)]:
 for i in range(n):
  a=i*2*math.pi/n;cx,sz=math.cos(a),math.sin(a)
  xx=np.sign(cx)*abs(cx)**.52;zz=np.sign(sz)*abs(sz)**.52
  x=w*xx*(1-.07*zz);z=cz+l*zz;y=cy-(z-cz)*.26
  vs.append([x,y,z])
faces=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i) for j in range(4) for i in range(n)]
faces.append(tuple(range(4*n,5*n)));tub=faced('Molded front trunk tub','Body',vs,faces,arch)
for face in tub.data.polygons:face.use_smooth=True
box('Cowl service panel','Body',[0,.93,1.14],[1.20,.055,.28],trim,.035,-.12)
# EV housing and shafts are layout studies anchored on the axle centers. Their casting
# details and pack variant differ across factories and are intentionally abstracted.
def cylinder_between(label,g,a,b,r,material,segments=36):
 a,b=np.array(a),np.array(b);delta=blender(b-a);origin=groups[g][1]
 bpy.ops.mesh.primitive_cylinder_add(vertices=segments,radius=r,depth=float(np.linalg.norm(delta)))
 o=bpy.context.object;o.name=label;o.parent=groups[g][0];o.location=blender((a+b)*.5-origin)
 o.rotation_euler=Vector(delta).to_track_quat('Z','Y').to_euler();o.data.materials.append(materials[material])
 for poly in o.data.polygons:poly.use_smooth=(len(poly.vertices)==4)
 return o
exec(compile((HERE/'electric.py').read_text(),str(HERE/'electric.py'),'exec'))
# The wheel badge follows the airbag face with its crown fully in front of the leather.

exec(compile((HERE/'cabin_details.py').read_text(),str(HERE/'cabin_details.py'),'exec'))
