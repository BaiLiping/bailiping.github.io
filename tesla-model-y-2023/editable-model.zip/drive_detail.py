"""Cast ribs, mounting lugs and coolant connections traced from the unit photos."""
for g,z,sg,depth,r in [('FrontDrive',1.445,1,-.088,.124),('RearDrive',-1.445,-1,.088,.146)]:
 sign=sg
 # Place rib ridges on the outside of the flared reduction housing at consecutive
 # axial sections. The buttresses fan out from the outer differential bearing.
 for i in range(11):
  a=math.tau*i/11
  stations=[(.26,.36,z,.96*.64*r,1.02*.71*r),(.208,.369,z+depth*.3,.93*r,1.10*r),(.11,.37,z+depth*.45,1.03*r,1.46*r),(-.05,.369,z+depth*.65,1.09*r,1.41*r)]
  verts=[]
  for xx,cy,cz,ry,rz in stations:
   for da,raise_ in [(-.043,0),(0,.011),(.043,0)]:
    verts.append([sg*xx,cy+(ry+raise_)*np.sin(a+da),cz+(rz+raise_)*np.cos(a+da)])
  faces=[]
  for k in range(3):
   for j in (0,1):
    k0=k*3+j;faces.append((k0,k0+3,k0+4,k0+1))
  faced('Reduction case gusset',g,verts,faces,aluminum,.001)
  # Distinct bolt bosses along the gearbox assembly mating flange.
  uy,uz=math.sin(a),math.cos(a);yy=.369+1.12*r*uy;zz=z+depth*.65+1.44*r*uz
  cylinder_between('Case flange bolt boss',g,[sg*(-.069),yy,zz],[sg*(-.035),yy,zz],.0125,cast,18)
  cylinder_between('Flange bolt head',g,[sg*(-.034),yy,zz],[sg*(-.027),yy,zz],.0085,metal,6)
 for xx,cy,cz,ry,rz in [(-.065,.369,z+depth*.65,r*1.10,r*1.43),(.114,.37,z+depth*.45,r*1.05,r*1.476)]:
  ring_housing(g,'Bolted case flange',[(sg*xx,cy,cz,ry,rz),(sg*(xx+.008),cy,cz,ry,rz)],aluminum)
 # A finned cooler stands on the front face, clear of the cast differential.
 cool_z=z+(.236 if g=='FrontDrive' else -.246)
 for j in range(11):
  box('Plate exchanger fin',g,[sg*.049,.370,cool_z+(j-5)*.0038],[.143,.139,.003],aluminum,.002)
 for sx in (-1,1):
  pipe('Exchanger coolant line',g,[[sg*.049+sx*.042,.432,cool_z],[sg*.047+sx*.042,.479,cool_z],[sg*.040+sx*.053,.498,cool_z+(z-cool_z)*.28]],.010,trim)
 inlet_z=z+(.179 if g=='FrontDrive' else -.188)
 for sx in (-1,1):
  cylinder_between('HV header collar',g,[-sg*.109,.461+sx*.020,inlet_z],[-sg*.109,.461+sx*.020,inlet_z+np.sign(inlet_z-z)*.035],.016,orange,16)
 # Triangulated web cast into the inverter face instead of a parallel comb.
 for i in range(3):
  dx=-.106+i*.080+( .075 if g=='FrontDrive' else -.05)
  cylinder_between('Inverter diagonal rib',g,[sg*dx,.549,z+depth-.071],[sg*(dx+.077),.549,z+depth+.114],.0045,aluminum,5)
  cylinder_between('Cover bolt',g,[sg*dx,.548,z+depth-.07],[sg*dx,.553,z+depth-.07],.006,trim,6)
