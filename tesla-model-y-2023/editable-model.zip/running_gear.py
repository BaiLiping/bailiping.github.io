"""Suspension architecture from Tesla's 2020–2024 service figures.
Link curves, cross sections and mount coordinates are illustrative at vehicle scale.
"""
pcoat=mat('E-coated subframe',(.033,.038,.043),.44,.43)
damper=mat('Damper tube',(.043,.047,.052),.53,.31)
springsteel=mat('Spring steel',(.028,.032,.035),.55,.31)
def girder(label,g,stations,m):
 # Rounded rectangular steel section swept through the stamped carrier.
 verts=[]
 for x,y,z,w,h in stations:
  for j in range(16):
   a=math.tau*j/16;c,s=math.cos(a),math.sin(a)
   verts.append([x+w*np.sign(c)*abs(c)**.55,y+h*np.sign(s)*abs(s)**.50,z])
 n=16;faces=[tuple(range(n-1,-1,-1)),tuple(range(len(verts)-n,len(verts)))]+[(i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j) for i in range(len(stations)-1) for j in range(n)]
 ob=faced(label,g,verts,faces,m,.003)
 for p in list(ob.data.polygons)[2:]:p.use_smooth=True
def spring(label,g,bottom,top,r,turns):
 a,b=np.array(bottom),np.array(top);axis=(b-a)/np.linalg.norm(b-a)
 side=np.cross(axis,[0,0,1]);side/=np.linalg.norm(side);front=np.cross(axis,side)
 t=np.linspace(0,1,int(turns*43));radius=r*(.83+.17*np.sin(t*math.pi)**.6)
 pts=[a+(b-a)*u+v*(np.cos(math.tau*turns*u)*side+np.sin(math.tau*turns*u)*front) for u,v in zip(t,radius)]
 polyline(label,g,pts,.0084,springsteel)
 for p in (a,b):cylinder_between('Spring isolator',g,p-axis*.005,p+axis*.005,r+.006,trim,48)
def shock(g,bottom,top):
 a,b=np.array(bottom),np.array(top);d=b-a
 cylinder_between('Damper lower eye and tube',g,a,a+.62*d,.028,damper)
 cylinder_between('Damper piston rod',g,a+.60*d,b,.010,chrome)
 for t in np.linspace(.60,.80,8):
  cylinder_between('Damper dust boot fold',g,a+d*t,a+d*(t+.019),.022,trim,24)
 cylinder_between('Upper damper mount',g,b-.025*d,b+.020*d,.045,pcoat,36)
def bushing(g,p):
 p=np.array(p)
 for rad,m,dx in [(.041,pcoat,.031),(.031,rubber,.034),(.012,metal,.037)]:
  cylinder_between('Bonded suspension bushing',g,p-[0,0,dx],p+[0,0,dx],rad,m,28)
for row,z0 in [('Front',1.445),('Rear',-1.445)]:
 g=row+'Carrier'
 for sg in (-1,1):
  girder(row+' boxed carrier rail',g,[(sg*x,y,z0+z,w,h) for x,y,z,w,h in [(.425,.32,-.33,.063,.045),(.44,.273,-.20,.069,.041),(.42,.248,-.02,.054,.039),(.395,.247,.19,.061,.040),(.38,.323,.31,.065,.047)]],pcoat)
  for zz in (-.31,.30):
   x=sg*(.428 if zz<0 else .38);y=.335
   cylinder_between('Carrier body mount',g,[x,y-.035,z0+zz],[x,y+.026,z0+zz],.047,rubber,36)
   cylinder_between('Carrier mount sleeve',g,[x,y-.035,z0+zz],[x,y+.029,z0+zz],.019,metal,24)
  # Cast knuckle behind the rotor; both outer ball joints terminate here.
  knuckle=[[sg*.752,.234,z0+.012],[sg*.749,.336,z0+.018],[sg*.741,.412,z0-.015],[sg*.726,.533,z0-.020]]
  pipe('Upright casting',g,knuckle,.031,cast)
  cylinder_between('Hub carrier',g,[sg*.714,.356,z0],[sg*.774,.356,z0],.069,cast,40)
  if row=='Front':
   for dz in (-.169,.163):
    a=[sg*.464,.555,z0+dz];b=[sg*.729,.549,z0-.020]
    pipe('Upper wishbone branch',g,[a,[sg*.55,.585,z0+.84*dz],[sg*.665,.572,z0+.53*dz],b],.017,pcoat);bushing(g,a)
   for dz in (-.228,.174):
    a=[sg*.405,.269,z0+dz];b=[sg*.743,.225,z0+dz*.17]
    pipe('Lower lateral and compliance link',g,[a,[sg*.515,.25,z0+dz*.76],[sg*.639,.242,z0+dz*.52],b],.023,cast);bushing(g,a)
   shock(g,[sg*.665,.248,z0+.032],[sg*.560,.789,z0-.071])
   spring('Front coil on damper',g,[sg*.634,.414,z0+.006],[sg*.563,.737,z0-.063],.062,5.8)
   cylinder_between('Steering tie rod',g,[sg*.392,.344,z0-.116],[sg*.734,.337,z0-.111],.010,metal)
  else:
   girder('Rear spring link',g,[(sg*.496,.223,z0-.115,.147,.024),(sg*.574,.220,z0-.067,.151,.023),(sg*.641,.232,z0+.043,.10,.020)],pcoat)
   for dy,dz,outer in [(.269,-.198,.242),(.397,.185,.438),(.423,-.158,.51)]:
    a=[sg*.411,dy,z0+dz];b=[sg*.736,outer,z0+dz*.19]
    pipe('Rear locating link',g,[a,[sg*.57,(dy+outer)/2+.015,z0+dz*.63],b],.019,cast);bushing(g,a)
   spring('Rear coil on spring link',g,[sg*.567,.256,z0-.078],[sg*.517,.570,z0-.101],.067,5.2)
   shock(g,[sg*.699,.243,z0-.137],[sg*.647,.712,z0-.211])
 for zz in (-.223,.224):
  pipe('Carrier crossmember',g,[[-.410,.267,z0+zz],[-.224,.243,z0+zz*1.12],[0,.242,z0+zz*1.18],[.224,.243,z0+zz*1.12],[.410,.267,z0+zz]],.035,pcoat)
 pipe('Anti-roll bar',g,[[-.681,.322,z0+.009],[-.57,.315,z0+.161],[-.36,.285,z0+.176],[0,.285,z0+.18],[.36,.285,z0+.176],[.57,.315,z0+.161],[.681,.322,z0+.009]],.012,damper)
