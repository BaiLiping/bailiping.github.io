"""Soft trim, steering controls and center console from the two saved cabin views."""
stitch=mat('Graphite leather seam',(.052,.052,.052),.01,.66)
headliner=mat('Light grey woven headliner',(.40,.39,.38),0,.90)
satin=mat('Satin console edging',(.38,.39,.39),.57,.43)
pad=mat('Grained steering wheel and charging mat',(.014,.015,.016),.015,.73)
hub_x,hub_y,hub_z=.371,1.023,.378

def wheel_station(label,stations,material):
 # Cross-sections follow the tilted wheel face. The driver-facing surface is
 # softly crowned and the rear surface joins the steering column.
 verts=[];n=40
 for height,half_width,front,depth in stations:
  for i in range(n):
   a=math.tau*i/n;c=np.cos(a);sn=np.sin(a)
   x=half_width*np.sign(c)*abs(c)**.72
   z=front+depth*.5*(1+np.sign(sn)*abs(sn)**.64)
   verts.append((hub_x+x,hub_y+height,hub_z+height*.32+z))
 faces=[tuple(range(n-1,-1,-1)),tuple(range((len(stations)-1)*n,len(stations)*n))]+[(k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j) for k in range(len(stations)-1) for j in range(n)]
 ob=faced(label,'Cabin',verts,faces,material,.002)
 for f in ob.data.polygons:f.use_smooth=True

wheel_station('Airbag bolster',[(-.077,.027,-.018,.041),(-.073,.046,-.024,.049),(-.043,.065,-.031,.063),(.004,.083,-.036,.074),(.035,.086,-.033,.070),(.046,.077,-.029,.059),(.052,.059,-.024,.049)],pad)
wheel_station('Spoke surround',[(-.156,.022,-.012,.027),(-.145,.031,-.018,.041),(-.092,.035,-.023,.047),(-.045,.050,-.021,.050),(-.014,.064,-.014,.045)],satin)
wheel_station('Lower spoke inlay',[(-.151,.019,-.016,.014),(-.142,.026,-.023,.015),(-.096,.029,-.028,.021),(-.048,.043,-.026,.022)],pad)
for sg in (-1,1):
 # Scooped switch housing bridges rim and airbag at the horizontal spokes.
 verts=[]
 for offset,lower,upper,front,back in [(.056,-.030,.034,-.017,.043),(.092,-.019,.030,-.015,.044),(.127,-.011,.027,-.010,.046),(.153,-.006,.018,-.003,.040)]:
  for y,z in [(lower,front+.004),(lower+.006,front),(upper-.005,front),(upper,front+.006),(upper,back),(lower,back)]:
   verts.append((hub_x+sg*offset,hub_y+y,hub_z+y*.32+z))
 n=6;faces=[tuple(range(5,-1,-1)),tuple(range(18,24))]+[(k*n+i,k*n+(i+1)%n,(k+1)*n+(i+1)%n,(k+1)*n+i) for k in range(3) for i in range(n)]
 o=faced('Steering switch housing','Cabin',verts,faces,trim,.003)
 cylinder_between('Steering scroll wheel','Cabin',[hub_x+sg*.106,hub_y+.010,hub_z-.012],[hub_x+sg*.119,hub_y+.010,hub_z-.012],.0073,cabin,20)
 for x in np.linspace(.108,.118,6):cylinder_between('Scroll knurl','Cabin',[hub_x+sg*x,hub_y+.0098,hub_z-.0123],[hub_x+sg*(x+.0008),hub_y+.0098,hub_z-.0123],.00745,stitch,12)
cylinder_between('Column shroud','Cabin',[hub_x,hub_y-.006,.40],[hub_x,.998,.554],.066,trim)
for sg in (-1,1):
 cylinder_between('Column stalk','Cabin',[hub_x+sg*.048,1.024,.453],[hub_x+sg*.146,1.045,.448],.009,trim,20)
 box('Stalk end','Cabin',[hub_x+sg*.148,1.045,.448],[.040,.015,.020],trim,.007)
# Sweep the pale inner pillar immediately behind the windshield edge.
points=[(.706,1.022,1.088),(.692,1.09,1.005),(.677,1.15,.907),(.664,1.216,.811),(.648,1.274,.717),(.634,1.329,.625),(.62,1.387,.526),(.605,1.45,.39),(.589,1.502,.279),(.578,1.528,.198)]
for sg in (-1,1):
 n=12;verts=[]
 for x,y,z in points:
  for k in range(n):
   a=math.tau*k/n
   verts.append((sg*(x+.012+.030*np.cos(a)),y-.023,z-.064+.071*np.sin(a)))
 faces=[tuple(range(n-1,-1,-1)),tuple(range((len(points)-1)*n,len(points)*n))]+[(j*n+k,j*n+(k+1)%n,(j+1)*n+(k+1)%n,(j+1)*n+k) for j in range(len(points)-1) for k in range(n)]
 ob=faced('A-pillar fabric trim','Cabin',verts,faces,headliner,.003)
 for f in ob.data.polygons:f.use_smooth=True
# Console with two connected cup recesses, a sliding cover and charging shelf.
box('Console upper surround','Cabin',[0,.606,.085],[.324,.109,.658],cabin,.040,-.09)
box('Console sliding cover','Cabin',[0,.667,.196],[.269,.014,.219],stitch,.014,-.09)
box('Sliding cover grip','Cabin',[0,.681,.086],[.190,.005,.008],satin,.002)
for sg in (-1,1):
 pipe('Console satin rail','Cabin',[[sg*.146,.64,-.105],[sg*.154,.66,.102],[sg*.151,.682,.291],[sg*.127,.739,.391]],.0032,satin)
for sg in (-1,1):
 x=sg*.046;z=-.003;y=.660;n=42;verts=[]
 for r,h in [(.046,.007),(.042,.010),(.037,.005),(.034,-.012)]:
  for k in range(n):
   a=math.tau*k/n;verts.append((x+r*np.cos(a),y+h,z+r*1.12*np.sin(a)))
 faces=[tuple(range(n*3,n*4))]+[(j*n+k,j*n+(k+1)%n,(j+1)*n+(k+1)%n,(j+1)*n+k) for j in range(3) for k in range(n)]
 ob=faced('Cup recess','Cabin',verts,faces,trim)
 for f in ob.data.polygons:f.use_smooth=True
for sg in (-1,1):
 box('Charging mat','Cabin',[sg*.070,.721,.374],[.130,.010,.176],pad,.008,-.56)
