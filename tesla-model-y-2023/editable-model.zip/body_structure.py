"""Inner door rings, floor and shock towers aligned with the exterior panel openings."""
ecoat=mat('Body inner e-coat',(.058,.078,.098),.44,.39)
def rail(label,stations,material):
 verts=[];faces=[]
 for x,y,z,w,h in stations:
  for a,b in [(-.8,-1),(.8,-1),(1,-.63),(1,.69),(.77,1),(-.73,1),(-1,.67),(-1,-.63)]:
   verts.append([x+w*a,y+h*b,z])
 n=8
 for k in range(len(stations)-1):
  for j in range(n):faces.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
 faces.extend([tuple(range(n-1,-1,-1)),tuple(range(len(verts)-n,len(verts)))])
 return faced(label,'Body',verts,faces,material,.004)
def column(label,stations,sg):
 vs=[]
 for x,y,z,w,d in stations:
  for dx,dz in [(-1,-.8),(-.68,-1),(.72,-1),(1,-.58),(1,.68),(.67,1),(-.74,1),(-1,.64)]:
   vs.append([sg*(x+dx*w),y,z+dz*d])
 n=8;ff=[(k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j) for k in range(len(stations)-1) for j in range(n)]
 ff.extend([tuple(range(n-1,-1,-1)),tuple(range(len(vs)-n,len(vs)))])
 return faced(label,'Body',vs,ff,ecoat,.004)
for sg in (-1,1):
 rail('Inner rocker pressing',[(sg*x,y,z,w,h) for x,y,z,w,h in [(.68,.33,-1.39,.05,.055),(.78,.275,-1.06,.052,.073),(.792,.272,-.7,.047,.072),(.794,.269,.5,.05,.073),(.783,.28,.98,.055,.072),(.69,.34,1.26,.05,.051)]],ecoat)
 column('Lower A pillar and hinge reinforcement',[(.758,.28,.918,.048,.084),(.797,.62,.918,.035,.059),(.775,.90,.90,.034,.058),(.70,1.033,1.005,.028,.051)],sg)
 column('B pillar high-strength reinforcement',[(.782,.29,-.282,.045,.071),(.788,.66,-.30,.034,.055),(.79,1.032,-.302,.024,.041),(.733,1.265,-.322,.022,.032),(.603,1.533,-.343,.018,.037)],sg)
 column('Rear wheelhouse pillar',[(.72,.29,-1.31,.054,.084),(.779,.64,-1.34,.061,.092),(.759,.89,-1.40,.043,.077),(.697,1.13,-1.52,.040,.081),(.604,1.36,-1.49,.023,.076)],sg)
 for row,z0 in [('Front',1.445),('Rear',-1.445)]:
  x=sg*(.56 if row=='Front' else .59);y=.797 if row=='Front' else .731;z=z0-(.06 if row=='Front' else .16)
  # Domed top and a flared stamping surround the damper mount.
  n=44;rings=[]
  for rx,rz,dy in [(.13,.149,-.121),(.100,.127,-.049),(.075,.080,-.014),(.051,.050,0),(.026,.026,0)]:
   rings.append([[x+rx*math.cos(t),y+dy,z+rz*math.sin(t)] for t in np.linspace(0,math.tau,n,endpoint=False)])
  flat_ring(row+' damper tower','Body',rings,ecoat)
  for t in np.linspace(.12,math.tau+.12,3,endpoint=False):
   xx=x+.054*math.cos(t);zz=z+.054*math.sin(t);cylinder_between('Top mount stud','Body',[xx,y-.010,zz],[xx,y+.002,zz],.0055,metal,12)
 for row,z0 in [('Front',1.45),('Rear',-1.45)]:
  rail(row+' inner longitudinal',[(sg*x,y,z0+dz,w,h) for x,y,dz,w,h in [(.58,.399,-.57,.052,.05),(.58,.402,-.27,.049,.047),(.57,.403,.11,.047,.044),(.531,.44,.50,.051,.047)]],ecoat)
pan=[(-.748,.95),(-.67,1.15),(.67,1.15),(.748,.95),(.751,-.95),(.622,-1.13),(-.622,-1.13),(-.751,-.95)]
extrusion('Cabin floor stamping','Body',pan,.304,.017,ecoat,.007)
for z in (-.64,-.31,.18,.66):
 box('Floor cross reinforcement','Body',[0,.329,z],[1.46,.024,.070],ecoat,.011)
for z,y,width in [(1.98,.466,1.37),(-2.07,.514,1.41)]:
 box('Bumper impact beam','Body',[0,y,z],[width,.091,.055],ecoat,.015)
