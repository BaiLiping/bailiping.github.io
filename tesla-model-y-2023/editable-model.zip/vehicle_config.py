"""Single-source parametric configuration for the 2023 Tesla Model Y master build.
Change PAINT_CODE or WHEEL_PACKAGE here when Phase 3b locks the final 360° studio set.
"""

PAINT_CODE = "PPSB"
WHEEL_PACKAGE = "gemini19"  # 'gemini19' (modular hook ready for 'induction20' if needed)

PAINT_PRESETS = {
    "PPSB": {
        "name": "Mat_Deep_Blue_Metallic_PPSB",
        "label": "Deep Blue Metallic",
        "rgb": (0.009, 0.058, 0.225),
        "metallic": 0.62,
        "roughness": 0.22,
        "coat": 0.78,
        "coat_roughness": 0.06,
    },
    "PPSW": {
        "name": "Mat_Body_Paint_PPSW",
        "label": "Pearl White Multi-Coat",
        "rgb": (0.80, 0.81, 0.82),
        "metallic": 0.14,
        "roughness": 0.20,
        "coat": 0.85,
        "coat_roughness": 0.05,
    },
    "PMNG": {
        "name": "Mat_Body_Paint_PMNG",
        "label": "Midnight Silver Metallic",
        "rgb": (0.115, 0.125, 0.138),
        "metallic": 0.74,
        "roughness": 0.23,
        "coat": 0.78,
        "coat_roughness": 0.06,
    },
    "PBSB": {
        "name": "Mat_Body_Paint_PBSB",
        "label": "Solid Black",
        "rgb": (0.008, 0.009, 0.011),
        "metallic": 0.12,
        "roughness": 0.18,
        "coat": 0.88,
        "coat_roughness": 0.05,
    },
    "PPMR": {
        "name": "Mat_Body_Paint_PPMR",
        "label": "Red Multi-Coat",
        "rgb": (0.42, 0.012, 0.018),
        "metallic": 0.52,
        "roughness": 0.21,
        "coat": 0.85,
        "coat_roughness": 0.05,
    },
    "PN00": {
        "name": "Mat_Body_Paint_PN00",
        "label": "Quicksilver",
        "rgb": (0.38, 0.40, 0.42),
        "metallic": 0.84,
        "roughness": 0.21,
        "coat": 0.82,
        "coat_roughness": 0.05,
    },
    "PR01": {
        "name": "Mat_Body_Paint_PR01",
        "label": "Ultra Red",
        "rgb": (0.31, 0.009, 0.014),
        "metallic": 0.62,
        "roughness": 0.20,
        "coat": 0.86,
        "coat_roughness": 0.05,
    },
}

# Official 2023 Tesla Model Y Long Range AWD (US 5-seat) targets in metres
SPECS_M = {
    "length": 4.751,
    "body_width": 1.921,
    "mirror_width": 2.129,
    "height": 1.624,
    "wheelbase": 2.890,
    "track": 1.636,
    "ground_clearance": 0.172,
    "tire_od_19": 0.7121,
}
