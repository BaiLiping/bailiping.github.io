"""Preserve the replaceable components within a complete wheel, brake or electric drive."""
def nest(parent,suffix,objects):
 if not objects:raise ValueError(parent+suffix)
 root=groups[parent][0];child=bpy.data.objects.new(parent+suffix,None);bpy.context.collection.objects.link(child);child.parent=root
 child.empty_display_size=.025
 for obj in objects:
  # Both empties have identical axes and origin in the assembled pose.
  obj.parent=child
for row in ('Front','Rear'):
 for side in ('Left','Right'):
  name='Wheel'+row+side;items=list(groups[name][0].children)
  tire=[o for o in items if o.name.startswith('Molded tire size') or o.data.materials[0].name in (rubber,'Molded sidewall','Tread grooves')]
  nest(name,'Tire',tire);nest(name,'Alloy',[o for o in items if o not in tire])
  name='Brake'+row+side;items=list(groups[name][0].children)
  caliper=[o for o in items if o.data.materials[0].name==alloy]
  nest(name,'Caliper',caliper);nest(name,'Rotor',[o for o in items if o not in caliper])
for g in ('FrontDrive','RearDrive'):
 batches=defaultdict(list)
 for o in groups[g][0].children:
  n=o.name
  if n.startswith(('Halfshaft','Inner CV joint','Outer CV boot','Output flange')):
   # Location is relative to the centered drive-unit datum.
   label='ShaftLeft' if o.location.x>0 else 'ShaftRight'
  elif n.startswith(('Electric motor casing','Motor shell rib')):label='Motor'
  elif n.startswith(('Inverter','High voltage inlet','Diagonal web','Cover bolt')):label='Inverter'
  elif n.startswith(('Coolant','Plate exchanger','Exchanger')):label='Cooler'
  else:label='Reduction'
  batches[label].append(o)
 for label,items in batches.items():nest(g,label,items)
