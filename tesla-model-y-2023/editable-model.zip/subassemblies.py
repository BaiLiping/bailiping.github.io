"""Preserve replaceable component groups in the 1:1m editable Blender master."""
def nest(parent, suffix, objects):
    if not objects:
        return
    root = groups[parent][0]
    child = bpy.data.objects.new(parent + suffix, None)
    bpy.context.collection.objects.link(child)
    child.parent = root
    child.empty_display_size = 0.025
    for obj in objects:
        obj.parent = child

for row in ("Front", "Rear"):
    for side in ("Left", "Right"):
        name = "Wheel" + row + side
        items = list(groups[name][0].children)
        tire = [o for o in items if o.name.startswith("Molded tire size") or (o.type == "MESH" and o.data.materials and o.data.materials[0].name in (rubber, "Molded sidewall", "Tread grooves"))]
        nest(name, "Tire", tire)
        nest(name, "Alloy", [o for o in items if o not in tire])
        name = "Brake" + row + side
        items = list(groups[name][0].children)
        caliper = [o for o in items if o.type == "MESH" and o.data.materials and o.data.materials[0].name == alloy]
        nest(name, "Caliper", caliper)
        nest(name, "Rotor", [o for o in items if o not in caliper])

for g in ("FrontDrive", "RearDrive"):
    batches = defaultdict(list)
    for o in list(groups[g][0].children):
        n = o.name
        if n.startswith(("Halfshaft", "Inner CV joint", "Outer CV boot", "Output flange")):
            label = "ShaftLeft" if o.location.x > 0 else "ShaftRight"
        elif n.startswith(("Drive_Case_",)):
            label = "Case"
        elif n.startswith(("Inverter_Cover",)):
            label = "InverterCover"
        elif n.startswith(("Inverter_", "Busbar_", "High voltage inlet")):
            label = "Inverter"
        elif n.startswith(("Stator_Core",)):
            label = "Stator"
        elif n.startswith(("Rotor_Core",)):
            label = "Rotor"
        elif n.startswith(("Pinion_", "Reduction_Gear_")):
            label = "ReductionGears"
        elif n.startswith(("Diff_Gear_",)):
            label = "DiffGears"
        elif n.startswith(("Coolant", "Plate exchanger", "Exchanger")):
            label = "Cooler"
        elif n.startswith(("Electric motor", "Motor_Lower")):
            label = "MotorLower"
        else:
            label = "ReductionLower"
        batches[label].append(o)
    for label, items in batches.items():
        nest(g, label, items)
