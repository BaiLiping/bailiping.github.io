"""Modular wheel & tyre builder for the 2023 Tesla Model Y.
Supports 19 x 9.5 Gemini wheel with flush removable aero cover (255/45R19 road tire),
with clean package hook for Phase 3b if 20" Induction is selected.
"""
from vehicle_config import WHEEL_PACKAGE


def generate_gemini19(row, side, sg):
    key = row + side
    wg = "Wheel" + key
    cg = "Cover" + key
    hub = groups[wg][1]
    rim_lip = False

    def polar(radius, angle, depth):
        if rim_lip:
            radius += 0.015 * min(1.0, max(0.0, (radius - 0.13) / 0.109))
            depth += 0.006
        return hub + np.array([sg * depth, radius * math.cos(angle), -sg * radius * math.sin(angle)])

    def cover_point(radius, angle, depth):
        # The hub sits back inside the sidewall. The outer vanes return to
        # the flange so their silver faces remain in front of the alloy rim.
        offset = np.interp(radius, [0.055, 0.107, 0.151, 0.190, 0.222],
                           [-0.027, -0.018, -0.009, -0.004, 0.0])
        return polar(radius, angle, depth + offset)

    def strip(group_name, material, verts, rows, cols, wrap=False):
        faces = []
        for i in range(rows - 1):
            for j in range(cols if wrap else cols - 1):
                a = i * cols + j
                b = i * cols + (j + 1) % cols
                faces.extend([(a, b, b + cols), (a, b + cols, a + cols)])
        patch(group_name, material, verts, faces)

    def lathe(g, m, profile, n=76):
        point = cover_point if g == cg else polar
        verts = [point(r, math.tau * i / n, x) for r, x in profile for i in range(n)]
        strip(g, m, verts, len(profile), n, True)

    # 255/45R19 tire: 712.1 mm OD, 255 mm nominal section width (±0.1275 m).
    # Clean quad lathe (76 x 49) gives razor-round wheels without post-decimation artifacts.
    shoulder = [
        (0.242, 0.099), (0.251, 0.106), (0.263, 0.116), (0.279, 0.1245),
        (0.303, 0.1275), (0.323, 0.1235), (0.339, 0.1145), (0.349, 0.101), (0.354, 0.088),
    ]
    surface = []
    for x in np.linspace(0.084, -0.084, 49):
        groove = sum(0.0065 * math.exp(-((x - center) / 0.0033) ** 4) for center in [-0.063, -0.022, 0.022, 0.063])
        surface.append((0.35595 - 0.0019 * (x / 0.084) ** 2 - groove, x))
    lathe(wg, rubber, shoulder + surface + [(r, -x) for r, x in reversed(shoulder)] + [(0.240, -0.082), (0.240, 0.082), shoulder[0]], 76)

    sidewall = materials.get("Molded sidewall").name if "Molded sidewall" in materials else mat("Molded sidewall", (0.021, 0.023, 0.025), 0.01, 0.68)
    for s in (-1, 1):
        for r, x in [(0.251, 0.116), (0.268, 0.1225), (0.307, 0.1275), (0.323, 0.1235)]:
            lathe(wg, sidewall, [(r - 0.0007, s * x), (r, s * (x + 0.0007)), (r + 0.0007, s * x)], 64)

    grooves = materials.get("Tread grooves").name if "Tread grooves" in materials else mat("Tread grooves", (0.006, 0.007, 0.008), 0, 0.87)
    for k in range(48):
        theta = k * math.tau / 48
        for s in (-1, 1):
            verts = []
            for x, r, a in [(0.115, 0.338, 0.017), (0.107, 0.346, 0.014), (0.092, 0.353, 0.009), (0.065, 0.3555, 0), (0.053, 0.3556, -0.012)]:
                for da in (-0.0032, 0.0032):
                    verts.append(polar(r + 0.00045, theta + s * a + da, s * x))
            strip(wg, grooves, verts, 5, 2)

    rim_lip = True
    # 19x9.5 alloy barrel and bead seats behind the removable Gemini wheel cover
    lathe(
        wg, alloy,
        [
            (0.209, -0.105), (0.224, -0.114), (0.239, -0.120), (0.245, -0.119),
            (0.245, -0.106), (0.236, -0.103), (0.229, -0.056), (0.217, -0.036),
            (0.217, 0.028), (0.229, 0.064), (0.238, 0.093), (0.245, 0.098),
            (0.246, 0.100), (0.241, 0.105), (0.232, 0.100), (0.209, 0.088),
        ],
        96,
    )
    lathe(wg, alloy, [(0.036, 0.064), (0.058, 0.071), (0.075, 0.064), (0.098, 0.044), (0.088, 0.028), (0.036, 0.032), (0.036, 0.064)], 64)

    # The two branches sit behind the silver blade and its graphite insert.
    for k in range(7):
        phi = math.tau * k / 7 + math.radians(15)
        for side_branch in (-1, 1):
            verts = []
            for radius, sweep, half, depth in [
                (0.060, 0, 0.150, 0.066), (0.087, 0.024, 0.132, 0.060),
                (0.120, 0.069, 0.089, 0.052), (0.170, 0.122, 0.051, 0.062),
                (0.221, 0.173, 0.048, 0.088), (0.238, 0.188, 0.048, 0.095),
            ]:
                for delta, dx in [(-half, -0.012), (-half * 0.73, -0.001), (0, 0.001), (half * 0.78, -0.002), (half, -0.013), (half * 0.76, -0.025), (-half * 0.78, -0.025)]:
                    verts.append(polar(radius, phi + side_branch * sweep + delta, depth + dx))
            strip(wg, alloy, verts, 6, 7, True)

    # Five recessed mounting holes and hexagonal lug nuts on a 114.3 mm bolt circle
    for i in range(5):
        phi = math.tau * i / 5
        for material, stations, steps in [(trim, [(0.014, 0.071), (0.010, 0.063)], 16), (lugmetal, [(0.0087, 0.067), (0.0097, 0.070), (0.0097, 0.082), (0.008, 0.084), (0.001, 0.084)], 6)]:
            v = []
            for rad, x in stations:
                for j in range(steps):
                    a = math.tau * j / steps
                    v.append(polar(0.05715, phi, x) + np.array([0, rad * math.cos(a), rad * math.sin(a)]))
            strip(wg, material, v, len(stations), steps, True)

    # Silver retaining ring and central button on the removable cover.
    lathe(cg, coverDark, [(0.206, 0.108), (0.237, 0.113), (0.242, 0.113), (0.243, 0.111), (0.241, 0.107), (0.206, 0.104)], 96)
    lathe(cg, cover, [(0.239, 0.115), (0.240, 0.1165), (0.241, 0.1145), (0.241, 0.112)], 96)
    lathe(cg, cover, [(0.025, 0.136), (0.029, 0.139), (0.032, 0.1415), (0.040, 0.140), (0.049, 0.134), (0.058, 0.132)], 64)

    for k in range(7):
        phi = math.tau * k / 7
        silver = [
            (0.041, 22, 76, 0.136, 0.141),
            (0.052, 21, 70, 0.134, 0.143),
            (0.072, 19, 54, 0.128, 0.139),
            (0.102, 16, 37, 0.120, 0.133),
            (0.140, 12, 33, 0.112, 0.129),
            (0.191, 9, 35, 0.110, 0.124),
            (0.239, 6, 36, 0.114, 0.118),
        ]
        verts = []
        for radius, left, right, edge, ridge in silver:
            for u, depth in [(0, edge - 0.005), (0.035, edge), (0.12, edge + 0.002), (0.55, ridge), (0.87, ridge - 0.001), (0.975, edge + 0.002), (1, edge - 0.003)]:
                verts.append(cover_point(radius, phi + math.radians(left + (right - left) * u), depth))
        strip(cg, cover, verts, len(silver), 7)

        dark = [
            (0.054, 0, 22, 0.135, 0.135),
            (0.074, -2, 19, 0.127, 0.130),
            (0.107, -3, 16, 0.117, 0.126),
            (0.151, -3, 12, 0.112, 0.121),
            (0.190, -3, 9, 0.110, 0.118),
            (0.239, -3, 6, 0.112, 0.115),
        ]
        verts = []
        for radius, left, right, edge, ridge in dark:
            for u, x in [(0, edge - 0.005), (0.065, edge + 0.001), (0.5, ridge), (0.92, ridge), (1, edge - 0.002)]:
                verts.append(cover_point(radius, phi + math.radians(left + (right - left) * u), x))
        strip(cg, coverDark, verts, len(dark), 5)

        for stations, edge in [(silver, 2), (dark, 1)]:
            verts = []
            for r, l, h, d, ridge in stations:
                a = phi + math.radians(h if edge == 2 else l)
                verts.extend([cover_point(r, a, d - 0.003), cover_point(r, a, d - 0.013)])
            strip(cg, coverDark, verts, len(stations), 2)

    lathe(cg, trim, [(0.023, 0.140), (0.026, 0.141), (0.027, 0.139)], 48)
    lathe(cg, cover, [(0.0001, 0.1425), (0.017, 0.1425), (0.023, 0.142), (0.025, 0.140)], 48)

    # Place the emblem on the central button using the same seating profile.
    button_center = cover_point(0.0, 0.0, 0.1428)
    for shape in [
        [(-0.011, 0.004), (-0.006, 0.0065), (0, 0.007), (0.006, 0.0065), (0.011, 0.004), (0.008, 0.003), (0, 0.005), (-0.008, 0.003)],
        [(-0.008, 0.002), (0, 0.004), (0.008, 0.002), (0.002, 0.0005), (0, -0.010), (-0.002, 0.0005)],
    ]:
        vv = [button_center + np.array([0, y, -sg * x]) for x, y in shape]
        patch(cg, coverDark, vv, [(0, j, j + 1) for j in range(1, len(vv) - 1)])

    # Valve stem inside alloy rim
    phi = math.radians(143)
    vv = []
    for r, x in [(0.004, 0.088), (0.004, 0.104), (0.005, 0.106), (0.005, 0.111)]:
        for j in range(10):
            a = math.tau * j / 10
            vv.append(polar(0.205, phi, x) + np.array([0, r * math.cos(a), r * math.sin(a)]))
    strip(wg, trim, vv, 4, 10, True)


def build_wheels(package=WHEEL_PACKAGE):
    if package == "gemini19":
        for row in ("Front", "Rear"):
            for side, sg in [("Left", 1), ("Right", -1)]:
                generate_gemini19(row, side, sg)
    else:
        raise ValueError(f"Unknown wheel package: {package}")


build_wheels()
