"""19 × 9.5 Gemini wheel, removable aero cover and 255/45R19 road tire.
Radii of the vanes and recessed pockets are traced from Tesla's silver cover close-up.
"""
def generate_wheel(row,side,sg):
 key=row+side;wg='Wheel'+key;cg='Cover'+key;hub=groups[wg][1]
 rim_lip=False
 def polar(radius,angle,depth):
  if rim_lip:
   radius+=.015*min(1,max(0,(radius-.13)/.109));depth+=.006
  return hub+np.array([sg*depth,radius*math.cos(angle),-sg*radius*math.sin(angle)])
 def strip(group_name,material,verts,rows,cols,wrap=False):
  faces=[]
  for i in range(rows-1):
   for j in range(cols if wrap else cols-1):
    a=i*cols+j;b=i*cols+(j+1)%cols;faces.extend([(a,b,b+cols),(a,b+cols,a+cols)])
  patch(group_name,material,verts,faces)
 def lathe(g,m,profile,n=144):
  verts=[polar(r,math.tau*i/n,x) for r,x in profile for i in range(n)]
  strip(g,m,verts,len(profile),n,True)
 # Round beads, sidewall bulge, shoulder and four grooves in the crown.
 shoulder=[(.242,.099),(.251,.106),(.263,.116),(.279,.125),(.303,.128),(.323,.124),(.339,.115),(.349,.101),(.354,.088)]
 surface=[]
 for x in np.linspace(.084,-.084,131):
  groove=sum(.0065*math.exp(-((x-center)/.0033)**4) for center in [-.063,-.022,.022,.063])
  surface.append((.35595-.0019*(x/.084)**2-groove,x))
 lathe(wg,rubber,shoulder+surface+[(r,-x) for r,x in reversed(shoulder)]+[(.240,-.082),(.240,.082),shoulder[0]],192)
 sidewall=materials.get('Molded sidewall').name if 'Molded sidewall' in materials else mat('Molded sidewall',(.021,.023,.025),.01,.68)
 for s in (-1,1):
  for r,x in [(.251,.116),(.268,.123),(.307,.128),(.323,.124)]:
   lathe(wg,sidewall,[(r-.0007,s*x),(r,s*(x+.0007)),(r+.0007,s*x)],164)
 # Narrow oblique grooves continue across the outer shoulders into the main channels.
 grooves=materials.get('Tread grooves').name if 'Tread grooves' in materials else mat('Tread grooves',(.006,.007,.008),0,.87)
 for k in range(92):
  theta=k*math.tau/92
  for s in (-1,1):
   verts=[]
   for x,r,a in [(.116,.338,.017),(.108,.346,.014),(.092,.353,.009),(.065,.3555,0),(.053,.3556,-.012)]:
    for da in (-.0029,.0029):verts.append(polar(r+.00045,theta+s*a+da,s*x))
   strip(wg,grooves,verts,5,2)
 rim_lip=True
 # Alloy barrel and bead seats behind the removable plastic wheel cover.
 lathe(wg,alloy,[(.209,-.105),(.224,-.114),(.239,-.120),(.245,-.119),(.245,-.106),(.236,-.103),(.229,-.056),(.217,-.036),(.217,.028),(.229,.064),(.238,.093),(.245,.100),(.246,.109),(.241,.114),(.232,.106),(.209,.09)],144)
 lathe(wg,alloy,[(.036,.070),(.058,.077),(.075,.070),(.098,.048),(.088,.031),(.036,.035),(.036,.070)])
 # Seven paired spoke branches carry loads from the bolt circle into the rim.
 for k in range(7):
  phi=math.tau*k/7
  for side_branch in (-1,1):
   verts=[]
   for radius,sweep,half,depth in [(.060,0,.150,.072),(.087,.024,.132,.066),(.12,.069,.089,.056),(.17,.122,.051,.067),(.221,.173,.048,.094),(.238,.188,.048,.101)]:
    for delta,dx in [(-half,-.012),(-half*.73,-.001),(0,.001),(half*.78,-.002),(half,-.013),(half*.76,-.026),(-half*.78,-.026)]:
     verts.append(polar(radius,phi+side_branch*sweep+delta,depth+dx))
   strip(wg,alloy,verts,6,7,True)
 # Five recessed mounting holes and hexagonal lug nuts on a 114.3 mm circle.
 for i in range(5):
  phi=math.tau*i/5
  for material,stations,steps in [(trim,[(.014,.077),(.010,.069)],24),(lugmetal,[(.0087,.073),(.0097,.076),(.0097,.088),(.008,.090),(.001,.090)],6)]:
   v=[]
   for rad,x in stations:
    for j in range(steps):
     a=math.tau*j/steps
     v.append(polar(.05715,phi,x)+np.array([0,rad*math.cos(a),rad*math.sin(a)]))
   strip(wg,material,v,len(stations),steps,True)
 # The narrow outside lip, deep black pockets, and two flanks of each swept silver vane.
 lathe(cg,coverDark,[(.222,.108),(.237,.113),(.242,.113),(.243,.111),(.241,.107),(.226,.104)])
 lathe(cg,cover,[(.235,.115),(.239,.1165),(.241,.1145),(.241,.112)])
 lathe(cg,cover,[(.025,.1385),(.029,.142),(.032,.145),(.040,.143),(.049,.137),(.058,.135)])
 # Each radial station has its own twist, width, crown and depth into the wheel.
 for k in range(7):
  phi=math.tau*k/7
  silver=[(.041,22,76,.140,.146),(.052,21,70,.138,.149),(.072,19,58,.131,.144),(.102,13,43,.121,.137),(.140,10,32,.111,.133),(.191,9,32,.108,.126),(.235,8,34,.113,.118)]
  verts=[]
  for radius,left,right,edge,ridge in silver:
   for u,depth in [(0,edge-.005),(.035,edge),(.12,edge+.002),(.55,ridge),(.87,ridge-.001),(.975,edge+.002),(1,edge-.003)]:
    verts.append(polar(radius,phi+math.radians(left+(right-left)*u),depth))
  strip(cg,cover,verts,len(silver),7)
  dark=[(.054,0,22,.139,.139),(.074,-2,19,.130,.134),(.107,-3,13,.118,.129),(.151,-3,10,.112,.123),(.190,-3,9,.109,.119),(.235,-3,8,.111,.115)]
  verts=[]
  for radius,left,right,edge,ridge in dark:
   for u,x in [(0,edge-.005),(.065,edge+.001),(.5,ridge),(.92,ridge),(1,edge-.002)]:
    verts.append(polar(radius,phi+math.radians(left+(right-left)*u),x))
  strip(cg,coverDark,verts,len(dark),5)
  # Return down the rim of the open slot; the alloy and rotor show through it.
  for stations,edge in [(silver,2),(dark,1)]:
   verts=[]
   for r,l,h,d,ridge in stations:
    a=phi+math.radians(h if edge==2 else l)
    verts.extend([polar(r,a,d-.003),polar(r,a,d-.014)])
   strip(cg,coverDark,verts,len(stations),2)
 lathe(cg,trim,[(.023,.143),(.026,.144),(.027,.142)])
 lathe(cg,cover,[(.0001,.146),(.017,.146),(.023,.1455),(.025,.143)])
 # Raised T on the center button, and a valve stem in a pocket of the outer rim.
 for shape in [[(-.011,.004),(-.006,.0065),(0,.007),(.006,.0065),(.011,.004),(.008,.003),(0,.005),(-.008,.003)],[(-.008,.002),(0,.004),(.008,.002),(.002,.0005),(0,-.010),(-.002,.0005)]]:
  vv=[hub+np.array([sg*.1528,y,-sg*x]) for x,y in shape];patch(cg,coverDark,vv,[(0,j,j+1) for j in range(1,len(vv)-1)])
 phi=math.radians(143)
 vv=[]
 for r,x in [(.004,.093),(.004,.111),(.005,.113),(.005,.119)]:
  for j in range(12):
   a=math.tau*j/12;vv.append(polar(.205,phi,x)+np.array([0,r*math.cos(a),r*math.sin(a)]))
 strip(wg,trim,vv,4,12,True)
for row in ('Front','Rear'):
 for side,sg in [('Left',1),('Right',-1)]:generate_wheel(row,side,sg)
