"""Five-seat upholstery from the front and rear seat portraits of the 2023 car."""
seatleather=mat('Black seat upholstery',(.029,.031,.034),.01,.51)
insert=mat('Seat center upholstery',(.034,.037,.040),.01,.58)
piping=mat('Inset seam shadow',(.012,.013,.014),0,.68)
def seatmesh(label,g,verts,faces,material):
 obj=faced(label,g,verts,faces,material)
 for poly in obj.data.polygons:poly.use_smooth=True
 return obj
def closed_sweep(label,g,rings,material):
 n=len(rings[0]);verts=np.vstack(rings)
 faces=[tuple(range(n-1,-1,-1)),tuple(range(len(verts)-n,len(verts)))]+[(k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j) for k in range(len(rings)-1) for j in range(n)]
 return seatmesh(label,g,verts,faces,material)
def round_stations(rows,count):
 from scipy.interpolate import PchipInterpolator
 arr=np.array(rows);ys=np.linspace(arr[0,0],arr[-1,0],count)
 return np.c_[ys,PchipInterpolator(arr[:,0],arr[:,1:],axis=0)(ys)]
def backrest(g,xc,width,stations,head,center_panel=True):
 arr=round_stations(stations,47);angles=np.linspace(0,math.tau,84,endpoint=False);rings=[]
 def facepoint(y,normalized):
  ww,z,depth,bol=(np.interp(y,arr[:,0],arr[:,j]) for j in range(1,5))
  x=normalized
  c=np.sqrt(np.maximum(0,1-np.abs(x)**(2/.88)));profile=c**.58
  return np.array([xc+width*ww*x,y,z+depth*profile+bol*np.exp(-((abs(x)-.77)/.17)**2)*c**.38])
 for y,ww,z,d,b in arr:
  ring=[]
  for a in angles:
   sn,co=np.sin(a),np.cos(a);x=np.sign(sn)*abs(sn)**.88
   zz=(facepoint(y,x)[2] if co>=0 else z-d*.81*abs(co)**.69)
   ring.append([xc+ww*width*x,y,zz])
  rings.append(ring)
 closed_sweep('Sculpted backrest and shoulder bolsters',g,rings,seatleather)
 if center_panel:
  ymin=arr[0,0]+.012;ymax=arr[-1,0]-.076;rows=[];edges=[[],[]]
  for t in np.linspace(0,1,39):
   # Rounded upper corners narrow into the shoulder section.
   hw=.53-.21*max(0,(t-.78)/.22)**2-.065*(1-t)**4
   row=[]
   for u in np.linspace(-1,1,27):
    y=ymin+t*(ymax-ymin)-.017*abs(u)**3*t**4
    q=facepoint(y,hw*u);q[2]+=.002+.006*(1-u*u)*np.sin(np.pi*t)
    row.append(q)
   rows.append(row);edges[0].append(row[0]);edges[1].append(row[-1])
  n=len(rows[0]);faces=[(i*n+j,i*n+j+1,(i+1)*n+j+1,(i+1)*n+j) for i in range(len(rows)-1) for j in range(n-1)]
  seatmesh('Stitched backrest insert',g,np.vstack(rows),faces,insert)
  perimeter=edges[0]+list(rows[-1])+edges[1][::-1]
  polyline('Seat insert welt',g,perimeter,.0024,piping)
  mid=rows[19];polyline('Transverse upholstery seam',g,[q+[0,0,.0015] for q in mid],.0016,piping)
 y,z,ww,hh,tilt=head
 for dx in (-ww*.48,ww*.48):cylinder_between('Head restraint post',g,[xc+dx,y-hh-.062,z],[xc+dx,y-hh+.022,z],.0057,metal,20)
 ring=[]
 for t in np.linspace(-1,1,28):
  span=max(.001,(1-abs(t)**3)**.43);cy=y+t*hh
  ring.append([[xc+ww*span*np.sign(np.cos(a))*abs(np.cos(a))**.82,cy,z+tilt*t+.064*span*np.sign(np.sin(a))*abs(np.sin(a))**.79] for a in angles])
 closed_sweep('Padded head restraint',g,ring,seatleather)
 # perimeter seam on the front face of the removable head restraint
 for sg in [-1,1]:
  path=[]
  for t in np.linspace(-.86,.86,20):
   span=(1-abs(t)**3)**.43;path.append([xc+sg*ww*.90*span,y+t*hh,z+tilt*t+.036*span])
  polyline('Head restraint seam',g,path,.0015,piping)

def cushion(g,xc,ww,back,front,y):
 ts=np.linspace(-1,1,50);angles=np.linspace(0,math.tau,76,endpoint=False);rings=[]
 for t in ts:
  z=(front+back)*.5+t*(front-back)*.5
  width=ww*(.905+.095*np.cos(t*math.pi/2))*(1-.115*abs(t)**9)
  ring=[]
  for a in angles:
   sx,sy=np.sin(a),np.cos(a);x=np.sign(sx)*abs(sx)**.75
   height=(.059 if sy>0 else .046)*np.sign(sy)*abs(sy)**.58
   bulge=.034*np.exp(-((abs(x)-.78)/.15)**2)*max(sy,0)**.36
   ring.append([xc+width*x,y+.024*(t+.4)+height+bulge-.019*abs(t)**10,z])
  rings.append(ring)
 closed_sweep('Seat cushion with thigh bolsters',g,rings,seatleather)
 for sg in (-1,1):
  path=[]
  for t in np.linspace(-.82,.92,30):
   z=(front+back)*.5+t*(front-back)*.5;x=xc+sg*ww*(.54+.055*t)
   path.append([x,y+.024*(t+.4)+.055-.019*abs(t)**10,z])
  polyline('Cushion seam',g,path,.0019,piping)
for sg,side in [(1,'Left'),(-1,'Right')]:
 g='FrontSeat'+side;xc=sg*.373
 box('Lower seat valance',g,[xc,.480,-.089],[.476,.139,.481],cabin,.048)
 cushion(g,xc,.258,-.366,.176,.563)
 backrest(g,xc,1,[(.569,.175,-.303,.073,.018),(.612,.218,-.316,.081,.029),(.740,.240,-.339,.067,.061),(.908,.243,-.373,.057,.058),(1.054,.233,-.409,.062,.037),(1.137,.212,-.434,.064,.021),(1.180,.172,-.445,.051,.008),(1.197,.116,-.447,.044,.004)],(1.272,-.466,.104,.102,-.017))
for xc,ww in [(.473,.227),(0,.231),(-.473,.227)]:
 cushion('RearSeat',xc,ww,-1.224,-.650,.525)
 outer=abs(xc)>.1
 if outer:
  backrest('RearSeat',xc,1,[(.556,ww*.87,-1.094,.070,.01),(.639,ww,-1.125,.064,.033),(.831,ww,-1.175,.059,.039),(1.014,ww*.97,-1.228,.054,.028),(1.096,ww*.84,-1.250,.051,.008),(1.114,ww*.59,-1.251,.041,.003)],(1.205,-1.286,.100,.092,-.018))
 else:
  backrest('RearSeat',xc,1,[(.558,.209,-1.096,.062,0),(.645,.228,-1.121,.055,0),(.853,.231,-1.186,.05,0),(1.085,.224,-1.249,.048,0),(1.104,.188,-1.254,.041,0)],(1.142,-1.269,.108,.055,-.009),False)
for x in (-.265,.232,.286):
 box('Rear belt buckle','RearSeat',[x,.588,-1.064],[.039,.025,.047],trim,.008,-.15)
 box('Rear buckle button','RearSeat',[x,.601,-1.060],[.023,.007,.027],rear,.003)
