import struct,numpy as np,json
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from pathlib import Path
import trimesh

scene=trimesh.load(next(Path(__file__).resolve().parent.glob('c0*.glb')),force='scene',process=False)
# Input scene transforms are glTF Y up, nose +Z. Bake these before measuring.
def inputs():
 for node in scene.graph.nodes_geometry:
  mat,mesh=scene.graph[node]; geo=scene.geometry[mesh]
  vs=trimesh.transform_points(geo.vertices,mat)
  yield node, vs, geo.faces

def source_meshes():
 # The split normals in the original glTF preserve the stamped panel highlights.
 for node in scene.graph.nodes_geometry:
  matrix, key = scene.graph[node]
  mesh = scene.geometry[key]
  pos = trimesh.transform_points(mesh.vertices, matrix)
  normals = mesh.vertex_normals @ np.linalg.inv(matrix[:3,:3])
  yield node, pos, mesh.faces, normals

def components(verts,faces):
 _,idx=np.unique(np.round(verts,5),axis=0,return_inverse=True)
 edges=idx[faces[:,[0,1,1,2,2,0]]].reshape(-1,2)
 graph=coo_matrix((np.ones(len(edges),dtype=np.bool_),edges.T),shape=(idx.max()+1,)*2)
 _,groups=connected_components(graph,directed=False)
 return groups[idx][faces[:,0]]
if __name__=='__main__':
 vs=[];fs=[];k=0
 for node,v,f in inputs():
  if node.startswith(('103_body','98_body')):
   vs.append(v);fs.append(f+k);k+=len(v)
 vertices=np.vstack(vs);faces=np.vstack(fs);groups=components(vertices,faces)
 for id,count in sorted(zip(*np.unique(groups,return_counts=True)),key=lambda p:-p[1])[:80]:
  pts=vertices[faces[groups==id].flatten()]
  print(id,count,np.round(pts.min(0),3),np.round(pts.max(0),3))
