from pathlib import Path
import json,math
import cv2,numpy as np
from scipy.optimize import least_squares
ROOT=Path(__file__).resolve().parents[1]
PDF='https://xr793.com/wp-content/uploads/2019/05/2005-Honda-Civic-Coupe.pdf'
CONV=np.array([[1.,0,0],[0,0,1.],[0,-1.,0]])
# Coordinates in metres in the master, picked on the native embedded photographs.
column=np.array([-.316,-.367,.771]);axis=np.array([.831,0,.556]);h=np.array([0,1.,0]);up=np.cross(axis,h)
hub=column+.072*axis+.016*up
anchors={
 'Steering emblem':(hub,[410,290],3.), 'Left instrument dial':([-.604,-.469,.809],[231,273],1.),'Centre speedometer':([-.604,-.377,.809],[271,244],1.3),'Right instrument dial':([-.604,-.276,.809],[318,230],.8),
 'Gear knob':([-.245,0,.548],[551,315],2.2),'Shifter bellows':([-.251,0,.421],[555,375],1.6),
 'Passenger door latch':([-.149,.723,.780],[733,121],1.),'Passenger window switch':([-.103,.704,.614],[746,187],.7),
 'Passenger vent':([-.412,.622,.792],[621,123],1.3),'Driver vent':([-.397,-.635,.843],[202,316],1.6),
 'Centre vents':([-.480,.002,.866],[442,162],1.),'Audio unit display':([-.446,.035,.811],[472,194],.8)}
# Eight physically visible points on the circumference, sampled as a perspective conic.
rim=np.array([[409,183],[455,202],[487,250],[493,302],[471,362],[438,391],[403,400],[368,391],[332,355],[314,311],[314,271],[324,230],[351,202],[374,187]],float)

def register(key,label,file,page,size,landmarks,start,look,focal,actions,extra=None):
 W,H=size; pts=np.array([v[0] for v in landmarks.values()]);obs=np.array([v[1] for v in landmarks.values()]);weight=np.sqrt([v[2] for v in landmarks.values()])[:,None]
 forward=np.asarray(look)-np.asarray(start);forward=forward/np.linalg.norm(forward);right=np.cross(forward,[0,0,1.]);right/=np.linalg.norm(right);down=np.cross(forward,right);R=np.array([right,down,forward]);x0=np.r_[cv2.Rodrigues(R)[0].ravel(),-R@start,np.log(focal)]
 def proj(x,arr):
    V=arr@cv2.Rodrigues(x[:3])[0].T+x[3:6];return V[:,:2]/V[:,2:]*np.exp(x[6])+[W*.5,H*.5]
 def score(x):
    diff=((proj(x,pts)-obs)*weight).ravel();rest=[]
    if extra:rest.extend(extra(x,proj))
    rest.append((x[6]-np.log(focal))*(100 if key in ('vtec-cover','auction-engine-bay') else 7));return np.r_[diff,rest]
 x=least_squares(score,x0,loss='soft_l1',f_scale=8,max_nfev=400,bounds=([-np.inf]*6+[np.log(940 if key=='auction-engine-bay' else 230)],[np.inf]*6+[np.log(3800)])).x
 mx=cv2.Rodrigues(x[:3])[0];pos=-mx.T@x[3:6];f=np.exp(x[6]);errors=np.linalg.norm(proj(x,pts)-obs,axis=1);i=int(np.argmax(errors));k=list(landmarks)[i];print(key,'position',np.round(pos,3),'focal',round(f),'reprojection',dict(zip(landmarks,np.around(errors,1))));print(dict(zip(landmarks, np.around(proj(x,pts),1).tolist())))
 v=dict(id=key,label=label,position=(CONV@pos).tolist(),target=(CONV@(pos+mx[2]*np.linalg.norm(pos-np.asarray(look)))).tolist(),up=(CONV@-mx[1]).tolist(),fov=math.degrees(2*math.atan(H/(2*f))),imageSize=size,source=PDF+'#page='+str(page),actions=actions)
 r=dict(id=key,label=label,file=file,source=v['source'],original=v['source'],dimensions=size,medianPx=round(float(np.median(errors)),1),worstPx=round(float(errors.max()),1),worstLandmark=k,worstDescription=k.lower(),anchors=dict(zip(landmarks,obs.tolist())))
 return v,r

def rim_resid(x,proj):
 samples=np.array([column+axis*.016+.165*(h*np.cos(t)+up*np.sin(t)) for t in np.linspace(0,2*np.pi,256)]);projected=proj(x,samples);delta=np.linalg.norm(rim[:,None]-projected[None,:],axis=2);
 rimerr=np.min(delta,axis=1)*1.3
 def stroke(points,a,b):
    xy=proj(x,np.asarray(points));a=np.array(a);u=np.array(b)-a;u=u/np.linalg.norm(u);return (xy-a)@np.array([-u[1],u[0]])
 near=stroke([[-.6,-.786,.884],[-.39,-.788,.891],[-.1,-.788,.902]],[0,316],[456,550])
 far=stroke([[-.65,.786,.877],[-.35,.785,.886],[.2,.781,.915]],[652,84],[1049,98]);inner=stroke([[-.6,-.661,.886],[-.39,-.661,.892],[-.1,-.661,.903]],[0,316],[456,550]);return np.r_[rimerr,inner*.6,near*.32,far*.6,(x[6]-np.log(760))*95,((-cv2.Rodrigues(x[:3])[0].T@x[3:6])[1]+1.02)*180]

def engine_bay():
 # Solid strut and latch locations constrain the bay width and its fore-aft depth.
 # Image picks use a 480px-wide preview of the original 2048px-wide photograph.
 size=[2048,1365]
 point={
    'Passenger strut stud':([-1.25437,.575,.744],[66,106],4.),
    'Driver strut stud':([-1.25437,-.575,.744],[398,99],4.),
    'Latch receiver':([-1.803,0,.644],[226,289],4.),
    'Left cover fastener':([-1.425,.016,.751],[226,154],1.3),
    'Right cover fastener':([-1.425,-.240,.751],[324,152],1.3),
    'Outer passenger coil':([-1.513,-.021,.739],[237,183],.8),
    'Outer driver coil':([-1.513,-.285,.739],[336,182],.8),
    'Plenum centre':([-1.235,-.074,.724],[250,105],.7),
    'Passenger shield bolt':([-1.63860,-.04390,.64599],[253.3,216.7],.5),
    'Driver shield bolt':([-1.63860,-.28410,.64599],[314.3,215.9],.5),
    'Passenger fuse lid':([-1.39,.66,.694],[35,152],.5),
    'Air filter lid':([-1.49,.28,.719],[140,175],.5),
    'Battery top centre':([-1.68,.52,.634],[62,240],.5),
    'Brake fluid cap':([-1.18,-.40,.778],[347,81],.5),
    'Washer fluid cap':([-1.51,-.74,.640],[461,187],.5),
    'Steering fluid cap':([-1.55,-.665,.626],[437,199],.5),
 }
 native={k:(world,(np.array(xy)*size[0]/480).tolist(),weight) for k,(world,xy,weight) in point.items()}
 v,r=register('auction-engine-bay','Five-speed EX engine bay · Nexus Auto Brokers','auction-engine-bay',0,size,native,[-1.96,-.05,1.67],[-1.41,0,.68],1410,['Raise hood'])
 r['source']=v['source']='https://bringatrailer.com/listing/2005-honda-civic-10/'
 r['original']='https://bringatrailer.com/wp-content/uploads/2025/09/Civic-32-of-70-78498-scaled.jpg'
 r['sourceLinkOnly']=True;r['status']='limited'
 r['credit']='Engine-bay photograph by Nexus Auto Brokers, via Bring a Trailer. The tracing follows visible edges in the photograph.'
 r['limit']='This 2005 US EX has the 1.7-litre VTEC engine and five-speed transaxle. It was photographed with its hood raised. Hardware hidden beneath the engine, hose routing and component depths remain approximate.'
 r['observation']='The open hood reveals the four coil packs, intake plenum, battery, front manifold heat shield and the tops of both struts. The overlaid tracing shows their installed position in the photographed car.'
 return v,r

def build():
 v,r=register('cockpit-five-speed','Five-speed EX cockpit','brochure-014',8,[1050,550],anchors,[.45,-1.08,1.32],[-.30,0,.73],865,['Lower driver window'],rim_resid);r['limit']='The brochure shows the black EX cabin without the driver’s window glass in the sightline. Instrument graphics, silver bezel contours and seat upholstery remain simplified.'
 engine={
    'Left fastener':([-1.315,.016,.751],[55,39],3.5),'Right fastener':([-1.315,-.240,.751],[424,227],3.5),
    'VTEC lettering centre':([-1.318,-.119,.751],[236,128],4.),'HONDA lettering centre':([-1.293,-.131,.751],[267,91],4.),
    'Right cover corner':([-1.284,-.323,.749],[637,280],.75),
    'Second skirt notch':([-1.352,-.109,.749],[164,159],.65),'Third skirt notch':([-1.352,-.197,.749],[315,227],.65)}
 # The engine assembly sits 110 mm further forward in the full engine-bay fit.
 engine={name:([p[0]-.110,p[1],p[2]],xy,w) for name,(p,xy,w) in engine.items()}
 e,t=register('vtec-cover','D17 VTEC ignition-cover detail','brochure-004',4,[1004,367],engine,[-1.77,-.39,1.02],[-1.44,-.19,.74],920,['Isolate ignition cover']);t['limit']='Honda shows a tight crop of the VTEC cover in studio lighting. Only this exterior cover, fasteners and visible ends of ignition packs can be compared. The image provides no check on the cylinder block, transaxle or internal parts.'
 return [(v,r),(e,t),engine_bay()]

def extend(views,rows,actions):
 actions.append(dict(label='Lower driver window',nodes=[dict(node='DoorLeft_·_Smoke_blue-green_glass',hidden=True)]))
 components=['Body','Interior','DoorLeft','DoorRight','Trunk','Hood','WheelFrontLeft','WheelFrontRight','WheelRearLeft','WheelRearRight']
 components+=['Powertrain_·_'+name for name in ['Brake_casting','Machined_aluminum','Satin_black_trim','Weatherstrips']]
 actions.append(dict(label='Isolate ignition cover',nodes=[dict(node=name,hidden=True) for name in components]))
 for v,r in build():views.append(v);rows.append(r)
if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser(description='Fit the cockpit, ignition-cover and open engine-bay cameras at source image resolution.')
 parser.add_argument('--output',type=Path,default=Path('.'),help='Directory for camera and image-landmark JSON files')
 args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
 result=build()
 (args.output/'detail-cameras.json').write_text(json.dumps([v for v,_ in result],indent=2))
 (args.output/'detail-landmarks.json').write_text(json.dumps([r for _,r in result],indent=2))
