"""Five-speed console shaped from int-05, int-06 and int-10."""
from geometry import *

def build(fascia):
    base=np.array([-.250,0,.399])
    # The dark console sidewalls continue beneath both removable trim panels.
    # Match their meeting edges at the cupholder lid, avoiding an open gap
    # between the sloped trim and the lower shift ring surround.
    joint_x=-.347; joint_z=.410
    def plate_height(x):
        slope=.64 if x<joint_x else .13
        return joint_z+slope*(joint_x-x)
    for name,start,end,slope in [
        ('Shift console surround',-.346,-.143,.13),
        ('Shift cupholder cover',-.476,-.348,.64),
    ]:
        x=(start+end)/2; angle=math.atan(slope)
        box(name,(x,0,plate_height(x)),((end-start)/cos(angle),.202,.012),fascia,cabin,.004,rot=(0,angle,0))
    for side in [-1,1]:
        def skirt(x,t):
            return (x,side*(.102-.006*t),plate_height(x)*(1-t)+.316*t)
        patch('Shift console skirt',skirt,[-.486,joint_x,-.140],span(4),trim,cabin,(0,side,0))
    end_x=-.484; end_z=plate_height(end_x)
    box('Shift accessory panel',(end_x,0,end_z+.033),(.018,.201,.084),dashboard,cabin,.008,rot=(0,-.19,0))
    for y in [-.058,-.004]:
        box('Shift accessory blank',(end_x+.011,y,end_z+.037),(.007,.042,.023),trim,cabin,.003,rot=(0,-.19,0))
    cylinder('Shift 12V outlet rim',(end_x+.007,.059,end_z+.035),(end_x+.014,.059,end_z+.036),.019,rubber,cabin)
    cylinder('Shift 12V socket cap',(end_x+.014,.059,end_z+.036),(end_x+.021,.059,end_z+.037),.014,trim,cabin)
    disk('Shift gaiter silver ring',base,(0,0,1),(1,0,0),[(.074,.001),(.075,.004),(.071,.007),(.066,.007),(.064,.004)],steel,cabin)
    # Gathered conical boot with longitudinal folds tapering to the collar.
    def boot(t,a):
        envelope=(1.-t)**.82
        folds=cos(6*a+.6*t)+.35*cos(11*a-1.3*t)
        radius=.016+.049*envelope+.0047*sin(pi*t)*folds
        return base+np.array([.002*t+radius*cos(a),radius*sin(a),.004+.057*t])
    patch('Shift gathered boot',boot,span(20),np.linspace(0,2*pi,85),rubber,cabin)
    center=np.array([-.248,0,.456])
    disk('Shift silver collar',center,(0,0,1),(1,0,0),[(.016,0),(.017,.002),(.016,.020),(.015,.022)],steel,cabin)
    disk('Shift textured grip',center,(0,0,1),(1,0,0),[(.014,.019),(.016,.021),(.016,.042),(.0185,.065),(.025,.089),(.0255,.101),(.024,.110),(.020,.115)],rubber,cabin)
    disk('Shift pattern inlay',center,(0,0,1),(1,0,0),[(.020,.1148),(.0178,.117),(.00001,.1174)],graphite,cabin)
    # Viewed from the seated driver, forward is -X and left is -Y.
    for i,(top,bottom) in enumerate(zip('135','24R')):
        y=(i-1)*.0082
        for x,digit in [(-.0085,top),(.0085,bottom)]:
            ob=text_label('Shift pattern digit',digit,center+[x,y,.1176],.0051,ivory,(0,0,1),cabin)
            ob.rotation_euler.z+=pi;ob.data.extrude=.00007
        tube('Shift gate pattern',[center+[-.005,y,.1177],center+[.005,y,.1177]],.00031,ivory,cabin)
    tube('Shift gate pattern',[center+[0,-.0082,.1177],center+[0,.0082,.1177]],.00031,ivory,cabin)
