"""Left-hand-drive Civic EX cloth cabin. Seats and switches remain individually editable."""
from shell import *
from finish import badge
# Inner panel and glazing returns remain attached to their hinged assemblies.
for s in (-1,1):
    def inside(u,v):
        x=float(mix(frontdoor(v),backdoor(v),u));p=side(x,v,s);p[1]-=s*(.063+.025*sin(pi*v));p[2]-=.012;return p
    patch('Door card',inside,span(43),span(15),dashboard,doors[s],(0,-s,0))
    for xfun in [frontdoor,backdoor]:
        patch('Door return',lambda t,v:np.array(side(xfun(t),t,s))-[0,s*.070*v,.008*v],span(25),span(7),paint,doors[s])
    patch('Door waist return',lambda u,v:mix(side(float(mix(frontdoor(1),backdoor(1),u)),1,s),inside(u,1),v),span(28),span(4),trim,doors[s],(0,0,1))
    oval('Door armrest',(.028,s*.729,.585),(.32,.059,.038),leather,doors[s],rot=(0,.075,0))
    line('Door card lower insert',[(-.42,s*.738,.65),(-.30,s*.724,.49),(.22,s*.741,.39),(.41,s*.75,.48)],.008,trim,doors[s])
    box('Window control',(-.103,s*.704,.614),(.104,.039,.013),trim,doors[s],.005)
    oval('Door speaker',(-.518,s*.756,.339),(.083,.009,.076),void,doors[s])
    box('Door latch trim',(-.155,s*.739,.78),(.135,.027,.053),void,doors[s],.012)
    box('Inner latch',(-.149,s*.723,.78),(.072,.011,.012),steel,doors[s],.004)
    box('Sill inner',(-.092,s*.718,.235),(1.47,.092,.087),trim,bevel=.032)
# The cushion and reclining backrest have integrated bolsters around cloth centers.
cloth=material('EX woven cloth insert',(.077,.081,.083),0,.94)
for s in (-1,1):
    y=s*.372
    def seat_top(t,k):
        w=.212*(.77+.23*sin(pi*min(1,t/.23)*.5))*(1-.10*t**3)
        x=-.226+.703*t+.091*abs(k)**3*(1-2*t)
        z=.433+.020*cos(pi*t)+.032*abs(k)**3+.043*math.exp(-((abs(k)-.78)/.21)**2)-.052*(max(0,1-t/.17)**2)
        return np.array([x,y+k*w,z])
    patch('Contoured bucket cushion',seat_top,span(45),np.linspace(-1,1,41),leather,cabin,(0,0,1))
    patch('Woven cushion center',lambda t,k:seat_top(t,k)+[0,0,.0013],np.linspace(.016,.978,34),np.linspace(-.58,.58,23),cloth,cabin,(0,0,1))
    for side_ in [-1,1]:
        patch('Seat side skirt',lambda t,v:seat_top(t,side_)+[0,-side_*.019*v,-.116*v],span(34),span(4),leather,cabin)
        line('Squab welt',[seat_top(t,.585*side_)+[0,0,.002] for t in np.linspace(.02,.96,35)],.0019,trim,cabin)
    patch('Front squab roll',lambda k,v:seat_top(0,k)+[.040*(1-cos(v*pi*.5)),0,-.062*sin(v*pi*.5)],np.linspace(-1,1,31),span(5),leather,cabin,(-1,0,0))
    def seat_back(t,k):
        w=.207*(1-.145*t**2)-.014*max(0,t-.85)/.15
        x=.425+.235*t-.041*math.exp(-((abs(k)-.79)/.22)**2)*sin(pi*t)**.42
        return np.array([x,y+k*w,.418+.514*t-.057*abs(k)**3*t**3])
    patch('Contoured front backrest',seat_back,span(39),np.linspace(-1,1,41),leather,cabin,(-1,0,0))
    patch('Woven backrest center',lambda t,k:seat_back(t,k)-[.0014,0,0],np.linspace(.06,.94,35),np.linspace(-.57,.57,26),cloth,cabin,(-1,0,0))
    for side_ in [-1,1]:
        patch('Backrest side casing',lambda t,v:seat_back(t,side_)+[v*.076,-side_*v*.016,-v*.012],span(33),span(8),leather,cabin)
        line('Side bolster seam',[seat_back(t,.574*side_)-[.002,0,0] for t in np.linspace(.055,.94,32)],.0020,trim,cabin)
    patch('Backrest outer shell',lambda t,k:seat_back(t,k)+[.074,0,-.015],span(31),np.linspace(-1,1,25),leather,cabin,(1,0,0))
    patch('Backrest shoulder seam',lambda k,v:seat_back(1,k)+[.074*v,0,-.015*v],np.linspace(-1,1,25),span(6),leather,cabin,(0,0,1))
    for k in [-1,1]:cylinder('Headrest stem',(.670,y+k*.065,.879),(.695,y+k*.065,.989),.007,graphite,cabin)
    oval('Padded head restraint',(.700,y,1.006),(.063,.132,.087),leather,cabin,rot=(0,.18,0))
for s in (-1,1):
    oval('Rear seat cushion',(1.04,s*.340,.418),(.249,.260,.096),leather,cabin)
    oval('Split rear backrest',(1.263,s*.330,.630),(.070,.288,.238),leather,cabin,rot=(0,.29,0))
    tube('Rear backrest seam',[(1.201,s*.322,.48),(1.215,s*.322,.62),(1.252,s*.322,.78)],.002,trim,cabin)

box('Luggage floor',(1.60,0,.344),(.78,1.31,.082),fabric,cabin,.028)
for s in (-1,1):oval('Trunk wheelhouse',(1.39,s*.641,.465),(.38,.139,.180),fabric,cabin)
def cargo_lip(k,t):
    return (1.866-.132*abs(k)**3-.018*sin(pi*t),k*.665,.37+.32*t)
patch('Curved cargo threshold',cargo_lip,np.linspace(-1,1,35),span(13),fabric,cabin,(-1,0,0))
# Dashboard crown, instrument binnacle, central vents and mechanical shifter.
# The continuous fascia returns around the recessed three-dial cluster and bows
# towards the outer vents. Longitudinal ribs define the cowl and face in one shell.
import math
from mathutils import Matrix
face_curve=curve([(-.746,-.48),(-.626,-.444),(-.582,-.503),(-.52,-.646),(-.37,-.652),(-.219,-.641),(-.142,-.524),(0,-.500),(.162,-.503),(.379,-.481),(.616,-.457),(.746,-.472)])
def dash_section(y):
    f=face_curve(y);d=max(0.,1-((y+.372)/.216)**2)**.58
    waist=.895+.055*d-.020*(abs(y)/.746)**2
    top=waist+.006
    return [(-.795,.682),(-.796,.832),(-.755,.862+.009*d),(-.664,.885+.030*d),
        (min(f-.035,-.623),top+.003),(f-.014,waist),(f+.002,waist-.015),
        (f+.014,.826-.02*d),(f+.040,.747-.045*d),(f+.048,.650-.038*d),
        (f+.034,.618),(f-.045,.578),(-.765,.570),(-.795,.682)]
ys=np.linspace(-.746,.746,117);verts=[];faces=[]
for y in ys:verts.extend([(x,y,z) for x,z in dash_section(y)])
n=len(dash_section(0));
for i in range(len(ys)-1):
    for j in range(n-1):
        z=i*n+j;faces.append((z,z+1,z+1+n,z+n))
mesh('Continuous molded dashboard and gauge brow',verts,faces,dashboard,cabin)
# Dark lining underneath the instrument brow and three reflective dial rings.
oval('Cluster surround',(-.632,-.372,.807),(.022,.177,.075),void,cabin)
for off,rad in [(-.092,.051),(.0,.064),(.101,.048)]:
    pos=np.array([-.604,-.377+off,.809]);n=(1,0,.14)
    disk('Instrument silver ring',pos,n,(0,1,0),[(rad,0),(rad*.985,.002),(rad*.946,.002)],steel,cabin)
    disk('Instrument dial',pos,n,(0,1,0),[(rad*.947,0),(rad*.91,.002),(.001,.002)],rubber,cabin)
    for a in np.linspace(-.55,pi*1.19,32):
        tube('Instrument tick',[pos+[.003,rad*.84*cos(a),rad*.84*sin(a)],pos+[.004,rad*.95*cos(a),rad*.95*sin(a)]],.00115,ivory,cabin)
    tube('Gauge needle',[pos+[.005,0,0],pos+[.005,-rad*.74,-rad*.26]],.0022,red,cabin)
# The fascia has tall outer louvres and two horizontal center vents. Controls
# follow the same rearward rake as the real EX stack.
stackmat=material('Satin graphite center stack',(.126,.133,.136),.29,.40)
def plate(name,center,width,height,depth,mat,rake=.27,radius=.007):
    return box(name,center,(depth,width,height),mat,cabin,radius,rot=(0,-rake,0))
def vent(name,center,w,h,rows):
    x,y,z=center;plate(name+' rim',center,w,h,.015,stackmat,.27,.009)
    plate(name+' dark opening',(x+.011,y,z),w-.009,h-.008,.008,void,.27,.006)
    for t in np.linspace(-.38,.38,rows):
        plate(name+' louvre',(x+.018-t*h*.27,y,z+t*h),w-.014,.0025,.006,trim,.27,.001)
for suffix,y,z in [('driver',-.635,.843),('passenger',.622,.792)]:
    vent('Outer vent '+suffix,(-.415 if y<0 else -.430,y,z),.071,.143,10)
plate('Center bezel',(-.471,.005,.783),.258,.225,.025,stackmat,.31,.023)
for y in [-.061,.065]:vent('Center vent',(-.498,y,.866),.112,.038,5)
plate('Radio chassis',(-.455,.032,.801),.187,.047,.011,trim,.31)
plate('Tuner display',(-.446,.035,.811),.106,.010,.004,darkred,.31,.002)
for yy in [-.038,.100]:
    cylinder('Tuner control',(-.452,yy,.794),(-.439,yy,.797),.008,graphite,cabin)
for z in [.804,.772,.738]:
    dx=(.804-z)*.30
    cylinder('HVAC dial',(-.451+dx,-.104,z),(-.437+dx,-.104,z+.004),.016,trim,cabin)
    cylinder('HVAC dial face',(-.436+dx,-.104,z+.004),(-.432+dx,-.104,z+.005),.012,graphite,cabin)
plate('Single DIN storage opening',(-.442,.041,.752),.160,.024,.013,void,.31)
for yy in np.linspace(-.022,.083,7):plate('Preset key',(-.439,yy,.783),.011,.006,.006,graphite,.31,.001)
for yy in [-.068,-.032,.025,.066]:
    cylinder('Ventilation mode key',(-.429,yy,.698),(-.425,yy,.699),.006,trim,cabin)
plate('Glovebox face',(-.431,.377,.71),.397,.144,.018,dashboard,.25,.015)
plate('Glovebox catch',(-.423,.363,.762),.070,.015,.007,trim,.25)
column=np.array([-.316,-.367,.771]);axis=np.array([.831,0,.556]);h=np.array([0,1,0]);up=np.cross(axis,h)
disk('Three-spoke steering rim',column,axis,h,[(.161,0),(.171,.010),(.171,.021),(.159,.030),(.146,.023),(.144,.010),(.153,.002),(.161,0)],leather,cabin,76)
for side_ in (-1,1):
    line('Upper wheel spoke',[column+side_*.143*h+.047*up,column+side_*.107*h+.035*up,column+side_*.064*h],.015,dashboard,cabin)
line('Lower wheel spoke',[column-.151*up,column-.110*up,column-.062*up],.021,dashboard,cabin)
# Shaped horn pad with lateral thumb supports and a wider lower spoke.
shape=[(-.121,.041),(-.107,.065),(-.073,.069),(-.034,.066),(.033,.068),(.079,.066),(.110,.052),(.118,.027),(.104,.004),(.074,-.013),(.052,-.052),(.040,-.100),(.015,-.124),(-.014,-.121),(-.032,-.102),(-.046,-.052),(-.071,-.014),(-.106,.004)]
rings=[(.90,.004),(.99,.014),(1.,.029),(.964,.043),(.77,.056),(.44,.061),(.025,.065)];vs=[];fs=[]
for factor,d in rings:
    for y,z in shape:vs.append(column+axis*d+h*y*factor+up*z*factor)
for i in range(len(rings)-1):
    for j in range(len(shape)):
        n=len(shape);q=i*n+j;k=i*n+(j+1)%n;fs.append((q,k,k+n,q+n))
mesh('Contoured three-spoke driver airbag pad',vs,fs,dashboard,cabin)
for sign in [-1,1]:
    line('Steering column stalk',[column-axis*.087+sign*.07*h,column-axis*.078+sign*.17*h+.010*up,column-axis*.070+sign*.203*h+.016*up],.009,trim,cabin)

hub=column+axis*.072+.016*up
badge('Steering wheel H',hub,axis,.044,cabin)
text_label('Airbag embossing','SRS AIRBAG',hub-.041*up,.009,graphite,axis,cabin)
for off,rad,labels in [(-.092,.051,range(1,8)),(0,.064,range(20,141,20)),(.101,.048,[0,1,2,3])]:
    pos=np.array([-.604,-.377+off,.809])
    for a,num in zip(np.linspace(3.75,-.60,len(labels)),labels):
       coord=pos+[.005,rad*.67*cos(a),rad*.68*sin(a)]
       text_label('Instrument numerals',str(num),coord,.0085,ivory,(1,0,.08),cabin)
    line('Instrument pointer',[pos+[.010,0,0],pos+[.010,-rad*.75,-rad*.33]],.0017,red,cabin)
box('Cruise switch pod',column+.098*h-.000*up+axis*.035,(.024,.045,.038),trim,cabin,.007,rot=(0,-.36,0))
for l in range(3):
    tube('Cruise key', [column+.086*h+(.010-l*.010)*up+axis*.052,column+.108*h+(.010-l*.010)*up+axis*.052],.0017,steel,cabin)
box('Tunnel console',(.055,0,.324),(.92,.178,.119),trim,cabin,.048)
box('Shift gate bezel',(-.25,0,.393),(.210,.161,.020),stackmat,cabin,.016)
oval('Shifter bellows',(-.251,0,.407),(.089,.070,.026),rubber,cabin)
cylinder('Five-speed shift lever',(-.251,0,.422),(-.245,0,.531),.010,steel,cabin)
oval('Leather shift knob',(-.245,0,.548),(.022,.023,.031),leather,cabin)
for z,rx,ry in [(.415,.076,.055),(.426,.063,.047),(.437,.048,.039),(.448,.034,.027)]:
    oval('Gathered black shift boot',(-.250,0,z),(rx,ry,.013),leather,cabin)
line('Handbrake',[(.23,-.05,.399),(.14,-.053,.428),(.055,-.055,.436)],.014,rubber,cabin)
oval('Console armrest',(.397,0,.461),(.139,.081,.053),leather,cabin)
# Clutch, brake and throttle of the chosen five-speed configuration.
for y,w in [(-.49,.055),(-.37,.065),(-.273,.037)]:
 line('Pedal lever',[(-.67,y,.45),(-.607,y,.29),(-.573,y,.248)],.010,graphite,cabin)
 box('Pedal pad',(-.566,y,.245),(.022,w,.049),rubber,cabin,.008)
for s in (-1,1):
 box('Carpet footwell',(-.046,.36*s,.248),(1.49,.64,.035),fabric,cabin,.018)
box('Firewall',(-.76,0,.561),(.087,1.43,.667),trim,body,.065)
box('Engine bay lower cradle',(-1.397,0,.271),(1.012,1.13,.065),graphite,body,.027)
for s in (-1,1):
 oval('Front wheelhouse pressing',(-1.305,s*.617,.475),(.358,.145,.227),paint)
 oval('Upper strut housing',(-1.122,s*.539,.689),(.104,.092,.069),paint)
 cylinder('Top mount',(-1.13,s*.542,.727),(-1.13,s*.542,.753),.052,graphite)
box('D17 aluminium block',(-1.35,-.12,.47),(.36,.525,.302),graphite,motor,.04)
box('D17 SOHC cylinder head',(-1.35,-.12,.629),(.315,.539,.105),steel,motor,.029)
box('SOHC cam cover',(-1.351,-.119,.698),(.245,.497,.060),graphite,motor,.025)
# The page-four detail shows a cast ignition cover with a notched forward
# skirt, dark plugs, a slotted fastener near each end and raised lettering.
covermetal=material('Charcoal textured ignition cover',(.061,.072,.075),.39,.42)
cover=pivot('IgnitionCover',(-1.326,-.119,.739));cover.parent=motor;cover.matrix_parent_inverse=motor.matrix_world.inverted()
x0=-1.326;y0=-.119
profile=[(.061,.206),(.067,.197),(.067,-.195),(.056,-.204),(-.042,-.204),(-.049,-.197)]
yslots=[-.17,-.058,.054,.158]
for y in yslots:
    profile.extend([(-.049,y-.020),(-.035,y-.019),(-.026,y-.015),(-.026,y+.012),(-.036,y+.018),(-.049,y+.020)])
profile.extend([(-.050,.198),(-.040,.206)])
vs=[(x0+x,y0+y,z) for z in [.726,.749] for x,y in profile];n=len(profile)
faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
shield=mesh('Four-notch ignition coil cover',vs,faces,covermetal,cover,False)
bev=shield.modifiers.new('Soft casting edges','BEVEL');bev.width=.0028;bev.segments=4
mod=shield.modifiers.new('Machined cast face normals','WEIGHTED_NORMAL');mod.keep_sharp=True
label=text_label('Ignition cover Honda casting','HONDA',(x0+.033,y0-.012,.7503),.0205,steel,(0,0,1),cover);label.data.shear=.18;label.scale.x=1.58;label.data.extrude=.00085
# The casting uses square terminal cuts and an italic VTEC logotype.
letters=[('V',[(0,1),(.22,1),(.37,.22),(.78,1),(1,1),(.48,0),(.24,0)]),
 ('T',[(0,1),(1,1),(1,.79),(.62,.79),(.62,0),(.39,0),(.39,.79),(0,.79)]),
 ('E',[(0,1),(1,1),(1,.80),(.24,.80),(.24,.60),(.90,.60),(.90,.41),(.24,.41),(.24,.20),(1,.20),(1,0),(0,0)]),
 ('C',[(.12,1),(1,1),(1,.80),(.23,.80),(.23,.20),(1,.20),(1,0),(.12,0),(0,.14),(0,.86)])]
for index,(glyph,poly) in enumerate(letters):
    pts=[(x0+.008+(v-.5)*.024,y0+.077-(index*.039+u*.035+(v-.5)*.006),z) for z in [.7492,.7515] for u,v in poly];n=len(poly)
    fs=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    ob=mesh('Raised VTEC '+glyph,pts,fs,steel,cover,False)
    edge=ob.modifiers.new('Stamped edges','BEVEL');edge.width=.00055;edge.segments=2
for y in [-.240,.016]:
    cylinder('Recessed cover fastener', (x0+.011,y,.749),(x0+.011,y,.7505),.011,trim,cover)
    cylinder('Fastener crown',(x0+.011,y,.7503),(x0+.011,y,.7510),.0089,covermetal,cover)
    box('Slotted screw line',(x0+.011,y,.7512),(.0145,.0019,.00065),void,cover,.00035,rot=(0,0,1.28))
for y in np.linspace(-.285,.05,4):
    box('Ignition pack',(-1.403,y,.721),(.087,.064,.035),covermetal,cover,.012)
    box('Coil connector body',(-1.455,y,.708),(.030,.047,.024),trim,cover,.005)
    line('Coil harness',[(-1.461,y,.708),(-1.465,y,.688),(-1.438,y+.035,.684)],.005,trim,cover)
    cylinder('Coil mount',(-1.410,y+.036,.713),(-1.410,y+.036,.726),.0067,steel,cover)
    line('Exhaust manifold runner',[(-1.491,y,.605),(-1.58,y,.560),(-1.62,y*.70,.419),(-1.57,-.10,.359)],.024,graphite,motor)
box('Exhaust heat shield',(-1.532,-.11,.563),(.063,.358,.185),steel,motor,.022,rot=(0,-.19,0))
oval('Manual transmission case',(-1.38,.298,.454),(.175,.22,.165),graphite,motor)
for x in [-1.46,-1.422,-1.384,-1.346,-1.309]:box('Gearbox casting rib',(x,.309,.474),(.012,.286,.16),steel,motor,.016)
for s in (-1,1):
 cylinder('Drive axle',(-1.31,.16,.310),(-1.31,s*.705,.3075),.016,graphite,motor)
 for t in range(4):cylinder('CV boot rib',(-1.31,s*(.624+t*.014),.308),(-1.31,s*(.635+t*.014),.308),.035+t*.001,rubber,motor)
box('Air filter case',(-1.26,.44,.645),(.258,.243,.14),trim,motor,.023)
line('Intake duct',[(-1.214,.341,.655),(-1.088,.247,.648),(-1.087,.025,.634),(-1.148,-.034,.625)],.048,rubber,motor)
box('Battery',(-1.65,.408,.529),(.192,.163,.188),trim,motor,.013)
for y in [.35,.46]:cylinder('Battery pole',(-1.65,y,.624),(-1.65,y,.638),.011,steel,motor)
box('Radiator core',(-1.847,0,.438),(.042,1.036,.309),graphite,body,.008)
for z in np.linspace(.306,.568,26):box('Radiator fins',(-1.87,0,z),(.005,.946,.003),trim,body,.001)
line('Upper radiator hose',[(-1.81,-.315,.593),(-1.736,-.356,.626),(-1.591,-.339,.653),(-1.475,-.298,.626)],.018,rubber,motor)
for s in (-1,1):
 line('Bonnet reinforcement',[(-1.88,s*.41,.623),(-1.46,s*.49,.721),(-1.05,s*.54,.818)],.014,paint,hood)
 # Enclose the cargo compartment behind the rear bench.
 box('Rear trunk wall',(1.90,s*.635,.565),(.53,.068,.425),fabric,cabin,.017)
box('Cargo well',(1.76,0,.385),(.76,1.17,.087),fabric,cabin,.032)
box('Rear parcel shelf',(1.54,0,.943),(.42,1.30,.05),dashboard,cabin,.022)
box('Centre brake light',(1.64,0,.972),(.07,.254,.023),red,cabin,.007)

# Fabric-lined surfaces block daylight through the tops of the rear wheel housings.
for s in (-1,1):
 patch('Quarter inner trim',lambda x,t:flank(x,t,s)-[0,s*.016,.008],np.linspace(1.36,1.77,30),span(10),dashboard,body,(0,-s,0))
 patch('Rear side cabin trim',lambda x,t:np.array([x,s*(.737+.020*t),.28+.633*t]),np.linspace(.54,1.54,30),span(12),dashboard,cabin,(0,-s,0))
patch('Cabin headlining',lambda x,k:canopy(x,k)-[0,0,.018],np.linspace(.56,.84,16),np.linspace(-1,1,33),fabric,body,(0,0,-1))
for s in (-1,1):
 patch('Inner roof rail',lambda x,k:canopy(x,s*k)-[0,s*.014,.013],np.linspace(-.16,.84,26),np.linspace(.73,1,8),fabric,body,(0,0,-1))
line('Rearview mirror stem',[(-.199,0,1.294),(-.240,0,1.252),(-.218,0,1.223)],.008,trim,body)
box('Rearview mirror',(-.213,0,1.212),(.038,.211,.066),trim,body,.022,rot=(0,-.1,-.09))
box('Interior mirror glass',(-.193,0,1.212),(.006,.186,.047),steel,body,.012,rot=(0,-.1,-.09))
