"""Sample registration points from the actual painted, glass and lens surfaces."""
from finish import *
import json
out={}
for side_,suffix in [(-1,'L'),(1,'R')]:
 s=side_
 for k,p in {'F':[-1.30937,s*.826,.3075],'R':[1.30937,s*.826,.3075],'G':canopy(-.995,s*.947),'W':canopy(-.16,s*.947),'P':flank(1.320,.042,s),'D':[.267,s*(width(.262)+.001),.794],'M':[-.637,s*.870,.961],'I':lamp_surface(0,0,s,.014),'O':lamp_surface(1,1,s,.014),'A':canopy(.84,s*.927),'T':side(1.968,.614,s),'K':[-1.30937,s*.737,0],'J':[1.30937,s*.737,0]}.items():out[k+suffix]=list(p)
out['B']=front(0,.878,.017).tolist();out['E']=rear(0,.931,.018).tolist()
(root/'model/datums.json').write_text(json.dumps(out,indent=2))
