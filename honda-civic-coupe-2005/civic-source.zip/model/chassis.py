"""Underside study from the 2005 EX coupe (KA 5MT) replacement-parts illustrations.
Axle/track and brake sizes are factory data. Hard points and hidden profiles are inferred.
"""
from geometry import *

coated=material('E-coated stamped chassis steel',(.058,.064,.068),.48,.43)
fastener=material('Zinc plated hardware',(.39,.40,.35),.72,.35)
pipe_metal=material('Exhaust stainless',(.29,.26,.22),.73,.39)
spring_mat=material('Black enamel spring steel',(.025,.031,.033),.38,.34)
tank_mat=material('Dark fuel tank coating',(.075,.079,.076),.36,.51)

def pressed_arm(name,points,z,wall,group,mat=coated):
    n=len(points)
    verts=[(x,y,z+h) for h in (-wall/2,wall/2) for x,y in points]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    ob=mesh(name,verts,faces,mat,group,False)
    bevel=ob.modifiers.new('Stamping radius','BEVEL');bevel.width=min(wall*.35,.014);bevel.segments=3
    ob.modifiers.new('Stamping normals','WEIGHTED_NORMAL')
    return ob

def build_suspension(x,s,center,corner):
    group=pivot('Suspension'+corner,center)
    front=x<0
    def xyz(dx,y,z):return np.array([x+dx,s*y,z])
    # Strut-to-knuckle fork, spindle, spring seats, rod, bellows and top mount.
    axis=np.array([0,s,0]); hub=xyz(0,.675,.3075)
    disk('Wheel bearing and knuckle',hub,axis,[1,0,0],[(.022,-.035),(.057,-.035),(.061,-.024),(.058,.014),(.037,.042),(.024,.042)],graphite,group)
    bottom=xyz(.009,.677,.295);top=xyz(.055,.575,.715 if front else .741)
    v=top-bottom;direction=v/np.linalg.norm(v)
    right=np.cross(direction,[1,0,0]);right/=np.linalg.norm(right);lateral=np.cross(direction,right)
    def station(t):return bottom+t*v
    radius=.064 if front else .055
    disk('Hydraulic damper cylinder',bottom,direction,right,[(.021,0),(.030,.028),(.029,.167),(.030,.174),(.023,.179)],coated,group)
    cylinder('Damper piston',station(.34),station(.97),.0115,steel,group,32)
    for t in np.linspace(.49,.77,9):
        disk('Damper dust boot fold',station(t),direction,right,[(.021,-.005),(.024,-.004),(.026,0),(.022,.004)],rubber,group,32)
    for t,sign in [(.39,1),(.90,-1)]:
        disk('Pressed coil seat',station(t),direction,right,[(.022,0),(.054,.005*sign),(radius+.014,.010*sign),(radius+.014,.016*sign),(radius+.005,.011*sign),(.049,.009*sign)],coated,group,48)
    points=[]
    for t in span(181):
        a=2*pi*(.12+5.65*t)
        pitch=.40+.49*(t-.050*sin(2*pi*t))
        r=radius*(.90+.10*sin(pi*t))
        points.append(station(pitch)+r*(cos(a)*right+sin(a)*lateral))
    tube('Coil spring',points,.0065 if front else .0058,spring_mat,group,n=8)
    for t,r,mat in [(.94,.048,rubber),(.97,.059,coated),(.982,.033,rubber)]:
        disk('Strut top mount',station(t),direction,right,[(.007,0),(r,0),(r,.007),(.007,.007)],mat,group,48)
    for a in np.arange(3)*2*pi/3:
        p=station(.977)+.048*(cos(a)*right+sin(a)*lateral)
        cylinder('Top mount nut',p,p+direction*.012,.008,fastener,group,6)
    if front:
        footprint=[(-.18,.319),(-.115,.317),(.01,.519),(.09,.473),(.199,.336),(.27,.350),(.246,.426),(.105,.588),(.024,.682),(-.035,.678),(-.10,.489)]
    else:
        footprint=[(-.080,.330),(.010,.325),(.090,.400),(.065,.567),(.024,.687),(-.048,.687),(-.041,.576),(.006,.437),(-.069,.403)]
    pressed_arm('Lower control arm',[(x+dx,s*y) for dx,y in footprint],.254,.041,group)
    for dx,y in ((-.145,.344),(.22,.368)) if front else ((-.05,.355),):
        p=xyz(dx,y,.25)
        disk('Lower arm pivot bushing',p,[0,0,1],[1,0,0],[(.008,-.029),(.030,-.029),(.032,.025),(.010,.026)],rubber,group,32)
        cylinder('Pivot bolt head',p+[0,0,.018],p+[0,0,.033],.012,fastener,group,6)
    line('Knuckle upright',[xyz(.012,.667,.247),hub,xyz(.011,.652,.401),xyz(.006,.641,.444)],.021,graphite,group)
    if not front:
        line('Upper rear wishbone',[xyz(-.085,.386,.452),xyz(-.047,.529,.448),xyz(.002,.654,.427),xyz(.059,.551,.454),xyz(.126,.435,.467)],.018,coated,group)
        line('Rear trailing link',[xyz(-.48,.580,.241),xyz(-.31,.581,.233),xyz(-.135,.643,.237),xyz(-.02,.674,.261)],.027,coated,group)
    else:
        line('Steering tie rod',[xyz(.165,.388,.364),xyz(.158,.534,.351),xyz(.102,.663,.347)],.0105,graphite,group)
    for a,b in [(xyz(.021,.651,.372),xyz(.021,.687,.372)),(xyz(.016,.652,.418),xyz(.016,.688,.418))]:
        cylinder('Damper foot bolt',a,b,.011,fastener,group,6)

def build_underside():
    group=pivot('Subframes')
    # The front cradle surrounds the sump, with pairs of mounting towers at each end.
    for x,length,width in [(-1.28,.82,.91),(1.24,.51,.85)]:
        for s in (-1,1):
            edge=[(-.50,-.8),(-.34,-1),(.41,-1),(.50,-.77),(.39,-.66),(.26,-.77),(-.20,-.76),(-.41,-.61)]
            pts=[(x+dx*length,s*dy*width/2) for dx,dy in edge]
            pressed_arm('Subframe side rail',pts,.236,.063,group)
        for dx,sgn in [(-.345,-1),(.355,1)]:
            pts=[(x+dx*length+.053*sgn*(1-(y/.41)**2),y,.239+.029*(1-(y/.41)**2)) for y in np.linspace(-width*.42,width*.42,20)]
            tube('Subframe crossmember',pts,.047,coated,group,n=8)
        bar_x=x+.163
        bar=[(bar_x-.18*np.clip((abs(y)-.28)/.30,0,1),y,.294+.038*(abs(y)/.61)**4) for y in np.linspace(-.61,.61,37)]
        tube('Front anti-roll bar' if x<0 else 'Rear anti-roll bar',bar,.00795 if x<0 else .006,spring_mat,group,n=8)
        for s in (-1,1):
            oval('Stabilizer bar D bush',(bar_x,s*.268,.297),(.021,.028,.018),rubber,group)
            box('Stabilizer bush clamp',(bar_x,s*.268,.306),(.054,.026,.010),fastener,group,.003)
    exhaust=pivot('Exhaust')
    def shell_can(name,x,y,z,length,ry,rz):
        def skin(u,a):
            shoulder=.86+.14*min(1,u/.07,(1-u)/.07)
            return [x+(u-.5)*length,y+ry*shoulder*cos(a),z+rz*shoulder*sin(a)]
        patch(name,skin,[0,.015,.065,.10,.90,.935,.985,1],np.linspace(0,2*pi,65),pipe_metal,exhaust)
        for u in (0,1):
            patch('Pressed silencer end',lambda t,a:mix([x+(u-.5)*length,y,z],skin(u,a),t),[0,1],np.linspace(0,2*pi,65),pipe_metal,exhaust)
        for u in (.045,.955):
            tube('Rolled exhaust can seam',[skin(u,a) for a in np.arange(64)*2*pi/64],.0038,pipe_metal,exhaust,True)
    run=[(-1.57,-.10,.36),(-1.59,-.09,.232),(-1.38,-.056,.166),(-.92,-.044,.171),(-.55,-.032,.175),(-.18,.038,.176),(.45,.120,.181),(.82,.224,.181),(1.10,.263,.247),(1.39,.304,.323),(1.68,.434,.291)]
    line('Bent exhaust pipe',run,.022,pipe_metal,exhaust)
    shell_can('Underfloor resonator',-.34,.003,.176,.46,.058,.051)
    shell_can('Rear silencer',1.86,.462,.279,.47,.129,.091)
    line('Muffler outlet pipe',[(2.026,.46,.28),(2.083,.476,.273),(2.141,.49,.267),(2.18,.49,.264)],.023,pipe_metal,exhaust)
    for x,y,z in [(-.76,-.04,.17),(.52,.129,.183),(1.54,.375,.309)]:
        disk('Exhaust flange',(x,y,z),[1,0,0],[0,1,0],[(.024,0),(.039,0),(.040,.005),(.026,.006)],graphite,exhaust,16)
    for x,y,z in [(-.35,.019,.199),(1.69,.54,.305),(2.0,.53,.302)]:
        line('Exhaust hanger wire',[(x,y,z),(x,y+.063,z+.007),(x+.026,y+.078,z+.04)],.0055,pipe_metal,exhaust)
        oval('Exhaust hanger isolator',(x+.028,y+.078,z+.051),(.012,.017,.027),rubber,exhaust)
    tank=pivot('FuelTank')
    # Under-seat stamped pan, upper flange, two storage lobes and steel support straps.
    def pan(a,t):
        r,z=[(.78,.161),(.94,.168),(1,.196),(1,.238),(.98,.263),(.82,.305),(.30,.310)][int(t)]
        c=cos(a);v=sin(a)
        return [.730+.317*r*np.sign(c)*abs(c)**.61,-.113+.433*r*np.sign(v)*abs(v)**.6,z+.018*(1-c*c)]
    patch('Fuel tank pressed halves',pan,np.linspace(0,2*pi,85),range(7),tank_mat,tank)
    for t in (0,6):
        patch('Fuel tank closure',lambda a,r:mix([.730,-.113,pan(a,t)[2]],pan(a,t),r),np.linspace(0,2*pi,85),[0,1],tank_mat,tank)
    tube('Fuel tank welded seam',[pan(a,3) for a in np.arange(96)*2*pi/96],.0059,coated,tank,True)
    for y in (-.398,.111):
        curvepts=[(.39,y,.267),(.427,y,.190),(.491,y,.163),(.918,y,.156),(1.007,y,.185),(1.065,y,.259)]
        base=softened(curvepts,54)
        patch('Fuel tank retaining band',lambda i,v:base[int(i)]+[0,v*.015,0],range(len(base)),[-1,1],fastener,tank)
    line('Fuel filler neck',[(.882,-.488,.265),(1.104,-.483,.315),(1.287,-.494,.478),(1.5,-.684,.695),(1.56,-.736,.839)],.021,pipe_metal,tank)
    pump=[.72,-.215,.319]
    disk('Fuel pump access ring',pump,[0,0,1],[1,0,0],[(.020,0),(.083,0),(.085,.005),(.074,.013),(.021,.014)],fastener,tank)
