"""Underhood detail of the U.S. 2005 EX D17A2, using the photographed five-speed engine bay."""
from shell import *

zinc=material('Zinc plated engine fasteners',(.31,.33,.28),.72,.34)
poly=material('Translucent reservoir polypropylene',(.69,.64,.41),.01,.37,.08)
yellow=material('Dipstick handle amber',(.94,.48,.010),.02,.31)
blue=material('Washer cap blue',(.012,.24,.50),.03,.37)
cable=material('Insulated cable jacket',(.012,.014,.014),.01,.48)
shield_metal=material('Stamped exhaust shield',(.68,.66,.61),.58,.31)

def bolt(name,x,y,z,r=.006,g=body):
    cylinder(name,(x,y,z),(x,y,z+.004),r,zinc,g,vertices=6)

def pipe(name,points,r,mat,g=body):
    return tube(name,softened(points,38),r,mat,g,n=9)

# The molded cowl tray wraps forward of the windshield bond. Its forward rim
# conceals the firewall and overhangs the heater connections in the open bay.
cowl_ribs=[(-.865,.849),(-.973,.884),(-1.025,.874),(-1.094,.844),
           (-1.116,.830),(-1.143,.817),(-1.151,.807),(-1.149,.779),(-1.126,.771)]
def cowl_surface(k,i):
    x,z=cowl_ribs[i];a=abs(k)
    return np.array([x-.018*a*a,k*.718,z-.025*a**3])
patch('Cowl vent tray',cowl_surface,np.linspace(-1,1,83),range(len(cowl_ribs)),trim,body,(0,0,1))
for s in (-1,1):
    patch('Cowl tray end',lambda i,v:mix(cowl_surface(s,i),cowl_surface(s,7),v),range(8),span(4),trim,body)
tube('Cowl leading bulb seal',[cowl_surface(k,6)+[0,0,.001] for k in np.linspace(-1,1,72)],.007,rubber)
for k in np.r_[np.linspace(-.80,-.16,49),np.linspace(.025,.45,33)]:
    # The air inlet slots follow the slope of the cowl and roll around its radiused sides.
    a=mix(cowl_surface(k,2),cowl_surface(k,3),.21)
    b=mix(cowl_surface(k,2),cowl_surface(k,3),.72)
    tube('Cowl grille slot',[a+[0,0,.0014],b+[0,0,.0014]],.0021,void)
# Both parked blades point toward the passenger side. The shorter blade
# follows the steeper curvature at the outboard corner. Derive the sweep,
# contact face and local top normal from the actual curved windshield.
for k,ya,yb,station0,station1 in [(-.849,-.473,.089,-.908,-.924),(-.041,.213,.660,-.950,-.891)]:
    base=mix(cowl_surface(k,1),cowl_surface(k,2),.62)
    cylinder('Wiper pivot boss',base,base+[0,0,.011],.015,trim)
    bolt('Wiper pivot nut',base[0],base[1],base[2]+.011,.008)
    def blade_point(t,h=0,wide=0):
        y=float(mix(ya,yb,t))
        x=float(mix(station0,station1,t))+.007*sin(pi*t)
        point=canopy(x,y/cw(x));along=canopy(x+.001,y/cw(x+.001))-point
        cross=canopy(x,(y+.001)/cw(x))-point
        normal=np.cross(along,cross);normal/=np.linalg.norm(normal)
        return point+normal*h+along/np.linalg.norm(along)*wide
    # Tapered rubber edge touches the glass, the flat carrier bridges it.
    coords=[(-.0012,.001),(.0012,.001),(.0033,.007),(.0033,.011),(-.0033,.011),(-.0033,.007),(-.0012,.001)]
    patch('Windshield wiper blade',lambda t,i:blade_point(t,coords[i][1],coords[i][0]),span(45),range(len(coords)),rubber,body)
    for a,b in [(0.05,.48),(.48,.94)]:
        tube('Windshield wiper bridge',[blade_point(t,.013+.008*sin(pi*(t-a)/(b-a))) for t in np.linspace(a,b,19)],.0037,trim)
    clip_pos=blade_point(.48,.020)
    box('Wiper blade attachment',clip_pos,(.021,.043,.015),trim,body,.004)
    elbow=base+.28*(clip_pos-base)+[-.017,0,.005]
    pts=softened([base+[0,0,.013],elbow,base+.68*(clip_pos-base)+[-.008,0,.016],clip_pos+[0,0,.009]],34)
    def arm(j,i):
        t=j/(len(pts)-1);half=.009*(1-t)+.005*t
        dx,dz=[(-half,-.002),(half,-.002),(half,.003),(-half,.003),(-half,-.002)][i]
        return pts[j]+[dx,0,dz]
    patch('Wiper arm pressing',arm,range(len(pts)),range(5),trim,body)
# The booster hangs on the driver side of the dash. Its vacuum line, the
# firewall loom and two heater hoses run behind the intake plenum.
disk('Brake booster shell',(-1.015,-.406,.679),(-1,0,0),(0,1,0),
     [(.020,-.051),(.086,-.048),(.103,-.028),(.107,.006),(.102,.020),(.082,.038),(.035,.042)],trim)
cylinder('Brake master cylinder',(-1.056,-.405,.686),(-1.202,-.405,.699),.028,graphite)
pipe('Booster vacuum line',[(-1.080,-.456,.730),(-1.128,-.479,.752),
     (-1.193,-.461,.741),(-1.230,-.396,.718),(-1.230,-.301,.710)],.011,rubber)
for y,side_ in [(-.118,-1),(.026,1)]:
    pipe('Heater hose at firewall',[(-.887,y,.698),(-.985,y,.723),(-1.071,y+side_*.061,.725),
         (-1.130,y+side_*.073,.692),(-1.174,y+side_*.084,.636)],.016,rubber)
pipe('Firewall wiring loom',[(-.991,.585,.735),(-1.018,.410,.742),(-1.042,.228,.758),
     (-1.041,-.052,.753),(-1.070,-.237,.741),(-1.083,-.455,.731)],.010,cable)
for y in (-.466,-.352,.233,.487):
    box('Cowl harness connector',(-1.054,y,.744),(.036,.028,.021),trim,body,.004)

# Hem, inner reinforcement and striker are visible with the hood raised.
def recess_distance(u,k,loop):
    # Signed inset to each edge of a convex polygon, with a rounded margin at the corners.
    # Coordinates use distance from the centerline so both pressings mirror on their ridge.
    d=[]
    for (x0,y0),(x1,y1) in zip(loop,loop[1:]+loop[:1]):
        dx,dy=x1-x0,y1-y0
        d.append((dx*(k-y0)-dy*(u-x0))/math.hypot(dx,dy))
    return min(d)
hood_cells=[
    [(.21,.11),(.43,.095),(.49,.61),(.20,.54)],
    [(.50,.095),(.85,.092),(.56,.595)],
    [(.62,.61),(.854,.205),(.84,.62)],
    [(.26,.759),(.68,.747),(.83,.822),(.39,.93)],
]
def hood_cell(u,k):
    return max(recess_distance(u,abs(k),loop) for loop in hood_cells)
def hood_under(u,k):
    x=float(mix(nose,-.924,u));p=deck(x,k*hood_side(x))
    rim=smooth((1-abs(k))/.082)*smooth(u/.09)*smooth((1-u)/.09)
    depth=.006+rim*(.026-.020*smooth(hood_cell(u,k)/.035))
    p[2]-=depth
    return p
patch('Bonnet inner pressing',hood_under,span(85),np.linspace(-1,1,105),paint,hood,(0,0,-1))
# Dark damping patches lie on the exposed outer skin inside four of the stamped openings.
pad=material('Panel damping pad',(.023,.022,.021),.03,.78)
for sy in [-1,1]:
 for loop in hood_cells[:3]:
    cx,cy=np.mean(loop,axis=0)
    ring=softened([(x,sy*y,0) for x,y in loop],28,True)
    def patchpoint(i,r):
        u=(1-r)*cx+r*ring[int(i)][0];k=(1-r)*sy*cy+r*ring[int(i)][1]
        return hood_under(u,k)-[0,0,.0009]
    patch('Bonnet damping patch',patchpoint,np.arange(len(ring)+1)%len(ring),np.linspace(.001,.76,9),pad,hood,(0,0,-1))
for s in (-1,1):
    patch('Hood folded side hem',lambda u,v:mix(hood_under(u,s),deck(float(mix(nose,-.924,u)),s*hood_side(float(mix(nose,-.924,u)))),v),span(44),span(3),paint,hood)
    pt=hood_under(.84,s*.78)
    box('Hood hinge leaf',pt-[0,0,.008],(.093,.039,.013),zinc,hood,.004)
    for dx in (-.029,.031):
        bolt('Hood hinge fixing',pt[0]+dx,pt[1],pt[2]-.019,.007,hood)
p=hood_under(.033,0)
pipe('Hood lock striker',[p+[-.005,-.026,0],p+[-.005,-.023,-.030],p+[-.005,.023,-.030],p+[-.005,.026,0]],.0042,zinc,hood)

# The radiator support runs across the nose of the bay. The center catch and
# its two small fasteners stay on the unit body when the radiator is removed.
def support(u,v):
    return [-1.83+.08*v+.032*abs(u)**3, u*.628, .637+.011*sin(pi*v)-.038*abs(u)**3]
patch('Radiator support crossmember',support,np.linspace(-1,1,54),span(14),paint,body,(0,0,1))
box('Hood latch receiver',(-1.803,0,.644),(.074,.100,.035),graphite,body,.009)
for y in [-.53,-.43,-.095,.095,.43,.53]:
    bolt('Radiator support bolt',-1.782,y,.641-.029*(abs(y)/.63)**3,.007)
for s in (-1,1):
    for angle in (pi/2,7*pi/6,11*pi/6):
        bolt('Strut top nut',-1.25437+.062*cos(angle),s*.575+.062*sin(angle),.721,.009)
    cylinder('Strut top stud',(-1.25437,s*.575,.730),(-1.25437,s*.575,.744),.009,zinc)
# At the right of the photographed bay are the brake/clutch reservoir at the
# firewall, the steering-fluid reservoir and the blue washer filler cap.
def reservoir(name,location,r,h,cap_material):
    x,y,z=location
    disk(name+' moulding',(x,y,z),(0,0,1),(1,0,0),
         [(.015,0),(.82*r,.003),(r,.020),(r,.70*h),(.83*r,.81*h),(.64*r,.85*h),(.64*r,h)],poly)
    disk(name+' cap',(x,y,z+h),(0,0,1),(1,0,0),
         [(.60*r,-.003),(.74*r,0),(.76*r,.012),(.68*r,.016),(.001,.016)],cap_material)
reservoir('Brake fluid reservoir',(-.993,-.338,.695),.051,.067,trim)
reservoir('Clutch fluid reservoir',(-.996,-.443,.673),.028,.068,trim)
reservoir('Steering fluid reservoir',(-1.586,-.556,.498),.050,.112,trim)
reservoir('Washer filler neck',(-1.682,-.564,.506),.040,.118,blue)
for i in range(3):
    y=-.352-.025*i
    pipe('Brake pipe',[(-1.186,y-.050,.707),(-1.202,y-.048,.681),(-1.161,y-.072,.624),(-.897,y-.071,.607)],.0031,zinc)
pipe('Power steering hose',[(-1.559,-.641,.565),(-1.588,-.512,.533),(-1.627,-.416,.548),(-1.624,-.358,.550)],.010,rubber)

# Fuse/relay box and battery are distinct on the passenger wing. The battery
# has two raised clamp posts, a hold-down yoke and separate cable routes.
box('Fuse box base',(-1.055,.453,.616),(.192,.235,.118),trim,body,.020)
box('Fuse box lid',(-1.054,.453,.678),(.204,.247,.030),trim,body,.012)
for sy in (-1,1):
    box('Fuse box lid catch',(-1.055,.453+sy*.119,.658),(.032,.014,.034),graphite,body,.004)
box('Battery top cover',(-1.65,.408,.628),(.196,.165,.013),trim,motor,.007)
for y in (.349,.460):
    cylinder('Battery cable clamp',(-1.65,y,.631),(-1.65,y,.642),.013,zinc,motor)
    bolt('Battery post nut',-1.639,y,.642,.005,motor)
box('Battery hold-down',(-1.650,.409,.639),(.022,.178,.014),graphite,motor,.003)
for y in (.316,.501):
    cylinder('Battery tie rod',(-1.650,y,.526),(-1.650,y,.646),.0031,zinc,motor)
    bolt('Battery tie nut',-1.65,y,.645,.005,motor)
pipe('Battery ground cable',[(-1.662,.461,.640),(-1.698,.485,.643),(-1.687,.542,.591),(-1.608,.559,.570)],.009,cable,motor)
pipe('Battery supply lead',[(-1.651,.346,.639),(-1.616,.303,.633),(-1.585,.302,.550),(-1.48,.273,.522)],.009,cable,motor)

# Air resonator with ribs, flexible inlet, rear plenum and manifold runners.
for x in np.linspace(-1.36,-1.17,8):
    bow=max(0,sin(pi*(x+1.405)/.292))
    box('Air filter lid rib',(x,.44,.701+.018*bow**.6),(.008,.155+.040*bow,.009),trim,motor,.003)
for x in [-1.34,-1.19]:
    for y in [.323,.557]:
        box('Air filter lid clip',(x,y,.693),(.017,.010,.031),zinc,motor,.003)
pipe('Air filter flexible inlet',[(-1.31,.517,.632),(-1.385,.544,.606),(-1.434,.514,.573),(-1.488,.493,.544)],.045,rubber,motor)
for u in np.linspace(0,1,8):
    x=float(mix(-1.389,-1.461,u))
    disk('Air filter duct convolution',(x,.539-.034*u,.603-.046*u),(-.80,-.22,-.55),(0,1,0),[(.043,-.003),(.049,-.001),(.049,.002),(.043,.004)],trim,motor)
box('Engine rear intake plenum',(-1.062,-.105,.680),(.144,.462,.084),trim,motor,.030)
for x in np.linspace(-1.116,-1.015,5):
    box('Engine plenum moulding rib',(x,-.105,.724),(.009,.399,.009),graphite,motor,.004)
for y in np.linspace(-.281,.057,4):
    pipe('Engine inlet runner',[(-1.231,y+.024,.669),(-1.246,y,.608),(-1.277,y,.613),(-1.309,y,.632)],.027,graphite,motor)
    pipe('Engine injector loom',[(-1.317,y,.668),(-1.301,y,.688),(-1.290,y+.045,.691)],.004,cable,motor)
# Satin pressed shield lies over the front-facing four-branch manifold. Its
# broad upper cap rolls over the head flange and funnels towards the collector.
# Coordinates are already in the registered engine-bay frame.
shield_width=curve([(0,.057),(.13,.108),(.26,.118),(.40,.171),(.58,.182),(.86,.178),(1,.153)])
shield_x=curve([(0,-1.724),(.18,-1.704),(.40,-1.682),(.65,-1.653),(.87,-1.629),(1,-1.591)])
def exhaust_shield(u,v):
    w=2*u-1;edge=abs(w);soft=sin(pi*v)**.7
    shoulder=.010*(math.exp(-((w-.55)/.29)**2)+math.exp(-((w+.55)/.29)**2))
    x=shield_x(v)-soft*(.023*(1-w*w)+shoulder)+.017*edge**5
    z=.493+.157*v+.012*(1-w*w)*soft-.008*edge**5
    z+=.011*math.exp(-((v-.86)/.064)**2)*(1-edge**3)
    return np.array([x,-.164+w*shield_width(v),z])
patch('Exhaust manifold pressed shield',exhaust_shield,span(67),span(54),shield_metal,motor,(-1,0,1))
for u in (0,1):
    tube('Exhaust shield rolled flange',[exhaust_shield(u,v) for v in span(47)],.0028,shield_metal,motor)
tube('Exhaust shield top rolled hem',[exhaust_shield(u,1) for u in span(53)],.003,shield_metal,motor)
for u in (.16,.84):
    q=exhaust_shield(u,.88);n=np.array([-.53,0,.85])
    cylinder('Exhaust shield washer',q,q+.002*n,.009,steel,motor)
    cylinder('Exhaust shield bolt',q+.002*n,q+.007*n,.006,zinc,motor,vertices=6)
# The stock orange dipstick rises behind the coil cover. The handle is above
# the upper trim, with its flared shoulder and handle opening both visible.
disk('Oil filler screw cap',(-1.362,-.333,.716),(0,0,1),(1,0,0),[(.026,0),(.029,.008),(.027,.018),(.001,.020)],trim,motor)
p=np.array([-1.351,-.253,.771])
outline=[(-.012,.010),(-.019,.006),(-.016,-.004),(-.004,-.012),(.004,-.012),(.018,.002),(.017,.009),(.010,.010)]
tube('Dipstick amber loop',[p+[.55*q[1],q[0],q[1]] for q in softened([(y,z,0) for y,z in outline],48,True)],.0043,yellow,motor,True)
pipe('Dipstick tube',[p+[0,0,-.012],[-1.356,-.253,.723],[-1.384,-.250,.646]],.005,zinc,motor)
for sy in (-1,1):
    path=[(-1.685,sy*.451,.552),(-1.594,sy*.499,.610),(-1.481,sy*.520,.632),(-1.334,sy*.482,.676),(-1.184,sy*.478,.690)]
    pipe('Body wiring loom',path,.010,cable)
# Rolled underside and latch of the trunk lid, visible when the cargo bay is open.
trunk_cells=[
    [(.20,.105),(.72,.098),(.26,.595)],
    [(.27,.710),(.72,.23),(.76,.663),(.47,.780)],
]
def trunk_inner(u,k):
    p=lid(u,k);edge=1-abs(k)
    cell=max(recess_distance(u,abs(k),loop) for loop in trunk_cells)
    frame=smooth(edge/.095)*smooth(u/.095)*smooth((1-u)/.09)
    p[2]-=.007+frame*(.032-.023*smooth(cell/.045))
    return p
patch('Trunk lid inner reinforcement',trunk_inner,span(75),np.linspace(-1,1,95),paint,hatch,(0,0,-1))
for sy in (-1,1):
    p=trunk_inner(.22,sy*.70)
    pipe('Trunk hinge arm',[p,p+[-.029,0,-.056],p+[-.082,sy*.019,-.112],p+[-.145,sy*.025,-.095]],.011,graphite,hatch)

# Register the installed equipment to the hood-open EX photo. The fixed strut
# tops and the center hood catch establish the coordinate frame. Translations
# are applied to complete components before material batching and leave each
# hose with its own routing. The battery tray is rotated in plan on this car.
from mathutils import Matrix, Vector
def register_equipment():
    bpy.context.view_layer.update()
    def set_parts(prefixes,delta,*,parent=None,angle=0,origin=(0,0,0)):
        move=Matrix.Translation(Vector(delta))
        if angle:
            pivot=Matrix.Translation(Vector(origin))
            move=move @ pivot @ Matrix.Rotation(math.radians(angle),4,'Z') @ pivot.inverted()
        selected=[ob for ob in bpy.context.scene.objects if ob.name.startswith(prefixes)
                  and (parent is None or ob.parent==parent)]
        for ob in selected:
            ob.matrix_world=move @ ob.matrix_world
    set_parts(('D17 ','SOHC cam cover','IgnitionCover','Oil filler'),(-.11,0,0),parent=motor)
    set_parts('Exhaust manifold runner',(-.102,-.053,0),parent=motor)
    set_parts('Air filter',(-.23,-.16,0),parent=motor)
    set_parts('Fuse box',(-.336,.207,0),parent=body)
    set_parts('Battery',(-.030,.112,0),parent=motor,angle=32,origin=(-1.65,.408,.63))
    set_parts('Steering fluid reservoir',(.036,-.109,0),parent=body)
    set_parts('Washer filler neck',(.172,-.176,0),parent=body)
    set_parts('Brake fluid reservoir',(-.187,-.062,0),parent=body)
    set_parts('Clutch fluid reservoir',(-.239,-.012,0),parent=body)
    set_parts(('Engine rear intake plenum','Engine plenum moulding'),(-.173,.031,0),parent=motor)
    bpy.context.view_layer.update()
register_equipment()
