"""Surface, profile and material tools for the metric Blender master."""
import math
from math import sin,cos,pi
from pathlib import Path
import bpy, numpy as np
from mathutils import Vector, Matrix
from bisect import bisect_right
root=Path(__file__).resolve().parents[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
def material(name,color,metal=0,rough=.38,coat=0,alpha=1):
    m=bpy.data.materials.new(name);m.use_nodes=True
    sh=m.node_tree.nodes.get('Principled BSDF')
    for k,v in [('Base Color',(*color,1)),('Metallic',metal),('Roughness',rough),('Coat Weight',coat),('Coat Roughness',.15),('Alpha',alpha)]: sh.inputs[k].default_value=v
    m.diffuse_color=(*color,alpha)
    if alpha<1:
        m.blend_method='BLEND';m.use_backface_culling=True
    return m
paint=material('R513 Rallye Red clear coat',(.335,.0034,.0068),.06,.31,.59)
rubber=material('Weatherstrips',(.009,.012,.014),0,.51)
rubbertire=material('Tire sidewall',(.016,.018,.019),.06,.61)
tread=material('Tread grooves',(.006,.007,.008),0,.76)
trim=material('Satin black trim',(.019,.022,.024),.16,.31)
void=material('Recess shadow',(.0035,.0045,.005),.04,.75)
glass=material('Smoke blue-green glass',(.017,.036,.045),.12,.19,.32,.68)
steel=material('Machined aluminum',(.52,.56,.59),.87,.22,.22)
bright=material('Chromed bezel',(.77,.81,.83),.94,.15)
wheelmat=material('Silver EX alloy',(.56,.58,.60),.80,.185,.35)
graphite=material('Brake casting',(.115,.119,.124),.65,.47)
leather=material('Dark gray woven upholstery',(.053,.056,.058),0,.88)
fabric=material('Cabin and carpet',(.016,.019,.021),0,.86)
dashboard=material('Graphite dashboard',(.027,.032,.034),.02,.54)
lamp=material('Headlamp reflector',(.58,.65,.71),.66,.20,.5)
projector=material('Projector lens',(.19,.26,.34),.44,.115,.75)
red=material('Ruby tail lamp',(.49,.007,.012),.25,.21,.8)
darkred=material('Tail lens edge',(.146,.004,.007),.26,.23,.7)
amber=material('Amber indicator',(.94,.181,.012),.22,.21,.65)
ivory=material('Reverse light lens',(.77,.78,.71),.17,.24,.62)

groups={}
def pivot(name,where=(0,0,0)):
    o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o.location=where;groups[name]=o;bpy.context.view_layer.update();return o
body=pivot('Body')
hood=pivot('Hood',(-.875,0,.868)); hatch=pivot('Trunk',(1.67,0,1.01))
doors={s:pivot('DoorLeft' if s<0 else 'DoorRight',(-.87,s*.79,.75)) for s in (-1,1)}
motor=pivot('Powertrain',(-1.39,0,.52)); cabin=pivot('Interior',(0,0,.53))
def assign(o,m,g):
    o.data.materials.append(m)
    if g: o.parent=g;o.matrix_parent_inverse=g.matrix_world.inverted()
    return o
def mesh(name,verts,faces,m,g=body,smooth=True):
    data=bpy.data.meshes.new(name);data.from_pydata(verts,[],faces);data.update()
    ob=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(ob);assign(ob,m,g)
    if smooth: data.polygons.foreach_set('use_smooth',np.ones(len(data.polygons),dtype=bool))
    return ob
def span(n):return np.linspace(0,1,n)
def mix(a,b,t):return (1-t)*np.asarray(a)+t*np.asarray(b)
def clip(v):return min(1,max(0,v))
def smooth(t):
    t=clip(t);return t*t*(3-2*t)
def curve(pairs):
    """Monotone cubic interpolation of a surveyed profile."""
    xs,ys=zip(*pairs);dx=np.diff(xs);d=np.diff(ys)/dx
    m=[d[0]]
    for i in range(1,len(xs)-1):
        left,right=d[i-1:i+1]
        if left*right<=0:m.append(0.)
        else:
            a=2*dx[i]+dx[i-1];b=dx[i]+2*dx[i-1]
            m.append((a+b)/(a/left+b/right))
    m.append(d[-1])
    def point(x):
        i=min(len(xs)-2,max(0,bisect_right(xs,x)-1));t=max(0,min(1,(x-xs[i])/dx[i]))
        return ((2*t**3-3*t*t+1)*ys[i]+(t**3-2*t*t+t)*dx[i]*m[i]
               +(-2*t**3+3*t*t)*ys[i+1]+(t**3-t*t)*dx[i]*m[i+1])
    return point
def patch(name,fn,us,vs,m,g=body,normal=None,skip=None):
    us=list(us);vs=list(vs);cols=len(vs);verts=[tuple(fn(u,v)) for u in us for v in vs]
    faces=[]
    reverse=False
    if normal is not None:
        a=np.array(verts).reshape(len(us),cols,3); i=max(0,len(us)//2-1);j=max(0,cols//2-1)
        reverse=np.dot(np.cross(a[i+1,j]-a[i,j],a[i,j+1]-a[i,j]),normal)<0
    for i in range(len(us)-1):
        for j in range(cols-1):
            if skip and skip((us[i]+us[i+1])*.5,(vs[j]+vs[j+1])*.5):continue
            a=i*cols+j;f=(a,a+cols,a+cols+1,a+1);faces.append(f[::-1] if reverse else f)
    return mesh(name,verts,faces,m,g)
def tube(name,points,r,m,g=body,closed=False,n=6):
    pts=[Vector(p) for p in points];vs=[];fs=[];old=None
    for j,p in enumerate(pts):
        before=pts[(j-1)%len(pts)] if closed or j else p
        after=pts[(j+1)%len(pts)] if closed or j<len(pts)-1 else p
        tan=(after-before).normalized()
        if old is None: old=Vector((0,0,1)) if abs(tan.z)<.85 else Vector((0,1,0))
        axis=(old-tan*old.dot(tan)).normalized();other=tan.cross(axis);old=axis
        for i in range(n): vs.append(tuple(p+r*(axis*cos(2*pi*i/n)+other*sin(2*pi*i/n))))
    for j in range(len(pts) if closed else len(pts)-1):
        for i in range(n):
            a=j*n+i;b=j*n+(i+1)%n;c=((j+1)%len(pts))*n+(i+1)%n;d=((j+1)%len(pts))*n+i;fs.append((a,b,c,d))
    return mesh(name,vs,fs,m,g)
def softened(points,num=55,closed=False):
    pts=np.array(points);n=len(pts)
    def p(i):return pts[i%n] if closed else pts[max(0,min(n-1,i))]
    result=[]
    for u in np.linspace(0,n if closed else n-1,num,endpoint=not closed):
        i=int(u);t=u-i;a,b,c,d=[p(j) for j in (i-1,i,i+1,i+2)]
        result.append(.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t**3))
    return result
def line(name,pts,r,m,g=body,closed=False):
    return tube(name,softened(pts,max(20,6*len(pts)),closed),r,m,g,closed)
def oval(name,center,scale,m,g=body,rot=None):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=16,location=center)
    ob=bpy.context.object;ob.name=name;ob.scale=scale
    if rot:ob.rotation_euler=rot
    for p in ob.data.polygons:p.use_smooth=True
    return assign(ob,m,g)
def box(name,center,size,m,g=body,bevel=.012,rot=None):
    bpy.ops.mesh.primitive_cube_add(size=1,location=center);o=bpy.context.object;o.name=name
    o.data.transform(Matrix.Diagonal((*size,1))); 
    if rot:o.rotation_euler=rot
    if bevel:
        mod=o.modifiers.new('Moulded edges','BEVEL');mod.width=bevel;mod.segments=4
        if hasattr(o.data,'use_auto_smooth'): o.data.use_auto_smooth=True
        mod=o.modifiers.new('Face-weighted normals','WEIGHTED_NORMAL');mod.keep_sharp=True
    return assign(o,m,g)
def cylinder(name,a,b,r,m,g=body,vertices=48):
    a,b=Vector(a),Vector(b);d=b-a
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=d.length,location=(a+b)*.5)
    ob=bpy.context.object;ob.name=name;ob.rotation_euler=d.to_track_quat('Z','Y').to_euler()
    for p in ob.data.polygons:p.use_smooth=len(p.vertices)==4
    return assign(ob,m,g)
def disk(name,center,axis,horizontal,profile,m,g=body,n=64):
    """Surface of revolution; profile is (radius, offset along outward normal)."""
    c=np.array(center);axis=np.array(axis);axis=axis/np.linalg.norm(axis)
    h=np.array(horizontal);h=h-axis*np.dot(axis,h);h=h/np.linalg.norm(h);v=np.cross(axis,h)
    verts=[c+axis*z+r*(h*cos(a)+v*sin(a)) for r,z in profile for a in np.arange(n)*2*pi/n]
    fs=[]
    for j in range(len(profile)-1):
        for i in range(n):fs.append((j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i))
    return mesh(name,verts,fs,m,g)
def text_label(name,text,loc,size,m,face,g=body):
    font=bpy.data.curves.new(name,'FONT');font.body=text;font.align_x='CENTER';font.align_y='CENTER';font.size=size;font.extrude=.00055;font.resolution_u=4
    ob=bpy.data.objects.new(name,font);bpy.context.collection.objects.link(ob);ob.location=loc
    normal=Vector(face).normalized();up=Vector((0,0,1)) if abs(normal.z)<.9 else Vector((1,0,0))
    right=up.cross(normal).normalized();up=normal.cross(right).normalized()
    ob.rotation_euler=Matrix((right,up,normal)).transposed().to_euler();assign(ob,m,g);return ob
