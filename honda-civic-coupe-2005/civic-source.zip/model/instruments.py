"""Faces of the US 2005 Civic EX five-speed cluster, traced from frame int-08."""
from geometry import *

face = material('Charcoal instrument dial', (.045,.043,.043), 0, .67)
ink = material('Ivory instrument print', (.81,.79,.72), 0, .68)
red_ink = material('Vermilion instrument print', (.65,.053,.022), 0, .65)
needle = material('Orange instrument needle', (1.,.13,.032), .06, .36)
lcd = material('Odometer amber LCD', (.65,.36,.12), 0, .54)
normal = np.array([1.,0,.14]); normal /= np.linalg.norm(normal)
horizontal = np.array([0.,1.,0.])
up = np.cross(normal,horizontal)

def polar(center, radius, angle, depth=.0017):
    return center + horizontal*radius*cos(angle) + up*radius*sin(angle) + normal*depth

def band(name, center, radius, width, start, end, surface):
    angles = np.linspace(start, end, 100)
    patch(name, lambda a, r: polar(center,r,a), angles, [radius-width,radius], surface, cabin, normal)

def marks(center, radius, start, end, count, length, major, surface):
    vertices, faces = [], []
    for i, angle in enumerate(np.linspace(start,end,count)):
        long = i % major == 0
        inner = radius-length*(1.5 if long else 1.)
        half = .013 if long else .006
        j=len(vertices)
        vertices.extend([polar(center,r,a) for r,a in [(inner,angle-half),(radius,angle-half),(radius,angle+half),(inner,angle+half)]])
        faces.append((j,j+1,j+2,j+3))
    mesh('Printed gauge graduations',vertices,faces,surface,cabin,False)

def number(center, string, size, surface=ink):
    ob=text_label('Dial legend',string,center,size,surface,normal,cabin)
    ob.data.extrude=.00009
    ob.data.shear=.12

def hand(center, radius, angle):
    # Tapered luminous pointer with a rounded cap on its pivot.
    direction=horizontal*cos(angle)+up*sin(angle)
    cross=-horizontal*sin(angle)+up*cos(angle)
    pos=center+normal*.0055
    points=[pos+direction*radius,pos-direction*.005+cross*.0022,pos-direction*.010,pos-direction*.005-cross*.0022]
    mesh('Gauge pointer',points,[(0,1,2,3)],needle,cabin,False)
    disk('Gauge pointer hub',center,normal,horizontal,[(.009,.002),(.009,.0047),(.0065,.0052),(.0001,.0054)],trim,cabin,40)

def build():
    # Holding the central speedometer and camera fixed places both side dials
    # lower, with a thin margin between each pair of bezels.
    tach=np.array([-.6004,-.4941,.7830])
    speed=np.array([-.604,-.377,.809])
    dual=np.array([-.6013,-.2577,.7895])
    for center,radius in [(tach,.052),(speed,.064),(dual,.052)]:
        disk('Instrument silver bezel',center,normal,horizontal,[(radius+.0014,-.003),(radius+.0014,.0014),(radius,.0020),(radius-.001,.0006)],steel,cabin)
        disk('Charcoal dial face',center,normal,horizontal,[(radius,.0004),(.00002,.0004)],face,cabin)
    a,b=np.deg2rad([225.,-37.5])
    for center,radius,values in [(tach,.052,range(9)),(speed,.064,range(0,141,20))]:
        band('Printed red perimeter',center,radius*.925,radius*.026,a,b,red_ink)
        marks(center,radius*.885,a,b,65 if center is tach else 71,radius*.039,5,ink)
        for angle,value in zip(np.linspace(a,b,len(values)), values):
            number(polar(center,radius*.738,angle),str(value),radius*.15)
    marks(tach,.052*.875,np.deg2rad(7),b,20,.004,2,red_ink)
    number(tach+up*.017+normal*.002,'×1000r/min',.0039)
    number(speed+up*.033+normal*.002,'mph',.0068)
    for angle,value in zip(np.linspace(a,b,13),range(0,241,20)):
        number(polar(speed,.024,angle),str(value),.0038,red_ink)
    number(speed+up*.017+normal*.002,'km/h',.0038,red_ink)
    hand(speed,.055,np.deg2rad(224))
    hand(tach,.044,np.deg2rad(207))
    band('Printed red perimeter',dual,.048,.0012,0.,2*pi,red_ink)
    for offset, angles, letters, angle in [(-.017,(142,219),('H','C'),191),(.017,(39,-39),('F','E'),19)]:
        center=dual+horizontal*offset
        marks(center,.026,*np.deg2rad(angles),15,.0025,7,ink)
        for a_,letter in zip(np.deg2rad(angles),letters):
            number(polar(center,.022,a_),letter,.006)
        hand(center,.025,np.deg2rad(angle))
    center=speed-up*.045+normal*.0025
    box('Digital odometer bezel',center,(.0018,.042,.0118),trim,cabin,.0007,rot=(0,-.139,0))
    # Illustrative display reading. Actual mileage belongs to the donor vehicle.
    number(center+normal*.0012,'000000',.0090,lcd)
    trip=np.array([-.5952,-.3251,.7462])
    cylinder('Trip reset stem',trip-normal*.004,trip+normal*.006,.0034,rubber,cabin)
