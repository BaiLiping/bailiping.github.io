"""Set GLB parent-local removal offsets in metres. Re-run after rebuilding studio.json."""
from pathlib import Path
import argparse
import json
import re

OFFSETS = {
    'Subframes': (0, 0, 0), 'Body': (0, 1.95, 0),
    'Hood': (-.91, 2.85, 0), 'Trunk': (.86, 2.56, 0),
    'FrontBumper': (-1.12, -.36, 0), 'RearBumper': (1.05, -.39, 0),
    'Windshield': (-.17, .54, 0), 'BackGlass': (.24, .5, 0), 'Moonroof': (0, .84, 0),
    'Interior': (-1.95, .64, -.60), 'Console': (.06, .28, .12),
    'Dashboard': (-.69, .51, -.26), 'Steering': (-.25, .78, .30),
    'RearBench': (.23, .48, .10), 'LuggageLiner': (2.65, .42, .35),
    'ParcelShelf': (2.42, .60, .34), 'SpareWheel': (.86, .39, .26),
    'Engine': (-.68, .41, .12), 'Transaxle': (-.46, .21, .76),
    'OilPan': (-.76, -.10, .13), 'CylinderHead': (-.69, .83, .13),
    'ValveCover': (-.70, 1.02, .13), 'IgnitionCover': (-.73, 1.22, .13),
    'AccessoryDrive': (-.61, .39, -.4), 'Intake': (-.48, .86, -.58),
    'Battery': (-.47, .72, .93), 'Radiator': (-.88, -1.30, -.10),
    'Exhaust': (.56, -.34, .07), 'FuelTank': (.19, -.30, -.26),
}
SIDE = {
    'Door': (-.10, 1.72, 1.33), 'DoorGlass': (.02, .32, .10),
    'Mirror': (-.15, .18, .32), 'DoorTrim': (.04, -.20, -.15),
    'Fender': (-.30, .02, .59), 'QuarterGlass': (.10, .31, .36),
    'Headlamp': (-.83, .02, .32), 'Taillamp': (.66, .12, .33),
    'Seat': (-.09, .52, .48), 'Wheel': (0, .03, .65),
    'Tire': (0, .02, .50), 'Brake': (0, 0, .37), 'Suspension': (0, .10, .12),
    'Halfshaft': (-.21, .10, .30),
}

def offset(name):
    if name in OFFSETS:
        return OFFSETS[name]
    match = re.fullmatch(r'(.+?)(Front|Rear)?(Left|Right)', name)
    family, _, side = match.groups()
    x, y, z = SIDE[family]
    return (x, y, z if side == 'Left' else -z)

def apply(path):
    config = json.loads(path.read_text())
    for part in config['parts']:
        part['offset'] = offset(part['node'])
        part.pop('portraitOffset', None)
    config['explodedDirection'] = [-.82, .73, 1.05]
    path.write_text(json.dumps(config, indent=2, ensure_ascii=False) + '\n')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('config', type=Path)
    apply(parser.parse_args().config)
