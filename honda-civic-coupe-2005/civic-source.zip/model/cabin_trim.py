"""EM2 split rear bench, molded carpet and cargo well from the EX photo gallery."""
from geometry import *

carpet = material('Charcoal needle-pile carpet', (.061,.059,.059), 0, .97)
belt = material('Gray seat belt webbing', (.105,.106,.109), 0, .75)
release = material('Buckle release red', (.49,.012,.007), 0, .49)
sparesteel = material('Compact spare black wheel', (.022,.025,.026), .55, .30)

def padded_rest(name,center,depth,width,height,lean):
    x,y,z=center
    taper=curve([(0,.77),(.07,.91),(.20,1),(.70,.97),(.90,.89),(1,.71)])
    def skin(a,t):
        scale=taper(t);ca,sa=cos(a),sin(a)
        return np.array([x+lean*t+depth*scale*np.sign(ca)*abs(ca)**.69,
                         y+width*scale*np.sign(sa)*abs(sa)**.64,z+height*t])
    angles=np.linspace(0,2*pi,59)
    patch(name+' cover',skin,angles,span(19),leather,cabin)
    for end in (0,1):
        patch(name+' end',lambda a,r:mix([x+lean*end,y,z+height*end+.009*(2*end-1)],skin(a,end),r),angles,span(7),leather,cabin)
    for side in (-1,1):
        tube(name+' side seam',[skin(side*pi*.78,t) for t in np.linspace(.06,.94,17)],.0012,trim,cabin)

def rear_bench(cloth):
    def cushion(t,k):
        y = k*(.686-.026*t*t)
        outer = abs(k)**5
        center = math.exp(-(y/.146)**4)
        basin = math.exp(-((abs(y)-.382)/.183)**4)
        x = .746+.484*t+.059*outer*(1-1.4*t)
        z = .446+.030*cos(pi*t)-.041*basin*sin(pi*t)**.83+.011*center+.025*outer
        z -= .043*max(0,1-t/.125)**2
        return np.array([x,y,z])

    def back(t,k):
        y=k*(.654-.041*t*t)
        bolsters=math.exp(-((abs(y)-.554)/.083)**2) + .65*math.exp(-(y/.124)**4)
        x=1.186+.205*t+.034*t*t-.049*bolsters*sin(pi*t)**.8-.013*sin(pi*t)+.009*math.exp(-((t-.60)/.045)**2)*math.exp(-((abs(y)-.36)/.18)**4)
        z=.431+.494*t-.038*abs(k)**4*t*t
        return np.array([x,y,z])

    ts=span(35);ks=np.linspace(-1,1,77)
    patch('Rear seat full-width cushion',cushion,ts,ks,leather,cabin,(0,0,1))
    for edge in (0,1):
        patch('Rear seat cushion end roll',lambda k,v:cushion(edge,k)+[(2*edge-1)*.022*sin(pi*v),0,-.088*v],ks,span(9),leather,cabin)
    for side in (-1,1):
        patch('Rear seat outer skirt',lambda t,v:cushion(t,side)+[0,-side*.014*v,-.088*v],ts,span(7),leather,cabin)
    patch('Rear seat underside',lambda t,k:cushion(t,k)-[0,0,.088],ts,ks,fabric,cabin,(0,0,-1))
    # The split follows the inboard edge of the passenger-side seating position.
    for low,high in [(-1,.260),(.268,1)]:
        bounds=np.linspace(low,high,47)
        patch('Split rear backrest face',back,ts,bounds,leather,cabin,(-1,0,0))
        patch('Split rear backrest carpeted panel',lambda t,k:back(t,k)+[.062-.025*t,0,0],ts,bounds,carpet,cabin,(1,0,0))
        patch('Split rear backrest top roll',lambda k,v:back(1,k)+[.037*v,0,.012*sin(pi*v)],bounds,span(9),leather,cabin,(0,0,1))
        for k in (low,high):
            patch('Split rear backrest bound edge',lambda t,v:back(t,k)+[(.062-.025*t)*v,0,0],ts,span(7),leather,cabin)
    for side in (-1,1):
        def center_k(t,k):
            return side*(.535+.268*k-.010*cos(pi*t))
        patch('Rear seat woven cushion insert',lambda t,k:cushion(.08+.84*t,center_k(t,k))+[0,0,.0014],ts,np.linspace(-1,1,22),cloth,cabin,(0,0,1))
        patch('Rear seat woven back insert',lambda t,k:back(.04+.915*t,center_k(t,k))+[-.0014,0,0],ts,np.linspace(-1,1,22),cloth,cabin,(-1,0,0))
        for k in (-1,1):
            line('Rear seat bolster stitching',[back(t,center_k(t,k))+[-.002,0,0] for t in np.linspace(.055,.944,18)],.0015,trim,cabin)
            line('Rear seat insert stitching',[cushion(t,center_k(t,k))+[0,0,.002] for t in np.linspace(.09,.91,18)],.0015,trim,cabin)
        line('Rear seat transverse seam',[back(.60,center_k(.60,k))+[-.0018,0,0] for k in np.linspace(-1,1,21)],.0020,trim,cabin)
        line('Rear seat cushion cross seam',[cushion(.39,center_k(.39,k))+[0,0,.0021] for k in np.linspace(-1,1,21)],.0017,trim,cabin)
        y=side*.375
        for d in (-.045,.045):
            cylinder('Rear seat restraint guide',(1.391,y+d,.910),(1.409,y+d,.963),.0065,steel,cabin)
        padded_rest('Rear seat head restraint',(1.396,y,.923),.058,.104,.133,.044)
        pos=cushion(.88,side*.30)
        box('Rear seat belt buckle',pos+[0,0,.018],(.056,.039,.031),trim,cabin,.009,rot=(0,.14,side*.12))
        box('Rear seat belt release',pos+[-.026,0,.023],(.006,.030,.017),release,cabin,.003,rot=(0,.14,side*.12))
        patch('Rear seat outboard belt webbing',lambda t,k:back(t*.93+.016,side*(.918+.065*t)+.028*k)-[.009,0,0],ts,[-1,1],belt,cabin,(-1,0,0))
    patch('Rear seat center shoulder webbing',lambda t,k:back(.015+.985*t,.214+.142*t+.029*k)-[.010,0,0],ts,[-1,1],belt,cabin,(-1,0,0))


def passenger_carpet():
    def floor(x,k):
        y=k*(.674+.022*sin(pi*(x+.70)/1.87))
        tunnel=.083*math.exp(-(y/.136)**2)*(1-.32*smooth((x-.52)/.35))
        toe=.110*smooth((-.43-x)/.31)
        heel=.105*smooth((x-.69)/.23)
        return np.array([x,y,.239+toe+heel+tunnel+.036*abs(k)**6])
    xs=np.linspace(-.716,1.155,79);ks=np.linspace(-1,1,55)
    patch('Carpet footwell molded floor',floor,xs,ks,carpet,cabin,(0,0,1))
    for s in (-1,1):
        def quarter(x,t):
            a=(x-.515)/.88
            y=.642+.062*t+.026*cos(pi*a)-.036*sin(pi*a)**2*sin(pi*t)**2
            return np.array([x,s*y,.279+.63*t+.055*a*(1-t)])
        patch('Rear side cabin molded trim',quarter,np.linspace(.515,1.395,49),span(20),dashboard,cabin,(0,-s,0))
        line('Rear side cabin trim bolster',[quarter(x,.59)-[0,s*.020,.015] for x in np.linspace(.617,1.16,16)],.018,leather,cabin)
        line('Rear side cabin trim armrest',[quarter(x,.42)-[0,s*.027,0] for x in np.linspace(.665,1.07,12)],.026,dashboard,cabin)


def luggage():
    def floor(u,k):
        x=1.300+.856*u-.067*abs(k)**5*(1+u)
        # The lowered mat narrows between the two rear wheel housings.
        w=.645-.133*math.exp(-((x-1.400)/.211)**2)-.037*u**5
        return np.array([x,k*w,.419+.017*(1-u)**2+.011*abs(k)**4])
    us=span(63);ks=np.linspace(-1,1,49)
    patch('Luggage floor removable deck mat',floor,us,ks,carpet,cabin,(0,0,1))
    for side in (-1,1):
        def wall(u,t):
            pt=floor(u,side)
            arch=.073*sin(pi*t)*math.exp(-((pt[0]-1.40)/.25)**2)
            rise=.412+.062*(1-u)-.100*u**4
            return pt+[.032*t*(2*u-1)-.013*sin(pi*t)*u**8,side*(.027*(1-math.exp(-12*t))+.041*t-arch),rise*t]
        patch('Trunk wheelhouse molded carpet',wall,us,span(33),carpet,cabin,(0,-side,0))
        tube('Luggage floor bound side edge',[floor(u,side)+[0,0,.002] for u in us],.0036,fabric,cabin)
        for u in (.24,.73):
            p=wall(u,.58)
            cylinder('Trunk wheelhouse retaining stud',p,p+[0,-side*.003,0],.010,trim,cabin)
    def rear(k,t):
        pt=floor(1,k)
        return pt+[.032*t-.013*sin(pi*t),k*(.027*(1-math.exp(-12*t))+.041*t),.276*t+.036*abs(k)**3*t]
    patch('Curved cargo threshold',rear,ks,span(17),carpet,cabin,(-1,0,0))
    patch('Curved cargo threshold sill cap',lambda k,v:rear(k,1)+[.033*v,0,.005*sin(pi*v)],ks,span(7),trim,cabin,(0,0,1))
    for u in (.29,.77):
        for k in (-.84,.84):
            p=floor(u,k)+[0,0,.002]
            disk('Luggage floor tie-down',p,[0,0,1],[1,0,0],[(.007,0),(.008,.002),(.004,.003)],graphite,cabin,22)
    # The coupe trunk access photo shows the removable carpet sitting over a
    # shallow steel auxiliary wheel. The valve, bowl and retaining bolt face up.
    spare=pivot('SpareWheel',(1.733,0,.358))
    c=np.array([1.733,0,.358]);axis=(0,0,1);h=(1,0,0)
    disk('Temporary spare tire',c,axis,h,[(.178,-.042),(.197,-.052),(.237,-.054),(.254,-.043),(.262,-.024),(.263,.025),(.255,.043),(.239,.053),(.201,.054),(.178,.043),(.178,-.042)],rubbertire,spare,96)
    disk('Compact steel spare wheel',c,axis,h,[(.019,-.027),(.055,-.027),(.071,-.021),(.122,-.026),(.142,-.014),(.164,.025),(.176,.037),(.183,.047),(.188,.044),(.185,.035),(.183,-.047),(.177,-.048)],sparesteel,spare,72)
    for i in range(4):
        a=pi*.25+i*pi*.5;p=c+[.051*cos(a),.051*sin(a),-.025]
        disk('Spare wheel stud hole',p,axis,h,[(.010,0),(.008,.001),(.001,0)],void,spare,18)
    cylinder('Spare wheel anchor',c+[0,0,-.030],c+[0,0,-.002],.008,steel,spare)
    cylinder('Spare wheel hold-down nut',c+[0,0,-.004],c+[0,0,.004],.016,graphite,spare,6)


def upholstery_textures():
    """Pack seamless, metric-scale yarn patterns and map only the fabric meshes."""
    import struct
    import tempfile
    import zlib
    import binascii

    # Linear roughness stays in the material. The RGB tile carries dyed yarn
    # variation, with the alternating diagonal ribs visible in the EX seat inserts.
    n=256
    j,i=np.indices((n,n))
    rng=np.random.default_rng(2005)
    yarn=(np.sin(2*pi*i/4)*np.sin(2*pi*j/4))
    chevron=np.where((i//32)%2==0,j+i,j-i)
    twill=np.cos(2*pi*chevron/16)*(.72+.28*np.cos(2*pi*j/64))
    fleck=rng.normal(0,1,(n,n))
    tuft=np.sin(2*pi*(i+j)/16)*np.cos(2*pi*(i-j)/8)
    patterns=[
        (leather,[78,78,77],3.5*yarn+1.7*fleck+2.0*tuft,.064),
        (bpy.data.materials['EX woven cloth insert'],[91,93,94],15*twill+3*yarn+2.2*fleck+4*tuft,.145),
        (carpet,[78,76,74],6.2*fleck+2.8*tuft+2*yarn,.095),
    ]
    def chunk(kind,data):
        return struct.pack('>I',len(data))+kind+data+struct.pack('>I',binascii.crc32(kind+data))
    for material_,base,noise,period in patterns:
        rgb=np.clip(np.asarray(base)[None,None,:]+noise[:,:,None],0,255).astype(np.uint8)
        scanlines=b''.join(b'\x00'+row.tobytes() for row in rgb)
        png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',n,n,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(scanlines,9))+chunk(b'IEND',b'')
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'fabric.png';path.write_bytes(png)
            tex=bpy.data.images.load(str(path));tex.name=material_.name+' woven albedo';tex.pack()
        node=material_.node_tree.nodes.new('ShaderNodeTexImage');node.image=tex
        material_.node_tree.links.new(node.outputs['Color'],material_.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
        material_['fabric_period_m']=period

    bpy.context.view_layer.update()
    for ob in bpy.context.scene.objects:
        if ob.type!='MESH' or not ob.data.materials:
            continue
        period=ob.data.materials[0].get('fabric_period_m')
        if not period:
            continue
        meshdata=ob.data
        uv=meshdata.uv_layers.active or meshdata.uv_layers.new(name='Cloth weave')
        verts=np.empty(len(meshdata.vertices)*3,np.float32);meshdata.vertices.foreach_get('co',verts)
        mat=np.asarray(ob.matrix_world);xyz=verts.reshape(-1,3)@mat[:3,:3].T+mat[:3,3]
        norms=np.empty(len(meshdata.polygons)*3,np.float32);meshdata.polygons.foreach_get('normal',norms)
        major=np.abs(norms.reshape(-1,3)@np.linalg.inv(mat[:3,:3])).argmax(axis=1)
        lengths=np.empty(len(meshdata.polygons),np.int32);meshdata.polygons.foreach_get('loop_total',lengths)
        major=np.repeat(major,lengths)
        indices=np.empty(len(meshdata.loops),np.int32);meshdata.loops.foreach_get('vertex_index',indices)
        coords=xyz[indices]
        # Keep the weave vertical on the backrests and lateral on cushion tops.
        u=np.where(major==1,coords[:,0],coords[:,1])
        v=np.where(major==2,-coords[:,0],coords[:,2])
        uv.data.foreach_set('uv',(np.stack((u,v),axis=1)/period).astype(np.float32).ravel())

def front_garnish():
    from shell import canopy
    # The inside of the windscreen surround is upholstered. A small rolled hem
    # runs along the glass, with the outer face of the pillar left painted.
    pillar_skin=material('Charcoal pillar garnish',(.106,.109,.110),0,.80)
    for side in (-1,1):
        def garnish(t,v):
            x=float(mix(-.992,-.143,t))
            p=canopy(x,side)
            w=.029+.012*(1-t)**3
            p[0]+=.018+.025*v
            p[1]-=side*(.012+w*v)
            p[2]-=.016+.012*sin(pi*v)
            return p
        patch('Cabin trim A pillar garnish',garnish,span(53),span(9),pillar_skin,cabin,(1,-side,0))
    def mat(y,t):
        x,z=[(-.52,.228),(-.614,.246),(-.675,.269),(-.731,.363),(-.771,.473),(-.788,.626),(-.806,.778),(-.830,.838)][int(t)]
        # Foam-backed carpet over the sheet-metal toe board and dash bulkhead.
        return [x+.026*(1-(y/.706)**2),y,z]
    patch('Carpet footwell dash insulator',mat,np.linspace(-.710,.710,61),range(8),carpet,cabin,(1,0,0))
    def low_dash(u,v):
        y=float(mix(-.731,-.152,u))
        x=float(mix(-.581,-.431,v))-.028*sin(pi*u)
        z=float(mix(.441+.050*abs(2*u-1)**2,.658,v))
        return [x,y,z]
    patch('Dashboard lower steering column bolster',low_dash,span(35),span(15),dashboard,cabin,(1,0,0))
    # Shifting boot and knee room sit in the recess below the narrower centre stack.
    for s in (-1,1):
        def console_wall(t,v):
            return [float(mix(-.68,-.35,t)),s*(.106+.033*v+.014*t),.277+.332*v-.082*t**2]
        patch('Console lower side cover',console_wall,span(21),span(13),dashboard,cabin,(0,s,0))
    def tray(t,u):
        return [float(mix(-.70,-.475,t)),.127*u,.425+.065*t**5+.015*abs(u)**3]
    patch('Console lower stowage tray',tray,span(19),np.linspace(-1,1,21),trim,cabin,(0,0,1))
