"""2004–05 bumper openings, optics, brightwork and rear deck face."""
from shell import *
def front(k,t,depth=.006):
 p=fascia(k,t); p+=np.array([-depth,depth*np.sign(k)*abs(k)**4,depth*.30*t]);return p
def rear(k,t,depth=.006):
 p=bodypoint(tail,t,k);p+=np.array([depth,depth*np.sign(k)*abs(k)**4,0]);return p
def boundary(n,fn,r,m,g=body):
 pts=[fn(u,0) for u in span(41)]+[fn(1,v) for v in span(12)[1:]]+[fn(u,1) for u in span(41)[-2::-1]]+[fn(0,v) for v in span(12)[-2:0:-1]]
 return tube(n,pts,r,m,g,True)
def grill(u,v):
 k=(2*u-1)*(.388+.113*v)
 t=.747+.240*v+.050*(abs(2*u-1)**3)*(1-v)
 return front(k,t)
patch('Upper grille pocket',grill,span(62),span(20),void,body,(-1,0,0));boundary('Upper grille surround',grill,.0053,trim)
# Individual staggered hexagonal radiator grille cells, trimmed along the sloped ends.
for j in range(5):
 for i in range(-14,15):
    u=.5+(i+.5*(j%2))*.042;v=.10+.17*j
    if .02<u<.98:
       coords=[grill(u+.023*cos(a),v+.105*sin(a))+[-.002,0,0] for a in np.arange(6)*pi/3]
       tube('Honeycomb grille',coords,.0015,trim,body,True,4)
def lowint(u,v):
 k=(2*u-1)*(.515-.055*v)
 return front(k,.147+.217*v+.012*abs(2*u-1)**4)
patch('Lower radiator intake',lowint,span(66),span(20),void,body,(-1,0,0))
boundary('Lower intake return',lowint,.0045,trim)
for v in [.18,.44,.70]:tube('Radiator louvre',[lowint(u,v)+[-.003,0,0] for u in span(48)],.003,trim)
for s in (-1,1):
 def duct(u,v):
    k=s*(.58+.176*u+.026*v+.030*sin(pi*v)*u)
    t=.151+.204*v+.036*u**2*(1-v)
    return front(k,t)
 patch('Outer bumper opening',duct,span(30),span(15),void,body,(-1,s*.6,0))
 boundary('Corner duct rim',duct,.0035,trim)
 # The inboard low point and upswept outboard tip give the facelift its almond lenses.
 def coords(u,v):
    k=.495+.498*u+.074*v*(1-u)-.012*v*u-.026*u**6*(abs(2*v-1)**4)
    t=(.759+.008*u+.083*u**6)*(1-v)+(.965+.019*sin(pi*u)+.012*u)*v
    return s*k,t
 def lens(u,v,depth=.009):
    k,t=coords(u,v);return front(k,t,.002+.69*depth)
 patch('Reflector housing back',lens,span(56),span(22),graphite,body,(-1,s*.45,.3))
 boundary('Headlamp gasket',lens,.0035,rubber)
 # The reflector has two shared, irregular optical wells, one larger than the other.
 # Distinct planar folds break the highlights; the source lamp has no circular projector bezel.
 optical=material('Polished reflector surface '+str(s),(.62,.66,.68),.94,.113,.24)
 for left,right_ in [(.018,.40),(.375,.835)]:
    def optic(u,v):
       w=left+(right_-left)*u+.033*(v-.5)
       w=max(.009,min(.853,w));q=.060+.874*v
       # Form a rounded-square paraboloid with shallower folds along the bottom lip.
       rr=(((u-.51)/.53)**2+((v-.48)/.55)**2)
       depth=.010+.025*min(1.18,rr)+.0019*math.sin(v*pi*7)**2*(1-v)**2
       return lens(w,q,depth)
    patch('Parabolic reflector well',optic,span(34),span(29),optical,body,(-1,s*.5,.28))
    tube('Angled dividing partition',[optic(1,v) for v in np.linspace(.05,.95,24)],.00185,steel,body)
    for j in [0.10,.19,.29]:
       tube('Lower optical flute',[optic(u,j+.036*(u-.48)**2)+[-.0007,0,0] for u in np.linspace(.12,.87,27)],.00065,bright,body)
    tip=optic(.54,.50)
    oval('Halogen bulb shield',tip+[-.004,0,0],(.005,.0065,.0047),bright)
 def indicator(u,v):return lens(.814+.117*u-.050*sin(pi*v),.100+.790*v,.016)
 patch('Amber corner reflector',indicator,span(18),span(12),amber,body,(-1,s*.6,.1))
 for t in np.linspace(.12,.90,8):tube('Indicator lens fluting',[indicator(t,v)+[-.001,0,0] for v in span(15)],.0013,ivory)
 clear=material('Optical lens '+str(s),(.55,.66,.7),.03,.12,.42,.12)
 for u0 in [0,1]:
    patch('Lens edge barrel',lambda v,w:mix(lens(u0,v,.007),lens(u0,v,.039),w),span(24),span(3),steel,body)
 patch('Clear headlamp cover',lambda u,v:lens(u,v,.039+.007*sin(pi*u)*sin(pi*v)),span(40),span(20),clear,body,(-1,s*.45,.3))
 # Vertical aft edge and tapered forward tip follow the triangular quarter lamp.
 def taillight(u,v):
    # sweep along the side, then across the corner to the trunk seam
    t=.614+.331*v
    # Walk the lamp from its pointed forward corner, around the rolled rear fascia, to the jamb.
    travel=float(mix(.895*v**.83,1,u))
    if travel<.55:
       xx=float(mix(1.968,tail,travel/.55));p=side(xx,t,s);p[1]+=s*.004
    else:
       k=1-(.335-.054*v)*(travel-.55)/.45;p=rear(s*k,t,.006)
    return p
 patch('Triangular tail lamp',taillight,span(65),span(20),darkred,body,(1,s,0));boundary('Rear lamp gasket',taillight,.004,rubber)
 def tailpane(a,b,m,offset):
    patch('Lens band',lambda u,v:taillight(u,float(mix(a,b,v)))+np.array([offset,s*offset,0]),span(60),span(10),m,body,(1,s,0))
 tailpane(.03,.96,red,.0014)
 for mid,level,radius in [(.69,.62,.12),(.41,.30,.105)]:
    def brake(a,t):
       u=mid+radius*t*cos(a);v=level+.195*t*sin(a)
       return taillight(u,v)+[.003+.002*t,s*.003,0]
    patch('Red reflector chamber',brake,np.linspace(0,2*pi,39),np.linspace(.002,1,9),darkred,body,(1,s*.24,0))
    for rr in [.30,.61,.94]:
       tube('Tail lens Fresnel ring',[brake(a,rr)+[.002,s*.001,0] for a in np.arange(46)*2*pi/46],.0017,red,body,True)

 for v in [.20,.32,.63,.74]:
    tube('Tail lamp fluting',[taillight(u,v)+[.002,s*.002,0] for u in np.linspace(.080,.99,60)],.00095,darkred)
 def reversing(a,t):
    return taillight(.924+.057*t*cos(a),.34+.149*t*sin(a))+[.005,s*.002,0]
 patch('Reversing lens',reversing,np.linspace(0,2*pi,50),np.linspace(.003,1,12),ivory,body,(1,s*.25,0))
# Trunk face and shaped plate pocket are carried by the lid with the latch and emblems.
def trunk(u,v):
 k=(2*u-1)*(.655+.075*v)
 t=.584+.410*v+.032*(abs(2*u-1)**5)*(1-v)
 return rear(k,t,.008)
patch('Trunk vertical pressing',trunk,span(50),span(17),paint,hatch,(1,0,0));boundary('Trunk peripheral seam',trunk,.0021,rubber,hatch)
def platearea(u,v):
 k=(2*u-1)*(.285+.064*v);t=.626+.207*v+.014*abs(2*u-1)**4
 return rear(k,t,.011)
patch('Inset plate pressing',platearea,span(31),span(13),paint,hatch,(1,0,0))
boundary('Plate pressing shadow',platearea,.0034,darkred,hatch)
tube('Deck release garnish',[rear(k,.846,.016)+[.004,0,0] for k in np.linspace(-.32,.32,40)],.009,paint,hatch)
p=rear(0,.736,.022);box('License plate',p,(.008,.305,.152),ivory,hatch,.004)
text_label('Civic plate','CIVIC',p+[.005,0,0],.05,trim,(1,0,0),hatch)
def badge(label,p,normal,size,g):
 n=np.array(normal,dtype=float);n/=np.linalg.norm(n);right=np.cross((0,0,1),n);right/=np.linalg.norm(right);up=np.cross(n,right)
 def pt(u,v):return p+size*(u*right+v*up)
 pts=[pt(.48*np.sign(cos(a))*abs(cos(a))**.50,.43*np.sign(sin(a))*abs(sin(a))**.48) for a in np.arange(48)*2*pi/48]
 tube(label+' bezel',pts,size*.033,bright,g,True)
 for s in (-1,1):line(label+' uprights',[pt(s*.24,.35),pt(s*.16,-.02),pt(s*.13,-.32)],size*.049,bright,g)
 tube(label+' crossbar',[pt(-.15,-.05),pt(.15,-.05)],size*.054,bright,g)
badge('Honda grille H',front(0,.851,.022),(-1,0,.15),.087,body)
badge('Honda deck H',rear(0,.931,.018),(1,0,.06),.075,hatch)
text_label('Civic script','C I V I C',rear(-.551,.913,.017),.029,bright,(1,0,0),hatch)
text_label('EX designation','EX',rear(.519,.907,.017),.026,bright,(1,0,0),hatch)
# Asymmetric fuel flap on driver's rear quarter.
def fuel(a):
 xx=1.57+.095*np.sign(cos(a))*abs(cos(a))**.46;z=.848+.087*np.sign(sin(a))*abs(sin(a))**.46
 t=(z-lower(xx))/(topline(xx)-lower(xx));p=side(xx,t,-1);p[1]-=.003;return p
tube('Fuel filler lid gap',[fuel(a) for a in np.arange(64)*2*pi/64],.0026,trim,body,True)
p=np.array([2.20,.49,.264])
disk('Exhaust tailpipe',p,(1,0,0),(0,1,0),[(.024,-.08),(.028,.01),(.024,.012),(.023,-.024)],steel)
