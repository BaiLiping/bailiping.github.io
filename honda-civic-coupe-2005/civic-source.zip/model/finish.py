"""2004–05 bumper openings, optics, brightwork and rear deck face."""
from shell import *
def front(k,t,depth=.006):
 p=fascia(k,t); p+=np.array([-depth,depth*np.sign(k)*abs(k)**4,depth*.30*t]);return p
def rear(k,t,depth=.006):
 p=bodypoint(tail,t,k);p+=np.array([depth,depth*np.sign(k)*abs(k)**4,0]);return p
def boundary(n,fn,r,m,g=body):
 pts=[fn(u,0) for u in span(41)]+[fn(1,v) for v in span(12)[1:]]+[fn(u,1) for u in span(41)[-2::-1]]+[fn(0,v) for v in span(12)[-2:0:-1]]
 return tube(n,pts,r,m,g,True)
def grill(u,v):
 w=2*u-1
 half=.375+.128*v+.020*sin(pi*v)
 k=w*half
 t=.797+.184*v+.065*abs(w)**4*(1-v)
 return front(k,t,.002)
patch('Upper grille pocket',grill,span(69),span(20),void,body,(-1,0,0))
boundary('Upper grille surround',grill,.004,trim)
web=material('Injection molded grille web',(.039,.044,.046),.17,.47)
# Shallow open cells sit ahead of the recessed backing plate.
for j in range(4):
 for i in range(-13,14):
    u=.5+(i+.5*(j%2))*.0445;v=.175+.21*j
    if not .023<u<.977:continue
    pts=[grill(u+.026*cos(a),v+.132*sin(a))+[-.006,0,0] for a in np.arange(6)*pi/3]
    tube('Honeycomb grille',pts,.0016,web,body,True,5)
def lowint(u,v):
 w=2*u-1
 k=w*(.526-.062*v-.018*(1-v)**3)
 return front(k,.139+.203*v+.027*abs(w)**5*(1-v),.002)
patch('Lower radiator intake',lowint,span(66),span(20),void,body,(-1,0,0))
for v in [.18,.52,.86]:tube('Radiator louvre',[lowint(u,v)+[-.004,0,0] for u in span(48)],.0036,web)
for u in [.18,.39,.61,.82]:
 tube('Radiator louvre support',[lowint(u,v)+[-.0005,0,0] for v in span(15)],.0023,trim)
for s in (-1,1):
 def duct(u,v):
    k=s*(.590+.170*u+.013*v+.035*v*u)
    t=.147+.199*v+.105*u**3.5*(1-v)
    return front(k,t,.002)
 patch('Outer bumper opening',duct,span(41),span(18),void,body,(-1,s*.6,0))
 for level in [.22,.40,.58,.76,.92]:
    tube('Corner duct vane',[duct(u,level)+[-.004,s*.0015,0] for u in np.linspace(.05,.95,28)],.0035,web)
 # Broad body-coloured ribs mount inside the single continuous lower aperture.
 # Their leading shoulder is flush with the lip, their back edge meets the duct.
 def rib(u,v):
    inside=.526-.064*v
    outside=.589+.013*v
    p=bodypoint(nose,.127+.224*v,s*float(mix(inside,outside,u)))
    p[0]+=.019+.021*(2*u-1)**4+.017*sin(pi*v)
    return p
 patch('Front bumper intake rib',rib,span(18),span(24),paint,body,(-1,s*.2,0))
 for edge in [0,1]:
    patch('Front bumper intake rib side',lambda v,d:rib(edge,v)+[d*.033,-s*.002*d,0],span(27),span(5),paint,body)
# The lenses sweep from the center grille back over the fender. Rim coordinates
# come from the inner point and tapered wing corner of the stock EX headlamps.
def lamp_surface(u,v,s,depth=0):
 k,t=lamp_coords(u,v)
 p=bodypoint(nose,t,s*k)
 angle=1.16*k**3
 return p+np.array([-cos(angle),s*sin(angle),.21])*depth
silver=material('Optical vacuum aluminium',(.77,.82,.86),.85,.16,.20)
lamp_chrome=material('Reflector bright folds',(.78,.83,.86),.66,.17,.23)
amberlight=material('Amber lens prism',(.93,.255,.017),.16,.19,.33)
for s in (-1,1):
 def lens(u,v,depth=.006):return lamp_surface(u,v,s,depth)
 patch('Reflector housing back',lambda u,v:lens(u,v,-.031),span(64),span(23),silver,body,(-1,s*.45,.3))
 boundary('Headlamp gasket',lambda u,v:lens(u,v,.004),.0024,rubber)
 boundary('Headlamp chrome moulding',lambda u,v:lens(u,v,.006),.0018,silver)
 for mid,wide,height in [(.239,.159,.386),(.572,.211,.421)]:
    # Each halogen chamber has a concave, stepped aluminized bowl. Rings are
    # concentric about the bulb; radial facets alternate direction around it.
    def xy(a,r):
       ca,sa=cos(a),sin(a)
       # Broad rectangular reflector boxes have chamfered corners and an
       # inboard wall that leans towards the grille at its lower end.
       x=math.copysign(abs(ca)**.76,ca)
       y=math.copysign(abs(sa)**.74,sa)
       return mid+wide*r*x+.016*r*y,.513+height*r*y-.022*r*x
    def dish(a,r):
       u,v=xy(a,r)
       return lens(u,v,-.024+.0315*r*r)
    facets_count=18
    verts=[];faces=[];facemats=[]
    radii=[.12,.35,.57,.77,.94,1]
    for j in range(len(radii)-1):
       for i in range(facets_count):
          a=2*pi*i/facets_count;b=2*pi*(i+1)/facets_count
          pts=[dish(a,radii[j]),dish(b,radii[j]),dish(b,radii[j+1]),dish(a,radii[j+1])]
          # Each reflective sector has a small optical step, with the step
          # staggering on alternate rows rather than forming a smooth dish.
          ridge=dish((a+b)*.5, .55*radii[j]+.45*radii[j+1])+[-.0008-.0003*(i%3),s*.00045,.00025*(-1)**i]
          idx=len(verts);verts.extend(pts+[ridge])
          for entry in [(0,1,4),(1,2,4),(2,3,4),(3,0,4)]:
             face=tuple(idx+k for k in entry)
             faces.append(face if s>0 else face[::-1])
             facemats.append((i%4==0 and j<5) or (i%6==1 and j>=5))
    # The export batches per object material, so keep both optical finishes
    # on separate faces even in the small mobile asset.
    for use_bright,finish in [(False,silver),(True,lamp_chrome)]:
       selected=[face for face,bright_facet in zip(faces,facemats) if bright_facet==use_bright]
       mesh('Parabolic reflector facets',verts,selected,finish,body,False)
    for i in range(16):
       a=2*pi*i/16+.028
       tube('Headlamp reflector flute',[dish(a+.016*r,r)+[-.0006,0,0] for r in np.linspace(.43,.93,11)],.00085,bright)
    for r in [1.]:
       tube('Headlamp circular reflector bead',[dish(a,r) for a in np.arange(56)*2*pi/56],.00125,bright,body,True)
    pt=lens(mid,.513,-.017);direction=np.array([-cos(.93*(mid*.5+.48)**3),s*sin(.93*(mid*.5+.48)**3),.23])
    cylinder('Headlamp halogen socket',pt-.005*direction,pt+.011*direction,.010,graphite,body,24)
    oval('Halogen bulb shield',pt+direction*.014,(.005,.007,.005),bright)
    tube('Halogen bulb shield clip',[pt+direction*.004+[0,0,-.012],pt+direction*.013+[0,0,-.003]],.0015,silver)
 for v in [.10,.18]:
    tube('Lower optical flute',[lens(u,v,.0005) for u in np.linspace(.10,.76,43)],.0011,silver)
 def indicator(u,v):return lens(.817+.093*u-.026*sin(pi*v),.15+.700*v,.004)
 patch('Amber corner reflector',indicator,span(20),span(16),amberlight,body,(-1,s*.6,.1))
 for t in np.linspace(.05,.95,11):
    tube('Indicator lens fluting',[indicator(t,v)+[-.001,s*.001,0] for v in span(16)],.0008,amber)
 patch('Headlamp outer bright reflector',lambda u,v:lens(.913+.075*u,.12+.76*v,.002),span(13),span(14),lamp_chrome,body,(-1,s*.7,.2))
 for edge in [0,1]:
    patch('Lens edge barrel',lambda v,w:mix(lens(edge,v,-.011),lens(edge,v,.012),w),span(21),span(4),trim,body)
 clear=material('Clear optical polycarbonate '+str(s),(.55,.68,.74),.05,.09,.61,.12)
 patch('Clear headlamp cover',lambda u,v:lens(u,v,.014+.003*sin(pi*u)*sin(pi*v)),span(50),span(22),clear,body,(-1,s*.5,.26))
 # Vertical aft edge and tapered forward tip follow the triangular quarter lamp.
 def taillight(u,v):
    # sweep along the side, then across the corner to the trunk seam
    t=.614+.331*v
    # Walk the lamp from its pointed forward corner, around the rolled rear fascia, to the jamb.
    travel=float(mix(.895*v**.83,1,u))
    if travel<.55:
       xx=float(mix(1.968,tail,travel/.55));p=side(xx,t,s);p[1]+=s*.004
    else:
       k=1-(.335-.054*v)*(travel-.55)/.45;p=rear(s*k,t,.006)
    return p
 # The red lens wraps around the quarter. Lay the optical cups on the actual
 # rear-facing portion, so their rings retain their circular form around the corner.
 lens_red=material('Stop lens red '+str(s),(.76,.008,.012),.11,.18,.82)
 facets=material('Stop reflector prisms '+str(s),(.69,.013,.017),.26,.26,.53)
 patch('Triangular tail lamp',taillight,span(77),span(29),lens_red,body,(1,s,0))
 boundary('Rear lamp gasket',taillight,.0027,rubber)
 def tailface(k,t,d):return rear(s*k,t,d)
 def circular(name,k,t,r,mat,depth):
    # Both parameters are physical in the face plane. k is a half-width
    # fraction and t is a fraction of the local deck-to-valance height.
    def pt(a,f,offset=0):
       kk=k+r*cos(a)*f/.81;tt=t+r*sin(a)*f/.745
       return tailface(kk,tt,depth+offset)
    patch(name,lambda a,f:pt(a,f,.002*(1-f*f)),np.linspace(0,2*pi,49),np.linspace(.001,1,11),mat,body,(1,s*.3,0))
    for f0 in ([.89,.98] if name.startswith('Reversing') else []):
       tube(name+' optical ring',[pt(a,f0,.0018) for a in np.arange(50)*2*pi/50],.0012,bright if name.startswith('Reversing') else lens_red,body,True)
    # Split molded optical facets preserve the clear circular chamber in the white
    # reversing lamp without drawing wire rings over the outer surface.
    if name.startswith('Reversing'):
       for j in range(16):
          a=2*pi*j/16;b=2*pi*(j+1)/16
          pts=[pt(a,.26,.001),pt(b,.26,.001),pt(b,.85,.001),pt(a,.85,.001),pt((a+b)*.5,.56,.0021)]
          faces=[(0,1,4),(1,2,4),(2,3,4),(3,0,4)]
          mesh(name+' radial prism',pts,faces if s>0 else [f[::-1] for f in faces],ivory,body,False)
    else:
       # Fine horizontal lenticules diffuse the filament through the red cover.
       for yy in np.linspace(-.85,.85,12):
          extent=math.sqrt(1-yy*yy)*.87
          pts=[pt(math.atan2(yy,xx),math.hypot(xx,yy),.0018) for xx in np.linspace(-extent,extent,18)]
          tube(name+' diffuser',pts,.00075,facets,body)
 # The round reversing optic sits low against the trunk opening, with the
 # larger red stop and turn chambers immediately above and outboard.
 circular('Reversing lens',.771,.716,.034,ivory,.0095)
 circular('Tail lamp upper stop bowl',.800,.855,.033,facets,.008)
 circular('Tail lamp outer stop bowl',.910,.753,.047,lens_red,.0095)
 for j in range(13):
    v=.08+.825*j/12
    tube('Tail lamp lens fluting',[taillight(u,v)+[.002,s*.0014,0] for u in np.linspace(.070,.54,42)],.00085,facets)
 for j in range(10):
    u=.085+.41*j/9
    tube('Tail lamp vertical prism',[taillight(u,v)+[.0021,s*.0012,0] for v in np.linspace(.11,.77,25)],.0008,facets)
 # One smooth transparent cover follows the triangular housing over all three optics.
 clear_tail=material('Taillamp molded clear coat '+str(s),(.66,.60,.60),.04,.13,.75,.11)
 patch('Tail lens outer cover',lambda u,v:taillight(u,v)+np.array([.011,.004*s,.0004]),span(68),span(29),clear_tail,body,(1,s,0))
# Trunk face and shaped plate pocket are carried by the lid with the latch and emblems.
def trunk(u,v):
 k=(2*u-1)*(.655+.075*v)
 t=.584+.410*v+.032*(abs(2*u-1)**5)*(1-v)
 p=rear(k,t,.008)
 # Press a continuous pocket into the sheet, with a rounded bottom and
 # tapered walls. Its projecting header shades the registration plate.
 half=.288+.111*clip((t-.633)/.205)
 inside=smooth((half-abs(k))/.038)*smooth((t-.628)/.033)*smooth((.854-t)/.041)
 p[0]-=.049*inside
 return p
patch('Trunk vertical pressing',trunk,span(105),span(71),paint,hatch,(1,0,0))
boundary('Trunk peripheral seam',trunk,.0019,rubber,hatch)
def plate_garnish(u,v):
 k=(2*u-1)*.397
 weight=sin(pi*u)**.55
 t=.833+.030*v
 p=rear(k,t,.009)
 p[0]+=.026*weight*(.45+.55*sin(pi*v));p[2]+=.002*weight
 return p
patch('Deck release garnish',plate_garnish,span(55),span(15),paint,hatch,(1,0,0))
tube('Deck release shadow',[plate_garnish(u,0) for u in np.linspace(.035,.965,44)],.0028,trim,hatch)
p=rear(0,.73,.009);p[0]-=.043
box('License plate',p,(.008,.305,.148),ivory,hatch,.005)
for sk in (-1,1):
 oval('Plate fastener',p+[.006,sk*.085,.057],(.002,.005,.005),steel,hatch)
text_label('Civic plate','CIVIC',p+[.005,0,0],.05,trim,(1,0,0),hatch)
def badge(label,p,normal,size,g):
 n=np.array(normal,dtype=float);n/=np.linalg.norm(n);right=np.cross((0,0,1),n);right/=np.linalg.norm(right);up=np.cross(n,right)
 def pt(u,v):return p+size*(u*right+v*up)
 pts=[pt(.48*np.sign(cos(a))*abs(cos(a))**.50,.43*np.sign(sin(a))*abs(sin(a))**.48) for a in np.arange(48)*2*pi/48]
 tube(label+' bezel',pts,size*.033,bright,g,True)
 for s in (-1,1):line(label+' uprights',[pt(s*.24,.35),pt(s*.16,-.02),pt(s*.13,-.32)],size*.049,bright,g)
 tube(label+' crossbar',[pt(-.15,-.05),pt(.15,-.05)],size*.054,bright,g)
badge('Honda grille H',front(0,.878,.017),(-1,0,.19),.107,body)
badge('Honda deck H',rear(0,.931,.018),(1,0,.06),.075,hatch)
text_label('Civic script','C I V I C',rear(-.551,.913,.017),.029,bright,(1,0,0),hatch)
text_label('EX designation','EX',rear(.519,.907,.017),.026,bright,(1,0,0),hatch)
# Asymmetric fuel flap on driver's rear quarter.
def fuel(a):
 xx=1.57+.095*np.sign(cos(a))*abs(cos(a))**.46;z=.848+.087*np.sign(sin(a))*abs(sin(a))**.46
 t=(z-lower(xx))/(topline(xx)-lower(xx));p=side(xx,t,-1);p[1]-=.003;return p
tube('Fuel filler lid gap',[fuel(a) for a in np.arange(64)*2*pi/64],.0026,trim,body,True)
p=np.array([2.20,.49,.264])
disk('Exhaust tailpipe',p,(1,0,0),(0,1,0),[(.024,-.08),(.028,.01),(.024,.012),(.023,-.024)],steel)
