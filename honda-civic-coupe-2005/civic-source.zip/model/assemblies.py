"""Keep removable components distinct in the master and its material-batched export."""
import json
from pathlib import Path

VIEW = [-0.58, 0.92, 1.45]

# Group small attached details with the piece that carries them. Blender may append
# numeric suffixes to duplicate object names, so these are stable name prefixes.
PAIRED_BODY = {
    'Headlamp': ('Headlamp', 'Reflector housing', 'Parabolic reflector', 'Angled dividing',
                 'Lower optical', 'Halogen bulb', 'Amber corner', 'Indicator lens', 'Lens edge barrel', 'Clear headlamp'),
    'Taillamp': ('Triangular tail lamp', 'Rear lamp gasket', 'Lens band', 'Red reflector chamber',
                 'Tail lens', 'Tail lamp', 'Reversing lens', 'Reverse bulb'),
    'Fender': ('Front wing', 'Front fender crown'),
    'QuarterGlass': ('Quarter light', 'Quarter lower gasket'),
}
BODY = {
    'FrontBumper': ('Front bumper', 'Lower radiator intake', 'Lower intake', 'Radiator louvre',
                    'Outer bumper opening', 'Corner duct', 'Upper grille', 'Honeycomb grille', 'Honda grille'),
    'RearBumper': ('Rear bumper',),
    'Windshield': ('Windscreen frit', 'Windscreen.', 'Rearview mirror', 'Interior mirror glass'),
    'BackGlass': ('Fixed rear glass', 'Rear glass heater'),
    'Moonroof': ('Moonroof', 'EX glass moonroof'),
    'Radiator': ('Radiator core', 'Radiator fins', 'Cooling pack'),
    'Exhaust': ('Exhaust tailpipe',),
}
SEAT = ('Contoured bucket', 'Woven cushion', 'Seat side', 'Squab welt', 'Front squab',
        'Contoured front backrest', 'Woven backrest', 'Backrest', 'Side bolster', 'Headrest', 'Padded head', 'Seat rail', 'Seat base pan', 'Seat release', 'Seat belt', 'Seat backrest cross', 'Seat cushion cross')
INTERIOR = {
    'RearBench': ('Rear seat', 'Split rear backrest', 'Rear backrest'),
    'Interior': ('Cabin trim A pillar', 'Carpet footwell', 'Rear side cabin'),
    'ParcelShelf': ('Rear parcel', 'Centre brake light'),
    'LuggageLiner': ('Luggage floor','Curved cargo','Trunk wheelhouse'),
    'Console': ('Tunnel console', 'Shift', 'Five-speed shift', 'Leather shift', 'Gathered black', 'Handbrake', 'Console armrest'),
    'Steering': ('Three-spoke steering', 'Upper wheel spoke', 'Lower wheel spoke', 'Steering',
                 'Contoured three-spoke', 'Airbag embossing', 'Cruise switch', 'Cruise key'),
}
ENGINE = {
    'Transaxle': ('Manual transmission', 'Gearbox'),
    'OilPan': ('D17 oil pan',),
    'CylinderHead': ('D17 cylinder head',),
    'ValveCover': ('D17 valve cover','Oil filler screw cap'),
    'AccessoryDrive': ('D17 accessory',),
    'Intake': ('Air filter', 'Intake duct'),
    'Battery': ('Battery',),
    'Radiator': ('Upper radiator hose',),
}
LABELS = {
    'Body':'Unit body', 'Hood':'Hood', 'Trunk':'Trunk lid', 'FrontBumper':'Front bumper and grille',
    'RearBumper':'Rear bumper', 'Windshield':'Windshield and interior mirror', 'BackGlass':'Heated rear window',
    'Moonroof':'Moonroof glass', 'RearBench':'Rear seat', 'Interior':'Passenger carpet and side trim', 'LuggageLiner':'Luggage carpet and wheelhouse lining',
    'SpareWheel':'Compact spare wheel', 'ParcelShelf':'Parcel shelf and high-mounted brake light',
    'Dashboard':'Dashboard and instruments', 'Console':'Console and gear lever', 'Steering':'Steering wheel and stalks',
    'OilPan':'Engine oil pan', 'CylinderHead':'SOHC cylinder head',
    'ValveCover':'Valve cover', 'AccessoryDrive':'Accessory belt and alternator',
    'Engine':'D17A2 engine block', 'IgnitionCover':'Ignition cover and coils', 'Transaxle':'Five-speed transaxle',
    'Intake':'Air cleaner and intake duct', 'Battery':'Battery', 'Radiator':'Radiator and upper hose',
    'Exhaust':'Exhaust system', 'FuelTank':'Fuel tank', 'Subframes':'Subframes and anti-roll bars',
}


def reorganize():
    import bpy
    from geometry import groups
    from mathutils import Vector
    bpy.context.view_layer.update()

    def match(name, rules):
        return next((group for group, prefixes in rules.items() if name.startswith(prefixes)), None)

    def ensure(name, parent):
        if name not in groups:
            existing = bpy.data.objects.get(name)
            if existing is not None:
                existing.name = name + " geometry"
            target = bpy.data.objects.new(name, None)
            bpy.context.collection.objects.link(target)
            target.parent = parent
            target.matrix_parent_inverse = parent.matrix_world.inverted()
            groups[name] = target
        return groups[name]

    for ob in list(bpy.context.scene.objects):
        if ob.type not in ('MESH', 'FONT') or not ob.parent:
            continue
        parent = ob.parent
        name = ob.name
        mid = ob.matrix_world @ (sum((Vector(p) for p in ob.bound_box), Vector()) / 8)
        side = 'Left' if mid.y < 0 else 'Right'
        group = None
        if parent.name == 'Body':
            paired = match(name, PAIRED_BODY)
            group = paired + side if paired else match(name, BODY)
            if name == 'Windscreen':
                group = 'Windshield'
            if name.startswith(('Fender and door shoulder', 'Upper swage line', 'Rolled arch return', 'Sill shoulder bridge')) and mid.x < -0.97:
                group = 'Fender' + side
        elif parent.name in ('DoorLeft','DoorRight'):
            kind = match(name, {
                'DoorGlass': ('Door glass',),
                'DoorTrim': ('Door card', 'Door armrest', 'Window control', 'Door speaker', 'Door latch trim', 'Inner latch'),
                'Mirror': ('Door mirror', 'Mirror foot', 'Color keyed mirror', 'Mirror face'),
            })
            group = kind + side if kind else None
        elif parent.name == 'Interior':
            group = ('Seat' + side) if name.startswith(SEAT) else (match(name, INTERIOR) or 'Dashboard')
        elif parent.name == 'Powertrain':
            group = ('Halfshaft' + side) if name.startswith(('Drive axle', 'CV boot')) else (match(name, ENGINE) or 'Engine')
        elif parent.name.startswith('Wheel'):
            corner = parent.name.removeprefix('Wheel')
            if name.startswith(('195/60', 'Tire sidewall', 'Tread', 'Sidewall', 'Circumferential tread', 'Tire carcass', 'Tire casing')):
                group = 'Tire' + corner
            elif name.startswith(('Brake', 'Pad contact')):
                group = 'Brake' + corner

        if group and group != parent.name:
            world = ob.matrix_world.copy()
            # The radiator hose and exhaust tip belong to assemblies outside their
            # initial source parent. Preserve the parent of the existing assembly.
            if group == 'Radiator':
                parent = groups['Body']
            target = ensure(group, parent)
            ob.parent = target
            ob.matrix_parent_inverse = target.matrix_world.inverted()
            ob.matrix_basis = world


def label(name):
    if name in LABELS:
        return LABELS[name]
    for side, prefix in [('Left','Left'), ('Right','Right')]:
        if not name.endswith(side):
            continue
        kind = name[:-len(side)]
        paired = {'Door':'door', 'DoorGlass':'door glass', 'DoorTrim':'inner door trim', 'Mirror':'door mirror', 'QuarterGlass':'rear quarter glass', 'Seat':'front seat', 'Fender':'front fender',
                  'Headlamp':'headlight', 'Taillamp':'taillight', 'Halfshaft':'front halfshaft'}
        if kind in paired:
            return prefix + ' ' + paired[kind]
        for axle in ('Front', 'Rear'):
            if kind.endswith(axle):
                component = kind[:-len(axle)]
                noun = {'Wheel':'alloy wheel', 'Tire':'tire', 'Brake':('disc brake' if axle == 'Front' else 'drum brake'),
                        'Suspension':'suspension'}[component]
                return f'{prefix} {axle.lower()} {noun}'
    raise KeyError('Missing component name: ' + name)


def design_offset(name, center):
    """Initial removal directions, in the viewer's right-handed Y-up meter frame."""
    side = 1 if name.endswith('Left') else -1
    forward = -1 if center[0] < 0 else 1
    offsets = {
        'Body': (0, .55, 0), 'Hood': (-.95, 2.25, 0), 'Trunk': (.90, 1.88, 0),
        'FrontBumper': (-2.6, .24, 0), 'RearBumper': (2.2, .19, 0),
        'Windshield': (-.25, 2.07, 0), 'BackGlass': (.45, 2.12, 0), 'Moonroof': (0, 2.70, 0),
        'Dashboard': (-.48, 1.35, 0), 'Steering': (-.22, 1.43, .65), 'Console': (0, 1.03, .39),
        'RearBench': (.61, 1.24, -.53), 'Interior': (.32, -.80, 0),
        'OilPan': (-2.12,.36,.33), 'CylinderHead': (-2.12,1.46,.36),
        'ValveCover': (-2.13,1.65,.39), 'AccessoryDrive': (-2.10,.93,.82),
        'Engine': (-2.11, 1.10, .30), 'IgnitionCover': (-2.16, 1.73, .32),
        'Transaxle': (-1.88, .76, -.82), 'Intake': (-1.76, 1.38, -.84), 'Battery': (-2.27, .88, -1.17),
        'Radiator': (-2.31, .46, -.27), 'Exhaust': (.68, -1.80, .59), 'FuelTank': (.50, -1.52, -.50),
        'Subframes': (0, -1.15, 0), 'ParcelShelf': (.88,1.07,.22), 'SpareWheel': (1.25,-.85,.52), 'LuggageLiner': (1.12,.88,-.38),
    }
    if name in offsets:
        return offsets[name]
    for prefix, offset in [
        ('DoorTrim', (.26, .04, side*1.50)), ('Mirror', (-.22, 1.24, side*2.23)),
        ('QuarterGlass', (.37, 1.51, side*.92)),
        ('DoorGlass', (0, 1.20, side*1.59)), ('Door', (0, .44, side*1.71)),
        ('Headlamp', (-2.10, .69, side*.83)), ('Taillamp', (1.57, .82, side*.83)),
        ('Fender', (-.81, 1.08, side*1.23)), ('Seat', (.05, 1.75, side*.68)),
        ('Halfshaft', (-1.48, .34, side*1.17)),
        ('Tire', (forward*.77, -.38, side*2.88)), ('Wheel', (forward*.61, -.38, side*2.08)),
        ('Brake', (forward*.49, -.29, side*1.42)), ('Suspension', (forward*.25, -.25, side*.88)),
    ]:
        if name.startswith(prefix):
            return offset
    raise KeyError(name)


def save_layout(groups, destination):
    """Clear projected overlaps while preserving each component's intended removal axis."""
    import numpy as np
    import bpy
    bpy.context.view_layer.update()
    direction = np.asarray(VIEW) / np.linalg.norm(VIEW)
    right = np.cross([0, 1, 0], direction)
    right /= np.linalg.norm(right)
    up = np.cross(direction, right)
    axes = np.array([right, up, direction])
    entries = []
    for name, group in groups.items():
        meshes = [ob for ob in group.children if ob.type == 'MESH']
        if not meshes:
            continue
        bounds = []
        for ob in meshes:
            coords = np.empty(len(ob.data.vertices)*3, dtype=np.float32)
            ob.data.vertices.foreach_get('co', coords)
            matrix = np.asarray(ob.matrix_world)
            points = coords.reshape(-1,3) @ matrix[:3,:3].T + matrix[:3,3]
            points = points[:,[0,2,1]]
            points[:,2] *= -1
            bounds.append(points @ axes.T)
        xyz = np.concatenate(bounds)
        lo, hi = xyz.min(0), xyz.max(0)
        mid = (lo+hi)/2
        nominal = np.array(design_offset(name, mid @ axes))
        desired = mid + axes @ nominal
        entries.append((name, mid, desired, (hi-lo)/2))

    # Place the largest outlines first. Candidate edges come from already placed
    # outlines, so the nearest clear location leaves the original spatial ordering recognizable.
    def place(portrait):
        occupied, offsets = [], {}
        for name, mid, desired, half in sorted(entries, key=lambda e: -np.prod(e[3][:2])):
            target = desired.copy()
            if portrait:
                # Put the nose assembly above the shell and rear assembly below.
                # This leaves room for a full-width chassis in the centre on phones.
                target[0], target[1] = .85*desired[1], -1.22*desired[0]
            target[2] *= .40
            pad = half[:2]*1.12 + .065
            xs = [target[0]] + [edge for x,y,w,h in occupied for edge in (x-w-pad[0],x+w+pad[0])]
            ys = [target[1]] + [edge for x,y,w,h in occupied for edge in (y-h-pad[1],y+h+pad[1])]
            def distance(p):
                du, dv = p[0]-target[0], p[1]-target[1]
                if portrait:
                    overflow = max(0,abs(p[0])+pad[0]-2.5)
                    return 2*du**2 + dv**2 + 100*overflow**2
                return du**2 + 1.5*dv**2
            candidates = sorted(((x,y) for x in xs for y in ys), key=distance)
            for x,y in candidates:
                if all(abs(x-ox)>=pad[0]+w-1e-7 or abs(y-oy)>=pad[1]+h-1e-7 for ox,oy,w,h in occupied):
                    target[:2] = [x,y]
                    occupied.append((x,y,*pad))
                    break
            offsets[name] = (target-mid) @ axes
        return offsets

    world_offsets = place(False)
    portrait_offsets = place(True)
    parts = []
    for name in sorted(world_offsets, key=label):
        ancestor = groups[name].parent
        while ancestor and ancestor.name not in world_offsets:
            ancestor = ancestor.parent
        inherited = world_offsets[ancestor.name] if ancestor else 0
        local = world_offsets[name] - inherited
        portrait = portrait_offsets[name] - (portrait_offsets[ancestor.name] if ancestor else 0)
        parts.append(dict(node=name, label=label(name), offset=local.round(5).tolist(),
                          portraitOffset=portrait.round(5).tolist()))
    destination.write_text(json.dumps(dict(parts=parts, explodedDirection=VIEW), indent=2))


def configure(cfg, layout=None):
    if layout is None:
        layout = Path(__file__).with_name('assembly-layout.json')
    cfg.update(json.loads(layout.read_text()))
    part_names = {p['node'] for p in cfg['parts']}
    for action in cfg['actions']:
        if action['label'] == 'Lower driver window':
            action['nodes'] = [dict(node='DoorGlassLeft', hidden=True)]
        elif action['label'] == 'Isolate ignition cover':
            # Keep the Powertrain parent visible for the cover's original hierarchy.
            action['nodes'] = [dict(node=name, hidden=True) for name in sorted(part_names - {'IgnitionCover'})]
