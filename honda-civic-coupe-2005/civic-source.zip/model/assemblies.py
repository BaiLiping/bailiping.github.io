"""Keep removable components distinct in the master and its material-batched export."""
import json
from pathlib import Path

VIEW = [-0.58, 0.92, 1.45]

# Group small attached details with the piece that carries them. Blender may append
# numeric suffixes to duplicate object names, so these are stable name prefixes.
PAIRED_BODY = {
    'Headlamp': ('Headlamp', 'Reflector housing', 'Parabolic reflector', 'Angled dividing',
                 'Lower optical', 'Halogen bulb', 'Amber corner', 'Indicator lens', 'Lens edge barrel', 'Clear headlamp'),
    'Taillamp': ('Triangular tail lamp', 'Rear lamp gasket', 'Lens band', 'Red reflector chamber',
                 'Tail lens', 'Tail lamp', 'Reversing lens', 'Reverse bulb'),
    'Fender': ('Front wing', 'Front fender crown'),
    'QuarterGlass': ('Quarter light', 'Quarter lower gasket'),
}
BODY = {
    'FrontBumper': ('Front bumper', 'Lower radiator intake', 'Lower intake', 'Radiator louvre',
                    'Outer bumper opening', 'Corner duct', 'Upper grille', 'Honeycomb grille', 'Honda grille'),
    'RearBumper': ('Rear bumper',),
    'Windshield': ('Windscreen frit', 'Windscreen.', 'Rearview mirror', 'Interior mirror glass'),
    'BackGlass': ('Fixed rear glass', 'Rear glass heater'),
    'Moonroof': ('Moonroof', 'EX glass moonroof'),
    'Radiator': ('Radiator core', 'Radiator fins', 'Cooling pack'),
    'Exhaust': ('Exhaust tailpipe',),
}
SEAT = ('Contoured bucket', 'Woven cushion', 'Seat side', 'Squab welt', 'Front squab',
        'Contoured front backrest', 'Woven backrest', 'Backrest', 'Side bolster', 'Headrest', 'Padded head', 'Seat rail', 'Seat base pan', 'Seat release', 'Seat belt', 'Seat backrest cross', 'Seat cushion cross')
INTERIOR = {
    'RearBench': ('Rear seat', 'Split rear backrest', 'Rear backrest'),
    'Interior': ('Cabin trim A pillar', 'Carpet footwell', 'Rear side cabin'),
    'ParcelShelf': ('Rear parcel', 'Centre brake light'),
    'LuggageLiner': ('Luggage floor','Curved cargo','Trunk wheelhouse'),
    'Console': ('Tunnel console', 'Shift', 'Five-speed shift', 'Leather shift', 'Gathered black', 'Handbrake', 'Console armrest'),
    'Steering': ('Three-spoke steering', 'Upper wheel spoke', 'Lower wheel spoke', 'Steering',
                 'Contoured three-spoke', 'Airbag embossing', 'Cruise switch', 'Cruise key'),
}
ENGINE = {
    'Transaxle': ('Manual transmission', 'Gearbox'),
    'OilPan': ('D17 oil pan',),
    'CylinderHead': ('D17 cylinder head',),
    'ValveCover': ('D17 valve cover','Oil filler screw cap'),
    'AccessoryDrive': ('D17 accessory',),
    'Intake': ('Air filter', 'Intake duct'),
    'Battery': ('Battery',),
    'Radiator': ('Upper radiator hose',),
}
LABELS = {
    'Body':'Unit body', 'Hood':'Hood', 'Trunk':'Trunk lid', 'FrontBumper':'Front bumper and grille',
    'RearBumper':'Rear bumper', 'Windshield':'Windshield and interior mirror', 'BackGlass':'Heated rear window',
    'Moonroof':'Moonroof glass', 'RearBench':'Rear seat', 'Interior':'Passenger carpet and side trim', 'LuggageLiner':'Luggage carpet and wheelhouse lining',
    'SpareWheel':'Compact spare wheel', 'ParcelShelf':'Parcel shelf and high-mounted brake light',
    'Dashboard':'Dashboard and instruments', 'Console':'Console and gear lever', 'Steering':'Steering wheel and stalks',
    'OilPan':'Engine oil pan', 'CylinderHead':'SOHC cylinder head',
    'ValveCover':'Valve cover', 'AccessoryDrive':'Accessory belt and alternator',
    'Engine':'D17A2 engine block', 'IgnitionCover':'Ignition cover and coils', 'Transaxle':'Five-speed transaxle',
    'Intake':'Air cleaner and intake duct', 'Battery':'Battery', 'Radiator':'Radiator and upper hose',
    'Exhaust':'Exhaust system', 'FuelTank':'Fuel tank', 'Subframes':'Subframes and anti-roll bars',
}


def reorganize():
    import bpy
    from geometry import groups
    from mathutils import Vector
    bpy.context.view_layer.update()

    def match(name, rules):
        return next((group for group, prefixes in rules.items() if name.startswith(prefixes)), None)

    def ensure(name, parent):
        if name not in groups:
            existing = bpy.data.objects.get(name)
            if existing is not None:
                existing.name = name + " geometry"
            target = bpy.data.objects.new(name, None)
            bpy.context.collection.objects.link(target)
            target.parent = parent
            target.matrix_parent_inverse = parent.matrix_world.inverted()
            groups[name] = target
        return groups[name]

    for ob in list(bpy.context.scene.objects):
        if ob.type not in ('MESH', 'FONT') or not ob.parent:
            continue
        parent = ob.parent
        name = ob.name
        mid = ob.matrix_world @ (sum((Vector(p) for p in ob.bound_box), Vector()) / 8)
        side = 'Left' if mid.y < 0 else 'Right'
        group = None
        if parent.name == 'Body':
            paired = match(name, PAIRED_BODY)
            group = paired + side if paired else match(name, BODY)
            if name == 'Windscreen':
                group = 'Windshield'
            if name.startswith(('Fender and door shoulder', 'Upper swage line', 'Rolled arch return', 'Sill shoulder bridge')) and mid.x < -0.97:
                group = 'Fender' + side
        elif parent.name in ('DoorLeft','DoorRight'):
            kind = match(name, {
                'DoorGlass': ('Door glass',),
                'DoorTrim': ('Door card', 'Door armrest', 'Window control', 'Door speaker', 'Door latch trim', 'Inner latch'),
                'Mirror': ('Door mirror', 'Mirror foot', 'Color keyed mirror', 'Mirror face'),
            })
            group = kind + side if kind else None
        elif parent.name == 'Interior':
            group = ('Seat' + side) if name.startswith(SEAT) else (match(name, INTERIOR) or 'Dashboard')
        elif parent.name == 'Powertrain':
            group = ('Halfshaft' + side) if name.startswith(('Drive axle', 'CV boot')) else (match(name, ENGINE) or 'Engine')
        elif parent.name.startswith('Wheel'):
            corner = parent.name.removeprefix('Wheel')
            if name.startswith(('195/60', 'Tire sidewall', 'Tread', 'Sidewall', 'Circumferential tread', 'Tire carcass', 'Tire casing')):
                group = 'Tire' + corner
            elif name.startswith(('Brake', 'Pad contact')):
                group = 'Brake' + corner

        if group and group != parent.name:
            world = ob.matrix_world.copy()
            # The radiator hose and exhaust tip belong to assemblies outside their
            # initial source parent. Preserve the parent of the existing assembly.
            if group == 'Radiator':
                parent = groups['Body']
            target = ensure(group, parent)
            ob.parent = target
            ob.matrix_parent_inverse = target.matrix_world.inverted()
            ob.matrix_basis = world


def label(name):
    if name in LABELS:
        return LABELS[name]
    for side, prefix in [('Left','Left'), ('Right','Right')]:
        if not name.endswith(side):
            continue
        kind = name[:-len(side)]
        paired = {'Door':'door', 'DoorGlass':'door glass', 'DoorTrim':'inner door trim', 'Mirror':'door mirror', 'QuarterGlass':'rear quarter glass', 'Seat':'front seat', 'Fender':'front fender',
                  'Headlamp':'headlight', 'Taillamp':'taillight', 'Halfshaft':'front halfshaft'}
        if kind in paired:
            return prefix + ' ' + paired[kind]
        for axle in ('Front', 'Rear'):
            if kind.endswith(axle):
                component = kind[:-len(axle)]
                noun = {'Wheel':'alloy wheel', 'Tire':'tire', 'Brake':('disc brake' if axle == 'Front' else 'drum brake'),
                        'Suspension':'suspension'}[component]
                return f'{prefix} {axle.lower()} {noun}'
    raise KeyError('Missing component name: ' + name)


def save_layout(groups, destination):
    """Write parent-relative removal paths for the named exported components."""
    from compact_layout import apply
    components = [
        {"node": name, "label": label(name)}
        for name, group in groups.items() if any(obj.type == 'MESH' for obj in group.children)
    ]
    components.sort(key=lambda part: part['label'])
    destination.write_text(json.dumps({"parts": components}))
    apply(destination)


def configure(cfg, layout=None):
    if layout is None:
        layout = Path(__file__).with_name('assembly-layout.json')
    cfg.update(json.loads(layout.read_text()))
    part_names = {p['node'] for p in cfg['parts']}
    for action in cfg['actions']:
        if action['label'] == 'Lower driver window':
            action['nodes'] = [dict(node='DoorGlassLeft', hidden=True)]
        elif action['label'] == 'Isolate ignition cover':
            # Keep the Powertrain parent visible for the cover's original hierarchy.
            action['nodes'] = [dict(node=name, hidden=True) for name in sorted(part_names - {'IgnitionCover'})]
