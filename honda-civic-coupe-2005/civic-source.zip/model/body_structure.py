"""Formed unibody surfaces visible through the door, engine and luggage openings."""
from shell import *

innerpaint=material('Rallye Red inner panel finish',(.245,.007,.008),.06,.48,.12)
sealer=material('Seam sealer and floor undercoat',(.082,.069,.063),.04,.76)
galvanized=material('Zinc coated body hardware',(.41,.38,.32),.56,.39)
floorheight=curve([(-.94,.327),(-.70,.208),(-.53,.201),(.17,.199),(.55,.235),(.75,.318),(1.05,.337),(1.34,.388),(1.65,.393),(1.98,.391),(2.14,.418)])

def pan(x,k):
    y=k*(.713-.072*smooth((x-1.15)/.42))
    z=floorheight(x)
    # Narrow exhaust tunnel, two depressed footwells and shallow stamped beads.
    z+=.083*math.exp(-(y/.122)**4)*smooth((1.25-x)/.4)
    z+=.013*abs(k)**6
    beads=max(math.exp(-((abs(y)-center)/.021)**2) for center in (.222,.329,.438,.552))
    z+=.011*beads*smooth((x+.57)/.14)*smooth((.69-x)/.21)
    # Circular well for the compact spare beneath the removable trunk board.
    rad=math.hypot(x-1.735,y)
    z-=.118*(1-smooth((rad-.258)/.069))
    return np.array([x,y,z])
patch('Pressed passenger and trunk floor',pan,np.linspace(-.94,2.14,161),np.linspace(-1,1,121),innerpaint,body,(0,0,1))
# Pinch welds connect the rocker and toe board. The sill lip closes the door aperture.
for s in (-1,1):
    def sill(x,t):
        seq=[(.689,.206),(.714,.183),(.747,.179),(.758,.160),(.766,.162),(.768,.193),(.789,.211),(.782,.244),(.768,.261),(.734,.265),(.705,.248),(.688,.218)]
        y,z=seq[t];return [x,s*y,z+.010*smooth((x-.14)/.45)]
    patch('Inner sill pressing',sill,np.linspace(-.88,.68,35),range(12),innerpaint,body,(0,0,1))
    # Exposed hinge face and latch jamb follow the moving door's curved shutline.
    for jamb,dx in [(frontdoor,-1),(backdoor,1)]:
        def face(v,u):
            pos=side(jamb(v),v,s)
            pos[0]+=dx*(.005+.035*u+.018*sin(pi*u))
            pos[1]-=s*(.010+.071*u)
            pos[2]-=.013*u
            return pos
        patch('Door opening stamped jamb',face,span(39),span(9),innerpaint,body,(dx,0,0))
        tube('Door opening pinch seal',[face(v,.83) for v in span(44)],.0055,rubber,body)
    # The structural B-pillar remains after door glass, garnish and rear quarter light are removed.
    def post(v,u):
        q=flank(float(mix(.515,.602,u)),v,s)
        q[1]-=s*(.026+.012*sin(pi*u))
        return q
    patch('Inner B pillar',post,span(37),span(10),innerpaint,body,(0,s,0))
    pos=side(backdoor(.68),.68,s);pos[0]+=.026;pos[1]-=s*.035
    box('Door striker plate',pos,(.009,.040,.060),galvanized,body,.005)
    line('Door striker loop',[pos+[-.004,0,.018],pos+[-.021,0,.013],pos+[-.021,0,-.013],pos+[-.004,0,-.018]],.004,galvanized)
    for v in (.31,.72):
        p=side(frontdoor(v),v,s)+[-.034,-s*.051,0]
        box('Door hinge bracket',p,(.065,.032,.033),galvanized,body,.005)
        cylinder('Door hinge pin',p+[.021,0,-.022],p+[.021,0,.022],.0075,graphite,body,16)
    # Front apron, longitudinal rail and suspension turret are welded to the shell.
    def rail(x,t):
        yy=.535+.038*(x+1.80);z=.315+.035*smooth((x+1.07)/.28)
        offsets=[(-.050,-.052),(.047,-.052),(.056,-.037),(.056,.043),(.043,.051),(-.045,.053),(-.055,.039),(-.055,-.041),(-.050,-.052)]
        w,h=offsets[t];return [x,s*(yy+w),z+h]
    patch('Front side member',rail,np.linspace(-1.914,-.741,27),range(9),innerpaint,body)
    def apron(x,v):
        bell=math.exp(-((x+1.254)/.245)**2)
        top=.614+.116*bell+.069*smooth((x+1.81)/.65)
        yy=.605+.047*smooth((x+1.81)/.4)
        # The stock EX tucks its fuse box and filler bottles inside shallow
        # wing pockets ahead of the strut domes.
        pocket=(.141 if s<0 else .119)*math.exp(-((x+1.55)/.205)**4)
        return [x,s*(yy+.036*v+pocket*v-.099*bell*sin(pi*v)),.332+(top-.332)*v]
    patch('Front inner fender apron',apron,np.linspace(-1.84,-.785,64),span(23),innerpaint,body,(0,-s,0))
    tube('Apron folded flange',[apron(x,1) for x in np.linspace(-1.83,-.795,56)],.0075,innerpaint)
    for dx in np.linspace(-1.64,-.90,11):
        p=np.array(apron(dx,.94))
        oval('Apron spot weld',p-[0,s*.001,0],(.004,.002,.004),innerpaint)
    # Rear wheel tub and the raised rear crossmember appear beneath the cargo trim.
    patch('Rear wheel tub',lambda a,u:[1.309+.354*cos(a),s*(.605+.158*u),.301+.354*sin(a)],np.linspace(0,pi,67),span(12),innerpaint,body,(0,0,1))

def bulkhead(y,v):
    # Rolled toe board with a raised center pressing and cowl return.
    xx,zz=[(-.60,.225),(-.68,.260),(-.755,.365),(-.796,.472),(-.812,.644),(-.829,.766),(-.847,.835),(-.922,.853)][v]
    xx-=.025*(abs(y)/.70)**3
    xx+=.034*math.exp(-((y+.375)/.153)**2)*sin(pi*v/7)
    return [xx,y,zz]
patch('Toe board and dash bulkhead',bulkhead,np.linspace(-.713,.713,71),range(8),innerpaint,body,(-1,0,0))
for s in (-1,1):
    line('Toe board bead',[(-.685,s*.189,.277),(-.747,s*.205,.358),(-.789,s*.215,.457),(-.806,s*.209,.543)],.007,innerpaint)
for x in (-.21,.398):
    def support(y,v):
        p=pan(x,y/.713)
        dx,h=[(-.037,0),(-.029,.003),(-.020,.027),(.016,.030),(.026,.004),(.039,0)][v]
        return p+[dx,0,h]
    patch('Seat crossmember pressing',support,np.linspace(-.69,.69,66),range(6),innerpaint,body,(0,0,1))
for s in (-1,1):
    line('Underfloor seam sealer',[pan(x,s*.923)+[0,0,-.003] for x in np.linspace(-.78,1.36,61)],.004,sealer)

# Left and right splash guards screen the apron and bumper ends. The center
# service opening exposes the oil pan, manual case and exhaust downpipe.
for s in (-1,1):
    def guard(u,v):
        x=float(mix(-1.93,-1.06,u));inner=.46-.095*(1-u)**5+.02*sin(pi*u)
        y=float(mix(inner,.658+.018*sin(pi*u),v))
        z=.238+.035*v*v+.028*u*u+.036*(1-u)**6
        z+=.0045*sin(5*pi*u)**4*sin(pi*v)
        return np.array([x,s*y,z])
    patch('Splash guard below front apron',guard,span(57),span(25),trim,body,(0,0,-1))
    for t in (.10,.29,.46,.73,.91):
        p=guard(t,.89)
        disk('Splash guard retainer',p,[0,0,-1],[1,0,0],[(.003,0),(.009,0),(.009,.002),(.004,.003)],rubber,body,24)

# Molded side deflectors seal the gap between the radiator and the front apron.
for s in (-1,1):
    def baffle(u,v):
        return [-1.85+.20*u+.020*sin(pi*v),s*(.50+.142*u),.268+.333*v+.032*u]
    patch('Cooling pack side baffle',baffle,span(11),span(15),trim,body)
# The battery sits on a recessed tray. Its hold-down yoke stays with the battery.
def tray(u,v):
    x=-1.68+.256*(u-.5);y=.519+.194*(v-.5)
    z=.437+.012*min(1,(2*abs(u-.5))**12+(2*abs(v-.5))**12)
    return [x,y,z]
patch('Battery support tray',tray,span(23),span(19),trim,body,(0,0,1))
