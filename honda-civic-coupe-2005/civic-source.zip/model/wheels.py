from geometry import *
def build_wheel(xc,s,axle):
    y0=s*.73406
    center=np.array([xc,y0,.3075]);axis=np.array([0,s,0.]);h=np.array([1,0,0.])
    name='Wheel'+('Front' if xc<0 else 'Rear')+('Left' if s<0 else 'Right')
    wh=pivot(name,center)
    def ring(label,shape,mat):
        return disk(label,center,axis,h,[(r+max(0,(r-.195)/.103)*.0095,z) for r,z in shape],mat,wh,96)
    ring('195/60 R15 tire',[(.182,-.066),(.193,-.085),(.239,-.098),(.273,-.094),(.289,-.084),(.296,-.065),(.298,-.041),(.298,.041),(.296,.065),(.289,.084),(.273,.094),(.239,.098),(.207,.091),(.19,.082),(.181,.065)],rubbertire)
    for rad,z in [(.211,.092),(.248,.098),(.278,.092)]:
        ring('Sidewall mould line',[(rad-.001,z-.0005),(rad,z+.001),(rad+.001,z-.0005)],tread)
    for lateral in [-.047,-.019,.019,.047]:
        ring('Circumferential tread',[(.2984,lateral-.002),(.2984,lateral+.002)],tread)
    ring('Alloy barrel',[(.166,-.071),(.193,-.072),(.195,.073),(.198,.078),(.193,.085),(.186,.087),(.182,.079),(.176,.071),(.166,.056),(.166,-.071)],wheelmat)
    ring('Brake disc',[(.022,.031),(.131,.031),(.131,.037),(.022,.037)],graphite)
    discmat=material('Swept brake surface '+name,(.088,.096,.103),.72,.46)
    ring('Pad contact surface',[(.127,.038),(.084,.038)],discmat)
    if xc<0:box('Brake caliper',tuple(center+[.105,s*.041,.002]),(.048,.030,.086),graphite,wh,bevel=.015)
    def point(r,a,z):return center+np.array([cos(a)*r,s*z,sin(a)*r])
    for i in range(5):
        th=2*pi*i/5+.31
        # The five stock blades widen at the hub, sweep in azimuth and flare into the rim.
        def spoke(u,v):
            r=.048+.140*u;a=th+.035*u+.018*sin(pi*u)+v*(.39-.253*u+.17*u**5)
            return point(r,a,.078-.012*sin(pi*u)+.007*(1-v*v))
        patch('Five-spoke EX alloy',spoke,span(19),np.linspace(-1,1,9),wheelmat,wh,(0,s,0))
        for side in [-1,1]:
            patch('Spoke return',lambda u,t:spoke(u,side)-np.array([0,s*t*.014,0]),span(17),[0,1],graphite,wh)
    ring('Center hub',[(.001,.042),(.071,.047),(.068,.075),(.059,.085),(.030,.086),(.023,.082),(.001,.082)],wheelmat)
    ring('Center cap',[(.022,.084),(.023,.090),(.001,.092)],steel)
    for i in range(4):
        a=pi*i/2+.34;pos=point(.050,a,.086)
        disk('Lug seat',pos,axis,h,[(.011,0),(.008,.002),(.001,.002)],void,wh,32)
        disk('Lug nut',pos,axis,h,[(.006,.000),(.008,.003),(.006,.008),(.001,.008)],bright,wh,6)
    p=point(.164,2.01,.082);tube('Tire valve',[p,p+np.array([-.004,s*.014,.004])],.003,rubber,wh)
    for k in [-1,1]:
        tube('H center cap rail',[point(.010,pi/2,.095)+[.006*k,0,0],point(.010,-pi/2,.095)+[.004*k,0,0]],.0015,trim,wh)
    tube('H center cap bridge',[point(0,0,.095)+[-.006,0,0],point(0,0,.095)+[.006,0,0]],.0014,trim,wh)
for x in [-1.30937,1.30937]:
    for side in [-1,1]:build_wheel(x,side,'front' if x<0 else 'rear')
