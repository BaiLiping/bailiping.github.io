"""U.S. EX five-spoke wheels, 195/60R15 tires, 10.3-in front discs and 7.8-in rear drums."""
from geometry import *
from chassis import build_suspension, build_underside

alloy = material('Cast silver alloy finish', (.60,.62,.64), .57,.29,.30)
rim_return = material('Cast alloy pocket returns', (.28,.30,.32), .51,.37)
brake_track = material('Machined rotor friction face', (.21,.205,.19), .77,.37)
drum_iron = material('Rear drum iron', (.081,.078,.072), .55,.58)
tread_face = material('Tire tread blocks', (.022,.024,.025), .02,.78)

def build_wheel(xc,s):
    front = xc < 0
    corner = ('Front' if front else 'Rear') + ('Left' if s<0 else 'Right')
    center=np.array([xc,s*.73406,.3075])
    axis=np.array([0,s,0.]); horizontal=np.array([1,0,0.])
    wh=pivot('Wheel'+corner,center)
    brake=pivot('Brake'+corner,center)
    def ring(label, profile, mat, group=wh, n=96):
        return disk(label,center,axis,horizontal,profile,mat,group,n)
    def point(r,a,z):
        return center+np.array([cos(a)*r,s*z,sin(a)*r])
    # A continuous carcass under the cut tread. Both faces are finished when removed from the hub.
    sidewall=[(.181,.067),(.190,.082),(.199,.089),(.213,.094),(.237,.098),(.260,.097),
              (.279,.092),(.293,.084),(.299,.074),(.301,.064)]
    ring('Tire carcass',[(r,-z) for r,z in sidewall]+[(.3028,-.042),(.3044,0),(.3028,.042)]+sidewall[::-1]+[(.181,-.067)],rubbertire)
    for side in (-1,1):
        for rad,z in [(.207,.0925),(.216,.0955),(.254,.0979),(.273,.0945)]:
            ring('Sidewall mould bead',[(rad-.0007,side*z),(rad,side*(z+.0005)),(rad+.0007,side*z)],rubbertire)
    # Close each moulded land with a pitched lateral slot and three circumferential channels.
    vertices=[];faces=[]
    lanes=[(-.081,-.045),(-.041,-.015),(-.012,.012),(.015,.041),(.045,.081)]
    for j,(lo,hi) in enumerate(lanes):
        for k in range(57):
            start=2*pi/57*(k+.28*(j%2)); idx=len(vertices)
            for a in np.linspace(.045,.973,4):
                for b in span(6):
                    lateral=float(mix(lo,hi,b))
                    radius=.3075-.009*(abs(lateral)/.081)**3
                    skew=.05*b*(1 if j<2 else -1)+.009*sin(b*pi)
                    for inset in (.0026,0):
                        vertices.append(point(radius-inset,start+(2*pi/57)*a+skew,lateral))
            for u in range(3):
                for v in range(5):
                    n=idx+u*12+v*2
                    faces.append((n+1,n+13,n+15,n+3))
                    if u==0:faces.append((n,n+1,n+3,n+2))
                    if u==2:faces.append((n+12,n+14,n+15,n+13))
                    if v==0:faces.append((n,n+12,n+13,n+1))
                    if v==4:faces.append((n+2,n+3,n+15,n+14))
    mesh('Tread lands with lateral sipes',vertices,faces,tread_face,wh)
    ring('Alloy barrel and rolled bead',[(.177,-.087),(.192,-.087),(.197,-.082),(.195,-.073),(.188,-.068),(.178,-.005),(.181,.055),(.197,.073),(.199,.080),(.196,.084),(.185,.085),(.176,.075),(.166,.047)],alloy)
    ring('Inner barrel casting',[(.166,.047),(.167,.039),(.174,-.065),(.177,-.087)],rim_return)
    # Cross sections through the five radiused openings vary from pointed at the hub
    # to a wide arc under the outer lip. Blade centerlines share the same radial samples.
    aperture=curve([(.061,0),(.078,0),(.081,.082),(.088,.205),(.105,.349),(.128,.435),
                    (.149,.461),(.163,.465),(.171,.438),(.177,.343),(.181,.198),(.182,0),(.193,0)])
    radii=np.unique(np.r_[np.linspace(.061,.193,72),.078,.081,.088,.105,.128,.149,.163,.171,.177,.181,.182])
    hardware=[(.05*cos(pi*i/2+.34),.05*sin(pi*i/2+.34)) for i in range(4)]
    def face_height(r,a):
        x=r*cos(a);z=r*sin(a)
        recess=sum(.009*math.exp(-((x-hx)**2+(z-hz)**2)/.00013) for hx,hz in hardware)
        return .080+.005*(r/.193)**2+.008*math.exp(-((r-.101)/.045)**2)-recess
    def opening_axis(r):return -.067+.109*(r-.078)/.104
    verts=[];faces=[]
    for j in range(5):
        phi=2*pi*j/5+.60
        for rr in radii:
            h=aperture(rr)
            mid=phi+opening_axis(rr)
            # A small rolled edge into each opening changes the reflection before the return.
            for frac in span(21):
                a=mid+h+frac*(2*pi/5-2*h)
                edgemm=min(frac,1-frac)*(2*pi/5-2*h)*rr
                relief=.0031*math.exp(-edgemm/.0045)*min(1,h/.15)
                verts.append(point(rr,a,face_height(rr,a)-relief))
        base=len(verts)-len(radii)*21
        for i in range(len(radii)-1):
            for k in range(20):
                a=base+i*21+k
                q=(a,a+21,a+22,a+1)
                faces.append(q if s<0 else q[::-1])
        for side in (-1,1):
            rs=radii[(radii>=.078)&(radii<=.182)]
            def lip(r,t):
                h=aperture(r);angle=phi+opening_axis(r)+side*(h+.022*t)
                ri=.130+(r-.130)*(1+.045*t)
                return point(ri,angle,face_height(r,angle)-.0031*min(1,h/.15)-.024*t)
            patch('Cast return inside wheel window',lip,rs,span(5),alloy,wh)
    mesh('EX five-spoke cast face',verts,faces,alloy,wh)
    def hub_skin(r,a):
        return point(r,a,face_height(r,a))
    patch('Integral wheel lug boss',hub_skin,np.linspace(.023,.061,24),np.linspace(0,2*pi,129),alloy,wh,(0,s,0))
    ring('Center cap',[(.001,.080),(.026,.085),(.024,.087),(.022,.088),(.001,.089)],alloy)
    for i in range(4):
        pos=point(.050,pi*i/2+.34,.0785)
        disk('Lug well',pos,axis,horizontal,[(.011,0),(.010,.0016),(.007,.001),(.005,0)],trim,wh,32)
        disk('Wheel lug nut',pos,axis,horizontal,[(.006,0),(.0073,.002),(.0073,.007),(.005,.009),(.0001,.009)],bright,wh,6)
    p=point(.174,2.07,.081)
    tube('Valve stem',[p,p+[-.003,s*.010,.002],p+[-.006,s*.014,.004]],.003,rubber,wh)
    def logo(x,z):return center+np.array([x,s*.0905,z])
    badge=[logo(.014*np.sign(cos(a))*abs(cos(a))**.5,.011*np.sign(sin(a))*abs(sin(a))**.50) for a in np.arange(40)*2*pi/40]
    tube('Center cap badge rim',badge,.0009,graphite,wh,True)
    for side in (-1,1):
        tube('Center cap H uprights',[logo(side*.0075,.0085),logo(side*.005,-.002),logo(side*.0047,-.008)],.0013,graphite,wh)
    tube('Center cap H crossbar',[logo(-.005,-.0015),logo(.005,-.0015)],.0014,graphite,wh)
    if front:
        # Two friction plates enclose the vented edge of the disc.
        R=.13081
        def guard(a,v):
            r,z=[(.035,.007),(.087,.004),(.115,.002),(.133,.005),(.139,.011)][int(v)]
            return point(r,a,z)
        patch('Front brake splash shield',guard,np.linspace(.52,2*pi-.52,76),range(5),drum_iron,brake)
        for z in (.021,.039):
            ring('Ventilated front brake disc',[(.063,z-.004),(R-.001,z-.004),(R,z-.003),(R,z+.003),(.127,z+.004),(.062,z+.004),(.063,z-.004)],brake_track,brake)
        ring('Rotor hat',[(.024,.022),(.070,.022),(.070,.044),(.065,.045),(.060,.055),(.026,.055),(.024,.022)],graphite,brake)
        for j in range(38):
            a=2*pi*j/38
            patch('Rotor cooling vane',lambda u,v:point(.083+.045*u,a+.06*u,.024+.012*v),[0,1],[0,1],graphite,brake)
        for a in (-.31,.28):
            p=point(.104,a,.023)
            box('Caliper guide boss',p,(.039,.065,.032),graphite,brake,.009)
            cylinder('Caliper slide pin',p-axis*.034,p-axis*.040,.008,steel,brake,6)
        for z in (.011,.050):
            patch('Brake pad backing plate',lambda a,v:point(.090+.035*v,a,z),np.linspace(-.43,.43,31),[0,1],drum_iron,brake)
        def caliper_surface(a,v):
            coords=[(.090,.005),(.116,-.003),(.139,.010),(.142,.034),(.137,.052),(.118,.061),(.094,.051)]
            r,z=coords[int(v)]
            return point(r-.006*(abs(a)/.40)**3,a,z)
        patch('Cast front brake caliper bridge',caliper_surface,np.linspace(-.40,.40,37),range(7),graphite,brake)
    else:
        # Honda specifies 198 mm inside diameter, with an integral iron friction shell.
        ring('Rear drum backing plate',[(.024,-.019),(.104,-.019),(.108,-.015),(.106,-.010),(.094,-.012),(.024,-.012)],trim,brake)
        ring('Rear brake drum',[(.099,-.009),(.103,-.012),(.108,-.009),(.108,-.004),(.105,.004),(.104,.032),(.100,.043),(.072,.046),(.062,.051),(.028,.051),(.026,.044),(.061,.043),(.095,.035),(.099,.029),(.099,-.009)],drum_iron,brake)
        for z in (.002,.012,.021):
            ring('Drum casting rib',[(.104,z-.0008),(.106,z+.0002),(.104,z+.0013)],drum_iron,brake)
    for i in range(4):
        p=point(.05,pi*i/2+.34,.050)
        cylinder('Wheel stud',p-axis*.009,p+axis*.025,.0056,steel,brake,16)
    build_suspension(xc,s,center,corner)
for xc in [-1.30937,1.30937]:
    for side in (-1,1):build_wheel(xc,side)
build_underside()
