"""EM2 coupe exterior in metres. X points aft, negative Y is the LHD side."""
from geometry import *
nose,tail=-2.124,2.351
topline=curve([(nose,.626),(-1.91,.698),(-1.61,.777),(-1.30,.827),(-.91,.867),(-.52,.879),(.39,.916),(1.01,.943),(1.66,1.000),(2.06,1.022),(tail,1.023)])
width=curve([(nose,.832),(-1.8,.84),(-1.37,.84709),(-.65,.837),(.44,.833),(1.31,.84709),(1.86,.843),(tail,.814)])
base=curve([(nose,.191),(-1.75,.176),(-.99,.177),(.96,.177),(1.75,.228),(tail,.282)])
def lower(x):
 z=base(x)
 for axle in (-1.30937,1.30937):
    d=abs(x-axle)
    if d<.350:z=max(z,.286+(.352 if axle<0 else .345)*math.sqrt(max(0,1-(d/.35)**2)))
    elif d<.365:z=max(z,.286+smooth((d-.35)/.015)*(z-.286))
 return z
section=curve([(0,-.040),(.12,-.024),(.20,-.018),(.25,-.008),(.29,-.015),(.5,-.008),(.64,-.003),(.72,0),(.76,-.005),(.87,-.011),(1,-.044)])
def bodypoint(x,t,k=1):
 a=abs(k);wf=smooth(1-(x-nose)/.81);wr=smooth(1-(tail-x)/.76)
 # Plan curvature sweeps the fascia ends around into the front and rear quarters.
 xf=wf*(.023+.055*(t-.48)**2+.106*t**3+.108*a**2+.295*a**5)
 xr=wr*(.006+.016*(t-.42)**2+.032*t**3+.044*a**2+.058*a**5+.100*(1-math.sqrt(max(0,1-a*a))))
 # A rounded impact band below the number plate projects from the rear fascia.
 rr=.024*math.exp(-((t-.46)/.20)**2)-.052*math.exp(-((t-.76)/.13)**2)*(1-a**2)-.031*math.exp(-(t/.13)**2)
 xx=x+xf-xr+wr*rr*(1-.25*a)
 low=lower(xx) if a>.99999 else base(x)
 zz=float(mix(low,topline(xx),t))
 q=clip((zz-base(x))/(topline(xx)-base(x)))
 yy=k*(width(x)+section(q))
 # The bumper rolls away from its widest section beneath the grille.
 xx+=wf*(.052*(1-t)**3-.008*math.sin(math.pi*t))*(1-.62*a)
 if a<1:zz+=t**3*(1-a**3)*(.025+.016*smooth((-x-.76)/.5))
 return np.array([xx,yy,zz])
def side(x,t,s):return bodypoint(x,t,s)
def deck(x,k):
 a=abs(k);p=bodypoint(x,1,k)
 p[2]+=.010*math.exp(-((a-.72)/.08)**2)*smooth((-x-.84)/.32)
 return p
def frontdoor(v):return -.836-.058*v+.019*sin(pi*v)
def backdoor(v):return .382+.131*v+.038*sin(pi*v)
for s in (-1,1):
 for a,b,g,n in [(lambda v:nose,lambda v:frontdoor(v)-.0029,body,'Front wing'),(lambda v:frontdoor(v)+.0029,lambda v:backdoor(v)-.0029,doors[s],'Coupe door'),(lambda v:backdoor(v)+.0029,lambda v:tail,body,'Rear quarter')]:
    patch(n,lambda u,v:side(float(mix(a(v),b(v),u)),v,s),span(149),span(27),paint,g,(0,s,0))
 for axle in (-1.30937,1.30937):
    xs=np.linspace(nose,tail,900);real=[side(x,0,s)[0] for x in xs]
    def opening(x,t):
       px=np.interp(x,real,xs);p=side(px,0,s)
       p[1]-=s*.075*t;p[2]+=.001*t;return p
    # Give the side stamping genuine thickness to darken the return into the wheel well.
    samples=np.linspace(axle-.369,axle+.369,181)
    patch('Rolled arch return',opening,samples,[0,.23,1],paint,body,(0,0,-1))
    patch('Wheelhouse liner',lambda a,t:[axle+.345*cos(a),s*(.817-.223*t),.278+.348*sin(a)],np.linspace(-.25,pi+.25,81),[0,1],void,body,(0,0,-1))
    patch('Inner arch closure',lambda a,t:[axle+.347*t*cos(a),s*.608,max(.235,.288+.353*t*sin(a))],np.linspace(-.85,pi+.85,58),np.linspace(0,1,7),void,body,(0,s,0))
 for a,b,g in [(nose,-.894,body),(-.894,.511,doors[s]),(.511,tail,body)]:
    patch('Fender and door shoulder roll',lambda x,k:deck(x,s*k),np.linspace(a,b,85),np.linspace(.975 if g==doors[s] else .829,1,16),paint,g,(0,0,1))
 box('Rocker pinch seam',(-.01,s*.776,.185),(1.84,.046,.026),paint,bevel=.015)
 # Straight swage below the belt. Its height is independent of either wheel opening.
 for a,b,g in [(-1.42,-.893,body),(-.878,.495,doors[s]),(.515,1.79,body)]:
    def crease(u,v):
      x=float(mix(a,b,u));z=topline(x)-.127+.004*v
      lo=lower(x);t=clip((z-lo)/(topline(x)-lo))
      p=side(x,t,s);p[1]+=s*.001*sin(math.pi*v);return p
    patch('Upper swage line',crease,span(70),span(5),paint,g,(0,s,0))
 for a,b,g in [(-.82,.38,doors[s]),(.410,.949,body)]:
    def lowerfold(u,v):
       x=float(mix(a,b,u));z=.278+.012*(x+.8)/1.8+.020*v
       t=(z-lower(x))/(topline(x)-lower(x));p=side(x,t,s);p[1]+=s*.006*sin(pi*v)*sin(pi*u)**.20;return p
    patch('Lower door pressing',lowerfold,span(49),span(8),paint,g,(0,s,0))
def intake_depth(k,t):
    # One bumper aperture crossed by two body-coloured struts. A rounded edge turns into the opening.
    a=abs(k);lo=.132+.041*a**4;hi=.388+.013*a*a;width=.785-.045*(1-t)
    depth=smooth((t-lo)/.042)*smooth((hi-t)/.045)*smooth((width-a)/.045)
    post=abs(a-(.54+.035*(t-.12)/.27))
    return depth*smooth((post-.022)/.034)*.059
def fascia(k,t):
 p=bodypoint(nose,t,k);depth=intake_depth(k,t);p[0]+=depth;p[1]-=np.sign(k)*depth*.29*abs(k)**2
 return p
for end,sgn in [(nose,-1),(tail,1)]:
 if sgn<0:patch('Front bumper fascia',fascia,np.linspace(-1,1,157),span(65),paint,body,(sgn,0,0))
 else:
    def boundary_t(k):return .584+.032*min(1,(abs(k)/.655)**5)
    patch('Rear bumper',lambda k,v:bodypoint(tail,boundary_t(k)*v,k),np.linspace(-1,1,95),span(30),paint,body,(1,0,0))
    for s in (-1,1):
       patch('Rear lamp panel',lambda u,v:bodypoint(tail,float(mix(boundary_t(.7),1,v)),s*float(mix(.655+.075*v,1,u))),span(35),span(24),paint,body,(1,0,0))
patch('Front hood',lambda u,k:deck(float(mix(nose,-.923,u)),k*.83),span(50),np.linspace(-1,1,45),paint,hood,(0,0,1))
for s in (-1,1):tube('Hood fender seam',[deck(x,s*.83)+[0,0,.0018] for x in np.linspace(nose,-.923,65)],.0028,rubber,hood)
tube('Hood leading hem',[deck(nose,k) for k in np.linspace(-.832,.832,70)],.003,rubber,hood)
patch('Cowl grille',lambda x,k:deck(x,k*.84),np.linspace(-.924,-.745,14),np.linspace(-1,1,39),trim)
# The profile, greenhouse and the two-door quarter light follow Honda's press broadside.
cz=curve([(-.995,.900),(-.83,.969),(-.48,1.171),(-.21,1.337),(.08,1.371),(.34,1.3925),(.55,1.39454),(.73,1.388),(.91,1.365),(1.17,1.300),(1.45,1.192),(1.77,1.036)])
cw=curve([(-.995,.725),(-.62,.661),(-.23,.581),(.05,.578),(.64,.587),(.90,.609),(1.34,.660),(1.77,.693)])
cd=curve([(-.995,.010),(-.55,.031),(-.12,.051),(.48,.054),(.81,.049),(1.31,.039),(1.77,.012)])
sweep=curve([(-.995,.117),(-.44,.067),(.03,.035),(.64,-.016),(.88,-.064),(1.77,-.132)])
def canopy(x,k):
 a=abs(k);return np.array([x+sweep(x)*a*a,k*cw(x),cz(x)-cd(x)*(.52*a*a+.48*a**8)])
def pane(n,a,b,g):
 def p(u,k): return canopy(float(mix(a,b,u)),k)
 patch(n,p,np.linspace(.032,.972,43),np.linspace(-.963,.963,53),glass,g,(0,0,1))
 for lo,hi in [(0,.032),(.972,1)]:patch(n+' frit',p,np.linspace(lo,hi,4),np.linspace(-1,1,52),rubber,g,(0,0,1))
 for s in (-1,1):patch(n+' frit',p,np.linspace(.032,.972,32),np.linspace(s*.963,s,4),rubber,g,(0,0,1))
pane('Windscreen',-.995,-.16,body);pane('Fixed rear glass',.84,1.77,body)
roofglass=material('Moonroof smoked safety glass',(.025,.047,.051),.26,.11,.65)
for a,b in [(-.16,.040),(.56,.84)]:
 patch('Roof pressing',canopy,np.linspace(a,b,21),np.linspace(-1,1,52),paint,body,(0,0,1))
for s in (-1,1):
 patch('Roof side pressing',canopy,np.linspace(.04,.56,23),np.linspace(s*.725,s,12),paint,body,(0,0,1))
 tube('Roof gutter seal',[canopy(x,s*.994) for x in np.linspace(-.077,.87,55)],.005,rubber)
patch('EX glass moonroof',canopy,np.linspace(.04,.56,35),np.linspace(-.725,.725,43),roofglass,body,(0,0,1))
for x in (.04,.56):tube('Moonroof gasket',[canopy(x,k) for k in np.linspace(-.725,.725,35)],.005,rubber)
for s in (-1,1):tube('Moonroof side gasket',[canopy(x,s*.725) for x in np.linspace(.04,.56,33)],.005,rubber)
def flank(x,t,s):
 upper=canopy(x,s);xx=upper[0];z=topline(xx)+.0004
 return np.array([xx,s*float(mix(width(xx)-.044,cw(x),t)+.015*sin(pi*t)),float(mix(z,upper[2],t))])
for s in (-1,1):
 def region(n,a,b,lo,hi,m,g):
    def fn(u,v):return flank(float(mix(a,b,u)),float(mix(lo(u),hi(u),v)),s)
    patch(n,fn,span(45),span(12),m,g,(0,s,0))
 zero=lambda u:0;one=lambda u:1
 region('A pillar',-.995,-.814,zero,one,paint,body)
 region('Door glass',-.814,.49,lambda u:.028,lambda u:.925,glass,doors[s])
 region('Upper door window frame',-.814,.49,lambda u:.925,one,trim,doors[s])
 region('Window sill seal',-.814,.49,zero,lambda u:.028,rubber,doors[s])
 region('Black B pillar',.49,.602,zero,one,trim,doors[s]);region('B pillar rear seal',.602,.624,zero,one,rubber,body)
 q=lambda u:.925*(1-u**2.04)+.075*u**2.04
 region('Quarter light',.624,1.320,lambda u:.036,q,glass,body)
 region('Quarter light seal',.624,1.320,q,lambda u:q(u)+.041,trim,body)
 region('Sail panel',.624,1.320,lambda u:q(u)+.041,one,paint,body)
 region('Quarter lower gasket',.624,1.320,zero,lambda u:.036,rubber,body)
 region('C pillar',1.320,1.77,zero,one,paint,body)
 tube('Windscreen pillar cap',[canopy(x,s) for x in np.linspace(-.995,-.157,44)],.016,paint)
 for a,b,g in [(-.995,-.89,body),(-.89,.532,doors[s]),(.532,1.77,body)]:
    patch('Sill shoulder bridge',lambda x,v:mix(flank(x,0,s),deck(flank(x,0,s)[0],s*(.975 if g==doors[s] else .82)),v),np.linspace(a,b,49),span(5),paint,g,(0,0,1))
for k in np.linspace(.12,.90,10):
 x=float(mix(.84,1.77,k));tube('Rear glass heater',[canopy(x,y)+[0,0,.0013] for y in np.linspace(-.944,.944,44)],.0006,graphite)
def lid(u,k):return mix(canopy(1.77,k),deck(tail,k*.86),u)+[0,0,.008*sin(pi*u)]
patch('Notchback trunk lid',lid,span(35),np.linspace(-1,1,55),paint,hatch,(0,0,1))
for s in (-1,1):
 tube('Trunk gutter',[lid(u,s) for u in span(36)],.0038,rubber,hatch)
 patch('Trunk side rail',lambda u,t:mix(lid(u,s),deck(float(mix(1.637,tail,u)),s),t),span(31),span(10),paint,body,(0,0,1))
for s in (-1,1):
 g=doors[s]
 x=-.670
 line('Mirror foot',[(x,s*.761,.895),(x+.003,s*.807,.902),(x+.010,s*.845,.947)],.022,trim,g)
 oval('Color keyed mirror',(x+.033,s*.870,.961),(.077,.095,.049),paint,g,rot=(0,.07,-s*.12))
 oval('Mirror face',(x+.092,s*.878,.964),(.011,.075,.032),steel,g,rot=(0,.13,-s*.20))
 y=s*(width(.262)-.008)
 oval('Recess under handle',(.267,y,.790),(.088,.012,.029),trim,g)
 oval('Body colour handle',(.267,y+s*.012,.795),(.074,.014,.014),paint,g)
 if s<0:oval('Door key barrel',(.337,y+s*.014,.791),(.008,.004,.008),steel,g)
for s in (-1,1):
 xs=[-.951,-.927,-.916,-.919];ys=[s*.51,s*.38,s*.19,s*.05]
 line('Windshield wiper',[(x,y,canopy(x,y/cw(x))[2]+.006) for x,y in zip(xs,ys)],.007,trim)
def floor_profile(x,k):
    ramp=smooth((x-1.22)/.91);front=smooth((-x-1.28)/.55)
    return [x,k*(.665-.160*ramp-.075*front),.183+.111*ramp+.052*front+.018*k*k]
patch('Formed floorpan',floor_profile,np.linspace(-1.86,2.19,71),np.linspace(-1,1,27),void,body,(0,0,-1))

