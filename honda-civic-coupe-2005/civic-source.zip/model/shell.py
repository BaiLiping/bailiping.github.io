"""EM2 coupe exterior in metres. X points aft, negative Y is the LHD side."""
from geometry import *
nose,tail=-2.124,2.351
topline=curve([(nose,.626),(-1.91,.698),(-1.61,.777),(-1.30,.827),(-.91,.867),(-.52,.879),(.39,.925),(1.01,.964),(1.36,.991),(1.66,1.012),(2.06,1.022),(tail,1.023)])
# This is the underlying stamping. The rolled arches add up to 7 mm per side.
width=curve([(nose,.82494),(-1.8,.83294),(-1.37,.84003),(-.65,.82994),(.44,.82594),(1.31,.84003),(1.86,.83594),(tail,.80694)])
base=curve([(nose,.191),(-1.75,.176),(-.99,.177),(.96,.177),(1.75,.228),(tail,.282)])
def lower(x):
 z=base(x)
 for axle in (-1.30937,1.30937):
    d=abs(x-axle)
    if d<.350:z=max(z,.286+(.352 if axle<0 else .345)*math.sqrt(max(0,1-(d/.35)**2)))
    elif d<.365:z=max(z,.286+smooth((d-.35)/.015)*(z-.286))
 return z
# Rounded rocker hem, shallow concave door and convex shoulder sampled across the stamping.
section=curve([(0,-.058),(.048,-.045),(.10,-.030),(.135,-.022),(.155,-.019),
               (.19,-.026),(.37,-.018),(.58,-.011),(.76,-.001),(.84,0),(.90,-.006),
               (.96,-.015),(1,-.020)])
def bodypoint(x,t,k=1):
 a=abs(k);wf=smooth(1-(x-nose)/.81);wr=smooth(1-(tail-x)/.76)
 # Plan curvature sweeps the fascia ends around into the front and rear quarters.
 xf=wf*(.023+.055*(t-.48)**2+.106*t**3+.108*a**2+.295*a**5)
 xr=wr*(.006+.016*(t-.42)**2+.032*t**3+.044*a**2+.058*a**5+.100*(1-math.sqrt(max(0,1-a*a))))
 # A rounded impact band below the number plate projects from the rear fascia.
 rr=.027*math.exp(-((t-.50)/.12)**2)-.052*math.exp(-((t-.76)/.13)**2)*(1-a**2)-.031*math.exp(-(t/.13)**2)
 # Keep the impact bands at the measured overhangs, with the axles fixed.
 xx=x+xf-xr+wr*rr*(1-.25*a)+.01931*wf-.03417*wr
 low=float(mix(base(x),lower(xx),smooth((a-.91)/.09)))
 # The stock rear bumper has a high center undercut for the muffler, with
 # low body-colour returns beneath each rear corner of the valance.
 low-=.064*wr*smooth((a-.60)/.20)
 zz=float(mix(low,topline(xx),t))
 q=clip((zz-base(x))/(topline(xx)-base(x)))
 # A rolled wheel lip tapers back into the wing above the opening.
 radius=min(math.hypot(xx-axle,(zz-.286)*1.025) for axle in (-1.30937,1.30937))
 arch=.012*math.exp(-((radius-.358)/.040)**2)*smooth((zz-.165)/.17)
 # The character line fades into the headlamp and rear optical housing.
 belt=topline(xx)-(.155-.014*smooth((xx+.85)/1.8))
 fade=smooth((xx+1.66)/.48)*smooth((2.16-xx)/.20)
 shoulder=.0038*math.tanh((zz-belt)/.009)*math.exp(-((zz-belt)/.081)**2)*fade
 # A rolled shoulder meets the fender crown tangentially. Its final few
 # millimetres are almost horizontal, as on the stamped outer wing.
 roll=clip((q-.925)/.075)
 shoulder_roll=.024*(1-math.sqrt(max(0,1-roll*roll)))
 yy=k*(width(x)+section(q)-shoulder_roll+a**5*(arch+shoulder))
 # Both bumper skins roll under, and return outward just above the lower lip.
 if wf or wr:
    band=wf*(.029*math.exp(-((t-.64)/.19)**2)+.018*math.exp(-((t-.075)/.068)**2))
    aft=wr*(.034*math.exp(-((t-.53)/.095)**2)-.036*math.exp(-((t-.115)/.07)**2))
    xx+=(-band+aft)*(1-.83*a**3)
    yy+=k*(band+aft)*.46*a**3
 # The bumper rolls away from its widest section beneath the grille.
 xx+=wf*(.052*(1-t)**3-.008*math.sin(math.pi*t))*(1-.62*a)
 if a<1:zz+=t**3*(1-a**3)*(.025+.016*smooth((-x-.76)/.5))
 # The 2005 grille and inboard end of the hood sit below the lamp crowns.
 zz-=wf*.054*smooth((.92-a)/.41)*t**3.4
 return np.array([xx,yy,zz])
def side(x,t,s):return bodypoint(x,t,s)
def deck(x,k):
 a=abs(k);p=bodypoint(x,1,k)
 # Two gradual pressed ridges rise toward the cowl, following the hood margins.
 blend=smooth((x-nose)/.42)*smooth((-.78-x)/.14)
 ridge=.57+.21*smooth((x-nose)/1.18)
 p[2]+=blend*(.016*math.exp(-((a-ridge)/.075)**2)+.012*(1-a*a))
 return p
def rolled_section(n):return np.sin(np.linspace(0,pi/2,n))
def frontdoor(v):return -.836-.058*v+.019*sin(pi*v)
def backdoor(v):return .382+.131*v+.038*sin(pi*v)
for s in (-1,1):
 # Bumper covers meet the wings at the lamp bases and terminate on the arch.
 # Divide the stamping on the actual shut line so detaching a bumper removes its corners.
 def split_at_height(x,z):
    if side(x,0,s)[2]>=z:return 0.
    lo,hi=0.,1.
    for _ in range(14):
       mid=(lo+hi)*.5
       if side(x,mid,s)[2]<z:lo=mid
       else:hi=mid
    return (lo+hi)*.5
 # Project the lower edge of the lens onto the neighbouring side stamping.
 # The parting line runs into the wheel cutout at a nearly constant physical height.
 def frontsplit(x):
    z=side(nose,.782,s)[2]-.011*smooth((x-nose)/.32)
    return split_at_height(x,z)
 def rearsplit(x):
    z=side(tail,.614,s)[2]-.079*smooth((1.98-x)/.17)
    return split_at_height(x,z)
 def split_panel(name,first,last,split,front):
    limits={}
    def panel(u,v,upper):
       x=float(mix(first,last,u))
       if x not in limits:limits[x]=split(x)
       cut=limits[x]
       return side(x,float(mix(cut,1,v) if upper else cut*v),s)
    patch(name,lambda u,v:panel(u,v,True),span(95),rolled_section(45),paint,body,(0,s,0))
    patch(('Front' if front else 'Rear')+' bumper side return',lambda u,v:panel(u,v,False),span(81),span(28),paint,body,(0,s,0))
    xs=np.linspace(first,last,90)
    pts=[side(x,split(x),s)+[0,s*.0008,0] for x in xs if split(x)>.016]
    if len(pts)>1:tube(('Front' if front else 'Rear')+' bumper corner shut line',pts,.0014,rubber)
 split_panel('Front wing',nose,-1.38,frontsplit,True)
 split_panel('Rear quarter',1.30,tail,rearsplit,False)
 for a,b,g,n in [(lambda v:-1.38,lambda v:frontdoor(v)-.0023,body,'Front wing'),
                 (lambda v:frontdoor(v)+.0023,lambda v:backdoor(v)-.0023,doors[s],'Coupe door'),
                 (lambda v:backdoor(v)+.0023,lambda v:1.30,body,'Rear quarter')]:
    patch(n,lambda u,v:side(float(mix(a(v),b(v),u)),v,s),span(110),rolled_section(54),paint,g,(0,s,0))
 for axle in (-1.30937,1.30937):
    xs=np.linspace(nose,tail,900);real=[side(x,0,s)[0] for x in xs]
    def opening(x,t):
       px=np.interp(x,real,xs);p=side(px,0,s)
       p[1]-=s*.075*t;p[2]+=.001*t;return p
    # Give the side stamping genuine thickness to darken the return into the wheel well.
    samples=np.linspace(axle-.369,axle+.369,181)
    patch('Rolled arch return',opening,samples,[0,.10],paint,body,(0,0,-1))
    patch('Wheelhouse liner fold',opening,samples,[.10,.30,1],void,body,(0,0,-1))
    patch('Wheelhouse liner',lambda a,t:[axle+.345*cos(a),s*(.817-.223*t),.278+.348*sin(a)],np.linspace(-.25,pi+.25,81),[0,1],void,body,(0,0,-1))
    patch('Inner arch closure',lambda a,t:[axle+.347*t*cos(a),s*.608,max(.235,.288+.353*t*sin(a))],np.linspace(-.85,pi+.85,58),np.linspace(0,1,7),void,body,(0,s,0))
 def hood_side(x):
    # At the nose the hem follows the top of the lamp up to the indicator.
    # The long fender joint then runs back to the outer corner of the cowl.
    u=clip((x-nose)/1.201)
    return .903-.068*u+.009*sin(pi*u)
 patch('Front fender crown',lambda x,v:deck(x,s*float(mix(hood_side(x)+.002,1,v))),np.linspace(nose,-.923,69),span(20),paint,body,(0,0,1))
 for a,b,g in [(-.923,-.894,body),(-.894,.511,doors[s]),(.511,tail,body)]:
    patch('Fender and door shoulder roll',lambda x,k:deck(x,s*k),np.linspace(a,b,85),np.linspace(.975 if g==doors[s] else .829,1,16),paint,g,(0,0,1))
 box('Rocker pinch seam',(-.01,s*.776,.185),(1.84,.046,.026),paint,bevel=.015)
 # The lower door pressing runs into the rocker, stopping before the arch.
 for a,b,g in [(-.82,.38,doors[s]),(.410,.949,body)]:
    def lowerfold(u,v):
       x=float(mix(a,b,u));z=.262+.009*(x+.8)/1.8+.045*v
       t=(z-lower(x))/(topline(x)-lower(x));p=side(x,t,s)
       p[1]+=s*.006*(sin(pi*v)**1.8)*min(1,14*u,14*(1-u));return p
    patch('Lower door pressing',lowerfold,span(56),span(11),paint,g,(0,s,0))
def intake_depth(k,t):
    # One bumper aperture crossed by two body-coloured struts. A rounded edge turns into the opening.
    a=abs(k)
    # Continuous channel with a rolled lip. Side ducts close up toward their outer tip.
    edge=clip((a-.56)/.255)
    lo=.112+.105*edge**3
    hi=.376+.016*a*a
    wall=smooth((t-lo)/.075)*smooth((hi-t)/.060)*smooth((.850-a)/.080)
    return wall*.075
def lamp_coords(u,v):
 k=.489+.472*u+.074*v*(1-u)+.025*v*u+.015*u**5*sin(pi*v)
 low=.766+.012*sin(pi*u)+.038*u+.072*u**6
 high=.986+.008*sin(pi*u)-.020*u**9
 return k,float(mix(low,high,v))
def lamp_recess(k,t):
 # Invert the optical chart within its local rectangle. The hood and bumper
 # retain their uninterrupted outer skins up to the exact lens outline.
 if abs(k)<.485 or t<.757 or t>.995:return 0.
 ak=abs(k);u=clip((ak-.50)/.48);v=.5
 for _ in range(4):
    left=lamp_coords(0,v)[0];right=lamp_coords(1,v)[0]
    u=clip((ak-left)/(right-left))
    bottom=lamp_coords(u,0)[1];top=lamp_coords(u,1)[1]
    v=clip((t-bottom)/(top-bottom))
 left=lamp_coords(0,v)[0];right=lamp_coords(1,v)[0]
 bottom=lamp_coords(u,0)[1];top=lamp_coords(u,1)[1]
 return smooth((ak-left)/.018)*smooth((right-ak)/.013)*smooth((t-bottom)/.030)*smooth((top-t)/.024)
def fascia(k,t):
 p=bodypoint(nose,t,k)
 depth=intake_depth(k,t)
 # Upper grille also sits behind the nose. The sidewall stays painted at the rim.
 a=abs(k);v=clip((t-.797)/.184)
 width=.375+.128*v+.020*sin(pi*v)
 bottom=.797+.065*min(1,a/.375)**4
 depth+=.030*smooth((t-bottom)/.031)*smooth((width-a)/.026)
 depth+=.047*lamp_recess(k,t)
 p[0]+=depth
 p[1]-=np.sign(k)*depth*.52*abs(k)**2
 return p
for end,sgn in [(nose,-1),(tail,1)]:
 if sgn<0:patch('Front bumper fascia',fascia,np.linspace(-1,1,157),span(65),paint,body,(sgn,0,0))
 else:
    def boundary_t(k):return .584+.032*min(1,(abs(k)/.655)**5)
    patch('Rear bumper',lambda k,v:bodypoint(tail,boundary_t(k)*v,k),np.sin(np.linspace(-pi/2,pi/2,153)),span(49),paint,body,(1,0,0))
    for s in (-1,1):
       patch('Rear lamp panel',lambda u,v:bodypoint(tail,float(mix(boundary_t(.7),1,v)),s*float(mix(.655+.075*v,1,sin(.5*pi*u)))),span(35),span(24),paint,body,(1,0,0))
patch('Front hood',lambda u,k:deck(float(mix(nose,-.923,u)),k*hood_side(float(mix(nose,-.923,u)))),span(50),np.linspace(-1,1,45),paint,hood,(0,0,1))
for s in (-1,1):tube('Hood fender seam',[deck(x,s*hood_side(x))+[0,0,.0012] for x in np.linspace(nose,-.923,65)],.0019,rubber,hood)
tube('Hood leading hem',[deck(nose,k) for k in np.linspace(-hood_side(nose),hood_side(nose),87)],.003,rubber,hood)
patch('Cowl grille',lambda x,k:deck(x,k*.84),np.linspace(-.924,-.745,14),np.linspace(-1,1,39),trim)
# The profile, greenhouse and the two-door quarter light follow Honda's press broadside.
cz=curve([(-.995,.900),(-.83,.982),(-.48,1.207),(-.30,1.309),(-.17,1.350),(.02,1.383),(.13,1.390),(.34,1.39454),(.55,1.393),(.73,1.390),(.91,1.375),(1.17,1.313),(1.45,1.204),(1.77,1.036)])
cw=curve([(-.995,.725),(-.62,.661),(-.23,.591),(.05,.590),(.64,.597),(.90,.615),(1.34,.660),(1.77,.693)])
cd=curve([(-.995,.010),(-.55,.027),(-.12,.034),(.48,.032),(.81,.032),(1.31,.031),(1.77,.012)])
sweep=curve([(-.995,.117),(-.44,.067),(.03,.035),(.64,-.016),(.88,-.064),(1.77,-.132)])
def canopy(x,k):
 a=abs(k);return np.array([x+sweep(x)*a*a,k*cw(x),cz(x)-cd(x)*(.21*a*a+.79*a**8)])
def pane(n,a,b,g,outer):
 def p(u,k): return canopy(float(mix(a,b,u)),k*outer)
 patch(n,p,np.linspace(.032,.972,43),np.linspace(-.963,.963,53),glass,g,(0,0,1))
 for lo,hi in [(0,.032),(.972,1)]:patch(n+' frit',p,np.linspace(lo,hi,4),np.linspace(-1,1,52),rubber,g,(0,0,1))
 for s in (-1,1):patch(n+' frit',p,np.linspace(.032,.972,32),np.linspace(s*.963,s,4),rubber,g,(0,0,1))
pane('Windscreen',-.995,-.16,body,.947)
pane('Fixed rear glass',.84,1.77,body,.927)
for s in (-1,1):
 for name,beg,end,edge in [('A pillar windscreen flange',-.995,-.16,.947),('Rear pillar glass flange',.84,1.77,.927)]:
    patch(name,canopy,np.linspace(beg,end,48),np.linspace(s*edge,s,9),paint,body,(0,0,1))
roofglass=material('Moonroof smoked safety glass',(.025,.047,.051),.26,.11,.65)
for a,b in [(-.16,.040),(.56,.84)]:
 patch('Roof pressing',canopy,np.linspace(a,b,21),np.linspace(-1,1,52),paint,body,(0,0,1))
for s in (-1,1):
 patch('Roof side pressing',canopy,np.linspace(.04,.56,23),np.linspace(s*.725,s,12),paint,body,(0,0,1))
 tube('Roof gutter seal',[canopy(x,s*.994) for x in np.linspace(-.077,.87,55)],.005,rubber)
patch('EX glass moonroof',canopy,np.linspace(.04,.56,35),np.linspace(-.725,.725,43),roofglass,body,(0,0,1))
for x in (.04,.56):tube('Moonroof gasket',[canopy(x,k) for k in np.linspace(-.725,.725,35)],.005,rubber)
for s in (-1,1):tube('Moonroof side gasket',[canopy(x,s*.725) for x in np.linspace(.04,.56,33)],.005,rubber)
def flank(x,t,s):
 # The coupe door's rear frame leans aft. Fade the shear out before the windshield and sail panel.
 x+=.069*t*smooth((x+.15)/.55)*smooth((1.25-x)/.51)
 upper=canopy(x,s);xx=upper[0];z=topline(xx)+.0004
 return np.array([xx,s*float(mix(width(xx)-.044,cw(x),t)+.015*sin(pi*t)),float(mix(z,upper[2],t))])
for s in (-1,1):
 def region(n,a,b,lo,hi,m,g):
    def fn(u,v):return flank(float(mix(a,b,u)),float(mix(lo(u),hi(u),v)),s)
    patch(n,fn,span(45),span(12),m,g,(0,s,0))
 zero=lambda u:0;one=lambda u:1
 region('A pillar',-.995,-.814,zero,one,paint,body)
 upper=lambda u:.876-.354*(1-u)**6+.023*sin(pi*u)
 region('Door glass',-.814,.49,lambda u:.027,upper,glass,doors[s])
 region('Upper door window frame',-.814,.49,upper,lambda u:upper(u)+.038,trim,doors[s])
 region('Roof rail above door',-.814,.49,lambda u:upper(u)+.038,one,paint,body)
 region('Window sill seal',-.814,.49,zero,lambda u:.027,rubber,doors[s])
 btop=lambda u:float(mix(upper(1)+.038,.89,u*.075/.088))
 rear_post_top=lambda u:float(mix(upper(1)+.038,.89,(.075+.013*u)/.088))
 region('Black B pillar',.49,.565,zero,btop,trim,doors[s])
 region('B pillar rear seal',.565,.578,zero,rear_post_top,rubber,body)
 region('Roof rail over post',.49,.565,btop,one,paint,body)
 region('Roof rail over post seal',.565,.578,rear_post_top,one,paint,body)
 q=lambda u:.853-.774*u**2.2
 region('Quarter light',.578,1.320,lambda u:.037,q,glass,body)
 region('Quarter light seal',.578,1.320,q,lambda u:q(u)+.037,trim,body)
 region('Sail panel',.578,1.320,lambda u:q(u)+.037,one,paint,body)
 region('Quarter lower gasket',.578,1.320,zero,lambda u:.037,rubber,body)
 region('C pillar',1.320,1.77,zero,one,paint,body)
 for a,b,g in [(-.995,-.89,body),(-.89,.532,doors[s]),(.532,1.77,body)]:
    patch('Sill shoulder bridge',lambda x,v:mix(flank(x,0,s),deck(flank(x,0,s)[0],s*(.975 if g==doors[s] else .82)),v),np.linspace(a,b,49),span(5),paint,g,(0,0,1))
for k in np.linspace(.12,.90,10):
 x=float(mix(.84,1.77,k));tube('Rear glass heater',[canopy(x,y)+[0,0,.0013] for y in np.linspace(-.944,.944,44)],.0006,graphite)
def lid(u,k):return mix(canopy(1.77,k),deck(tail,k*.86),u)+[0,0,.008*sin(pi*u)]
patch('Notchback trunk lid',lid,span(35),np.linspace(-1,1,55),paint,hatch,(0,0,1))
for s in (-1,1):
 tube('Trunk gutter',[lid(u,s) for u in span(36)],.0038,rubber,hatch)
 patch('Trunk side rail',lambda u,t:mix(lid(u,s),deck(float(mix(1.637,tail,u)),s),t),span(31),span(10),paint,body,(0,0,1))
for s in (-1,1):
 g=doors[s]
 # The mirror sits on the triangular sail at the front of the door.
 region_pts=[flank(-.804,.036,s),flank(-.745,.68,s),flank(-.584,.030,s)]
 mesh('Door mirror sail',region_pts,[(0,1,2)],paint,g,False)
 # The EX's painted stalk is an integrated wing sweeping out of the triangular
 # sail. Its lower edge rises towards the shell, as seen from the A-pillar.
 def mirror_pedestal(u,a):
    y=.760+.100*u
    x=-.694+.032*u
    z=.918+.041*u
    rx=.067-.016*sin(pi*u)
    rz=.028-.009*sin(pi*u)
    ca,sa=cos(a),sin(a)
    return [x+rx*math.copysign(abs(ca)**.69,ca),s*y,z+rz*math.copysign(abs(sa)**.61,sa)+.013*u*ca]
 patch('Door mirror painted pedestal',mirror_pedestal,span(25),np.linspace(0,2*pi,37),paint,g)
 # Cross-sections normal to the viewing direction form a tapered, flat-bottomed cast housing.
 def mirror_face(a,r=1):
    ca,sa=cos(a),sin(a)
    w=np.sign(ca)*abs(ca)**.70;h=np.sign(sa)*abs(sa)**.64
    return np.array([-.587-.018*w*r-.012*h*r,s*(.891+.092*w*r),.964+.052*h*r+.009*w*r])
 def casing(u,a):
    rear=mirror_face(a)
    tip=np.array([-.755,s*.872,.951])
    return mix(tip,rear,sin(u*pi/2))+[-.033*sin(pi*u),0,0]
 patch('Color keyed mirror',casing,np.linspace(.015,1,20),np.linspace(0,2*pi,65),paint,g)
 tube('Door mirror glass gasket',[mirror_face(a) for a in np.arange(56)*2*pi/56],.0036,trim,g,True)
 patch('Mirror face',lambda a,r:mirror_face(a,r)+[.0018*(1-r*r),0,0],np.linspace(0,2*pi,61),np.linspace(.001,.947,13),steel,g,(1,0,0))
 # Moulded handle has a finger cup below a horizontal body-coloured pull.
 y=s*(width(.262)-.007)
 oval('Recess under handle',(.267,y,.780),(.084,.009,.035),paint,g)
 def handle(u,v):
    x=.190+.157*u;bow=sin(pi*u)**.65
    return [x,y+s*(.002+.016*bow+.006*cos(v)*bow),.795+.011*bow+.013*sin(v)*min(1,8*u,8*(1-u))]
 patch('Body colour handle',handle,span(36),np.linspace(0,2*pi,15),paint,g)
 if s<0:oval('Door key barrel',(.336,y+s*.009,.802),(.007,.003,.006),steel,g)
for y in (-.36,.36):
 x=-1.042
 nozzle=deck(x,y/width(x))
 oval('Hood washer jet',nozzle+[0,0,.004],(.011,.007,.005),trim,hood)
