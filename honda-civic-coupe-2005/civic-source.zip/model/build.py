"""Rebuild the editable master and its material-batched, metre-scale glTF export."""
import sys,os
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'model'))
from geometry import *
import shell,wheels,body_structure
if '--blockout' not in sys.argv:
    import finish,interior,cooling,datums,assemblies
    assemblies.reorganize()
    interior.cabin_trim.upholstery_textures()
revision='blockout' if '--blockout' in sys.argv else 'civic'
compress=revision=='civic' and '--uncompressed' not in sys.argv
filename='civic-uncompressed.glb' if revision=='civic' and not compress else f'{revision}.glb'
out=root/'model'/filename
bpy.context.scene.unit_settings.system='METRIC'
bpy.ops.object.select_all(action='DESELECT')
if revision!='blockout':
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(root/'model/civic.blend'), compress=True)
# Bake bevels and lettering, then batch fixed subparts per assembly & material for mobile GPUs.
deps=bpy.context.evaluated_depsgraph_get(); groups_by_material={}
for ob in list(bpy.context.scene.objects):
    if ob.type not in ('MESH','FONT'):continue
    ev=ob.evaluated_get(deps);data=bpy.data.meshes.new_from_object(ev,depsgraph=deps);data.transform(ev.matrix_world)
    key=(ob.parent.name if ob.parent else 'Body',ob.data.materials[0].name)
    groups_by_material.setdefault(key,[]).append(data)
for ob in list(bpy.context.scene.objects):
    if ob.type in ('MESH','FONT'):bpy.data.objects.remove(ob,do_unlink=True)
import bmesh
for (group,mat),meshes in groups_by_material.items():
    bm=bmesh.new()
    for m in meshes:
        bm.from_mesh(m)
    if mat==paint.name:
        bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00018)
    bm.normal_update();data=bpy.data.meshes.new(mat);bm.to_mesh(data);bm.free()
    if not bpy.data.materials[mat].get('fabric_period_m'):
        for layer in list(data.uv_layers):
            data.uv_layers.remove(layer)
    ob=bpy.data.objects.new(group+' · '+mat,data);bpy.context.collection.objects.link(ob);ob.parent=groups[group]
    data.transform(groups[group].matrix_world.inverted());data.materials.clear();data.materials.append(bpy.data.materials[mat])
if revision != "blockout":
    assemblies.save_layout(groups, root/"model/assembly-layout.json")
bpy.ops.export_scene.gltf(
    filepath=str(out), export_format='GLB', export_texcoords=True,
    export_tangents=False, export_animations=False, export_yup=True,
    export_draco_mesh_compression_enable=compress, export_draco_mesh_compression_level=6,
    export_draco_position_quantization=18, export_draco_normal_quantization=14,
)
print('Saved',out,out.stat().st_size)
sys.stdout.flush()
