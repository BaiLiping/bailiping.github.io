"""D17A2 and transverse manual case exterior, based on the 2005 EX parts plates."""
from geometry import *

casting=material('Cast aluminium engine case',(.28,.29,.275),.67,.47)
lidmetal=material('Cast aluminium head cover',(.50,.51,.49),.65,.37)
machined=material('Machined cast faces',(.50,.52,.52),.78,.32)
sumpmetal=material('Oil pan aluminium',(.185,.184,.17),.60,.46)
zinc=material('Engine zinc fasteners',(.39,.39,.35),.76,.34)
copper=material('Alternator copper windings',(.25,.08,.029),.58,.44)
beltmat=material('Accessory belt fabric rubber',(.019,.019,.017),.03,.76)
cx=-1.35;cy=-.12

def zprofile(label,levels,mat):
    # Horizontal profiles interpolate independent intake and exhaust side draft angles.
    def ring(i,a):
        z,front,rear,half,roundness=levels[int(i)]
        c,s=cos(a),sin(a)
        return np.array([cx+(rear if c>0 else front)*np.sign(c)*abs(c)**roundness,
                         cy+half*np.sign(s)*abs(s)**roundness,z])
    angles=np.linspace(0,2*pi,89)
    patch(label,ring,range(len(levels)),angles,mat,motor)
    return ring

def cap(label,ring,index,mat):
    p=ring(index,0)
    patch(label,lambda a,r:mix([cx,cy,p[2]],ring(index,a),r),np.linspace(0,2*pi,89),[0,1],mat,motor)

def screw(label,p,axis,rad=.007):
    p=np.asarray(p);axis=np.asarray(axis,dtype=float);axis/=np.linalg.norm(axis)
    cylinder(label+' washer',p,p+axis*.0018,rad*1.26,zinc,motor,24)
    cylinder(label+' hex',p+axis*.001,p+axis*.0065,rad,zinc,motor,6)

def prism_xz(label,outline,y,depth,mat,radius=.004):
    n=len(outline);verts=[(x,y+d,z) for d in (-depth/2,depth/2) for x,z in outline]
    faces=[tuple(range(n)),tuple(reversed(range(n,2*n)))]+[(i,i+n,(i+1)%n+n,(i+1)%n) for i in range(n)]
    ob=mesh(label,verts,faces,mat,motor,False)
    mod=ob.modifiers.new('Radius of casting','BEVEL');mod.width=radius;mod.segments=3
    ob.modifiers.new('Casting face normals','WEIGHTED_NORMAL')
    return ob

# Open deck, ribbed crankcase skirts and a deep cast sump. Published bore and stroke
# are 75 and 94.4 mm; piston positions show paired crank throws at an illustrative angle.
block=zprofile('D17 crankcase casting',[
    (.342,.143,.105,.215,.37),(.355,.152,.111,.224,.36),(.379,.155,.119,.228,.44),
    (.414,.141,.129,.225,.57),(.465,.125,.110,.220,.57),(.509,.127,.093,.214,.49),
    (.559,.119,.094,.210,.36),(.598,.122,.102,.215,.27),(.606,.124,.102,.215,.27)],casting)
cap('D17 crankcase base',block,0,casting)
bore_x=cx-.018
ys=[-.285,-.197,-.109,-.021]
yslices=[cy-.211]+[(a+b)/2 for a,b in zip(ys,ys[1:])]+[cy+.213]
for i,y in enumerate(ys):
    def deck_ring(a,t):
        co,si=cos(a),sin(a)
        limit_x=((cx+.101 if co>0 else cx-.123)-bore_x)/co if abs(co)>.000001 else 1.e6
        limit_y=((yslices[i+1] if si>0 else yslices[i])-y)/si if abs(si)>.000001 else 1.e6
        r=float(mix(.0375,min(limit_x,limit_y),t))
        return [bore_x+r*co,y+r*si,.606]
    patch('D17 machined cylinder deck',deck_ring,np.linspace(0,2*pi,97),[0,1],machined,motor,(0,0,1))
    depth=.031 if i in (0,3) else .085
    disk('D17 honed cylinder bore',(bore_x,y,.606),(0,0,1),(1,0,0),[(.0375,0),(.0375,-.105)],casting,motor)
    disk('D17 piston crown',(bore_x,y,.606-depth),(0,0,1),(1,0,0),[(.0371,-.016),(.0371,-.001),(.036,0),(.026,0),(.018,-.002),(.0001,-.002)],machined,motor,64)
    for s in (-1,1):
        x=cx+s*.112
        line('D17 crankcase cast web',[(x,y-.031,.592),(x+s*.006,y-.035,.555),(x+s*.018,y-.023,.484),(x+s*.020,y-.044,.427),(x+s*.033,y-.040,.373)],.009,casting,motor)
        screw('D17 deck bolt land',[bore_x+s*.070,y-.026,.606],[0,0,1],.0053)
    tube('D17 oil gallery rib',[(cx-.134,y-.038,.476),(cx-.142,y-.008,.517),(cx-.122,y+.038,.554)],.0053,casting,motor)
# The sump follows a stepped pan rail, with a shallower gearbox end.
def sump(t,a):
    p=block(0,a)
    x,y=p[:2]
    d=smooth((y+.074)/.15);bottom=.226+.041*d
    return [cx+(x-cx)*float(mix(.78,1,t)),cy+(y-cy)*float(mix(.93,1,t)),float(mix(bottom,.341,t))]
patch('D17 oil pan sump wall',sump,span(12),np.linspace(0,2*pi,81),sumpmetal,motor)
patch('D17 oil pan lower pan',lambda a,t:mix([cx,cy,.237],sump(0,a),t),np.linspace(0,2*pi,81),span(9),sumpmetal,motor,(0,0,-1))
for a in np.arange(18)*2*pi/18:
    p=np.array(sump(.97,a));screw('D17 oil pan bolt',p,[0,0,-1],.006)
tube('D17 oil pan flange',[np.asarray(sump(.98,a)) for a in np.arange(96)*2*pi/96],.005,machined,motor,True)
for y in np.linspace(-.296,.061,9):
    z=.229+.041*smooth((y+.074)/.15)
    line('D17 oil pan stiffening rib',[(cx-.135,y,.327),(cx-.13,y,z+.028),(cx-.105,y,z+.003),(cx-.06,y,z)],.0047,sumpmetal,motor)
screw('D17 oil pan drain plug',[cx-.117,-.258,.251],[-1,0,-.15],.010)

head=zprofile('D17 cylinder head casting',[(.606,.123,.104,.219,.28),(.613,.137,.114,.227,.30),(.628,.144,.126,.233,.39),
    (.651,.146,.131,.235,.45),(.671,.133,.120,.234,.39),(.678,.141,.128,.239,.29)],casting)
cap('D17 cylinder head combustion face',head,0,machined);cap('D17 cylinder head upper casting',head,5,casting)
for y in ys:
    disk('D17 cylinder head chamber',(bore_x,y,.605),(0,0,-1),(1,0,0),[(.037,0),(.030,.0008),(.020,.0015),(.001,.0018)],graphite,motor,48)
    for xx in (-.013,.014):
        for yy in (-.012,.012):
            disk('D17 cylinder head valve face',(bore_x+xx,y+yy,.602),(0,0,-1),(1,0,0),[(.011,0),(.010,.001),(.001,.001)],machined,motor,24)
    for s in (-1,1):
        p=[cx+s*(.143 if s<0 else .126),y,.639]
        disk('D17 cylinder head port flange',p,[s,0,0],[0,1,0],[(.017,0),(.027,0),(.027,.005),(.018,.006)],machined,motor,32)

lid=zprofile('D17 valve cover casting',[(.677,.137,.128,.239,.29),(.683,.140,.130,.24,.29),(.688,.129,.121,.232,.36),
    (.703,.124,.108,.229,.48),(.717,.117,.088,.227,.60),(.729,.095,.060,.221,.72)],lidmetal)
cap('D17 valve cover roof',lid,5,lidmetal)
tube('D17 valve cover dark gasket',[head(5,a)+[0,0,.0009] for a in np.arange(96)*2*pi/96],.003,rubber,motor,True)
for y in ys:
    disk('D17 valve cover plug tube',(-1.403,y,.729),(0,0,1),(1,0,0),[(.013,0),(.024,0),(.026,.0015),(.015,.003),(.013,.003)],trim,motor,48)
for dx in (-.113,.096):
    for y in (-.300,.055):
        screw('D17 valve cover stud',[cx+dx,y,.711],[0,0,1],.006)
# Removable timing covers contour around the cam and crank sprockets.
strips=[(-.074,.694),(-.078,.668),(-.061,.632),(-.043,.553),(-.070,.467),
        (-.080,.430),(-.066,.389),(-.033,.366),(.017,.366),(.045,.392),(.045,.432),
        (.027,.506),(.067,.621),(.075,.661),(.063,.692),(.033,.714),(-.028,.714)]
prism_xz('D17 molded timing cover',[(cx+x,z) for x,z in strips],-.358,.034,trim,.009)
for a in (-1.9,-1.2,-.3,.7,2.4):
    p=[cx+.061*cos(a),-.379,.655+.054*sin(a)]
    screw('D17 timing cover fastener',p,[0,-1,0],.005)
# Accessory belt wraps both pulleys with tangential runs.
crank=np.array([cx,-.395,.423]);alt=np.array([cx-.144,-.395,.558]);axis=(0,-1,0)
for title,p,r in [('crank pulley',crank,.067),('alternator pulley',alt,.032)]:
    disk('D17 accessory '+title,p,axis,[1,0,0],[(.008,-.016),(r*.86,-.016),(r,-.012),(r,.008),(r*.92,.011),(r*.85,.008),(r*.75,-.003),(r*.27,-.006),(.010,.004)],graphite,motor,72)
    for z in (-.008,-.004,0,.004):
        disk('D17 accessory pulley groove',p,axis,[1,0,0],[(r,z-.0008),(r+.0006,z),(r,z+.0008)],rubber,motor,72)
    screw('D17 accessory pulley retaining bolt',p+[0,-.007,0],axis,.010)
c1=crank[[0,2]];c2=alt[[0,2]];v=c2-c1;base=math.atan2(v[1],v[0]);offset=math.acos((.067-.032)/np.linalg.norm(v))
a1=base-offset;a2=base+offset
loop=[c2+.033*np.array([cos(a),sin(a)]) for a in np.linspace(a1,a2,45)]
loop+= [c1+.068*np.array([cos(a),sin(a)]) for a in np.linspace(a2,a1+2*pi,68)]
pts=[np.array([x,-.392,z]) for x,z in loop]
patch('D17 accessory ribbed belt',lambda i,k:pts[int(i)%len(pts)]+[0,.010*k,0],range(len(pts)+1),[-1,1],beltmat,motor)
# Vented front and rear bell castings surround the alternator stator windings.
p=alt+[0,.060,0]
disk('D17 accessory stator',p,axis,[1,0,0],[(.015,-.049),(.047,-.049),(.047,.041),(.015,.041)],copper,motor,56)
for z in (-.043,.032):
    disk('D17 accessory alternator end ring',p,axis,[1,0,0],[(.015,z),(.050,z),(.053,z+.004),(.054,z+.009),(.048,z+.011),(.021,z+.016),(.015,z+.016)],casting,motor,56)
for a in np.arange(13)*2*pi/13:
    def fin(t,w):
        rr=.0523+.002*sin(pi*t);az=a+.16*t+.059*w
        return p+[rr*cos(az),-.063*(t-.42),rr*sin(az)]
    patch('D17 accessory alternator ventilation bridge',fin,span(9),[-1,1],casting,motor)
prism_xz('D17 accessory adjuster bracket',[(cx-.178,.550),(cx-.175,.587),(cx-.083,.632),(cx-.046,.623),(cx-.066,.602),(cx-.111,.603)],-.306,.015,casting,.005)
# Two irregular lobes of the manual case follow the input/secondary shafts and differential.
# The gearbox meets the relocated engine face and returns to the differential at the axle.
def gearbox_shape(t,a):
    station=[(.083,-1.446,.433,.151,.159),(.110,-1.438,.429,.156,.166),(.174,-1.415,.422,.148,.154),
             (.247,-1.393,.416,.145,.143),(.323,-1.381,.416,.136,.128),(.40,-1.378,.428,.124,.116),
             (.474,-1.368,.435,.106,.098),(.49,-1.369,.435,.099,.095)]
    y,x,z,rx,rz=station[int(t)]
    c,q=cos(a),sin(a)
    # Differential bulge is offset aft and below the input axis.
    bulge=math.exp(-((math.atan2(sin(a+.83),cos(a+.83)))/.58)**2)
    factor=1+(.24+.15*sin(y*7))*bulge
    return np.array([x+rx*factor*c,y,z+rz*factor*q])
ang=np.linspace(0,2*pi,105)
patch('Gearbox transmission case',gearbox_shape,range(2,8),ang,casting,motor)
for t in (7,):
    p=gearbox_shape(t,0);c=p-[.12,0,0]
    patch('Gearbox end cover',lambda a,r:mix(c,gearbox_shape(t,a),r),ang,[0,1],casting,motor)
for t in (5,7):
    ring=[gearbox_shape(t,a) for a in np.arange(96)*2*pi/96]
    tube('Gearbox mating flange',ring,.0058,machined,motor,True)
    for a in np.arange(10)*2*pi/10:
        v=gearbox_shape(t,a);screw('Gearbox flange bolt',v,[0,1,0],.006)
for a in np.arange(11)*2*pi/11:
    line('Gearbox cast stiffening web',[gearbox_shape(t,a+.10*sin(t*.51)) for t in range(2,8)],.0053,casting,motor)
for t in (2,3,4):
    p=gearbox_shape(t,-.42);screw('Gearbox case plug',p,[1,0,-.2],.009)
starter=[-1.517,.147,.521]
disk('Gearbox starter motor',starter,[0,1,0],[1,0,0],[(.019,0),(.038,.009),(.040,.026),(.039,.115),(.035,.121),(.015,.125),(.001,.125)],graphite,motor,48)
disk('Gearbox starter solenoid',np.array(starter)+[-.018,.020,.047],[0,1,0],[1,0,0],[(.012,0),(.021,0),(.021,.069),(.016,.073),(.001,.073)],machined,motor,40)

# Traced on the SLW bellhousing photograph (reference 32, coordinates on a
# 640-pixel proof). The mating face is open when the transaxle is removed.
def bell_point(u, v, depth):
    return np.array([-1.454 + (u - 281) / 1240, depth, .423 + (346 - v) / 1240])

bell_edges = [(472,345),(457,403),(420,457),(378,494),(328,523),(260,530),
              (196,516),(148,487),(113,443),(96,400),(94,320),(104,273),
              (124,208),(144,144),(172,130),(294,109),(322,114),(344,139),
              (402,179),(440,229),(465,283)]
bell_lip = [bell_point(u,v,.083) for u,v in bell_edges]
bell_angles = [math.atan2(p[2]-.423,p[0]+1.454) for p in bell_lip]
def bell_section(label, rings, surface):
    n = len(rings[0])
    faces = [(i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j)
             for i in range(len(rings)-1) for j in range(n)]
    return mesh(label,[p for ring in rings for p in ring],faces,surface,motor)
rim_center = bell_point(281,346,.083)
def inset_ring(scale, depth):
    return [rim_center + (p-rim_center)*scale + [0,depth-.083,0] for p in bell_lip]

bell_section('Gearbox bellhousing outer skirt',
             [bell_lip,inset_ring(.988,.105),[gearbox_shape(2,a) for a in bell_angles]],casting)
bell_section('Gearbox machined bellhousing rim',[inset_ring(.942,.083),bell_lip],machined)
bell_section('Gearbox recessed bellhousing wall',
             [inset_ring(.125,.160),inset_ring(.51,.155),inset_ring(.82,.139),inset_ring(.942,.083)],casting)
# A stepped release bearing and input shaft stand in front of the recessed back.
bell_normal = (0,-1,0)
def bell_ring(label, u, v, depth, profile, surface):
    disk('Gearbox '+label,bell_point(u,v,depth),bell_normal,(1,0,0),profile,surface,motor)
bell_ring('input bearing seat',281,346,.161,[(.009,0),(.032,0),(.032,.009),(.026,.015),(.015,.015)],casting)
bell_ring('release bearing',281,346,.149,[(.013,0),(.028,0),(.028,.024),(.024,.028),(.013,.028)],graphite)
bell_ring('release bearing collar',281,346,.123,[(.013,0),(.022,0),(.022,.003),(.013,.003)],machined)
bell_ring('input shaft',281,346,.150,[(.001,0),(.011,0),(.011,.067),(.008,.074),(.002,.074)],machined)
for a in np.arange(18)*2*pi/18:
    p = bell_point(281,346,.096) + [.0104*cos(a),0,.0104*sin(a)]
    cylinder('Gearbox input shaft spline',p,p+[0,-.014,0],.0012,zinc,motor,6)
# The fork straddles the release bearing. The casting has webs from the bowl
# floor to the rim, including the distinctive vertical ribs above the bearing.
prism_xz('Gearbox clutch release fork',
         [tuple(bell_point(u,v,.13)[[0,2]]) for u,v in
          [(134,313),(213,322),(257,306),(277,307),(258,325),(246,341),
           (249,362),(269,381),(254,383),(223,364),(197,356),(135,349)]],.133,.010,machined,.002)
for start, end in [((298,293),(307,124)),((340,320),(338,144)),((350,331),(433,310)),
                   ((341,369),(434,411)),((330,386),(391,468)),((277,397),(202,499)),
                   ((250,385),(122,387)),((237,302),(131,280)),((286,296),(218,216))]:
    a=bell_point(*start,.150);b=bell_point(*end,.101)
    tube('Gearbox clutch housing cast rib',[a,(a+b)*.5+[0,.009,0],b],.0031,casting,motor)
# The axle seal sits in a separate casting beyond the clutch cavity.
bell_ring('differential extension',491,404,.173,[(.020,0),(.048,0),(.046,.035),(.041,.058),(.033,.063),(.020,.063),(.020,0)],casting)
bell_ring('differential axle seal',491,404,.112,[(.016,0),(.027,0),(.027,.003),(.024,.005),(.018,.004),(.016,0)],graphite)
bell_ring('axle bore',491,404,.172,[(.016,0),(.016,.060)],graphite)
for u,v in [(145,153),(323,122),(100,288),(94,412),(156,510),(418,515),(496,245),(591,350),(593,412)]:
    p = bell_point(u,v,.085)
    disk('Gearbox mounting ear',p,bell_normal,(1,0,0),[(.005,-.014),(.014,-.014),(.014,.001),(.005,.001),(.005,-.014)],machined,motor,32)
    if u>480:
        a=bell_point(485,390,.123)
        tube('Gearbox cast extension rib',[a,(a+p)*.5+[0,.002,0],p+[0,.009,0]],.009,casting,motor)
