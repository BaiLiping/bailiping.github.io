"""Radiator stack, electric cooling fans and lower hose behind the upper support."""
from geometry import *
aluminized=material('Aluminized radiator fins',(.22,.25,.26),.70,.46)
def molded(name,location,size,m,bevel):
    return box('Cooling pack '+name,location,size,m,body,bevel)
molded('A/C condenser',(-1.886,0,.442),(.022,.950,.302),graphite,.006)
for z in np.linspace(.299,.584,28):
    molded('condenser tubes',(-1.899,0,z),(.0016,.939,.0019),aluminized,.0005)
for s in (-1,1):
    molded('radiator header tank',(-1.846,s*.500,.443),(.054,.049,.317),trim,.014)
    molded('condenser manifold',(-1.888,s*.480,.441),(.024,.015,.296),aluminized,.007)
# Fan blades are cambered and pitched around the stationary motor, with open sightlines
# through the frame. The cowl varies from a square core footprint to the circular venturi.
x=-1.801
for y,r in [(-.224,.149),(.219,.137)]:
    z=.444
    def shroud(a,t):
        c,q=cos(a),sin(a)
        # On the core side, lay a soft rectangular perimeter against the fins.
        outer=1/max(abs(c)/.211,abs(q)/.160)
        radius=float(mix(r+.002,outer,t))
        return [x-.028*t,y+radius*c,z+radius*q]
    patch('Cooling pack fan shroud',shroud,np.linspace(0,2*pi,113),span(10),trim,body,(1,0,0))
    disk('Cooling pack fan throat',(x,y,z),(1,0,0),(0,1,0),[(r+.012,-.013),(r+.005,.005),(r,.009),(r,-.007)],trim,body,80)
    for i in range(7):
        a=2*pi*i/7
        def blade(t,w):
            radius=.038+(r-.045)*t
            angle=a+.32*t+(.49-.16*t)*w
            depth=-.011+.012*w+.005*sin(pi*t)+.004*t*w
            return [x+depth,y+radius*cos(angle),z+radius*sin(angle)]
        patch('Cooling pack swept fan blade',blade,span(19),span(8),rubber,body,(1,0,0))
    disk('Cooling pack fan hub',(x,y,z),(1,0,0),(0,1,0),[(.008,-.033),(.037,-.027),(.043,-.011),(.041,.012),(.029,.022),(.003,.022)],trim,body,48)
    for a in np.arange(4)*pi/2+.40:
        line('Cooling pack motor support',[(x+.022,y+.040*cos(a),z+.040*sin(a)),(x+.027,y+.095*cos(a+.17),z+.095*sin(a+.17)),(x+.014,y+r*cos(a+.16),z+r*sin(a+.16))],.006,trim,body)
    line('Cooling pack fan harness',[(x+.023,y,z+.017),(x+.032,y+.085,z+.049),(x+.014,y+.166,z+.14)],.004,rubber,body)
line('Cooling pack lower coolant hose',[(-1.822,.397,.302),(-1.731,.392,.311),(-1.675,.246,.346),(-1.559,.119,.396),(-1.422,.118,.431)],.020,rubber,body)
for s in (-1,1):
    molded('upper core peg',(-1.838,s*.377,.612),(.036,.065,.026),rubber,.007)
