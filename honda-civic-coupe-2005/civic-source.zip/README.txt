2005 Honda Civic EX Coupe in Rallye Red

Open model/civic.blend in Blender 4.3 or later. This master keeps individual panels, lamps, switches, interior components and mechanical parts. Blender X points aft and Z points up. The GLB uses Y up.

Rebuild in Blender 4.3.2 with its bundled NumPy. Run from the unzipped folder:

  blender --background --factory-startup --python model/build.py

Blender writes the editable model/civic.blend with full-precision geometry. The civic.glb delivery uses Blender’s bundled Draco encoder at compression level 6 with 18-bit positions and 14-bit normals. Append -- --uncompressed to the same Blender command to produce model/civic-uncompressed.glb. The web export batches each fixed assembly by material while retaining the door, hood and trunk pivots. studio.json contains the saved cameras and offsets in GLB coordinates. comparison-data.json provides source, credit and fit measurements by frame. camera-fit/match_interiors.py records the native camera landmarks and fitting method for the cockpit and ignition-cover macro. With NumPy, OpenCV and SciPy installed, run python camera-fit/match_interiors.py --output review to regenerate the two detail camera matrices and source landmarks.
