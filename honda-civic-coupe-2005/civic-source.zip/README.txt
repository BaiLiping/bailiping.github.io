2005 Honda Civic EX Coupe, US-market EM2, Rallye Red, five-speed manual

Open model/civic.blend in Blender to edit the full assembly. The editable
master uses metres, X aft and Z up. The browser's glTF has Y up.
Rebuild using Blender 4.3.2 from the extracted archive root:

    blender --background --factory-startup --python-exit-code 1 --python model/build.py

The build writes model/civic.blend, model/civic.glb, model/datums.json and
model/assembly-layout.json. The GLB uses Draco compression with 18-bit positions
and 14-bit normals. Add -- --uncompressed to produce an uncompressed export.

The instrument cluster, shifter and console use the 2005 US EX five-speed
coupe photographed for Bring a Trailer lot 211588. The odometer digits are
illustrative. The rear bumper return was revised against five locked cameras
of the same donor. The exposed transmission uses a freestanding SLW gearbox
photograph. Ribs, casting wall depth and obscured parts are reconstructed.


The original pre-revision camera annotations and studio configuration are
retained in previous-release/ for reproducibility of the earlier frame set.

The studio environment is a filtered 768 x 384 copy of Studio Small 09
by Sergej Majboroda for Poly Haven, licensed CC0.
https://polyhaven.com/a/studio_small_09

The current 3D viewer settings are in studio.json. honda-views.json indexes
the comparison cameras, credited photographs and frame-specific findings.
reference-library.json lists the original sources for the full photo and
workshop reference collection. Compare camera positions in metric glTF
coordinates. The saved camera fits and their calibration landmarks are in
benchmark/cameras.json. Model geometry is tied to the GLB digest below.

d85c67086a39c938beaf5003f02ab0e76126228b79be204efdec700cac26b90c  civic.glb
