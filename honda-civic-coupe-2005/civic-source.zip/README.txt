2005 Honda Civic EX Coupe in Rallye Red

Open model/civic.blend to edit individual body panels, lamps, cabin trim, wheels, suspension and mechanical parts. Blender uses metres, with X pointing aft and Z up. In the browser Y points up.

To rebuild the editable master and compressed web export, run this in the unzipped directory with Blender 4.3.2:

    blender --background --factory-startup --python-exit-code 1 --python model/build.py

The rebuild produces model/civic.blend, model/civic.glb, model/datums.json and model/assembly-layout.json. To export an uncompressed GLB add -- --uncompressed to the command. The compressed file uses Draco with 18-bit positions and 14-bit normals. The export batches by material within each removable component and preserves hinges and parent transforms. The generated layout contains the component labels and translations used by the exploded view.

studio.json contains the released cameras and assembly poses. comparison-data.json records reference links, image dimensions, landmark fits and known differences. extra-frames.json contains annotations for the additional exterior references. match_interiors.py documents the cockpit and cover camera fits. Exterior styling uses Honda and real-car photographs. Hidden shapes and mounting points are reconstructed from parts illustrations and photographs. The 75 mm bores and 94.4 mm stroke use Honda’s published dimensions. The internal gear train is outside the reconstruction.

Studio lighting uses a filtered 768 × 384 copy of Studio Small 09 by Sergej Majboroda for Poly Haven, licensed CC0. https://polyhaven.com/a/studio_small_09
