"""Apply calibrated factory surface detail to visible engine castings and PDK housing."""
import json
import re
from pathlib import Path
import numpy as np
import bpy

ROOT=Path(__file__).with_name('finishes')

def apply():
    entries=json.loads((ROOT/'registration.json').read_text())
    for ref in entries:
        key=ref['id']
        ref['depth']=np.load(ROOT/(key+'.npz'))['depth']
        m=bpy.data.materials.new('Factory surface · '+key);m.use_nodes=True
        bsdf=m.node_tree.nodes.get('Principled BSDF')
        tex=m.node_tree.nodes.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(ROOT/(key+'.jpg')),check_existing=True);tex.image.pack()
        m.node_tree.links.new(tex.outputs['Color'],bsdf.inputs['Base Color'])
        m.node_tree.links.new(tex.outputs['Color'],bsdf.inputs['Emission Color'])
        bsdf.inputs['Metallic'].default_value=.18;bsdf.inputs['Roughness'].default_value=.61
        bsdf.inputs['Emission Strength'].default_value=.36
        ref['material']=m
    for obj in bpy.context.scene.objects:
        refs=[r for r in entries if re.search(r['group'],obj.name) and not(r['hide'] and re.search(r['hide'],obj.name))]
        if not refs or obj.type!='MESH' or re.search('PhaseLeads|UpperHarness|EMotor|Tip_',obj.name):continue
        mesh=obj.data;vs=np.array([v.co[:] for v in mesh.vertices]);T=np.array(obj.matrix_world);xyz=vs@T[:3,:3].T+T[:3,3]
        centres=np.empty(len(mesh.polygons)*3,'f4');mesh.polygons.foreach_get('center',centres);centres=centres.reshape(-1,3)@T[:3,:3].T+T[:3,3]
        normals=np.empty(len(mesh.polygons)*3,'f4');mesh.polygons.foreach_get('normal',normals);normals=normals.reshape(-1,3)@np.linalg.inv(T[:3,:3])
        normals/=np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-8)
        best=np.zeros(len(centres));chosen=np.full(len(centres),-1,dtype=int)
        maps=[]
        for idx,r in enumerate(refs):
            eye=np.array(r['eye']);R=np.array(r['axes']);w,h=r['width'],r['height']
            def project(pts):
                q=(pts-eye)@R.T
                return q[:,:2]*r['focal']/q[:,2:]+np.array([w/2,h/2]),q[:,2]
            xy,z=project(centres);uv,_=project(xyz);maps.append(uv/[w,h]*[1,-1]+[0,1])
            ix=np.clip(np.int32(xy[:,0]),0,w-1);iy=np.clip(np.int32(xy[:,1]),0,h-1);depth=r['depth'][iy,ix]
            toEye=eye-centres;toEye/=np.maximum(np.linalg.norm(toEye,axis=1,keepdims=True),1e-8)
            facing=(normals*toEye).sum(1)
            score=facing*np.clip((.068-abs(depth-z))/.04,0,1)
            if r['id']=='engine-rear':score*=1.09
            keep=(score>.16)&(score>best)&(depth>0)&(xy[:,0]>=0)&(xy[:,0]<w)&(xy[:,1]>=0)&(xy[:,1]<h)
            best[keep]=score[keep];chosen[keep]=idx
        if not np.any(chosen>=0):continue
        layer=mesh.uv_layers.active or mesh.uv_layers.new()
        slots=[]
        for r in refs:slots.append(len(mesh.materials));mesh.materials.append(r['material'])
        for face in mesh.polygons:
            i=chosen[face.index]
            if i<0:continue
            face.material_index=slots[i]
            for loop,vert in zip(face.loop_indices,face.vertices):layer.data[loop].uv=maps[i][vert]
