"""992.2 Porsche 911 Turbo S Cabriolet — Yellow PCCB Calipers, MacPherson Front & 5-Link Rear Suspension.

Photo-matched to `911 Turbo S Cabriolet (50).jpeg`, `(3).jpeg`, and official factory illustrations
`Rolling chassis and electrical routing - view 1.jpg` & `view 2.jpg`:
- Front PCCB: massive Speed Yellow 10-piston monobloc fixed caliper mounted TRAILING (-X side of front rotor)
  with sculpted piston bores, stainless pad pins/bolts, crossover tube, and curved black `PORSCHE` lettering.
- Rear PCCB: Speed Yellow 4-piston monobloc fixed caliper mounted LEADING (+X side of rear rotor) with
  curved black `PORSCHE` lettering + black electromechanical parking brake actuator.
- Front suspension: MacPherson PASM coilover strut (3-bolt aluminum top mount, black progressive helical spring),
  cast aluminum steering knuckle/upright, forged lower transverse control arm + diagonal trailing/tension link.
- Rear suspension: lightweight 5-link aluminum multi-link suspension + rear-axle steering actuator pod + PASM coilover.
- Chassis-mounted: electromechanical power steering rack + tie rods, front & rear ehPDCC active anti-roll bars,
  and all four AWD CV half-shafts with convoluted rubber boots.
"""

from __future__ import annotations

import math
from typing import Any

import bpy
import numpy as np
from mathutils import Matrix, Vector

from .common import (
    bolt_array,
    ellipse_case,
    helical_coil,
    join_objects,
    loft_sections,
    revolve_profile,
    round_box,
    text_to_mesh,
    tube_along_points,
)


def _build_pccb_caliper(
    corner: str,
    side: float,
    is_rear: bool,
    rotor_r: float,
    rotor_t: float,
    friction_y: float,
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> bpy.types.Object:
    """Build sculpted Speed Yellow PCCB monobloc fixed caliper (10-piston F trailing / 4-piston R leading)."""
    # Front caliper sits on REARWARD (-X) side of front disc; Rear caliper sits on FORWARD (+X) side of rear disc!
    x_dir = +1.0 if is_rear else -1.0
    arc_half = math.radians(39.0) if is_rear else math.radians(53.0)
    r_in = rotor_r * 0.675
    r_out = rotor_r + 0.022
    y_mid = friction_y - 0.5 * rotor_t
    y_out_face = friction_y + (0.032 if not is_rear else 0.027)
    y_in_face = y_mid - (0.5 * rotor_t + (0.036 if not is_rear else 0.030))

    parts: list[bpy.types.Object] = []

    # Sculpted monobloc caliper body lofted along rotor arc with distinct stepped 10-piston lobes & central flat PORSCHE spine!
    n_arc = 27
    ts = np.linspace(-arc_half, arc_half, n_arc)
    sections = []
    for t in ts:
        end_frac = abs(t) / arc_half
        taper = 1.0 - 0.16 * max(0.0, (end_frac - 0.70) / 0.30) ** 2
        # Distinct sculpted piston-bore cheeks (5 bores per side front / 2 per side rear)
        n_pist = 5 if not is_rear else 2
        piston_lobe = 0.0055 * (0.5 + 0.5 * math.cos(n_pist * 2.0 * math.pi * (t / (2.0 * arc_half)))) * (1.0 - 0.45 * end_frac**2)

        r0 = r_in + (1.0 - taper) * 0.024
        r1 = r_out - (1.0 - taper) * 0.018
        r_span = r1 - r0
        # Stepped profile: inner cheek -> raised crisp flat PORSCHE center plaque -> outer scalloped piston cheek -> recessed pad bridge!
        r_p1 = r0 + 0.22 * r_span
        r_p2 = r0 + 0.62 * r_span
        r_p3 = r0 + 0.84 * r_span

        y_spine = y_out_face + 0.003 - (1.0 - taper) * 0.006
        y_cheek = y_out_face - 0.001 + piston_lobe - (1.0 - taper) * 0.007
        yi = y_in_face + (1.0 - taper) * 0.007

        prof = [
            (r0, friction_y + 0.005),
            (r0 + 0.006, y_cheek - 0.007),
            (r_p1, y_cheek),
            (r_p1 + 0.005, y_spine),
            (r_p2, y_spine),
            (r_p2 + 0.005, y_cheek),
            (r_p3, y_cheek - 0.002),
            (r1 - 0.005, y_out_face - 0.010),
            (r1, y_mid + 0.008),
            (r1, y_mid - 0.008),
            (r1 - 0.005, yi + 0.008),
            (r_p2, yi),
            (r_p1, yi),
            (r0 + 0.006, yi + 0.006),
            (r0, friction_y - rotor_t - 0.005),
            (r_out - 0.014, friction_y - rotor_t - 0.005),
            (r_out - 0.012, friction_y + 0.005),
        ]
        ct, st = math.cos(t), math.sin(t)
        ring = [(x_dir * rr * ct, side * yy, rr * st) for rr, yy in prof]
        sections.append(ring)

    body = loft_sections(f"_tmp_cal_body_{corner}", sections, mats["caliper_yellow"], parent=None, cap_ends=True, smooth=True)
    parts.append(body)

    # Dark recessed brake pad carrier & stainless bridge bolts visible along outer scalloped spine (`(50).jpeg`!)
    for t_pad in (-0.42 * arc_half, 0.0, 0.42 * arc_half):
        r_b = r_out - 0.003
        px = x_dir * r_b * math.cos(t_pad)
        pz = r_b * math.sin(t_pad)
        parts.append(round_box(
            f"_tmp_cal_bridge_{corner}_{t_pad:.2f}",
            (px, side * y_mid, pz),
            (0.016, rotor_t + 0.026, 0.022),
            mats["gunmetal"],
            parent=None,
            bevel=0.003,
            rot_euler=(0.0, -x_dir * t_pad, 0.0),
        ))
    # Dark outer pad-window recess pocket on outboard shoulder (gives exact stepped silhouette of 10-piston PCCB!)
    for t_win in (-0.28 * arc_half, 0.28 * arc_half):
        r_w = r_out - 0.012
        parts.append(round_box(
            f"_tmp_cal_padwin_{corner}_{t_win:.2f}",
            (x_dir * r_w * math.cos(t_win), side * (y_out_face - 0.006), r_w * math.sin(t_win)),
            (0.016, 0.012, 0.042 if not is_rear else 0.028),
            mats["pccb_hole"],
            parent=None,
            bevel=0.002,
            rot_euler=(0.0, -x_dir * t_win, 0.0),
        ))

    # Stainless pad retaining bolts / caliper bridge fasteners (visible on (50).jpeg!)
    bolt_angles = [-0.62 * arc_half, 0.62 * arc_half] if is_rear else [-0.66 * arc_half, -0.24 * arc_half, 0.24 * arc_half, 0.66 * arc_half]
    b_pts = [
        (x_dir * (r_in + 0.016) * math.cos(a), side * (y_out_face + 0.001), (r_in + 0.016) * math.sin(a))
        for a in bolt_angles
    ]
    parts.append(bolt_array(f"_tmp_cal_bolts_{corner}", b_pts, radius=0.0048, height=side * 0.0055, material=mats["stainless"], parent=None, axis="y", sides=6))

    # Hydraulic steel crossover pipe & bleeder nipple at top of caliper
    t_top = 0.85 * arc_half
    r_pipe = r_out + 0.004
    parts.append(tube_along_points(
        f"_tmp_cal_pipe_{corner}",
        [
            (x_dir * (r_pipe - 0.012) * math.cos(t_top), side * (y_out_face - 0.008), (r_pipe - 0.012) * math.sin(t_top)),
            (x_dir * r_pipe * math.cos(t_top), side * y_mid, r_pipe * math.sin(t_top)),
            (x_dir * (r_pipe - 0.012) * math.cos(t_top), side * (y_in_face + 0.008), (r_pipe - 0.012) * math.sin(t_top)),
        ],
        0.0032,
        mats["stainless"],
        parent=None,
        sides=10,
        subdiv=3,
    ))

    # Black curved "PORSCHE" lettering centered cleanly on the raised flat central spine inside the 3:00 spoke window!
    # All 7 letters span +-11.2 deg so P..E stay 100% visible & unclipped between the adjacent Y-spokes!
    r_txt = r_in + 0.42 * (r_out - r_in)
    y_txt = side * (y_out_face + 0.0050)
    word = "PORSCHE"
    fsize = 0.0112 if not is_rear else 0.0102
    step_a = (fsize * 0.58) / r_txt
    half_w = 0.5 * (len(word) - 1)
    for j, ch in enumerate(word):
        ang = (half_w - j) * step_a if (x_dir * side < 0) else (j - half_w) * step_a
        rad = Vector((x_dir * math.cos(ang), 0.0, math.sin(ang)))
        out_n = Vector((0.0, side, 0.0))
        tang_x = rad.cross(out_n).normalized()
        rot_m = Matrix((tang_x, rad, out_n)).transposed()
        pos = rad * r_txt + Vector((0.0, y_txt, 0.0))
        parts.append(text_to_mesh(
            f"_tmp_cal_txt_{corner}_{j}",
            ch,
            fsize,
            mats["caliper_text"],
            parent=None,
            extrude=0.0010,
            location=pos,
            rot_matrix=rot_m,
        ))

    # Rear electromechanical parking brake actuator pod on inboard rear face (992.2 standard!)
    if is_rear:
        parts.append(ellipse_case(
            f"_tmp_epb_{corner}",
            [
                (side * (y_in_face - 0.002), 0.095, -0.105, 0.032, 0.032),
                (side * (y_in_face - 0.055), 0.095, -0.105, 0.030, 0.030),
                (side * (y_in_face - 0.062), 0.095, -0.105, 0.024, 0.024),
            ],
            mats["engine_plastic"],
            parent=None,
            axis="y",
            steps=20,
        ))

    return join_objects(f"TSC_Caliper_{corner}", parts, parent=parent)


def _build_front_corner_suspension(
    corner: str,
    side: float,
    z_hub: float,
    y_hub_abs: float,
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> None:
    """Build front MacPherson strut, cast aluminum upright, forged wishbone & trailing arm (local to Pivot_Corner)."""
    # Local origin of Pivot_Corner_FL/FR is at (x_axle, side * y_hub_abs, z_hub).
    # Inboard direction in local coords is -side * Y!
    inb = -side

    # 1) Cast aluminum steering knuckle / upright
    kn_parts: list[bpy.types.Object] = []
    # Main upright vertical forging
    kn_sec = []
    for dy_in, zz, dx_w, dy_t in [
        (0.088, -0.135, 0.024, 0.018),
        (0.092, -0.075, 0.042, 0.024),
        (0.098,  0.000, 0.068, 0.028),
        (0.112,  0.078, 0.044, 0.026),
        (0.128,  0.148, 0.034, 0.024),
    ]:
        kn_sec.append([
            (-dx_w, inb * (dy_in - dy_t), zz),
            ( dx_w, inb * (dy_in - dy_t), zz),
            ( dx_w, inb * (dy_in + dy_t), zz),
            (-dx_w, inb * (dy_in + dy_t), zz),
        ])
    kn_parts.append(loft_sections(f"_tmp_fkn_body_{corner}", kn_sec, mats["cast_alu"], parent=None, cap_ends=True, smooth=True))

    # Wheel bearing hub housing & center-lock stub axle carrier
    kn_parts.append(revolve_profile(
        f"_tmp_fkn_hub_{corner}",
        [
            (0.030, -0.055), (0.064, -0.055), (0.068, -0.088),
            (0.056, -0.122), (0.032, -0.122),
        ],
        mats["gunmetal"],
        parent=None,
        axis="y",
        side_sign=side,
        steps=28,
        closed_profile=True,
        smooth=True,
    ))

    # Caliper mounting ears reaching back (-X) to meet the 10-piston caliper
    for z_ear in (-0.098, 0.098):
        kn_parts.append(tube_along_points(
            f"_tmp_fkn_ear_{corner}_{z_ear:.2f}",
            [(0.0, inb * 0.105, z_ear * 0.55), (-0.095, inb * 0.108, z_ear), (-0.145, inb * 0.102, z_ear * 1.05)],
            0.014,
            mats["cast_alu"],
            parent=None,
            sides=10,
            subdiv=2,
        ))
    # Forward steering arm lug meeting tie rod
    kn_parts.append(tube_along_points(
        f"_tmp_fkn_steerarm_{corner}",
        [(0.035, inb * 0.102, -0.045), (0.115, inb * 0.118, -0.068), (0.148, inb * 0.132, -0.072)],
        0.013,
        mats["cast_alu"],
        parent=None,
        sides=10,
        subdiv=2,
    ))
    join_objects(f"TSC_Front_Knuckle_{corner}", kn_parts, parent=parent)

    # 2) MacPherson PASM Coilover Strut (angled inward from upright up to front shock tower Z ≈ 0.74 m)
    p_bot = Vector((-0.010, inb * 0.126, 0.115))
    p_top = Vector((-0.036, inb * 0.258, 0.405))  # World Z ≈ 0.338 + 0.405 = 0.743 m (safely under front fender!)
    strut_axis = (p_top - p_bot).normalized()
    u_ax = strut_axis.cross(Vector((1.0, 0.0, 0.0))).normalized()
    v_ax = strut_axis.cross(u_ax).normalized()

    strut_parts: list[bpy.types.Object] = []
    def _strut_sleeve(sname: str, prof_tr: list[tuple[float, float]], mat: bpy.types.Material) -> bpy.types.Object:
        rings = []
        for t, rr in prof_tr:
            c = p_bot.lerp(p_top, t)
            rings.append([tuple(c + (u_ax * math.cos(q) + v_ax * math.sin(q)) * rr) for q in np.linspace(0, 2 * math.pi, 24, endpoint=False)])
        return loft_sections(sname, rings, mat, parent=None, cap_ends=True, smooth=True)

    strut_parts.append(_strut_sleeve(f"_tmp_fdamper_{corner}", [(0.0, 0.025), (0.10, 0.028), (0.56, 0.028), (0.60, 0.021)], mats["machined_alu"]))
    strut_parts.append(_strut_sleeve(f"_tmp_frod_{corner}", [(0.54, 0.011), (0.94, 0.011)], mats["stainless"]))
    strut_parts.append(_strut_sleeve(f"_tmp_fperch_lo_{corner}", [(0.22, 0.029), (0.25, 0.056), (0.28, 0.057), (0.30, 0.044)], mats["gunmetal"]))
    strut_parts.append(_strut_sleeve(f"_tmp_fperch_hi_{corner}", [(0.82, 0.048), (0.85, 0.057), (0.91, 0.056), (0.95, 0.036)], mats["cast_alu"]))

    # Iconic circular 3-bolt aluminum MacPherson top mount visible in Rolling chassis view 1!
    strut_parts.append(_strut_sleeve(f"_tmp_ftopmount_{corner}", [(0.94, 0.068), (0.97, 0.072), (1.00, 0.068)], mats["machined_alu"]))
    # Helical black PASM road spring
    strut_parts.append(helical_coil(
        f"_tmp_fspring_{corner}",
        p_bot.lerp(p_top, 0.27),
        p_bot.lerp(p_top, 0.85),
        coil_radius=0.048,
        wire_radius=0.0074,
        turns=6.2,
        material=mats["spring_black"],
        parent=None,
        sides=10,
        steps_per_turn=18,
    ))
    join_objects(f"TSC_Front_Strut_Coilover_{corner}", strut_parts, parent=parent)

    # 3) Forged aluminum lower transverse control arm + diagonal trailing tension strut
    y_subframe_in = y_hub_abs - 0.375  # Meets front subframe rail at |Y| ≈ 0.375 m
    arm_parts: list[bpy.types.Object] = []
    # Main transverse lower control arm (outer ball joint to subframe)
    arm_parts.append(tube_along_points(
        f"_tmp_flca_{corner}",
        [(0.005, inb * 0.095, -0.132), (0.002, inb * 0.240, -0.128), (-0.015, inb * y_subframe_in, -0.118)],
        [0.018, 0.022, 0.020],
        mats["machined_alu"],
        parent=None,
        sides=12,
        subdiv=3,
    ))
    # Forged diagonal trailing / tension arm sweeping rearward to subframe bushing
    arm_parts.append(tube_along_points(
        f"_tmp_ftrail_{corner}",
        [(0.005, inb * 0.145, -0.130), (-0.115, inb * 0.265, -0.125), (-0.255, inb * (y_subframe_in - 0.02), -0.118)],
        [0.015, 0.018, 0.019],
        mats["cast_alu"],
        parent=None,
        sides=12,
        subdiv=3,
    ))
    # Rubber bushings at inner pivots
    for bx, by_in in [(-0.015, y_subframe_in), (-0.255, y_subframe_in - 0.02)]:
        arm_parts.append(ellipse_case(
            f"_tmp_fbush_{corner}_{bx:.2f}",
            [(bx - 0.028, inb * by_in, -0.118, 0.024, 0.024), (bx + 0.028, inb * by_in, -0.118, 0.024, 0.024)],
            mats["rubber_hose"],
            parent=None,
            axis="x",
            steps=16,
        ))
    join_objects(f"TSC_Front_LowerWishbone_{corner}", arm_parts, parent=parent)


def _build_rear_corner_suspension(
    corner: str,
    side: float,
    z_hub: float,
    y_hub_abs: float,
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> None:
    """Build rear lightweight 5-link multi-link suspension, PASM coilover, rear-axle steering actuator & upright."""
    inb = -side
    y_sub_in = y_hub_abs - 0.385  # Meets rear aluminum subframe around |Y| ≈ 0.385 m

    # 1) Cast aluminum rear multi-link upright / wheel carrier
    kn_parts: list[bpy.types.Object] = []
    kn_sec = []
    for dy_in, zz, dx_w, dy_t in [
        (0.115, -0.142, 0.036, 0.020),
        (0.118, -0.070, 0.054, 0.025),
        (0.124,  0.000, 0.072, 0.028),
        (0.130,  0.088, 0.052, 0.025),
        (0.140,  0.150, 0.036, 0.022),
    ]:
        kn_sec.append([
            (-dx_w, inb * (dy_in - dy_t), zz),
            ( dx_w, inb * (dy_in - dy_t), zz),
            ( dx_w, inb * (dy_in + dy_t), zz),
            (-dx_w, inb * (dy_in + dy_t), zz),
        ])
    kn_parts.append(loft_sections(f"_tmp_rkn_body_{corner}", kn_sec, mats["cast_alu"], parent=None, cap_ends=True, smooth=True))
    kn_parts.append(revolve_profile(
        f"_tmp_rkn_hub_{corner}",
        [(0.034, -0.080), (0.068, -0.080), (0.072, -0.115), (0.058, -0.145), (0.034, -0.145)],
        mats["gunmetal"],
        parent=None,
        axis="y",
        side_sign=side,
        steps=28,
        closed_profile=True,
        smooth=True,
    ))
    # Forward caliper ears (+X) meeting the leading 4-piston rear caliper
    for z_ear in (-0.088, 0.088):
        kn_parts.append(tube_along_points(
            f"_tmp_rkn_ear_{corner}_{z_ear:.2f}",
            [(0.025, inb * 0.130, z_ear * 0.55), (0.105, inb * 0.132, z_ear), (0.145, inb * 0.128, z_ear * 1.02)],
            0.013,
            mats["cast_alu"],
            parent=None,
            sides=10,
            subdiv=2,
        ))
    join_objects(f"TSC_Rear_Knuckle_{corner}", kn_parts, parent=parent)

    # 2) Lightweight 5-Link Rear Control Arms + Rear-Axle Steering Actuator Pod!
    arm_parts: list[bpy.types.Object] = []
    # Link 1: Main forged lower camber wishbone (wide track arm)
    arm_parts.append(tube_along_points(
        f"_tmp_rl1_{corner}",
        [(-0.020, inb * 0.120, -0.136), (-0.025, inb * 0.265, -0.140), (-0.030, inb * y_sub_in, -0.130)],
        [0.020, 0.025, 0.022],
        mats["machined_alu"],
        parent=None,
        sides=12,
        subdiv=3,
    ))
    # Link 2: Lower front diagonal/thrust link
    arm_parts.append(tube_along_points(
        f"_tmp_rl2_{corner}",
        [(0.055, inb * 0.135, -0.128), (0.155, inb * 0.270, -0.125), (0.275, inb * (y_sub_in - 0.01), -0.118)],
        0.015,
        mats["cast_alu"],
        parent=None,
        sides=10,
        subdiv=3,
    ))
    # Link 3: Upper front camber link
    arm_parts.append(tube_along_points(
        f"_tmp_rl3_{corner}",
        [(0.045, inb * 0.142, 0.142), (0.120, inb * 0.275, 0.152), (0.185, inb * y_sub_in, 0.148)],
        0.014,
        mats["machined_alu"],
        parent=None,
        sides=10,
        subdiv=3,
    ))
    # Link 4: Upper rear control link
    arm_parts.append(tube_along_points(
        f"_tmp_rl4_{corner}",
        [(-0.045, inb * 0.145, 0.138), (-0.110, inb * 0.275, 0.145), (-0.175, inb * y_sub_in, 0.140)],
        0.014,
        mats["machined_alu"],
        parent=None,
        sides=10,
        subdiv=3,
    ))
    # Link 5: Rear-axle steering (RAS) toe link + electromechanical actuator housing!
    arm_parts.append(tube_along_points(
        f"_tmp_rl5_ras_{corner}",
        [(-0.095, inb * 0.130, -0.055), (-0.120, inb * 0.260, -0.058), (-0.135, inb * y_sub_in, -0.055)],
        0.012,
        mats["gunmetal"],
        parent=None,
        sides=10,
        subdiv=2,
    ))
    # RAS electromechanical motor cylinder mounted on toe link
    arm_parts.append(ellipse_case(
        f"_tmp_ras_motor_{corner}",
        [
            (inb * 0.230, -0.120, -0.058, 0.025, 0.025),
            (inb * 0.340, -0.128, -0.056, 0.025, 0.025),
        ],
        mats["engine_plastic"],
        parent=None,
        axis="y",
        steps=18,
    ))
    join_objects(f"TSC_Rear_ControlArm_{corner}", arm_parts, parent=parent)

    # 3) Rear PASM Coilover Spring-Damper Unit (world top Z ≈ 0.358 + 0.415 = 0.773 m, safely inside haunch!)
    p_bot = Vector((-0.022, inb * 0.195, -0.128))
    p_top = Vector((+0.025, inb * 0.268, 0.415))
    axis = (p_top - p_bot).normalized()
    u_ax = axis.cross(Vector((1.0, 0.0, 0.0))).normalized()
    v_ax = axis.cross(u_ax).normalized()

    co_parts: list[bpy.types.Object] = []
    def _rcoil_sleeve(sname: str, prof_tr: list[tuple[float, float]], mat: bpy.types.Material) -> bpy.types.Object:
        rings = []
        for t, rr in prof_tr:
            c = p_bot.lerp(p_top, t)
            rings.append([tuple(c + (u_ax * math.cos(q) + v_ax * math.sin(q)) * rr) for q in np.linspace(0, 2 * math.pi, 24, endpoint=False)])
        return loft_sections(sname, rings, mat, parent=None, cap_ends=True, smooth=True)

    co_parts.append(_rcoil_sleeve(f"_tmp_rdamper_{corner}", [(0.0, 0.022), (0.10, 0.028), (0.58, 0.028), (0.62, 0.020)], mats["machined_alu"]))
    co_parts.append(_rcoil_sleeve(f"_tmp_rrod_{corner}", [(0.56, 0.011), (0.94, 0.011)], mats["stainless"]))
    co_parts.append(_rcoil_sleeve(f"_tmp_rperch_lo_{corner}", [(0.26, 0.029), (0.29, 0.055), (0.32, 0.056), (0.34, 0.044)], mats["gunmetal"]))
    co_parts.append(_rcoil_sleeve(f"_tmp_rperch_hi_{corner}", [(0.83, 0.047), (0.86, 0.056), (0.91, 0.055), (0.95, 0.036)], mats["cast_alu"]))
    co_parts.append(_rcoil_sleeve(f"_tmp_rtopmount_{corner}", [(0.94, 0.066), (0.97, 0.070), (1.00, 0.066)], mats["machined_alu"]))
    co_parts.append(helical_coil(
        f"_tmp_rspring_{corner}",
        p_bot.lerp(p_top, 0.30),
        p_bot.lerp(p_top, 0.85),
        coil_radius=0.047,
        wire_radius=0.0076,
        turns=6.5,
        material=mats["spring_black"],
        parent=None,
        sides=10,
        steps_per_turn=18,
    ))
    join_objects(f"TSC_Rear_Coilover_{corner}", co_parts, parent=parent)


def _build_steering_swaybars_halfshafts(
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
    chassis_pivot: bpy.types.Object,
) -> None:
    """Build electromechanical steering rack, front/rear ehPDCC active sway bars, and 4 AWD CV half-shafts."""
    x_f = cfg["x_front_axle"]
    x_r = cfg["x_rear_axle"]
    y_f = 0.5 * cfg["track_front"]
    y_r = 0.5 * cfg["track_rear"]
    z_f = cfg["z_hub_f"]
    z_r = cfg["z_hub_r"]

    # 1) Front Electromechanical Power Steering Rack (mounted ahead of front diff at X = x_f + 0.145, Z = 0.255)
    sr_parts: list[bpy.types.Object] = []
    x_rack = x_f + 0.148
    z_rack = z_f - 0.076  # ~0.262 m
    sr_parts.append(ellipse_case(
        "_tmp_sr_tube",
        [
            (-0.34, x_rack, z_rack, 0.025, 0.025),
            (-0.18, x_rack, z_rack, 0.027, 0.027),
            ( 0.18, x_rack, z_rack, 0.027, 0.027),
            ( 0.34, x_rack, z_rack, 0.025, 0.025),
        ],
        mats["cast_alu"],
        parent=None,
        axis="y",
        steps=24,
    ))
    # Parallel belt-driven electric power steering assist motor housing (visible in Rolling chassis view 1!)
    sr_parts.append(ellipse_case(
        "_tmp_sr_motor",
        [
            (-0.24, x_rack + 0.055, z_rack - 0.008, 0.036, 0.036),
            (-0.22, x_rack + 0.055, z_rack - 0.008, 0.042, 0.042),
            (-0.04, x_rack + 0.055, z_rack - 0.008, 0.042, 0.042),
            (-0.02, x_rack + 0.055, z_rack - 0.008, 0.034, 0.034),
        ],
        mats["machined_alu"],
        parent=None,
        axis="y",
        steps=24,
    ))
    # Pinion housing on driver (+Y) side + steering column stub
    sr_parts.append(tube_along_points(
        "_tmp_sr_pinion",
        [(x_rack, 0.28, z_rack), (x_rack - 0.06, 0.30, z_rack + 0.08), (x_rack - 0.16, 0.33, z_rack + 0.19)],
        [0.028, 0.020, 0.014],
        mats["cast_alu"],
        parent=None,
        sides=14,
        subdiv=2,
    ))
    # Corrugated rack boots + tie rods reaching front knuckle steering arms
    for side in (-1.0, 1.0):
        # Rubber bellows boot
        boot_st = []
        for k in range(6):
            yy = side * (0.335 + 0.018 * k)
            boot_st.append((yy, x_rack, z_rack, 0.028, 0.028))
            boot_st.append((yy + side * 0.009, x_rack, z_rack, 0.019, 0.019))
        sr_parts.append(ellipse_case(f"_tmp_sr_boot_{int(side)}", boot_st, mats["rubber_hose"], parent=None, axis="y", steps=18))
        sr_parts.append(tube_along_points(
            f"_tmp_sr_tierod_{int(side)}",
            [(x_rack, side * 0.435, z_rack), (x_rack, side * (y_f - 0.132), z_rack + 0.004)],
            0.0085,
            mats["gunmetal"],
            parent=None,
            sides=10,
            subdiv=1,
        ))
    join_objects("TSC_Steering_Rack", sr_parts, parent=chassis_pivot)

    # 2) Front & Rear ehPDCC Active Anti-Roll Bars (with electro-hydraulic rotary actuators)
    # Front ehPDCC bar
    fsb_parts: list[bpy.types.Object] = []
    fsb_parts.append(tube_along_points(
        "_tmp_fsb_bar",
        [
            (x_f + 0.05, +(y_f - 0.16), 0.235),
            (x_f + 0.22, +(y_f - 0.24), 0.235),
            (x_f + 0.25, +0.34, 0.248),
            (x_f + 0.25, -0.34, 0.248),
            (x_f + 0.22, -(y_f - 0.24), 0.235),
            (x_f + 0.05, -(y_f - 0.16), 0.235),
        ],
        0.0135,
        mats["spring_black"],
        parent=None,
        sides=12,
        subdiv=3,
    ))
    # Central ehPDCC rotary actuator canister
    fsb_parts.append(ellipse_case(
        "_tmp_fsb_ehpdcc",
        [(-0.085, x_f + 0.25, 0.248, 0.032, 0.032), (0.085, x_f + 0.25, 0.248, 0.032, 0.032)],
        mats["gunmetal"],
        parent=None,
        axis="y",
        steps=20,
    ))
    for side in (-1.0, 1.0):
        fsb_parts.append(tube_along_points(
            f"_tmp_fsb_link_{int(side)}",
            [(x_f + 0.05, side * (y_f - 0.16), 0.235), (x_f - 0.01, side * (y_f - 0.145), z_f + 0.135)],
            0.006,
            mats["stainless"],
            parent=None,
            sides=8,
            subdiv=1,
        ))
    join_objects("TSC_SwayBar_Front", fsb_parts, parent=chassis_pivot)

    # Rear ehPDCC bar
    rsb_parts: list[bpy.types.Object] = []
    rsb_parts.append(tube_along_points(
        "_tmp_rsb_bar",
        [
            (x_r - 0.04, +(y_r - 0.18), 0.255),
            (x_r - 0.20, +(y_r - 0.26), 0.258),
            (x_r - 0.24, +0.34, 0.268),
            (x_r - 0.24, -0.34, 0.268),
            (x_r - 0.20, -(y_r - 0.26), 0.258),
            (x_r - 0.04, -(y_r - 0.18), 0.255),
        ],
        0.013,
        mats["spring_black"],
        parent=None,
        sides=12,
        subdiv=3,
    ))
    rsb_parts.append(ellipse_case(
        "_tmp_rsb_ehpdcc",
        [(-0.080, x_r - 0.24, 0.268, 0.030, 0.030), (0.080, x_r - 0.24, 0.268, 0.030, 0.030)],
        mats["gunmetal"],
        parent=None,
        axis="y",
        steps=20,
    ))
    for side in (-1.0, 1.0):
        rsb_parts.append(tube_along_points(
            f"_tmp_rsb_link_{int(side)}",
            [(x_r - 0.04, side * (y_r - 0.18), 0.255), (x_r - 0.02, side * (y_r - 0.185), z_r - 0.125)],
            0.006,
            mats["stainless"],
            parent=None,
            sides=8,
            subdiv=1,
        ))
        # Forged clevis eyelet bushing at bar end so exploded view shows clean finished hardware
        rsb_parts.append(ellipse_case(
            f"_tmp_rsb_eye_{int(side)}",
            [(side * (y_r - 0.195), x_r - 0.04, 0.255, 0.015, 0.015), (side * (y_r - 0.165), x_r - 0.04, 0.255, 0.015, 0.015)],
            mats["gunmetal"],
            parent=None,
            axis="y",
            steps=14,
        ))
    join_objects("TSC_SwayBar_Rear", rsb_parts, parent=chassis_pivot)

    # 3) All 4 AWD CV Half-Shafts (Front PTM diff -> Front hubs; Rear PDK -> Rear hubs)
    for label, x_ax, y_hub, z_hub, y_in_flange, z_diff, shaft_r in [
        ("Front", x_f, y_f, z_f, 0.145, 0.295, 0.0155),
        ("Rear",  x_r, y_r, z_r, 0.175, 0.340, 0.0190),
    ]:
        for side, s_tag in [(+1.0, "L"), (-1.0, "R")]:
            hs_parts: list[bpy.types.Object] = []
            y_out = y_hub - 0.105
            p_in = Vector((x_ax, side * y_in_flange, z_diff))
            p_out = Vector((x_ax, side * y_out, z_hub))
            # Shaft bar
            hs_parts.append(tube_along_points(
                f"_tmp_hs_bar_{label}_{s_tag}",
                [p_in, p_out],
                shaft_r,
                mats["gunmetal"],
                parent=None,
                sides=14,
                subdiv=1,
            ))
            # Cast inboard CV cup flange
            hs_parts.append(ellipse_case(
                f"_tmp_hs_flange_{label}_{s_tag}",
                [
                    (side * (y_in_flange - 0.015), x_ax, z_diff, 0.052, 0.052),
                    (side * (y_in_flange + 0.025), x_ax, z_diff, 0.050, 0.050),
                    (side * (y_in_flange + 0.045), x_ax, z_diff, 0.036, 0.036),
                ],
                mats["cast_alu"],
                parent=None,
                axis="y",
                steps=20,
            ))
            # Convoluted rubber CV boots at inboard and outboard ends
            for t0, t1, r_big, r_sm in [(0.08, 0.24, 0.044, 0.024), (0.76, 0.94, 0.024, 0.042)]:
                pts_boot = []
                n_ribs = 5
                for k in range(2 * n_ribs + 1):
                    f = k / (2 * n_ribs)
                    tt = t0 + f * (t1 - t0)
                    p = p_in.lerp(p_out, tt)
                    rr_base = r_big + f * (r_sm - r_big)
                    rr = rr_base + (0.006 if k % 2 == 0 else -0.005)
                    pts_boot.append((p.y, p.x, p.z, rr, rr))
                hs_parts.append(ellipse_case(f"_tmp_hs_boot_{label}_{s_tag}_{t0:.2f}", pts_boot, mats["rubber_hose"], parent=None, axis="y", steps=18))

            join_objects(f"TSC_AWD_HalfShaft_{label}_{s_tag}", hs_parts, parent=chassis_pivot)


def build_suspension_and_calipers(
    pivots: dict[str, bpy.types.Object],
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
) -> None:
    """Populate `Pivot_Corner_*` with yellow PCCB calipers + suspension, and `Pivot_Drivetrain_Chassis` with steering/swaybars/halfshafts."""
    y_f = 0.5 * cfg["track_front"] - 0.005
    y_r = 0.5 * cfg["track_rear"] - 0.012

    corners = [
        ("FL", +1.0, False, y_f),
        ("FR", -1.0, False, y_f),
        ("RL", +1.0, True,  y_r),
        ("RR", -1.0, True,  y_r),
    ]
    for corner, side, is_rear, y_hub_abs in corners:
        p_corner = pivots[f"Pivot_Corner_{corner}"]
        z_hub = cfg["z_hub_r"] if is_rear else cfg["z_hub_f"]
        w_tire = (min(cfg["w_tire_r"], 0.304) if is_rear else cfg["w_tire_f"])
        dish_depth = 0.058 if is_rear else 0.036
        outboard_face = 0.5 * w_tire - 0.011
        hub_face_y = outboard_face - dish_depth
        friction_y = hub_face_y - 0.025
        rotor_r = 0.5 * (cfg["rotor_dia_r"] if is_rear else cfg["rotor_dia_f"])
        rotor_t = cfg["rotor_thick_r"] if is_rear else cfg["rotor_thick_f"]

        _build_pccb_caliper(corner, side, is_rear, rotor_r, rotor_t, friction_y, mats, p_corner)
        if is_rear:
            _build_rear_corner_suspension(corner, side, z_hub, y_hub_abs, mats, p_corner)
        else:
            _build_front_corner_suspension(corner, side, z_hub, y_hub_abs, mats, p_corner)

    _build_steering_swaybars_halfshafts(cfg, mats, pivots["Pivot_Drivetrain_Chassis"])
