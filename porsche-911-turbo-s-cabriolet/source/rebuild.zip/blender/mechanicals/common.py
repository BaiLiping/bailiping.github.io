"""Shared Blender geometry builders and PBR materials for the 992.2 911 Turbo S Cabriolet mechanicals.

Coordinate convention (Blender master):
- Real-world meters (1 BU = 1.0 m)
- +X = Forward, +Y = Left (driver, LHD), +Z = Up
- Origin (0, 0, 0) = Ground plane (Z=0), centerline (Y=0), wheelbase midpoint (X=0)
"""

from __future__ import annotations

import math
from typing import Iterable, Sequence

import bpy
import bmesh
import numpy as np
from mathutils import Euler, Matrix, Vector


# ---------------------------------------------------------------------------
# Color & Material Helpers
# ---------------------------------------------------------------------------

def srgb_to_linear(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def hex_to_rgba(hex_str: str, alpha: float = 1.0) -> tuple[float, float, float, float]:
    h = hex_str.lstrip("#")
    r = srgb_to_linear(int(h[0:2], 16) / 255.0)
    g = srgb_to_linear(int(h[2:4], 16) / 255.0)
    b = srgb_to_linear(int(h[4:6], 16) / 255.0)
    return (r, g, b, alpha)


def get_or_create_material(
    name: str,
    hex_color: str,
    metallic: float = 0.0,
    roughness: float = 0.5,
    coat_weight: float = 0.0,
    coat_roughness: float = 0.08,
    alpha: float = 1.0,
) -> bpy.types.Material:
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes.get("Principled BSDF")
    if bsdf is None:
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Base Color"].default_value = hex_to_rgba(hex_color, 1.0)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = roughness
    if "Coat Weight" in bsdf.inputs and coat_weight > 0.0:
        bsdf.inputs["Coat Weight"].default_value = coat_weight
        bsdf.inputs["Coat Roughness"].default_value = coat_roughness
    if alpha < 1.0:
        bsdf.inputs["Alpha"].default_value = alpha
    return mat


def _build_pccb_ceramic_material() -> bpy.types.Material:
    """Create Mat_PCCB_Ceramic_Rotor with a high-res 1024x1024 fine carbon-ceramic fiber weave texture."""
    name = "Mat_PCCB_Ceramic_Rotor"
    existing = bpy.data.materials.get(name)
    if existing is not None:
        return existing
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes.get("Principled BSDF")

    size = 512
    rng = np.random.default_rng(9922)
    yy, xx = np.mgrid[0:size, 0:size]
    u = (xx / size) * 2.0 - 1.0
    v = (yy / size) * 2.0 - 1.0
    r = np.hypot(u, v)

    # Crisp 512x512 multi-octave crystalline carbon-ceramic weave (razor-sharp at 4K while keeping GLB lean!)
    c1 = rng.normal(0.0, 1.0, (64, 64)).astype(np.float32)
    c1 = np.repeat(np.repeat(c1, 8, axis=0), 8, axis=1)
    for _ in range(3):
        c1 = 0.25 * (np.roll(c1, 1, 0) + np.roll(c1, -1, 0) + np.roll(c1, 1, 1) + np.roll(c1, -1, 1))
    c2 = rng.normal(0.0, 1.0, (128, 128)).astype(np.float32)
    c2 = np.repeat(np.repeat(c2, 4, axis=0), 4, axis=1)
    c2 = 0.25 * (np.roll(c2, 1, 0) + np.roll(c2, -1, 0) + np.roll(c2, 1, 1) + np.roll(c2, -1, 1))
    c3 = rng.normal(0.0, 1.0, (256, 256)).astype(np.float32)
    c3 = np.repeat(np.repeat(c3, 2, axis=0), 2, axis=1)
    fine = rng.normal(0.0, 0.55, (size, size)).astype(np.float32)
    rings = (0.025 * np.sin(r * 240.0) + 0.015 * np.sin(r * 520.0)).astype(np.float32)

    flake = np.clip(0.41 + 0.055 * c1 + 0.065 * c2 + 0.055 * c3 + 0.045 * fine + rings, 0.18, 0.64)
    img_arr = np.empty((size, size, 4), dtype=np.float32)
    img_arr[:, :, 0] = np.clip(flake * 0.62, 0.11, 0.54)
    img_arr[:, :, 1] = np.clip(flake * 0.63, 0.11, 0.55)
    img_arr[:, :, 2] = np.clip(flake * 0.65, 0.12, 0.57)
    img_arr[:, :, 3] = 1.0

    img = bpy.data.images.get("Tex_PCCB_Ceramic")
    if img is None:
        img = bpy.data.images.new("Tex_PCCB_Ceramic", width=size, height=size, alpha=False)
    img.colorspace_settings.name = "sRGB"
    img.pixels.foreach_set(img_arr.ravel())
    img.pack()

    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Metallic"].default_value = 0.24
    bsdf.inputs["Roughness"].default_value = 0.50
    return mat


def create_material_library() -> dict[str, bpy.types.Material]:
    """Create standardized PBR materials matching web/rig_contract.md & sampled 4K photo (50).jpeg."""
    mats = {
        # Standardized viewer hook materials (EXACT names per web/rig_contract.md)
        # Turbonite calibrated across Stage A5 split (view-04): deep satin charcoal-bronze titanium (#45423e)
        "turbonite": get_or_create_material("Mat_Turbonite_Alloy", "45423e", metallic=0.88, roughness=0.28, coat_weight=0.08),
        "turbonite_dark": get_or_create_material("Mat_Turbonite_Dark", "252422", metallic=0.78, roughness=0.34),
        "turbonite_crest": get_or_create_material("Mat_Turbonite_Crest", "88857e", metallic=0.88, roughness=0.23),
        "centerlock_black": get_or_create_material("Mat_CenterLock_Black", "121316", metallic=0.58, roughness=0.34),
        # Speed Yellow sampled from (50).jpeg (#e2b403): verified dead-on across Stage A5 view-04 split!
        "caliper_yellow": get_or_create_material("Mat_PCCB_Caliper_Yellow", "f5be00", metallic=0.02, roughness=0.24, coat_weight=0.20, coat_roughness=0.10),
        "caliper_text": get_or_create_material("Mat_PCCB_Caliper_Text", "0e0f11", metallic=0.04, roughness=0.40),
        "pccb_rotor": _build_pccb_ceramic_material(),
        "pccb_hole": get_or_create_material("Mat_PCCB_Hole_Dark", "0a0b0d", metallic=0.15, roughness=0.80),
        "rotor_hat": get_or_create_material("Mat_Rotor_Hat_Black", "131518", metallic=0.74, roughness=0.32),
        # Deep satin Pirelli P Zero R tire rubber calibrated across Stage A5 view-04 split
        "tire_rubber": get_or_create_material("Mat_Tire_Rubber", "101113", metallic=0.02, roughness=0.72),
        "tire_tread": get_or_create_material("Mat_Tire_Tread", "0c0d0f", metallic=0.02, roughness=0.84),
        "tire_text": get_or_create_material("Mat_Tire_Sidewall_Text", "24262a", metallic=0.03, roughness=0.60),
        # Metals & powertrain
        "stainless": get_or_create_material("Mat_Bobbin_Stainless", "cfd3d7", metallic=0.92, roughness=0.20),
        "cast_alu": get_or_create_material("Mat_Cast_Aluminum", "a6acb2", metallic=0.82, roughness=0.36),
        "machined_alu": get_or_create_material("Mat_Machined_Aluminum", "c6cbd0", metallic=0.90, roughness=0.23),
        "gunmetal": get_or_create_material("Mat_Dark_Gunmetal", "3c4148", metallic=0.80, roughness=0.34),
        "gear_steel": get_or_create_material("Mat_Gear_Steel", "8d939c", metallic=0.92, roughness=0.20),
        "copper": get_or_create_material("Mat_Copper_Winding", "c95b1e", metallic=0.92, roughness=0.24),
        "eturbo_green": get_or_create_material("Mat_eTurbo_Green", "177c46", metallic=0.35, roughness=0.34),
        "hv_orange": get_or_create_material("Mat_HV_Orange", "f55c08", metallic=0.04, roughness=0.38, coat_weight=0.15),
        # Polymers, exhaust & chassis
        "engine_plastic": get_or_create_material("Mat_Engine_Composite", "1e2024", metallic=0.06, roughness=0.56),
        "rubber_hose": get_or_create_material("Mat_Silicone_Hose", "181a1d", metallic=0.02, roughness=0.68),
        "titanium": get_or_create_material("Mat_Titanium_Exhaust", "b6b0a6", metallic=0.86, roughness=0.32),
        "inconel": get_or_create_material("Mat_Exhaust_Inconel", "9e8e79", metallic=0.84, roughness=0.36),
        "tip_dark": get_or_create_material("Mat_Exhaust_Tip_Dark", "222428", metallic=0.80, roughness=0.28),
        "chassis_tub": get_or_create_material("Mat_Chassis_Tub", "252a32", metallic=0.62, roughness=0.40),
        "chassis_sill": get_or_create_material("Mat_Chassis_Sill", "5d636c", metallic=0.84, roughness=0.30),
        "undertray": get_or_create_material("Mat_Undertray_Composite", "191b1f", metallic=0.05, roughness=0.68),
        "spring_black": get_or_create_material("Mat_Spring_Black", "1a1d22", metallic=0.20, roughness=0.28, coat_weight=0.25),
        "rad_core": get_or_create_material("Mat_Radiator_Core", "363a40", metallic=0.72, roughness=0.44),
        "valve_cap": get_or_create_material("Mat_Valve_Black", "15171a", metallic=0.55, roughness=0.34),
    }
    return mats


# ---------------------------------------------------------------------------
# Scene / Object Helpers
# ---------------------------------------------------------------------------

def get_collection() -> bpy.types.Collection:
    return bpy.context.scene.collection


def make_empty(
    name: str,
    location: Sequence[float] = (0.0, 0.0, 0.0),
    parent: bpy.types.Object | None = None,
) -> bpy.types.Object:
    obj = bpy.data.objects.new(name, None)
    obj.empty_display_type = "PLAIN_AXES"
    obj.empty_display_size = 0.12
    obj.location = Vector(location)
    get_collection().objects.link(obj)
    if parent is not None:
        obj.parent = parent
    return obj


def set_smooth_polygons(mesh_data: bpy.types.Mesh, smooth: bool = True) -> None:
    if len(mesh_data.polygons) > 0:
        mesh_data.polygons.foreach_set("use_smooth", [smooth] * len(mesh_data.polygons))


def _split_sharp_edges(bm: bmesh.types.BMesh, angle_deg: float = 34.0) -> None:
    """Split edges sharper than angle_deg so smooth shading never blurs across hard CAD flanges/ribs in glTF."""
    bm.normal_update()
    rad = math.radians(angle_deg)
    sharp = [e for e in bm.edges if len(e.link_faces) == 2 and e.calc_face_angle(0.0) > rad]
    if sharp:
        bmesh.ops.split_edges(bm, edges=sharp)


def finalize_mesh(
    name: str,
    verts: Sequence[Sequence[float]],
    faces: Sequence[Sequence[int]],
    material: bpy.types.Material | Sequence[bpy.types.Material],
    parent: bpy.types.Object | None = None,
    smooth: bool = True,
    recalc_normals: bool = True,
    mat_indices: Sequence[int] | None = None,
    pdk_internal: bool = False,
    sharp_angle: float = 34.0,
) -> bpy.types.Object:
    """Create a clean mesh object with outward normals and crisp auto-smooth edge splits for glTF."""
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)

    if isinstance(material, (list, tuple)):
        for m in material:
            me.materials.append(m)
    else:
        me.materials.append(material)

    if mat_indices is not None and len(mat_indices) == len(me.polygons):
        me.polygons.foreach_set("material_index", np.asarray(mat_indices, dtype=np.int32))

    if (recalc_normals or (smooth and sharp_angle > 0.0)) and len(me.polygons) > 0:
        bm = bmesh.new()
        bm.from_mesh(me)
        if recalc_normals:
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        if smooth and sharp_angle > 0.0:
            _split_sharp_edges(bm, sharp_angle)
        bm.to_mesh(me)
        bm.free()

    set_smooth_polygons(me, smooth)
    me.update()

    obj = bpy.data.objects.new(name, me)
    get_collection().objects.link(obj)
    if parent is not None:
        obj.parent = parent
    if pdk_internal:
        obj["pdkInternal"] = True
    return obj


def add_planar_uv(obj: bpy.types.Object, scale: float = 1.0, axis: str = "y") -> None:
    """Attach clean planar UVs (used for rotor ceramic texture)."""
    me = obj.data
    uv_layer = me.uv_layers.new(name="UVMap")
    for poly in me.polygons:
        for li in poly.loop_indices:
            co = me.vertices[me.loops[li].vertex_index].co
            if axis == "y":
                uv_layer.data[li].uv = (co.x / scale + 0.5, co.z / scale + 0.5)
            elif axis == "x":
                uv_layer.data[li].uv = (co.y / scale + 0.5, co.z / scale + 0.5)
            else:
                uv_layer.data[li].uv = (co.x / scale + 0.5, co.y / scale + 0.5)


def add_box_uv(obj: bpy.types.Object, scale: float = 0.25) -> None:
    me = obj.data
    uv_layer = me.uv_layers.new(name="UVMap")
    for poly in me.polygons:
        n = poly.normal
        ax = max(range(3), key=lambda i: abs(n[i]))
        p0, p1 = [(1, 2), (0, 2), (0, 1)][ax]
        for li in poly.loop_indices:
            co = me.vertices[me.loops[li].vertex_index].co
            uv_layer.data[li].uv = (co[p0] / scale, co[p1] / scale)


# ---------------------------------------------------------------------------
# Procedural Mesh Primitives
# ---------------------------------------------------------------------------

def loft_sections(
    name: str,
    sections: Sequence[Sequence[Sequence[float]]],
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    cap_ends: bool = True,
    closed_u: bool = False,
    smooth: bool = True,
    pdk_internal: bool = False,
) -> bpy.types.Object:
    """Loft a sequence of equal-length 3D rings into a closed manifold mesh."""
    n_sec = len(sections)
    n_pts = len(sections[0])
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, ...]] = []
    for ring in sections:
        verts.extend((float(p[0]), float(p[1]), float(p[2])) for p in ring)

    sec_range = range(n_sec) if closed_u else range(n_sec - 1)
    for i in sec_range:
        i2 = (i + 1) % n_sec
        base0 = i * n_pts
        base1 = i2 * n_pts
        for j in range(n_pts):
            j2 = (j + 1) % n_pts
            faces.append((base0 + j, base0 + j2, base1 + j2, base1 + j))

    if cap_ends and not closed_u:
        # Cap start & end using center vertex fan for clean triangulation
        c0 = np.mean(np.asarray(sections[0]), axis=0)
        idx0 = len(verts)
        verts.append((float(c0[0]), float(c0[1]), float(c0[2])))
        for j in range(n_pts):
            j2 = (j + 1) % n_pts
            faces.append((idx0, j2, j))

        c1 = np.mean(np.asarray(sections[-1]), axis=0)
        idx1 = len(verts)
        verts.append((float(c1[0]), float(c1[1]), float(c1[2])))
        base_last = (n_sec - 1) * n_pts
        for j in range(n_pts):
            j2 = (j + 1) % n_pts
            faces.append((idx1, base_last + j, base_last + j2))

    return finalize_mesh(name, verts, faces, material, parent, smooth=smooth, pdk_internal=pdk_internal)


def revolve_profile(
    name: str,
    profile_rz: Sequence[tuple[float, float]],
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    axis: str = "y",
    center: Sequence[float] = (0.0, 0.0, 0.0),
    side_sign: float = 1.0,
    steps: int = 96,
    closed_profile: bool = True,
    smooth: bool = True,
    pdk_internal: bool = False,
) -> bpy.types.Object:
    """Revolve a 2D (radius, axial_coord) profile around X, Y, or Z axis."""
    cx, cy, cz = center
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int, int]] = []
    m = len(profile_rz)
    angles = [2.0 * math.pi * k / steps for k in range(steps)]
    cos_a = [math.cos(a) for a in angles]
    sin_a = [math.sin(a) for a in angles]

    for r, ax in profile_rz:
        ax_s = side_sign * ax
        for k in range(steps):
            u = r * cos_a[k]
            v = r * sin_a[k]
            if axis == "y":
                verts.append((cx + u, cy + ax_s, cz + v))
            elif axis == "x":
                verts.append((cx + ax_s, cy + u, cz + v))
            else:
                verts.append((cx + u, cy + v, cz + ax_s))

    j_count = m if closed_profile else m - 1
    for j in range(j_count):
        j2 = (j + 1) % m
        b0 = j * steps
        b1 = j2 * steps
        for k in range(steps):
            k2 = (k + 1) % steps
            faces.append((b0 + k, b0 + k2, b1 + k2, b1 + k))

    return finalize_mesh(name, verts, faces, material, parent, smooth=smooth, pdk_internal=pdk_internal)


def ellipse_case(
    name: str,
    stations: Sequence[tuple[float, float, float, float, float]],
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    axis: str = "x",
    steps: int = 36,
    cap_ends: bool = True,
    smooth: bool = True,
    pdk_internal: bool = False,
) -> bpy.types.Object:
    """Loft elliptical stations: (axial, c1, c2, r1, r2) along 'x', 'y', or 'z'."""
    sections = []
    for axial, c1, c2, r1, r2 in stations:
        ring = []
        for j in range(steps):
            t = 2.0 * math.pi * j / steps
            u = c1 + r1 * math.cos(t)
            v = c2 + r2 * math.sin(t)
            if axis == "x":
                ring.append((axial, u, v))
            elif axis == "y":
                ring.append((u, axial, v))
            else:
                ring.append((u, v, axial))
        sections.append(ring)
    return loft_sections(name, sections, material, parent, cap_ends=cap_ends, smooth=smooth, pdk_internal=pdk_internal)


def sculpted_box_loft(
    name: str,
    stations: Sequence[tuple[float, float, float, float, float]],
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    axis: str = "x",
    smooth: bool = True,
    pdk_internal: bool = False,
) -> bpy.types.Object:
    """Loft rounded-rectangle cross-sections along an axis."""
    prof = [
        (-0.76, -1.0), (0.76, -1.0), (0.97, -0.72), (1.0, -0.15),
        (1.0, 0.15), (0.95, 0.72), (0.72, 0.98), (0.0, 1.0),
        (-0.72, 0.98), (-0.95, 0.72), (-1.0, 0.15), (-1.0, -0.15), (-0.97, -0.72),
    ]
    sections = []
    for axial, c1, c2, h1, h2 in stations:
        ring = []
        for u, v in prof:
            p1 = c1 + h1 * u
            p2 = c2 + h2 * v
            if axis == "x":
                ring.append((axial, p1, p2))
            elif axis == "y":
                ring.append((p1, axial, p2))
            else:
                ring.append((p1, p2, axial))
        sections.append(ring)
    return loft_sections(name, sections, material, parent, cap_ends=True, smooth=smooth, pdk_internal=pdk_internal)


def round_box(
    name: str,
    center: Sequence[float],
    size: Sequence[float],
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    bevel: float = 0.008,
    rot_euler: Sequence[float] = (0.0, 0.0, 0.0),
    segments: int = 2,
    pdk_internal: bool = False,
) -> bpy.types.Object:
    """Create a beveled solid box directly with bmesh (no ops)."""
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    sx, sy, sz = size
    bmesh.ops.scale(bm, vec=(sx, sy, sz), verts=bm.verts)
    b = min(bevel, 0.42 * min(sx, sy, sz))
    if b > 1e-5:
        bmesh.ops.bevel(
            bm,
            geom=list(bm.edges),
            offset=b,
            segments=segments,
            affect="EDGES",
            clamp_overlap=True,
        )
    rot_m = Euler(rot_euler, "XYZ").to_matrix().to_4x4()
    trans_m = Matrix.Translation(Vector(center))
    bmesh.ops.transform(bm, matrix=trans_m @ rot_m, verts=bm.verts)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    _split_sharp_edges(bm, 36.0)

    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    me.materials.append(material)
    set_smooth_polygons(me, True)
    me.update()

    obj = bpy.data.objects.new(name, me)
    get_collection().objects.link(obj)
    if parent is not None:
        obj.parent = parent
    if pdk_internal:
        obj["pdkInternal"] = True
    return obj


def _catmull_rom(points: Sequence[Vector], samples_per_seg: int = 6) -> list[Vector]:
    pts = [Vector(p) for p in points]
    if len(pts) <= 2:
        return pts
    out: list[Vector] = []
    n = len(pts)
    for i in range(n - 1):
        p0 = pts[max(0, i - 1)]
        p1 = pts[i]
        p2 = pts[i + 1]
        p3 = pts[min(n - 1, i + 2)]
        steps = samples_per_seg if i < n - 2 else samples_per_seg + 1
        for k in range(steps):
            t = k / samples_per_seg
            t2 = t * t
            t3 = t2 * t
            pt = 0.5 * (
                (2.0 * p1)
                + (-p0 + p2) * t
                + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2
                + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3
            )
            out.append(pt)
    return out


def tube_along_points(
    name: str,
    points: Sequence[Sequence[float]],
    radius: float | Sequence[float],
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    sides: int = 16,
    subdiv: int = 5,
    cap_ends: bool = True,
    smooth: bool = True,
    pdk_internal: bool = False,
) -> bpy.types.Object:
    """Build a smooth swept circular tube along 3D waypoints directly as a mesh."""
    pts = _catmull_rom(points, samples_per_seg=subdiv) if subdiv > 1 and len(points) >= 3 else [Vector(p) for p in points]
    n = len(pts)
    if isinstance(radius, (int, float)):
        radii = [float(radius)] * n
    else:
        # Interpolate radius array across resampled points
        r_in = np.asarray(radius, dtype=float)
        radii = list(np.interp(np.linspace(0, 1, n), np.linspace(0, 1, len(r_in)), r_in))

    sections: list[list[tuple[float, float, float]]] = []
    prev_n = None
    for i, pt in enumerate(pts):
        if i == 0:
            tang = (pts[1] - pts[0]).normalized()
        elif i == n - 1:
            tang = (pts[-1] - pts[-2]).normalized()
        else:
            tang = (pts[i + 1] - pts[i - 1]).normalized()
        if tang.length < 1e-8:
            tang = Vector((1.0, 0.0, 0.0))

        if prev_n is None:
            ref = Vector((0.0, 0.0, 1.0)) if abs(tang.z) < 0.9 else Vector((1.0, 0.0, 0.0))
            normal = tang.cross(ref).normalized()
        else:
            # Parallel transport to prevent twist flips
            normal = (prev_n - tang * prev_n.dot(tang))
            if normal.length < 1e-6:
                ref = Vector((0.0, 0.0, 1.0)) if abs(tang.z) < 0.9 else Vector((1.0, 0.0, 0.0))
                normal = tang.cross(ref).normalized()
            else:
                normal.normalize()
        binorm = tang.cross(normal).normalized()
        prev_n = normal

        r = radii[i]
        ring = []
        for k in range(sides):
            ang = 2.0 * math.pi * k / sides
            p = pt + (normal * math.cos(ang) + binorm * math.sin(ang)) * r
            ring.append((p.x, p.y, p.z))
        sections.append(ring)

    return loft_sections(name, sections, material, parent, cap_ends=cap_ends, smooth=smooth, pdk_internal=pdk_internal)


def bolt_array(
    name: str,
    centers: Sequence[Sequence[float]],
    radius: float,
    height: float,
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    axis: str = "x",
    sides: int = 6,
    pdk_internal: bool = False,
) -> bpy.types.Object:
    """Create a batched mesh of chamfered hex/torx bolts or washers."""
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, ...]] = []
    for cx, cy, cz in centers:
        start = len(verts)
        stations = [
            (0.0, radius * 0.92),
            (height * 0.16, radius),
            (height * 0.84, radius),
            (height, radius * 0.82),
        ]
        for off, r in stations:
            for k in range(sides):
                ang = 2.0 * math.pi * k / sides
                u = r * math.cos(ang)
                v = r * math.sin(ang)
                if axis == "x":
                    verts.append((cx + off, cy + u, cz + v))
                elif axis == "y":
                    verts.append((cx + u, cy + off, cz + v))
                else:
                    verts.append((cx + u, cy + v, cz + off))
        for j in range(3):
            b0 = start + j * sides
            b1 = start + (j + 1) * sides
            for k in range(sides):
                k2 = (k + 1) % sides
                faces.append((b0 + k, b0 + k2, b1 + k2, b1 + k))
        # Top cap
        c_idx = len(verts)
        if axis == "x":
            verts.append((cx + height, cy, cz))
        elif axis == "y":
            verts.append((cx, cy + height, cz))
        else:
            verts.append((cx, cy, cz + height))
        b_top = start + 3 * sides
        for k in range(sides):
            k2 = (k + 1) % sides
            faces.append((c_idx, b_top + k, b_top + k2))
    return finalize_mesh(name, verts, faces, material, parent, smooth=False, pdk_internal=pdk_internal)


def gear_wheel(
    name: str,
    center: Sequence[float],
    pitch_r: float,
    width: float,
    teeth: int,
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    axis: str = "x",
    helix_twist: float = 0.08,
    bore_r: float = 0.014,
    pdk_internal: bool = True,
) -> bpy.types.Object:
    """Generate a genuine toothed helical/spur gear mesh for the PDK gear train."""
    cx, cy, cz = center
    module = 2.0 * pitch_r / max(teeth, 8)
    r_root = max(bore_r + 0.004, pitch_r - 1.15 * module)
    r_tip = pitch_r + 0.90 * module
    pts_per_tooth = 4
    n_ring = teeth * pts_per_tooth
    # 3 axial stations to show crisp helical twist
    axial_stations = [(-0.5 * width, -helix_twist), (0.0, 0.0), (0.5 * width, helix_twist)]
    sections = []
    for ax_off, twist in axial_stations:
        ring = []
        for t in range(teeth):
            base_a = 2.0 * math.pi * t / teeth + twist
            da = 2.0 * math.pi / teeth
            for frac, rr in [(0.0, r_root), (0.20, r_root), (0.34, r_tip), (0.64, r_tip)]:
                ang = base_a + da * frac
                u = rr * math.cos(ang)
                v = rr * math.sin(ang)
                if axis == "x":
                    ring.append((cx + ax_off, cy + u, cz + v))
                elif axis == "y":
                    ring.append((cx + u, cy + ax_off, cz + v))
                else:
                    ring.append((cx + u, cy + v, cz + ax_off))
        sections.append(ring)
    return loft_sections(name, sections, material, parent, cap_ends=True, smooth=False, pdk_internal=pdk_internal)


def helical_coil(
    name: str,
    p_start: Sequence[float],
    p_end: Sequence[float],
    coil_radius: float,
    wire_radius: float,
    turns: float,
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    sides: int = 10,
    steps_per_turn: int = 20,
) -> bpy.types.Object:
    """Create a realistic coiled PASM suspension road spring between two endpoints."""
    p0 = Vector(p_start)
    p1 = Vector(p_end)
    axis = (p1 - p0).normalized()
    ref = Vector((1.0, 0.0, 0.0)) if abs(axis.x) < 0.85 else Vector((0.0, 1.0, 0.0))
    u_vec = axis.cross(ref).normalized()
    v_vec = axis.cross(u_vec).normalized()

    total_steps = max(24, int(turns * steps_per_turn))
    pts = []
    for i in range(total_steps + 1):
        t = i / total_steps
        ang = t * turns * 2.0 * math.pi
        # Slight barrel taper at ends for realistic progressive Porsche PASM spring
        r = coil_radius * (1.0 - 0.08 * (2.0 * t - 1.0) ** 4)
        pt = p0.lerp(p1, t) + (u_vec * math.cos(ang) + v_vec * math.sin(ang)) * r
        pts.append(pt)
    return tube_along_points(name, pts, wire_radius, material, parent, sides=sides, subdiv=1, cap_ends=True, smooth=True)


def text_to_mesh(
    name: str,
    body: str,
    size: float,
    material: bpy.types.Material,
    parent: bpy.types.Object | None = None,
    extrude: float = 0.0008,
    location: Sequence[float] = (0.0, 0.0, 0.0),
    rot_matrix: Matrix | None = None,
    spacing: float = 1.0,
) -> bpy.types.Object:
    """Create a 3D text object and convert it immediately to a clean MESH so GLB export preserves it."""
    cu = bpy.data.curves.new(name + "_curve", "FONT")
    cu.body = body
    cu.size = size
    cu.space_character = spacing
    cu.align_x = "CENTER"
    cu.align_y = "CENTER"
    cu.extrude = extrude
    cu.resolution_u = 4

    temp_obj = bpy.data.objects.new(name + "_tmp", cu)
    get_collection().objects.link(temp_obj)

    depsgraph = bpy.context.evaluated_depsgraph_get()
    eval_obj = temp_obj.evaluated_get(depsgraph)
    me = bpy.data.meshes.new_from_object(eval_obj)
    me.name = name

    bpy.data.objects.remove(temp_obj, do_unlink=True)
    bpy.data.curves.remove(cu, do_unlink=True)

    # Bake local transform into mesh vertices or keep clean local transform
    if rot_matrix is not None:
        xform = Matrix.Translation(Vector(location)) @ rot_matrix.to_4x4()
        me.transform(xform)
    elif any(abs(v) > 1e-9 for v in location):
        me.transform(Matrix.Translation(Vector(location)))

    me.materials.clear()
    me.materials.append(material)
    set_smooth_polygons(me, False)
    me.update()

    obj = bpy.data.objects.new(name, me)
    get_collection().objects.link(obj)
    if parent is not None:
        obj.parent = parent
    return obj


def join_objects(
    name: str,
    objs: Sequence[bpy.types.Object],
    parent: bpy.types.Object | None = None,
    pdk_internal: bool = False,
) -> bpy.types.Object:
    """Merge multiple sibling mesh objects into one clean mesh object without bpy.ops."""
    bm = bmesh.new()
    mat_list: list[bpy.types.Material] = []
    mat_map: dict[str, int] = {}

    for o in objs:
        if o.type != "MESH" or o.data is None:
            continue
        me = o.data
        local_mats = []
        for m in me.materials:
            if m is None:
                local_mats.append(0)
                continue
            if m.name not in mat_map:
                mat_map[m.name] = len(mat_list)
                mat_list.append(m)
            local_mats.append(mat_map[m.name])

        sub_bm = bmesh.new()
        sub_bm.from_mesh(me)
        if o.matrix_local != Matrix.Identity(4):
            bmesh.ops.transform(sub_bm, matrix=o.matrix_local, verts=sub_bm.verts)
        mapped_indices = [local_mats[min(f.material_index, len(local_mats) - 1)] if local_mats else 0 for f in sub_bm.faces]

        tmp = bpy.data.meshes.new("_merge_tmp")
        sub_bm.to_mesh(tmp)
        sub_bm.free()
        bm.faces.ensure_lookup_table()
        face_count_before = len(bm.faces)
        bm.from_mesh(tmp)
        bpy.data.meshes.remove(tmp, do_unlink=True)
        bm.faces.ensure_lookup_table()
        for k, m_idx in enumerate(mapped_indices):
            bm.faces[face_count_before + k].material_index = m_idx

        # Clean up source object
        bpy.data.objects.remove(o, do_unlink=True)
        bpy.data.meshes.remove(me, do_unlink=True)

    out_me = bpy.data.meshes.new(name)
    bm.to_mesh(out_me)
    bm.free()
    for m in mat_list:
        out_me.materials.append(m)
    out_me.update()

    out_obj = bpy.data.objects.new(name, out_me)
    get_collection().objects.link(out_obj)
    if parent is not None:
        out_obj.parent = parent
    if pdk_internal:
        out_obj["pdkInternal"] = True
    return out_obj
