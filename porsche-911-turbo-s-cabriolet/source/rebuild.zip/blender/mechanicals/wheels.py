"""992.2 Porsche 911 Turbo S Cabriolet — Forged Turbonite Center-Lock Wheels, Pirelli P Zero R Tires & PCCB Rotors.

Photo-matched directly to 4K studio photos `911 Turbo S Cabriolet (3).jpeg`, `(8).jpeg`, and `(50).jpeg`:
- Staggered factory specs (EU technical data MY T 10/2025):
  - Front: 9.5J x 20" ET44, Pirelli P Zero R (NA2) 255/35 ZR20, 420x40 mm cross-drilled PCCB ceramic disc
  - Rear : 12.0J x 21" ET63, Pirelli P Zero R (NA2) 325/30 ZR21, 410x32 mm cross-drilled PCCB ceramic disc
- Wheel design: exact 10-fold symmetry (10 sculpted forged Y-spokes = 20 rim landings, 10 parallel inter-Y
  slots with TPMS valve stem centered at 6 o'clock, recessed scalloped black center-lock nut with
  monochrome Turbonite Porsche crest).
- Rig hierarchy (web/rig_contract.md):
  - `Pivot_Corner_{FL,FR,RL,RR}` at axle center `(x_axle, side * half_track, z_hub)`
  - Child `Pivot_WheelSpin_{FL,FR,RL,RR}` at local `(0, 0, 0)` carrying:
    - `TSC_Tire_{corner}` (explodes +/-43 outward in Z)
    - `TSC_Rim_YSpoke_{corner}` (explodes +/-16 outward in Z)
    - `TSC_CenterLockHub_{corner}`, `TSC_CenterCrestCap_{corner}` (explodes +/-55 outward in Z)
    - `TSC_Rim_Barrel_{corner}`, `TSC_Rim_Valve_{corner}`
    - `TSC_PCCB_Rotor_{corner}`, `TSC_PCCB_Hat_{corner}` (rotates with wheel!)
"""

from __future__ import annotations

import math
from typing import Any

import bpy
import numpy as np
from mathutils import Matrix, Vector

from .common import (
    add_planar_uv,
    bolt_array,
    finalize_mesh,
    join_objects,
    loft_sections,
    make_empty,
    revolve_profile,
    text_to_mesh,
)


def _build_tire(
    corner: str,
    side: float,
    r_outer: float,
    r_rim_bead: float,
    width: float,
    is_rear: bool,
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> bpy.types.Object:
    """Build Pirelli P Zero R tire casing, circumferential grooves, shoulder sipes, and molded sidewall lettering."""
    a = 0.5 * width
    # Realistic 30/35-series Pirelli P Zero R rounded athletic shoulder taper (tucks cleanly inside 992.2 arches!)
    r_sh = r_outer * (0.954 if is_rear else 0.960)
    r_bulge = r_rim_bead + 0.38 * (r_outer - r_rim_bead)
    bulge_w = a + 0.0022
    rim_prot = a + 0.0035  # Realistic Pirelli rim protector lip

    # Tire cross-section profile (r, y_outboard_signed_unscaled)
    # Positive axial is OUTBOARD (multiplied by side: +1 for Left/+Y, -1 for Right/-Y)
    grooves = [-0.46, -0.15, 0.15, 0.46] if is_rear else [-0.45, -0.15, 0.15, 0.45]
    gw = 0.0082 if is_rear else 0.0070
    gd = 0.0068
    sh_in = 0.016 if is_rear else 0.012
    tr_in = 0.044 if is_rear else 0.036

    # Smooth convex upper-sidewall point between r_bulge and r_sh (eliminates silhouette kinks)
    r_sw_hi = r_bulge + 0.62 * (r_sh - r_bulge)
    y_sw_hi = bulge_w + 0.50 * ((a - sh_in) - bulge_w)
    # Subtle integrated Pirelli P Zero R sidewall styling bead (watertight inside casing profile — zero floating sheets!)
    r_bead_hi = r_bulge + 0.72 * (r_sh - r_bulge)
    y_bead_hi = y_sw_hi + ((r_bead_hi - r_sw_hi) / (r_sh - r_sw_hi)) * ((a - sh_in) - y_sw_hi)

    # Outer crown & shoulder envelope (y_abs, r) used BOTH for casing and exact-conforming tread sipes
    env_pts = [
        (0.0, r_outer),
        (a - tr_in, r_outer),
        (a - tr_in * 0.84, r_outer - 0.0022),
        (a - tr_in * 0.65, r_outer - 0.0068),
        (a - sh_in, r_sh),
    ]

    def _sample_env(y_abs: float) -> tuple[float, float, float]:
        """Return exact casing (r, ny_out, nr_out) on the crown/shoulder envelope at y_abs >= 0."""
        for idx in range(len(env_pts) - 1):
            y0, r0 = env_pts[idx]
            y1, r1 = env_pts[idx + 1]
            if y_abs <= y1 + 1e-9 or idx == len(env_pts) - 2:
                t = max(0.0, min(1.0, (y_abs - y0) / max(1e-9, y1 - y0)))
                r_c = r0 + t * (r1 - r0)
                dy = y1 - y0
                dr = r1 - r0
                # Outward normal to increasing-y curve (dy > 0, dr <= 0) is (-dr, dy) -> (+ny, +nr)
                nlen = math.hypot(dy, dr) + 1e-9
                return r_c, -dr / nlen, dy / nlen
        return r_sh, 0.7, 0.7

    profile = [
        (r_rim_bead - 0.004, -a + 0.015),
        (r_rim_bead + 0.008, -a + 0.005),
        (r_rim_bead + 0.018, -a),
        (r_bulge, -bulge_w),
        (r_sw_hi, -y_sw_hi),
        (r_sh, -(a - sh_in)),
        (r_outer - 0.0068, -(a - tr_in * 0.65)),
        (r_outer - 0.0022, -(a - tr_in * 0.84)),
        (r_outer, -(a - tr_in)),
    ]
    for gpos in grooves:
        yg = a * gpos
        profile.extend([
            (r_outer, yg - gw),
            (r_outer - gd, yg - gw * 0.65),
            (r_outer - gd, yg + gw * 0.65),
            (r_outer, yg + gw),
        ])
    profile.extend([
        (r_outer, a - tr_in),
        (r_outer - 0.0022, a - tr_in * 0.84),
        (r_outer - 0.0068, a - tr_in * 0.65),
        (r_sh, a - sh_in),
        (r_bead_hi + 0.0014, y_bead_hi - 0.0004),
        (r_bead_hi, y_bead_hi + 0.0006),
        (r_bead_hi - 0.0014, y_bead_hi + 0.0004),
        (r_sw_hi, y_sw_hi),
        (r_bulge, bulge_w),
        (r_rim_bead + 0.020, rim_prot),
        (r_rim_bead + 0.012, rim_prot - 0.002),
        (r_rim_bead + 0.004, a - 0.006),
        (r_rim_bead - 0.004, a - 0.015),
    ])

    parts: list[bpy.types.Object] = []
    casing = revolve_profile(
        f"_tmp_casing_{corner}",
        profile,
        mats["tire_rubber"],
        parent=None,
        axis="y",
        side_sign=side,
        steps=120,
        closed_profile=True,
        smooth=True,
    )
    parts.append(casing)

    # Closed-manifold tread & shoulder block sipes conforming strictly to exact casing envelope
    # (Embedded -1.6 mm into casing base, tapering flush into shoulder at y = a - 0.68*tr_in -> ZERO air gaps!)
    sv: list[tuple[float, float, float]] = []
    sf: list[tuple[int, int, int, int]] = []
    n_blocks = 64
    g_mid = abs(grooves[1]) * a
    g_out = abs(grooves[0]) * a
    sipe_bands = [
        # Intermediate rib sipes (between inner & outer circumferential grooves)
        [
            (g_mid + gw + 0.0025, 0.00035),
            (g_out - gw - 0.0025, 0.00035),
        ],
        # Outer shoulder tread block sipes (taper flush into smooth rounded shoulder before silhouette!)
        [
            (g_out + gw + 0.0025, 0.00035),
            (a - tr_in, 0.00035),
            (a - tr_in * 0.84, 0.00025),
            (a - tr_in * 0.68, -0.00025),
        ],
    ]
    for k in range(n_blocks):
        for s_in in (-1.0, 1.0):
            base_phi = 2.0 * math.pi * (k + 0.30 * (s_in + 1.0) * 0.5) / n_blocks
            for band in sipe_bands:
                st = len(sv)
                n_st = len(band)
                for y_abs, h_out in band:
                    yf = y_abs / a
                    phi = base_phi + s_in * (0.044 * yf - 0.018 * yf * yf)
                    dw = 0.0022 + 0.0014 * yf
                    r_c, ny_n, nr_n = _sample_env(y_abs)
                    r_top = r_c + h_out * nr_n
                    y_top = side * s_in * (y_abs + h_out * ny_n)
                    r_bot = r_c - 0.0018 * nr_n
                    y_bot = side * s_in * (y_abs - 0.0018 * ny_n)
                    # 4-vertex closed cross-section ring: top-L, top-R, bot-R, bot-L
                    sv.append((r_top * math.cos(phi - dw), y_top, r_top * math.sin(phi - dw)))
                    sv.append((r_top * math.cos(phi + dw), y_top, r_top * math.sin(phi + dw)))
                    sv.append((r_bot * math.cos(phi + dw), y_bot, r_bot * math.sin(phi + dw)))
                    sv.append((r_bot * math.cos(phi - dw), y_bot, r_bot * math.sin(phi - dw)))
                for n in range(n_st - 1):
                    b0 = st + 4 * n
                    b1 = st + 4 * (n + 1)
                    for c in range(4):
                        c2 = (c + 1) % 4
                        sf.append((b0 + c, b0 + c2, b1 + c2, b1 + c))
                # Close both ends so every sipe is 100% watertight manifold (reliable outward normals!)
                sf.append((st, st + 3, st + 2, st + 1))
                en = st + 4 * (n_st - 1)
                sf.append((en, en + 1, en + 2, en + 3))
    sipes = finalize_mesh(
        f"_tmp_sipes_{corner}",
        sv,
        sf,
        mats["tire_tread"],
        parent=None,
        smooth=False,
        recalc_normals=True,
    )
    parts.append(sipes)

    # Raised molded sidewall lettering ("PIRELLI", "P ZERO R", size spec) flush on the sloped sidewall
    size_str = "325/30 ZR21" if is_rear else "255/35 ZR20"
    r_text = r_bulge + 0.28 * (r_sh - r_bulge)
    # Exact sidewall y & outward normal on segment (r_bulge, bulge_w) -> (r_sw_hi, y_sw_hi)
    t_sw = max(0.0, min(1.0, (r_text - r_bulge) / max(1e-9, r_sw_hi - r_bulge)))
    y_text_abs = bulge_w + t_sw * (y_sw_hi - bulge_w)
    dr_sw = r_sw_hi - r_bulge
    dy_sw = y_sw_hi - bulge_w  # negative (tapers inward with increasing r)
    sw_len = math.hypot(dr_sw, dy_sw) + 1e-9
    nr_wall = -dy_sw / sw_len  # > 0 (tilted slightly radially outward)
    ny_wall = dr_sw / sw_len   # > 0 (mostly axially outboard)
    for word, angle0, fsize in [
        ("PIRELLI", math.radians(112.0), 0.0175),
        ("P ZERO R", math.radians(-78.0), 0.0155),
        (size_str, math.radians(18.0), 0.0110),
    ]:
        step_ang = (fsize * 0.72) / r_text
        half = 0.5 * (len(word) - 1)
        for j, ch in enumerate(word):
            if ch == " ":
                continue
            t_ang = angle0 + side * (j - half) * step_ang
            rad_raw = Vector((math.cos(t_ang), 0.0, math.sin(t_ang)))
            out_dir = Vector((nr_wall * math.cos(t_ang), side * ny_wall, nr_wall * math.sin(t_ang))).normalized()
            tang_x = rad_raw.cross(out_dir).normalized()
            rad_dir = out_dir.cross(tang_x).normalized()
            rot_m = Matrix((tang_x, rad_dir, out_dir)).transposed()
            # Base sits on exact sidewall; symmetric extrude=0.0009 embeds -0.9 mm inside rubber and +0.9 mm proud
            pos = rad_raw * r_text + Vector((0.0, side * y_text_abs, 0.0))
            ch_obj = text_to_mesh(
                f"_tmp_txt_{corner}_{j}",
                ch,
                fsize,
                mats["tire_text"],
                parent=None,
                extrude=0.0009,
                location=pos,
                rot_matrix=rot_m,
            )
            parts.append(ch_obj)

    return join_objects(f"TSC_Tire_{corner}", parts, parent=parent)


def _build_wheel_barrel_and_valve(
    corner: str,
    side: float,
    r_rim_bead: float,
    r_rim_flange: float,
    width: float,
    outboard_face: float,
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> tuple[bpy.types.Object, bpy.types.Object]:
    """Build forged aluminum inner/outer wheel barrel with drop center and 6 o'clock TPMS valve stem."""
    a = 0.5 * width
    inboard = -a + 0.014
    drop_r = r_rim_bead - 0.022
    barrel_inner = r_rim_bead - 0.011

    # Complete structural rim barrel profile (r, y_outboard)
    prof = [
        (r_rim_flange, outboard_face - 0.002),
        (r_rim_flange, outboard_face + 0.0025),
        (r_rim_flange - 0.004, outboard_face + 0.0045),
        (r_rim_bead - 0.001, outboard_face + 0.0020),
        (r_rim_bead - 0.009, outboard_face - 0.005),
        (r_rim_bead - 0.013, outboard_face - 0.018),
        (drop_r, outboard_face - 0.045),
        (drop_r, outboard_face - 0.088),
        (barrel_inner, outboard_face - 0.115),
        (barrel_inner, inboard + 0.012),
        (r_rim_flange - 0.004, inboard + 0.004),
        (r_rim_flange - 0.004, inboard - 0.004),
        (r_rim_bead, inboard - 0.004),
        (r_rim_bead + 0.001, inboard + 0.012),
        (r_rim_bead - 0.002, outboard_face - 0.095),
        (r_rim_bead - 0.004, outboard_face - 0.025),
        (r_rim_bead + 0.004, outboard_face - 0.007),
    ]
    barrel = revolve_profile(
        f"TSC_Rim_Barrel_{corner}",
        prof,
        mats["turbonite"],
        parent=parent,
        axis="y",
        side_sign=side,
        steps=100,
        closed_profile=True,
        smooth=True,
    )

    # TPMS valve stem centered at 6 o'clock (-Z) inside the lower parallel inter-Y slot
    r_valve_base = r_rim_bead - 0.010
    valve_y = side * (outboard_face - 0.017)
    valve_prof = [
        (0.0085, 0.0),
        (0.0085, 0.005),
        (0.0052, 0.007),
        (0.0052, 0.022),
        (0.0064, 0.023),
        (0.0064, 0.032),
        (0.0048, 0.035),
        (0.0005, 0.035),
    ]
    # Axis +Z pointing radially inward from bottom of rim (-Z toward center)
    valve = revolve_profile(
        f"TSC_Rim_Valve_{corner}",
        valve_prof,
        mats["valve_cap"],
        parent=parent,
        axis="z",
        center=(0.0, valve_y, -r_valve_base),
        side_sign=1.0,
        steps=16,
        closed_profile=False,
        smooth=True,
    )
    return barrel, valve


def _build_forged_10y_spokes(
    corner: str,
    side: float,
    r_rim_flange: float,
    outboard_face: float,
    dish_depth: float,
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> bpy.types.Object:
    """Build exact 10-fold Y-spoke Turbonite forged face (20 rim landings, 10 parallel inter-Y slots).

    Geometry verified against 4K close-up `(50).jpeg`:
    - Slim chamfered center-lock hub collar (`r = 0.056..0.070 m`)
    - 10 sculpted flat-faced Y-trunks radiating from hub ring to fork (`r_fork ≈ 0.098 m`, ~38% of rim radius)
    - Each Y-trunk splits cleanly into 2 STRAIGHT sculpted beams running strictly parallel to the 36° slot lines
      all the way into the outer rim barrel lip (ZERO dogleg/kink — exact razor-crisp Porsche forged profile!).
    """
    r_rim_join = r_rim_flange - 0.002
    r_hub_ring = 0.068 if r_rim_flange < 0.274 else 0.071
    r_fork = r_rim_join * 0.424  # ~102 mm front / ~108 mm rear -> zero dogleg straight Y!

    # Half-spacing of spoke centers across each 36° parallel slot (matches (50).jpeg: ~23 mm center-to-center -> ~11 mm clear gap!)
    parallel_offset = r_rim_join * 0.088  # ~22.6 mm from 36° slot centerline

    parts: list[bpy.types.Object] = []

    # Crisp flat-chamfered Turbonite center-lock boss collar (NOT a bulky torus!)
    hub_face_y = outboard_face - dish_depth
    hub_ring_prof = [
        (0.054, hub_face_y - 0.022),
        (0.054, hub_face_y + 0.006),
        (0.058, hub_face_y + 0.009),
        (r_hub_ring - 0.003, hub_face_y + 0.007),
        (r_hub_ring + 0.003, hub_face_y + 0.001),
        (r_hub_ring + 0.004, hub_face_y - 0.017),
        (0.062, hub_face_y - 0.024),
    ]
    hub_ring = revolve_profile(
        f"_tmp_hubring_{corner}",
        hub_ring_prof,
        mats["turbonite"],
        parent=None,
        axis="y",
        side_sign=side,
        steps=80,
        closed_profile=True,
        smooth=True,
    )
    parts.append(hub_ring)

    # Graceful Porsche forged concave arch from hub face to outer rim lip
    def y_depth(r: float) -> float:
        u = max(0.0, min(1.0, (r - r_hub_ring) / (r_rim_join - r_hub_ring)))
        return hub_face_y + dish_depth * (1.0 - (1.0 - u) ** 1.55) - 0.003 * (1.0 - u)

    # Sculpted chamfered forged spoke cross-section: flat machined front face, wide beveled shoulders, deep structural rib
    cross_sec = [
        (-0.92, -0.0022),
        (-0.74,  0.0016),
        (-0.56,  0.0026),
        ( 0.56,  0.0026),
        ( 0.74,  0.0016),
        ( 0.92, -0.0022),
        ( 1.00, -0.0085),
        ( 0.80, -0.0235),
        (-0.80, -0.0235),
        (-1.00, -0.0085),
    ]

    def build_beam(
        bname: str,
        knots_xywd: list[tuple[float, float, float, float]],
    ) -> bpy.types.Object:
        pts2d = [(x, z) for x, z, _, _ in knots_xywd]
        sections = []
        n_k = len(knots_xywd)
        for idx, (x, z, hw, dscale) in enumerate(knots_xywd):
            p_prev = pts2d[max(0, idx - 1)]
            p_next = pts2d[min(n_k - 1, idx + 1)]
            tx, tz = p_next[0] - p_prev[0], p_next[1] - p_prev[1]
            tlen = math.hypot(tx, tz) + 1e-9
            nx, nz = -tz / tlen, tx / tlen
            r = math.hypot(x, z)
            yf = y_depth(r)
            ring = []
            for q, dy in cross_sec:
                px = x + q * hw * nx
                pz = z + q * hw * nz
                py = side * (yf + dy * dscale)
                ring.append((px, py, pz))
            sections.append(ring)
        beam = loft_sections(bname, sections, mats["turbonite"], parent=None, cap_ends=True, smooth=True)
        for face in beam.data.polygons:
            if face.index % len(cross_sec) in (1,2,3,6,7,8):
                face.use_smooth = False
        return beam

    # 10 identical Y-spokes at phi_trunk = (k + 0.5) * 36° (parallel slots at 0°, 36°, ..., 180° valve stem!)
    sector = 2.0 * math.pi / 10.0
    for k in range(10):
        phi_trunk = (k + 0.5) * sector
        st, ct = math.sin(phi_trunk), math.cos(phi_trunk)

        # 1) Bold sculpted Y-trunk from slim hub collar to fork junction (wider forged root!)
        trunk_knots = []
        for r_frac, hw, ds in [
            (0.00, 0.0185, 1.30),
            (0.45, 0.0172, 1.22),
            (0.85, 0.0168, 1.15),
            (1.00, 0.0162, 1.10),
        ]:
            rr = r_hub_ring - 0.004 + r_frac * (r_fork + 0.005 - (r_hub_ring - 0.004))
            trunk_knots.append((rr * st, rr * ct, hw * 1.23, ds))
        parts.append(build_beam(f"_tmp_trunk_{corner}_{k}", trunk_knots))

        # 2) Two razor-straight sculpted forged legs running STRICTLY PARALLEL to the adjacent 36° slot lines!
        #    Flared generously into the rim-landing foot & filleted cleanly into the Y-crotch!
        leg_starts = []
        for branch_sign, slot_idx in [(-1.0, k), (1.0, k + 1)]:
            phi_slot = slot_idx * sector
            ss, cs = math.sin(phi_slot), math.cos(phi_slot)
            perp_x = -branch_sign * cs
            perp_z = branch_sign * ss

            r_start = r_fork * math.cos(0.5 * sector) - 0.008
            p0 = (r_start * ss + (parallel_offset * 1.16) * perp_x, r_start * cs + (parallel_offset * 1.16) * perp_z)
            r_end = r_rim_join + 0.007
            p_end = (r_end * ss + parallel_offset * perp_x, r_end * cs + parallel_offset * perp_z)
            leg_starts.append((p0, p_end))

            leg_knots = []
            for f, hw, ds in [
                (0.00, 0.0102, 1.12),
                (0.18, 0.0090, 1.04),
                (0.55, 0.0082, 0.98),
                (0.86, 0.0086, 1.02),
                (1.00, 0.0112, 1.14),  # Flared forged rim-landing foot!
            ]:
                lx = p0[0] + f * (p_end[0] - p0[0])
                lz = p0[1] + f * (p_end[1] - p0[1])
                leg_knots.append((lx, lz, hw * 1.11, ds))
            parts.append(build_beam(f"_tmp_leg_{corner}_{k}_{int(branch_sign)}", leg_knots))

        # 3) Curved forged Y-crotch gusset fillet blending the V-junction seamlessly (eliminates hard butt seam!)
        p_l0, p_l1 = leg_starts[0]
        p_r0, p_r1 = leg_starts[1]
        p_gl = (p_l0[0] + 0.14 * (p_l1[0] - p_l0[0]), p_l0[1] + 0.14 * (p_l1[1] - p_l0[1]))
        p_gr = (p_r0[0] + 0.14 * (p_r1[0] - p_r0[0]), p_r0[1] + 0.14 * (p_r1[1] - p_r0[1]))
        p_gc = ((r_fork + 0.008) * st, (r_fork + 0.008) * ct)
        gusset_knots = [
            (p_gl[0], p_gl[1], 0.0068, 0.95),
            (p_gc[0], p_gc[1], 0.0085, 1.02),
            (p_gr[0], p_gr[1], 0.0068, 0.95),
        ]
        parts.append(build_beam(f"_tmp_gusset_{corner}_{k}", gusset_knots))

    return join_objects(f"TSC_Rim_YSpoke_{corner}", parts, parent=parent)


def _build_center_lock_hub(
    corner: str,
    side: float,
    hub_face_y: float,
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> tuple[bpy.types.Object, bpy.types.Object]:
    """Build scalloped black anodized center-lock nut and monochrome Turbonite Porsche crest cap."""
    # 1) Black anodized center-lock nut with 12 external drive lobes (matching (50).jpeg!)
    nut_parts: list[bpy.types.Object] = []
    # Main cylindrical collar + bevels
    collar_prof = [
        (0.032, hub_face_y - 0.022),
        (0.058, hub_face_y - 0.022),
        (0.058, hub_face_y + 0.002),
        (0.055, hub_face_y + 0.006),
        (0.044, hub_face_y + 0.008),
        (0.042, hub_face_y + 0.015),
        (0.034, hub_face_y + 0.016),
        (0.032, hub_face_y + 0.012),
    ]
    nut_parts.append(revolve_profile(
        f"_tmp_cl_collar_{corner}",
        collar_prof,
        mats["centerlock_black"],
        parent=None,
        axis="y",
        side_sign=side,
        steps=64,
        closed_profile=True,
        smooth=True,
    ))

    # Thin machined silver/Turbonite laser-ring border around center-lock nut perimeter
    ring_prof = [
        (0.0545, hub_face_y + 0.0055),
        (0.0568, hub_face_y + 0.0055),
        (0.0568, hub_face_y + 0.0068),
        (0.0545, hub_face_y + 0.0068),
    ]
    nut_parts.append(revolve_profile(
        f"_tmp_cl_ring_{corner}",
        ring_prof,
        mats["turbonite_crest"],
        parent=None,
        axis="y",
        side_sign=side,
        steps=64,
        closed_profile=True,
        smooth=True,
    ))

    # 12-lobe scalloped center-lock spline ring (iconic Porsche center-lock silhouette!)
    n_lobes = 12
    pts_per_lobe = 6
    n_ring = n_lobes * pts_per_lobe
    lobe_sections = []
    for y_off, r_scale in [(0.004, 1.0), (0.0145, 0.99), (0.0165, 0.94)]:
        ring = []
        for k in range(n_ring):
            ang = 2.0 * math.pi * k / n_ring
            rr = (0.0425 + 0.0038 * math.cos(n_lobes * ang)) * r_scale
            ring.append((rr * math.cos(ang), side * (hub_face_y + y_off), rr * math.sin(ang)))
        lobe_sections.append(ring)
    nut_parts.append(loft_sections(
        f"_tmp_cl_lobes_{corner}",
        lobe_sections,
        mats["centerlock_black"],
        parent=None,
        cap_ends=True,
        smooth=True,
    ))
    center_lock_obj = join_objects(f"TSC_CenterLockHub_{corner}", nut_parts, parent=parent)

    # 2) Recessed center cap with sculpted 3D monochrome Turbonite Porsche crest shield!
    cap_parts: list[bpy.types.Object] = []
    cap_prof = [
        (0.0005, hub_face_y + 0.0165),
        (0.031, hub_face_y + 0.0165),
        (0.0325, hub_face_y + 0.0145),
        (0.0325, hub_face_y + 0.008),
        (0.0005, hub_face_y + 0.008),
    ]
    cap_parts.append(revolve_profile(
        f"_tmp_cap_base_{corner}",
        cap_prof,
        mats["centerlock_black"],
        parent=None,
        axis="y",
        side_sign=side,
        steps=48,
        closed_profile=True,
        smooth=True,
    ))

    # Sculpted Porsche heraldic shield contour in Turbonite metallic relief
    shield_2d = [
        (-0.0145, 0.0175), (0.0145, 0.0175),
        (0.0150, 0.0055), (0.0125, -0.0055),
        (0.0068, -0.0135), (0.0, -0.0185),
        (-0.0068, -0.0135), (-0.0125, -0.0055),
        (-0.0150, 0.0055),
    ]
    y_s0 = side * (hub_face_y + 0.0162)
    y_s1 = side * (hub_face_y + 0.0186)
    sec_s = [
        [(x, y_s0, z) for x, z in shield_2d],
        [(x * 0.94, y_s1, z * 0.94) for x, z in shield_2d],
    ]
    cap_parts.append(loft_sections(f"_tmp_crest_shield_{corner}", sec_s, mats["turbonite_crest"], parent=None, cap_ends=True, smooth=False))

    # Inner dark shield recess + raised Turbonite quadrant/banner bars for unmistakable Porsche crest detail
    y_r0 = side * (hub_face_y + 0.0185)
    y_r1 = side * (hub_face_y + 0.0195)
    sec_in = [
        [(x * 0.80, y_r0, z * 0.80) for x, z in shield_2d],
        [(x * 0.78, y_r1, z * 0.78) for x, z in shield_2d],
    ]
    cap_parts.append(loft_sections(f"_tmp_crest_field_{corner}", sec_in, mats["turbonite_dark"], parent=None, cap_ends=True, smooth=False))

    # Central Stuttgart escutcheon & quartering cross bars
    y_c0 = side * (hub_face_y + 0.0194)
    y_c1 = side * (hub_face_y + 0.0204)
    bars = [
        [(-0.011, 0.0115), (0.011, 0.0115), (0.011, 0.0085), (-0.011, 0.0085)],  # Top PORSCHE banner
        [(-0.0045, 0.0045), (0.0045, 0.0045), (0.0040, -0.0040), (0.0, -0.0075), (-0.0040, -0.0040)],  # Center horse shield
        [(-0.010, 0.0008), (0.010, 0.0008), (0.010, -0.0008), (-0.010, -0.0008)],  # Horizontal divider
    ]
    for bi, b2d in enumerate(bars):
        cap_parts.append(loft_sections(
            f"_tmp_crest_bar_{corner}_{bi}",
            [[(x, y_c0, z) for x, z in b2d], [(x, y_c1, z) for x, z in b2d]],
            mats["turbonite_crest"],
            parent=None,
            cap_ends=True,
            smooth=False,
        ))

    crest_cap_obj = join_objects(f"TSC_CenterCrestCap_{corner}", cap_parts, parent=parent)
    return center_lock_obj, crest_cap_obj


def _build_pccb_rotor(
    corner: str,
    side: float,
    rotor_radius: float,
    rotor_thick: float,
    friction_y: float,
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> tuple[bpy.types.Object, bpy.types.Object]:
    """Build cross-drilled carbon-ceramic PCCB rotor with sweeping 4-hole rows, cooling vanes, aluminum hat & 10 bobbins."""
    r_inner = rotor_radius * 0.565  # ~119 mm on 420 mm front disc, ~116 mm on 410 mm rear disc
    r_outer = rotor_radius

    # Build genuine perforated ceramic friction ring: 24 sweeping rows × 4 radial holes = 96 real holes per face!
    n_sectors = 24
    radial_breaks = np.linspace(r_inner, r_outer, 5)
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int, int]] = []
    mat_idx: list[int] = []

    y_out = friction_y
    y_in = friction_y - rotor_thick
    hole_r = 0.0024

    for k in range(n_sectors):
        t0 = 2.0 * math.pi * k / n_sectors
        dt = 2.0 * math.pi / n_sectors
        for row in range(4):
            r0 = float(radial_breaks[row])
            r1 = float(radial_breaks[row + 1])
            # Sweeping curved drill pattern matching 4K photo (50).jpeg
            hole_t = t0 + dt * (0.22 + 0.21 * row)
            hole_rad = 0.5 * (r0 + r1)
            hx = hole_rad * math.cos(hole_t)
            hz = hole_rad * math.sin(hole_t)

            # 12-point perimeter of annular cell
            outer_pts: list[tuple[float, float]] = []
            for tt in np.linspace(t0, t0 + dt, 4):
                outer_pts.append((r1 * math.cos(tt), r1 * math.sin(tt)))
            for rr in np.linspace(r1, r0, 3)[1:]:
                outer_pts.append((rr * math.cos(t0 + dt), rr * math.sin(t0 + dt)))
            for tt in np.linspace(t0 + dt, t0, 4)[1:]:
                outer_pts.append((r0 * math.cos(tt), r0 * math.sin(tt)))
            for rr in np.linspace(r0, r1, 3)[1:-1]:
                outer_pts.append((rr * math.cos(t0), rr * math.sin(t0)))

            unit_dirs = []
            for px, pz in outer_pts:
                dx, dz = px - hx, pz - hz
                L = math.hypot(dx, dz) + 1e-9
                unit_dirs.append((dx / L, dz / L))

            n = len(unit_dirs)
            start = len(verts)
            # 6 rings: outer-face cell -> outer-face hole chamfer -> bore -> inner-face chamfer -> inner-face cell
            layers = [
                (None, y_out),
                (hole_r * 1.25, y_out),
                (hole_r, y_out - 0.0012),
                (hole_r, y_in + 0.0012),
                (hole_r * 1.25, y_in),
                (None, y_in),
            ]
            for rr_h, yy in layers:
                pts = outer_pts if rr_h is None else [(hx + dx * rr_h, hz + dz * rr_h) for dx, dz in unit_dirs]
                verts.extend((px, side * yy, pz) for px, pz in pts)

            for lay in range(5):
                b0 = start + lay * n
                b1 = start + (lay + 1) * n
                m_slot = 1 if lay in (1, 2, 3) else 0
                for j in range(n):
                    j2 = (j + 1) % n
                    quad = (b0 + j, b0 + j2, b1 + j2, b1 + j)
                    faces.append(quad if side > 0 else quad[::-1])
                    mat_idx.append(m_slot)

    rotor_disc = finalize_mesh(
        f"_tmp_rotor_disc_{corner}",
        verts,
        faces,
        [mats["pccb_rotor"], mats["pccb_hole"]],
        parent=None,
        smooth=False,
        recalc_normals=True,
        mat_indices=mat_idx,
    )
    add_planar_uv(rotor_disc, scale=2.0 * rotor_radius, axis="y")

    # Dark recessed outer vent channel + directional internal cooling vanes
    vent_core = revolve_profile(
        f"_tmp_vent_core_{corner}",
        [(r_outer - 0.006, y_out - 0.004), (r_outer - 0.006, y_in + 0.004)],
        mats["pccb_hole"],
        parent=None,
        axis="y",
        side_sign=side,
        steps=72,
        closed_profile=False,
        smooth=True,
    )
    vv: list[tuple[float, float, float]] = []
    vf: list[tuple[int, int, int, int]] = []
    n_vanes = 60
    for k in range(n_vanes):
        phi = 2.0 * math.pi * k / n_vanes
        st = len(vv)
        for dy in (y_out - 0.002, y_in + 0.002):
            for dt_v in (-0.014, 0.014):
                vv.append((
                    (r_outer - 0.0004) * math.cos(phi + dt_v),
                    side * dy,
                    (r_outer - 0.0004) * math.sin(phi + dt_v),
                ))
        vf.append((st, st + 1, st + 3, st + 2))
    vanes = finalize_mesh(f"_tmp_rotor_vanes_{corner}", vv, vf, mats["pccb_rotor"], parent=None, smooth=False)
    add_planar_uv(vanes, scale=2.0 * rotor_radius, axis="y")

    rotor_obj = join_objects(f"TSC_PCCB_Rotor_{corner}", [rotor_disc, vent_core, vanes], parent=parent)

    # Black anodized floating aluminum hat + 10 stainless steel floating bobbins (exact match to (50).jpeg!)
    hat_parts: list[bpy.types.Object] = []
    hat_prof = [
        (0.036, y_out + 0.022),
        (0.096, y_out + 0.022),
        (0.104, y_out + 0.015),
        (r_inner - 0.008, y_out + 0.003),
        (r_inner + 0.006, y_out + 0.001),
        (r_inner + 0.006, y_in + 0.008),
        (0.095, y_in + 0.008),
        (0.036, y_in + 0.010),
    ]
    hat_parts.append(revolve_profile(
        f"_tmp_hat_{corner}",
        hat_prof,
        mats["rotor_hat"],
        parent=None,
        axis="y",
        side_sign=side,
        steps=64,
        closed_profile=True,
        smooth=True,
    ))

    # 10 refined machined stainless floating bobbin buttons + dark recessed socket centers (matches (50).jpeg!)
    r_bobbin = r_inner - 0.004
    bobbin_centers = [
        (r_bobbin * math.sin(2.0 * math.pi * k / 10.0), side * (y_out + 0.001), r_bobbin * math.cos(2.0 * math.pi * k / 10.0))
        for k in range(10)
    ]
    hat_parts.append(bolt_array(
        f"_tmp_bobbins_{corner}",
        bobbin_centers,
        radius=0.0068,
        height=side * 0.0058,
        material=mats["stainless"],
        parent=None,
        axis="y",
        sides=12,
    ))
    hat_parts.append(bolt_array(
        f"_tmp_bobbin_cores_{corner}",
        [(bx, side * (y_out + 0.0056), bz) for bx, _, bz in bobbin_centers],
        radius=0.0030,
        height=side * 0.0018,
        material=mats["pccb_hole"],
        parent=None,
        axis="y",
        sides=6,
    ))
    hat_obj = join_objects(f"TSC_PCCB_Hat_{corner}", hat_parts, parent=parent)
    return rotor_obj, hat_obj


def build_wheels_and_rotors(
    rig_root: bpy.types.Object,
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
) -> dict[str, bpy.types.Object]:
    """Create all four `Pivot_Corner_*` -> `Pivot_WheelSpin_*` hierarchies with wheels, tires & PCCB rotors."""
    pivots: dict[str, bpy.types.Object] = {}

    x_f = cfg["x_front_axle"]
    x_r = cfg["x_rear_axle"]
    # Factory track is measured at ground contact center; with negative camber (-0.8° F / -1.8° R),
    # wheel hub center sits slightly inboard so top of tire tucks cleanly inside the 950 mm widebody haunch (`|Y| <= 0.946 m`)!
    y_f = 0.5 * cfg["track_front"] - 0.005
    y_r = 0.5 * cfg["track_rear"] - 0.012

    corners = [
        ("FL", x_f, +y_f, +1.0, False),
        ("FR", x_f, -y_f, -1.0, False),
        ("RL", x_r, +y_r, +1.0, True),
        ("RR", x_r, -y_r, -1.0, True),
    ]

    for corner, x_ax, y_ax, side, is_rear in corners:
        camber_deg = 1.8 if is_rear else 0.8
        z_hub = cfg["z_hub_r"] if is_rear else cfg["z_hub_f"]
        # Compensate slight inner-shoulder drop from negative camber so tire sits tangent to Z=0.000!
        r_tire = (cfg["r_tire_r"] - 0.0030) if is_rear else (cfg["r_tire_f"] - 0.0012)
        w_tire = (min(cfg["w_tire_r"], 0.304) if is_rear else cfg["w_tire_f"])
        r_rim_bead = cfg["r_rim_bead_r"] if is_rear else cfg["r_rim_bead_f"]
        r_rim_flange = r_rim_bead + 0.0145
        dish_depth = 0.058 if is_rear else 0.036
        rotor_r = 0.5 * (cfg["rotor_dia_r"] if is_rear else cfg["rotor_dia_f"])
        rotor_t = cfg["rotor_thick_r"] if is_rear else cfg["rotor_thick_f"]

        # Steering / corner pivot at wheel center with authentic Porsche negative camber (+X rotation tilts +Y left top INWARD!)
        p_corner = make_empty(f"Pivot_Corner_{corner}", (x_ax, y_ax, z_hub), parent=rig_root)
        p_corner.rotation_euler = (side * math.radians(camber_deg), 0.0, 0.0)
        p_spin = make_empty(f"Pivot_WheelSpin_{corner}", (0.0, 0.0, 0.0), parent=p_corner)

        pivots[p_corner.name] = p_corner
        pivots[p_spin.name] = p_spin

        outboard_face = 0.5 * w_tire - 0.011
        hub_face_y = outboard_face - dish_depth
        friction_y = hub_face_y - 0.025

        _build_tire(corner, side, r_tire, r_rim_bead, w_tire, is_rear, mats, p_spin)
        _build_wheel_barrel_and_valve(corner, side, r_rim_bead, r_rim_flange, w_tire, outboard_face, mats, p_spin)
        _build_forged_10y_spokes(corner, side, r_rim_flange, outboard_face, dish_depth, mats, p_spin)
        _build_center_lock_hub(corner, side, hub_face_y, mats, p_spin)
        _build_pccb_rotor(corner, side, rotor_r, rotor_t, friction_y, mats, p_spin)

    return pivots
