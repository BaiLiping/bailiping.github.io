"""992.2 Porsche 911 Turbo S Cabriolet mechanicals Blender package."""

from .build_mechanicals import DEFAULT_CFG, build

__all__ = ["DEFAULT_CFG", "build"]
