"""992.2 Porsche 911 Turbo S Cabriolet — Monocoque Chassis Tub, AWD Front Drive, Subframes & 400V T-Hybrid HV System.

Faithfully modeled from official Porsche AG illustrations:
- `Rolling chassis and electrical routing - view 1.jpg` (323530)
- `Rolling chassis and electrical routing - view 2.jpg` (323532)
- `Porsche - 911 T-Hybrid rescue sheets.pdf` (page 1 top & side HV layout)

All meshes sit cleanly under `Pivot_Drivetrain_Chassis` (fixed at origin in exploded view), strictly above
`Z_UNDERBODY = 0.125 m`, cleanly under cabin carpet (`Z_carpet = 0.195 m`), and strictly inboard of the
992.2 exterior skin & wheelhouse cutouts so zero clipping occurs when assembled and the rolling chassis
looks breathtaking when the body lifts 1.5H in exploded view!
"""

from __future__ import annotations

import math
from typing import Any

import bpy
import numpy as np

from .common import (
    bolt_array,
    ellipse_case,
    join_objects,
    loft_sections,
    round_box,
    sculpted_box_loft,
    tube_along_points,
)


def _build_undertray_and_floorpan(
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> None:
    """Build flat aerodynamic underbody composite tray and aluminum-steel Cabriolet monocoque floorpan + sills."""
    z_ub = cfg.get("z_underbody", 0.126)

    # 1) Flat Aerodynamic Undertray (`TSC_Undertray_Main`) — strictly inside body sills & rear diffuser
    # Profile from behind front bumper (+1.92) to ahead of rear diffuser (-2.05)
    ut_stations = [
        # (x, half_width, z_bot, z_top)
        (+1.92, 0.50, z_ub + 0.012, z_ub + 0.024),
        (+1.68, 0.56, z_ub + 0.004, z_ub + 0.016),
        (+1.22, 0.48, z_ub + 0.002, z_ub + 0.014),  # Narrowed cleanly between front wheelhouses!
        (+0.78, 0.54, z_ub + 0.002, z_ub + 0.014),
        (+0.55, 0.72, z_ub + 0.002, z_ub + 0.014),
        (-0.52, 0.72, z_ub + 0.002, z_ub + 0.014),
        (-0.78, 0.50, z_ub + 0.004, z_ub + 0.016),  # Narrowed cleanly between rear wheelhouses!
        (-1.22, 0.46, z_ub + 0.012, z_ub + 0.024),
        (-1.62, 0.48, z_ub + 0.026, z_ub + 0.038),
        (-1.95, 0.42, z_ub + 0.068, z_ub + 0.080),  # Sweeps cleanly inside steeper 992.2 rear departure angle!
    ]
    ut_sec = []
    for x, hw, zb, zt in ut_stations:
        ut_sec.append([
            (x, -hw, zb + 0.005),
            (x, -hw * 0.92, zb),
            (x,  hw * 0.92, zb),
            (x,  hw, zb + 0.005),
            (x,  hw * 0.95, zt),
            (x, -hw * 0.95, zt),
        ])
    ut_parts = [loft_sections("_tmp_ut_pan", ut_sec, mats["undertray"], parent=None, cap_ends=True, smooth=False)]

    # Subtle aerodynamic underbody longitudinal strakes
    for y_s in (-0.32, 0.0, 0.32):
        ut_parts.append(round_box(
            f"_tmp_ut_strake_{y_s:.2f}",
            (0.0, y_s, z_ub + 0.001),
            (1.10, 0.014, 0.010),
            mats["undertray"],
            parent=None,
            bevel=0.002,
        ))
    join_objects("TSC_Undertray_Main", ut_parts, parent=parent)

    # 2) Aluminum-Steel Cabriolet Monocoque Floorpan, Central Tunnel, Reinforced Sills & Bulkheads
    fl_parts: list[bpy.types.Object] = []

    # Main passenger cabin floorpan with raised central driveshaft/HV tunnel (kept <= Z=0.184 under carpet!)
    # Cross-section across Y with raised central tunnel (Z_tunnel_top ≈ 0.32 m, well inside center console)
    fl_x = [+0.78, +0.62, +0.42, 0.00, -0.45, -0.68, -0.82]
    fl_sec = []
    for x in fl_x:
        hw = 0.68 if abs(x) < 0.58 else 0.54
        # Tunnel narrows slightly in rear
        tw = 0.135 if x > -0.50 else 0.165
        th = 0.295 if x > -0.55 else 0.315
        z0 = z_ub + 0.016  # 0.142 m
        z1 = z_ub + 0.056  # 0.182 m (strictly below interior carpet Z=0.195!)
        fl_sec.append([
            (x, -hw, z0), (x, hw, z0),
            (x,  hw, z1), (x,  tw + 0.03, z1),
            (x,  tw, th), (x, -tw, th),
            (x, -tw - 0.03, z1), (x, -hw, z1),
        ])
    fl_parts.append(loft_sections("_tmp_fl_cabin", fl_sec, mats["chassis_tub"], parent=None, cap_ends=True, smooth=False))

    # Heavily reinforced Cabriolet box-section rocker sills (extra torsional rigidity for convertible!)
    for side in (-1.0, 1.0):
        sill_sec = []
        for x, y_in, y_out, zb, zt in [
            (+0.78, 0.53, 0.63, z_ub + 0.018, 0.255),
            (+0.58, 0.65, 0.755, z_ub + 0.015, 0.250),
            ( 0.00, 0.66, 0.760, z_ub + 0.015, 0.245),
            (-0.54, 0.65, 0.755, z_ub + 0.016, 0.255),
            (-0.76, 0.52, 0.63, z_ub + 0.022, 0.275),
        ]:
            sill_sec.append([
                (x, side * y_in, zb),
                (x, side * y_out, zb + 0.006),
                (x, side * y_out, zt - 0.008),
                (x, side * y_in, zt),
            ])
        fl_parts.append(loft_sections(f"_tmp_sill_{int(side)}", sill_sec, mats["chassis_sill"], parent=None, cap_ends=True, smooth=False))
        # Structural seat cross-braces & longitudinal floor stiffeners for rich metallic unibody realism
        fl_parts.append(round_box(f"_tmp_fl_rib_{int(side)}", (0.0, side * 0.42, z_ub + 0.060), (1.18, 0.036, 0.016), mats["chassis_sill"], parent=None, bevel=0.003))
    for x_xm in (+0.38, -0.18):
        fl_parts.append(round_box(f"_tmp_fl_xm_{x_xm:.2f}", (x_xm, 0.0, z_ub + 0.060), (0.055, 1.30, 0.018), mats["chassis_sill"], parent=None, bevel=0.004))

    # Low sculpted front footwell toe-board bulkhead (leaves front 400V HV battery & steering cleanly exposed!)
    fl_parts.append(round_box(
        "_tmp_fw_front",
        (+0.76, 0.0, 0.275),
        (0.045, 1.06, 0.21),
        mats["chassis_tub"],
        parent=None,
        bevel=0.010,
    ))
    # Low rear cabin heel-board cross-brace (leaves PDK transaxle, gear train & inverters completely unobstructed!)
    fl_parts.append(round_box(
        "_tmp_fw_rear",
        (-0.84, 0.0, 0.270),
        (0.048, 1.04, 0.19),
        mats["chassis_tub"],
        parent=None,
        bevel=0.010,
    ))

    # Front & Rear longitudinal aluminum crash / frame rails (open architecture exposing coilovers per Rolling chassis 1 & 2!)
    for side in (-1.0, 1.0):
        # Front longitudinal frame rails (+0.75 -> +1.96) framing frunk & radiators
        fl_parts.append(tube_along_points(
            f"_tmp_rail_f_{int(side)}",
            [
                (+0.74, side * 0.44, 0.26),
                (+1.05, side * 0.45, 0.31),
                (+1.42, side * 0.43, 0.34),
                (+1.88, side * 0.41, 0.32),
            ],
            0.032,
            mats["machined_alu"],
            parent=None,
            sides=8,
            subdiv=3,
        ))
        # Open aluminum strut-tower ring collar at top of front MacPherson mount (coilover springs stay 100% visible!)
        fl_parts.append(tube_along_points(
            f"_tmp_tower_brace_f_{int(side)}",
            [(+1.06, side * 0.45, 0.32), (+1.19, side * 0.53, 0.74), (+1.34, side * 0.44, 0.35)],
            0.014,
            mats["machined_alu"],
            parent=None,
            sides=8,
            subdiv=2,
        ))
        # Rear longitudinal frame rails (-0.82 -> -1.94) framing PDK & flat-6 engine bay (stops cleanly at engine console!)
        fl_parts.append(tube_along_points(
            f"_tmp_rail_r_{int(side)}",
            [
                (-0.82, side * 0.46, 0.30),
                (-1.18, side * 0.47, 0.36),
                (-1.58, side * 0.47, 0.38),
                (-1.93, side * 0.43, 0.35),
            ],
            0.032,
            mats["machined_alu"],
            parent=None,
            sides=8,
            subdiv=3,
        ))
        # Open rear coilover upper brace arch (keeps rear PASM spring & coilover 100% exposed!)
        fl_parts.append(tube_along_points(
            f"_tmp_tower_brace_r_{int(side)}",
            [(-1.06, side * 0.47, 0.36), (-1.20, side * 0.525, 0.77), (-1.34, side * 0.47, 0.38)],
            0.014,
            mats["machined_alu"],
            parent=None,
            sides=8,
            subdiv=2,
        ))

    # Front aluminum crash cross-beam behind front bumper
    fl_parts.append(tube_along_points(
        "_tmp_crash_front",
        [(+1.88, -0.44, 0.32), (+1.96, -0.22, 0.32), (+1.98, 0.0, 0.32), (+1.96, +0.22, 0.32), (+1.88, +0.44, 0.32)],
        0.028,
        mats["machined_alu"],
        parent=None,
        sides=8,
        subdiv=3,
    ))

    join_objects("TSC_Chassis_Floor", fl_parts, parent=parent)


def _build_frunk_fuel_and_radiators(
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> None:
    """Build low contoured frunk floor tray, 63L front fuel tank (rescue sheet layout), and triple cooling radiators."""
    # 1) Sculpted 63L front fuel tank tucked between front bulkhead & front axle (exact rescue sheet position!)
    fuel_parts = [
        sculpted_box_loft(
            "_tmp_fuel_tank",
            [
                (+0.82, 0.0, 0.27, 0.34, 0.10),
                (+0.98, 0.0, 0.28, 0.36, 0.12),
                (+1.14, 0.0, 0.31, 0.32, 0.10),
                (+1.24, 0.0, 0.34, 0.24, 0.07),
            ],
            mats["engine_plastic"],
            parent=None,
            axis="x",
        ),
        # Fuel filler neck routed tightly behind front bulkhead / inner wheelhouse rail with 2 mounting clips (zero open-air crossing!)
        tube_along_points(
            "_tmp_fuel_neck",
            [(+0.96, -0.34, 0.34), (+0.92, -0.45, 0.37), (+0.94, -0.52, 0.56), (+1.02, -0.68, 0.70), (+1.04, -0.76, 0.74)],
            0.018,
            mats["rubber_hose"],
            parent=None,
            sides=12,
            subdiv=3,
        ),
        # Bolted aluminum support brackets anchoring fuel filler neck to front bulkhead & right rail
        round_box("_tmp_fuel_clip1", (+0.92, -0.45, 0.37), (0.038, 0.042, 0.042), mats["machined_alu"], parent=None, bevel=0.004),
        round_box("_tmp_fuel_clip2", (+0.95, -0.53, 0.56), (0.038, 0.046, 0.038), mats["machined_alu"], parent=None, bevel=0.004),
        ellipse_case(
            "_tmp_fuel_pocket",
            [(-0.74, +1.04, 0.74, 0.038, 0.038), (-0.78, +1.04, 0.74, 0.032, 0.032)],
            mats["engine_plastic"],
            parent=None,
            axis="y",
            steps=20,
        ),
    ]
    join_objects("TSC_Chassis_FuelTank", fuel_parts, parent=parent)

    # 2) Sculpted Open-Top Frunk Luggage Tray (thin floor + low side lip, leaving front steering/radiators clear!)
    frunk_parts = [
        round_box("_tmp_frunk_floor", (+1.64, 0.0, 0.295), (0.36, 0.66, 0.022), mats["undertray"], parent=None, bevel=0.006),
        round_box("_tmp_frunk_wall_f", (+1.82, 0.0, 0.385), (0.022, 0.64, 0.18), mats["engine_plastic"], parent=None, bevel=0.005),
        round_box("_tmp_frunk_wall_r", (+1.46, 0.0, 0.395), (0.022, 0.68, 0.20), mats["engine_plastic"], parent=None, bevel=0.005),
        round_box("_tmp_frunk_wall_l", (+1.64, +0.33, 0.385), (0.36, 0.022, 0.18), mats["engine_plastic"], parent=None, bevel=0.005),
        round_box("_tmp_frunk_wall_rr", (+1.64, -0.33, 0.385), (0.36, 0.022, 0.18), mats["engine_plastic"], parent=None, bevel=0.005),
    ]
    join_objects("TSC_Chassis_FrunkTub", frunk_parts, parent=parent)

    # 3) Triple Front Cooling Radiators (Left, Center, Right) positioned behind the 992.2 active bumper flaps!
    rad_parts: list[bpy.types.Object] = []
    # Center low-temp T-Hybrid / engine radiator
    rad_parts.append(round_box("_tmp_rad_c_core", (+2.02, 0.0, 0.27), (0.048, 0.52, 0.20), mats["rad_core"], parent=None, bevel=0.006, rot_euler=(0.0, math.radians(-16), 0.0)))
    rad_parts.append(round_box("_tmp_rad_c_tanks_l", (+2.02, +0.275, 0.27), (0.058, 0.036, 0.21), mats["engine_plastic"], parent=None, bevel=0.006, rot_euler=(0.0, math.radians(-16), 0.0)))
    rad_parts.append(round_box("_tmp_rad_c_tanks_r", (+2.02, -0.275, 0.27), (0.058, 0.036, 0.21), mats["engine_plastic"], parent=None, bevel=0.006, rot_euler=(0.0, math.radians(-16), 0.0)))
    # Left & Right outboard angled radiators tucked cleanly behind the 5 vertical active flaps & tapered nose planform!
    for side in (-1.0, 1.0):
        rad_parts.append(round_box(
            f"_tmp_rad_side_{int(side)}",
            (+1.86, side * 0.48, 0.285),
            (0.048, 0.28, 0.22),
            mats["rad_core"],
            parent=None,
            bevel=0.006,
            rot_euler=(0.0, math.radians(-12), side * math.radians(-26)),
        ))
        rad_parts.append(round_box(
            f"_tmp_rad_shroud_{int(side)}",
            (+1.89, side * 0.495, 0.285),
            (0.022, 0.30, 0.235),
            mats["engine_plastic"],
            parent=None,
            bevel=0.005,
            rot_euler=(0.0, math.radians(-12), side * math.radians(-26)),
        ))
    join_objects("TSC_Front_Radiators", rad_parts, parent=parent)


def _build_subframes_and_awd_ptm(
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> None:
    """Build front & rear cast aluminum subframes, front skid/shear plate, AWD front diff & truss prop-shaft beam."""
    x_f = cfg["x_front_axle"]
    x_r = cfg["x_rear_axle"]

    # 1) Front Cast Aluminum Subframe & Bolted Aluminum Shear Plate (iconic detail in Rolling chassis view 1!)
    sf_f: list[bpy.types.Object] = []
    # Front & rear crossmembers
    for dx in (-0.26, +0.22):
        sf_f.append(round_box(f"_tmp_sff_xm_{dx:.2f}", (x_f + dx, 0.0, 0.215), (0.075, 0.78, 0.048), mats["cast_alu"], parent=None, bevel=0.010))
    for side in (-1.0, 1.0):
        sf_f.append(tube_along_points(
            f"_tmp_sff_rail_{int(side)}",
            [(x_f - 0.28, side * 0.37, 0.215), (x_f, side * 0.38, 0.215), (x_f + 0.24, side * 0.37, 0.215)],
            0.028,
            mats["cast_alu"],
            parent=None,
            sides=8,
            subdiv=2,
        ))
    # Bright machined aluminum front shear/skid plate with bolt array (Rolling chassis view 1!)
    sf_f.append(round_box("_tmp_sff_shearplate", (x_f + 0.16, 0.0, 0.172), (0.28, 0.72, 0.014), mats["machined_alu"], parent=None, bevel=0.004))
    sf_f.append(bolt_array(
        "_tmp_sff_bolts",
        [(x_f + bx, by, 0.165) for bx in (0.06, 0.26) for by in (-0.31, -0.14, 0.14, 0.31)],
        radius=0.008,
        height=-0.006,
        material=mats["stainless"],
        parent=None,
        axis="z",
    ))
    join_objects("TSC_Subframe_Front", sf_f, parent=parent)

    # 2) Rear Lightweight Cast Aluminum Multi-Link Subframe Carrier
    sf_r: list[bpy.types.Object] = []
    for dx, zz in [(-0.24, 0.225), (+0.26, 0.232)]:
        sf_r.append(round_box(f"_tmp_sfr_xm_{dx:.2f}", (x_r + dx, 0.0, zz), (0.082, 0.80, 0.055), mats["cast_alu"], parent=None, bevel=0.012))
    for side in (-1.0, 1.0):
        sf_r.append(tube_along_points(
            f"_tmp_sfr_rail_{int(side)}",
            [(x_r - 0.28, side * 0.39, 0.230), (x_r, side * 0.40, 0.235), (x_r + 0.28, side * 0.39, 0.235)],
            0.032,
            mats["cast_alu"],
            parent=None,
            sides=8,
            subdiv=2,
        ))
        # Upper multi-link pickup towers on rear subframe
        sf_r.append(tube_along_points(
            f"_tmp_sfr_up_{int(side)}",
            [(x_r - 0.18, side * 0.39, 0.245), (x_r - 0.16, side * 0.39, 0.505), (x_r + 0.18, side * 0.39, 0.510), (x_r + 0.20, side * 0.39, 0.245)],
            0.024,
            mats["cast_alu"],
            parent=None,
            sides=8,
            subdiv=2,
        ))
    join_objects("TSC_Subframe_Rear", sf_r, parent=parent)

    # 3) AWD Front Differential + PTM Electro-Hydraulic Multi-Plate Clutch Unit (Rolling chassis view 1!)
    fd_parts: list[bpy.types.Object] = []
    # Main ribbed differential pumpkin aligned with front axle
    fd_parts.append(ellipse_case(
        "_tmp_fdiff_body",
        [
            (-0.155, x_f, 0.295, 0.072, 0.070),
            (-0.110, x_f, 0.295, 0.105, 0.100),
            ( 0.000, x_f, 0.295, 0.112, 0.108),
            (+0.110, x_f, 0.295, 0.098, 0.094),
            (+0.155, x_f, 0.295, 0.068, 0.066),
        ],
        mats["cast_alu"],
        parent=None,
        axis="y",
        steps=28,
    ))
    # Rearward PTM wet multi-plate hang-on AWD clutch barrel extending aft toward prop shaft!
    fd_parts.append(ellipse_case(
        "_tmp_fdiff_ptm",
        [
            (x_f - 0.04, 0.0, 0.290, 0.095, 0.092),
            (x_f - 0.16, 0.0, 0.285, 0.086, 0.084),
            (x_f - 0.32, 0.0, 0.278, 0.068, 0.068),
            (x_f - 0.42, 0.0, 0.275, 0.048, 0.048),
        ],
        mats["cast_alu"],
        parent=None,
        axis="x",
        steps=24,
    ))
    # External reinforcement ribs & bolts on PTM housing
    for rx in (x_f - 0.12, x_f - 0.22, x_f - 0.31):
        fd_parts.append(ellipse_case(
            f"_tmp_fdiff_rib_{rx:.2f}",
            [(rx - 0.006, 0.0, 0.284, 0.090, 0.088), (rx + 0.006, 0.0, 0.284, 0.090, 0.088)],
            mats["machined_alu"],
            parent=None,
            axis="x",
            steps=24,
        ))
    join_objects("TSC_AWD_FrontDiff", fd_parts, parent=parent)

    # 4) Iconic Central Machined Aluminum Prop-Shaft Truss Beam & AWD Carbon/Steel Driveshaft (Rolling chassis 1 & 2!)
    ps_parts: list[bpy.types.Object] = []
    # Main cylindrical AWD driveshaft running from front PTM clutch (X = +0.80) back to front of PDK (X = -0.52)
    ps_parts.append(ellipse_case(
        "_tmp_propshaft_tube",
        [
            (+0.82, 0.0, 0.272, 0.032, 0.032),
            (+0.72, 0.0, 0.270, 0.036, 0.036),
            (+0.18, 0.0, 0.266, 0.034, 0.034),
            (-0.18, 0.0, 0.268, 0.034, 0.034),
            (-0.54, 0.0, 0.278, 0.038, 0.038),
        ],
        mats["machined_alu"],
        parent=None,
        axis="x",
        steps=24,
    ))
    # Mid-shaft rubber/steel guibo flex coupling & center support bearing carrier
    ps_parts.append(ellipse_case(
        "_tmp_propshaft_coupler",
        [(+0.14, 0.0, 0.266, 0.052, 0.052), (+0.22, 0.0, 0.266, 0.052, 0.052)],
        mats["gunmetal"],
        parent=None,
        axis="x",
        steps=24,
    ))
    # Signature machined aluminum triangular-truss prop-shaft carrier spine (Rolling chassis view 1 & 2!)
    for side in (-1.0, 1.0):
        # Upper & lower truss rails on left/right of front prop-shaft half (+0.18 to +0.82)
        ps_parts.append(round_box(f"_tmp_truss_top_{int(side)}", (+0.50, side * 0.052, 0.308), (0.66, 0.014, 0.016), mats["machined_alu"], parent=None, bevel=0.003))
        ps_parts.append(round_box(f"_tmp_truss_bot_{int(side)}", (+0.50, side * 0.052, 0.228), (0.66, 0.014, 0.016), mats["machined_alu"], parent=None, bevel=0.003))
        # Diagonal Warren-truss webs creating the crisp triangular lightening cutouts!
        n_bays = 6
        x0_t, x1_t = 0.20, 0.80
        dx_b = (x1_t - x0_t) / n_bays
        for b in range(n_bays):
            xa = x0_t + b * dx_b
            xb = xa + dx_b
            za = 0.232 if b % 2 == 0 else 0.304
            zb = 0.304 if b % 2 == 0 else 0.232
            ps_parts.append(tube_along_points(
                f"_tmp_truss_diag_{int(side)}_{b}",
                [(xa, side * 0.052, za), (xb, side * 0.052, zb)],
                0.008,
                mats["machined_alu"],
                parent=None,
                sides=8,
                subdiv=1,
            ))
    join_objects("TSC_AWD_PropShaft", ps_parts, parent=parent)


def _build_thybrid_400v_system(
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
    parent: bpy.types.Object,
) -> None:
    """Build 992.2 T-Hybrid 1.9 kWh 400V front Li-ion HV battery, rear pulse inverters, and vivid orange HV cable loom."""
    x_f = cfg["x_front_axle"]

    # 1) Front-mounted 1.9 kWh 400V Liquid-Cooled Li-Ion HV Battery (`Rolling chassis view 1 & 2`, `rescue-01.png`)
    # Sits compactly in the front bulkhead battery compartment right above the front differential!
    bat_parts: list[bpy.types.Object] = []
    bx, by, bz = x_f + 0.02, 0.0, 0.505  # World X=+1.245, Z=0.405..0.605 (well below frunk lid Z=0.79!)
    # Main silver aluminum liquid-cooled housing
    bat_parts.append(round_box("_tmp_hv_bat_box", (bx, by, bz), (0.26, 0.38, 0.20), mats["machined_alu"], parent=None, bevel=0.012))
    # Top sealed lid plate + black molded carry/hold-down bridge handle (iconic look in Rolling chassis view 1!)
    bat_parts.append(round_box("_tmp_hv_bat_lid", (bx, by, bz + 0.102), (0.24, 0.36, 0.016), mats["cast_alu"], parent=None, bevel=0.005))
    bat_parts.append(round_box("_tmp_hv_bat_handle", (bx + 0.02, by, bz + 0.125), (0.045, 0.28, 0.026), mats["engine_plastic"], parent=None, bevel=0.006))
    # Side mounting brackets anchoring HV battery down to front bulkhead/rails
    for side in (-1.0, 1.0):
        bat_parts.append(round_box(f"_tmp_hv_bat_brkt_{int(side)}", (bx, side * 0.205, bz - 0.06), (0.18, 0.035, 0.075), mats["gunmetal"], parent=None, bevel=0.005))
    # Orange HV plug receptacle & quick-disconnect on front-left (+Y) face of battery
    bat_parts.append(round_box("_tmp_hv_bat_plug", (bx - 0.06, +0.208, bz - 0.025), (0.075, 0.048, 0.062), mats["hv_orange"], parent=None, bevel=0.008))
    bat_parts.append(bolt_array(
        "_tmp_hv_bat_bolts",
        [(bx + dx, dy, bz + 0.110) for dx in (-0.10, +0.10) for dy in (-0.15, 0.0, +0.15)],
        radius=0.006,
        height=0.006,
        material=mats["stainless"],
        parent=None,
        axis="z",
    ))
    join_objects("TSC_HV_Battery_400V", bat_parts, parent=parent)

    # 2) Rear T-Hybrid Power Electronics Suite (Pulse Inverter + Dual eTurbo Inverters + HV Junction Box)
    # Faithfully arranged above the PDK & front of engine per `Rolling chassis view 2.jpg`!
    inv_parts: list[bpy.types.Object] = []
    # Main black HV distribution/junction box above forward PDK (X = -0.78, Y = +0.06, Z = 0.61)
    inv_parts.append(round_box("_tmp_hv_jbox", (-0.82, +0.08, 0.60), (0.24, 0.28, 0.11), mats["engine_plastic"], parent=None, bevel=0.012))
    # Main silver finned 400V Pulse Inverter (drives 60 kW PDK electric traction motor; X = -1.08, Y = -0.10, Z = 0.63)
    inv_parts.append(round_box("_tmp_hv_pulse_inv", (-1.08, -0.06, 0.62), (0.28, 0.26, 0.095), mats["machined_alu"], parent=None, bevel=0.010))
    # Cooling fins on top of main pulse inverter
    for fi in range(7):
        inv_parts.append(round_box(f"_tmp_hv_fin_{fi}", (-1.08, -0.16 + fi * 0.033, 0.672), (0.25, 0.008, 0.014), mats["cast_alu"], parent=None, bevel=0.002))
    # Twin eTurbo power electronics / DC-DC converter boxes flanking rear engine bay (Rolling chassis view 2!)
    inv_parts.append(round_box("_tmp_hv_etinv_l", (-1.12, +0.26, 0.56), (0.22, 0.16, 0.12), mats["cast_alu"], parent=None, bevel=0.010))
    inv_parts.append(round_box("_tmp_hv_etinv_r", (-1.34, -0.24, 0.60), (0.20, 0.18, 0.085), mats["machined_alu"], parent=None, bevel=0.010))
    # Orange HV connector plugs on inverters
    for px, py, pz in [(-0.96, +0.08, 0.58), (-1.22, -0.05, 0.62), (-1.12, +0.17, 0.57), (-1.24, -0.22, 0.60)]:
        inv_parts.append(round_box(f"_tmp_hv_conn_{px:.2f}_{py:.2f}", (px, py, pz), (0.042, 0.038, 0.038), mats["hv_orange"], parent=None, bevel=0.006))
    join_objects("TSC_HV_Inverter_Suite", inv_parts, parent=parent)

    # 3) Iconic Bright Orange 400V High-Voltage Cable Harness (`Rolling chassis view 1 & 2`!)
    hv_parts: list[bpy.types.Object] = []
    # Dual main DC bus cables looping out of front HV battery plug -> down into central tunnel -> back to rear junction box!
    for dy_off, dz_off in [(+0.014, +0.004), (-0.014, -0.004)]:
        hv_parts.append(tube_along_points(
            f"_tmp_hv_main_{dy_off:.3f}",
            [
                (bx - 0.05, +0.205, bz - 0.025 + dz_off),
                (bx - 0.14, +0.215 + dy_off, 0.395),
                (bx - 0.25, +0.145 + dy_off, 0.340),
                (+0.78, +0.045 + dy_off, 0.326 + dz_off),
                (+0.20, +0.042 + dy_off, 0.312 + dz_off),
                (-0.42, +0.045 + dy_off, 0.320 + dz_off),
                (-0.62, +0.115 + dy_off, 0.415),
                (-0.74, +0.115 + dy_off, 0.555),
                (-0.82, +0.095 + dy_off, 0.585),
            ],
            0.0105,
            mats["hv_orange"],
            parent=None,
            sides=12,
            subdiv=4,
        ))

    # Branch 1: Junction box -> Main Pulse Inverter -> 3-phase orange leads into PDK electric motor!
    hv_parts.append(tube_along_points(
        "_tmp_hv_j_to_inv",
        [(-0.92, +0.04, 0.59), (-0.98, -0.02, 0.61), (-1.04, -0.05, 0.62)],
        0.011,
        mats["hv_orange"],
        parent=None,
        sides=10,
        subdiv=3,
    ))
    # 3 iconic orange 3-phase cables curving into upper-left side of PDK bellhousing (`Hybrid transmission and electric motor.jpg`!)
    for idx, (dx_p, dy_p) in enumerate([(-0.028, 0.0), (0.0, 0.016), (0.028, 0.030)]):
        hv_parts.append(tube_along_points(
            f"_tmp_hv_pdk3ph_{idx}",
            [
                (-1.08 + dx_p, -0.02 + dy_p, 0.59),
                (-1.02 + dx_p, +0.10 + dy_p, 0.54),
                (-0.98 + dx_p, +0.165, 0.465 + idx * 0.014),
                (-1.04 + dx_p, +0.155, 0.425 + idx * 0.010),
            ],
            0.0085,
            mats["hv_orange"],
            parent=None,
            sides=10,
            subdiv=3,
        ))

    # Branch 2: Clean inboard HV distribution runs terminating at rear bulkhead quick-disconnect sockets (|Y| <= 0.32 m — ZERO subframe clipping & ZERO floating ends when engine explodes!)
    hv_parts.append(tube_along_points(
        "_tmp_hv_eturbo_bus_l",
        [(-1.12, +0.22, 0.56), (-1.24, +0.28, 0.54), (-1.34, +0.26, 0.51)],
        0.0085,
        mats["hv_orange"],
        parent=None,
        sides=10,
        subdiv=3,
    ))
    hv_parts.append(round_box("_tmp_hv_sock_l", (-1.35, +0.26, 0.51), (0.036, 0.034, 0.032), mats["hv_orange"], parent=None, bevel=0.005))
    hv_parts.append(tube_along_points(
        "_tmp_hv_eturbo_bus_r",
        [(-1.26, -0.22, 0.59), (-1.31, -0.26, 0.55), (-1.35, -0.26, 0.51)],
        0.0085,
        mats["hv_orange"],
        parent=None,
        sides=10,
        subdiv=3,
    ))
    hv_parts.append(round_box("_tmp_hv_sock_r", (-1.35, -0.26, 0.51), (0.036, 0.034, 0.032), mats["hv_orange"], parent=None, bevel=0.005))
    # Branch 3: HV feed to front-of-PDK electric A/C compressor (left side, visible in Rolling chassis view 1!)
    hv_parts.append(tube_along_points(
        "_tmp_hv_ac_comp",
        [(-0.78, +0.14, 0.55), (-0.70, +0.26, 0.42), (-0.64, +0.28, 0.30)],
        0.0075,
        mats["hv_orange"],
        parent=None,
        sides=10,
        subdiv=3,
    ))
    # Small silver electric 400V A/C compressor pod on left side of PDK (clearly visible in Rolling chassis view 1!)
    hv_parts.append(ellipse_case(
        "_tmp_ac_comp_pod",
        [(-0.74, +0.29, 0.29, 0.050, 0.048), (-0.56, +0.29, 0.29, 0.048, 0.046)],
        mats["cast_alu"],
        parent=None,
        axis="x",
        steps=20,
    ))
    join_objects("TSC_HV_Cable_Harness", hv_parts, parent=parent)

    # 4) Underbody black twin coolant/brake pipe lines running cleanly along left sill into rear aluminum coolant manifold block!
    line_parts: list[bpy.types.Object] = []
    for dy_l in (0.50, 0.53):
        line_parts.append(tube_along_points(
            f"_tmp_cool_line_{dy_l:.2f}",
            [
                (+1.20, dy_l - 0.14, 0.205),
                (+0.72, dy_l, 0.165),
                ( 0.00, dy_l, 0.162),
                (-0.72, dy_l, 0.168),
                (-0.98, dy_l - 0.12, 0.232),
            ],
            0.0075,
            mats["rubber_hose"],
            parent=None,
            sides=8,
            subdiv=3,
        ))
    # Bolted aluminum coolant distribution manifold terminating lines cleanly on left rear subframe rail (no cut-off hose!)
    line_parts.append(round_box("_tmp_cool_manif_r", (-1.00, 0.395, 0.235), (0.068, 0.062, 0.042), mats["cast_alu"], parent=None, bevel=0.006))
    line_parts.append(round_box("_tmp_cool_manif_f", (+1.21, 0.375, 0.210), (0.064, 0.056, 0.038), mats["cast_alu"], parent=None, bevel=0.006))
    join_objects("TSC_Chassis_CoolantLines", line_parts, parent=parent)


def build_chassis_and_hv(
    rig_root: bpy.types.Object,
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
) -> bpy.types.Object:
    """Build `Pivot_Drivetrain_Chassis` with monocoque floorpan, undertray, subframes, AWD PTM, and 400V HV system."""
    from .common import make_empty
    p_chassis = make_empty("Pivot_Drivetrain_Chassis", (0.0, 0.0, 0.0), parent=rig_root)

    _build_undertray_and_floorpan(cfg, mats, p_chassis)
    _build_frunk_fuel_and_radiators(cfg, mats, p_chassis)
    _build_subframes_and_awd_ptm(cfg, mats, p_chassis)
    _build_thybrid_400v_system(cfg, mats, p_chassis)
    return p_chassis
