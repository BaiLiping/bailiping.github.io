"""Main entrypoint for building all 992.2 Porsche 911 Turbo S Cabriolet mechanicals in Blender.

Contract (`blender/exterior/contract.md` & `web/rig_contract.md`):
- Entrypoint: `build(rig_root: bpy.types.Object, cfg: dict | None = None) -> dict[str, bpy.types.Object]`
- Builds all mechanicals in real-world meters (Z-up: +X fwd, +Y left, +Z up; X=0 mid-axle, Z=0 ground),
  parented cleanly under `rig_root`, returning a dict mapping every created `Pivot_*` name to its Blender Empty.
- Automatically accepts either uppercase keys from `exterior.config.as_shared_dict()` or lowercase keys.
"""

from __future__ import annotations

from typing import Any

import bpy

from .chassis import build_chassis_and_hv
from .common import create_material_library
from .powertrain import build_exhaust_system, build_flat6_engine, build_hybrid_pdk
from .suspension import build_suspension_and_calipers
from .wheels import build_wheels_and_rotors


DEFAULT_CFG: dict[str, Any] = {
    # Official 992.2 Turbo S Cabriolet (MY T 10/2025 EU PDF) dimensions in meters
    "wheelbase": 2.450,
    "x_front_axle": +1.2250,
    "x_rear_axle": -1.2250,
    "track_front": 1.583,
    "track_rear": 1.588,
    # Static loaded rolling radius == z_hub so circular spinning tires sit tangent to Z=0.000!
    "z_hub_f": 0.338,
    "z_hub_r": 0.358,
    "r_tire_f": 0.338,
    "r_tire_r": 0.358,
    "w_tire_f": 0.258,         # 255/35 ZR20 mounted on 9.5J
    "w_tire_r": 0.328,         # 325/30 ZR21 mounted on 12.0J
    "r_rim_bead_f": 0.2540,    # 20" nominal bead diameter = 508.0 mm
    "r_rim_bead_r": 0.2667,    # 21" nominal bead diameter = 533.4 mm
    # PCCB carbon-ceramic brakes
    "rotor_dia_f": 0.420,      # 420 mm front
    "rotor_thick_f": 0.040,    # 40 mm thick
    "rotor_dia_r": 0.410,      # 410 mm rear
    "rotor_thick_r": 0.032,    # 32 mm thick
    # Shared chassis & exhaust interfaces with exterior/config.py
    "z_underbody": 0.125,
    "exhaust_x": -2.195,
    "exhaust_y": 0.515,
    "exhaust_z": 0.298,
}


def _normalize_cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    """Merge defaults with either exterior.config.as_shared_dict() uppercase keys or lowercase overrides."""
    merged = dict(DEFAULT_CFG)
    if not cfg:
        return merged

    # Map uppercase exterior/config.py keys if supplied
    key_map = {
        "WHEELBASE": "wheelbase",
        "X_FRONT_AXLE": "x_front_axle",
        "X_REAR_AXLE": "x_rear_axle",
        "TRACK_FRONT": "track_front",
        "TRACK_REAR": "track_rear",
        "Z_WHEEL_FRONT": "z_hub_f",
        "Z_WHEEL_REAR": "z_hub_r",
        "TIRE_FRONT_WIDTH": "w_tire_f",
        "TIRE_REAR_WIDTH": "w_tire_r",
        "Z_UNDERBODY": "z_underbody",
        "EXHAUST_CUTOUT_X": "exhaust_x",
        "EXHAUST_CUTOUT_Y": "exhaust_y",
        "EXHAUST_CUTOUT_Z": "exhaust_z",
    }
    for src_k, dst_k in key_map.items():
        if src_k in cfg:
            merged[dst_k] = float(cfg[src_k])

    if "RIM_FRONT_DIAM" in cfg:
        merged["r_rim_bead_f"] = 0.5 * float(cfg["RIM_FRONT_DIAM"])
    if "RIM_REAR_DIAM" in cfg:
        merged["r_rim_bead_r"] = 0.5 * float(cfg["RIM_REAR_DIAM"])
    if "ROTOR_FRONT_R" in cfg:
        merged["rotor_dia_f"] = 2.0 * float(cfg["ROTOR_FRONT_R"])
    if "ROTOR_REAR_R" in cfg:
        merged["rotor_dia_r"] = 2.0 * float(cfg["ROTOR_REAR_R"])

    # Keep spinning circular tire tangent to Z=0.000 (use static loaded radius == z_hub unless explicitly overridden)
    merged["r_tire_f"] = merged["z_hub_f"]
    merged["r_tire_r"] = merged["z_hub_r"]

    # Explicit lowercase overrides always take highest precedence
    for k, v in cfg.items():
        if k in merged:
            merged[k] = v

    return merged


def build(
    rig_root: bpy.types.Object,
    cfg: dict[str, Any] | None = None,
) -> dict[str, bpy.types.Object]:
    """Build all mechanicals assemblies under `rig_root` and return mapping of Pivot_* empties."""
    c = _normalize_cfg(cfg)
    mats = create_material_library()

    pivots: dict[str, bpy.types.Object] = {}

    # 1. Fixed rolling chassis tub, subframes, AWD front diff, propshaft & 400V T-Hybrid HV architecture
    p_chassis = build_chassis_and_hv(rig_root, c, mats)
    pivots[p_chassis.name] = p_chassis

    # 2. CDU.50 8-speed hybrid PDK transaxle (removable PDK_Case_* over exposed 60 kW PMSM + 8-speed gear train)
    build_hybrid_pdk(p_chassis, c, mats)

    # 3. Four corners: Pivot_Corner_* -> Pivot_WheelSpin_* (10-fold Y-spoke Turbonite wheels, P Zero R, PCCB rotors)
    wheel_pivots = build_wheels_and_rotors(rig_root, c, mats)
    pivots.update(wheel_pivots)

    # 4. Yellow PCCB calipers (10-piston F trailing / 4-piston R leading), MacPherson F & 5-link R suspension, steering, ehPDCC, half-shafts
    build_suspension_and_calipers(pivots, c, mats)

    # 5. 3.6L 9A3 T-Hybrid twin-eTurbo flat-6 boxer engine, top intercoolers & Cabriolet twin-fan service bay
    p_engine = build_flat6_engine(rig_root, c, mats)
    pivots[p_engine.name] = p_engine

    # 6. Titanium valved sport exhaust system (headers, heat-shielded GPFs, transverse silencer, twin inner tailpipes)
    p_exhaust = build_exhaust_system(rig_root, c, mats)
    pivots[p_exhaust.name] = p_exhaust

    return pivots
