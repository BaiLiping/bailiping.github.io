"""992.2 Porsche 911 Turbo S Cabriolet — 3.6L 9A3 T-Hybrid Twin-eTurbo Flat-6, CDU.50 8-Speed Hybrid PDK & Titanium Exhaust.

Faithfully modeled from official Porsche AG 6K illustrations & real 2026 Cabriolet photos:
- `Engine and exhaust - rear view.jpg` (323524) & `three-quarter view.jpg` (323525)
- `Electric turbocharger cutaway.jpg` (323523)
- `Hybrid transmission and electric motor.jpg` (323520) + 992 PDK internal gear-train cutaways
- `Cabriolet - engine bay fans from above.jpg` (twin honeycomb cooling fans + central `911` service bay)
- `Factory cutaway - rear engine compartment.jpg` (323527) & `Exhaust on car - underside overview.jpg`

Rig & Exploded View Hierarchy (`web/rig_contract.md`):
1. Under `Pivot_Drivetrain_Chassis`:
   - `TSC_PDK_Case_Main`, `TSC_PDK_Case_Bellhousing`, `TSC_PDK_Case_OilPan`: removable/X-ray outer castings
     (viewer offsets `PDK_Case_*` by `(-22, 14, 13)` in exploded view & makes translucent in X-ray!).
   - Internal `pdkInternal=True` assemblies exposed when casing lifts:
     `TSC_PDK_EMotor_Stator`, `TSC_PDK_EMotor_Windings`, `TSC_PDK_EMotor_Rotor` (60 kW Ø286×55 mm PMSM),
     `TSC_PDK_Clutch_Pack`, `TSC_PDK_Diff_RingGear`, `TSC_PDK_Shaft_Train`, `TSC_PDK_Gear_Set` (8-speed helical stack).
2. Under `Pivot_Flat6_Engine`:
   - `TSC_Eng_Crankcase`, `TSC_Eng_DrySump` (hex-ribbed black composite oil pan), `TSC_Eng_Cylinder_L/R`,
     `TSC_Eng_CylHead_L/R`, `TSC_Eng_ValveCover_L/R`, `TSC_Eng_RearConsole` (4-bolt aluminum mount beam)
   - `TSC_Eng_eTurbo_L`, `TSC_Eng_eTurbo_R` (twin electric exhaust turbochargers: Ø73 mm compressor + impeller,
     integrated emerald-green electric motor housing, Ø65 mm turbine, orange HV plug, corrugated intake snorkels)
   - `TSC_Eng_Throttle_L/R`, `TSC_Eng_FuelRail_L/R`, `TSC_Eng_ChargePipe_L/R` (lifted mid-level in exploded view)
   - `TSC_Eng_Intercooler_L/R`, `TSC_Eng_IntakePlenum_FanShroud` (twin black top intercoolers + Cabriolet
     twin honeycomb cooling fans & central `911` emblem beneath rear decklid — lifts +23 in exploded view!).
3. Under `Pivot_Exhaust_System`:
   - `TSC_Exh_Header_L/R` (3-into-1 tubular headers feeding twin eTurbos)
   - `TSC_Exh_Cat_L/R` (bulbous heat-shielded outboard GPF/catalytic converter pods + electric valve actuators)
   - `TSC_Exh_Silencer_Main` (contoured stamped-rib transverse titanium muffler — steps -17 aft in exploded view)
   - `TSC_Exhaust_Tip_L/R` (paired dark circular inner tailpipes aligned flush inside exterior figure-8 bezels).
"""

from __future__ import annotations

import math
from typing import Any

import bpy
import numpy as np
from mathutils import Matrix, Vector

from .common import (
    bolt_array,
    ellipse_case,
    finalize_mesh,
    gear_wheel,
    join_objects,
    loft_sections,
    make_empty,
    revolve_profile,
    round_box,
    sculpted_box_loft,
    text_to_mesh,
    tube_along_points,
)


# ---------------------------------------------------------------------------
# 1. CDU.50 8-Speed Hybrid PDK Transaxle + 60 kW PMSM Electric Motor
#    (Parented to Pivot_Drivetrain_Chassis)
# ---------------------------------------------------------------------------

def build_hybrid_pdk(
    chassis_pivot: bpy.types.Object,
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
) -> None:
    """Build CDU.50 8-speed hybrid PDK outer cases (`PDK_Case_*`) over full internal gear train + 60 kW e-motor."""
    x_r = cfg["x_rear_axle"]  # -1.225 m (crown wheel / rear axle centerline!)
    z_axis = 0.345            # Main transmission input shaft axis height

    # --- A. Outer Cast Aluminum Housings (`PDK_Case_*`: lifted off internals in exploded view & X-ray!) ---
    # 1) Main ribbed transaxle casting (`X = -1.16` forward to `-0.52`, tapering cleanly forward like 323520!)
    case_stations = [
        (-1.26, 0.0, z_axis, 0.205, 0.195),  # Bellhousing rear flange
        (-1.18, 0.0, z_axis, 0.215, 0.190),  # Diff & e-motor bay
        (-1.06, 0.0, z_axis, 0.192, 0.168),
        (-0.92, 0.0, z_axis, 0.168, 0.150),
        (-0.78, 0.0, z_axis, 0.148, 0.136),
        (-0.64, 0.0, z_axis, 0.126, 0.118),
        (-0.54, 0.0, z_axis, 0.095, 0.092),
        (-0.50, 0.0, z_axis, 0.068, 0.068),  # Front AWD propshaft nose
    ]
    main_parts: list[bpy.types.Object] = []
    main_parts.append(ellipse_case("_tmp_pdk_shell", case_stations, mats["cast_alu"], parent=None, axis="x", steps=36))

    # External circumferential structural casting ribs (signature Porsche PDK cast look in 323520!)
    for xx, _, zz, ry, rz in case_stations[1:-2]:
        main_parts.append(ellipse_case(
            f"_tmp_pdk_rib_{xx:.2f}",
            [
                (xx - 0.008, 0.0, zz, ry + 0.002, rz + 0.002),
                (xx - 0.004, 0.0, zz, ry + 0.011, rz + 0.011),
                (xx + 0.004, 0.0, zz, ry + 0.011, rz + 0.011),
                (xx + 0.008, 0.0, zz, ry + 0.002, rz + 0.002),
            ],
            mats["machined_alu"],
            parent=None,
            axis="x",
            steps=32,
        ))
    # Longitudinal stiffening webs along the tapered PDK casting
    for k in range(8):
        ang = 2.0 * math.pi * k / 8.0 + math.pi / 8.0
        pts = [(xx, (ry + 0.004) * math.cos(ang), zz + (rz + 0.004) * math.sin(ang)) for xx, _, zz, ry, rz in case_stations[1:-1]]
        main_parts.append(tube_along_points(f"_tmp_pdk_lweb_{k}", pts, 0.006, mats["cast_alu"], parent=None, sides=8, subdiv=2))

    # Left & right axle output bosses at rear axle centerline (X = x_r)
    for side in (-1.0, 1.0):
        main_parts.append(ellipse_case(
            f"_tmp_pdk_axboss_{int(side)}",
            [
                (side * 0.145, x_r, 0.340, 0.068, 0.068),
                (side * 0.185, x_r, 0.340, 0.060, 0.060),
            ],
            mats["cast_alu"],
            parent=None,
            axis="y",
            steps=24,
        ))
    # Black 3-phase HV terminal connector plate on upper-left PDK flank (matching 323520!)
    main_parts.append(round_box("_tmp_pdk_hvplate", (-1.04, +0.165, z_axis + 0.095), (0.115, 0.032, 0.072), mats["engine_plastic"], parent=None, bevel=0.006, rot_euler=(math.radians(-28), 0.0, 0.0)))
    # Serpentine external oil cooling channel boss on side of PDK case (323520 detail!)
    main_parts.append(tube_along_points(
        "_tmp_pdk_oilchan",
        [(-0.98, +0.175, z_axis + 0.03), (-0.90, +0.168, z_axis + 0.05), (-0.86, +0.162, z_axis - 0.02), (-0.76, +0.148, z_axis - 0.03)],
        0.011,
        mats["machined_alu"],
        parent=None,
        sides=10,
        subdiv=3,
    ))
    # Cast webs, end bosses and the three orange phase leads visible on the detached PDK.
    for sign in (-1,1):
        for j in range(4):
            x=-1.15+.125*j
            r=.193-.020*j
            main_parts.append(tube_along_points("_casting_web",[(x,sign*(r-.038),.445),(x+.047,sign*(r+.002),.365),(x+.099,sign*(r-.014),.292)],.005,mats["cast_alu"],sides=7,subdiv=2))
            main_parts.append(ellipse_case("_cast_boss",[(sign*(r-.009),x,.338,.017,.017),(sign*(r+.012),x,.338,.017,.017)],mats["machined_alu"],axis="y",steps=14))
    join_objects("TSC_PDK_Case_Main", main_parts, parent=chassis_pivot)
    cables=[]
    for i in range(3):
        shift=i*.026
        cables.append(tube_along_points("_phase_lead",[(-1.166, .184, .398+shift),(-1.19,.189,.428+shift),
                        (-1.255,.169,.47+shift),(-1.302,.118,.497+shift*.36),(-1.32,.075,.486+shift*.30)],.010,
                        mats["hv_orange"],sides=12,subdiv=5))
    join_objects("TSC_PDK_Case_PhaseLeads",cables,parent=chassis_pivot)

    # 2) Open-Mouth Cast Aluminum Bellhousing Ring (`X = -1.36 .. -1.24`, houses 60 kW PMSM electric motor — hollow!)
    bh_parts = [
        revolve_profile(
            "_tmp_pdk_bh",
            [
                (0.185, -1.355), (0.214, -1.355), (0.222, -1.325), (0.216, -1.245),
                (0.194, -1.245), (0.192, -1.320), (0.185, -1.335),
            ],
            mats["cast_alu"],
            parent=None,
            axis="x",
            center=(0.0, 0.0, z_axis),
            steps=40,
            closed_profile=True,
            smooth=True,
        ),
        bolt_array(
            "_tmp_pdk_bh_bolts",
            [(-1.355, 0.202 * math.cos(t), z_axis + 0.198 * math.sin(t)) for t in np.linspace(0, 2 * math.pi, 12, endpoint=False)],
            radius=0.008,
            height=-0.009,
            material=mats["stainless"],
            parent=None,
            axis="x",
        ),
    ]
    join_objects("TSC_PDK_Case_Bellhousing", bh_parts, parent=chassis_pivot)

    # 3) Bottom PDK Transmission Oil Sump Pan (`Z ≈ 0.18..0.22`)
    round_box("TSC_PDK_Case_OilPan", (-0.88, 0.0, 0.195), (0.50, 0.27, 0.055), mats["engine_plastic"], parent=chassis_pivot, bevel=0.012)

    # --- B. Exposed Internal Hybrid PDK Mechanicals (pdkInternal=True -> hidden assembled, revealed exploded/X-ray!) ---
    # 1) 60 kW / 188 Nm PMSM Electric Traction Motor (Ø286 × 55 mm — faithful to factory illustration 323520!)
    em_x0, em_x1 = -1.305, -1.245
    r_stator_out = 0.143  # Ø286 mm exact!
    r_stator_in = 0.106
    # Segmented laminated electrical steel stator core with 48 crisp axial lamination teeth & dark air-gap grooves!
    stator_sec = []
    n_slots = 48
    for xx in (em_x0, em_x1):
        ring = []
        for k in range(n_slots * 2):
            ang = 2.0 * math.pi * k / (n_slots * 2)
            rr = r_stator_out if k % 2 == 0 else r_stator_out - 0.007
            ring.append((xx, rr * math.cos(ang), z_axis + rr * math.sin(ang)))
        stator_sec.append(ring)
    stator_parts = [
        loft_sections("_tmp_em_stator", stator_sec, mats["machined_alu"], parent=None, cap_ends=True, smooth=False),
        # Lamination stack dark banding rings (matches 323520's bright stacked electrical steel core!)
        revolve_profile(
            "_tmp_em_outer_band1",
            [(r_stator_out - 0.001, em_x0 + 0.008), (r_stator_out + 0.003, em_x0 + 0.008), (r_stator_out + 0.003, em_x0 + 0.014), (r_stator_out - 0.001, em_x0 + 0.014)],
            mats["gunmetal"], parent=None, axis="x", center=(0.0, 0.0, z_axis), steps=48, closed_profile=True, smooth=False,
        ),
        revolve_profile(
            "_tmp_em_outer_band2",
            [(r_stator_out - 0.001, em_x1 - 0.014), (r_stator_out + 0.003, em_x1 - 0.014), (r_stator_out + 0.003, em_x1 - 0.008), (r_stator_out - 0.001, em_x1 - 0.008)],
            mats["gunmetal"], parent=None, axis="x", center=(0.0, 0.0, z_axis), steps=48, closed_profile=True, smooth=False,
        ),
        # Stator mounting flange tabs (3 radial ears matching 323520)
        *[
            round_box(
                f"_tmp_em_ear_{ei}",
                (0.5 * (em_x0 + em_x1), (r_stator_out + 0.012) * math.cos(ea), z_axis + (r_stator_out + 0.012) * math.sin(ea)),
                (0.018, 0.026, 0.026),
                mats["cast_alu"],
                parent=None,
                bevel=0.003,
                rot_euler=(ea, 0.0, 0.0),
            )
            for ei, ea in enumerate([0.0, 2.0 * math.pi / 3.0, 4.0 * math.pi / 3.0])
        ],
    ]
    join_objects("TSC_PDK_EMotor_Stator", stator_parts, parent=chassis_pivot, pdk_internal=True)

    # 36 distinct segmented enameled COPPER hairpin end-winding coils on both faces (zero blobby orange ring — matches 323520!)
    wind_parts: list[bpy.types.Object] = []
    rc = 0.5 * (r_stator_in + r_stator_out) - 0.002
    for x_end, dir_s in [(em_x0 - 0.009, -1.0), (em_x1 + 0.009, +1.0)]:
        # Dark insulating slot-liner ring behind the copper hairpins
        wind_parts.append(revolve_profile(
            f"_tmp_em_insul_{x_end:.3f}",
            [(r_stator_in + 0.003, x_end - dir_s * 0.006), (r_stator_out - 0.010, x_end - dir_s * 0.006),
             (r_stator_out - 0.010, x_end + dir_s * 0.003), (r_stator_in + 0.003, x_end + dir_s * 0.003)],
            mats["engine_plastic"],
            parent=None,
            axis="x",
            center=(0.0, 0.0, z_axis),
            steps=48,
            closed_profile=True,
            smooth=False,
        ))
        # Individual crisp angled copper hairpin bars around circumference!
        n_bars = 36
        for k in range(n_bars):
            ang = 2.0 * math.pi * k / n_bars
            wind_parts.append(round_box(
                f"_tmp_em_hp_{x_end:.2f}_{k}",
                (x_end + dir_s * 0.004, rc * math.cos(ang), z_axis + rc * math.sin(ang)),
                (0.020, 0.026, 0.0095),
                mats["copper"],
                parent=None,
                bevel=0.0018,
                rot_euler=(ang + 0.22, 0.0, 0.0),
            ))
    # 3-phase black terminal block mounted on top-left of stator ring (`323520` detail!)
    wind_parts.append(round_box("_tmp_em_termblk", (em_x1 + 0.016, +0.115, z_axis + 0.092), (0.028, 0.062, 0.036), mats["engine_plastic"], parent=None, bevel=0.004, rot_euler=(math.radians(38), 0.0, 0.0)))
    join_objects("TSC_PDK_EMotor_Windings", wind_parts, parent=chassis_pivot, pdk_internal=True)

    # Detailed 6-spoke machined aluminum internal PMSM rotor carrier + splined input hub (`323520`!)
    rot_parts = [
        revolve_profile(
            "_tmp_em_rotor_rim",
            [(r_stator_in - 0.020, em_x0 + 0.004), (r_stator_in - 0.003, em_x0 + 0.004),
             (r_stator_in - 0.003, em_x1 - 0.004), (r_stator_in - 0.020, em_x1 - 0.004)],
            mats["gear_steel"],
            parent=None,
            axis="x",
            center=(0.0, 0.0, z_axis),
            steps=40,
            closed_profile=True,
            smooth=True,
        ),
        revolve_profile(
            "_tmp_em_rotor_hub",
            [(0.026, em_x0 - 0.016), (0.046, em_x0 - 0.016), (0.046, em_x1 + 0.010), (0.026, em_x1 + 0.010)],
            mats["machined_alu"],
            parent=None,
            axis="x",
            center=(0.0, 0.0, z_axis),
            steps=32,
            closed_profile=True,
            smooth=True,
        ),
        *[
            round_box(
                f"_tmp_em_spoke_{sk}",
                (0.5 * (em_x0 + em_x1), 0.066 * math.cos(sk * math.pi / 3.0), z_axis + 0.066 * math.sin(sk * math.pi / 3.0)),
                (0.022, 0.052, 0.016),
                mats["machined_alu"],
                parent=None,
                bevel=0.003,
                rot_euler=(sk * math.pi / 3.0, 0.0, 0.0),
            )
            for sk in range(6)
        ],
        gear_wheel("_tmp_em_spline", (em_x0 - 0.016, 0.0, z_axis), 0.026, 0.032, 18, mats["stainless"], parent=None, axis="x", helix_twist=0.0, bore_r=0.012),
    ]
    join_objects("TSC_PDK_EMotor_Rotor", rot_parts, parent=chassis_pivot, pdk_internal=True)

    # 2) Dual Wet Clutch Pack (`X = -1.22 .. -1.11`, concentric K1/K2 multi-plate drum ahead of e-motor!)
    cl_parts = [
        revolve_profile(
            "_tmp_pdk_clutch_drum",
            [
                (0.030, -1.225), (0.122, -1.225), (0.122, -1.115),
                (0.110, -1.115), (0.110, -1.210), (0.030, -1.210),
            ],
            mats["gear_steel"],
            parent=None,
            axis="x",
            center=(0.0, 0.0, z_axis),
            steps=40,
            closed_profile=True,
            smooth=True,
        ),
        # Inner friction plate stack alternating dark/steel
        revolve_profile(
            "_tmp_pdk_clutch_plates",
            [(0.048, -1.208), (0.106, -1.208), (0.106, -1.125), (0.048, -1.125)],
            mats["gunmetal"],
            parent=None,
            axis="x",
            center=(0.0, 0.0, z_axis),
            steps=36,
            closed_profile=True,
            smooth=True,
        ),
    ]
    join_objects("TSC_PDK_Clutch_Pack", cl_parts, parent=chassis_pivot, pdk_internal=True)

    # 3) PTV Plus Rear Differential & Hypoid Crown Wheel (aligned EXACTLY at rear axle X = -1.225!)
    #    Matches `2018 Carrera PDK - exposed gear train and crown wheel.png`!
    diff_parts = [
        # Large helical/bevel crown ring gear on Y axis (left of centerline, driving rear axle!)
        gear_wheel("_tmp_pdk_crown", (x_r, +0.065, 0.340), 0.112, 0.034, 38, mats["gear_steel"], parent=None, axis="y", helix_twist=0.14, bore_r=0.055),
        # Slotted cast aluminum PTV Plus locking differential carrier
        revolve_profile(
            "_tmp_pdk_diff_carrier",
            [(0.032, -0.095), (0.090, -0.095), (0.095, -0.020), (0.088, +0.050), (0.048, +0.095), (0.032, +0.095)],
            mats["machined_alu"],
            parent=None,
            axis="y",
            center=(x_r, 0.0, 0.340),
            steps=32,
            closed_profile=True,
            smooth=True,
        ),
        # Pinion bevel gear meshing with crown wheel
        gear_wheel("_tmp_pdk_pinion", (x_r + 0.118, +0.065, 0.285), 0.034, 0.042, 14, mats["gear_steel"], parent=None, axis="x", helix_twist=0.16, bore_r=0.015),
    ]
    join_objects("TSC_PDK_Diff_RingGear", diff_parts, parent=chassis_pivot, pdk_internal=True)

    # 4) Multi-Shaft 8-Speed Helical Gear Train (`X = -1.08 .. -0.58`, matching `2018 Carrera PDK - exposed gear train`!)
    # Shafts: Input Shaft 1/2 (Y=0.0, Z=z_axis+0.048), Pinion/Main Shaft 1 (Y=+0.065, Z=z_axis-0.052),
    #         Main Shaft 2 (Y=-0.068, Z=z_axis-0.042), Front-axle AWD output shaft (Y=0.0, Z=z_axis-0.068)
    shaft_parts = [
        ellipse_case("_tmp_sh_in",  [(-1.22, 0.0, z_axis + 0.045, 0.020, 0.020), (-0.60, 0.0, z_axis + 0.045, 0.018, 0.018)], mats["stainless"], parent=None, axis="x", steps=18),
        ellipse_case("_tmp_sh_m1",  [(-1.14, +0.065, z_axis - 0.050, 0.018, 0.018), (-0.58, +0.065, z_axis - 0.050, 0.017, 0.017)], mats["stainless"], parent=None, axis="x", steps=18),
        ellipse_case("_tmp_sh_m2",  [(-1.08, -0.065, z_axis - 0.045, 0.017, 0.017), (-0.60, -0.065, z_axis - 0.045, 0.016, 0.016)], mats["stainless"], parent=None, axis="x", steps=18),
        ellipse_case("_tmp_sh_awd", [(-0.72, 0.0, z_axis - 0.068, 0.018, 0.018), (-0.48, 0.0, z_axis - 0.068, 0.022, 0.022)], mats["stainless"], parent=None, axis="x", steps=18),
    ]
    join_objects("TSC_PDK_Shaft_Train", shaft_parts, parent=chassis_pivot, pdk_internal=True)

    # 8 Helical Gear Pairs sized progressively along the official 992.2 Turbo S gear ratios (4.89 down to 0.61!)
    # Center distance between Input Shaft (0, +0.045) and Main Shaft 1/2 (±0.065, -0.048) is ~0.114 m -> r_in + r_out ≈ 0.112 m!
    gear_parts: list[bpy.types.Object] = []
    # (label, x_pos, shaft_y, shaft_z, r_in, r_out, teeth_in, teeth_out)
    gear_specs = [
        ("1st", -1.05, +0.065, z_axis - 0.050, 0.032, 0.080, 14, 34),
        ("2nd", -0.99, -0.065, z_axis - 0.045, 0.038, 0.074, 16, 32),
        ("3rd", -0.93, +0.065, z_axis - 0.050, 0.044, 0.068, 19, 29),
        ("4th", -0.87, -0.065, z_axis - 0.045, 0.050, 0.062, 22, 26),
        ("5th", -0.81, +0.065, z_axis - 0.050, 0.056, 0.056, 24, 24),
        ("6th", -0.75, -0.065, z_axis - 0.045, 0.061, 0.051, 26, 22),
        ("7th", -0.69, +0.065, z_axis - 0.050, 0.066, 0.046, 28, 20),
        ("8th", -0.63, -0.065, z_axis - 0.045, 0.070, 0.042, 30, 18),
    ]
    for gname, gx, sy, sz, r_i, r_o, ti, to in gear_specs:
        gear_parts.append(gear_wheel(f"_tmp_g_{gname}_in",  (gx, 0.0, z_axis + 0.045), r_i, 0.028, ti, mats["gear_steel"], parent=None, axis="x", helix_twist=+0.11, bore_r=0.018))
        gear_parts.append(gear_wheel(f"_tmp_g_{gname}_out", (gx, sy, sz),              r_o, 0.028, to, mats["gear_steel"], parent=None, axis="x", helix_twist=-0.11, bore_r=0.017))
    # Front-axle AWD summation drive gear at front nose of gearbox
    gear_parts.append(gear_wheel("_tmp_g_awd_sum", (-0.59, 0.0, z_axis - 0.068), 0.048, 0.026, 22, mats["gear_steel"], parent=None, axis="x", helix_twist=+0.08, bore_r=0.018))
    join_objects("TSC_PDK_Gear_Set", gear_parts, parent=chassis_pivot, pdk_internal=True)


# ---------------------------------------------------------------------------
# 2. 3.6L 9A3 T-Hybrid Twin-eTurbo Flat-6 Boxer Engine
#    (Parented to Pivot_Flat6_Engine)
# ---------------------------------------------------------------------------

def build_flat6_engine(
    rig_root: bpy.types.Object,
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
) -> bpy.types.Object:
    """Build 3.6L 9A3 T-Hybrid twin-eTurbo flat-6, top intercoolers & 2026 Cabriolet twin-fan service bay."""
    p_eng = make_empty("Pivot_Flat6_Engine", (0.0, 0.0, 0.0), parent=rig_root)

    # Engine sits aft of PDK bellhousing: X ∈ [-1.96, -1.35] m, centerline Z_crank = 0.345 m
    x_front = -1.355  # Meets PDK bellhousing flange
    x_rear = -1.915   # Rear face of crankcase / timing case (beltless 9A3 front/rear drive!)
    z_crank = 0.345

    # 1) Horizontally-Split Cast Aluminum Crankcase + Rear Engine Mount Cross-Console (`Engine and exhaust - rear view.jpg`!)
    cc_parts: list[bpy.types.Object] = []
    cc_parts.append(sculpted_box_loft(
        "_tmp_eng_cc_core",
        [
            (x_front,       0.0, z_crank + 0.01, 0.165, 0.135),
            (x_front - 0.12, 0.0, z_crank + 0.01, 0.185, 0.145),
            (x_rear + 0.10,  0.0, z_crank + 0.01, 0.185, 0.145),
            (x_rear,        0.0, z_crank + 0.01, 0.165, 0.135),
        ],
        mats["cast_alu"],
        parent=None,
        axis="x",
    ))
    # Rear timing/cam-chain covers spanning cleanly across both banks (iconic sculpted face in `rear view.jpg`!)
    cc_parts.append(sculpted_box_loft(
        "_tmp_eng_rearcover",
        [
            (x_rear + 0.06, 0.0, z_crank + 0.03, 0.415, 0.125),
            (x_rear - 0.01, 0.0, z_crank + 0.03, 0.405, 0.118),
            (x_rear - 0.04, 0.0, z_crank + 0.03, 0.370, 0.102),
        ],
        mats["cast_alu"],
        parent=None,
        axis="x",
    ))
    # Sculpted rear bright aluminum structural engine-mount cross-console with 4 big Torx bolts (`rear view.jpg`!)
    cc_parts.append(sculpted_box_loft(
        "_tmp_eng_console",
        [
            (x_rear - 0.035, 0.0, z_crank - 0.035, 0.385, 0.055),
            (x_rear - 0.075, 0.0, z_crank - 0.042, 0.370, 0.048),
            (x_rear - 0.095, 0.0, z_crank - 0.045, 0.145, 0.068),
        ],
        mats["machined_alu"],
        parent=None,
        axis="x",
    ))
    # 4 recessed bright stainless Torx mounting bolts on rear engine console
    cc_parts.append(bolt_array(
        "_tmp_eng_console_bolts",
        [
            (x_rear - 0.096, -0.042, z_crank - 0.018),
            (x_rear - 0.096, +0.042, z_crank - 0.018),
            (x_rear - 0.096, -0.048, z_crank - 0.072),
            (x_rear - 0.096, +0.048, z_crank - 0.072),
        ],
        radius=0.011,
        height=-0.010,
        material=mats["stainless"],
        parent=None,
        axis="x",
        sides=12,
    ))
    # VarioCam circular black phase actuator caps on rear timing cover left & right (`rear view.jpg`!)
    for side in (-1.0, 1.0):
        cc_parts.append(ellipse_case(
            f"_tmp_eng_variocam_{int(side)}",
            [(x_rear - 0.035, side * 0.285, z_crank + 0.065, 0.032, 0.032), (x_rear - 0.058, side * 0.285, z_crank + 0.065, 0.028, 0.028)],
            mats["engine_plastic"],
            parent=None,
            axis="x",
            steps=20,
        ))
    # Raised rear casting emblem "PORSCHE" above the cross-console (matches `rear view.jpg`!)
    rot_back = Matrix(((0.0, -1.0, 0.0), (0.0, 0.0, 1.0), (-1.0, 0.0, 0.0))).transposed()
    cc_parts.append(text_to_mesh(
        "_tmp_eng_porsche_cast",
        "PORSCHE",
        0.020,
        mats["machined_alu"],
        parent=None,
        extrude=0.002,
        location=(x_rear - 0.042, +0.075, z_crank + 0.025),
        rot_matrix=rot_back,
        spacing=1.18,
    ))
    # Rear flywheel / flexplate at forward face joining 60 kW PDK electric motor
    cc_parts.append(revolve_profile(
        "_tmp_eng_flywheel",
        [(0.035, x_front + 0.015), (0.145, x_front + 0.015), (0.145, x_front - 0.012), (0.035, x_front - 0.012)],
        mats["gunmetal"],
        parent=None,
        axis="x",
        center=(0.0, 0.0, z_crank),
        steps=36,
        closed_profile=True,
        smooth=True,
    ))
    join_objects("TSC_Eng_Crankcase", cc_parts, parent=p_eng)

    # 2) Signature Black Hex-Ribbed Composite Dry-Sump Oil Pan (`Exhaust on car - underside overview.jpg`!)
    sump_parts = [
        sculpted_box_loft(
            "_tmp_eng_sump_body",
            [
                (x_front - 0.05, 0.0, 0.198, 0.155, 0.026),
                (x_front - 0.14, 0.0, 0.194, 0.178, 0.030),
                (x_rear + 0.12,  0.0, 0.194, 0.175, 0.030),
                (x_rear + 0.04,  0.0, 0.198, 0.145, 0.024),
            ],
            mats["engine_plastic"],
            parent=None,
            axis="x",
        ),
    ]
    # Crisp structural bottom cooling/stiffening ribs on oil pan
    for k in range(5):
        yy = -0.11 + k * 0.055
        sump_parts.append(round_box(f"_tmp_sump_rib_{k}", (0.5 * (x_front + x_rear), yy, 0.166), (0.40, 0.010, 0.010), mats["engine_plastic"], parent=None, bevel=0.002))
    join_objects("TSC_Eng_DrySump", sump_parts, parent=p_eng)

    # 3) Horizontally Opposed Left & Right Cylinder Banks, DOHC Heads & Ribbed Black Cam Covers (3 cylinders per side!)
    for side, s_tag in [(+1.0, "L"), (-1.0, "R")]:
        bank_parts: list[bpy.types.Object] = []
        # Cast aluminum cylinder barrel block (3 opposing bores per bank, bore 97 mm!)
        bank_parts.append(sculpted_box_loft(
            f"_tmp_cyl_block_{s_tag}",
            [
                (side * 0.155, 0.5 * (x_front + x_rear), z_crank + 0.012, 0.255, 0.112),
                (side * 0.295, 0.5 * (x_front + x_rear), z_crank + 0.015, 0.260, 0.116),
            ],
            mats["cast_alu"],
            parent=None,
            axis="y",
        ))
        # Cast aluminum 4-valve DOHC cylinder head
        bank_parts.append(sculpted_box_loft(
            f"_tmp_cyl_head_{s_tag}",
            [
                (side * 0.290, 0.5 * (x_front + x_rear), z_crank + 0.018, 0.268, 0.122),
                (side * 0.395, 0.5 * (x_front + x_rear), z_crank + 0.020, 0.265, 0.118),
            ],
            mats["machined_alu"],
            parent=None,
            axis="y",
        ))
        # 3 Ignition coil packs + plug boots tucked into cylinder head side
        for c_idx in range(3):
            cx = x_front - 0.11 - c_idx * 0.155
            bank_parts.append(round_box(f"_tmp_coil_{s_tag}_{c_idx}", (cx, side * 0.405, z_crank + 0.025), (0.048, 0.042, 0.042), mats["engine_plastic"], parent=None, bevel=0.006))
        join_objects(f"TSC_Eng_CylinderHead_{s_tag}", bank_parts, parent=p_eng)

        # Ribbed black composite DOHC cam/valve cover (`rear view.jpg`!)
        vc_parts = [
            sculpted_box_loft(
                f"_tmp_vc_main_{s_tag}",
                [
                    (side * 0.390, 0.5 * (x_front + x_rear), z_crank + 0.020, 0.258, 0.112),
                    (side * 0.442, 0.5 * (x_front + x_rear), z_crank + 0.020, 0.242, 0.098),
                ],
                mats["engine_plastic"],
                parent=None,
                axis="y",
            ),
        ]
        # Waffle reinforcing ribs on valve cover outer face
        for r_i in range(4):
            rx = x_front - 0.12 - r_i * 0.115
            vc_parts.append(round_box(f"_tmp_vc_rib_{s_tag}_{r_i}", (rx, side * 0.442, z_crank + 0.020), (0.012, 0.014, 0.165), mats["engine_plastic"], parent=None, bevel=0.003))
        join_objects(f"TSC_Eng_ValveCover_{s_tag}", vc_parts, parent=p_eng)

    # 4) TWIN Electric Exhaust Turbochargers (`TSC_Eng_eTurbo_L/R`) — THE 992.2 Turbo S signature!
    #    Faithfully modeled from `Engine and exhaust - rear view.jpg` & `Electric turbocharger cutaway.jpg` (323523):
    #    Ø73 mm compressor inlet facing aft-outboard at lower corners, emerald-green center e-motor stator collar,
    #    Ø65 mm turbine snail, orange 400V connector plug, and black corrugated intake snorkel hoses!
    for side, s_tag in [(+1.0, "L"), (-1.0, "R")]:
        et_parts: list[bpy.types.Object] = []
        tx, ty, tz = x_rear - 0.035, side * 0.445, z_crank - 0.045  # Lower outer rear corners!

        # Compressor spiral volute facing rearward (-X) with open bell mouth showing CNC compressor wheel!
        vol_sec = []
        for ang in np.linspace(-0.2 * math.pi, 1.72 * math.pi, 40):
            phase = (ang + 0.2 * math.pi) / (1.92 * math.pi)
            rc = 0.046 + 0.016 * phase
            rt = 0.012 + 0.024 * phase
            vol_sec.append([
                (tx - 0.025 + rt * math.sin(b),
                 ty + side * (rc + rt * math.cos(b)) * math.cos(ang),
                 tz + (rc + rt * math.cos(b)) * math.sin(ang))
                for b in np.linspace(0, 2 * math.pi, 16, endpoint=False)
            ])
        et_parts.append(loft_sections(f"_tmp_et_comp_{s_tag}", vol_sec, mats["machined_alu"], parent=None, cap_ends=True, smooth=True))

        # Open compressor inlet bell ring + dark bore + CNC multi-blade impeller wheel (`rear view.jpg`!)
        et_parts.append(revolve_profile(
            f"_tmp_et_bell_{s_tag}",
            [(0.036, tx - 0.055), (0.048, tx - 0.055), (0.052, tx - 0.038), (0.046, tx - 0.015), (0.036, tx - 0.015)],
            mats["machined_alu"],
            parent=None,
            axis="x",
            center=(0.0, ty, tz),
            steps=32,
            closed_profile=True,
            smooth=True,
        ))
        # Compressor impeller hub + 10 angled silver blades visible right inside the mouth!
        et_parts.append(revolve_profile(
            f"_tmp_et_imp_hub_{s_tag}",
            [(0.001, tx - 0.048), (0.010, tx - 0.044), (0.016, tx - 0.022), (0.001, tx - 0.022)],
            mats["stainless"],
            parent=None,
            axis="x",
            center=(0.0, ty, tz),
            steps=18,
            closed_profile=True,
            smooth=True,
        ))
        for bk in range(10):
            ba = 2.0 * math.pi * bk / 10.0
            r_b = 0.024
            et_parts.append(round_box(
                f"_tmp_et_blade_{s_tag}_{bk}",
                (tx - 0.034, ty + r_b * math.cos(ba), tz + r_b * math.sin(ba)),
                (0.022, 0.020, 0.0022),
                mats["stainless"],
                parent=None,
                bevel=0.0004,
                rot_euler=(ba + 0.35, 0.30, 0.0),
            ))

        # Center integrated electric motor cartridge (signature emerald-green eTurbo motor band per cutaway 323523!)
        et_parts.append(ellipse_case(
            f"_tmp_et_motor_{s_tag}",
            [
                (tx - 0.008, ty, tz, 0.056, 0.056),
                (tx + 0.012, ty, tz, 0.060, 0.060),
                (tx + 0.072, ty, tz, 0.060, 0.060),
                (tx + 0.088, ty, tz, 0.054, 0.054),
            ],
            mats["cast_alu"],
            parent=None,
            axis="x",
            steps=28,
        ))
        et_parts.append(ellipse_case(
            f"_tmp_et_green_{s_tag}",
            [(tx + 0.022, ty, tz, 0.062, 0.062), (tx + 0.060, ty, tz, 0.062, 0.062)],
            mats["eturbo_green"],
            parent=None,
            axis="x",
            steps=28,
        ))
        # Orange 400V HV plug + engine-side HV pigtail harness traveling WITH Pivot_Flat6_Engine (zero cut wires when exploded!)
        et_parts.append(round_box(f"_tmp_et_hvplug_{s_tag}", (tx + 0.042, ty - side * 0.062, tz + 0.015), (0.036, 0.028, 0.026), mats["hv_orange"], parent=None, bevel=0.005))
        et_parts.append(tube_along_points(
            f"_tmp_et_hvpigtail_{s_tag}",
            [
                (tx + 0.045, ty - side * 0.072, tz + 0.018),
                (tx + 0.145, side * 0.365, tz + 0.075),
                (-1.52,      side * 0.315, 0.485),
                (-1.38,      side * 0.260, 0.510),
            ],
            0.0075,
            mats["hv_orange"],
            parent=None,
            sides=10,
            subdiv=3,
        ))
        et_parts.append(round_box(f"_tmp_et_hvcoupler_{s_tag}", (-1.37, side * 0.260, 0.510), (0.028, 0.028, 0.028), mats["hv_orange"], parent=None, bevel=0.004))

        # Hot-side turbine housing (forward of e-motor, heat-tinted Inconel alloy)
        et_parts.append(ellipse_case(
            f"_tmp_et_turb_{s_tag}",
            [
                (tx + 0.085, ty, tz, 0.058, 0.056),
                (tx + 0.115, ty, tz, 0.068, 0.064),
                (tx + 0.155, ty, tz, 0.064, 0.060),
                (tx + 0.175, ty, tz, 0.046, 0.046),
            ],
            mats["inconel"],
            parent=None,
            axis="x",
            steps=28,
        ))
        # Black corrugated air intake elbow curving up from compressor inlet (`rear view.jpg` & `cutaway.jpg`!)
        et_parts.append(tube_along_points(
            f"_tmp_et_snorkel_{s_tag}",
            [
                (tx + 0.005, ty + side * 0.045, tz + 0.055),
                (tx + 0.045, ty + side * 0.055, tz + 0.135),
                (tx + 0.095, ty + side * 0.015, tz + 0.205),
            ],
            [0.036, 0.040, 0.042],
            mats["engine_plastic"],
            parent=None,
            sides=18,
            subdiv=3,
        ))
        join_objects(f"TSC_Eng_eTurbo_{s_tag}", et_parts, parent=p_eng)

    # 5) Upper Engine Induction: Twin Electronic Throttle Bodies, Intake Manifolds, Fuel Rails & Charge Pipes
    #    (Matches `Eng_Throttle` / `Eng_FuelRail` / `Eng_ChargePipe` -> lifts mid-level in exploded view!)
    th_parts: list[bpy.types.Object] = []
    # Twin opposing aluminum throttle bodies with black stepper actuator pods sitting atop rear engine (`rear view.jpg`!)
    for side in (-1.0, 1.0):
        th_parts.append(ellipse_case(
            f"_tmp_tb_bore_{int(side)}",
            [
                (side * 0.065, -1.78, 0.565, 0.036, 0.036),
                (side * 0.145, -1.78, 0.565, 0.038, 0.038),
            ],
            mats["machined_alu"],
            parent=None,
            axis="y",
            steps=24,
        ))
        th_parts.append(round_box(f"_tmp_tb_motor_{int(side)}", (-1.80, side * 0.140, 0.550), (0.058, 0.042, 0.065), mats["engine_plastic"], parent=None, bevel=0.008))
        # Ribbed black composite intake manifold plenum per bank feeding 3 cylinder ports
        th_parts.append(sculpted_box_loft(
            f"_tmp_int_man_{int(side)}",
            [
                (x_front - 0.06, side * 0.255, 0.545, 0.078, 0.052),
                (x_rear + 0.14,  side * 0.255, 0.555, 0.082, 0.056),
            ],
            mats["engine_plastic"],
            parent=None,
            axis="x",
        ))
        for c_i in range(3):
            cx = x_front - 0.11 - c_i * 0.155
            th_parts.append(tube_along_points(
                f"_tmp_runner_{int(side)}_{c_i}",
                [(cx, side * 0.265, 0.525), (cx, side * 0.315, 0.475), (cx, side * 0.330, 0.435)],
                0.022,
                mats["engine_plastic"],
                parent=None,
                sides=12,
                subdiv=2,
            ))
    # Central cast aluminum crossover resonance bridge between left/right throttles (`rear view.jpg`!)
    th_parts.append(round_box("_tmp_tb_bridge", (-1.77, -0.02, 0.565), (0.095, 0.125, 0.072), mats["cast_alu"], parent=None, bevel=0.010))
    join_objects("TSC_Eng_Throttle_Intake", th_parts, parent=p_eng)

    # High-pressure direct-injection stainless fuel rails + wiring loom
    fr_parts: list[bpy.types.Object] = []
    for side in (-1.0, 1.0):
        fr_parts.append(tube_along_points(
            f"_tmp_frail_{int(side)}",
            [(x_front - 0.08, side * 0.29, 0.485), (x_rear + 0.10, side * 0.29, 0.485)],
            0.009,
            mats["stainless"],
            parent=None,
            sides=10,
            subdiv=1,
        ))
        # High-pressure fuel pump dome
        fr_parts.append(ellipse_case(
            f"_tmp_hpfp_{int(side)}",
            [(0.49, x_front - 0.12, side * 0.22, 0.024, 0.024), (0.55, x_front - 0.12, side * 0.22, 0.022, 0.022)],
            mats["machined_alu"],
            parent=None,
            axis="z",
            steps=16,
        ))
    # Black overhead main engine wiring harness duct arching across rear (`rear view.jpg`!)
    fr_parts.append(tube_along_points(
        "_tmp_eng_harness",
        [(-1.82, -0.35, 0.49), (-1.85, -0.18, 0.51), (-1.86, 0.0, 0.50), (-1.85, +0.18, 0.51), (-1.82, +0.35, 0.49)],
        0.014,
        mats["engine_plastic"],
        parent=None,
        sides=10,
        subdiv=3,
    ))
    join_objects("TSC_Eng_FuelRail_Harness", fr_parts, parent=p_eng)

    # Curved black silicone/composite charge pipes connecting twin eTurbos up to top intercoolers!
    cp_parts: list[bpy.types.Object] = []
    for side in (-1.0, 1.0):
        cp_parts.append(tube_along_points(
            f"_tmp_chpipe_{int(side)}",
            [
                (x_rear - 0.04, side * 0.47, z_crank + 0.02),
                (x_rear - 0.06, side * 0.50, 0.52),
                (x_rear + 0.02, side * 0.44, 0.65),
                (-1.78,         side * 0.34, 0.70),
            ],
            0.032,
            mats["rubber_hose"],
            parent=None,
            sides=16,
            subdiv=4,
        ))
        # Bright stainless worm-drive hose clamps on charge pipes
        for cx, cy, cz in [(x_rear - 0.05, side * 0.49, 0.46), (-1.80, side * 0.38, 0.68)]:
            cp_parts.append(ellipse_case(
                f"_tmp_clamp_{int(side)}_{cz:.2f}",
                [(cz - 0.008, cx, cy, 0.035, 0.035), (cz + 0.008, cx, cy, 0.035, 0.035)],
                mats["stainless"],
                parent=None,
                axis="z",
                steps=20,
            ))
    join_objects("TSC_Eng_ChargePipe_Set", cp_parts, parent=p_eng)

    # 6) Twin Top-Mounted Charge-Air Intercoolers (`Rolling chassis view 2.jpg`)
    #    Named `TSC_Eng_Intercooler_Pair` so viewer lifts them +12 in exploded view!
    ic_parts: list[bpy.types.Object] = []
    for side in (-1.0, 1.0):
        # Aluminum bar-and-plate intercooler core angled cleanly side-by-side over rear of flat-6
        ic_parts.append(round_box(
            f"_tmp_ic_core_{int(side)}",
            (-1.74, side * 0.22, 0.685),
            (0.24, 0.32, 0.072),
            mats["rad_core"],
            parent=None,
            bevel=0.006,
            rot_euler=(0.0, math.radians(-14), 0.0),
        ))
        # Black molded composite upper charge-air collector shroud (`Rolling chassis view 2.jpg`!)
        ic_parts.append(round_box(
            f"_tmp_ic_shroud_{int(side)}",
            (-1.74, side * 0.22, 0.735),
            (0.26, 0.34, 0.052),
            mats["engine_plastic"],
            parent=None,
            bevel=0.012,
            rot_euler=(0.0, math.radians(-14), 0.0),
        ))
    join_objects("TSC_Eng_Intercooler_Pair", ic_parts, parent=p_eng)

    # 7) 2026 Cabriolet Rear Service Bay Shroud: Twin Honeycomb Cooling Fans + Central `911` Plate + Oil Cap!
    #    Faithfully modeled from REAL 2026 Cabriolet photo `Cabriolet - engine bay fans from above.jpg`!
    #    Positioned right under the rear louvered decklid (`X ≈ -1.52..-1.84, Z ≈ 0.81..0.86`, below Z_center=0.95..1.00!)
    #    Named with `Eng_IntakePlenum` token so it lifts cleanly +23 in exploded view above the intercoolers!
    fan_parts: list[bpy.types.Object] = []
    z_bay = 0.825
    tilt_y = math.radians(-15.0)
    # Matte black textured surround panel spanning rear service opening
    fan_parts.append(round_box("_tmp_bay_shroud", (-1.68, 0.0, z_bay), (0.31, 0.86, 0.032), mats["engine_plastic"], parent=None, bevel=0.010, rot_euler=(0.0, tilt_y, 0.0)))
    # Twin circular recessed electric cooling fans (left & right, Y = ±0.235 m) with 7 sculpted blades + outer guard ring
    for side in (-1.0, 1.0):
        fy = side * 0.235
        fx = -1.68
        # Outer circular fan ring bezel
        fan_parts.append(revolve_profile(
            f"_tmp_fan_ring_{int(side)}",
            [(0.095, 0.0), (0.118, 0.0), (0.118, 0.024), (0.102, 0.026), (0.095, 0.020)],
            mats["undertray"],
            parent=None,
            axis="z",
            center=(fx, fy, z_bay + 0.008),
            steps=36,
            closed_profile=True,
            smooth=True,
        ))
        # Central fan motor hub + 7 swept fan blades
        fan_parts.append(ellipse_case(
            f"_tmp_fan_hub_{int(side)}",
            [(z_bay + 0.004, fx, fy, 0.032, 0.032), (z_bay + 0.024, fx, fy, 0.028, 0.028)],
            mats["gunmetal"],
            parent=None,
            axis="z",
            steps=20,
        ))
        for bk in range(7):
            ba = 2.0 * math.pi * bk / 7.0
            fan_parts.append(round_box(
                f"_tmp_fan_bl_{int(side)}_{bk}",
                (fx + 0.062 * math.cos(ba), fy + 0.062 * math.sin(ba), z_bay + 0.015),
                (0.060, 0.020, 0.004),
                mats["gunmetal"],
                parent=None,
                bevel=0.001,
                rot_euler=(0.32, 0.0, ba),
            ))
        # Protective grille concentric mesh rings across top of fan opening
        for r_gr in (0.048, 0.072, 0.092):
            fan_parts.append(revolve_profile(
                f"_tmp_fan_gr_{int(side)}_{r_gr:.3f}",
                [(r_gr - 0.002, z_bay + 0.024), (r_gr + 0.002, z_bay + 0.024), (r_gr + 0.002, z_bay + 0.027), (r_gr - 0.002, z_bay + 0.027)],
                mats["engine_plastic"],
                parent=None,
                axis="z",
                center=(fx, fy, 0.0),
                steps=28,
                closed_profile=True,
                smooth=False,
            ))
    # Central satin plaque with raised "911" lettering between the two fans (`Cabriolet - engine bay fans from above.jpg`!)
    fan_parts.append(round_box("_tmp_bay_911_pad", (-1.62, 0.0, z_bay + 0.022), (0.095, 0.145, 0.012), mats["turbonite_dark"], parent=None, bevel=0.003, rot_euler=(0.0, tilt_y, 0.0)))
    # Top-facing text readable standing behind the car looking forward, tilted flush with shroud slope (tilt_y)!
    rot_top = Matrix.Rotation(tilt_y, 3, "Y") @ Matrix(((0.0, -1.0, 0.0), (1.0, 0.0, 0.0), (0.0, 0.0, 1.0))).transposed()
    fan_parts.append(text_to_mesh(
        "_tmp_bay_911_txt",
        "911",
        0.044,
        mats["turbonite_crest"],
        parent=None,
        extrude=0.0025,
        location=(-1.62, 0.0, z_bay + 0.032),
        rot_matrix=rot_top,
    ))
    # Structural side support ducts linking fan shroud seamlessly down onto twin intercoolers
    for side in (-1.0, 1.0):
        fan_parts.append(round_box(f"_tmp_bay_duct_{int(side)}", (-1.70, side * 0.22, z_bay - 0.048), (0.24, 0.28, 0.075), mats["engine_plastic"], parent=None, bevel=0.008, rot_euler=(0.0, tilt_y, 0.0)))
    # Right-side oil filler cap (with bright Porsche yellow accent ring matching real Cabriolet photo!)
    fan_parts.append(ellipse_case(
        "_tmp_bay_oilcap",
        [(z_bay + 0.005, -1.66, -0.395, 0.028, 0.028), (z_bay + 0.032, -1.66, -0.395, 0.026, 0.026)],
        mats["engine_plastic"],
        parent=None,
        axis="z",
        steps=20,
    ))
    fan_parts.append(round_box("_tmp_bay_oilcap_tab", (-1.66, -0.395, z_bay + 0.035), (0.014, 0.046, 0.008), mats["caliper_yellow"], parent=None, bevel=0.002))

    join_objects("TSC_Eng_IntakePlenum_FanShroud", fan_parts, parent=p_eng)
    # The harness spans the two cylinder banks above the timing cover. Build
    # the visible junctions, hoses and fasteners independently of the service fan module.
    loom=[]
    for sign in (-1,1):
        for j in range(3):
            x=-1.47-j*.105
            loom.append(tube_along_points("_coil_loom",[(x+.055,sign*.113,.53),(x,sign*.165,.572),
                       (x-.055,sign*.249,.570),(x-.075,sign*.314,.520),(x-.063,sign*.368,.452)],
                       .010-j*.0014,mats["rubber_hose"],sides=9,subdiv=4))
            loom.append(round_box("_coil_socket",(x-.063,sign*.359,.46),(.040,.032,.037),mats["engine_plastic"],bevel=.005))
        loom.append(tube_along_points("_charge_crossover",[(-1.49,sign*.10,.549),(-1.52,sign*.224,.60),
                   (-1.70,sign*.270,.595),(-1.802,sign*.302,.57),(-1.853,sign*.33,.482),
                   (-1.926,sign*.297,.452),(-1.935,sign*.195,.433)],.017,mats["rubber_hose"],sides=12,subdiv=5))
        for k in range(3):
            y=sign*(.095+.104*k)
            loom.append(tube_along_points("_timing_rib",[(-1.947,y,.427),(-1.959,y+sign*.045,.402),(-1.956,y+sign*.051,.336)],
                         .005,mats["cast_alu"],sides=8,subdiv=2))
        loom.append(bolt_array("_upper_case_fasteners",[(-1.964,sign*(.102+.061*k),.420-.007*(k%2)) for k in range(5)],.007,-.009,mats["machined_alu"],axis="x",sides=6))
    loom.append(tube_along_points("_harness_bridge",[(-1.70,-.28,.59),(-1.63,-.17,.611),(-1.69,-.04,.582),
              (-1.73,.068,.576),(-1.663,.205,.599),(-1.72,.28,.58)],.013,mats["rubber_hose"],sides=12,subdiv=5))
    join_objects("TSC_Eng_UpperHarness",loom,parent=p_eng)
    return p_eng


# ---------------------------------------------------------------------------
# 3. Titanium Valved Sport Exhaust System
#    (Parented to Pivot_Exhaust_System)
# ---------------------------------------------------------------------------

def build_exhaust_system(
    rig_root: bpy.types.Object,
    cfg: dict[str, Any],
    mats: dict[str, bpy.types.Material],
) -> bpy.types.Object:
    """Build 3-into-1 headers, outboard heat-shielded GPF/cat pods, transverse titanium silencer & twin inner tailpipes."""
    p_exh = make_empty("Pivot_Exhaust_System", (0.0, 0.0, 0.0), parent=rig_root)

    x_tip = cfg["exhaust_x"]   # -2.265 m (outer bezel plane; inner tips end 10 mm inside bezel!)
    y_tip = cfg["exhaust_y"]   #  0.560 m (center of left/right double-barrel figure-8 cutout!)
    z_tip = cfg["exhaust_z"]   #  0.275 m
    z_crank = 0.345

    # 1) 3-into-1 Tubular Exhaust Headers (each bank's 3 lower exhaust ports merging into eTurbo turbine inlet!)
    for side, s_tag in [(+1.0, "L"), (-1.0, "R")]:
        hdr_parts: list[bpy.types.Object] = []
        tx, ty, tz = -1.83, side * 0.445, z_crank - 0.045
        for c_i, px_port in enumerate([-1.46, -1.615, -1.77]):
            hdr_parts.append(tube_along_points(
                f"_tmp_hdr_{s_tag}_{c_i}",
                [
                    (px_port, side * 0.355, z_crank - 0.095),
                    (px_port - 0.04, side * 0.415, z_crank - 0.130),
                    (tx + 0.06, ty - side * 0.025, tz - 0.045),
                    (tx + 0.02, ty, tz - 0.015),
                ],
                0.022,
                mats["inconel"],
                parent=None,
                sides=14,
                subdiv=3,
            ))
            # Bolted 2-bolt exhaust port flange on head underside
            hdr_parts.append(round_box(f"_tmp_hdr_flg_{s_tag}_{c_i}", (px_port, side * 0.355, z_crank - 0.095), (0.065, 0.048, 0.014), mats["inconel"], parent=None, bevel=0.003))
        join_objects(f"TSC_Exh_Header_{s_tag}", hdr_parts, parent=p_exh)

    # 2) Twin Outboard Heat-Shielded GPF / Catalytic Converter Canister Pods + Electric Exhaust Valve Actuators
    #    Tucked cleanly forward/inboard (`X >= -1.99, |Y| <= 0.61`) inside the tapered 992.2 rear bumper planform!
    for side, s_tag in [(+1.0, "L"), (-1.0, "R")]:
        cat_parts: list[bpy.types.Object] = []
        # Curved downpipe from eTurbo turbine outlet into tucked catalytic/GPF canister
        cat_parts.append(tube_along_points(
            f"_tmp_cat_in_{s_tag}",
            [(-1.84, side * 0.445, 0.300), (-1.89, side * 0.505, 0.320), (-1.92, side * 0.535, 0.365)],
            0.032,
            mats["inconel"],
            parent=None,
            sides=16,
            subdiv=3,
        ))
        # Iconic bulbous stamped-titanium heat-shielded vertical GPF/cat pod tucked strictly within X>=-1.99, |Y|<=0.61
        cat_parts.append(ellipse_case(
            f"_tmp_cat_can_{s_tag}",
            [
                (0.255, -1.915, side * 0.525, 0.062, 0.068),
                (0.325, -1.915, side * 0.530, 0.075, 0.080),
                (0.425, -1.910, side * 0.525, 0.076, 0.082),
                (0.485, -1.905, side * 0.515, 0.060, 0.066),
            ],
            mats["titanium"],
            parent=None,
            axis="z",
            steps=28,
        ))
        # Electric exhaust flap actuator motor perched cleanly on rear-inboard shoulder of GPF pod (X >= -2.01, |Y| <= 0.55)
        cat_parts.append(round_box(f"_tmp_exh_valve_{s_tag}", (-1.985, side * 0.505, 0.385), (0.056, 0.048, 0.046), mats["engine_plastic"], parent=None, bevel=0.007))
        # Cast aluminum vibration-damping exhaust hanger bracket joining cat pod to engine rear flange
        cat_parts.append(tube_along_points(
            f"_tmp_cat_hanger_{s_tag}",
            [(-1.88, side * 0.43, 0.365), (-1.91, side * 0.48, 0.388), (-1.93, side * 0.51, 0.395)],
            0.011,
            mats["cast_alu"],
            parent=None,
            sides=8,
            subdiv=2,
        ))
        join_objects(f"TSC_Exh_Cat_{s_tag}", cat_parts, parent=p_exh)

    # 3) Contoured Stamped-Titanium Transverse Main Silencer / Muffler (`Engine and exhaust - three-quarter view.jpg`!)
    #    Tucked cleanly forward (`X >= -2.155, |Y| <= 0.45`) strictly behind exterior's matte-black diffuser face!
    muf_parts: list[bpy.types.Object] = []
    muf_stations = [
        (-0.44, -2.060, z_tip + 0.024, 0.058, 0.060),
        (-0.32, -2.068, z_tip + 0.030, 0.068, 0.072),
        (-0.16, -2.072, z_tip + 0.034, 0.072, 0.076),
        ( 0.00, -2.075, z_tip + 0.040, 0.076, 0.084),  # Central raised reinforcement hump matching 323525!
        (+0.16, -2.072, z_tip + 0.034, 0.072, 0.076),
        (+0.32, -2.068, z_tip + 0.030, 0.068, 0.072),
        (+0.44, -2.060, z_tip + 0.024, 0.058, 0.060),
    ]
    muf_parts.append(sculpted_box_loft("_tmp_muf_shell", muf_stations, mats["titanium"], parent=None, axis="y"))

    # Stamped heat-shield embossing ribs & recessed mounting bosses proud of rear shell (`X >= -2.158`)
    for y_rib, x_rib in [(-0.30, -2.138), (-0.15, -2.144), (+0.15, -2.144), (+0.30, -2.138)]:
        muf_parts.append(round_box(f"_tmp_muf_rib_{y_rib:.2f}", (x_rib, y_rib, z_tip + 0.032), (0.014, 0.022, 0.105), mats["titanium"], parent=None, bevel=0.003))
    muf_parts.append(round_box("_tmp_muf_center_emboss", (-2.148, 0.0, z_tip + 0.040), (0.014, 0.140, 0.110), mats["machined_alu"], parent=None, bevel=0.004))
    muf_parts.append(bolt_array(
        "_tmp_muf_bosses",
        [(-2.142, y_b, z_tip + 0.025) for y_b in (-0.36, -0.21, +0.21, +0.36)],
        radius=0.010,
        height=-0.008,
        material=mats["stainless"],
        parent=None,
        axis="x",
        sides=12,
    ))
    join_objects("TSC_Exh_Silencer_Main", muf_parts, parent=p_exh)

    # 4) Paired Double-Barrel Inner Exhaust Tailpipes (`TSC_Exhaust_Tip_L/R`)
    #    Two sleek dark satin titanium circular outlets per side (4 total), centered inside cfg['EXHAUST_CUTOUT_X/Y/Z']!
    for side, s_tag in [(+1.0, "L"), (-1.0, "R")]:
        tip_parts: list[bpy.types.Object] = []
        # Spaced ±48 mm around y_tip (e.g. ±0.515 ± 0.048) to fit flush inside exterior's figure-8 bezel!
        for dy_pipe, r_pipe in [(-0.048, 0.032), (+0.048, 0.032)]:
            py = side * (y_tip + dy_pipe)
            # Thick-walled hollow circular exhaust pipe terminating cleanly at x_tip + 0.008 (flush inside bezel!)
            tip_prof = [
                (r_pipe - 0.005, x_tip + 0.105),
                (r_pipe,         x_tip + 0.105),
                (r_pipe,         x_tip + 0.010),
                (r_pipe - 0.002, x_tip + 0.006),
                (r_pipe - 0.005, x_tip + 0.010),
                (r_pipe - 0.005, x_tip + 0.092),
            ]
            tip_parts.append(revolve_profile(
                f"_tmp_tip_pipe_{s_tag}_{dy_pipe:.3f}",
                tip_prof,
                mats["tip_dark"],
                parent=None,
                axis="x",
                center=(0.0, py, z_tip),
                steps=28,
                closed_profile=True,
                smooth=True,
            ))
            # Dark baffle cap deep inside bore so you never see daylight through the pipe
            tip_parts.append(ellipse_case(
                f"_tmp_tip_baffle_{s_tag}_{dy_pipe:.3f}",
                [(x_tip + 0.088, py, z_tip, r_pipe - 0.005, r_pipe - 0.005), (x_tip + 0.102, py, z_tip, r_pipe - 0.005, r_pipe - 0.005)],
                mats["pccb_hole"],
                parent=None,
                axis="x",
                steps=20,
            ))
            # Curved round titanium transition elbow connecting pipe cleanly forward-inboard into tucked main silencer
            tip_parts.append(tube_along_points(
                f"_tmp_tip_neck_{s_tag}_{dy_pipe:.3f}",
                [(x_tip + 0.095, py, z_tip), (x_tip + 0.125, side * (y_tip - 0.05), z_tip + 0.014), (-2.065, side * 0.38, z_tip + 0.024)],
                0.024,
                mats["titanium"],
                parent=None,
                sides=14,
                subdiv=2,
            ))
        join_objects(f"TSC_Exhaust_Tip_{s_tag}", tip_parts, parent=p_exh)

    return p_exh
