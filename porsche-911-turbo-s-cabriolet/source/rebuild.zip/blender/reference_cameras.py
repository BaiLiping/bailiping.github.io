"""Store the studio and detail cameras in the editable master."""
import json
import math
from pathlib import Path

import bpy
from mathutils import Vector, Matrix


def add(scene):
    root = Path(__file__).resolve().parents[1]
    path = root / 'cameras.json'
    if not path.exists():
        path = root / 'calibration/cameras.json'
    poses = json.loads(path.read_text())
    collection = bpy.data.collections.new('Porsche reference cameras')
    scene.collection.children.link(collection)
    for name, entry in poses.items():
        pose = entry['blender_m']
        camera = bpy.data.cameras.new(name)
        camera.sensor_fit = 'VERTICAL'
        camera.sensor_height = 24
        camera.lens = 12 / math.tan(math.radians(pose['fov_deg']) / 2)
        camera.display_size = .08
        obj = bpy.data.objects.new(name, camera)
        collection.objects.link(obj)
        eye = Vector(pose['position'])
        target = Vector(pose['target'])
        rotation = (target-eye).to_track_quat('-Z','Y').to_matrix().to_4x4()
        obj.matrix_world = Matrix.Translation(eye) @ rotation @ Matrix.Rotation(
            float(entry['viewer'].get('roll',0)),4,'Z')
        obj['reference_width'] = entry['solved']['width']
        obj['reference_height'] = entry['solved']['height']
        obj['roof_state'] = entry.get('roof','up')
        obj['viewer_pose'] = json.dumps(entry['viewer'],ensure_ascii=False)
    scene.camera = collection.objects.get('view-12')
    scene.render.resolution_x = poses['view-12']['solved']['width']
    scene.render.resolution_y = poses['view-12']['solved']['height']
    scene.render.resolution_percentage = 100
    return collection
