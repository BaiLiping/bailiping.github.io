"""
Master Assembly & Export Script for the 2026 Porsche 911 Turbo S Cabriolet (992.2 T-Hybrid).

Combines:
  - blender/exterior/build_exterior.py      (owned by @exterior)
  - blender/mechanicals/build_mechanicals.py (owned by @mechanicals; falls back to accurate placeholder wheels if absent)
  - blender/interior/build_interior.py      (owned by @interior; falls back to basic dark cabin floor if absent)

Outputs (in blender/out/):
  - porsche_911_turbo_s_cab.blend : 1:1 real-world METERS, Z-up, editable hierarchy
  - porsche_911_turbo_s_cab.glb   : Draco-compressed glTF 2.0, Y-up, 1:18-scale mm (EXPORT_SCALE = 1000/18),
                                    with scale cleanly baked into vertices & pivot locations so EVERY Pivot_* node
                                    has identity scale [1,1,1] and identity rotation [0,0,0,1] per web/rig_contract.md!

Usage:
  blender --background --python-exit-code 1 --python build_master.py -- [--out-prefix porsche_911_turbo_s_cab] [--roof up|down]
"""

import os
import sys
import math
import importlib
from pathlib import Path

import bpy
from mathutils import Vector, Matrix

BLENDER_DIR = Path(__file__).resolve().parent
OUT_DIR = BLENDER_DIR / "out"
OUT_DIR.mkdir(parents=True, exist_ok=True)

if str(BLENDER_DIR) not in sys.path:
    sys.path.insert(0, str(BLENDER_DIR))

from exterior import config as cfg
from exterior.geom_utils import ensure_empty, create_cylinder, create_rounded_box
from exterior.materials import create_all_materials
from exterior import build_exterior


def _parse_args():
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    opts = {"out_prefix": "porsche_911_turbo_s_cab", "roof": "up", "no_draco": False}
    i = 0
    while i < len(argv):
        if argv[i] == "--out-prefix" and i + 1 < len(argv):
            opts["out_prefix"] = argv[i + 1]
            i += 2
        elif argv[i] == "--roof" and i + 1 < len(argv):
            opts["roof"] = argv[i + 1]
            i += 2
        elif argv[i] == "--no-draco":
            opts["no_draco"] = True
            i += 1
        else:
            i += 1
    return opts


def _build_placeholder_mechanicals(rig_root: bpy.types.Object, shared_cfg: dict) -> dict:
    """
    Accurate-dimension placeholder wheels, PCCB rotors, yellow calipers & underbody floor
    used ONLY during Stage A blockout before @mechanicals lands build_mechanicals.py.
    """
    mats = create_all_materials()
    pivots = {}

    piv_ch = ensure_empty("Pivot_Drivetrain_Chassis", (0.0, 0.0, 0.0), parent=rig_root)
    pivots["Pivot_Drivetrain_Chassis"] = piv_ch
    # Clean flat underbody pan
    create_rounded_box("TSC_Undertray_Placeholder", (0.0, 0.0, cfg.Z_UNDERBODY + 0.015), (3.60, 1.38, 0.03), material=mats["shadow"], parent=piv_ch, bevel_width=0.005)

    pivots["Pivot_Flat6_Engine"] = ensure_empty("Pivot_Flat6_Engine", (0.0, 0.0, 0.0), parent=rig_root)
    pivots["Pivot_Exhaust_System"] = ensure_empty("Pivot_Exhaust_System", (0.0, 0.0, 0.0), parent=rig_root)

    corners = [
        ("FL", cfg.X_FRONT_AXLE, +cfg.Y_WHEEL_FRONT, cfg.Z_WHEEL_FRONT, cfg.TIRE_FRONT_R, cfg.TIRE_FRONT_WIDTH, cfg.RIM_FRONT_DIAM * 0.5, cfg.ROTOR_FRONT_R, -1.0),
        ("FR", cfg.X_FRONT_AXLE, -cfg.Y_WHEEL_FRONT, cfg.Z_WHEEL_FRONT, cfg.TIRE_FRONT_R, cfg.TIRE_FRONT_WIDTH, cfg.RIM_FRONT_DIAM * 0.5, cfg.ROTOR_FRONT_R, -1.0),
        ("RL", cfg.X_REAR_AXLE,  +cfg.Y_WHEEL_REAR,  cfg.Z_WHEEL_REAR,  cfg.TIRE_REAR_R,  cfg.TIRE_REAR_WIDTH,  cfg.RIM_REAR_DIAM * 0.5,  cfg.ROTOR_REAR_R,  +1.0),
        ("RR", cfg.X_REAR_AXLE,  -cfg.Y_WHEEL_REAR,  cfg.Z_WHEEL_REAR,  cfg.TIRE_REAR_R,  cfg.TIRE_REAR_WIDTH,  cfg.RIM_REAR_DIAM * 0.5,  cfg.ROTOR_REAR_R,  +1.0),
    ]
    for tag, cx, cy, cz, r_tire, w_tire, r_rim, r_rot, cal_dir in corners:
        sign = 1.0 if cy > 0 else -1.0
        p_corner = ensure_empty(f"Pivot_Corner_{tag}", (cx, cy, cz), parent=rig_root)
        p_spin = ensure_empty(f"Pivot_WheelSpin_{tag}", (0.0, 0.0, 0.0), parent=p_corner)
        pivots[f"Pivot_Corner_{tag}"] = p_corner
        pivots[f"Pivot_WheelSpin_{tag}"] = p_spin

        create_cylinder(f"TSC_Tire_{tag}", (cx, cy, cz), r_tire, w_tire, axis="Y", segments=48, material=mats["tire"], parent=p_spin, bevel=0.024)
        create_cylinder(f"TSC_Rim_Barrel_{tag}", (cx, cy + sign * 0.015, cz), r_rim, w_tire * 0.86, axis="Y", segments=40, material=mats["turbonite"], parent=p_spin, bevel=0.008)
        create_cylinder(f"TSC_CenterLockHub_{tag}", (cx, cy + sign * (w_tire * 0.42), cz), 0.055, 0.035, axis="Y", segments=24, material=mats["gloss_black"], parent=p_spin, bevel=0.006)
        create_cylinder(f"TSC_PCCB_Rotor_{tag}", (cx, cy + sign * 0.025, cz), r_rot, 0.036, axis="Y", segments=36, material=mats["rotor"], parent=p_spin, bevel=0.003)
        # Yellow PCCB caliper inboard of axles (trailing front, leading rear!)
        create_rounded_box(f"TSC_Caliper_{tag}", (cx + cal_dir * (r_rot * 0.72), cy + sign * 0.045, cz), (0.095, 0.070, 0.210 if tag.startswith("F") else 0.165), material=mats["caliper_yellow"], parent=p_corner, bevel_width=0.015)

    return pivots


def _build_placeholder_interior(rig_root: bpy.types.Object) -> dict:
    """Minimal dark cabin tub placeholder used ONLY if blender/interior/build_interior.py is not yet present."""
    mats = create_all_materials()
    piv = ensure_empty("Pivot_Interior_Cabin", (0.0, 0.0, 0.0), parent=rig_root)
    create_rounded_box("TSC_Carpet_Floor_Placeholder", (-0.10, 0.0, 0.21), (1.70, 1.38, 0.06), material=mats["cabin_carpet"], parent=piv, bevel_width=0.01)
    create_rounded_box("TSC_Dash_Placeholder", (0.52, 0.0, 0.78), (0.36, 1.34, 0.22), material=mats["cabin_leather"], parent=piv, bevel_width=0.04)
    for sy, tag in [(+0.34, "L"), (-0.34, "R")]:
        create_rounded_box(f"TSC_Seat_Front_{tag}_Placeholder", (-0.18, sy, 0.62), (0.28, 0.44, 0.68), material=mats["cabin_leather"], parent=piv, bevel_width=0.06, rotation=(0.0, -0.22, 0.0))
    return {"Pivot_Interior_Cabin": piv}


def _bake_scale_and_modifiers_for_export(scale: float):
    """
    Prepare scene for glTF/GLB export at 1:18-scale mm (scale = 1000/18):
      1. Convert Curve objects to Mesh and apply all modifiers cleanly.
      2. Scale EVERY object's local location AND every mesh vertex coordinate by `scale`,
         leaving EVERY Pivot_* and mesh object with identity scale (1, 1, 1)!
    This guarantees Three.js explode offsets, pull offsets, and hinge rotations operate
    directly in exact 1:18 mm units without any parent scale factor!
    """
    bpy.ops.object.select_all(action="DESELECT")
    deps = bpy.context.evaluated_depsgraph_get()

    # Reliable conversion of CURVE -> MESH using bpy.ops.object.convert
    curves = [ob for ob in bpy.data.objects if ob.type == "CURVE"]
    if curves:
        hidden_states = {ob: ob.hide_viewport for ob in curves}
        for ob in curves:
            ob.hide_viewport = False
        bpy.ops.object.select_all(action="DESELECT")
        for ob in curves:
            ob.select_set(True)
        bpy.context.view_layer.objects.active = curves[0]
        bpy.ops.object.convert(target="MESH")
        for ob, hv in hidden_states.items():
            ob.hide_viewport = hv

    # Apply modifiers on all mesh objects safely (even hidden ones)
    deps = bpy.context.evaluated_depsgraph_get()
    for ob in list(bpy.data.objects):
        if ob.type == "MESH" and ob.modifiers:
            was_hv = ob.hide_viewport
            ob.hide_viewport = False
            deps.update()
            eo = ob.evaluated_get(deps)
            new_me = bpy.data.meshes.new_from_object(eo, preserve_all_data_layers=True, depsgraph=deps)
            new_me.name = ob.data.name + "_baked"
            old_me = ob.data
            ob.modifiers.clear()
            ob.data = new_me
            if old_me.users == 0:
                bpy.data.meshes.remove(old_me)
            ob.hide_viewport = was_hv

    # Bake uniform scale S into every object's local translation and every mesh's vertices.
    # Unhide all objects during scaling + view_layer.update() so Blender updates matrix_world
    # on hidden nodes like Pivot_Soft_Top_Stowed before glTF export!
    all_hidden = {ob: ob.hide_viewport for ob in bpy.data.objects}
    for ob in bpy.data.objects:
        ob.hide_viewport = False

    scaled_meshes = set()
    scale_mat = Matrix.Scale(scale, 4)
    for ob in bpy.data.objects:
        ob.location = ob.location * scale
        if ob.type == "MESH" and ob.data not in scaled_meshes:
            ob.data.transform(scale_mat)
            ob.data.update()
            scaled_meshes.add(ob.data)
        ob.scale = Vector((1.0, 1.0, 1.0))

    bpy.context.view_layer.update()
    for ob, hv in all_hidden.items():
        ob.hide_viewport = hv


def _print_scene_diagnostics(label: str):
    """Print exact assembled bounds and pivot verification."""
    deps = bpy.context.evaluated_depsgraph_get()
    mn = Vector((1e9, 1e9, 1e9))
    mx = Vector((-1e9, -1e9, -1e9))
    mesh_count = 0
    tri_count = 0
    pivots = []
    for ob in bpy.data.objects:
        if ob.name.startswith("Pivot_"):
            pivots.append(ob.name)
        if ob.type == "MESH" and not ob.hide_viewport:
            mesh_count += 1
            eo = ob.evaluated_get(deps)
            me = eo.to_mesh()
            me.calc_loop_triangles()
            tri_count += len(me.loop_triangles)
            M = ob.matrix_world
            for v in me.vertices:
                w = M @ v.co
                mn.x = min(mn.x, w.x); mn.y = min(mn.y, w.y); mn.z = min(mn.z, w.z)
                mx.x = max(mx.x, w.x); mx.y = max(mx.y, w.y); mx.z = max(mx.z, w.z)
            eo.to_mesh_clear()
    ext = mx - mn
    print(f"[{label}] Meshes={mesh_count}, Tris={tri_count:,}, Pivots={len(pivots)}")
    print(f"[{label}] Bounds X:[{mn.x:.4f}, {mx.x:.4f}] (L={ext.x:.4f})  Y:[{mn.y:.4f}, {mx.y:.4f}] (W={ext.y:.4f})  Z:[{mn.z:.4f}, {mx.z:.4f}] (H={ext.z:.4f})")
    print(f"[{label}] Pivots: {sorted(pivots)}")


def main():
    opts = _parse_args()
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.unit_settings.system = "METRIC"
    sc.unit_settings.length_unit = "METERS"

    shared_cfg = cfg.as_shared_dict()
    rig_root = ensure_empty("TurboSCab_Interactive_Rig", (0.0, 0.0, 0.0))

    # Check if @mechanicals and @interior modules exist yet
    mech_exists = (BLENDER_DIR / "mechanicals" / "build_mechanicals.py").is_file()
    int_exists = (BLENDER_DIR / "interior" / "build_interior.py").is_file()
    print(f"[build_master] exterior=True, mechanicals={mech_exists}, interior={int_exists}, roof={opts['roof']}")

    # 1. Exterior (always built)
    pivots = build_exterior.build(
        rig_root,
        shared_cfg,
        include_door_cards=(not int_exists),
        roof_state=opts["roof"],
    )

    # 2. Mechanicals (real module if present, else exact-dimension Stage A placeholder wheels)
    if mech_exists:
        mech_mod = importlib.import_module("mechanicals.build_mechanicals")
        pivots.update(mech_mod.build(rig_root, shared_cfg) or {})
    else:
        pivots.update(_build_placeholder_mechanicals(rig_root, shared_cfg))

    # 3. Interior (real module if present, else minimal placeholder)
    if int_exists:
        int_mod = importlib.import_module("interior.build_interior")
        pivots.update(int_mod.build(rig_root, shared_cfg) or {})
    else:
        pivots.update(_build_placeholder_interior(rig_root))

    bpy.context.view_layer.update()
    from exterior.surface_details import apply_graphics
    from exterior.surface_fit import apply_to_body
    apply_graphics()
    if mech_exists:
        from mechanicals.finishes import apply as apply_mechanical_finishes
        apply_mechanical_finishes()
    # Blender skips world-matrix updates on the alternate, hidden roof assembly.
    alternate = [obj for obj in bpy.context.scene.objects if obj.hide_viewport]
    for obj in alternate:
        obj.hide_viewport = False
    bpy.context.view_layer.update()
    apply_to_body(bpy.context.scene.objects)
    from exterior.rear_outlets import rebuild_rear_valance
    rebuild_rear_valance()
    from exterior.rear_upper import build as build_rear_upper
    build_rear_upper()
    for obj in alternate:
        obj.hide_viewport = True
    bpy.context.view_layer.update()
    _print_scene_diagnostics("MASTER_METERS")

    # Save 1:1 real-world meters editable Blender master!
    blend_path = OUT_DIR / f"{opts['out_prefix']}.blend"
    from reference_cameras import add as add_reference_cameras
    cameras = add_reference_cameras(sc)
    bpy.ops.wm.save_as_mainfile(filepath=str(blend_path), compress=True)
    for camera in list(cameras.objects):
        bpy.data.objects.remove(camera, do_unlink=True)
    bpy.data.collections.remove(cameras)
    print(f"[build_master] Saved 1:1m Blender master: {blend_path}")

    # Scale cleanly to 1:18 mm (S = 1000/18) and export Draco GLB!
    _bake_scale_and_modifiers_for_export(cfg.EXPORT_SCALE)
    bpy.context.view_layer.update()
    _print_scene_diagnostics("EXPORT_1_18_MM")

    glb_path = OUT_DIR / f"{opts['out_prefix']}.glb"
    export_kwargs = dict(
        filepath=str(glb_path),
        export_format="GLB",
        export_yup=True,
        export_apply=True,
        export_extras=True,
        export_animations=False,
        export_materials="EXPORT",
        use_visible=False,  # CRITICAL: keep hidden Pivot_Soft_Top_Stowed inside GLB for roof toggle!
    )
    if not opts["no_draco"]:
        export_kwargs.update(
            export_draco_mesh_compression_enable=True,
            export_draco_mesh_compression_level=6,
            export_draco_position_quantization=14,
            export_draco_normal_quantization=10,
            export_draco_texcoord_quantization=12,
        )
    bpy.ops.export_scene.gltf(**export_kwargs)
    size_mb = glb_path.stat().st_size / (1024 * 1024)
    print(f"[build_master] Exported Draco GLB: {glb_path} ({size_mb:.2f} MB)")


if __name__ == "__main__":
    main()
