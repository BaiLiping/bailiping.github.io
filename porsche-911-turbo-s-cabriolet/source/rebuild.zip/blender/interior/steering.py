"""
GT Sport Steering Wheel, Monochrome Turbonite Porsche Crest, Open-Frame Turbonite Spokes,
Rotary Drive-Mode Switch with Red Sport Response Button, PDK Shift Paddles, Column & Stalks.

Mesh names start with TSC_SteeringWheel_ / TSC_Steering_ per web/rig_contract.md so the
entire steering assembly separates cleanly as one cohesive unit in Exploded view.
"""

import math
import numpy as np
from . import config as C
from .geom_utils import (
    create_tube_mesh,
    create_cylinder,
    create_rounded_box,
    create_textured_quad,
    create_stitch_line,
)


def _wheel_xf(pts_local, center, pitch_rad):
    """
    Transform local wheel-frame points (where -X faces driver, +Y is left, +Z is up)
    into world space rotated by +pitch_rad around +Y and translated to center.
    """
    arr = np.asarray(pts_local, dtype=np.float64)
    cp, sp = math.cos(pitch_rad), math.sin(pitch_rad)
    x = arr[..., 0] * cp + arr[..., 2] * sp + center[0]
    y = arr[..., 1] + center[1]
    z = -arr[..., 0] * sp + arr[..., 2] * cp + center[2]
    return np.stack([x, y, z], axis=-1)


def _wpt(lx, ly, lz, center, pitch_rad):
    p = _wheel_xf(np.array([lx, ly, lz], dtype=np.float64), center, pitch_rad)
    return tuple(p.tolist())


def build_steering_wheel(parent, mats: dict, cfg: dict) -> list:
    objs = []
    center = np.array(C.WHEEL_CENTER, dtype=np.float64)
    r_rim = C.WHEEL_RADIUS
    pitch = math.radians(C.WHEEL_TILT_DEG)

    # ------------------------------------------------------------------
    # 1. Contoured GT Sport Leather Rim + 12-o'clock Seam + Inner Stitch
    # ------------------------------------------------------------------
    n_seg = 64
    thetas = np.linspace(0.0, 2.0 * math.pi, n_seg, endpoint=False)
    rim_pts_local = []
    rim_radii = []
    for th in thetas:
        # th=0 at 12 o'clock (+Z), th=pi/2 at 9 o'clock (+Y), th=pi at 6 o'clock (-Z)
        ly = r_rim * math.sin(th)
        lz = r_rim * math.cos(th)
        # Subtle dish: rim sits slightly closer to driver than hub center
        lx = -0.022
        rim_pts_local.append((lx, ly, lz))
        # Subtle contoured thumb rests at 10 o'clock (th ~ 0.6) and 2 o'clock (th ~ 5.68)
        thumb_l = math.exp(-0.5 * ((th - 0.62) / 0.24) ** 2)
        thumb_r = math.exp(-0.5 * ((th - (2.0 * math.pi - 0.62)) / 0.24) ** 2)
        rim_radii.append(0.0175 + 0.0026 * (thumb_l + thumb_r))

    rim_pts_world = _wheel_xf(rim_pts_local, center, pitch)
    objs.append(create_tube_mesh(
        "TSC_SteeringWheel_Rim",
        rim_pts_world,
        radius=rim_radii,
        segments=20,
        material=mats["leather"],
        parent=parent,
        cyclic=True,
        radius_y_scale=0.88,
    ))

    # 12-o'clock subtle dark stitched center leather band (photo 47 shows clean black seam band)
    objs.append(create_cylinder(
        "TSC_SteeringWheel_TopBand",
        _wpt(-0.022, 0.0, r_rim, center, pitch),
        radius=0.0182, depth=0.010, axis="Y", segments=24,
        material=mats["leather_dark"], parent=parent,
        rotation=(0.0, pitch, 0.0),
    ))

    # Turbonite contrast stitch running around the inner edge of the steering rim
    stitch_pts_local = [(-0.024, (r_rim - 0.017) * math.sin(th), (r_rim - 0.017) * math.cos(th)) for th in thetas]
    stitch_pts_world = _wheel_xf(stitch_pts_local, center, pitch)
    objs.append(create_tube_mesh(
        "TSC_SteeringWheel_RimStitch",
        stitch_pts_world,
        radius=0.0014,
        segments=6,
        material=mats["stitch"],
        parent=parent,
        cyclic=True,
    ))

    # ------------------------------------------------------------------
    # 2. Circular Airbag Hub, Turbonite Ring & Monochrome Porsche Crest
    # ------------------------------------------------------------------
    # Main domed circular leather airbag pad
    objs.append(create_cylinder(
        "TSC_SteeringWheel_HubBase",
        _wpt(0.008, 0.0, 0.0, center, pitch),
        radius=0.072, radius2=0.066, depth=0.044, axis="X", segments=48,
        material=mats["leather"], parent=parent, bevel=0.009,
        rotation=(0.0, pitch, 0.0),
    ))
    objs.append(create_cylinder(
        "TSC_SteeringWheel_HubPad",
        _wpt(-0.014, 0.0, 0.0, center, pitch),
        radius=0.061, radius2=0.056, depth=0.024, axis="X", segments=48,
        material=mats["leather"], parent=parent, bevel=0.006,
        rotation=(0.0, pitch, 0.0),
    ))
    # Prominent satin Turbonite metallic circular ring on airbag hub (matching crop_47_wheel_cluster!)
    ring_thetas = np.linspace(0.0, 2.0 * math.pi, 48, endpoint=False)
    ring_pts = _wheel_xf([(-0.027, 0.049 * math.sin(t), 0.049 * math.cos(t)) for t in ring_thetas], center, pitch)
    objs.append(create_tube_mesh(
        "TSC_SteeringWheel_HubTurboniteRing",
        ring_pts, radius=0.0036, segments=12,
        material=mats["turbonite"], parent=parent, cyclic=True,
    ))
    # Monochrome Turbonite Porsche Crest centered on airbag pad
    cw, ch = 0.038, 0.046
    crest_corners = _wheel_xf([
        (-0.0295, +cw * 0.5, -ch * 0.5),
        (-0.0295, -cw * 0.5, -ch * 0.5),
        (-0.0295, -cw * 0.5, +ch * 0.5),
        (-0.0295, +cw * 0.5, +ch * 0.5),
    ], center, pitch)
    objs.append(create_textured_quad(
        "TSC_SteeringWheel_PorscheCrest", crest_corners,
        material=mats["crest_turbonite"], parent=parent,
    ))

    # ------------------------------------------------------------------
    # 3. Three Spokes: Left/Right Open-Frame Turbonite Bezels + Twin 6-o'clock Spoke
    # ------------------------------------------------------------------
    for side_lbl, sgn in (("L", +1.0), ("R", -1.0)):
        # Sculpted leather spoke arm connecting hub to outer rim
        objs.append(create_rounded_box(
            f"TSC_SteeringWheel_SpokeArm_{side_lbl}",
            _wpt(-0.008, sgn * 0.114, -0.004, center, pitch),
            (0.026, 0.118, 0.046),
            material=mats["leather"], parent=parent, bevel_width=0.008,
            rotation=(0.0, pitch, 0.0),
        ))
        # Open-frame Satin Turbonite metallic spoke bezel (with top, bottom, outer bars)
        objs.append(create_rounded_box(
            f"TSC_SteeringWheel_SpokeBezelTop_{side_lbl}",
            _wpt(-0.021, sgn * 0.112, +0.016, center, pitch),
            (0.008, 0.095, 0.007),
            material=mats["turbonite"], parent=parent, bevel_width=0.002,
            rotation=(0.0, pitch, 0.0),
        ))
        objs.append(create_rounded_box(
            f"TSC_SteeringWheel_SpokeBezelBot_{side_lbl}",
            _wpt(-0.021, sgn * 0.112, -0.022, center, pitch),
            (0.008, 0.095, 0.007),
            material=mats["turbonite"], parent=parent, bevel_width=0.002,
            rotation=(0.0, pitch, 0.0),
        ))
        objs.append(create_rounded_box(
            f"TSC_SteeringWheel_SpokeBezelOut_{side_lbl}",
            _wpt(-0.021, sgn * 0.156, -0.003, center, pitch),
            (0.008, 0.008, 0.044),
            material=mats["turbonite"], parent=parent, bevel_width=0.002,
            rotation=(0.0, pitch, 0.0),
        ))
        # Multifunction switch pod + knurled horizontal scroll roller inside bezel
        objs.append(create_rounded_box(
            f"TSC_SteeringWheel_SwitchPod_{side_lbl}",
            _wpt(-0.022, sgn * 0.108, -0.003, center, pitch),
            (0.012, 0.072, 0.024),
            material=mats["piano_black"], parent=parent, bevel_width=0.003,
            rotation=(0.0, pitch, 0.0),
        ))
        objs.append(create_cylinder(
            f"TSC_SteeringWheel_ScrollWheel_{side_lbl}",
            _wpt(-0.029, sgn * 0.112, -0.003, center, pitch),
            radius=0.0075, depth=0.024, axis="Y", segments=18,
            material=mats["knurled_dark"], parent=parent, bevel=0.001,
            rotation=(0.0, pitch, 0.0),
        ))
        # Subtle white backlit icons flanking scroll wheel
        objs.append(create_rounded_box(
            f"TSC_SteeringWheel_SwitchLED_{side_lbl}",
            _wpt(-0.029, sgn * 0.088, -0.003, center, pitch),
            (0.002, 0.008, 0.005),
            material=mats["white_led"], parent=parent, bevel_width=0.0005,
            rotation=(0.0, pitch, 0.0),
        ))

    # Twin lower 6-o'clock spokes + Turbonite metallic lower U-bridge (photo 47!)
    for side_lbl, sgn in (("L", +1.0), ("R", -1.0)):
        pts_low = _wheel_xf([
            (-0.004, sgn * 0.032, -0.056),
            (-0.012, sgn * 0.022, -0.114),
            (-0.020, sgn * 0.014, -0.166),
        ], center, pitch)
        objs.append(create_tube_mesh(
            f"TSC_SteeringWheel_LowerSpoke_{side_lbl}",
            pts_low, radius=0.011, segments=12,
            material=mats["leather"], parent=parent,
        ))
    # Satin Turbonite bottom bridge clasp wrapping 6-o'clock spoke junction
    objs.append(create_rounded_box(
        "TSC_SteeringWheel_LowerTurboniteBridge",
        _wpt(-0.024, 0.0, -0.158, center, pitch),
        (0.016, 0.036, 0.034),
        material=mats["turbonite"], parent=parent, bevel_width=0.005,
        rotation=(0.0, pitch, 0.0),
    ))

    # ------------------------------------------------------------------
    # 4. 4:30 Rotary Drive-Mode Switch + Red Sport Response Push-Button
    # ------------------------------------------------------------------
    dm_local = (-0.016, -0.068, -0.066)
    # Mounting stalk connecting dial to lower-right hub
    stalk_pts = _wheel_xf([(-0.004, -0.044, -0.044), dm_local], center, pitch)
    objs.append(create_tube_mesh(
        "TSC_SteeringWheel_DriveModeStalk", stalk_pts, radius=0.009, segments=12,
        material=mats["trim_dark"], parent=parent,
    ))
    # Knurled dark outer rotary bezel
    objs.append(create_cylinder(
        "TSC_SteeringWheel_DriveModeDial",
        _wpt(dm_local[0] - 0.006, dm_local[1], dm_local[2], center, pitch),
        radius=0.021, depth=0.018, axis="X", segments=32,
        material=mats["piano_black"], parent=parent, bevel=0.003,
        rotation=(0.0, pitch, 0.0),
    ))
    objs.append(create_cylinder(
        "TSC_SteeringWheel_DriveModeRing",
        _wpt(dm_local[0] - 0.013, dm_local[1], dm_local[2], center, pitch),
        radius=0.0185, depth=0.006, axis="X", segments=32,
        material=mats["knurled_dark"], parent=parent, bevel=0.001,
        rotation=(0.0, pitch, 0.0),
    ))
    # Iconic bright RED central Sport Response push button!
    objs.append(create_cylinder(
        "TSC_SteeringWheel_SportResponseBtn",
        _wpt(dm_local[0] - 0.017, dm_local[1], dm_local[2], center, pitch),
        radius=0.0105, depth=0.006, axis="X", segments=28,
        material=mats["red_accent"], parent=parent, bevel=0.002,
        rotation=(0.0, pitch, 0.0),
    ))

    # ------------------------------------------------------------------
    # 5. Metallic PDK Shift Paddles (- Left, + Right)
    # ------------------------------------------------------------------
    for side_lbl, sgn in (("L", +1.0), ("R", -1.0)):
        objs.append(create_rounded_box(
            f"TSC_SteeringWheel_ShiftPaddle_{side_lbl}",
            _wpt(0.024, sgn * 0.112, +0.024, center, pitch),
            (0.007, 0.032, 0.068),
            material=mats["knurled_dark"], parent=parent, bevel_width=0.003,
            rotation=(sgn * math.radians(-8.0), pitch, 0.0),
        ))
        objs.append(create_rounded_box(
            f"TSC_SteeringWheel_ShiftPaddleEdge_{side_lbl}",
            _wpt(0.021, sgn * 0.118, +0.044, center, pitch),
            (0.004, 0.018, 0.016),
            material=mats["brushed_alu"], parent=parent, bevel_width=0.0015,
            rotation=(sgn * math.radians(-8.0), pitch, 0.0),
        ))

    # ------------------------------------------------------------------
    # 6. Steering Column Shroud & Control Stalks (Turn, Cruise, Wiper)
    # ------------------------------------------------------------------
    objs.append(create_cylinder(
        "TSC_Steering_ColumnShaft",
        _wpt(0.145, 0.0, 0.0, center, pitch),
        radius=0.056, radius2=0.064, depth=0.265, axis="X", segments=32,
        material=mats["trim_dark"], parent=parent, bevel=0.006,
        rotation=(0.0, pitch, 0.0),
    ))
    # Gloss-black flat top cap on steering column shroud (clearly visible right below tach in photo 47!)
    objs.append(create_rounded_box(
        "TSC_Steering_ColumnTopCap",
        _wpt(0.105, 0.0, +0.058, center, pitch),
        (0.130, 0.112, 0.018),
        material=mats["piano_black"], parent=parent, bevel_width=0.006,
        rotation=(0.0, pitch - math.radians(10.0), 0.0),
    ))

    # Left turn-signal stalk, lower-left cruise-control stalk (SET/SPEED), right wiper stalk
    stalks = [
        ("TurnL", (0.068, +0.055, +0.018), (0.054, +0.165, +0.036), 0.0085),
        ("CruiseL", (0.072, +0.055, -0.038), (0.052, +0.155, -0.056), 0.0105),
        ("WiperR", (0.068, -0.055, +0.018), (0.054, -0.165, +0.036), 0.0085),
    ]
    for s_name, p0, p1, rad in stalks:
        s_pts = _wheel_xf([p0, p1], center, pitch)
        objs.append(create_tube_mesh(
            f"TSC_Steering_Stalk_{s_name}", s_pts, radius=rad, segments=12,
            material=mats["trim_dark"], parent=parent,
        ))

    return objs
