"""
992.2 Porsche 911 Turbo S Cabriolet Center Console, Tunnel, Climate Control Bar,
Stubby PDK Toggle Shifter, Cabriolet Roof Switches, Matte Carbon Cupholder Surround & Armrest.

Mesh naming follows web/rig_contract.md:
  - TSC_CenterConsole_* (tunnel, Turbonite trim, carbon surround, climate, roof switches, armrest)
  - TSC_PDK_Selector_*  (stubby toggle shifter, R-N-D face, P/M buttons, Turbonite shifter bezel)
"""

import math
import numpy as np
from . import config as C
from .geom_utils import (
    create_quad_grid,
    create_rounded_box,
    create_cylinder,
    create_textured_quad,
    create_stitch_line,
)


def _console_top_z(x: float) -> float:
    """Exact 992 sloping center console deck height Z(x) from dash (+0.455) to rear (-0.960)."""
    if x >= -0.055:
        # Smooth rising bridge from cupholder (-0.055, Z=0.448) up to lower dash (+0.455, Z=0.618)
        t = (x - (-0.055)) / (0.455 - (-0.055))
        return 0.448 + 0.170 * (t ** 1.05)
    elif x >= -0.455:
        # Armrest base zone
        return 0.448
    else:
        # Rear center console bridge rising subtly toward rear seatback
        t = (-0.455 - x) / (0.960 - 0.455)
        return 0.448 + 0.025 * t


def _console_half_w(x: float) -> float:
    """Half-width of center console bridge (slightly wider near climate bar, tapers subtly to cupholder)."""
    if x >= -0.055:
        t = (x - (-0.055)) / (0.455 - (-0.055))
        return 0.106 + 0.016 * t
    elif x >= -0.455:
        return 0.104
    else:
        t = (-0.455 - x) / (0.960 - 0.455)
        return 0.104 - 0.014 * t


def build_console(parent, mats: dict, cfg: dict) -> list:
    objs = []
    slope_pitch = math.atan2(0.170, 0.510)  # ~18.4 deg upward toward +X

    # ------------------------------------------------------------------
    # 1. Leather Center Tunnel Body (with real deep recessed cupholder cavity!)
    # ------------------------------------------------------------------
    xs = np.linspace(-0.960, +0.510, 56)
    n_v = 11
    grid = np.zeros((len(xs), n_v, 3), dtype=np.float64)
    z_floor = cfg["Z_FLOOR"] - 0.008
    for i, x in enumerate(xs):
        zt = _console_top_z(float(x))
        hw = _console_half_w(float(x))
        hw_bot = hw + 0.036
        # Carve genuine deep recessed cupholder pocket in center deck (X in [-0.020, +0.074])!
        cup_dip = 0.0
        if -0.022 < x < 0.076:
            edge_l = min(1.0, (x - (-0.022)) / 0.014)
            edge_r = min(1.0, (0.076 - x) / 0.014)
            cup_dip = 0.072 * min(edge_l, edge_r)
        profile = [
            (+hw_bot, z_floor),
            (+hw_bot - 0.004, z_floor + 0.095),
            (+hw + 0.012, zt - 0.065),
            (+hw + 0.004, zt - 0.014),
            (+hw - 0.018, zt - 0.002),
            (0.0, zt - cup_dip),
            (-hw + 0.018, zt - 0.002),
            (-hw - 0.004, zt - 0.014),
            (-hw - 0.012, zt - 0.065),
            (-hw_bot + 0.004, z_floor + 0.095),
            (-hw_bot, z_floor),
        ]
        for j, (py, pz) in enumerate(profile):
            grid[i, j] = (x, py, pz)
    objs.append(create_quad_grid(
        "TSC_CenterConsole_Tunnel", grid,
        material=mats["leather_dark"], parent=parent, cap_u0=False, cap_u1=False,
    ))

    # Subtle blue ambient light strips tucked under left & right console upper overhang (photo 47!)
    for side_lbl, sgn in (("L", +1.0), ("R", -1.0)):
        amb_pts = []
        for x in np.linspace(-0.02, +0.38, 16):
            zt = _console_top_z(float(x))
            hw = _console_half_w(float(x))
            amb_pts.append((float(x), sgn * (hw + 0.006), zt - 0.022))
        objs.append(create_stitch_line(
            f"TSC_CenterConsole_AmbientLED_{side_lbl}", amb_pts, mats["ambient_blue"], parent=parent, radius=0.0024,
        ))

    # ------------------------------------------------------------------
    # 2. Continuous Satin Turbonite U-Perimeter Trim Molding (matching crop_47_console!)
    # ------------------------------------------------------------------
    turb_pts = []
    # Left rail running aft from dash to rear of cupholder
    for x in np.linspace(+0.450, -0.032, 20):
        hw = _console_half_w(float(x))
        zt = _console_top_z(float(x)) + 0.005
        turb_pts.append((float(x), +hw, zt))
    # Smooth rounded rear U-bend behind park brake switch
    for ang in np.linspace(0.0, math.pi, 14):
        rx = -0.032 - 0.028 * math.sin(ang)
        ry = 0.106 * math.cos(ang)
        turb_pts.append((rx, ry, 0.453))
    # Right rail returning forward to dash
    for x in np.linspace(-0.032, +0.450, 20):
        hw = _console_half_w(float(x))
        zt = _console_top_z(float(x)) + 0.005
        turb_pts.append((float(x), -hw, zt))
    objs.append(create_stitch_line(
        "TSC_CenterConsole_TurboniteFrame", turb_pts, mats["turbonite"], parent=parent, radius=0.0082,
    ))

    # ------------------------------------------------------------------
    # 3. Climate Control Bar ('22.0 SYNC 22.0') + 2 Rotary Knobs + 3 Knurled Toggles
    # ------------------------------------------------------------------
    # Gloss-black upper climate readout strip
    cx0, cx1 = 0.402, 0.450
    cz0, cz1 = _console_top_z(cx0) + 0.006, _console_top_z(cx1) + 0.006
    objs.append(create_textured_quad(
        "TSC_CenterConsole_ClimateDisplay",
        [
            (cx0, +0.105, cz0),
            (cx0, -0.105, cz0),
            (cx1, -0.105, cz1),
            (cx1, +0.105, cz1),
        ],
        material=mats["climate_bar"], parent=parent,
    ))
    # Left & Right knurled rotary climate/media dials
    for side_lbl, ky in (("L", +0.084), ("R", -0.084)):
        kx = 0.378
        kz = _console_top_z(kx) + 0.011
        objs.append(create_cylinder(
            f"TSC_CenterConsole_Knob_{side_lbl}",
            (kx, ky, kz), radius=0.0145, depth=0.016, axis="Z", segments=28,
            material=mats["knurled_dark"], parent=parent, bevel=0.002,
            rotation=(0.0, -slope_pitch, 0.0),
        ))
        objs.append(create_cylinder(
            f"TSC_CenterConsole_KnobCap_{side_lbl}",
            (kx - 0.003, ky, kz + 0.007), radius=0.011, depth=0.003, axis="Z", segments=24,
            material=mats["piano_black"], parent=parent,
            rotation=(0.0, -slope_pitch, 0.0),
        ))
    # 3 central knurled HVAC toggle rockers (TEMP L, Fan, TEMP R)
    for k, ty in enumerate((+0.036, 0.0, -0.036)):
        tx = 0.382
        tz = _console_top_z(tx) + 0.012
        objs.append(create_rounded_box(
            f"TSC_CenterConsole_HVACToggle_{k + 1}",
            (tx, ty, tz), (0.016, 0.022, 0.018),
            material=mats["piano_black"], parent=parent, bevel_width=0.0025,
            rotation=(0.0, -slope_pitch, 0.0),
        ))
        objs.append(create_rounded_box(
            f"TSC_CenterConsole_HVACToggleTop_{k + 1}",
            (tx - 0.003, ty, tz + 0.009), (0.009, 0.020, 0.004),
            material=mats["knurled_dark"], parent=parent, bevel_width=0.001,
            rotation=(0.0, -slope_pitch, 0.0),
        ))

    # ------------------------------------------------------------------
    # 4. Gloss Piano-Black Sloped Console Deck + Flanking Trim Wings
    # ------------------------------------------------------------------
    objs.append(create_rounded_box(
        "TSC_CenterConsole_PianoDeck",
        (0.245, 0.0, _console_top_z(0.245) + 0.001),
        (0.320, 0.205, 0.012),
        material=mats["piano_black"], parent=parent, bevel_width=0.004,
        rotation=(0.0, -slope_pitch, 0.0),
    ))

    # ------------------------------------------------------------------
    # 5. Stubby 992 PDK Toggle Shifter + Satin Turbonite Bezel + P/M Buttons
    # ------------------------------------------------------------------
    # Turbonite oval-rectangular bezel framing the shifter bay
    sh_x0, sh_x1 = 0.165, 0.342
    sh_y = 0.040
    bez_pts = []
    for x in np.linspace(sh_x1, sh_x0, 10):
        bez_pts.append((float(x), +sh_y, _console_top_z(float(x)) + 0.010))
    for ang in np.linspace(0.0, math.pi, 10):
        bx = sh_x0 - 0.012 * math.sin(ang)
        by = sh_y * math.cos(ang)
        bez_pts.append((bx, by, _console_top_z(bx) + 0.010))
    for x in np.linspace(sh_x0, sh_x1, 10):
        bez_pts.append((float(x), -sh_y, _console_top_z(float(x)) + 0.010))
    for ang in np.linspace(math.pi, 2.0 * math.pi, 10):
        bx = sh_x1 - 0.010 * math.sin(ang)
        by = sh_y * math.cos(ang)
        bez_pts.append((bx, by, _console_top_z(bx) + 0.010))
    objs.append(create_stitch_line(
        "TSC_PDK_Selector_Bezel", bez_pts, mats["turbonite"], parent=parent, radius=0.0052,
    ))

    # Matte inner plate inside shifter bezel
    objs.append(create_rounded_box(
        "TSC_PDK_Selector_BasePlate",
        (0.252, 0.0, _console_top_z(0.252) + 0.008),
        (0.185, 0.072, 0.009),
        material=mats["trim_dark"], parent=parent, bevel_width=0.003,
        rotation=(0.0, -slope_pitch, 0.0),
    ))

    # Iconic Stubby 992 PDK Toggle Shifter ('electric shaver' nub!)
    sx = 0.296
    sz = _console_top_z(sx) + 0.036
    # Stem collar
    objs.append(create_rounded_box(
        "TSC_PDK_Selector_Stem",
        (sx, 0.0, sz - 0.016),
        (0.026, 0.032, 0.024),
        material=mats["trim_dark"], parent=parent, bevel_width=0.004,
        rotation=(0.0, -slope_pitch * 0.5, 0.0),
    ))
    # Main piano-black toggle body
    objs.append(create_rounded_box(
        "TSC_PDK_Selector_Toggle",
        (sx - 0.004, 0.0, sz + 0.008),
        (0.024, 0.042, 0.046),
        material=mats["piano_black"], parent=parent, bevel_width=0.005,
        rotation=(0.0, math.radians(-12.0), 0.0),
    ))
    # Knurled dark metallic top grip cap
    objs.append(create_rounded_box(
        "TSC_PDK_Selector_TopGrip",
        (sx - 0.008, 0.0, sz + 0.029),
        (0.020, 0.038, 0.009),
        material=mats["knurled_dark"], parent=parent, bevel_width=0.0025,
        rotation=(0.0, math.radians(-12.0), 0.0),
    ))
    # Lit white R / N / D dots on driver-facing vertical face of toggle
    for k, dz_dot in enumerate((+0.014, +0.005, -0.004)):
        objs.append(create_rounded_box(
            f"TSC_PDK_Selector_RND_{k}",
            (sx - 0.017, 0.0, sz + dz_dot),
            (0.002, 0.006, 0.004),
            material=mats["white_led"], parent=parent, bevel_width=0.0005,
            rotation=(0.0, math.radians(-12.0), 0.0),
        ))

    # Flush 'P' (Park) and 'M' (Manual) buttons aft of PDK toggle
    for lbl, bx in (("P", 0.236), ("M", 0.200)):
        bz = _console_top_z(bx) + 0.013
        objs.append(create_rounded_box(
            f"TSC_PDK_Selector_Btn_{lbl}",
            (bx, 0.0, bz),
            (0.028, 0.052, 0.006),
            material=mats["trim_dark"], parent=parent, bevel_width=0.002,
            rotation=(0.0, -slope_pitch, 0.0),
        ))
        objs.append(create_rounded_box(
            f"TSC_PDK_Selector_LED_{lbl}",
            (bx - 0.001, 0.0, bz + 0.0035),
            (0.006, 0.008, 0.0012),
            material=mats["white_led"], parent=parent, bevel_width=0.0003,
            rotation=(0.0, -slope_pitch, 0.0),
        ))

    # ------------------------------------------------------------------
    # 6. Cabriolet Roof Open/Close, Wind Deflector & Heated Seat Switches
    # ------------------------------------------------------------------
    # Twin Roof Open / Close switches directly behind shifter bezel (photo 47!)
    for lbl, ry in (("RoofOpen", +0.022), ("RoofClose", -0.022)):
        rx = 0.132
        rz = _console_top_z(rx) + 0.010
        objs.append(create_rounded_box(
            f"TSC_CenterConsole_Switch_{lbl}",
            (rx, ry, rz), (0.026, 0.036, 0.009),
            material=mats["trim_dark"], parent=parent, bevel_width=0.0025,
            rotation=(0.0, -slope_pitch, 0.0),
        ))
        objs.append(create_rounded_box(
            f"TSC_CenterConsole_Icon_{lbl}",
            (rx - 0.001, ry, rz + 0.005), (0.005, 0.014, 0.0012),
            material=mats["white_led"], parent=parent, bevel_width=0.0003,
            rotation=(0.0, -slope_pitch, 0.0),
        ))
    # Wide Wind-Deflector button behind roof switches
    wdx = 0.104
    wdz = _console_top_z(wdx) + 0.010
    objs.append(create_rounded_box(
        "TSC_CenterConsole_Switch_WindDeflector",
        (wdx, 0.0, wdz), (0.024, 0.076, 0.009),
        material=mats["trim_dark"], parent=parent, bevel_width=0.0025,
        rotation=(0.0, -slope_pitch, 0.0),
    ))
    # Flanking Left & Right Heated/Ventilated Seat switches
    for lbl, sy in (("SeatHeatL", +0.068), ("SeatHeatR", -0.068)):
        sx_h = 0.104
        sz_h = _console_top_z(sx_h) + 0.009
        objs.append(create_rounded_box(
            f"TSC_CenterConsole_Switch_{lbl}",
            (sx_h, sy, sz_h), (0.028, 0.024, 0.008),
            material=mats["piano_black"], parent=parent, bevel_width=0.002,
            rotation=(0.0, -slope_pitch, 0.0),
        ))

    # ------------------------------------------------------------------
    # 7. Matte Carbon Fiber U-Surround + Recessed Cupholder Well + (P) Park Brake
    # ------------------------------------------------------------------
    # Left & Right Matte Carbon Fiber wings flanking the cupholder & rear console (crop_47_console!)
    for side_lbl, sgn in (("L", +1.0), ("R", -1.0)):
        objs.append(create_rounded_box(
            f"TSC_CenterConsole_CarbonWing_{side_lbl}",
            (0.032, sgn * 0.082, _console_top_z(0.032) + 0.005),
            (0.168, 0.036, 0.011),
            material=mats["carbon"], parent=parent, bevel_width=0.003,
            rotation=(0.0, -slope_pitch * 0.85, 0.0),
        ))
    # Rear matte carbon bridge behind cupholder framing the (P) electronic parking brake
    objs.append(create_rounded_box(
        "TSC_CenterConsole_CarbonRear",
        (-0.038, 0.0, 0.453),
        (0.044, 0.196, 0.012),
        material=mats["carbon"], parent=parent, bevel_width=0.004,
    ))
    # Recessed Cupholder / Storage Well (real recessed cavity with dark walls & rubber pad floor!)
    cup_x, cup_z = 0.025, 0.435
    objs.append(create_rounded_box(
        "TSC_CenterConsole_CupholderFloor",
        (cup_x, 0.0, cup_z - 0.048),
        (0.095, 0.118, 0.012),
        material=mats["rubber"], parent=parent, bevel_width=0.003,
    ))
    # 4 inner walls of cupholder recess
    objs.append(create_rounded_box(
        "TSC_CenterConsole_CupholderWallF",
        (cup_x + 0.050, 0.0, cup_z - 0.015), (0.012, 0.125, 0.068),
        material=mats["trim_dark"], parent=parent, bevel_width=0.003,
    ))
    objs.append(create_rounded_box(
        "TSC_CenterConsole_CupholderWallR",
        (cup_x - 0.048, 0.0, cup_z - 0.018), (0.012, 0.125, 0.060),
        material=mats["trim_dark"], parent=parent, bevel_width=0.003,
    ))
    for side_lbl, sgn in (("L", +1.0), ("R", -1.0)):
        objs.append(create_rounded_box(
            f"TSC_CenterConsole_CupholderWall_{side_lbl}",
            (cup_x, sgn * 0.060, cup_z - 0.018), (0.105, 0.012, 0.062),
            material=mats["trim_dark"], parent=parent, bevel_width=0.003,
        ))

    # Electronic Parking Brake '(P)' switch at aft lip of cupholder
    objs.append(create_rounded_box(
        "TSC_CenterConsole_ParkBrake",
        (-0.034, 0.0, 0.461),
        (0.028, 0.046, 0.008),
        material=mats["piano_black"], parent=parent, bevel_width=0.0025,
    ))
    objs.append(create_rounded_box(
        "TSC_CenterConsole_ParkBrakeLED",
        (-0.034, 0.0, 0.4655),
        (0.007, 0.012, 0.0012),
        material=mats["white_led"], parent=parent, bevel_width=0.0003,
    ))

    # ------------------------------------------------------------------
    # 8. Padded Turbonite-Stitched Leather Center Armrest + Rear Console Bridge
    # ------------------------------------------------------------------
    objs.append(create_rounded_box(
        "TSC_CenterConsole_ArmrestLid",
        (-0.262, 0.0, 0.484),
        (0.388, 0.184, 0.056),
        material=mats["leather"], parent=parent, bevel_width=0.018,
    ))
    # Turbonite double contrast stitch seams along armrest left & right borders
    for side_lbl, sgn in (("L", +1.0), ("R", -1.0)):
        arm_pts = [
            (-0.440, sgn * 0.078, 0.511),
            (-0.260, sgn * 0.078, 0.5125),
            (-0.082, sgn * 0.078, 0.511),
        ]
        objs.append(create_stitch_line(
            f"TSC_CenterConsole_ArmrestStitch_{side_lbl}", arm_pts, mats["stitch"], parent=parent, radius=0.0014,
        ))

    # Rear-seat center console bridge cushion (between 2+2 rear seats, matching photo 48 & 49!)
    objs.append(create_rounded_box(
        "TSC_CenterConsole_RearBridge",
        (-0.710, 0.0, 0.468),
        (0.490, 0.172, 0.052),
        material=mats["leather"], parent=parent, bevel_width=0.016,
        rotation=(0.0, math.radians(-3.0), 0.0),
    ))
    for side_lbl, sgn in (("L", +1.0), ("R", -1.0)):
        rb_pts = [
            (-0.940, sgn * 0.070, 0.506),
            (-0.710, sgn * 0.072, 0.494),
            (-0.480, sgn * 0.074, 0.482),
        ]
        objs.append(create_stitch_line(
            f"TSC_CenterConsole_RearStitch_{side_lbl}", rb_pts, mats["stitch"], parent=parent, radius=0.0013,
        ))

    # 4 Red-Accent Seatbelt Buckle Receivers (2 front inner + 2 rear inner, visible in photos 44, 48, 49!)
    buckles = [
        ("FL", -0.175, +0.118, 0.415, -18.0),
        ("FR", -0.175, -0.118, 0.415, -18.0),
        ("RL", -0.745, +0.106, 0.425, -24.0),
        ("RR", -0.745, -0.106, 0.425, -24.0),
    ]
    for b_lbl, bx, by, bz, pitch_d in buckles:
        objs.append(create_rounded_box(
            f"TSC_CenterConsole_BuckleBody_{b_lbl}",
            (bx, by, bz), (0.048, 0.022, 0.068),
            material=mats["trim_dark"], parent=parent, bevel_width=0.004,
            rotation=(0.0, math.radians(pitch_d), 0.0),
        ))
        objs.append(create_rounded_box(
            f"TSC_CenterConsole_BuckleRed_{b_lbl}",
            (bx + 0.012, by, bz + 0.028), (0.022, 0.017, 0.020),
            material=mats["red_accent"], parent=parent, bevel_width=0.003,
            rotation=(0.0, math.radians(pitch_d), 0.0),
        ))

    return objs
