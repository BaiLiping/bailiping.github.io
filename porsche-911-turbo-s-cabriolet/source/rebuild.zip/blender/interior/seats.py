"""
18-Way Adaptive Sport Seats Plus (Front L/R), 2+2 Sculpted Rear Seats,
Debossed 'turbo S' Headrests, Finished Sculpted Dark-Grey Seatback Shells,
and Turbonite-Taupe Front & Rear Seatbelts.

Calibrated strictly against 4K studio photos (44), (45), (46), (48), (49), (52), (53), (54).
"""

import math
import numpy as np
from . import config as C
from .geom_utils import (
    create_quad_grid,
    create_solidified_grid,
    create_rounded_box,
    create_textured_quad,
    create_stitch_line,
)


def _build_closed_cushion(name: str, grid_top, depth_z: float, material, parent, uv_repeat=(1.0, 1.0)):
    """Build a watertight cushion shell from an upper (Nx, Ny, 3) surface extruded strictly DOWN in -Z."""
    arr = np.asarray(grid_top, dtype=np.float64)
    nx, ny, _ = arr.shape
    # Closed ring per X station: top surface (j=0..ny-1) -> bottom surface (j=ny-1..0)
    ring = np.zeros((nx, 2 * ny, 3), dtype=np.float64)
    for i in range(nx):
        for j in range(ny):
            ring[i, j] = arr[i, j]
            p_bot = arr[i, ny - 1 - j].copy()
            # Keep bottom flat near seat pan, gently tucked at edges
            p_bot[2] = min(p_bot[2] - 0.022, arr[i, ny // 2, 2] - depth_z)
            ring[i, ny + j] = p_bot
    return create_quad_grid(
        name, ring, material=material, parent=parent,
        cyclic_u=False, cyclic_v=True, cap_u0=True, cap_u1=True,
        smooth=True, recalc_normals=True, uv_repeat=uv_repeat,
    )


def _build_front_seat(side: str, yc: float, parent, mats: dict, cfg: dict) -> list:
    """
    Build one complete 18-Way Adaptive Sport Seat Plus centered at Y = yc.
    Front headrest peaks at X = -0.455, Z = 1.108 (measured from photo 46 & 44!).
    """
    objs = []
    sgn = +1.0 if side == "L" else -1.0
    z_floor = cfg["Z_FLOOR"]

    # ------------------------------------------------------------------
    # 1. Structural Under-Seat Frame, Slide Rails & 18-Way Power Switch Pod
    # ------------------------------------------------------------------
    for r_lbl, dy in (("Out", sgn * 0.175), ("In", -sgn * 0.175)):
        objs.append(create_rounded_box(
            f"TSC_Seat_Front_Rail_{side}_{r_lbl}",
            (-0.020, yc + dy, z_floor + 0.016),
            (0.460, 0.036, 0.030),
            material=mats["trim_dark"], parent=parent, bevel_width=0.004,
        ))
    objs.append(create_rounded_box(
        f"TSC_Seat_Front_BasePan_{side}",
        (0.005, yc, z_floor + 0.056),
        (0.440, 0.445, 0.052),
        material=mats["trim_dark"], parent=parent, bevel_width=0.012,
    ))
    objs.append(create_rounded_box(
        f"TSC_Seat_Front_SwitchValance_{side}",
        (-0.010, yc + sgn * 0.238, z_floor + 0.088),
        (0.365, 0.032, 0.072),
        material=mats["trim_dark"], parent=parent, bevel_width=0.010,
    ))
    objs.append(create_rounded_box(
        f"TSC_Seat_Front_PowerSwitch1_{side}",
        (0.025, yc + sgn * 0.256, z_floor + 0.090),
        (0.068, 0.012, 0.016),
        material=mats["knurled_dark"], parent=parent, bevel_width=0.003,
    ))
    objs.append(create_rounded_box(
        f"TSC_Seat_Front_PowerSwitch2_{side}",
        (-0.055, yc + sgn * 0.256, z_floor + 0.095),
        (0.022, 0.012, 0.044),
        material=mats["knurled_dark"], parent=parent, bevel_width=0.003,
        rotation=(0.0, math.radians(-18.0), 0.0),
    ))

    # ------------------------------------------------------------------
    # 2. Sculpted Bottom Cushion (TSC_Seat_Cushion_F* — watertight, extruded DOWN in -Z!)
    # ------------------------------------------------------------------
    nx_c, ny_c = 18, 22
    xs_c = np.linspace(-0.220, +0.232, nx_c)
    vs_c = np.linspace(-1.0, +1.0, ny_c)
    c_grid = np.zeros((nx_c, ny_c, 3), dtype=np.float64)
    for i, x in enumerate(xs_c):
        t = (x - (-0.220)) / (0.232 - (-0.220))
        z_base = 0.278 + 0.056 * t - 0.026 * (max(0.0, t - 0.80) / 0.20) ** 2
        half_w = 0.246 + 0.010 * math.sin(math.pi * t) - 0.016 * (t ** 2)
        for j, v in enumerate(vs_c):
            av = abs(v)
            y = yc + v * half_w
            bolster = 0.0
            if av > 0.54:
                bt = (av - 0.54) / 0.46
                bolster = 0.068 * math.sin(math.pi * min(1.0, bt * 0.92)) * (0.65 + 0.35 * math.sin(math.pi * t))
                if bt > 0.78:
                    bolster -= 0.052 * ((bt - 0.78) / 0.22) ** 1.6
            c_grid[i, j] = (x, y, z_base + bolster)
    objs.append(_build_closed_cushion(
        f"TSC_Seat_Cushion_F{side}", c_grid, depth_z=0.048,
        material=mats["leather"], parent=parent,
    ))

    # Perforated Leather Center Cushion Insert sitting cleanly +4 mm ABOVE cushion top!
    nx_p, ny_p = 16, 12
    xs_p = np.linspace(-0.195, +0.208, nx_p)
    vs_p = np.linspace(-1.0, +1.0, ny_p)
    p_grid = np.zeros((nx_p, ny_p, 3), dtype=np.float64)
    for i, x in enumerate(xs_p):
        t = (x - (-0.220)) / (0.232 - (-0.220))
        z_base = 0.283 + 0.056 * t - 0.022 * (max(0.0, t - 0.80) / 0.20) ** 2
        rib = -0.0025 * (math.sin(4.0 * math.pi * t) ** 8)
        hw_ins = 0.134 + 0.008 * t
        for j, v in enumerate(vs_p):
            y = yc + v * hw_ins
            p_grid[i, j] = (x, y, z_base + 0.004 * (v * v) + rib)
    objs.append(create_quad_grid(
        f"TSC_Seat_Cushion_Insert_F{side}", p_grid,
        material=mats["perforated"], parent=parent, uv_repeat=(1.6, 1.2),
    ))
    # 3 crisp horizontal non-perforated stitch channels on cushion insert
    for k in range(3):
        t_r = 0.24 + k * 0.24
        xr = -0.220 + t_r * (0.232 - (-0.220))
        zr = 0.285 + 0.056 * t_r
        r_pts = [(xr, yc + vv * 0.130, zr + 0.003 * (vv * vv)) for vv in np.linspace(-0.95, 0.95, 10)]
        objs.append(create_stitch_line(
            f"TSC_Seat_Cushion_Rib_F{side}_{k + 1}", r_pts, mats["leather"], parent=parent, radius=0.0028,
        ))

    # Contrast Turbonite stitch lines cleanly proud on left & right thigh bolster crests
    for b_lbl, bsgn in (("Out", sgn), ("In", -sgn)):
        st_pts = []
        for x in np.linspace(-0.195, +0.200, 16):
            t = (x - (-0.220)) / (0.232 - (-0.220))
            half_w = 0.246 + 0.010 * math.sin(math.pi * t) - 0.016 * (t ** 2)
            z_b = 0.281 + 0.056 * t + 0.068 * (0.65 + 0.35 * math.sin(math.pi * t))
            st_pts.append((float(x), yc + bsgn * (half_w * 0.78), z_b))
        objs.append(create_stitch_line(
            f"TSC_Seat_Cushion_Stitch_F{side}_{b_lbl}", st_pts, mats["stitch"], parent=parent, radius=0.0016,
        ))

    # ------------------------------------------------------------------
    # 3. Watertight Contoured Sport Seat Plus Backrest + Smooth Domed Headrest
    # ------------------------------------------------------------------
    def back_spine(u):
        x = -0.200 - 0.255 * u - 0.022 * math.sin(math.pi * u)
        z = 0.325 + 0.783 * u
        if u < 0.62:
            t = u / 0.62
            hw = 0.242 - 0.012 * math.sin(math.pi * t) + 0.022 * (t ** 2)
        elif u < 0.78:
            t = (u - 0.62) / 0.16
            s = t * t * (3.0 - 2.0 * t)
            hw = 0.264 * (1.0 - s) + 0.126 * s
        else:
            t = (u - 0.78) / 0.22
            # Broad smooth rounded Porsche headrest crown (NO pointy tent peak!)
            cap_t = max(0.0, (t - 0.62) / 0.38)
            hw = 0.126 * (1.0 - 0.22 * t) * ((1.0 - 0.78 * (cap_t ** 2.6)) ** 0.45)
        return x, z, hw

    def front_surface_pt(u, v):
        xc, zc, hw = back_spine(u)
        wrap_amp = 0.112 * math.sin(math.pi * min(1.0, u / 0.74)) if u < 0.74 else 0.014 * (1.0 - (u - 0.74) / 0.26)
        lumbar = 0.018 * math.sin(math.pi * min(1.0, u / 0.55)) if u < 0.55 else 0.0
        head_nod = 0.020 * math.sin(math.pi * max(0.0, (u - 0.74) / 0.26)) if u > 0.74 else 0.0
        av = abs(v)
        y = yc + v * hw
        bolster_fwd = 0.0
        if av > 0.43:
            bt = (av - 0.43) / 0.57
            bolster_fwd = wrap_amp * math.sin(math.pi * min(1.0, bt * 0.85))
            if bt > 0.82:
                bolster_fwd -= 0.026 * ((bt - 0.82) / 0.18) ** 1.5
        xf = xc + lumbar + head_nod + bolster_fwd - 0.008 * (v * v)
        # Gentle flat-rounded arch across top headrest edge (zero center pinch!)
        crown_round = 0.007 * (1.0 - av ** 2.5) * max(0.0, (u - 0.88) / 0.12)
        zf = zc + crown_round
        return xf, y, zf

    def back_surface_pt(u, v):
        xc, zc, hw = back_spine(u)
        av = abs(v)
        y = yc + v * hw
        crown_taper = ((1.0 - 0.82 * (max(0.0, (u - 0.86) / 0.14) ** 2.4)) ** 0.5)
        thick = (0.088 - 0.026 * (u ** 1.2)) * crown_taper
        spine_bump = -0.016 * math.exp(-0.5 * (v / 0.42) ** 2) * crown_taper
        edge_tuck = 0.040 * (av ** 2.4) * crown_taper
        xb = xc - thick + spine_bump + edge_tuck
        crown_round = 0.007 * (1.0 - av ** 2.5) * max(0.0, (u - 0.88) / 0.12)
        zf = zc + crown_round
        return xb, y, zf

    # Build ONE watertight closed backrest leather body (front + side edges + smooth domed top cap!)
    nu_b, nv_half = 36, 16
    us_b = np.linspace(0.0, 1.0, nu_b)
    vs_f = np.linspace(-1.0, +1.0, nv_half)
    vs_r = np.linspace(+1.0, -1.0, nv_half)[1:-1]  # return along rear face (strictly non-duplicate endpoints!)
    n_ring = len(vs_f) + len(vs_r)
    body_ring = np.zeros((nu_b, n_ring, 3), dtype=np.float64)

    for i, u in enumerate(us_b):
        for j, v in enumerate(vs_f):
            body_ring[i, j] = front_surface_pt(float(u), float(v))
        for k, v in enumerate(vs_r):
            xb, yb, zb = back_surface_pt(float(u), float(v))
            # Slightly inset leather body rear face by 3 mm so hard seatback shell wraps cleanly outside it!
            body_ring[i, len(vs_f) + k] = (xb + 0.004, yb, zb)

    objs.append(create_quad_grid(
        f"TSC_Seat_Front_BackLeather_{side}", body_ring,
        material=mats["leather"], parent=parent,
        cyclic_u=False, cyclic_v=True, cap_u0=True, cap_u1=True,
        smooth=True, recalc_normals=True,
    ))

    # Sculpted Dark-Grey Hard Seatback Shell hugging rear half of backrest (clearly visible in 44, 45, 49, 53!)
    nu_sh, nv_sh = 30, 18
    us_sh = np.linspace(0.03, 0.94, nu_sh)
    vs_sh = np.linspace(-0.92, +0.92, nv_sh)
    sh_grid = np.zeros((nu_sh, nv_sh, 3), dtype=np.float64)
    for i, u in enumerate(us_sh):
        for j, v in enumerate(vs_sh):
            xb, yb, zb = back_surface_pt(float(u), float(v))
            sh_grid[i, j] = (xb - 0.002, yb, zb)
    objs.append(create_quad_grid(
        f"TSC_Seat_Front_BackShell_{side}", sh_grid,
        material=mats["seatback_shell"], parent=parent,
        smooth=True, recalc_normals=True, flip_faces=True,
    ))

    # Perforated Leather Center Backrest Insert cleanly +5 mm PROUD on front backrest surface!
    nu_i, nv_i = 26, 14
    us_i = np.linspace(0.06, 0.68, nu_i)
    vs_i = np.linspace(-1.0, +1.0, nv_i)
    ins_grid = np.zeros((nu_i, nv_i, 3), dtype=np.float64)
    for i, u in enumerate(us_i):
        t = (u - 0.06) / (0.68 - 0.06)
        arch = math.sqrt(max(0.14, 1.0 - max(0.0, (t - 0.80) / 0.20) ** 2))
        v_max = 0.50 * arch
        rib = -0.0028 * (math.sin(5.0 * math.pi * t) ** 10)
        for j, sv in enumerate(vs_i):
            v = sv * v_max
            xf, yf, zf = front_surface_pt(float(u), float(v))
            ins_grid[i, j] = (xf + 0.005 + rib, yf, zf)
    objs.append(create_quad_grid(
        f"TSC_Seat_Front_BackInsert_{side}", ins_grid,
        material=mats["perforated"], parent=parent,
        recalc_normals=False, flip_faces=True, uv_repeat=(1.6, 1.4),
    ))

    # 5 Crisp Smooth Horizontal Leather Rib Channels across the perforated center insert (photo 48!)
    for k in range(5):
        u_rib = 0.14 + k * 0.104
        t_k = (u_rib - 0.06) / (0.68 - 0.06)
        arch = math.sqrt(max(0.14, 1.0 - max(0.0, (t_k - 0.80) / 0.20) ** 2))
        v_span = 0.49 * arch
        r_pts = []
        for sv in np.linspace(-1.0, +1.0, 12):
            xf, yf, zf = front_surface_pt(u_rib, sv * v_span)
            r_pts.append((xf + 0.0072, yf, zf))
        objs.append(create_stitch_line(
            f"TSC_Seat_Front_Rib_{side}_{k + 1}", r_pts, mats["leather"], parent=parent, radius=0.0036,
        ))

    # Seamless curved transparent-alpha debossed 'turbo S' headrest lettering conforming to headrest curve!
    nu_hl, nv_hl = 5, 11
    hl_grid = np.zeros((nv_hl, nu_hl, 3), dtype=np.float64)
    for i_v, sv in enumerate(np.linspace(-0.62, +0.62, nv_hl)):
        for j_u, su in enumerate(np.linspace(0.80, 0.915, nu_hl)):
            xh, yh, zh = front_surface_pt(float(su), float(sv))
            hl_grid[i_v, j_u] = (xh + 0.0028, yh, zh)
    objs.append(create_quad_grid(
        f"TSC_Seat_Front_HeadrestLogo_{side}", hl_grid,
        material=mats["headrest_turbos"], parent=parent,
        smooth=True, recalc_normals=False, flip_faces=False, uv_grid=True, uv_repeat=(1.0, 1.0),
    ))

    # One continuous smooth rounded Turbonite contrast stitch tracing bolster -> rounded headrest arch -> bolster!
    loop_pts = []
    for u in np.linspace(0.05, 0.91, 24):
        xf, yf, zf = front_surface_pt(float(u), -0.78)
        loop_pts.append((xf + 0.0022, yf, zf))
    # Rounded headrest crown arc (smoothly blends sides over top with zero square corners!)
    for ang in np.linspace(0.0, math.pi, 18):
        u_a = 0.91 + 0.055 * math.sin(ang)
        v_a = -0.78 * math.cos(ang)
        xf, yf, zf = front_surface_pt(u_a, v_a)
        loop_pts.append((xf + 0.0022, yf, zf))
    for u in np.linspace(0.91, 0.05, 24):
        xf, yf, zf = front_surface_pt(float(u), +0.78)
        loop_pts.append((xf + 0.0022, yf, zf))
    objs.append(create_stitch_line(
        f"TSC_Seat_Front_BackStitch_{side}", loop_pts, mats["stitch"], parent=parent, radius=0.0012,
    ))

    # Outer shoulder leather seatbelt guide loop tab (photo 48!)
    x_sh, y_sh, z_sh = front_surface_pt(0.65, sgn * 0.96)
    objs.append(create_rounded_box(
        f"TSC_Seat_Front_BeltLoop_{side}",
        (x_sh - 0.012, y_sh + sgn * 0.012, z_sh),
        (0.028, 0.022, 0.044),
        material=mats["leather"], parent=parent, bevel_width=0.005,
    ))

    # ------------------------------------------------------------------
    # 4. Turbonite-Taupe Front Seatbelt Webbing + Metallic Tongue (photos 44, 45, 48, 49!)
    # ------------------------------------------------------------------
    belt_path = np.array([
        [-0.545, sgn * 0.670, 0.880],
        [-0.470, sgn * 0.652, 0.790],
        [-0.415, sgn * 0.635, 0.640],
        [-0.375, sgn * 0.630, 0.455],
        [-0.345, sgn * 0.638, 0.255],
    ], dtype=np.float64)
    b_grid = np.zeros((len(belt_path), 4, 3), dtype=np.float64)
    w_belt = 0.024
    for i, pt in enumerate(belt_path):
        b_grid[i, 0] = pt + np.array([-w_belt, 0.0, 0.0])
        b_grid[i, 1] = pt + np.array([+w_belt, 0.0, 0.0])
        b_grid[i, 2] = pt + np.array([+w_belt, -sgn * 0.003, 0.0])
        b_grid[i, 3] = pt + np.array([-w_belt, -sgn * 0.003, 0.0])
    objs.append(create_quad_grid(
        f"TSC_SeatBelt_Front_{side}", b_grid,
        material=mats["seatbelt"], parent=parent, cyclic_v=True, cap_u0=True, cap_u1=True,
    ))
    objs.append(create_rounded_box(
        f"TSC_SeatBelt_Tongue_Front_{side}",
        (-0.398, sgn * 0.626, 0.560),
        (0.064, 0.014, 0.036),
        material=mats["brushed_alu"], parent=parent, bevel_width=0.003,
    ))
    objs.append(create_rounded_box(
        f"TSC_SeatBelt_TongueGrip_Front_{side}",
        (-0.402, sgn * 0.625, 0.576),
        (0.068, 0.018, 0.024),
        material=mats["trim_dark"], parent=parent, bevel_width=0.004,
    ))

    return objs


def _build_rear_seats(parent, mats: dict, cfg: dict) -> list:
    """Build sculpted 2+2 Cabriolet rear seats, perforated 5-ribbed backrests & Turbonite rear belts."""
    objs = []

    for side, sgn in (("L", +1.0), ("R", -1.0)):
        yc = sgn * C.SEAT_REAR_Y

        # 1. Rear Sculpted Bucket Cushion (watertight, extruded down in -Z!)
        nx_r, ny_r = 14, 14
        xs_r = np.linspace(-0.925, -0.575, nx_r)
        vs_r = np.linspace(-1.0, +1.0, ny_r)
        rc_grid = np.zeros((nx_r, ny_r, 3), dtype=np.float64)
        for i, x in enumerate(xs_r):
            t = (x - (-0.925)) / ((-0.575) - (-0.925))
            z_base = 0.285 + 0.072 * (t ** 1.2) - 0.015 * (max(0.0, t - 0.85) / 0.15) ** 2
            hw = 0.220 + 0.012 * t
            rib = -0.003 * (math.sin(3.0 * math.pi * t) ** 8)
            for j, v in enumerate(vs_r):
                y = yc + v * hw
                dish = 0.032 * (v * v)
                rc_grid[i, j] = (x, y, z_base + dish + rib)
        objs.append(_build_closed_cushion(
            f"TSC_Seat_Rear_Cushion_{side}", rc_grid, depth_z=0.045,
            material=mats["leather"], parent=parent,
        ))
        # 3 subtle dark seam grooves on rear cushion matching photo (49)!
        for k in range(3):
            t_k = 0.24 + k * 0.24
            xk = -0.925 + t_k * ((-0.575) - (-0.925))
            zk = 0.287 + 0.072 * (t_k ** 1.2)
            r_pts = [(xk, yc + vv * 0.205, zk + 0.030 * (vv * vv)) for vv in np.linspace(-0.95, 0.95, 10)]
            objs.append(create_stitch_line(
                f"TSC_Seat_Rear_CushionRib_{side}_{k + 1}", r_pts, mats["leather_dark"], parent=parent, radius=0.0018,
            ))

        # 2. Split-Folding Rear Seatback Outer Leather Shell (solidified REARWARD in -X!)
        nu_rb, nv_rb = 16, 16
        us_rb = np.linspace(0.0, 1.0, nu_rb)
        vs_rb = np.linspace(-1.0, +1.0, nv_rb)
        rb_ring = np.zeros((nu_rb, 2 * nv_rb - 2, 3), dtype=np.float64)
        for i, u in enumerate(us_rb):
            xc = -0.922 - 0.082 * u
            zc = 0.340 + 0.562 * u
            hw = 0.250 - 0.015 * u
            for j, v in enumerate(vs_rb):
                y = yc + v * hw
                bolster = 0.024 * (v * v) * (1.0 - 0.35 * u)
                rb_ring[i, j] = (xc + bolster, y, zc)
            for k, v in enumerate(vs_rb[-2:0:-1]):
                y = yc + v * hw
                rb_ring[i, nv_rb + k] = (xc - 0.044, y, zc)
        objs.append(create_quad_grid(
            f"TSC_Seat_Rear_Back_{side}", rb_ring,
            material=mats["leather"], parent=parent,
            cyclic_u=False, cyclic_v=True, cap_u0=True, cap_u1=True,
        ))

        # 3. Perforated Rear Backrest Center Insert + 5 Crisp Horizontal Ribs (crop_48_rear_seats!)
        nu_ri, nv_ri = 16, 12
        us_ri = np.linspace(0.08, 0.92, nu_ri)
        vs_ri = np.linspace(-1.0, +1.0, nv_ri)
        ri_grid = np.zeros((nu_ri, nv_ri, 3), dtype=np.float64)
        for i, u in enumerate(us_ri):
            t = (u - 0.08) / 0.84
            xc = -0.922 - 0.082 * u
            zc = 0.340 + 0.562 * u
            rib = -0.0025 * (math.sin(5.0 * math.pi * t) ** 10)
            for j, v in enumerate(vs_ri):
                y = yc + v * 0.165
                bolster = 0.024 * ((v * 0.66) ** 2) * (1.0 - 0.35 * u)
                ri_grid[i, j] = (xc + bolster + 0.0045 + rib, y, zc)
        objs.append(create_quad_grid(
            f"TSC_Seat_Rear_BackInsert_{side}", ri_grid,
            material=mats["perforated"], parent=parent,
            recalc_normals=False, flip_faces=True, uv_repeat=(1.6, 1.4),
        ))
        for k in range(5):
            u_r = 0.18 + k * 0.14
            xc = -0.922 - 0.082 * u_r
            zc = 0.340 + 0.562 * u_r
            r_pts = [(xc + 0.024 * ((vv * 0.66) ** 2) * (1.0 - 0.35 * u_r) + 0.0068, yc + vv * 0.162, zc)
                     for vv in np.linspace(-0.96, 0.96, 10)]
            objs.append(create_stitch_line(
                f"TSC_Seat_Rear_Rib_{side}_{k + 1}", r_pts, mats["leather"], parent=parent, radius=0.0032,
            ))

        # 4. Turbonite Rear Seatbelt draping from upper outer shoulder down into rear cushion (photos 48, 49, 44!)
        rb_path = np.array([
            [-0.995, sgn * 0.555, 0.895],
            [-0.935, sgn * 0.550, 0.745],
            [-0.875, sgn * 0.542, 0.570],
            [-0.815, sgn * 0.530, 0.415],
            [-0.780, sgn * 0.515, 0.320],
        ], dtype=np.float64)
        rbg = np.zeros((len(rb_path), 4, 3), dtype=np.float64)
        wb = 0.023
        for i, pt in enumerate(rb_path):
            rbg[i, 0] = pt + np.array([0.0, -wb, 0.0])
            rbg[i, 1] = pt + np.array([0.0, +wb, 0.0])
            rbg[i, 2] = pt + np.array([-0.003, +wb, 0.0])
            rbg[i, 3] = pt + np.array([-0.003, -wb, 0.0])
        objs.append(create_quad_grid(
            f"TSC_SeatBelt_Rear_{side}", rbg,
            material=mats["seatbelt"], parent=parent, cyclic_v=True, cap_u0=True, cap_u1=True,
        ))
        objs.append(create_rounded_box(
            f"TSC_SeatBelt_Tongue_Rear_{side}",
            (-0.835, sgn * 0.534, 0.458),
            (0.016, 0.056, 0.036),
            material=mats["brushed_alu"], parent=parent, bevel_width=0.003,
            rotation=(0.0, math.radians(-22.0), 0.0),
        ))
        objs.append(create_rounded_box(
            f"TSC_SeatBelt_TongueGrip_Rear_{side}",
            (-0.842, sgn * 0.534, 0.474),
            (0.020, 0.060, 0.022),
            material=mats["trim_dark"], parent=parent, bevel_width=0.004,
            rotation=(0.0, math.radians(-22.0), 0.0),
        ))

    # Central vertical leather bolster strip between split rear seatbacks
    objs.append(create_rounded_box(
        "TSC_Seat_Rear_CenterDivider",
        (-0.960, 0.0, 0.625),
        (0.065, 0.145, 0.555),
        material=mats["leather"], parent=parent, bevel_width=0.016,
        rotation=(0.0, math.radians(-8.5), 0.0),
    ))

    return objs


def build_seats(parent, mats: dict, cfg: dict) -> list:
    objs = []
    objs.extend(_build_front_seat("L", cfg["Y_DRIVER"], parent, mats, cfg))
    objs.extend(_build_front_seat("R", cfg["Y_PASSENGER"], parent, mats, cfg))
    objs.extend(_build_rear_seats(parent, mats, cfg))
    return objs
