"""
Main entrypoint for the 2026 Porsche 911 Turbo S Cabriolet (992.2 T-Hybrid) Cabin & Interior.

Contract (per blender/exterior/contract.md and web/rig_contract.md):
    build(rig_root: bpy.types.Object, cfg: dict | None = None) -> dict[str, bpy.types.Object]

Coordinate system: 1:1 real-world METERS in Blender Z-up (+X fwd, +Y left/driver, +Z up;
X=0 mid-axle, Y=0 centerline, Z=0 ground plane).

Hierarchy:
  - All cockpit geometry placed under `Pivot_Interior_Cabin` (origin (0,0,0) under rig_root).
  - Detailed inner door cards placed under `Pivot_Door_L` and `Pivot_Door_R` (when present under
    rig_root or passed via cfg) so door trim swings cleanly with exterior doors and zero Z-fighting.
"""

import bpy
from .config import merge_cfg
from .geom_utils import ensure_empty
from .materials import create_interior_materials
from .dashboard import build_dashboard
from .steering import build_steering_wheel
from .console import build_console
from .seats import build_seats
from .cabin_trim import build_cabin_trim
from .door_cards import build_door_cards as _build_door_cards_impl


def _find_pivot(rig_root, name: str, cfg: dict | None = None):
    if cfg and name in cfg and isinstance(cfg[name], bpy.types.Object):
        return cfg[name]
    obj = bpy.data.objects.get(name)
    if obj is not None:
        return obj
    if rig_root is not None:
        for ch in rig_root.children_recursive:
            if ch.name == name:
                return ch
    return None


def build_door_cards(door_l, door_r, cfg: dict | None = None) -> list:
    """Public helper to attach photo-matched inner door cards to Pivot_Door_L and Pivot_Door_R."""
    icfg = merge_cfg(cfg)
    mats = create_interior_materials()
    return _build_door_cards_impl(door_l, door_r, mats, icfg)


def build(rig_root: bpy.types.Object, cfg: dict | None = None) -> dict:
    """
    Build the complete 992.2 Turbo S Cabriolet interior under Pivot_Interior_Cabin
    (plus inner door cards under Pivot_Door_L / Pivot_Door_R when present).

    Returns dict[str, bpy.types.Object] mapping pivot & key mesh names to Blender objects.
    """
    icfg = merge_cfg(cfg)
    mats = create_interior_materials()

    pivot_cabin = ensure_empty("Pivot_Interior_Cabin", location=(0.0, 0.0, 0.0), parent=rig_root)

    all_objs = []
    all_objs.extend(build_dashboard(pivot_cabin, mats, icfg))
    all_objs.extend(build_steering_wheel(pivot_cabin, mats, icfg))
    all_objs.extend(build_console(pivot_cabin, mats, icfg))
    all_objs.extend(build_seats(pivot_cabin, mats, icfg))
    all_objs.extend(build_cabin_trim(pivot_cabin, mats, icfg))

    # Attach detailed inner door cards to Pivot_Door_L / Pivot_Door_R so they hinge with doors
    door_l = _find_pivot(rig_root, "Pivot_Door_L", cfg)
    door_r = _find_pivot(rig_root, "Pivot_Door_R", cfg)
    if door_l is not None or door_r is not None:
        all_objs.extend(_build_door_cards_impl(door_l, door_r, mats, icfg))
    else:
        # Fallback if invoked completely standalone without exterior door pivots
        all_objs.extend(_build_door_cards_impl(pivot_cabin, pivot_cabin, mats, icfg))

    result = {"Pivot_Interior_Cabin": pivot_cabin}
    if door_l is not None:
        result["Pivot_Door_L"] = door_l
    if door_r is not None:
        result["Pivot_Door_R"] = door_r
    for ob in all_objs:
        result[ob.name] = ob
    return result
