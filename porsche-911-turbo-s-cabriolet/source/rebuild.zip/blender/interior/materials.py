"""
Standardized PBR & Textured Materials for the 2026 Porsche 911 Turbo S Cabriolet Interior.
All material names strictly honor web/rig_contract.md Section 3:
  - Mat_Cabin_Rearview (EXACT name for Three.js live planar mirror reflection)
  - Mat_Turbonite_Alloy (shared satin dark bronze-titanium Turbonite)
  - Mat_Cabin_* (viewer automatically applies 8x texture anisotropy)
"""

import bpy
from .textures import generate_all_textures


def _srgb_to_linear(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def hex_rgba(hex_str: str, alpha: float = 1.0):
    h = hex_str.lstrip("#")
    r = _srgb_to_linear(int(h[0:2], 16) / 255.0)
    g = _srgb_to_linear(int(h[2:4], 16) / 255.0)
    b = _srgb_to_linear(int(h[4:6], 16) / 255.0)
    return (r, g, b, alpha)


def _reset_material_nodes(mat: bpy.types.Material):
    """Ensure clean Principled BSDF -> Material Output node tree when upgrading placeholder materials."""
    nt = mat.node_tree
    nt.nodes.clear()
    out_node = nt.nodes.new("ShaderNodeOutputMaterial")
    out_node.location = (300, 0)
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (0, 0)
    nt.links.new(bsdf.outputs["BSDF"], out_node.inputs["Surface"])
    return bsdf


def make_pbr(
    name: str,
    hex_color: str,
    metallic: float = 0.0,
    roughness: float = 0.5,
    coat_weight: float = 0.0,
    coat_roughness: float = 0.08,
    specular_ior: float = 0.4,
    emission_hex: str = None,
    emission_strength: float = 0.0,
    overwrite: bool = True,
) -> bpy.types.Material:
    if name in bpy.data.materials:
        mat = bpy.data.materials[name]
        if not overwrite:
            return mat
        bsdf = _reset_material_nodes(mat)
    else:
        mat = bpy.data.materials.new(name)
        bsdf = _reset_material_nodes(mat)
    col = hex_rgba(hex_color, 1.0)
    mat.diffuse_color = col
    bsdf.inputs["Base Color"].default_value = col
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = roughness
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = specular_ior
    if "Coat Weight" in bsdf.inputs and coat_weight > 0.0:
        bsdf.inputs["Coat Weight"].default_value = coat_weight
        bsdf.inputs["Coat Roughness"].default_value = coat_roughness
    if emission_hex is not None and emission_strength > 0.0:
        bsdf.inputs["Emission Color"].default_value = hex_rgba(emission_hex, 1.0)
        bsdf.inputs["Emission Strength"].default_value = emission_strength
    return mat


def _load_packed_image(filepath: str) -> bpy.types.Image:
    for img in bpy.data.images:
        if img.filepath == filepath:
            img.reload()
            try:
                img.pack()
            except Exception:
                pass
            return img
    img = bpy.data.images.load(filepath, check_existing=True)
    try:
        img.pack()
    except Exception:
        pass
    return img


def make_textured_pbr(
    name: str,
    filepath: str,
    metallic: float = 0.0,
    roughness: float = 0.4,
    coat_weight: float = 0.0,
    coat_roughness: float = 0.06,
    emission_strength: float = 0.0,
    uv_scale=(1.0, 1.0),
    specular_ior: float = 0.4,
    alpha_blend: bool = False,
    overwrite: bool = True,
) -> bpy.types.Material:
    if name in bpy.data.materials:
        mat = bpy.data.materials[name]
        if not overwrite:
            return mat
        bsdf = _reset_material_nodes(mat)
    else:
        mat = bpy.data.materials.new(name)
        bsdf = _reset_material_nodes(mat)
    nt = mat.node_tree
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = roughness
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = specular_ior
    if "Coat Weight" in bsdf.inputs and coat_weight > 0.0:
        bsdf.inputs["Coat Weight"].default_value = coat_weight
        bsdf.inputs["Coat Roughness"].default_value = coat_roughness

    tex_node = nt.nodes.new("ShaderNodeTexImage")
    tex_node.image = _load_packed_image(filepath)
    tex_node.location = (-360, 260)

    if uv_scale != (1.0, 1.0):
        tc = nt.nodes.new("ShaderNodeTexCoord")
        tc.location = (-780, 260)
        mp = nt.nodes.new("ShaderNodeMapping")
        mp.location = (-580, 260)
        mp.inputs["Scale"].default_value = (uv_scale[0], uv_scale[1], 1.0)
        nt.links.new(tc.outputs["UV"], mp.inputs["Vector"])
        nt.links.new(mp.outputs["Vector"], tex_node.inputs["Vector"])

    nt.links.new(tex_node.outputs["Color"], bsdf.inputs["Base Color"])
    if alpha_blend:
        nt.links.new(tex_node.outputs["Alpha"], bsdf.inputs["Alpha"])
        if hasattr(mat, "blend_method"):
            mat.blend_method = "BLEND"
        if hasattr(mat, "surface_render_method"):
            mat.surface_render_method = "BLENDED"
    if emission_strength > 0.0:
        nt.links.new(tex_node.outputs["Color"], bsdf.inputs["Emission Color"])
        bsdf.inputs["Emission Strength"].default_value = emission_strength
    return mat


def create_interior_materials() -> dict:
    """Create and return the full interior material palette calibrated to 4K studio photos (47)-(49)."""
    tex = generate_all_textures(force=False)
    mats = {}

    # 1. Smooth Black/Slate Leather (calibrated to bright studio AgX/ACESFilmic lighting matching photos 47/48/49)
    mats["leather"] = make_pbr(
        "Mat_Cabin_Leather_Black", "#25272b",
        metallic=0.0, roughness=0.52, specular_ior=0.36,
    )
    # Slightly darker leather for dash lower / side skirts / console tunnel
    mats["leather_dark"] = make_pbr(
        "Mat_Cabin_Leather_Dark", "#1a1c20",
        metallic=0.0, roughness=0.56, specular_ior=0.30,
    )
    # Smooth painted/composite dark-grey sculpted front seatback shell (matching photo 49!)
    mats["seatback_shell"] = make_pbr(
        "Mat_Cabin_Seatback_Shell", "#2c2f35",
        metallic=0.08, roughness=0.34, coat_weight=0.28, coat_roughness=0.20, specular_ior=0.46,
    )
    # Perforated Leather Seat & Door Center Inserts
    mats["perforated"] = make_textured_pbr(
        "Mat_Cabin_Seat_Insert", tex["leather_perforated.png"],
        metallic=0.0, roughness=0.66, uv_scale=(5.0, 5.0), specular_ior=0.26,
    )
    # Headrest with seamless transparent debossed 'turbo S' lettering
    mats["headrest_turbos"] = make_textured_pbr(
        "Mat_Cabin_Headrest_TurboS", tex["headrest_turbos.png"],
        metallic=0.0, roughness=0.52, specular_ior=0.34, alpha_blend=True,
    )
    # Matte 2x2 Twill Carbon Fiber Inlays (dash shelf, console U-surround, door trim strip)
    mats["carbon"] = make_textured_pbr(
        "Mat_Cabin_Matte_Carbon", tex["carbon_twill_matte.png"],
        metallic=0.22, roughness=0.34, coat_weight=0.28, coat_roughness=0.18, uv_scale=(3.0, 3.0),
    )
    # Satin Turbonite Metallic Trim (preserve shared Mat_Turbonite_Alloy if exterior/mechanicals already created it)
    mats["turbonite"] = make_pbr(
        "Mat_Turbonite_Alloy", "#6b6458",
        metallic=0.82, roughness=0.28, coat_weight=0.20, coat_roughness=0.16,
        overwrite=False,
    )
    # Turbonite Contrast Stitching thread (refined taupe-bronze thread matching photos 47/48!)
    mats["stitch"] = make_pbr(
        "Mat_Cabin_Stitch_Turbonite", "#7d7465",
        metallic=0.0, roughness=0.68, specular_ior=0.22,
    )
    # Turbonite Seatbelt Webbing (warm taupe-champagne matching photos 48, 49, 44, 45!)
    mats["seatbelt"] = make_pbr(
        "Mat_Cabin_Seatbelt_Turbonite", "#a89f8d",
        metallic=0.0, roughness=0.78, specular_ior=0.18,
    )
    # Carpet & Floor Mats (deep charcoal-slate automotive velour)
    mats["carpet"] = make_pbr(
        "Mat_Cabin_Carpet", "#1d1f24",
        metallic=0.0, roughness=0.92, specular_ior=0.12,
    )
    mats["floor_mat"] = make_pbr(
        "Mat_Cabin_FloorMat", "#181a20",
        metallic=0.0, roughness=0.88, specular_ior=0.14,
    )
    # Gloss Piano Black (center console deck, shifter vertical face, screen bezels, mirror housing)
    mats["piano_black"] = make_pbr(
        "Mat_Cabin_Piano_Black", "#0d0f12",
        metallic=0.05, roughness=0.10, coat_weight=0.88, coat_roughness=0.04, specular_ior=0.65,
    )
    # Matte Dark Soft-Touch Trim (A-pillars, windshield header, vents, stalks, speaker frames, switches)
    mats["trim_dark"] = make_pbr(
        "Mat_Cabin_Trim_Dark", "#1d1f23",
        metallic=0.02, roughness=0.64, specular_ior=0.28,
    )
    # Fine Speaker Grille Mesh (doors & rear quarter panels)
    mats["speaker_mesh"] = make_pbr(
        "Mat_Cabin_Speaker_Mesh", "#16181c",
        metallic=0.25, roughness=0.62, specular_ior=0.25,
    )
    # Brushed Aluminum / Stainless (pedals, shift paddles, toggle accents, seatbelt tongues)
    mats["brushed_alu"] = make_pbr(
        "Mat_Cabin_Brushed_Aluminum", "#adb3bc",
        metallic=0.90, roughness=0.26, specular_ior=0.60,
    )
    # Dark Knurled Metal (rotary dials, shifter top grip, switch borders)
    mats["knurled_dark"] = make_pbr(
        "Mat_Cabin_Knurled_Metal", "#45484e",
        metallic=0.78, roughness=0.38,
    )
    # Black Rubber (pedal grip ribs, cupholder base pad, seals)
    mats["rubber"] = make_pbr(
        "Mat_Cabin_Rubber", "#151618",
        metallic=0.0, roughness=0.82, specular_ior=0.18,
    )
    # Red Accents (Sport Response button, seatbelt release latches, hazard triangle)
    mats["red_accent"] = make_pbr(
        "Mat_Cabin_Red_Accent", "#d62426",
        metallic=0.06, roughness=0.28, coat_weight=0.45,
        emission_hex="#d62426", emission_strength=0.25,
    )
    # Green AUTO Headlight indicator LED
    mats["green_led"] = make_pbr(
        "Mat_Cabin_LED_Green", "#34d662",
        metallic=0.0, roughness=0.25, emission_hex="#34d662", emission_strength=1.4,
    )
    # White Backlit Switch Icon LED
    mats["white_led"] = make_pbr(
        "Mat_Cabin_LED_White", "#e8eef5",
        metallic=0.0, roughness=0.25, emission_hex="#e8eef5", emission_strength=0.95,
    )
    # Subtle Cool-Blue Ambient Footwell / Door-Pocket Glow (visible in photo 47!)
    mats["ambient_blue"] = make_pbr(
        "Mat_Cabin_Ambient_Blue", "#3a62c8",
        metallic=0.0, roughness=0.30, emission_hex="#4672e8", emission_strength=1.1,
    )

    # EXACT CONTRACT MATERIAL: Interior Rearview Mirror Glass (Three.js live planar mirror!)
    mats["rearview"] = make_pbr(
        "Mat_Cabin_Rearview", "#d4dce4",
        metallic=0.96, roughness=0.03, coat_weight=0.95, coat_roughness=0.02, specular_ior=0.90,
    )

    # Textured Emissive Displays & Badges
    mats["cluster_screen"] = make_textured_pbr(
        "Mat_Cabin_DigitalCluster", tex["cluster_992_2_turbos.png"],
        metallic=0.02, roughness=0.08, coat_weight=0.85, coat_roughness=0.03,
        emission_strength=1.15,
    )
    mats["pcm_screen"] = make_textured_pbr(
        "Mat_Cabin_PCMScreen", tex["pcm_911_turbos.png"],
        metallic=0.02, roughness=0.08, coat_weight=0.85, coat_roughness=0.03,
        emission_strength=1.05,
    )
    mats["chrono_face"] = make_textured_pbr(
        "Mat_Cabin_SportChrono", tex["sport_chrono_face.png"],
        metallic=0.05, roughness=0.14, coat_weight=0.85, coat_roughness=0.04,
        emission_strength=0.35,
    )
    mats["crest_turbonite"] = make_textured_pbr(
        "Mat_Cabin_PorscheCrest", tex["porsche_crest_turbonite.png"],
        metallic=0.72, roughness=0.28, coat_weight=0.30, alpha_blend=True,
    )
    mats["climate_bar"] = make_textured_pbr(
        "Mat_Cabin_ClimateBar", tex["console_climate_bar.png"],
        metallic=0.04, roughness=0.10, coat_weight=0.85, emission_strength=0.95,
    )
    mats["sill_plate"] = make_textured_pbr(
        "Mat_Cabin_DoorSill_TurboS", tex["sill_turbos_plate.png"],
        metallic=0.72, roughness=0.28, emission_strength=0.38,
    )
    mats["dash_badge"] = make_textured_pbr(
        "Mat_Cabin_DashBadge_TurboS", tex["dash_turbos_badge.png"],
        metallic=0.10, roughness=0.48,
    )
    mats["visor_decal"] = make_textured_pbr(
        "Mat_Cabin_VisorDecal", tex["visor_airbag_decal.png"],
        metallic=0.0, roughness=0.65,
    )

    return mats
