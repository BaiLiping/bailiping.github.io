"""
992.2 Porsche 911 Turbo S Cabriolet Dashboard, 12.6" Curved Digital Cluster,
10.9" PCM Display, Hooded Sport Chrono, Matte Carbon Shelf, Turbonite Trim & Push-Button Start.
"""

import math
import numpy as np
from . import config as C
from .geom_utils import (
    create_quad_grid,
    create_solidified_grid,
    create_rounded_box,
    create_cylinder,
    create_textured_quad,
    create_stitch_line,
)


def _dash_upper_profile(y: float, u: float):
    """
    Evaluate (x, z) on the sculpted 992.2 upper leather dashboard surface.
    y in [-0.735, +0.735], u in [0.0 (windshield cowl) .. 1.0 (driver-facing brow lip)].
    """
    ay = abs(y)
    # Windshield cowl edge curves rearward toward outer A-pillars (matches exterior X_COWL_CENTER/SIDE)
    t_side = min(1.0, (ay / 0.72) ** 2)
    x_front = 0.785 - 0.115 * t_side
    z_front = 0.823 + 0.010 * t_side

    # Front-facing brow lip X & Z
    # Driver cluster binnacle hood centered at Y_DRIVER (+0.355), width ~0.39 m
    d_clust = (y - C.Y_DRIVER) / 0.205
    clust_hood = math.exp(-0.5 * (d_clust ** 4)) if abs(d_clust) < 1.6 else 0.0
    # Subtle smooth dome crest
    clust_dome = math.exp(-0.5 * ((y - C.Y_DRIVER) / 0.18) ** 2)

    x_brow = 0.448 - 0.028 * clust_hood + 0.022 * t_side
    z_brow = 0.862 + 0.044 * clust_dome + 0.014 * t_side

    # Smooth longitudinal profile from cowl (u=0) -> mid-crown -> brow lip (u=1) -> tucked lip underside
    if u <= 0.82:
        t = u / 0.82
        x = x_front + (x_brow - x_front) * t
        # Gentle crown rise across top of dash
        crown = 0.024 * math.sin(math.pi * t) * (1.0 - 0.35 * t_side) + 0.015 * clust_dome * (t ** 1.5)
        z = z_front + (z_brow - z_front) * (t ** 0.85) + crown
    else:
        # Rounded brow nose turning neatly underneath to seal top of PCM/cluster recess
        t = (u - 0.82) / 0.18
        ang = t * math.pi * 0.92
        x = x_brow - 0.010 * math.sin(ang) + 0.036 * (1.0 - math.cos(ang)) * 0.5
        z = z_brow - 0.016 * (1.0 - math.cos(ang)) * 0.5 - 0.010 * t
    return x, z


def build_dashboard(parent, mats: dict, cfg: dict) -> list:
    objs = []

    # ------------------------------------------------------------------
    # 1. Upper Sculpted Leather Dashboard + Turbonite Double Brow Stitch
    # ------------------------------------------------------------------
    ny, nu = 54, 20
    ys = np.linspace(-0.735, +0.735, ny)
    us = np.linspace(0.0, 1.0, nu)
    grid = np.zeros((ny, nu, 3), dtype=np.float64)
    for i, y in enumerate(ys):
        for j, u in enumerate(us):
            x, z = _dash_upper_profile(float(y), float(u))
            grid[i, j] = (x, y, z)
    objs.append(create_solidified_grid(
        "TSC_Dash_UpperLeather", grid, thickness=0.016,
        material=mats["leather"], parent=parent, offset=-1.0,
    ))

    # Double contrast Turbonite stitching cleanly ON TOP of solidified upper leather brow lip (photo 47!)
    for idx_s, u_st in enumerate((0.765, 0.800)):
        pts = []
        for y in np.linspace(-0.71, +0.71, 60):
            x, z = _dash_upper_profile(float(y), u_st)
            pts.append((x - 0.002, float(y), z + 0.0175))
        objs.append(create_stitch_line(
            f"TSC_Dash_BrowStitch_{idx_s + 1}", pts, mats["stitch"], parent=parent, radius=0.0014,
        ))

    # ------------------------------------------------------------------
    # 2. Inner Recessed Dash Backplane (clears curved 12.6" cluster & PCM cleanly!)
    # ------------------------------------------------------------------
    ny_b, nz_b = 32, 12
    ys_b = np.linspace(-0.730, +0.730, ny_b)
    zs_b = np.linspace(0.420, 0.875, nz_b)
    bgrid = np.zeros((ny_b, nz_b, 3), dtype=np.float64)
    for i, y in enumerate(ys_b):
        t_side = min(1.0, (abs(y) / 0.72) ** 2)
        for j, z in enumerate(zs_b):
            if z >= 0.725:
                # Recessed strictly forward (+X = 0.568) behind curved digital cluster & PCM!
                x = 0.568 - 0.032 * t_side + 0.015 * ((z - 0.725) / 0.15)
            else:
                t_low = (0.725 - z) / 0.305
                x = 0.472 + 0.165 * (t_low ** 1.35) - 0.025 * t_side
            bgrid[i, j] = (x, y, z)
    objs.append(create_solidified_grid(
        "TSC_Dash_LowerBacking", bgrid, thickness=0.014,
        material=mats["leather_dark"], parent=parent, offset=+1.0,
    ))

    # ------------------------------------------------------------------
    # 3. 992.2 Freestanding Curved 12.6" Digital Instrument Cluster
    # ------------------------------------------------------------------
    cx, cy, cz = 0.512, C.CLUSTER_Y, C.CLUSTER_Z
    cw, ch = C.CLUSTER_WIDTH, C.CLUSTER_HEIGHT
    tilt_rad = math.radians(10.0)
    dx_top = math.sin(tilt_rad) * (ch * 0.5)
    dz_top = math.cos(tilt_rad) * (ch * 0.5)

    # Explicit watertight curved piano-black housing strictly BEHIND (+X of) the display screen
    n_cu = 24
    ch_ring = np.zeros((n_cu, 4, 3), dtype=np.float64)
    hh = (ch + 0.016) * 0.5
    for i in range(n_cu):
        u = i / float(n_cu - 1)
        y = cy + (0.5 - u) * (cw + 0.018)
        sag = -0.020 * (4.0 * (u - 0.5) ** 2)  # 0 at center, -0.020 at left/right edges
        xf_bot = cx + 0.005 + sag - dx_top
        xf_top = cx + 0.005 + sag + dx_top
        ch_ring[i, 0] = (xf_bot, y, cz - hh)
        ch_ring[i, 1] = (xf_top, y, cz + hh)
        ch_ring[i, 2] = (xf_top + 0.018, y, cz + hh)
        ch_ring[i, 3] = (xf_bot + 0.018, y, cz - hh)
    objs.append(create_quad_grid(
        "TSC_DigitalCluster_Housing", ch_ring,
        material=mats["piano_black"], parent=parent,
        cyclic_u=False, cyclic_v=True, cap_u0=True, cap_u1=True,
    ))

    # Active curved 12.6" OLED display screen cleanly 5 mm IN FRONT (-X) of housing, 100% unobstructed!
    bl = (cx - 0.020 - dx_top, cy + cw * 0.5, cz - dz_top)
    br = (cx - 0.020 - dx_top, cy - cw * 0.5, cz - dz_top)
    tr = (cx - 0.020 + dx_top, cy - cw * 0.5, cz + dz_top)
    tl = (cx - 0.020 + dx_top, cy + cw * 0.5, cz + dz_top)
    objs.append(create_textured_quad(
        "TSC_DigitalCluster_Screen", [bl, br, tr, tl],
        material=mats["cluster_screen"], parent=parent,
        subdiv_u=24, subdiv_v=4, curve_sag_x=-0.020,
    ))

    # ------------------------------------------------------------------
    # 4. 10.9" Center PCM Display (flush in dash recess, shows "911 Turbo S")
    # ------------------------------------------------------------------
    px, py, pz = C.PCM_X, -0.018, C.PCM_Z
    pw, ph = C.PCM_WIDTH, C.PCM_HEIGHT
    p_tilt = math.radians(8.0)
    pdx = math.sin(p_tilt) * (ph * 0.5)
    pdz = math.cos(p_tilt) * (ph * 0.5)

    # Flush piano-black glass bezel surround
    objs.append(create_rounded_box(
        "TSC_PCMScreen_Bezel",
        (px + 0.008, py, pz),
        (0.018, pw + 0.022, ph + 0.018),
        material=mats["piano_black"], parent=parent,
        bevel_width=0.004, rotation=(0.0, p_tilt, 0.0),
    ))
    # Crisp active PCM touchscreen quad facing driver (-X)
    p_bl = (px - pdx - 0.002, py + pw * 0.5, pz - pdz)
    p_br = (px - pdx - 0.002, py - pw * 0.5, pz - pdz)
    p_tr = (px + pdx - 0.002, py - pw * 0.5, pz + pdz)
    p_tl = (px + pdx - 0.002, py + pw * 0.5, pz + pdz)
    objs.append(create_textured_quad(
        "TSC_PCMScreen_Display", [p_bl, p_br, p_tr, p_tl],
        material=mats["pcm_screen"], parent=parent,
        subdiv_u=4, subdiv_v=2,
    ))

    # ------------------------------------------------------------------
    # 5. Horizontal Matte Carbon Fiber Shelf + Satin Turbonite Trim + 'turbo S' Badge
    # ------------------------------------------------------------------
    # Main center-to-passenger carbon shelf (Y = -0.680 .. +0.135)
    ny_s = 28
    ys_s = np.linspace(-0.685, +0.138, ny_s)
    s_grid = np.zeros((ny_s, 4, 3), dtype=np.float64)
    for i, y in enumerate(ys_s):
        t_side = max(0.0, (-y - 0.25) / 0.45) ** 2
        x_back = 0.515 - 0.020 * t_side
        x_edge = 0.442 + 0.020 * t_side
        z_sh = 0.728 + 0.008 * t_side
        s_grid[i, 0] = (x_back, y, z_sh + 0.004)
        s_grid[i, 1] = (x_edge, y, z_sh)
        s_grid[i, 2] = (x_edge + 0.006, y, z_sh - 0.015)
        s_grid[i, 3] = (x_back, y, z_sh - 0.016)
    objs.append(create_quad_grid(
        "TSC_Dash_CarbonShelf_R", s_grid,
        material=mats["carbon"], parent=parent,
        cyclic_u=False, cyclic_v=True, cap_u0=True, cap_u1=True,
        uv_repeat=(4.0, 0.8),
    ))

    # Left driver-side carbon shelf stub under left vent (Y = +0.525 .. +0.690)
    objs.append(create_rounded_box(
        "TSC_Dash_CarbonShelf_L",
        (0.478, +0.608, 0.732),
        (0.068, 0.165, 0.016),
        material=mats["carbon"], parent=parent, bevel_width=0.003,
    ))

    # Continuous Satin Turbonite accent lip below carbon shelf + wrapping UP outer vents
    turb_pts_r = []
    for y in np.linspace(+0.138, -0.685, 28):
        t_side = max(0.0, (-y - 0.25) / 0.45) ** 2
        x_edge = 0.438 + 0.020 * t_side
        z_sh = 0.713 + 0.008 * t_side
        turb_pts_r.append((x_edge, float(y), z_sh))
    # Wrap cleanly upward around outer passenger vent!
    turb_pts_r.extend([
        (0.464, -0.704, 0.726),
        (0.474, -0.710, 0.768),
        (0.472, -0.708, 0.822),
    ])
    objs.append(create_stitch_line(
        "TSC_Dash_TurboniteTrim_R", turb_pts_r, mats["turbonite"], parent=parent, radius=0.0065,
    ))

    # Matching driver-side outer Turbonite trim wrapping left vent
    turb_pts_l = [
        (0.445, +0.525, 0.716),
        (0.452, +0.625, 0.718),
        (0.464, +0.695, 0.728),
        (0.474, +0.708, 0.770),
        (0.472, +0.706, 0.824),
    ]
    objs.append(create_stitch_line(
        "TSC_Dash_TurboniteTrim_L", turb_pts_l, mats["turbonite"], parent=parent, radius=0.0065,
    ))

    # Passenger-side recessed leather trim plaque with italic Turbonite 'turbo S' script (photo 47!)
    objs.append(create_textured_quad(
        "TSC_Dash_TurboSBadge_R",
        [
            (0.494, -0.175, 0.742),
            (0.498, -0.535, 0.746),
            (0.506, -0.535, 0.788),
            (0.502, -0.175, 0.784),
        ],
        material=mats["dash_badge"], parent=parent,
    ))

    # ------------------------------------------------------------------
    # 6. Top-Center Recessed Sport Chrono Pod & Dual Louvered Defroster Vents
    # ------------------------------------------------------------------
    # Contour Sport Chrono surround tray & flanking dual vents cleanly ON TOP of solidified upper leather!
    # (TSC_Dash_UpperLeather solidifies upward by +0.016 m, so flush top surface sits at zt + 0.016)
    ny_t, nu_t = 18, 8
    ys_t = np.linspace(-0.185, +0.185, ny_t)
    us_t = np.linspace(0.24, 0.66, nu_t)
    t_grid = np.zeros((ny_t, nu_t, 3), dtype=np.float64)
    for i, yt in enumerate(ys_t):
        for j, ut in enumerate(us_t):
            xt, zt = _dash_upper_profile(float(yt), float(ut))
            t_grid[i, j] = (xt, yt, zt + 0.0175)
    objs.append(create_quad_grid(
        "TSC_SportChrono_Tray", t_grid,
        material=mats["trim_dark"], parent=parent,
    ))

    # Dual symmetrical matte-dark flanking louvered top dash vents conforming to dash surface!
    for side_lbl, y0, y1 in (("L", +0.064, +0.168), ("R", -0.168, -0.064)):
        vg = np.zeros((6, 6, 3), dtype=np.float64)
        for i, yv in enumerate(np.linspace(y0, y1, 6)):
            for j, uv in enumerate(np.linspace(0.32, 0.60, 6)):
                xv, zv = _dash_upper_profile(float(yv), float(uv))
                vg[i, j] = (xv, yv, zv + 0.0190)
        objs.append(create_quad_grid(
            f"TSC_Dash_TopVentBox_{side_lbl}", vg,
            material=mats["rubber"], parent=parent,
        ))
        for k in range(6):
            uk = 0.34 + k * 0.048
            s_pts = []
            for yv in np.linspace(y0 + 0.004, y1 - 0.004, 8):
                xv, zv = _dash_upper_profile(float(yv), uk)
                s_pts.append((xv, float(yv), zv + 0.0215))
            objs.append(create_stitch_line(
                f"TSC_Dash_TopVentSlat_{side_lbl}_{k}", s_pts, mats["trim_dark"], parent=parent, radius=0.0022,
            ))

    # Forward center speaker mesh grille ahead of Sport Chrono
    sg = np.zeros((6, 4, 3), dtype=np.float64)
    for i, ys_sp in enumerate(np.linspace(-0.058, +0.058, 6)):
        for j, us_sp in enumerate(np.linspace(0.18, 0.28, 4)):
            xs_sp, zs_sp = _dash_upper_profile(float(ys_sp), float(us_sp))
            sg[i, j] = (xs_sp, ys_sp, zs_sp + 0.0190)
    objs.append(create_quad_grid(
        "TSC_Dash_CenterSpeaker", sg,
        material=mats["speaker_mesh"], parent=parent,
    ))

    # Hooded Sport Chrono stopwatch casing (integrated flush cowl, full '9:11' dial clearly visible!)
    chr_x, chr_y, chr_z = C.CHRONO_X-.020, C.CHRONO_Y, C.CHRONO_Z + 0.001
    chr_r = C.CHRONO_RADIUS
    objs.append(create_cylinder(
        "TSC_SportChrono_Hood",
        (chr_x + 0.012, chr_y, chr_z + 0.002),
        radius=chr_r + 0.011, depth=0.056, axis="X", segments=36,
        material=mats["leather"], parent=parent, bevel=0.007,
        rotation=(0.0, math.radians(8.0), 0.0),
    ))
    objs.append(create_cylinder(
        "TSC_SportChrono_Bezel",
        (chr_x - 0.010, chr_y, chr_z),
        radius=chr_r + 0.003, depth=0.018, axis="X", segments=36,
        material=mats["turbonite"], parent=parent, bevel=0.0025,
        rotation=(0.0, math.radians(8.0), 0.0),
    ))
    objs.append(create_cylinder(
        "TSC_SportChrono_Face",
        (chr_x - 0.019, chr_y, chr_z - 0.001),
        radius=chr_r - 0.001, depth=0.004, axis="X", segments=36,
        material=mats["chrono_face"], parent=parent,
        rotation=(0.0, math.radians(8.0), 0.0),
        cap_uv_face="-X",
    ))

    # ------------------------------------------------------------------
    # 7. 5 Center Tactile Toggle Switches & Twin Center + Outer HVAC Vents
    # ------------------------------------------------------------------
    # Recessed switch bar housing directly beneath PCM carbon shelf
    objs.append(create_rounded_box(
        "TSC_Dash_ToggleBar",
        (0.464, -0.012, 0.692),
        (0.028, 0.190, 0.026),
        material=mats["trim_dark"], parent=parent, bevel_width=0.003,
    ))
    for k in range(5):
        ty = 0.056 - k * 0.034
        objs.append(create_rounded_box(
            f"TSC_Dash_ToggleSwitch_{k + 1}",
            (0.448, ty, 0.692),
            (0.022, 0.024, 0.016),
            material=mats["piano_black"], parent=parent, bevel_width=0.0025,
            rotation=(0.0, math.radians(18.0), 0.0),
        ))
        # Knurled metallic lower lip on each toggle
        objs.append(create_rounded_box(
            f"TSC_Dash_ToggleLip_{k + 1}",
            (0.438, ty, 0.686),
            (0.006, 0.022, 0.005),
            material=mats["knurled_dark"], parent=parent, bevel_width=0.001,
        ))
        # Red hazard triangle accent on middle switch (#3)
        if k == 2:
            objs.append(create_rounded_box(
                "TSC_Dash_HazardIcon",
                (0.437, ty, 0.694),
                (0.003, 0.009, 0.007),
                material=mats["red_accent"], parent=parent, bevel_width=0.001,
            ))

    # Twin Center HVAC Vents directly below the 5 switches
    objs.append(create_rounded_box(
        "TSC_Dash_CenterVentFrame",
        (0.468, -0.012, 0.646),
        (0.036, 0.215, 0.044),
        material=mats["trim_dark"], parent=parent, bevel_width=0.004,
    ))
    for side_lbl, vy in (("L", +0.040), ("R", -0.064)):
        objs.append(create_rounded_box(
            f"TSC_Dash_CenterVentRecess_{side_lbl}",
            (0.474, vy, 0.646),
            (0.024, 0.092, 0.034),
            material=mats["piano_black"], parent=parent, bevel_width=0.002,
        ))
        for j in range(3):
            vz = 0.635 + j * 0.011
            objs.append(create_rounded_box(
                f"TSC_Dash_CenterVentLouver_{side_lbl}_{j}",
                (0.456, vy, vz),
                (0.018, 0.088, 0.003),
                material=mats["trim_dark"], parent=parent, bevel_width=0.0008,
            ))
        # Metallic center adjuster tab
        objs.append(create_rounded_box(
            f"TSC_Dash_CenterVentTab_{side_lbl}",
            (0.449, vy, 0.646),
            (0.010, 0.014, 0.009),
            material=mats["knurled_dark"], parent=parent, bevel_width=0.0015,
        ))

    # Left & Right Outer Trapezoidal HVAC Vents
    for side_lbl, vy, yaw in (("L", +0.628, math.radians(-12.0)), ("R", -0.628, math.radians(+12.0))):
        objs.append(create_rounded_box(
            f"TSC_Dash_OuterVentFrame_{side_lbl}",
            (0.492, vy, 0.780),
            (0.038, 0.118, 0.068),
            material=mats["trim_dark"], parent=parent, bevel_width=0.005,
            rotation=(0.0, 0.0, yaw),
        ))
        objs.append(create_rounded_box(
            f"TSC_Dash_OuterVentRecess_{side_lbl}",
            (0.498, vy, 0.780),
            (0.025, 0.104, 0.054),
            material=mats["piano_black"], parent=parent, bevel_width=0.002,
            rotation=(0.0, 0.0, yaw),
        ))
        for j in range(4):
            vz = 0.761 + j * 0.0125
            objs.append(create_rounded_box(
                f"TSC_Dash_OuterVentLouver_{side_lbl}_{j}",
                (0.478, vy, vz),
                (0.018, 0.098, 0.0032),
                material=mats["trim_dark"], parent=parent, bevel_width=0.0008,
                rotation=(0.0, 0.0, yaw),
            ))

    # ------------------------------------------------------------------
    # 8. 992.2 Left-of-Column Push-Button Start & Headlight Switch Pod
    # ------------------------------------------------------------------
    # Circular Push-Button Start (992.2 signature feature replacing old rotary dummy key!)
    sb_pos = (0.472, +0.545, 0.706)
    objs.append(create_cylinder(
        "TSC_Dash_StartButton_Ring",
        (sb_pos[0] + 0.004, sb_pos[1], sb_pos[2]),
        radius=0.0185, depth=0.012, axis="X", segments=32,
        material=mats["turbonite"], parent=parent, bevel=0.002,
    ))
    objs.append(create_cylinder(
        "TSC_Dash_StartButton_Cap",
        (sb_pos[0] - 0.002, sb_pos[1], sb_pos[2]),
        radius=0.0145, depth=0.008, axis="X", segments=32,
        material=mats["piano_black"], parent=parent, bevel=0.0018,
    ))
    objs.append(create_cylinder(
        "TSC_Dash_StartButton_LED",
        (sb_pos[0] - 0.0062, sb_pos[1], sb_pos[2]),
        radius=0.011, depth=0.0015, axis="X", segments=28,
        material=mats["white_led"], parent=parent,
    ))
    objs.append(create_cylinder(
        "TSC_Dash_StartButton_Center",
        (sb_pos[0] - 0.0068, sb_pos[1], sb_pos[2]),
        radius=0.0092, depth=0.0016, axis="X", segments=28,
        material=mats["trim_dark"], parent=parent,
    ))

    # Headlight AUTO / Rear Fog Switch Pod (clearly visible on left of wheel in photo 47!)
    objs.append(create_rounded_box(
        "TSC_Dash_LightSwitchPod",
        (0.478, +0.625, 0.688),
        (0.024, 0.095, 0.036),
        material=mats["piano_black"], parent=parent, bevel_width=0.004,
    ))
    objs.append(create_rounded_box(
        "TSC_Dash_LightSwitch_AutoLED",
        (0.465, +0.642, 0.693),
        (0.004, 0.016, 0.006),
        material=mats["green_led"], parent=parent, bevel_width=0.001,
    ))
    objs.append(create_rounded_box(
        "TSC_Dash_LightSwitch_FogLED",
        (0.465, +0.605, 0.690),
        (0.004, 0.014, 0.006),
        material=mats["white_led"], parent=parent, bevel_width=0.001,
    ))

    # ------------------------------------------------------------------
    # 9. Passenger Glovebox Lid & Lower Dash Trim
    # ------------------------------------------------------------------
    objs.append(create_rounded_box(
        "TSC_Dash_GloveboxLid",
        (0.492, -0.405, 0.618),
        (0.065, 0.490, 0.165),
        material=mats["leather"], parent=parent, bevel_width=0.014,
        rotation=(0.0, math.radians(-16.0), 0.0),
    ))
    objs.append(create_rounded_box(
        "TSC_Dash_GloveboxHandle",
        (0.456, -0.255, 0.665),
        (0.014, 0.072, 0.022),
        material=mats["trim_dark"], parent=parent, bevel_width=0.003,
    ))
    # Passenger footwell kick-panel access hatch (matching crop_47_dash_R_door_R.png!)
    objs.append(create_rounded_box(
        "TSC_Dash_PassKickHatch",
        (0.645, -0.355, 0.420),
        (0.018, 0.135, 0.165),
        material=mats["trim_dark"], parent=parent, bevel_width=0.004,
        rotation=(0.0, math.radians(-28.0), 0.0),
    ))

    return objs
