"""
Cabin Floor Carpet, Tailored Floor Mats, Brushed Aluminum Sport Pedals (8-speed PDK),
Illuminated 'turbo S' Door Sill Treadplates, Rear Quarter Trim & Speakers,
Concealed Roll-Over Protection Bar Surround, Watertight A-Pillar & Windshield Header Trim,
Sun Visors, Overhead Dome Pod, and Frameless Interior Rearview Mirror (Mat_Cabin_Rearview).
"""

import math
import numpy as np
from . import config as C
from .geom_utils import (
    create_quad_grid,
    create_solidified_grid,
    create_rounded_box,
    create_cylinder,
    create_tube_mesh,
    create_textured_quad,
    create_stitch_line,
)


def build_cabin_trim(parent, mats: dict, cfg: dict) -> list:
    objs = []
    z_floor = cfg["Z_FLOOR"]

    # ------------------------------------------------------------------
    # 1. Full Carpeted Floorpan Tub, Front Sloped Footwell & Rear Risers
    # ------------------------------------------------------------------
    # Continuous carpeted floor from rear bulkhead (-1.02) forward up sloped firewall (+0.87)
    floor_stations = [
        (-1.020, 0.345, 0.675),
        (-0.920, 0.315, 0.680),
        (-0.620, 0.275, 0.695),
        (-0.560, z_floor, 0.705),
        (-0.200, z_floor, 0.710),
        (+0.320, z_floor, 0.710),
        (+0.580, z_floor + 0.015, 0.700),
        (+0.780, z_floor + 0.145, 0.685),
        (+0.865, z_floor + 0.365, 0.670),
    ]
    n_u = len(floor_stations)
    n_v = 11
    f_grid = np.zeros((n_u, n_v, 3), dtype=np.float64)
    for i, (x, zf, hw) in enumerate(floor_stations):
        # Turn up outer sill skirts slightly to seal cleanly to inner sills
        profile = [
            (+hw + 0.012, zf + 0.095),
            (+hw, zf + 0.012),
            (+hw * 0.75, zf),
            (+hw * 0.42, zf),
            (+0.135, zf),
            (0.0, zf + 0.010),
            (-0.135, zf),
            (-hw * 0.42, zf),
            (-hw * 0.75, zf),
            (-hw, zf + 0.012),
            (-hw - 0.012, zf + 0.095),
        ]
        for j, (py, pz) in enumerate(profile):
            f_grid[i, j] = (x, py, pz)
    objs.append(create_solidified_grid(
        "TSC_Carpet_FloorTub", f_grid, thickness=0.014,
        material=mats["carpet"], parent=parent, offset=-1.0,
    ))

    # Tailored Front Floor Mats (L & R) with contrast stitched piping border
    for side, sgn in (("L", +1.0), ("R", -1.0)):
        yc = sgn * 0.405
        objs.append(create_rounded_box(
            f"TSC_Carpet_FloorMat_{side}",
            (0.365, yc, z_floor + 0.006),
            (0.560, 0.435, 0.008),
            material=mats["floor_mat"], parent=parent, bevel_width=0.004,
        ))
        # Subtle border stitch loop around floor mat
        m_pts = [
            (0.095, yc - 0.210, z_floor + 0.0105),
            (0.635, yc - 0.210, z_floor + 0.0105),
            (0.635, yc + 0.210, z_floor + 0.0105),
            (0.095, yc + 0.210, z_floor + 0.0105),
        ]
        objs.append(create_tube_mesh(
            f"TSC_Carpet_FloorMatBorder_{side}", m_pts, radius=0.0022, segments=6,
            material=mats["stitch"], parent=parent, cyclic=True,
        ))

    # ------------------------------------------------------------------
    # 2. Brushed Aluminum / Stainless Sport Pedals & Dead-Pedal Footrest (PDK only!)
    # ------------------------------------------------------------------
    # A. Wide Dead-Pedal Footrest on left driver footwell (clearly visible in photo 49!)
    dp_center = (0.715, C.PEDAL_DEAD_Y, 0.348)
    dp_rot = (0.0, math.radians(-38.0), math.radians(-8.0))
    objs.append(create_rounded_box(
        "TSC_Pedal_Footrest_Base", dp_center, (0.016, 0.088, 0.225),
        material=mats["rubber"], parent=parent, bevel_width=0.004, rotation=dp_rot,
    ))
    objs.append(create_rounded_box(
        "TSC_Pedal_Footrest_Alu", (dp_center[0] - 0.007, dp_center[1] - 0.001, dp_center[2] + 0.004),
        (0.006, 0.076, 0.205),
        material=mats["brushed_alu"], parent=parent, bevel_width=0.002, rotation=dp_rot,
    ))
    # 3 vertical black rubber grip ribs on dead-pedal footrest (matching photo 49!)
    for k, dy in enumerate((-0.022, 0.0, +0.022)):
        objs.append(create_rounded_box(
            f"TSC_Pedal_Footrest_Grip_{k + 1}",
            (dp_center[0] - 0.011, dp_center[1] + dy, dp_center[2] + 0.006),
            (0.004, 0.009, 0.180),
            material=mats["rubber"], parent=parent, bevel_width=0.001, rotation=dp_rot,
        ))

    # B. Wide PDK Brake Pedal (hanging steel arm + brushed stainless face + horizontal rubber ribs)
    bk_center = (0.690, C.PEDAL_BRAKE_Y, 0.355)
    bk_rot = (0.0, math.radians(-26.0), 0.0)
    objs.append(create_tube_mesh(
        "TSC_Pedal_Brake_Arm",
        [(0.725, C.PEDAL_BRAKE_Y, 0.560), (0.715, C.PEDAL_BRAKE_Y, 0.435), (0.698, C.PEDAL_BRAKE_Y, 0.355)],
        radius=0.010, segments=10, material=mats["trim_dark"], parent=parent,
    ))
    objs.append(create_rounded_box(
        "TSC_Pedal_Brake_Plate", bk_center, (0.012, 0.118, 0.068),
        material=mats["brushed_alu"], parent=parent, bevel_width=0.003, rotation=bk_rot,
    ))
    for k, dy in enumerate((-0.036, -0.012, +0.012, +0.036)):
        objs.append(create_rounded_box(
            f"TSC_Pedal_Brake_Grip_{k + 1}",
            (bk_center[0] - 0.007, bk_center[1] + dy, bk_center[2] + 0.002),
            (0.004, 0.011, 0.056),
            material=mats["rubber"], parent=parent, bevel_width=0.001, rotation=bk_rot,
        ))

    # C. Floor-Hinged Organ-Style Accelerator Pedal (signature Porsche 911 feature!)
    ac_center = (0.725, C.PEDAL_GAS_Y, 0.320)
    ac_rot = (0.0, math.radians(-30.0), 0.0)
    objs.append(create_rounded_box(
        "TSC_Pedal_Accel_Base", ac_center, (0.014, 0.054, 0.210),
        material=mats["rubber"], parent=parent, bevel_width=0.004, rotation=ac_rot,
    ))
    objs.append(create_rounded_box(
        "TSC_Pedal_Accel_Alu", (ac_center[0] - 0.006, ac_center[1], ac_center[2] + 0.004),
        (0.005, 0.044, 0.192),
        material=mats["brushed_alu"], parent=parent, bevel_width=0.0018, rotation=ac_rot,
    ))
    for k, dy in enumerate((-0.011, +0.011)):
        objs.append(create_rounded_box(
            f"TSC_Pedal_Accel_Grip_{k + 1}",
            (ac_center[0] - 0.0095, ac_center[1] + dy, ac_center[2] + 0.005),
            (0.0035, 0.008, 0.168),
            material=mats["rubber"], parent=parent, bevel_width=0.001, rotation=ac_rot,
        ))

    # ------------------------------------------------------------------
    # 3. Illuminated 'turbo S' Door Sill Treadplates & Inner Sill Trims (L & R)
    # ------------------------------------------------------------------
    for side, sgn in (("L", +1.0), ("R", -1.0)):
        # Watertight contoured matte dark inner sill cover sealing floor tub to outer door jamb (ZERO light leak!)
        objs.append(create_rounded_box(
            f"TSC_DoorSill_Trim_{side}",
            (0.065, sgn * 0.728, 0.232),
            (1.160, 0.110, 0.102),
            material=mats["trim_dark"], parent=parent, bevel_width=0.014,
        ))
        # Illuminated brushed dark-aluminum 'turbo S' scuff treadplate on top of sill!
        # Oriented upright reading left-to-right from outside each open door, with strict +Z WebGL normal!
        x0, x1 = -0.240, +0.370
        y_in, y_out = sgn * 0.692, sgn * 0.760
        z_pl = 0.283
        if sgn > 0:
            corners = [(x1, y_out, z_pl), (x0, y_out, z_pl), (x0, y_in, z_pl), (x1, y_in, z_pl)]
        else:
            corners = [(x0, y_out, z_pl), (x1, y_out, z_pl), (x1, y_in, z_pl), (x0, y_in, z_pl)]
        objs.append(create_textured_quad(
            f"TSC_DoorSill_TurboSPlate_{side}", corners,
            material=mats["sill_plate"], parent=parent,
        ))
        # Small frunk/engine release toggle switches on driver sill (visible bottom-left of photo 47 & 48!)
        if side == "L":
            objs.append(create_rounded_box(
                "TSC_DoorSill_LidSwitchPod",
                (0.245, +0.694, 0.286), (0.095, 0.032, 0.014),
                material=mats["piano_black"], parent=parent, bevel_width=0.003,
            ))

    # ------------------------------------------------------------------
    # 4. Rear Quarter Leather Trim Panels, Rear Speakers & Concealed Roll-Bar Rim
    # ------------------------------------------------------------------
    for side, sgn in (("L", +1.0), ("R", -1.0)):
        # Smooth contoured leather rear-quarter side panel (solidified strictly OUTWARD <= 0.765 on BOTH sides!)
        nx_q, nz_q = 18, 12
        xs_q = np.linspace(-1.035, -0.460, nx_q)
        zs_q = np.linspace(0.250, 0.925, nz_q)
        q_grid = np.zeros((nx_q, nz_q, 3), dtype=np.float64)
        for i, x in enumerate(xs_q):
            t_x = (x - (-1.035)) / ((-0.460) - (-1.035))
            z_top = 0.940 - 0.048 * t_x
            y_curve = 0.640 + 0.098 * (t_x ** 0.55)
            for j, _ in enumerate(zs_q):
                t_z = j / float(nz_q - 1)
                zz = 0.250 + (z_top - 0.250) * t_z
                y = sgn * (y_curve - 0.020 * math.sin(math.pi * t_z) + 0.016 * (t_z ** 3))
                q_grid[i, j] = (x, y, zz)
        # Ensure L and R have symmetric outward normal so solidify expands uniformly!
        if sgn < 0:
            q_grid = q_grid[:, ::-1, :]
        objs.append(create_solidified_grid(
            f"TSC_Trim_RearQuarter_{side}", q_grid, thickness=0.018,
            material=mats["leather"], parent=parent, offset=-1.0,
        ))

        # Sealed B-pillar inner jamb & front A-pillar kick panel (eliminates ALL vertical & footwell light leaks!)
        objs.append(create_rounded_box(
            f"TSC_Trim_BPillarJamb_{side}",
            (-0.472, sgn * 0.742, 0.560), (0.062, 0.044, 0.650),
            material=mats["trim_dark"], parent=parent, bevel_width=0.008,
        ))
        objs.append(create_rounded_box(
            f"TSC_Trim_FrontKickPanel_{side}",
            (0.680, sgn * 0.725, 0.455), (0.340, 0.056, 0.565),
            material=mats["carpet"], parent=parent, bevel_width=0.008,
        ))

        # Horizontal Turbonite contrast stitch line along rear-quarter panel (photo 49!)
        qs_pts = []
        for x in np.linspace(-1.015, -0.475, 16):
            t_x = (x - (-1.035)) / ((-0.460) - (-1.035))
            y_c = 0.640 + 0.098 * (t_x ** 0.55) - 0.012
            z_s = 0.805 - 0.022 * t_x
            qs_pts.append((float(x), sgn * y_c, z_s))
        objs.append(create_stitch_line(
            f"TSC_Trim_RearQuarterStitch_{side}", qs_pts, mats["stitch"], parent=parent, radius=0.0014,
        ))

        # Conformal curved Rear Quarter Speaker Mesh Grille hugging rear quarter surface cleanly (photo 49!)
        def _q_y(xq, zq):
            tx = (xq - (-1.035)) / ((-0.460) - (-1.035))
            ztop = 0.940 - 0.048 * tx
            tz = max(0.0, min(1.0, (zq - 0.250) / (ztop - 0.250)))
            yc = 0.640 + 0.098 * (tx ** 0.55)
            return yc - 0.020 * math.sin(math.pi * tz) + 0.016 * (tz ** 3)

        sp_frame = np.zeros((10, 8, 3), dtype=np.float64)
        sp_mesh = np.zeros((10, 8, 3), dtype=np.float64)
        for i_s, xs_p in enumerate(np.linspace(-0.790, -0.600, 10)):
            u_s = (i_s / 9.0) * 2.0 - 1.0  # -1..+1 along X
            # Rounded trapezoid top slope matching photo (49)!
            z_lo = 0.448 + 0.010 * (u_s * u_s)
            z_hi = 0.562 + 0.014 * u_s - 0.014 * (u_s * u_s)
            for j_s, v_s in enumerate(np.linspace(0.0, 1.0, 8)):
                zs_p = z_lo + (z_hi - z_lo) * v_s
                yq = _q_y(float(xs_p), float(zs_p))
                # Edge taper so bezel blends smoothly into rear quarter panel
                edge_bulge = math.sin(math.pi * (i_s / 9.0)) * math.sin(math.pi * v_s)
                sp_frame[i_s, j_s] = (xs_p, sgn * (yq - 0.004 - 0.004 * edge_bulge), zs_p)
                zs_m = (z_lo + 0.010) + ((z_hi - 0.010) - (z_lo + 0.010)) * v_s
                sp_mesh[i_s, j_s] = (-0.778 + (i_s / 9.0) * 0.166, sgn * (yq - 0.008 - 0.003 * edge_bulge), zs_m)
        if sgn < 0:
            sp_frame = sp_frame[:, ::-1, :]
            sp_mesh = sp_mesh[:, ::-1, :]
        objs.append(create_quad_grid(
            f"TSC_Trim_RearSpeakerFrame_{side}", sp_frame,
            material=mats["trim_dark"], parent=parent,
            recalc_normals=False, flip_faces=False,
        ))
        objs.append(create_quad_grid(
            f"TSC_Trim_RearSpeakerMesh_{side}", sp_mesh,
            material=mats["speaker_mesh"], parent=parent,
            recalc_normals=False, flip_faces=False,
        ))

        # Front seatbelt upper guide bezel tucked into B-pillar corner (photo 49 top-center!)
        objs.append(create_rounded_box(
            f"TSC_Trim_BeltBezel_{side}",
            (-0.545, sgn * 0.705, 0.885),
            (0.068, 0.044, 0.042),
            material=mats["trim_dark"], parent=parent, bevel_width=0.008,
        ))

    # Rear Cabin Bulkhead Backing Wall (seals behind rear seats so zero gaps into engine/tonneau!)
    objs.append(create_rounded_box(
        "TSC_Trim_RearBulkhead",
        (-1.045, 0.0, 0.635),
        (0.048, 1.290, 0.615),
        material=mats["carpet"], parent=parent, bevel_width=0.012,
    ))

    # A slim padded cockpit rail follows the forward edge of the tonneau.
    # The old outboard tube crossed the painted rear quarters when viewed
    # from above. The side branches land inside the inner quarter trims.
    ys = np.array([-.554,-.547,-.528,-.502,-.472,-.444,-.40,-.31,0,
                   .31,.40,.444,.472,.502,.528,.547,.554])
    ax = np.array([.00,.31,.40,.444,.472,.502,.528,.547,.554])
    rx = np.array([-1.005,-1.003,-1.0,-.985,-.96,-.893,-.811,-.733,-.690])
    rz = np.array([.974,.976,.968,.957,.946,.935,.926,.920,.915])
    rim_pts = list(zip(np.interp(abs(ys),ax,rx),ys,np.interp(abs(ys),ax,rz)))
    objs.append(create_tube_mesh(
        "TSC_RollBar_CockpitRim", rim_pts, radius=.013, segments=12,
        material=mats["leather"], parent=parent, radius_y_scale=.87,
    ))

    # Concealed Roll-Over Protection Bar Pop-Up Cassette Covers behind rear seatbacks (L & R)
    for side, sgn in (("L", +1.0), ("R", -1.0)):
        objs.append(create_rounded_box(
            f"TSC_RollBar_Cassette_{side}",
            (-1.032, sgn * 0.345, 0.945),
            (0.056, 0.285, 0.024),
            material=mats["trim_dark"], parent=parent, bevel_width=0.008,
        ))

    # ------------------------------------------------------------------
    # 5. Watertight A-Pillar Inner Trim & Windshield Header Rail (ZERO Light Leaks!)
    # ------------------------------------------------------------------
    # Locked strictly to exterior/config.py windshield perimeter:
    #   Cowl side: (+0.660, ±0.730, 0.892) -> Header corner: (+0.015, ±0.578, 1.210)
    #   Header center crown: (+0.115, 0.0, 1.258)
    for side, sgn in (("L", +1.0), ("R", -1.0)):
        ap_pts = []
        for t in np.linspace(0.0, 1.0, 16):
            # Subtle realistic windshield A-pillar bow
            x = cfg["X_COWL_SIDE"] + (cfg["X_HEADER_SIDE"] - cfg["X_COWL_SIDE"]) * t + 0.012 * math.sin(math.pi * t)
            y = sgn * (0.728 + (0.614 - 0.728) * t + 0.008 * math.sin(math.pi * t))
            z = (cfg["Z_COWL_SIDE"] - 0.018) + ((cfg["Z_HEADER_SIDE"] - 0.004) - (cfg["Z_COWL_SIDE"] - 0.018)) * t + 0.012 * math.sin(math.pi * t)
            ap_pts.append((x-.013, y-sgn*.021, z-.015))
        # Thick contoured inner pillar trim overlapping exterior's 24x32mm D-beam so zero gap exists!
        objs.append(create_tube_mesh(
            f"TSC_Trim_APillar_{side}", ap_pts, radius=0.023, segments=16,
            material=mats["trim_dark"], parent=parent, radius_y_scale=0.82,
        ))

    # Continuous Sculpted Windshield Inner Header Rail spanning L corner -> center crown -> R corner
    # Seated strictly inside exterior's Z_HEADER_CENTER=1.258 (max Z <= 1.255) with zero light leaks!
    hdr_pts = []
    for s in np.linspace(-1.0, +1.0, 26):
        x = cfg["X_HEADER_CENTER"] + (cfg["X_HEADER_SIDE"] - cfg["X_HEADER_CENTER"]) * (s * s) - 0.008
        y = s * 0.618
        z = (cfg["Z_HEADER_CENTER"] - 0.026) + ((cfg["Z_HEADER_SIDE"] - 0.016) - (cfg["Z_HEADER_CENTER"] - 0.026)) * (s * s)
        hdr_pts.append((x, y, z))
    objs.append(create_tube_mesh(
        "TSC_Trim_WindshieldHeader", hdr_pts, radius=0.030, segments=16,
        material=mats["trim_dark"], parent=parent, radius_y_scale=0.72,
    ))

    # Dual Folded Sun Visors mounted cleanly under windshield header (photo 47!)
    for side, sgn in (("L", +1.0), ("R", -1.0)):
        vx = 0.067
        vy = sgn * 0.310
        vz = 1.187
        yaw = sgn * math.radians(-11.0)
        roll = sgn * math.radians(-5.0)
        objs.append(create_rounded_box(
            f"TSC_Trim_SunVisor_{side}",
            (vx, vy, vz), (0.118, 0.345, 0.020),
            material=mats["trim_dark"], parent=parent, bevel_width=0.008,
            rotation=(roll, math.radians(-14.0), yaw),
        ))
        # Passenger sun visor EU airbag warning label (clearly visible top-right of photo 47!)
        if side == "R":
            objs.append(create_textured_quad(
                "TSC_Trim_SunVisor_AirbagDecal",
                [
                    (0.031, -0.405, 1.172),
                    (0.047, -0.255, 1.177),
                    (0.103, -0.265, 1.188),
                    (0.087, -0.415, 1.183),
                ],
                material=mats["visor_decal"], parent=parent,
            ))

    # Central Overhead Dome Console / SOS / Passenger Airbag Pod (crop_47_mirror_header.png!)
    objs.append(create_rounded_box(
        "TSC_Trim_OverheadPod",
        (0.106, 0.0, 1.180), (0.145, 0.225, 0.044),
        material=mats["trim_dark"], parent=parent, bevel_width=0.012,
        rotation=(0.0, math.radians(-16.0), 0.0),
    ))
    # Twin frosted reading-light lenses + SOS button on underside of overhead pod
    for side_lbl, ly in (("L", +0.065), ("R", -0.065)):
        objs.append(create_rounded_box(
            f"TSC_Trim_DomeLight_{side_lbl}",
            (0.103, ly, 1.158), (0.042, 0.028, 0.006),
            material=mats["piano_black"], parent=parent, bevel_width=0.002,
            rotation=(0.0, math.radians(-16.0), 0.0),
        ))
    objs.append(create_rounded_box(
        "TSC_Trim_OverheadStatusPanel",
        (0.093, 0.0, 1.160), (0.048, 0.088, 0.006),
        material=mats["piano_black"], parent=parent, bevel_width=0.002,
        rotation=(0.0, math.radians(-16.0), 0.0),
    ))

    # ------------------------------------------------------------------
    # 6. Frameless Interior Rearview Mirror (EXACT Material: Mat_Cabin_Rearview!)
    # ------------------------------------------------------------------
    mx, my, mz = C.MIRROR_POS
    mw, mh = C.MIRROR_WIDTH, C.MIRROR_HEIGHT
    # Mirror mounting stalk from overhead pod / upper windshield down to mirror housing
    objs.append(create_tube_mesh(
        "TSC_RearviewMirror_Stalk",
        [(mx - 0.052, 0.0, 1.182), (mx + 0.018, 0.0, 1.182), (mx + 0.016, 0.0, mz)],
        radius=0.010, segments=14, material=mats["trim_dark"], parent=parent,
    ))
    # Sleek rounded-trapezoid matte-black rear mirror housing
    objs.append(create_rounded_box(
        "TSC_RearviewMirror_Housing",
        (mx + 0.010, my, mz), (0.022, mw, mh),
        material=mats["piano_black"], parent=parent, bevel_width=0.008,
        rotation=(0.0, math.radians(5.0), 0.0),
    ))
    # Frameless beveled planar mirror glass facing rearward (-X) with EXACT Mat_Cabin_Rearview!
    # Slight rounded trapezoid corners (wider on top, gently tapered bottom matching crop_47_mirror_header!)
    hw_t = mw * 0.49
    hw_b = mw * 0.45
    hh = mh * 0.47
    tilt_m = math.radians(5.0)
    dx_m = math.sin(tilt_m) * hh
    dz_m = math.cos(tilt_m) * hh
    objs.append(create_textured_quad(
        "TSC_RearviewMirror_Glass",
        [
            (mx - 0.002 - dx_m, +hw_b, mz - dz_m),
            (mx - 0.002 - dx_m, -hw_b, mz - dz_m),
            (mx - 0.002 + dx_m, -hw_t, mz + dz_m),
            (mx - 0.002 + dx_m, +hw_t, mz + dz_m),
        ],
        material=mats["rearview"], parent=parent,
    ))

    return objs
