"""
Clean Blender 5.2 bmesh, lofting, UV-mapping, bevel, and stitching utilities
for the Porsche 911 Turbo S Cabriolet interior package.
"""

import math
import numpy as np
import bpy
import bmesh
from mathutils import Vector, Matrix, Euler


def ensure_empty(name: str, location=(0.0, 0.0, 0.0), parent=None) -> bpy.types.Object:
    obj = bpy.data.objects.get(name)
    if obj is None:
        obj = bpy.data.objects.new(name, None)
        obj.empty_display_type = "PLAIN_AXES"
        obj.empty_display_size = 0.12
        bpy.context.scene.collection.objects.link(obj)
    obj.location = Vector(location)
    if parent is not None and obj.parent != parent:
        obj.parent = parent
    return obj


def get_world_offset(parent) -> np.ndarray:
    """Cumulative translation offset from world origin to parent (zero rotation during build)."""
    if parent is None:
        return np.zeros(3, dtype=np.float64)
    offset = Vector((0.0, 0.0, 0.0))
    cur = parent
    while cur is not None:
        offset += cur.location
        cur = cur.parent
    return np.array([offset.x, offset.y, offset.z], dtype=np.float64)


def to_local_coords(verts, parent=None) -> np.ndarray:
    arr = np.asarray(verts, dtype=np.float64)
    if parent is None:
        return arr
    return arr - get_world_offset(parent)


def _apply_planar_uv(me: bpy.types.Mesh, mode: str = "box", scale: float = 4.0):
    """Assign clean box or planar UVs to any mesh without custom UVs."""
    bm = bmesh.new()
    bm.from_mesh(me)
    uv_layer = bm.loops.layers.uv.verify()
    for f in bm.faces:
        n = f.normal
        ax, ay, az = abs(n.x), abs(n.y), abs(n.z)
        for loop in f.loops:
            co = loop.vert.co
            if mode == "xy" or (mode == "box" and az >= ax and az >= ay):
                loop[uv_layer].uv = (co.x * scale, co.y * scale)
            elif mode == "yz" or (mode == "box" and ax >= ay and ax >= az):
                loop[uv_layer].uv = (co.y * scale, co.z * scale)
            else:
                loop[uv_layer].uv = (co.x * scale, co.z * scale)
    bm.to_mesh(me)
    bm.free()


def create_mesh_object(
    name: str,
    verts,
    faces,
    material=None,
    parent=None,
    uvs=None,
    smooth: bool = True,
    recalc_normals: bool = True,
    world_coords: bool = True,
    uv_scale: float = 4.0,
) -> bpy.types.Object:
    """Create a validated Blender mesh object with optional explicit UVs or automatic box UVs."""
    pts = to_local_coords(verts, parent) if world_coords else np.asarray(verts, dtype=np.float64)
    me = bpy.data.meshes.new(name)
    me.from_pydata(pts.tolist(), [], faces)
    if material is not None:
        if isinstance(material, (list, tuple)):
            for m in material:
                me.materials.append(m)
        else:
            me.materials.append(material)
    me.update(calc_edges=True)

    bm = bmesh.new()
    bm.from_mesh(me)
    # Remove any accidental degenerate faces
    bmesh.ops.dissolve_degenerate(bm, dist=1e-6, edges=bm.edges)
    if recalc_normals:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    if smooth:
        for f in bm.faces:
            f.smooth = True
    if uvs is not None:
        uv_layer = bm.loops.layers.uv.verify()
        for f in bm.faces:
            for loop in f.loops:
                vi = loop.vert.index
                if vi < len(uvs):
                    loop[uv_layer].uv = (float(uvs[vi][0]), float(uvs[vi][1]))
    bm.to_mesh(me)
    bm.free()

    if uvs is None:
        _apply_planar_uv(me, mode="box", scale=uv_scale)

    me.validate(verbose=False)
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    if parent is not None:
        ob.parent = parent
    return ob


def create_quad_grid(
    name: str,
    grid_xyz,
    material=None,
    parent=None,
    cyclic_u: bool = False,
    cyclic_v: bool = False,
    cap_u0: bool = False,
    cap_u1: bool = False,
    smooth: bool = True,
    recalc_normals: bool = True,
    world_coords: bool = True,
    flip_faces: bool = False,
    uv_grid: bool = True,
    uv_repeat=(1.0, 1.0),
) -> bpy.types.Object:
    """Create a clean quad-topology mesh from (Nu, Nv, 3) grid with normalized grid UVs."""
    arr = np.asarray(grid_xyz, dtype=np.float64)
    nu, nv, _ = arr.shape
    verts = arr.reshape(-1, 3)

    uvs = None
    if uv_grid:
        us = np.linspace(0.0, uv_repeat[0], nu)
        vs = np.linspace(0.0, uv_repeat[1], nv)
        uu, vv = np.meshgrid(us, vs, indexing="ij")
        uvs = np.stack([uu.ravel(), vv.ravel()], axis=-1)

    faces = []
    u_lim = nu if cyclic_u else nu - 1
    v_lim = nv if cyclic_v else nv - 1
    for i in range(u_lim):
        i2 = (i + 1) % nu
        for j in range(v_lim):
            j2 = (j + 1) % nv
            a = i * nv + j
            b = i2 * nv + j
            c = i2 * nv + j2
            d = i * nv + j2
            if flip_faces:
                faces.append((a, d, c, b))
            else:
                faces.append((a, b, c, d))

    if cap_u0 and cyclic_v:
        c0 = verts[:nv].mean(axis=0)
        c0_idx = len(verts)
        verts = np.vstack([verts, c0[None, :]])
        if uvs is not None:
            uvs = np.vstack([uvs, np.array([[0.0, 0.5]])])
        for j in range(nv):
            j2 = (j + 1) % nv
            faces.append((c0_idx, j2, j) if not flip_faces else (c0_idx, j, j2))

    if cap_u1 and cyclic_v:
        base = (nu - 1) * nv
        c1 = verts[base:base + nv].mean(axis=0)
        c1_idx = len(verts)
        verts = np.vstack([verts, c1[None, :]])
        if uvs is not None:
            uvs = np.vstack([uvs, np.array([[uv_repeat[0], 0.5]])])
        for j in range(nv):
            j2 = (j + 1) % nv
            faces.append((c1_idx, base + j, base + j2) if not flip_faces else (c1_idx, base + j2, base + j))

    return create_mesh_object(
        name,
        verts,
        faces,
        material=material,
        parent=parent,
        uvs=uvs,
        smooth=smooth,
        recalc_normals=recalc_normals,
        world_coords=world_coords,
    )


def create_solidified_grid(
    name: str,
    grid_xyz,
    thickness: float,
    material=None,
    parent=None,
    offset: float = -1.0,
    smooth: bool = True,
    world_coords: bool = True,
    uv_repeat=(1.0, 1.0),
) -> bpy.types.Object:
    """Create a solidified clean mesh (applying Solidify directly so exported GLB has zero modifier surprises)."""
    ob = create_quad_grid(
        name, grid_xyz, material=material, parent=parent, smooth=smooth,
        recalc_normals=True, world_coords=world_coords, uv_repeat=uv_repeat,
    )
    if thickness > 0.0:
        bm = bmesh.new()
        bm.from_mesh(ob.data)
        ret = bmesh.ops.solidify(bm, geom=list(bm.faces), thickness=thickness * (-1.0 if offset < 0 else 1.0))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        for f in bm.faces:
            f.smooth = smooth
        bm.to_mesh(ob.data)
        bm.free()
        ob.data.update()
        ob.data.validate(verbose=False)
    return ob


def create_rounded_box(
    name: str,
    center,
    dimensions,
    material=None,
    parent=None,
    bevel_width: float = 0.005,
    bevel_segments: int = 3,
    rotation=(0.0, 0.0, 0.0),
    world_coords: bool = True,
    uv_scale: float = 4.0,
) -> bpy.types.Object:
    """Create a smooth beveled box with baked rotation & position in parent-local vertex space."""
    loc = to_local_coords([center], parent)[0] if world_coords else np.asarray(center, dtype=np.float64)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    sx, sy, sz = dimensions
    for v in bm.verts:
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz
    if bevel_width > 0.0:
        bw = min(bevel_width, 0.44 * min(sx, sy, sz))
        bmesh.ops.bevel(
            bm,
            geom=list(bm.edges),
            offset=bw,
            segments=bevel_segments,
            affect="EDGES",
            clamp_overlap=True,
        )
    rot_m = Euler(rotation, "XYZ").to_matrix().to_4x4()
    trans_m = Matrix.Translation(Vector(loc.tolist()))
    bmesh.ops.transform(bm, matrix=trans_m @ rot_m, verts=bm.verts)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces:
        f.smooth = True
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    _apply_planar_uv(me, mode="box", scale=uv_scale)
    if material is not None:
        me.materials.append(material)
    me.validate(verbose=False)
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    if parent is not None:
        ob.parent = parent
    return ob


def create_cylinder(
    name: str,
    center,
    radius: float,
    depth: float,
    axis: str = "X",
    segments: int = 40,
    material=None,
    parent=None,
    bevel: float = 0.0,
    rotation=(0.0, 0.0, 0.0),
    radius2: float = None,
    world_coords: bool = True,
    cap_uv_face: str = None,
) -> bpy.types.Object:
    """Create a smooth cylinder/cone with baked transform and optional circular front-face UV."""
    loc = to_local_coords([center], parent)[0] if world_coords else np.asarray(center, dtype=np.float64)
    r2 = radius if radius2 is None else radius2
    bm = bmesh.new()
    bmesh.ops.create_cone(
        bm, cap_ends=True, cap_tris=False, segments=segments,
        radius1=radius, radius2=r2, depth=depth,
    )
    if axis == "Y":
        bmesh.ops.rotate(bm, cent=(0, 0, 0), matrix=Matrix.Rotation(math.pi / 2.0, 3, "X"), verts=bm.verts)
    elif axis == "X":
        bmesh.ops.rotate(bm, cent=(0, 0, 0), matrix=Matrix.Rotation(math.pi / 2.0, 3, "Y"), verts=bm.verts)
    if bevel > 0.0:
        cap_edges = [
            e for e in bm.edges
            if len(e.link_faces) == 2 and abs(e.link_faces[0].normal.dot(e.link_faces[1].normal)) < 0.5
        ]
        if cap_edges:
            bmesh.ops.bevel(bm, geom=cap_edges, offset=min(bevel, radius * 0.35, depth * 0.35),
                            segments=3, affect="EDGES", clamp_overlap=True)

    # Assign circular UV on facing cap BEFORE baking world transform
    uv_layer = bm.loops.layers.uv.verify()
    rmax = max(radius, r2, 1e-5)
    for f in bm.faces:
        for loop in f.loops:
            co = loop.vert.co
            if cap_uv_face == "-X":
                # Facing driver (-X): +Y is left (u=0), -Y is right (u=1), +Z is up (v=1)
                u = 0.5 - co.y / (2.0 * rmax)
                v = 0.5 + co.z / (2.0 * rmax)
                loop[uv_layer].uv = (u, v)
            elif cap_uv_face == "+Z":
                u = 0.5 - co.y / (2.0 * rmax)
                v = 0.5 + co.x / (2.0 * rmax)
                loop[uv_layer].uv = (u, v)
            else:
                loop[uv_layer].uv = (co.x * 5.0, co.z * 5.0)

    rot_m = Euler(rotation, "XYZ").to_matrix().to_4x4()
    trans_m = Matrix.Translation(Vector(loc.tolist()))
    bmesh.ops.transform(bm, matrix=trans_m @ rot_m, verts=bm.verts)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces:
        f.smooth = True
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    if material is not None:
        me.materials.append(material)
    me.validate(verbose=False)
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    if parent is not None:
        ob.parent = parent
    return ob


def create_tube_mesh(
    name: str,
    points,
    radius,
    segments: int = 16,
    material=None,
    parent=None,
    cyclic: bool = False,
    cap_ends: bool = True,
    world_coords: bool = True,
    radius_y_scale: float = 1.0,
) -> bpy.types.Object:
    """
    Sweep a clean closed quad tube mesh along a 3D polyline (avoids Blender Curve objects
    so exported meshes have guaranteed clean topology & UVs).
    `radius` may be a scalar float or a per-point sequence.
    """
    pts = np.asarray(points, dtype=np.float64)
    n = len(pts)
    radii = np.full(n, float(radius)) if np.isscalar(radius) else np.asarray(radius, dtype=np.float64)

    # Compute smooth Frenet/parallel-transport frames
    tangents = np.zeros_like(pts)
    for i in range(n):
        if cyclic:
            t = pts[(i + 1) % n] - pts[(i - 1) % n]
        elif i == 0:
            t = pts[1] - pts[0]
        elif i == n - 1:
            t = pts[-1] - pts[-2]
        else:
            t = pts[i + 1] - pts[i - 1]
        norm = np.linalg.norm(t)
        tangents[i] = t / max(norm, 1e-8)

    # Initial normal perpendicular to tangent[0]
    ref = np.array([0.0, 0.0, 1.0]) if abs(tangents[0, 2]) < 0.9 else np.array([1.0, 0.0, 0.0])
    n0 = np.cross(tangents[0], ref)
    n0 /= max(np.linalg.norm(n0), 1e-8)

    normals = np.zeros_like(pts)
    binormals = np.zeros_like(pts)
    normals[0] = n0
    binormals[0] = np.cross(tangents[0], n0)

    for i in range(1, n):
        # Parallel transport
        v = np.cross(tangents[i - 1], tangents[i])
        s = np.linalg.norm(v)
        c = float(np.dot(tangents[i - 1], tangents[i]))
        if s > 1e-7:
            axis = v / s
            ang = math.atan2(s, np.clip(c, -1.0, 1.0))
            # Rodrigues rotation
            k = axis
            n_prev = normals[i - 1]
            n_cur = n_prev * math.cos(ang) + np.cross(k, n_prev) * math.sin(ang) + k * np.dot(k, n_prev) * (1.0 - math.cos(ang))
        else:
            n_cur = normals[i - 1]
        n_cur -= np.dot(n_cur, tangents[i]) * tangents[i]
        n_cur /= max(np.linalg.norm(n_cur), 1e-8)
        normals[i] = n_cur
        binormals[i] = np.cross(tangents[i], n_cur)

    # Close cyclic twist cleanly
    if cyclic:
        dot_end = float(np.clip(np.dot(normals[-1], normals[0]), -1.0, 1.0))
        sign = 1.0 if np.dot(np.cross(normals[-1], normals[0]), tangents[0]) >= 0 else -1.0
        twist = sign * math.acos(dot_end)
        for i in range(n):
            a = twist * (i / float(n))
            ca, sa = math.cos(a), math.sin(a)
            ni = normals[i] * ca + binormals[i] * sa
            bi = -normals[i] * sa + binormals[i] * ca
            normals[i] = ni
            binormals[i] = bi

    angles = np.linspace(0.0, 2.0 * math.pi, segments, endpoint=False)
    grid = np.zeros((n, segments, 3), dtype=np.float64)
    for i in range(n):
        r = radii[i]
        for j, a in enumerate(angles):
            grid[i, j] = pts[i] + r * (math.cos(a) * normals[i] + radius_y_scale * math.sin(a) * binormals[i])

    return create_quad_grid(
        name,
        grid,
        material=material,
        parent=parent,
        cyclic_u=cyclic,
        cyclic_v=True,
        cap_u0=(cap_ends and not cyclic),
        cap_u1=(cap_ends and not cyclic),
        smooth=True,
        recalc_normals=True,
        world_coords=world_coords,
    )


def create_textured_quad(
    name: str,
    corners_bl_br_tr_tl,
    material,
    parent=None,
    world_coords: bool = True,
    subdiv_u: int = 1,
    subdiv_v: int = 1,
    curve_sag_x: float = 0.0,
) -> bpy.types.Object:
    """
    Create a UV-mapped planar or gently curved quad facing the driver/cabin.
    corners: [bottom_left, bottom_right, top_right, top_left] matching UV (0,0), (1,0), (1,1), (0,1).
    """
    bl, br, tr, tl = [np.asarray(p, dtype=np.float64) for p in corners_bl_br_tr_tl]
    nu = subdiv_u + 1
    nv = subdiv_v + 1
    grid = np.zeros((nu, nv, 3), dtype=np.float64)
    uvs = np.zeros((nu, nv, 2), dtype=np.float64)
    for i in range(nu):
        u = i / float(nu - 1)
        b_pt = (1.0 - u) * bl + u * br
        t_pt = (1.0 - u) * tl + u * tr
        # Optional horizontal curvature (edges curve slightly back toward driver for 992.2 curved cluster)
        sag = curve_sag_x * (4.0 * (u - 0.5) ** 2 - 1.0)  # 0 at edges, -sag at center => concave toward -X
        for j in range(nv):
            v = j / float(nv - 1)
            pt = (1.0 - v) * b_pt + v * t_pt
            pt[0] += sag
            grid[i, j] = pt
            uvs[i, j] = (u, v)

    verts = grid.reshape(-1, 3)
    uv_flat = uvs.reshape(-1, 2)
    faces = []
    for i in range(nu - 1):
        for j in range(nv - 1):
            a = i * nv + j
            b = (i + 1) * nv + j
            c = (i + 1) * nv + (j + 1)
            d = i * nv + (j + 1)
            faces.append((a, b, c, d))

    return create_mesh_object(
        name,
        verts,
        faces,
        material=material,
        parent=parent,
        uvs=uv_flat,
        smooth=True,
        recalc_normals=False,
        world_coords=world_coords,
    )


def create_stitch_line(
    name: str,
    points,
    material,
    parent=None,
    radius: float = 0.0014,
    world_coords: bool = True,
) -> bpy.types.Object:
    """Create a fine continuous Turbonite contrast stitch piping bead along a leather seam."""
    return create_tube_mesh(
        name,
        points,
        radius=radius,
        segments=6,
        material=material,
        parent=parent,
        cyclic=False,
        cap_ends=True,
        world_coords=world_coords,
    )
