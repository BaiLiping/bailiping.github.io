"""
Dimensional datums & cabin envelope configuration for the
2026 Porsche 911 Turbo S Cabriolet (992.2 T-Hybrid, LHD EU-spec) Interior.

Units: 1:1 real-world METERS inside Blender (Z-up right-handed):
  +X : Forward (nose)
  +Y : Left (driver side, LHD)
  +Z : Up (Z = 0.0 is ground plane)
  X = 0.0 : Wheelbase midpoint (front axle +1.225 m, rear axle -1.225 m)
  Y = 0.0 : Centerline

Strictly locked to blender/exterior/config.py and web/rig_contract.md.
"""

import math

# Core Exterior Envelope Datums (synchronized with blender/exterior/config.py)
Z_UNDERBODY = 0.125
Z_ROCKER_BOTTOM = 0.130

X_COWL_CENTER = +0.795
X_COWL_SIDE = +0.660
Z_COWL_CENTER = 0.870
Z_COWL_SIDE = 0.892

X_HEADER_CENTER = +0.115
X_HEADER_SIDE = +0.015
Z_HEADER_CENTER = 1.258
Z_HEADER_SIDE = 1.210
Y_HEADER_OUTER = 0.595
Y_HEADER_INNER = 0.545

X_DOOR_FRONT = +0.640
X_DOOR_REAR = -0.495
DOOR_PIVOT_L = (+0.625, +0.835, 0.560)
DOOR_PIVOT_R = (+0.625, -0.835, 0.560)

# Cabin Floor, Sill & Beltline Envelope
Z_FLOOR = 0.195                 # Carpeted floor top (cleanly above Z_UNDERBODY = 0.125)
Z_FOOTWELL_FRONT = 0.210        # Slight upward slope toward front firewall
X_FIREWALL = +0.880             # Front bulkhead behind pedals
X_CABIN_REAR = -1.045           # Rear cabin bulkhead (tucks under stowed tonneau front lip)
Y_CABIN_INNER = 0.725           # Inner sill / quarter trim wall half-width
Y_BELT_INNER = 0.745            # Inner beltline lip (strictly inboard of exterior Y_belt 0.766..0.774)
Z_BELT_FRONT = 0.885            # Door/dash beltline Z at A-pillar
Z_BELT_REAR = 0.928             # Quarter beltline Z rising gently toward rear tonneau

# Dashboard & Instrumentation Datums (LHD: driver = +Y)
X_DASH_FRONT = +0.785           # Windshield base / defroster cowl edge
X_DASH_BROW = +0.445            # Upper dash brow overhanging cluster & PCM
X_DASH_SHELF = +0.455           # Horizontal matte-carbon dash shelf front-facing lip
Z_DASH_TOP = 0.890              # Upper dash crown behind cowl
Z_DASH_SHELF = 0.728            # Center horizontal carbon fiber shelf height

Y_DRIVER = +0.355               # Driver seat, steering wheel & digital cluster centerline
Y_PASSENGER = -0.355            # Passenger seat centerline

# 992.2 12.6" Freestanding Curved Digital Instrument Cluster
CLUSTER_X = +0.525
CLUSTER_Y = Y_DRIVER
CLUSTER_Z = 0.818
CLUSTER_WIDTH = 0.345           # 12.6" curved widescreen width
CLUSTER_HEIGHT = 0.125

# 10.9" Center PCM Display (flush in dash recess)
PCM_X = +0.505
PCM_Y = 0.000
PCM_Z = 0.798
PCM_WIDTH = 0.268               # 10.9" wide touchscreen
PCM_HEIGHT = 0.122

# Sport Chrono Stopwatch (hooded center top dash)
CHRONO_X = +0.585
CHRONO_Y = 0.000
CHRONO_Z = 0.916
CHRONO_RADIUS = 0.036

# GT Sport Steering Wheel & Column
WHEEL_CENTER = (+0.195, Y_DRIVER, 0.772)
WHEEL_RADIUS = 0.178            # ~356 mm diameter GT Sport wheel
WHEEL_TILT_DEG = 21.0           # Tilted slightly upward facing driver

# Center Console & Tunnel
CONSOLE_Y_HALF = 0.118          # Console outer Turbonite trim half-width at top
CONSOLE_TUNNEL_Y = 0.138        # Lower leather tunnel sides
CONSOLE_X_FRONT = +0.465        # Meets lower dash below HVAC vents
CONSOLE_X_REAR = -0.960         # Extends through armrest into 2+2 rear console bridge
SHIFTER_POS = (+0.235, 0.000, 0.562)

# Front 18-Way Adaptive Sport Seats Plus (calibrated to photo 46 & 44!)
SEAT_FRONT_HIP_X = -0.220       # H-point / rear of bottom cushion
SEAT_FRONT_FRONT_X = +0.235     # Front thigh bolster edge
SEAT_FRONT_CUSHION_Z = 0.310    # Seat cushion top surface (low 911 sports car seating)
SEAT_FRONT_BACK_TOP_X = -0.455  # Headrest peak X (aligned near rear door edge as in photo 46)
SEAT_FRONT_BACK_TOP_Z = 1.108   # Headrest peak Z (~60% between beltline 0.892 and header 1.258)
SEAT_FRONT_WIDTH = 0.505        # Total bolster-to-bolster width

# 2+2 Rear Seats
SEAT_REAR_FRONT_X = -0.575
SEAT_REAR_BACK_X = -0.945
SEAT_REAR_TOP_X = -1.015
SEAT_REAR_TOP_Z = 0.918
SEAT_REAR_CUSHION_Z = 0.345
SEAT_REAR_Y = 0.335

# Interior Rearview Mirror (using exact material Mat_Cabin_Rearview)
MIRROR_POS = (+0.195, 0.000, 1.158)
MIRROR_WIDTH = 0.215
MIRROR_HEIGHT = 0.058

# Pedals (LHD driver footwell, 8-speed PDK: Dead-pedal + Brake + Organ Accelerator)
PEDAL_X = +0.765
PEDAL_DEAD_Y = +0.575
PEDAL_BRAKE_Y = +0.405
PEDAL_GAS_Y = +0.255


def merge_cfg(cfg: dict | None) -> dict:
    """Merge exterior/master cfg overrides into interior datums."""
    out = {
        "Z_UNDERBODY": Z_UNDERBODY,
        "Z_ROCKER_BOTTOM": Z_ROCKER_BOTTOM,
        "X_COWL_CENTER": X_COWL_CENTER,
        "X_COWL_SIDE": X_COWL_SIDE,
        "Z_COWL_CENTER": Z_COWL_CENTER,
        "Z_COWL_SIDE": Z_COWL_SIDE,
        "X_HEADER_CENTER": X_HEADER_CENTER,
        "X_HEADER_SIDE": X_HEADER_SIDE,
        "Z_HEADER_CENTER": Z_HEADER_CENTER,
        "Z_HEADER_SIDE": Z_HEADER_SIDE,
        "Y_HEADER_OUTER": Y_HEADER_OUTER,
        "Y_HEADER_INNER": Y_HEADER_INNER,
        "X_DOOR_FRONT": X_DOOR_FRONT,
        "X_DOOR_REAR": X_DOOR_REAR,
        "DOOR_PIVOT_L": DOOR_PIVOT_L,
        "DOOR_PIVOT_R": DOOR_PIVOT_R,
        "Z_FLOOR": Z_FLOOR,
        "Y_DRIVER": Y_DRIVER,
        "Y_PASSENGER": Y_PASSENGER,
    }
    if cfg:
        for k, v in cfg.items():
            if k in out:
                out[k] = v
        pivots = cfg.get("PIVOT_LOCATIONS") or {}
        if "Pivot_Door_L" in pivots:
            out["DOOR_PIVOT_L"] = tuple(pivots["Pivot_Door_L"])
        if "Pivot_Door_R" in pivots:
            out["DOOR_PIVOT_R"] = tuple(pivots["Pivot_Door_R"])
    return out
