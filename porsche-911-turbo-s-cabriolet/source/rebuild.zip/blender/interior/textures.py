"""
High-resolution 2D texture generator for the 2026 Porsche 911 Turbo S Cabriolet (992.2) cabin.
Generates crisp PNG textures in blender/interior/textures/ using Pillow (system python3)
so Blender packs them directly into .blend and exported GLB files.
"""

import math
import os
import subprocess
import sys

TEX_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "textures")

REQUIRED_TEXTURES = [
    "cluster_992_2_turbos.png",
    "pcm_911_turbos.png",
    "sport_chrono_face.png",
    "porsche_crest_turbonite.png",
    "carbon_twill_matte.png",
    "leather_perforated.png",
    "console_climate_bar.png",
    "sill_turbos_plate.png",
    "headrest_turbos.png",
    "visor_airbag_decal.png",
    "dash_turbos_badge.png",
]


def _load_font(size: int, bold: bool = False, italic: bool = False):
    from PIL import ImageFont

    candidates = []
    if bold and italic:
        candidates = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-BoldOblique.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-BoldItalic.ttf",
        ]
    elif italic:
        candidates = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Italic.ttf",
        ]
    elif bold:
        candidates = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
        ]
    else:
        candidates = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
        ]
    for path in candidates:
        if os.path.exists(path):
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _draw_centered(draw, xy, text, font, fill):
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    draw.text((xy[0] - tw / 2.0 - bbox[0], xy[1] - th / 2.0 - bbox[1]), text, font=font, fill=fill)


def _gen_cluster(out_path: str):
    """Generate 992.2 curved 12.6-inch full-digital 5-dial EU cluster matching photo (47)."""
    from PIL import Image, ImageDraw

    W, H = 2048, 720
    img = Image.new("RGB", (W, H), (8, 10, 13))
    d = ImageDraw.Draw(img)

    # Subtle glass vignette / bezel sheen
    for y in range(H):
        v = int(8 + 6 * math.sin(math.pi * y / H))
        d.line([(0, y), (W, y)], fill=(v, v + 1, v + 3))

    def draw_dial_ring(cx, cy, r, thickness=4, col=(185, 190, 198)):
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(14, 16, 20), outline=col, width=thickness)
        d.ellipse([cx - r + 10, cy - r + 10, cx + r - 10, cy + r - 10], outline=(55, 60, 68), width=2)

    def draw_needle(cx, cy, r_len, angle_deg, color=(235, 76, 36), width=9):
        rad = math.radians(angle_deg)
        x1 = cx + math.cos(rad) * r_len
        y1 = cy + math.sin(rad) * r_len
        x0 = cx - math.cos(rad) * (r_len * 0.16)
        y0 = cy - math.sin(rad) * (r_len * 0.16)
        d.line([(x0, y0), (x1, y1)], fill=color, width=width)
        d.ellipse([cx - 18, cy - 18, cx + 18, cy + 18], fill=(35, 38, 44), outline=(140, 145, 152), width=3)

    # 1. Far-left Boost / Pressure dial (partially tucked)
    cx1, cy1, r1 = 275, 375, 155
    draw_dial_ring(cx1, cy1, r1, 3, (120, 126, 135))
    f_tiny = _load_font(22, bold=True)
    for k, val in enumerate(["0.0", "1.0", "2.0"]):
        ang = 150 + k * 45
        rad = math.radians(ang)
        d.line([(cx1 + math.cos(rad) * (r1 - 24), cy1 + math.sin(rad) * (r1 - 24)),
                (cx1 + math.cos(rad) * (r1 - 8), cy1 + math.sin(rad) * (r1 - 8))], fill=(210, 215, 222), width=3)
        _draw_centered(d, (cx1 + math.cos(rad) * (r1 - 48), cy1 + math.sin(rad) * (r1 - 48)), val, f_tiny, (200, 205, 212))
    _draw_centered(d, (cx1 + 10, cy1 + 65), "bar", _load_font(20), (150, 156, 165))
    draw_needle(cx1, cy1, r1 - 22, 148, width=7)

    # 2. Inner-left Speedometer (30..360 km/h EU-spec)
    cx2, cy2, r2 = 605, 360, 205
    draw_dial_ring(cx2, cy2, r2, 4, (175, 180, 188))
    f_spd = _load_font(26, bold=True)
    speeds = [30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330, 360]
    for i, sp in enumerate(speeds):
        ang = 135 + i * (270.0 / (len(speeds) - 1))
        rad = math.radians(ang)
        d.line([(cx2 + math.cos(rad) * (r2 - 26), cy2 + math.sin(rad) * (r2 - 26)),
                (cx2 + math.cos(rad) * (r2 - 8), cy2 + math.sin(rad) * (r2 - 8))], fill=(235, 238, 242), width=4)
        if sp in (60, 120, 180, 240, 300, 360):
            _draw_centered(d, (cx2 + math.cos(rad) * (r2 - 56), cy2 + math.sin(rad) * (r2 - 56)), str(sp), f_spd, (235, 238, 242))
    # Minor ticks
    for j in range(34):
        ang = 135 + j * (270.0 / 33.0)
        rad = math.radians(ang)
        d.line([(cx2 + math.cos(rad) * (r2 - 16), cy2 + math.sin(rad) * (r2 - 16)),
                (cx2 + math.cos(rad) * (r2 - 8), cy2 + math.sin(rad) * (r2 - 8))], fill=(140, 145, 152), width=2)
    _draw_centered(d, (cx2, cy2 - 48), "km/h", _load_font(22), (165, 170, 178))
    draw_needle(cx2, cy2, r2 - 24, 92, width=8)  # pointing straight down near 0

    # 3. Inner-right Oil Pressure / Temp Dual Gauge
    cx4, cy4, r4 = 1443, 360, 205
    draw_dial_ring(cx4, cy4, r4, 4, (175, 180, 188))
    # Top half: bar (3.0 / 6.0), bottom half: °C (50 / 150)
    for ang, lbl in [(210, "0"), (255, "3.0"), (305, "6.0")]:
        rad = math.radians(ang)
        d.line([(cx4 + math.cos(rad) * (r4 - 24), cy4 + math.sin(rad) * (r4 - 24)),
                (cx4 + math.cos(rad) * (r4 - 8), cy4 + math.sin(rad) * (r4 - 8))], fill=(225, 230, 236), width=4)
        _draw_centered(d, (cx4 + math.cos(rad) * (r4 - 55), cy4 + math.sin(rad) * (r4 - 55)), lbl, _load_font(24, bold=True), (225, 230, 236))
    for ang, lbl in [(145, "50"), (90, "100"), (35, "150")]:
        rad = math.radians(ang)
        d.line([(cx4 + math.cos(rad) * (r4 - 24), cy4 + math.sin(rad) * (r4 - 24)),
                (cx4 + math.cos(rad) * (r4 - 8), cy4 + math.sin(rad) * (r4 - 8))], fill=(225, 230, 236), width=4)
        _draw_centered(d, (cx4 + math.cos(rad) * (r4 - 55), cy4 + math.sin(rad) * (r4 - 55)), lbl, _load_font(24, bold=True), (225, 230, 236))
    _draw_centered(d, (cx4 + 42, cy4 - 16), "bar", _load_font(20), (155, 162, 170))
    _draw_centered(d, (cx4 + 42, cy4 + 28), "°C", _load_font(20), (155, 162, 170))
    draw_needle(cx4, cy4 - 25, r4 - 45, 212, width=7)
    draw_needle(cx4, cy4 + 28, r4 - 55, 92, width=7)

    # 4. Far-right Fuel / Coolant Gauge
    cx5, cy5, r5 = 1773, 375, 155
    draw_dial_ring(cx5, cy5, r5, 3, (120, 126, 135))
    for ang, lbl in [(310, "1/1"), (15, "1/2"), (65, "R")]:
        rad = math.radians(ang)
        d.line([(cx5 + math.cos(rad) * (r5 - 22), cy5 + math.sin(rad) * (r5 - 22)),
                (cx5 + math.cos(rad) * (r5 - 8), cy5 + math.sin(rad) * (r5 - 8))], fill=(210, 215, 222), width=3)
    draw_needle(cx5, cy5, r5 - 24, 5, width=7)

    # 5. CENTER LARGE TACHOMETER (overlaps neighbors cleanly as in 992.2 digital cluster!)
    cx3, cy3, r3 = 1024, 345, 258
    d.ellipse([cx3 - r3 - 8, cy3 - r3 - 8, cx3 + r3 + 8, cy3 + r3 + 8], fill=(10, 12, 15))
    draw_dial_ring(cx3, cy3, r3, 5, (215, 220, 228))

    # Redline arc from 7.2 to 8.2 (angles ~ 5 to 36 deg)
    for a_deg in range(0, 34):
        rad = math.radians(a_deg)
        d.line([(cx3 + math.cos(rad) * (r3 - 30), cy3 + math.sin(rad) * (r3 - 30)),
                (cx3 + math.cos(rad) * (r3 - 8), cy3 + math.sin(rad) * (r3 - 8))], fill=(225, 36, 32), width=6)

    # Major RPM ticks 0..8 from 140° to 398° (i.e., 38°)
    f_rpm = _load_font(42, bold=True)
    for rpm in range(0, 9):
        ang = 142 + rpm * (256.0 / 8.0)
        rad = math.radians(ang)
        col = (235, 50, 42) if rpm == 8 else (242, 245, 248)
        d.line([(cx3 + math.cos(rad) * (r3 - 34), cy3 + math.sin(rad) * (r3 - 34)),
                (cx3 + math.cos(rad) * (r3 - 9), cy3 + math.sin(rad) * (r3 - 9))], fill=col, width=6)
        _draw_centered(d, (cx3 + math.cos(rad) * (r3 - 68), cy3 + math.sin(rad) * (r3 - 68)), str(rpm), f_rpm, col)
    # Half-RPM minor ticks
    for half in range(16):
        ang = 142 + (half + 0.5) * (256.0 / 16.0)
        rad = math.radians(ang)
        col = (220, 46, 40) if half >= 14 else (160, 166, 174)
        d.line([(cx3 + math.cos(rad) * (r3 - 22), cy3 + math.sin(rad) * (r3 - 22)),
                (cx3 + math.cos(rad) * (r3 - 9), cy3 + math.sin(rad) * (r3 - 9))], fill=col, width=3)

    # 'turbo S' italic script inside upper center tach
    _draw_centered(d, (cx3, cy3 - 86), "turbo S", _load_font(34, bold=True, italic=True), (218, 212, 198))
    _draw_centered(d, (cx3, cy3 - 54), "1/min x 1000", _load_font(17), (150, 155, 162))

    # Tach needle at idle (~800 rpm => ~167 deg)
    draw_needle(cx3, cy3, r3 - 28, 168, color=(238, 78, 36), width=11)

    # Digital speed "0 km/h" and green range bar "480 km" at bottom of center tach
    _draw_centered(d, (cx3, cy3 + 104), "0", _load_font(78, bold=True), (248, 250, 252))
    _draw_centered(d, (cx3 + 56, cy3 + 118), "km/h", _load_font(20), (170, 176, 184))
    _draw_centered(d, (cx3, cy3 + 178), "480 km", _load_font(24, bold=True), (215, 222, 228))
    # Green T-Hybrid battery / ready arc at very bottom of tach
    d.arc([cx3 - r3 + 22, cy3 - r3 + 22, cx3 + r3 - 22, cy3 + r3 - 22], start=72, end=108, fill=(56, 205, 98), width=7)

    # Red speed-limit sign "50" top right of center tach (just like photo 47!)
    sx, sy = cx3 + 220, cy3 - 190
    d.ellipse([sx - 34, sy - 34, sx + 34, sy + 34], fill=(245, 245, 248), outline=(220, 32, 32), width=8)
    _draw_centered(d, (sx, sy), "50", _load_font(28, bold=True), (18, 20, 24))

    # Bottom status bar matching (47)
    _draw_centered(d, (465, 622), "19°C   9:11", _load_font(24), (195, 200, 208))
    _draw_centered(d, (465, 656), "1.963 km", _load_font(28, bold=True), (235, 238, 242))
    _draw_centered(d, (1535, 646), "NORMAL", _load_font(30, bold=True), (225, 228, 232))
    _draw_centered(d, (1755, 636), "P", _load_font(32, bold=True), (245, 248, 252))
    _draw_centered(d, (1755, 668), "D/M", _load_font(20), (150, 156, 164))

    img.save(out_path)


def _gen_pcm(out_path: str):
    """Generate 10.9-inch PCM home display matching photo (47) with '911 Turbo S' header."""
    from PIL import Image, ImageDraw

    W, H = 1600, 720
    img = Image.new("RGB", (W, H), (14, 16, 19))
    d = ImageDraw.Draw(img)

    # Subtle glass gradient
    for y in range(H):
        v = int(13 + 7 * (1.0 - y / H))
        d.line([(0, y), (W, y)], fill=(v, v + 2, v + 5))

    # Left vertical Porsche shortcut bar
    d.rectangle([0, 0, 145, H], fill=(10, 12, 15))
    d.line([(145, 20), (145, H - 20)], fill=(38, 42, 48), width=2)
    _draw_centered(d, (72, 48), "9:11", _load_font(30, bold=True), (235, 238, 242))
    _draw_centered(d, (72, 86), "5G  ||||", _load_font(18), (160, 168, 178))

    # Dock icons: Home, Nav, Media, Phone, Car
    dock_ys = [180, 285, 390, 495, 600]
    # Home icon (white)
    y0 = dock_ys[0]
    d.polygon([(72, y0 - 20), (50, y0), (94, y0)], fill=(242, 245, 248))
    d.rectangle([57, y0, 87, y0 + 20], fill=(242, 245, 248))
    # Nav arrow (blue)
    y1 = dock_ys[1]
    d.polygon([(72, y1 - 24), (52, y1 + 22), (72, y1 + 12), (92, y1 + 22)], fill=(52, 132, 246))
    # Media note (red)
    y2 = dock_ys[2]
    d.rectangle([62, y2 - 20, 86, y2 - 12], fill=(235, 58, 52))
    d.rectangle([62, y2 - 16, 68, y2 + 16], fill=(235, 58, 52))
    d.rectangle([80, y2 - 16, 86, y2 + 12], fill=(235, 58, 52))
    d.ellipse([52, y2 + 8, 69, y2 + 24], fill=(235, 58, 52))
    d.ellipse([70, y2 + 4, 87, y2 + 20], fill=(235, 58, 52))
    # Phone (green)
    y3 = dock_ys[3]
    d.rounded_rectangle([58, y3 - 20, 86, y3 + 20], radius=8, fill=(52, 200, 92))
    d.rectangle([66, y3 - 10, 78, y3 + 10], fill=(10, 12, 15))
    # Car (white)
    y4 = dock_ys[4]
    d.rounded_rectangle([48, y4 - 6, 96, y4 + 12], radius=5, fill=(232, 236, 240))
    d.polygon([(56, y4 - 6), (64, y4 - 18), (82, y4 - 18), (90, y4 - 6)], fill=(232, 236, 240))

    # Top header — explicitly "911 Turbo S" (NEVER GT3!)
    _draw_centered(d, (860, 56), "911 Turbo S", _load_font(36, bold=True), (236, 238, 242))
    _draw_centered(d, (1010, 56), "▾", _load_font(24), (170, 175, 182))

    # 2x5 App Grid matching photo (47)
    tiles = [
        ("Search", "search"),
        ("Navigation", "nav"),
        ("Media", "media"),
        ("Phone", "phone"),
        ("Car", "car"),
        ("App Centre", "apps"),
        ("Sport Chrono", "chrono"),
        ("Performance", "perf"),
        ("Parking", "park"),
        ("Apple CarPlay", "carplay"),
    ]
    gx0, gy0 = 188, 115
    tw, th = 252, 248
    gap_x, gap_y = 20, 20
    f_lbl = _load_font(25)

    for idx, (label, kind) in enumerate(tiles):
        r, c = divmod(idx, 5)
        x0 = gx0 + c * (tw + gap_x)
        y0 = gy0 + r * (th + gap_y)
        d.rounded_rectangle([x0, y0, x0 + tw, y0 + th], radius=14, fill=(32, 36, 42), outline=(52, 57, 65), width=2)
        icx, icy = x0 + tw // 2, y0 + 100

        if kind == "search":
            d.ellipse([icx - 28, icy - 28, icx + 16, icy + 16], outline=(240, 243, 248), width=6)
            d.line([(icx + 12, icy + 12), (icx + 34, icy + 34)], fill=(240, 243, 248), width=7)
        elif kind == "nav":
            d.polygon([(icx, icy - 34), (icx - 26, icy + 30), (icx, icy + 16), (icx + 26, icy + 30)], fill=(54, 138, 250))
        elif kind == "media":
            d.rectangle([icx - 16, icy - 28, icx + 22, icy - 18], fill=(238, 64, 56))
            d.rectangle([icx - 16, icy - 22, icx - 8, icy + 22], fill=(238, 64, 56))
            d.rectangle([icx + 14, icy - 22, icx + 22, icy + 16], fill=(238, 64, 56))
            d.ellipse([icx - 30, icy + 10, icx - 6, icy + 32], fill=(238, 64, 56))
            d.ellipse([icx + 0, icy + 4, icx + 24, icy + 26], fill=(238, 64, 56))
        elif kind == "phone":
            d.arc([icx - 26, icy - 26, icx + 26, icy + 26], start=20, end=160, fill=(56, 206, 94), width=14)
            d.ellipse([icx - 30, icy - 12, icx - 10, icy + 8], fill=(56, 206, 94))
            d.ellipse([icx + 10, icy + 12, icx + 30, icy + 32], fill=(56, 206, 94))
        elif kind == "car":
            d.rounded_rectangle([icx - 38, icy - 8, icx + 38, icy + 18], radius=8, fill=(235, 239, 245))
            d.polygon([(icx - 24, icy - 8), (icx - 12, icy - 24), (icx + 16, icy - 24), (icx + 28, icy - 8)], fill=(235, 239, 245))
            d.ellipse([icx - 28, icy + 10, icx - 12, icy + 26], fill=(40, 44, 52))
            d.ellipse([icx + 12, icy + 10, icx + 28, icy + 26], fill=(40, 44, 52))
        elif kind == "apps":
            d.rounded_rectangle([icx - 30, icy - 30, icx - 4, icy - 4], radius=6, outline=(245, 166, 35), width=5)
            d.rounded_rectangle([icx + 4, icy - 30, icx + 30, icy - 4], radius=6, outline=(235, 76, 66), width=5)
            d.rounded_rectangle([icx - 30, icy + 4, icx - 4, icy + 30], radius=6, outline=(52, 168, 235), width=5)
            d.line([(icx + 17, icy + 6), (icx + 17, icy + 28)], fill=(235, 238, 242), width=5)
            d.line([(icx + 6, icy + 17), (icx + 28, icy + 17)], fill=(235, 238, 242), width=5)
        elif kind == "chrono":
            d.ellipse([icx - 28, icy - 24, icx + 28, icy + 32], outline=(235, 238, 242), width=5)
            d.rectangle([icx - 8, icy - 36, icx + 8, icy - 26], fill=(235, 238, 242))
            d.line([(icx, icy + 4), (icx, icy - 14)], fill=(58, 148, 245), width=5)
        elif kind == "perf":
            d.arc([icx - 30, icy - 28, icx + 30, icy + 32], start=160, end=20, fill=(235, 62, 54), width=6)
            d.line([(icx, icy + 4), (icx + 18, icy - 14)], fill=(242, 244, 248), width=5)
            d.rounded_rectangle([icx - 16, icy + 14, icx + 28, icy + 28], radius=5, fill=(230, 234, 240))
        elif kind == "park":
            _draw_centered(d, (icx - 10, icy), "P", _load_font(56, bold=True), (64, 152, 250))
            d.arc([icx + 6, icy - 16, icx + 26, icy + 20], start=-50, end=50, fill=(64, 152, 250), width=4)
            d.arc([icx + 14, icy - 24, icx + 38, icy + 28], start=-50, end=50, fill=(64, 152, 250), width=4)
        elif kind == "carplay":
            d.rounded_rectangle([icx - 32, icy - 32, icx + 32, icy + 32], radius=16, fill=(58, 212, 88))
            d.polygon([(icx - 10, icy - 16), (icx + 20, icy), (icx - 10, icy + 16)], fill=(248, 250, 252))

        _draw_centered(d, (icx, y0 + 202), label, f_lbl, (218, 222, 228))

    # Page indicator dots at bottom
    d.rounded_rectangle([820, 668, 858, 678], radius=5, fill=(235, 238, 242))
    d.ellipse([872, 668, 882, 678], fill=(90, 96, 105))
    d.ellipse([896, 668, 906, 678], fill=(90, 96, 105))

    img.save(out_path)


def _gen_sport_chrono(out_path: str):
    """Generate Sport Chrono stopwatch face matching photo (47): Turbonite outer ring + '9:11'."""
    from PIL import Image, ImageDraw

    S = 512
    img = Image.new("RGB", (S, S), (16, 18, 20))
    d = ImageDraw.Draw(img)
    cx, cy = S // 2, S // 2

    # Outer bezel ring
    d.ellipse([16, 16, S - 16, S - 16], fill=(22, 24, 27), outline=(92, 86, 76), width=10)
    # Turbonite-taupe seconds chapter ring (matching crop_47_chrono_vents.png!)
    d.ellipse([36, 36, S - 36, S - 36], fill=(108, 100, 88))
    # Dark inner dial center
    d.ellipse([104, 104, S - 104, S - 104], fill=(18, 20, 23), outline=(65, 62, 56), width=3)

    f_num = _load_font(26, bold=True)
    for sec in range(60):
        ang = math.radians(-90 + sec * 6)
        r_out = 216
        r_in = 198 if sec % 5 == 0 else 208
        w = 4 if sec % 5 == 0 else 2
        d.line([(cx + math.cos(ang) * r_in, cy + math.sin(ang) * r_in),
                (cx + math.cos(ang) * r_out, cy + math.sin(ang) * r_out)], fill=(235, 232, 224), width=w)
        if sec % 5 == 0:
            lbl = "60" if sec == 0 else str(sec)
            _draw_centered(d, (cx + math.cos(ang) * 174, cy + math.sin(ang) * 174), lbl, f_num, (238, 235, 228))

    # Digital '9:11' readout at 6 o'clock
    _draw_centered(d, (cx, cy + 78), "9:11", _load_font(42, bold=True), (235, 238, 242))

    # Brushed metallic center hand straight up at 12 o'clock
    d.polygon([(cx - 6, cy + 16), (cx + 6, cy + 16), (cx + 3, cy - 196), (cx - 3, cy - 196)], fill=(225, 228, 232))
    d.ellipse([cx - 18, cy - 18, cx + 18, cy + 18], fill=(165, 168, 174), outline=(50, 52, 56), width=4)
    img.save(out_path)


def _gen_porsche_crest_turbonite(out_path: str):
    """Monochrome satin Turbonite Porsche crest strictly clipped inside shield."""
    from PIL import Image, ImageDraw

    S = 512
    # Draw interior artwork on full layer, then clip with crisp anti-aliased shield mask
    art = Image.new("RGBA", (S, S), (42, 40, 36, 255))
    da = ImageDraw.Draw(art)
    cx = S // 2

    # Top banner "PORSCHE"
    da.rectangle([110, 82, 402, 144], fill=(138, 130, 115, 255))
    _draw_centered(da, (cx, 114), "PORSCHE", _load_font(34, bold=True), (26, 24, 22, 255))

    # 4 quadrants (clipped neatly by shield mask below)
    # Top-left & bottom-right: antlers (Turbonite field with dark bars)
    da.rectangle([100, 150, 252, 280], fill=(122, 114, 100, 255))
    for k in range(3):
        yy = 176 + k * 34
        da.line([(146, yy), (236, yy - 8)], fill=(34, 32, 29, 255), width=9)
    da.rectangle([260, 286, 410, 440], fill=(122, 114, 100, 255))
    for k in range(3):
        yy = 312 + k * 30
        da.line([(272, yy), (354, yy - 8)], fill=(34, 32, 29, 255), width=9)

    # Top-right & bottom-left: alternating black & Turbonite stripes
    for k in range(5):
        yy = 150 + k * 26
        col = (32, 30, 28, 255) if k % 2 == 0 else (146, 138, 122, 255)
        da.rectangle([260, yy, 410, yy + 24], fill=col)
    for k in range(6):
        yy = 286 + k * 26
        col = (146, 138, 122, 255) if k % 2 == 0 else (32, 30, 28, 255)
        da.rectangle([100, yy, 252, yy + 24], fill=col)

    # Center Stuttgart escutcheon & clean prancing horse silhouette
    esc = [(202, 198), (310, 198), (310, 292), (256, 344), (202, 292)]
    da.polygon(esc, fill=(162, 154, 138, 255), outline=(36, 34, 30, 255))
    _draw_centered(da, (cx, 218), "STUTTGART", _load_font(15, bold=True), (26, 24, 22, 255))
    horse = [
        (238, 318), (244, 292), (236, 276), (224, 270), (234, 258),
        (246, 252), (242, 240), (256, 232), (268, 238), (264, 248),
        (276, 254), (288, 266), (274, 276), (270, 292), (282, 316),
        (268, 316), (260, 298), (250, 318),
    ]
    da.polygon(horse, fill=(24, 22, 20, 255))

    # Build crisp shield outer border + inner clip mask
    shield_outer = [
        (108, 58), (404, 58), (404, 242),
        (386, 326), (342, 396), (256, 460),
        (170, 396), (126, 326), (108, 242),
    ]
    shield_inner = [
        (126, 76), (386, 76), (386, 240),
        (370, 316), (330, 380), (256, 438),
        (182, 380), (142, 316), (126, 240),
    ]
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon(shield_outer, fill=(142, 134, 118, 255), outline=(58, 54, 48, 255))
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).polygon(shield_inner, fill=255)
    img.paste(art, (0, 0), mask)
    d.line(shield_inner + [shield_inner[0]], fill=(176, 168, 150, 255), width=3)
    img.save(out_path)


def _gen_carbon_twill(out_path: str):
    """Crisp matte 2x2 diagonal twill carbon fiber weave texture."""
    import numpy as np
    from PIL import Image

    S = 512
    yy, xx = np.mgrid[0:S, 0:S]
    cell = 16.0
    u = (xx / cell) % 4.0
    v = (yy / cell) % 4.0
    # 2x2 twill pattern
    phase = (np.floor(u) + np.floor(v)) % 4.0
    is_warp = phase < 2.0
    uf = u % 1.0
    vf = v % 1.0
    # Specular rib shading inside each fiber tow
    warp_val = 46.0 + 38.0 * np.sin(math.pi * uf) * (0.72 + 0.28 * np.sin(math.pi * vf))
    weft_val = 30.0 + 26.0 * np.sin(math.pi * vf) * (0.72 + 0.28 * np.sin(math.pi * uf))
    lum = np.where(is_warp, warp_val, weft_val)
    # Subtle micro-filament grain
    grain = 4.0 * np.sin(xx * 1.7 + yy * 0.4)
    lum = np.clip(lum + grain, 18, 110).astype(np.uint8)
    rgb = np.stack([lum, lum, np.clip(lum.astype(int) + 2, 0, 255).astype(np.uint8)], axis=-1)
    Image.fromarray(rgb, "RGB").save(out_path)


def _gen_perforated_leather(out_path: str):
    """Perforated Black/Slate Porsche leather insert texture matching (48)."""
    import numpy as np
    from PIL import Image

    S = 512
    yy, xx = np.mgrid[0:S, 0:S]
    # Offset dot grid
    step = 16
    gx = (xx % step) - step * 0.5
    gy = (yy % step) - step * 0.5
    r1 = np.sqrt(gx * gx + gy * gy)
    gx2 = ((xx + step // 2) % step) - step * 0.5
    gy2 = ((yy + step // 2) % step) - step * 0.5
    r2 = np.sqrt(gx2 * gx2 + gy2 * gy2)
    r = np.minimum(r1, r2)
    # Subtle dark charcoal leather pebble base with crisp dark micro-perforation holes
    rng = np.random.default_rng(992)
    pebble = rng.normal(0.0, 2.0, (S, S))
    base = 40.0 + pebble
    hole = np.clip((r - 2.6) / 1.1, 0.0, 1.0)
    lum = np.clip(7.0 + (base - 7.0) * hole, 6, 62).astype(np.uint8)
    rgb = np.stack([lum, np.clip(lum.astype(int) + 1, 0, 255).astype(np.uint8), np.clip(lum.astype(int) + 2, 0, 255).astype(np.uint8)], axis=-1)
    Image.fromarray(rgb, "RGB").save(out_path)


def _gen_console_climate_bar(out_path: str):
    """Gloss-black center console HVAC display bar ('22.0  SYNC  22.0')."""
    from PIL import Image, ImageDraw

    W, H = 1024, 256
    img = Image.new("RGB", (W, H), (14, 15, 18))
    d = ImageDraw.Draw(img)
    d.rectangle([6, 6, W - 6, H - 6], outline=(42, 45, 50), width=3)
    _draw_centered(d, (120, 128), "MAX", _load_font(30, bold=True), (190, 196, 204))
    _draw_centered(d, (315, 128), "22.0", _load_font(62, bold=True), (242, 245, 248))
    _draw_centered(d, (512, 128), "SYNC", _load_font(28, bold=True), (180, 186, 194))
    _draw_centered(d, (709, 128), "22.0", _load_font(62, bold=True), (242, 245, 248))
    _draw_centered(d, (904, 128), "AUTO", _load_font(30, bold=True), (190, 196, 204))
    img.save(out_path)


def _gen_sill_turbos(out_path: str):
    """Brushed dark-aluminum door sill treadplate with illuminated 'turbo S' script."""
    import numpy as np
    from PIL import Image, ImageDraw

    W, H = 1024, 256
    rng = np.random.default_rng(711)
    # Brushed horizontal metal grain
    row_noise = rng.normal(0.0, 5.0, (H, 1))
    fine = rng.normal(0.0, 2.0, (H, W))
    base = np.clip(48.0 + row_noise + fine, 26, 76).astype(np.uint8)
    rgb = np.stack([base, base, np.clip(base.astype(int) + 3, 0, 255).astype(np.uint8)], axis=-1)
    img = Image.fromarray(rgb, "RGB")
    d = ImageDraw.Draw(img)
    d.rectangle([18, 22, W - 18, H - 22], outline=(112, 105, 94), width=5)
    _draw_centered(d, (W // 2, H // 2), "turbo S", _load_font(96, bold=True, italic=True), (242, 246, 252))
    img.save(out_path)


def _gen_headrest_turbos(out_path: str):
    """Transparent RGBA debossed italic 'turbo S' decal for seamless leather headrest embossing."""
    from PIL import Image, ImageDraw

    W, H = 512, 256
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    f = _load_font(82, bold=True, italic=True)
    # Crisp debossed rim highlight (bottom-right) + dark recessed letter core — ZERO box border!
    _draw_centered(d, (W // 2 + 2, H // 2 + 3), "turbo S", f, (88, 92, 98, 200))
    _draw_centered(d, (W // 2 - 2, H // 2 - 2), "turbo S", f, (10, 11, 13, 235))
    _draw_centered(d, (W // 2, H // 2), "turbo S", f, (20, 22, 26, 230))
    img.save(out_path)


def _gen_dash_turbos_badge(out_path: str):
    """Passenger-side dark leather strip with fine Turbonite 'turbo S' lettering."""
    from PIL import Image, ImageDraw

    W, H = 1024, 160
    img = Image.new("RGB", (W, H), (44, 47, 52))
    d = ImageDraw.Draw(img)
    # Subtle Turbonite accent line flanking 'turbo S' (matching crop_47_dash_R_door_R.png!)
    d.line([(60, H // 2), (370, H // 2)], fill=(130, 122, 108), width=3)
    d.line([(654, H // 2), (964, H // 2)], fill=(130, 122, 108), width=3)
    _draw_centered(d, (W // 2, H // 2 - 2), "turbo S", _load_font(54, bold=True, italic=True), (174, 165, 148))
    img.save(out_path)


def _gen_visor_airbag_decal(out_path: str):
    """EU passenger sun visor airbag warning label visible at top-right of photo (47)."""
    from PIL import Image, ImageDraw

    W, H = 512, 256
    img = Image.new("RGB", (W, H), (34, 36, 40))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([24, 24, W - 24, H - 24], radius=14, fill=(40, 42, 46), outline=(140, 144, 150), width=4)
    # Yellow header bar
    d.rectangle([28, 28, W - 28, 92], fill=(215, 174, 38))
    _draw_centered(d, (W // 2, 60), "!  AIRBAG", _load_font(40, bold=True), (24, 24, 24))
    # Red prohibited circle + white pictogram
    d.ellipse([70, 114, 174, 218], outline=(212, 44, 40), width=9)
    d.line([(86, 130), (158, 202)], fill=(212, 44, 40), width=9)
    d.rectangle([210, 126, 456, 144], fill=(195, 198, 204))
    d.rectangle([210, 160, 420, 176], fill=(165, 168, 174))
    d.rectangle([210, 192, 380, 208], fill=(165, 168, 174))
    img.save(out_path)


def generate_all_textures(force: bool = False) -> dict:
    """Ensure all PNG textures exist in TEX_DIR and return {name: filepath}."""
    os.makedirs(TEX_DIR, exist_ok=True)
    paths = {name: os.path.join(TEX_DIR, name) for name in REQUIRED_TEXTURES}
    missing = [n for n, p in paths.items() if force or not os.path.exists(p)]
    if not missing:
        return paths

    try:
        import PIL  # noqa: F401
        has_pil = True
    except ImportError:
        has_pil = False

    if not has_pil:
        # Delegate texture generation to system python3 (which has Pillow installed)
        subprocess.run(
            ["python3", os.path.abspath(__file__), "--force" if force else "--ensure"],
            check=True,
        )
        return paths

    _gen_cluster(paths["cluster_992_2_turbos.png"])
    _gen_pcm(paths["pcm_911_turbos.png"])
    _gen_sport_chrono(paths["sport_chrono_face.png"])
    _gen_porsche_crest_turbonite(paths["porsche_crest_turbonite.png"])
    _gen_carbon_twill(paths["carbon_twill_matte.png"])
    _gen_perforated_leather(paths["leather_perforated.png"])
    _gen_console_climate_bar(paths["console_climate_bar.png"])
    _gen_sill_turbos(paths["sill_turbos_plate.png"])
    _gen_headrest_turbos(paths["headrest_turbos.png"])
    _gen_visor_airbag_decal(paths["visor_airbag_decal.png"])
    _gen_dash_turbos_badge(paths["dash_turbos_badge.png"])
    return paths


if __name__ == "__main__":
    force_flag = "--force" in sys.argv
    out = generate_all_textures(force=force_flag)
    print(f"Generated {len(out)} interior textures in {TEX_DIR}")
