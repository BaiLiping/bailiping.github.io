"""
992.2 Porsche 911 Turbo S Cabriolet Inner Door Cards (Left & Right).
Parented directly to Pivot_Door_L and Pivot_Door_R so inner door trim swings cleanly
with the doors in the interactive viewer with ZERO gaps or Z-fighting!

Envelope strictly locked with @exterior (#20):
  - X in [-0.465, +0.605]
  - |Y| <= 0.748 at beltline (Z=0.880), |Y| <= 0.782 mid-door (strictly inboard of outer door skin!)
Details matched directly to 4K studio photos (47) and (48):
  - Upper leather beltline bolster with double Turbonite contrast stitch
  - Horizontal Satin Turbonite trim bar + matte carbon fiber inlay sweeping into recessed door pull lever
  - Seat-memory SET/1/2/3 & lock switch pod (L) / lock switch pod (R)
  - Diagonal-ribbed perforated leather center door insert
  - Sculpted angled leather grab handle & Turbonite-stitched padded armrest
  - Window / mirror switch pod (4-switch + mirror joystick on L; 1-switch on R)
  - Lower map pocket + large angled BOSE speaker mesh grille + metallic BOSE badge + cool-blue ambient LED
"""

import math
import numpy as np
from .geom_utils import (
    create_solidified_grid,
    create_rounded_box,
    create_cylinder,
    create_tube_mesh,
    create_stitch_line,
)


def _build_single_door_card(side: str, parent, mats: dict, cfg: dict) -> list:
    objs = []
    sgn = +1.0 if side == "L" else -1.0

    # ------------------------------------------------------------------
    # 1. Sculpted Main Inner Door Card Backing Shell (strictly inside @exterior envelope!)
    # ------------------------------------------------------------------
    nx_d, nz_d = 22, 16
    xs_d = np.linspace(-0.460, +0.595, nx_d)
    zs_d = np.linspace(0.285, 0.875, nz_d)
    d_grid = np.zeros((nx_d, nz_d, 3), dtype=np.float64)

    for i, x in enumerate(xs_d):
        t_x = (x - (-0.460)) / (0.595 - (-0.460))  # 0=rear door shutline, 1=front hinge
        # Beltline rises very gently rearward matching 992 door shoulder
        z_top = 0.880 - 0.012 * t_x
        z_bot = 0.285 + 0.018 * (1.0 - t_x) ** 2
        for j, _ in enumerate(zs_d):
            t_z = j / float(nz_d - 1)
            z = z_bot + (z_top - z_bot) * t_z
            # Base inner surface strictly inboard of exterior skin (|Y| <= 0.746 at top, <= 0.775 mid)
            y_base = 0.742 + 0.028 * math.sin(math.pi * t_z) - 0.014 * (t_x ** 2)
            # Upper beltline bolster swells slightly inward (cabin-facing) around t_z = 0.85..0.98
            bolster = -0.026 * math.exp(-0.5 * ((t_z - 0.90) / 0.09) ** 2)
            # Sculpted mid-door concavity recess around perforated insert
            recess = +0.014 * math.sin(math.pi * t_x) * math.exp(-0.5 * ((t_z - 0.56) / 0.16) ** 2)
            d_grid[i, j] = (x, sgn * (y_base + bolster + recess), z)

    # Flip V axis on right side so L and R solidify symmetrically INBOARD (strictly |Y| <= 0.782)!
    if sgn < 0:
        d_grid = d_grid[:, ::-1, :]
    objs.append(create_solidified_grid(
        f"TSC_DoorCard_Shell_{side}", d_grid, thickness=0.016,
        material=mats["leather"], parent=parent, offset=-1.0,
    ))

    # Double Turbonite contrast stitch seams running full length of upper door bolster (photo 47!)
    for idx_s, z_off in enumerate((0.854, 0.842)):
        st_pts = []
        for x in np.linspace(-0.440, +0.565, 22):
            t_x = (x - (-0.460)) / (0.595 - (-0.460))
            y = 0.722 - 0.012 * (t_x ** 2)
            st_pts.append((float(x), sgn * y, z_off - 0.010 * t_x))
        objs.append(create_stitch_line(
            f"TSC_DoorCard_UpperStitch_{side}_{idx_s + 1}", st_pts, mats["stitch"], parent=parent, radius=0.0014,
        ))

    # ------------------------------------------------------------------
    # 2. Satin Turbonite Horizontal Trim Bar + Matte Carbon Strip + Door Pull Lever
    # ------------------------------------------------------------------
    # Continuous Satin Turbonite upper door spear (X = -0.43 .. +0.34, Z ~ 0.770)
    bar_pts = []
    for x in np.linspace(-0.435, +0.355, 20):
        t_x = (x - (-0.460)) / (0.595 - (-0.460))
        y = 0.734 - 0.012 * (t_x ** 2)
        z = 0.778 - 0.012 * t_x
        bar_pts.append((float(x), sgn * y, z))
    objs.append(create_tube_mesh(
        f"TSC_DoorCard_TurboniteBar_{side}", bar_pts, radius=0.013, segments=12,
        material=mats["turbonite"], parent=parent, radius_y_scale=0.55,
    ))
    # Matte Carbon Fiber inlay nestled cleanly along the rear/mid length of the Turbonite bar (photo 48!)
    objs.append(create_rounded_box(
        f"TSC_DoorCard_CarbonStrip_{side}",
        (-0.140, sgn * 0.726, 0.775),
        (0.560, 0.012, 0.018),
        material=mats["carbon"], parent=parent, bevel_width=0.0025,
    ))
    # Recessed dark finger pocket + angled Satin Turbonite Inner Door Pull Handle (photo 47!)
    objs.append(create_rounded_box(
        f"TSC_DoorCard_PullRecess_{side}",
        (0.265, sgn * 0.748, 0.772),
        (0.145, 0.022, 0.056),
        material=mats["trim_dark"], parent=parent, bevel_width=0.006,
    ))
    objs.append(create_rounded_box(
        f"TSC_DoorCard_PullLever_{side}",
        (0.285, sgn * 0.726, 0.768),
        (0.125, 0.014, 0.024),
        material=mats["turbonite"], parent=parent, bevel_width=0.004,
        rotation=(0.0, math.radians(-10.0), sgn * math.radians(-8.0)),
    ))

    # Door Lock & Seat-Memory Switch Pod ahead of door pull lever (SET / 1 / 2 / 3 on L; Lock/Unlock on R)
    objs.append(create_rounded_box(
        f"TSC_DoorCard_MemoryPod_{side}",
        (0.398, sgn * 0.725, 0.774),
        (0.072, 0.016, 0.076),
        material=mats["piano_black"], parent=parent, bevel_width=0.003,
        rotation=(0.0, 0.0, sgn * math.radians(-5.0)),
    ))
    n_btns = 4 if side == "L" else 2
    for k in range(n_btns):
        objs.append(create_rounded_box(
            f"TSC_DoorCard_MemBtn_{side}_{k + 1}",
            (0.398, sgn * 0.717, 0.800 - k * 0.016),
            (0.058, 0.004, 0.012),
            material=mats["trim_dark"], parent=parent, bevel_width=0.001,
        ))

    # ------------------------------------------------------------------
    # 3. Diagonal-Ribbed Perforated Leather Mid-Door Insert (photo 47 & 48!)
    # ------------------------------------------------------------------
    nx_p, nz_p = 14, 8
    xs_p = np.linspace(-0.420, +0.260, nx_p)
    zs_p = np.linspace(0.555, 0.735, nz_p)
    p_grid = np.zeros((nx_p, nz_p, 3), dtype=np.float64)
    for i, x in enumerate(xs_p):
        t_x = (x - (-0.460)) / (0.595 - (-0.460))
        for j, z in enumerate(zs_p):
            y = 0.752 - 0.010 * (t_x ** 2)
            # Subtle diagonal stripe channel indents (matching photo 47 & 48!)
            diag = math.sin((x * 16.0 - z * 11.0) * math.pi)
            y += 0.0025 * (diag ** 6)
            p_grid[i, j] = (x, sgn * y, z)
    if sgn < 0:
        p_grid = p_grid[:, ::-1, :]
    objs.append(create_solidified_grid(
        f"TSC_DoorCard_PerfInsert_{side}", p_grid, thickness=0.006,
        material=mats["perforated"], parent=parent, offset=-1.0,
        uv_repeat=(2.5, 1.0),
    ))
    # 4 crisp diagonal bolster stitch stripes across the perforated center insert
    for k in range(4):
        x_start = -0.340 + k * 0.145
        d_pts = [
            (x_start, sgn * 0.747, 0.562),
            (x_start + 0.085, sgn * 0.746, 0.648),
            (x_start + 0.170, sgn * 0.745, 0.730),
        ]
        objs.append(create_stitch_line(
            f"TSC_DoorCard_DiagRib_{side}_{k + 1}", d_pts, mats["leather"], parent=parent, radius=0.0026,
        ))

    # ------------------------------------------------------------------
    # 4. Padded Stitched Leather Armrest, Sculpted Grab Handle & Window Switch Pod
    # ------------------------------------------------------------------
    # Padded Armrest sweeping rearward along mid-lower door (X = -0.435 .. +0.285, Z ~ 0.525)
    objs.append(create_rounded_box(
        f"TSC_DoorCard_Armrest_{side}",
        (-0.080, sgn * 0.706, 0.528),
        (0.715, 0.088, 0.052),
        material=mats["leather"], parent=parent, bevel_width=0.018,
        rotation=(0.0, math.radians(-3.5), 0.0),
    ))
    # Contrast Turbonite stitch along armrest top inner edge
    arm_st = [
        (-0.425, sgn * 0.672, 0.564),
        (-0.080, sgn * 0.670, 0.550),
        (+0.255, sgn * 0.672, 0.535),
    ]
    objs.append(create_stitch_line(
        f"TSC_DoorCard_ArmrestStitch_{side}", arm_st, mats["stitch"], parent=parent, radius=0.0014,
    ))

    # Sculpted Angled Leather Pull Grab Handle sweeping from armrest up into forward door bolster (photo 47!)
    grab_pts = [
        (0.245, sgn * 0.688, 0.535),
        (0.278, sgn * 0.678, 0.605),
        (0.305, sgn * 0.686, 0.678),
        (0.335, sgn * 0.725, 0.708),
    ]
    objs.append(create_tube_mesh(
        f"TSC_DoorCard_GrabHandle_{side}", grab_pts, radius=0.018, segments=14,
        material=mats["leather"], parent=parent, radius_y_scale=0.82,
    ))

    # Window & Mirror Switch Pod recessed into top of armrest
    if side == "L":
        objs.append(create_rounded_box(
            "TSC_DoorCard_WindowPod_L",
            (0.085, +0.696, 0.548), (0.215, 0.056, 0.016),
            material=mats["piano_black"], parent=parent, bevel_width=0.004,
            rotation=(0.0, math.radians(-3.5), 0.0),
        ))
        # 4 window/cab switches + circular mirror joystick
        for k, (sx, sy) in enumerate([(0.155, +0.684), (0.155, +0.708), (0.115, +0.684), (0.115, +0.708)]):
            objs.append(create_rounded_box(
                f"TSC_DoorCard_WinSwitch_L_{k + 1}",
                (sx, sy, 0.556), (0.026, 0.016, 0.008),
                material=mats["trim_dark"], parent=parent, bevel_width=0.002,
            ))
        objs.append(create_cylinder(
            "TSC_DoorCard_MirrorJoystick_L",
            (0.032, +0.696, 0.558), radius=0.014, depth=0.008, axis="Z", segments=20,
            material=mats["trim_dark"], parent=parent, bevel=0.002,
        ))
    else:
        objs.append(create_rounded_box(
            "TSC_DoorCard_WindowPod_R",
            (0.155, -0.696, 0.544), (0.072, 0.038, 0.014),
            material=mats["piano_black"], parent=parent, bevel_width=0.003,
            rotation=(0.0, math.radians(-3.5), 0.0),
        ))

    # ------------------------------------------------------------------
    # 5. Lower Door Map Pocket + Angled BOSE Speaker Grille + Blue Ambient LED
    # ------------------------------------------------------------------
    # Lower sculpted door map pocket rail
    objs.append(create_rounded_box(
        f"TSC_DoorCard_MapPocket_{side}",
        (0.065, sgn * 0.714, 0.352),
        (0.865, 0.054, 0.115),
        material=mats["leather_dark"], parent=parent, bevel_width=0.016,
        rotation=(0.0, math.radians(-4.0), 0.0),
    ))
    # Large angled forward BOSE speaker mesh grille (clearly visible on both doors in photo 47!)
    objs.append(create_rounded_box(
        f"TSC_DoorCard_SpeakerGrille_{side}",
        (0.425, sgn * 0.735, 0.485),
        (0.245, 0.018, 0.175),
        material=mats["speaker_mesh"], parent=parent, bevel_width=0.006,
        rotation=(0.0, math.radians(-12.0), sgn * math.radians(-5.0)),
    ))
    # Brushed aluminum BOSE logo tab on top-front corner of door speaker grille
    objs.append(create_rounded_box(
        f"TSC_DoorCard_BoseBadge_{side}",
        (0.495, sgn * 0.724, 0.555),
        (0.038, 0.005, 0.012),
        material=mats["brushed_alu"], parent=parent, bevel_width=0.001,
        rotation=(0.0, math.radians(-12.0), sgn * math.radians(-5.0)),
    ))
    # Subtle cool-blue ambient LED light tucked beneath armrest / door pocket (visible in photo 47!)
    amb_door = [
        (-0.280, sgn * 0.732, 0.498),
        (0.050, sgn * 0.732, 0.486),
        (0.240, sgn * 0.732, 0.480),
    ]
    objs.append(create_stitch_line(
        f"TSC_DoorCard_AmbientLED_{side}", amb_door, mats["ambient_blue"], parent=parent, radius=0.0024,
    ))

    return objs


def build_door_cards(door_l, door_r, mats: dict, cfg: dict) -> list:
    """Build left & right inner door cards parented directly to Pivot_Door_L and Pivot_Door_R."""
    objs = []
    if door_l is not None:
        objs.extend(_build_single_door_card("L", door_l, mats, cfg))
    if door_r is not None:
        objs.extend(_build_single_door_card("R", door_r, mats, cfg))
    return objs
