"""Rear upper body fitted in the final metre-scale coordinate system.

The square rear registers height and width. The closed-roof overhead fixes
chord and sweep, and the rear quarters distinguish the lamp ends from the LED.
"""
import math

import bpy
import numpy as np
from mathutils import Vector

from .geom_utils import create_quad_grid, create_tube, pchip_eval
from .emblems import emblem
from .rear_lid_opening import build as build_service_opening
from .materials import create_all_materials, make_pbr



def grille_section(y):
    u = abs(y) / .510
    return (-1.969 + .093*u*u, -1.701 + .059*u*u,
            .932 - .013*u*u, 1.004 - .032*u*u)


def grille_point(y, s, depth=0):
    back, front, rear_z, front_z = grille_section(y)
    return ((1-s)*back + s*front, y, (1-s)*rear_z + s*front_z + depth)


def fair_deck(shell):
    # Seat the louver cassette in the painted skin. The transition on each
    # side runs out before reaching the haunch, whose profile is independent.
    for v in shell.data.vertices:
        x,y,z = v.co
        if z < .79 or not (-2.13 < x < -1.42 and abs(y) < .64):
            continue
        back,front,_,_ = grille_section(y)
        s = (x-back)/(front-back)
        lateral = np.clip((.64-abs(y))/.13,0,1)
        ends = np.clip(min((s+.45)/.45,(1.66-s)/.66),0,1)
        blend = lateral*ends
        blend = blend*blend*(3-2*blend)
        target = grille_point(y,s,-.041)[2]
        v.co.z = z + (target-z)*blend
    shell.data.update()


def build_grille(pivot, mats):
    satin=make_pbr("Mat_Deck_Grille_Satin","#4b4c52",metallic=.47,roughness=.33)
    edge=make_pbr("Mat_Deck_Grille_Edge","#3e4044",metallic=.24,roughness=.40,specular_ior=.33)
    ys = np.linspace(-.506,.506,49)
    grid = [[grille_point(y,s,-.025) for s in np.linspace(0,1,8)] for y in ys]
    create_quad_grid("TSC_Rear_Lid_Tray",grid,material=mats["shadow"],parent=pivot)
    # Form the chamfered surround as a continuous surface from its rounded
    # rectangular opening. The forward flange reads wider in the overhead.
    loops = []
    for a in np.linspace(0,2*math.pi,145)[:-1]:
        cy,cs = math.cos(a),math.sin(a)
        u = math.copysign(abs(cy)**.19,cy)
        t = math.copysign(abs(cs)**.18,cs)
        loops.append([grille_point(u*w,.50+t*half,d) for w,half,d in [
            (.518,.532,-.013),(.516,.535,.002),(.511,.530,.005),
            (.493,.426,-.001),(.489,.418,-.005),(.487,.418,-.025)]])
    create_quad_grid("TSC_Rear_Lid_Frame",loops,material=satin,parent=pivot,cyclic_u=True)
    for i,y in enumerate(np.linspace(-.467,.467,21)):
        rib=[]
        for s in np.linspace(.074,.933,10):
            rib.append([grille_point(y+dy,s,z) for dy,z in
                        [(-.005,-.022),(-.005,.000),(-.002,.004),(.003,.003),(.005,0),(.005,-.022)]])
        create_quad_grid(f"TSC_Rear_Lid_Grille_{i:02}",rib,material=edge,parent=pivot,
                         cyclic_v=True,cap_u0=True,cap_u1=True)
    for i,s in enumerate((.28,.53,.77)):
        create_tube(f"TSC_Rear_Lid_Grille_Tie_{i}",[grille_point(y,s,-.013) for y in ys],
                    radius=.0024,segments=6,material=mats["shadow"],parent=pivot)


def build_spoiler(pivot, mats):
    wing_paint=make_pbr("Mat_Active_Wing_Gentian","#162348",metallic=.55,roughness=.21,
                        coat_weight=.86,coat_roughness=.09)
    plinth_paint=make_pbr("Mat_Wing_Base_Gentian","#14254c",metallic=.52,roughness=.19,
                          coat_weight=.87,coat_roughness=.07)
    rings=[]
    for y in np.linspace(-.688,.688,91):
        u=abs(y)/.688
        trailing=-2.195+.135*u**2+.132*u**5
        chord=(.25-.055*u**2) * (.09+.91*math.sqrt(max(0,1-u**6)))
        top=.933-.010*u*u-.012*u**5
        thickness=.026*(1-.63*u**3)
        rings.append([(trailing+s*chord,y,top+h*thickness+.008*s+.032*s*s*(1-u**3))
                      for s,h in [(0,-.31),(.015,-.50),(.12,-.78),(.51,-.91),(.90,-.69),(1,-.28),
                                  (.99,-.11),(.87,.03),(.55,.11),(.20,.09),(.023,0),(0,-.1)]])
    create_quad_grid("TSC_Active_Wing_Mainplane",rings,material=wing_paint,parent=pivot,
                     cyclic_v=True,cap_u0=True,cap_u1=True)
    # Closed aerodynamic plinth. The throat is recessed behind the rounded
    # lips on all four sides and has a continuous dark-blue return.
    sections=[]
    for y in np.linspace(-.493,.493,85):
        u=abs(y)/.493
        x=-2.155+.098*u*u
        low=.826+.005*u*u
        high=.917-.002*u*u
        taper=math.sqrt(max(.001,1-u**12))
        mid=(high+low)/2
        lo,hi=mid-(mid-low)*taper,mid+(high-mid)*taper
        sections.append([(x+.147,y,lo-.014),(x+.014,y,lo-.010),(x-.004,y,lo-.001),
                         (x-.005,y,lo+.005),(x+.009,y,lo+.013*taper),
                         (x+.032,y,lo+.021*taper),(x+.031,y,hi-.016*taper),
                         (x+.005,y,hi-.009*taper),(x-.003,y,hi),(x+.007,y,hi+.004),
                         (x+.145,y,hi+.004)])
    plinth=create_quad_grid("TSC_Active_Wing_Base",sections,material=plinth_paint,parent=pivot,
                            cyclic_v=True,cap_u0=True,cap_u1=True)
    dark=make_pbr("Mat_Spoiler_Recess","#101931",metallic=.30,roughness=.34)
    plinth.data.materials.append(dark)
    for face in plinth.data.polygons:
        verts=tuple(face.vertices)
        if len(verts)==4 and {v%11 for v in verts}=={5,6}:
            face.material_index=1
    rows=[]
    for y in np.linspace(-.232,.232,29):
        x=-2.195+.135*(y/.688)**2+.132*abs(y/.688)**5
        z=.924-.010*(y/.688)**2
        rows.append([(x-.0015,y,z+.0025),(x-.0018,y,z-.0025),(x+.001,y,z-.004)])
    create_quad_grid("TSC_Third_Brake",rows,material=mats["taillight_clear"],parent=pivot)


def build_lights(shell, parent, mats):
    # Ray-cast the rear bumper in its assembled shape. A smooth longitudinal
    # profile carries the lens around the outside corners without panel bleed.
    def back_x(y,z):
        hit,co,_,_=shell.ray_cast(Vector((-3.,float(y),float(z))),Vector((1.,0.,0.)))
        if not hit:
            raise ValueError(f"Rear lamp missed body at {y}, {z}")
        return co.x
    stations=np.array([0.,.20,.40,.54,.64,.70,.75,.79,.82,.840])
    def levels(y):
        u=abs(y)/.84
        return .692+.001*u*u+.009*u**9,.778-.009*u*u+.016*u**9
    # The lens pitches with the surrounding panel as it turns the corner.
    # Sample the upper and lower lips separately to keep the tips flush.
    xt=[back_x(y,levels(y)[1]+.001)-.005 for y in stations]
    xb=[back_x(y,levels(y)[0]-.001)-.005 for y in stations]
    def xr(y,z):
        lo,hi=levels(y)
        s=np.clip((z-lo)/(hi-lo),0.,1.)
        return (1-s)*pchip_eval(stations,xb,abs(y))+s*pchip_eval(stations,xt,abs(y))
    sections=[]
    ledge=[]
    fascia_mat=mats["paint"]
    smoked=make_pbr("Mat_Rear_Light_Band","#18191d",metallic=.05,roughness=.37,specular_ior=.18)
    for y in np.linspace(-.838,.838,125):
        bottom,top=levels(y)
        # Outer-most lens wall closes on a tapered tip visible from either side.
        u=abs(y)/.838
        bottom+=.056*u**42
        profile=[(bottom+.007,.035),(bottom,.003),(bottom+.004,-.002),
                 (bottom+.015,-.005),(top-.014,-.007),(top-.003,-.005),
                 (top,.001),(top-.003,.035)]
        sections.append([(xr(y,z)+offset,y,z) for z,offset in profile])
        # The painted rear apron turns away just below the lower lens edge,
        # then returns to the bumper with a rounded shoulder and crisp break.
        z0=levels(y)[0]-.005
        fade=max(0,1-u**18)
        row=[]
        for drop,offset in [(0,-.001),(.007,.007),(.018,.010),(.045,.007),
                            (.064,.003),(.070,.002),(.077,-.0005),(.089,-.002)]:
            z=z0-drop*max(.03,fade)
            x=back_x(y,z)
            row.append((x-offset*fade,y,z))
        ledge.append(row)
    create_quad_grid("TSC_Rear_Bumper_Lamp_Return",ledge,material=fascia_mat,parent=parent)
    create_quad_grid("TSC_Taillight_Housing",sections,material=smoked,parent=parent,
                     cyclic_v=True,cap_u0=True,cap_u1=True)
    def lens(name,ys,level,height,material):
        rows=[]
        for y in ys:
            z=level(y)
            x=xr(y,z+height*.5)-.015
            rows.append([(x+.008,y,z),(x,y,z+.001),(x-.0025,y,z+.005),(x-.001,y,z+height-.003),
                         (x+.001,y,z+height),(x+.008,y,z+height)])
        create_quad_grid(name,rows,material=material,parent=parent,cyclic_v=True,cap_u0=True,cap_u1=True)
    blade=lambda y:.747-.009*(abs(y)/.77)**2
    lens("TSC_Taillight_Bar",np.linspace(-.791,.791,103),blade,.024,mats["taillight_red"])
    for side,tag in ((1,"L"),(-1,"R")):
        level=lambda y:levels(y)[0]+.009
        lens("TSC_Taillight_Reverse_"+tag,side*np.linspace(.342,.807,60),level,.017,mats["taillight_clear"])
        # Parallel moulded prisms in the clear lower blade.
        for i in range(3):
            pts=[(xr(y,level(y)+.009)-.017,y,level(y)+.003+i*.0045) for y in side*np.linspace(.347,.802,49)]
            create_tube(f"TSC_Taillight_Prism_{tag}_{i}",pts,radius=.0008,segments=5,
                        material=mats["chrome"],parent=parent)
    # Photo traces are shared with the earlier 992652 build. The two emblems
    # are registered to the centreline of this Cabriolet's lens and bumper.
    emblem("TSC_Rear_Porsche","porsche",.544,.018,
           lambda u,v,d:(xr(-u,.714+v)-.017-d,-u,.714+v),mats["porsche_lettering"],parent)
    emblem("TSC_Rear_TurboSBadge","turbo-s",.181,.021,
           lambda u,v,d:(back_x(-u,.663+v)-.018-d,-u,.663+v),mats["turbonite"],parent)



def build():
    shell=bpy.data.objects["TSC_Body_Shell"]
    mats=create_all_materials()
    fair_deck(shell)
    build_grille(bpy.data.objects["Pivot_Rear_Lid"],mats)
    build_spoiler(bpy.data.objects["Pivot_Active_Wing"],mats)
    build_lights(shell,bpy.data.objects["Pivot_Body_Assembly"],mats)
    build_service_opening(shell, bpy.data.objects["Pivot_Body_Assembly"], grille_point)
