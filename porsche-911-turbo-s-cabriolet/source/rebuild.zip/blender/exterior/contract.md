# Porsche 911 Turbo S Cabriolet (992.2 T-Hybrid) — Blender Coordinate, Rig & Module Contract (v2 — Aligned with `web/rig_contract.md`)

**Owner:** `@exterior` (`blender/exterior/`, `blender/build_master.py`, `blender/out/`)
**Aligned 100% with:** `web/rig_contract.md` (`@viewer`) and official MY T 10/2025 factory PDF (`@refs`).

## 1. Units, Axes & Origin
- **Blender Master (`.blend` & build modules):** `1:1` real-world **meters** (`1 BU = 1.0 m`), Z-up right-handed:
  - `+X` = Forward (front bumper nose), `-X` = Rearward (tail)
  - `+Y` = Left (driver side, LHD), `-Y` = Right (passenger / fuel-flap side)
  - `+Z` = Up (`Z = 0.0` = ground plane under tire contact patches)
  - `X = 0.0` = Wheelbase midpoint (`X_FRONT_AXLE = +1.225 m`, `X_REAR_AXLE = -1.225 m`)
  - `Y = 0.0` = Longitudinal symmetry centerline
- **Exported GLB (`blender/out/porsche_911_turbo_s_cab.glb`):**
  - `export_yup=True`, Draco compressed (`level=6`, pos 14, normal 10, uv 12).
  - Scaled cleanly on export by `S = 1000.0 / 18.0 = 55.55555555555556` (**1:18-scale mm**, GT3 standard) baked into mesh vertices & pivot locations so **every `Pivot_*` node has `scale = [1, 1, 1]` and identity `rotation = [0, 0, 0, 1]`**.
  - glTF Y-up axes: `+X` forward, `+Y` up, `+Z` right (`-Z` left/driver).

## 2. Factory Dimensional Datums (2026 Porsche 911 Turbo S Cabriolet, 992.2 T-Hybrid)
- Length: `4.551 m` (`X_NOSE = +2.241 m`, `X_TAIL = -2.310 m`, front overhang `1.016 m`, rear overhang `1.085 m`)
- Width: `1.900 m` body (`±0.950 m` at rear haunches), `2.033 m` across mirrors (`±1.0165 m`)
- Height: `1.304 m` (soft-top UP)
- Wheelbase: `2.450 m` (`X_F = +1.225 m`, `X_R = -1.225 m`)
- Front track: `1.583 m` (`Y_FL = +0.7915 m`, `Y_FR = -0.7915 m`), tire `255/35 ZR20` (`OD = 0.6865 m`, `R = 0.34325 m`, `Z_hub = 0.338 m`)
- Rear track: `1.588 m` (`Y_RL = +0.7940 m`, `Y_RR = -0.7940 m`), tire `325/30 ZR21` (`OD = 0.7284 m`, `R = 0.36420 m`, `Z_hub = 0.358 m`)
- Brakes: Front PCCB `420 × 40 mm` (yellow 10-piston caliper rear of front axle), Rear PCCB `410 × 32 mm` (yellow 4-piston caliper front of rear axle)

## 3. Shared `Pivot_*` Hierarchy (verbatim from `web/rig_contract.md`)
```text
TurboSCab_Interactive_Rig
├── Pivot_Body_Assembly           [exterior]
│   ├── Pivot_Door_L              [exterior] hinge at (+0.635, +0.845, 0.560)
│   ├── Pivot_Door_R              [exterior] hinge at (+0.635, -0.845, 0.560)
│   ├── Pivot_Front_Lid           [exterior] hinge at (+0.785,  0.000, 0.845)
│   ├── Pivot_Fuel_Flap           [exterior] hinge at (+1.075, -0.865, 0.785) (right front fender)
│   │   └── Pivot_Fuel_Cap        [exterior]
│   ├── Pivot_Soft_Top            [exterior] fabric roof UP + rear glass window
│   ├── Pivot_Soft_Top_Stowed     [exterior] folded black tonneau stack (hidden by default)
│   ├── Pivot_Rear_Lid            [exterior] louvered rear engine decklid / service cover
│   └── Pivot_Active_Wing         [exterior] deployable Turbo S rear spoiler + 3rd brake light
├── Pivot_Drivetrain_Chassis      [mechanicals] (0,0,0) — floor, subframes, 400V HV battery, PTM, PDK_Case_* + internals
├── Pivot_Flat6_Engine            [mechanicals] (0,0,0) — 3.6L twin-eTurbo flat-6
├── Pivot_Exhaust_System          [mechanicals] (0,0,0) — headers, cats, silencer, twin-barrel titanium tips
├── Pivot_Interior_Cabin          [exterior/interior] (0,0,0) — 2+2 cabin, dash, PCM, seats, roll hoops
├── Pivot_Corner_FL / FR          [mechanicals] at (+1.225, ±0.7915, 0.338) -> Pivot_WheelSpin_FL / FR
└── Pivot_Corner_RL / RR          [mechanicals] at (-1.225, ±0.7940, 0.358) -> Pivot_WheelSpin_RL / RR
```

## 4. Module Entrypoint Contract (`build_master.py`)
Every module (`blender/exterior/build_exterior.py`, `blender/mechanicals/build_mechanicals.py`, optional `blender/interior/build_interior.py`) exposes:
```python
def build(rig_root: bpy.types.Object, cfg: dict) -> dict[str, bpy.types.Object]:
    ...
```
- All mesh names use prefix `TSC_` and match `web/rig_contract.md` Section 3 tokens.
- All material names match `web/rig_contract.md` Section 3 (`Mat_Gentian_Blue_Metallic`, `Mat_SoftTop_Fabric`, `Mat_Turbonite_Alloy`, `Mat_PCCB_Caliper_Yellow`, `Mat_PCCB_Ceramic_Rotor`, `Mat_Automotive_Glass`, `Mat_Rear_Window_Smoke`, `Mat_Fixed_Quarter_Glass`, `Mat_Headlight_Clear_Lens`, `Mat_Front_Honeycomb`, `Mat_Cabin_Rearview`, `Mat_Cabin_*`).
- Wheelhouse & exhaust envelopes for `@mechanicals`:
  - Front arch cutout center `(+1.225, Z=0.338)`, radius `0.376 m`, inner well wall `|Y| = 0.545 m`.
  - Rear arch cutout center `(-1.225, Z=0.358)`, radius `0.398 m`, inner well wall `|Y| = 0.525 m`.
  - Exhaust tip cutout centers: `X = -2.265 m`, `Y = ±0.560 m`, `Z = 0.275 m` (opening width `0.255 m`, height `0.108 m`).
  - Underbody clearance: chassis floor pan bottom at `Z = 0.125 m` (rocker sill bottom `Z = 0.130 m`).
