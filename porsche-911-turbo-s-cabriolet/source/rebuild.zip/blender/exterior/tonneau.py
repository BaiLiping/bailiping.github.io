"""Roof-down tonneau and shutlines traced from studio frames 44, 50 and 51."""
import numpy as np

from .geom_utils import create_quad_grid, create_tube, pchip_eval
from .materials import make_pbr
from .surface_fit import FIT_PATH, displacement
from .rear_upper import grille_section

def build(pivot, mats):
    # Use the assembled metric frame for matching the overhead shape and
    # side elevation. The master applies the body fit to this assembly later.
    field = np.load(FIT_PATH)['field'] if FIT_PATH.exists() else None
    def rest(points):
        pts=np.asarray(points,float)
        if field is None:
            return pts
        shape=pts.shape
        target=pts.reshape(-1,3)
        fit=target.copy()
        for i in range(6):
            fit=target-displacement(fit,field)
        return fit.reshape(shape)

    # In plan, the black tray rounds forward at the rear quarters and wraps
    # the rear seats. The high point of the folded cover is behind the rim.
    ys=np.linspace(-.694,.694,81)
    ay=abs(ys)
    aft=pchip_eval([0,.23,.38,.46,.51,.57,.61,.65,.674,.694],
                   [-1.501,-1.492,-1.470,-1.446,-1.407,-1.334,-1.19,-.99,-.812,-.525],ay)
    front=pchip_eval([0,.39,.455,.49,.515,.543,.58,.615,.66,.694],
                     [-1.01,-1.008,-.994,-.961,-.86,-.65,-.512,-.502,-.502,-.504],ay)
    def height(x,y):
        xx=np.asarray(x)
        centre=pchip_eval([-1.78,-1.70,-1.61,-1.50,-1.41,-1.28,-1.13,-1.04,-.97,-.83,-.65,-.50],
                          [.985,1.006,1.032,1.049,1.062,1.069,1.069,1.057,1.030,1.004,.955,.924],xx)
        # Crossfall grows over the haunches. The surface remains above the
        # underlying deck behind the seatbacks in the assembled car.
        return centre-.084*(abs(np.asarray(y))/.70)**2.6
    def section(x,y,dz=0):
        return np.stack(np.broadcast_arrays(x,y,height(x,y)+dz),axis=-1)
    rows=[section(aft+t*(front-aft),ys) for t in np.linspace(0,1,27)]
    textile = make_pbr('Tonneau facing fabric', '#222327', roughness=.87, specular_ior=.24)
    seal = make_pbr('Tonneau moulded edge', '#333337', roughness=.58, specular_ior=.34)
    create_quad_grid('TSC_Soft_Top_Stowed',rest(rows),material=textile,parent=pivot)
    # The aft junction is about 20 cm ahead of the centre grille frame. Blend
    # the blue strip to both rear quarters, following the U-shaped fabric edge.
    edge_x=np.array([grille_section(y)[1] for y in ys])+.003
    edge_z=np.array([grille_section(y)[3] for y in ys])-.001
    side=np.clip((ay-.50)/.194,0,1)
    edge_x+=side**2*(-.544-edge_x)
    edge_z=(1-side)*edge_z+side*(height(edge_x,ys)-.016)
    rows=[]
    for t in np.linspace(0,1,22):
        x=(1-t)*edge_x+t*aft
        z=(1-t)*edge_z+t*(height(aft,ys)-.002)+.004*np.sin(np.pi*t)*(1-side)
        rows.append(np.stack((x,ys,z),axis=1))
    create_quad_grid('TSC_Tonneau_Painted_Deck',rest(rows),material=mats['paint'],parent=pivot)
    aft_seal=section(aft,ys,.0005)
    create_tube('TSC_Tonneau_Aft_Seal',rest(aft_seal),radius=.0052,segments=8,material=seal,parent=pivot)
    # A padded horseshoe rail frames the rear seats. The black bulkhead meets
    # the seatbacks below the rail and closes the formerly open well.
    lip=[]
    for shift,dz in ((-.012,-.008),(-.01,.001),(-.004,.007),(.004,.008),(.012,.002),(.014,-.010)):
        lip.append(section(front+shift,ys,dz))
    create_quad_grid('TSC_Tonneau_Cabin_Rim',rest(lip),material=seal,parent=pivot)
    wall=[]
    for t in np.linspace(0,1,9):
        wall.append(section(front+.006+.048*t,ys,-.007-.27*t))
    create_quad_grid('TSC_Tonneau_Well_Trim',rest(wall),material=mats['soft_top'],parent=pivot)

    # In overhead and high rear views the rollover module outlines flank the
    # rear bulkhead. They are flush flaps in the textile-covered deck.
    for side,tag in [(1,'L'),(-1,'R')]:
        ang=np.linspace(0,2*np.pi,64,endpoint=False)
        cs,sn=np.cos(ang),np.sin(ang)
        x=-1.090+.043*np.sign(cs)*abs(cs)**.30
        y=side*(.325+.112*np.sign(sn)*abs(sn)**.30)
        create_tube('TSC_Tonneau_Rollover_Cover_'+tag,rest(section(x,y,.0018)),
                    radius=.0012,segments=6,material=mats['shadow'],parent=pivot,cyclic=True)
