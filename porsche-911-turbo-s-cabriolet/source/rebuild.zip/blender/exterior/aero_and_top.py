"""
Convertible Soft-Top (UP & Stowed DOWN) and Active Aerodynamics for the
2026 Porsche 911 Turbo S Cabriolet (992.2 T-Hybrid) — v3 Polished:
  - Pivot_Soft_Top        : Raised black canvas top, low-crown heated rear glass,
                            ceramic border, perimeter seal and lined roof well.
  - Pivot_Soft_Top_Stowed : Folded matte-black horseshoe Z-fold fabric tonneau cover (roof DOWN state!)
  - Pivot_Active_Wing     : Bold, sleek sculpted curved Gentian Blue Turbo S deployable wing
                            with clean recessed under-cradle & horizontal LED 3rd brake light
  - Front Active Aero     : 5 vertical active cooling flaps per side nestled RECESSED inside the
                            front bumper intakes above a crisp Gentian Blue chin bar + splitter
  - Side Aero & Intakes   : Satin-black side skirts + accurately slanted Turbo rear-quarter intakes
  - Rear Diffuser & Tips  : Recessed exhaust pocket + 4 vertical diffuser strakes + outboard gills +
                            unobstructed figure-8 Turbonite exhaust bezels framing @mechanicals' twin pipes!
"""

import math
import numpy as np
import bpy
from mathutils import Vector

from .materials import make_pbr
from . import config as cfg
from .geom_utils import (
    ensure_empty,
    pchip_eval,
    smootherstep,
    create_quad_grid,
    create_solidified_panel,
    create_mesh_object,
    create_rounded_box,
    create_tube,
)
from .body_shell import (
    eval_flank_y,
    eval_y_max,
    eval_y_belt,
    eval_z_bot,
    eval_z_shoulder,
    eval_rear_deck_z,
    eval_front_wrap_xy,
    front_surface_x_at_y,
    rear_surface_x_at_y,
    query_front_surface_x,
    query_rear_surface_x,
)


def eval_soft_top_z(x):
    return pchip_eval(cfg.SOFT_TOP_X, cfg.SOFT_TOP_Z, x)


def eval_soft_top_rail_y(x):
    return pchip_eval(cfg.SOFT_TOP_X, cfg.SOFT_TOP_RAIL_Y, x)


def eval_soft_top_base_y(x):
    return pchip_eval(cfg.SOFT_TOP_X, cfg.SOFT_TOP_BASE_Y, x)


def _eval_soft_top_pt(x: float, u: float):
    au = abs(u)
    sign = 1.0 if u >= 0 else -1.0
    z_c = float(eval_soft_top_z(x))
    y_rail = float(eval_soft_top_rail_y(x))
    y_base = float(eval_soft_top_base_y(x))

    sail_blend = 1.0 - smootherstep(-0.86, -0.34, x)
    # Unbroken sleek coupe-like side arch flowing cleanly from windshield header (-0.002, 1.206)
    z_arch = cfg.Z_HEADER_SIDE + 0.022 * math.sin(math.pi * np.clip((0.01 - x) / 0.54, 0.0, 1.0)) - 0.15 * smootherstep(-0.34, -0.82, x)
    z_deck = float(eval_z_shoulder(x)) + 0.008
    z_edge = z_arch * (1.0 - sail_blend) + z_deck * sail_blend
    y_edge = (y_rail + 0.010) * (1.0 - sail_blend) + y_base * sail_blend

    # Narrower, tauter trapezoidal roof crown matching 4K rear (13) & front (36)!
    y = sign * (y_edge * (0.74 * au + 0.26 * (au ** 0.88)))
    crown_pow = 2.25 * (1.0 - sail_blend) + 1.80 * sail_blend
    z = z_edge + (z_c - z_edge) * (1.0 - au ** crown_pow)
    bow = 0.0015 * (math.exp(-((x + 0.35) / 0.04) ** 2) + math.exp(-((x + 0.72) / 0.04) ** 2)) * (1.0 - au * au)
    return (float(x), float(y), float(z + bow))


# ---------------------------------------------------------------------------
# 1. Convertible Soft-Top UP (Pivot_Soft_Top) & Stowed DOWN (Pivot_Soft_Top_Stowed)
# ---------------------------------------------------------------------------
def build_soft_top_up(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    piv = ensure_empty("Pivot_Soft_Top", cfg.PIVOT_LOCATIONS["Pivot_Soft_Top"], parent=body_pivot)

    # The lower and upper edges came from tracing the glass in the rear,
    # both quarters and the two elevated views. Coordinates describe the
    # assembled car after its silhouette calibration, in metres.
    from .surface_fit import FIT_PATH, displacement
    field = np.load(FIT_PATH)["field"] if FIT_PATH.exists() else None

    def fitted(points):
        return points if field is None else points + displacement(points, field)

    def rest_positions(points):
        # Invert the body calibration once for the aperture and its surround.
        # build_master applies the same field to the complete assembly later.
        if field is None:
            return points
        rest = points.copy()
        for _ in range(10):
            rest += points - fitted(rest)
        return rest

    # Travel continuously around the four sides of a square. Project the
    # square onto a superellipse to sample the radiused glass corners evenly.
    side = np.linspace(-1.0, 1.0, 40, endpoint=False)
    s = np.concatenate([side, np.ones_like(side), -side, -np.ones_like(side)])
    t = np.concatenate([-np.ones_like(side), side, np.ones_like(side), -side])
    radius = (abs(s)**4.56 + abs(t)**4.56)**(1/4.56)
    u, v = s/radius, t/radius

    def pane(u, v):
        forward = (u + 1) / 2
        half_width = .429 + .016 * forward
        x = -1.417 + .402 * forward + (.021 + .002 * forward) * v**2
        # Shallow transverse crown and a slight longitudinal bow. The
        # flexible sail panels turn down much more sharply than the glass.
        z = 1.080 + .121 * forward - (.015 - .006 * forward) * v**2
        z += .003 * (1-u**2) * (1-v**2)
        return np.stack([x, half_width*v, z], axis=-1)

    edge = pane(u, v)
    # The bonding band is wider at the upper edge. Give the glass and
    # ceramic border a shared edge and one thin rubber-to-fabric joint.
    frit_u = .886*u - .040
    frit_v = .930*v
    glass_rows = [pane(frit_u*f, frit_v*f) for f in np.linspace(.06, 1.0, 16)]
    glass_rows.append(edge)
    glass_grid = rest_positions(np.concatenate(glass_rows)).reshape(len(glass_rows), len(u), 3)
    glass = create_quad_grid("TSC_Glass_Rear", glass_grid, material=mats["rear_glass"],
                             parent=piv, cyclic_v=True, cap_u0=True)
    glass.data.materials.append(mats["rear_window_frit"])
    first_frit = (len(glass_rows)-2) * len(u)
    # create_quad_grid appends its centre cap after the annular faces.
    for face in glass.data.polygons:
        if first_frit <= face.index < first_frit + len(u):
            face.material_index = 1

    seam_x = -.765
    # Reconstruct the canvas from the aperture out to the existing rails
    # and header. The bottom hem sweeps forward around the rear quarters.
    def canvas_limit(a, b):
        if a == -1:
            x = -1.501 + .028*b*b + .126*abs(b)**6
            y = .667*b
            return (x, y, float(eval_rear_deck_z(x, y)) + .004)
        if abs(b) == 1:
            x = -.5*(1-a)*1.347 + .5*(1+a)*seam_x
            _, y, z = _eval_soft_top_pt(x, b)
            blend = 1 - smootherstep(-1.347, -1.08, x)
            y = y*(1-blend) + b*.667*blend
            z += blend*(float(eval_rear_deck_z(x,y))+.004-z)
            return (x,y,z)
        return _eval_soft_top_pt(seam_x, b)

    limit = fitted(np.array([canvas_limit(a,b) for a,b in zip(s,t)]))
    rings = []
    rim = edge.copy()
    rim[:,2] += .0015
    for r in np.linspace(0, 1, 20):
        rings.append((1-r)*rim + r*limit)
    shell = np.asarray(rings)

    # Stitch the forward panel and annulus along the same seam vertices.
    n = len(u)
    verts = shell.reshape(-1,3).tolist()
    faces = [(row*n+i,row*n+(i+1)%n,(row+1)*n+(i+1)%n,(row+1)*n+i)
             for row in range(len(rings)-1) for i in range(n)]
    span = np.linspace(-1,1,len(side)+1)
    prev = [(len(rings)-1)*n + len(side)+i for i in range(len(span))]
    for x in np.linspace(seam_x, cfg.X_HEADER_CENTER + .016, 32)[1:]:
        cur = list(range(len(verts),len(verts)+len(span)))
        verts.extend(fitted(np.array([_eval_soft_top_pt(x,b) for b in span])))
        faces.extend((prev[i],cur[i],cur[i+1],prev[i+1]) for i in range(len(span)-1))
        prev = cur
    # A minimum-bending surface fairs the sewn canvas between the measured
    # glass, hem, roof rails, front header and crown. The glass ring alone
    # cannot constrain the fabric tangents near the sail shoulders.
    body = np.asarray(verts)
    guides = [rim[::3], pane(u[::6]*.76, v[::6]*.76)]
    outer = limit[(s != 1) | (abs(t) == 1)]
    guides.append(outer[::2])
    guide_x = np.linspace(seam_x, cfg.X_HEADER_CENTER+.016, 11)
    fore = [_eval_soft_top_pt(x,b) for x in guide_x for b in (-1,-.70,0,.70,1)]
    fore.extend(_eval_soft_top_pt(guide_x[-1],b) for b in span[::4])
    guides.append(fitted(np.asarray(fore)))
    guides = np.unique(np.concatenate(guides).round(6), axis=0)

    def bending_basis(points):
        delta = points[:,None,:2] - guides[None,:,:2]
        squared = np.sum(delta*delta,axis=2)
        radial = squared*np.log(np.maximum(squared,1e-14))
        affine = np.column_stack((np.ones(len(points)), points[:,:2]))
        return radial, affine

    kernel, affine = bending_basis(guides)
    kernel.flat[::len(guides)+1] += 1e-6
    system = np.block([[kernel,affine],[affine.T,np.zeros((3,3))]])
    weights = np.linalg.solve(system, np.r_[guides[:,2], [0,0,0]])
    kernel, affine = bending_basis(body)
    body[:,2] = kernel@weights[:-3] + affine@weights[-3:]
    body[:n] = rim
    verts = rest_positions(body)
    fabric = create_mesh_object("TSC_Soft_Top_Fabric", verts, faces, material=mats["soft_top"], parent=piv)
    lining = fabric.modifiers.new("Canvas thickness","SOLIDIFY")
    lining.thickness = .004
    lining.offset = -1
    seal = rest_positions((rim+edge)/2)
    create_tube("TSC_Rear_Window_Seal", seal, radius=.0020, segments=6,
                material=mats["matte_trim"], parent=piv, cyclic=True)

    # With the roof raised, the lined top well closes the space from the
    # rear seat bulkhead to the deck hem. It folds away with the top.
    liner = []
    for fraction in np.linspace(0, 1, 19):
        row = []
        for b in np.linspace(-1, 1, 37):
            x_aft = -1.486 + .026*b*b + .125*abs(b)**6
            x_front = -1.030 + .034*b*b
            x = (1-fraction)*x_aft + fraction*x_front
            y = b*(.645+.013*fraction)
            deck = float(eval_rear_deck_z(x,y)) + .007
            z = deck + (.945 - deck)*smootherstep(-1.28,-1.03,x)
            row.append((x,y,z))
        liner.append(row)
    create_solidified_panel("TSC_Soft_Top_Well_Lining", liner, thickness=.004,
                            material=mats["soft_top"], parent=piv)

    # Fixed rear quarter side glass panes + ultra-thin frameless matte-black B-seal (auto-hides on roof DOWN!)
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        q_xs = np.linspace(-0.715, -0.340, 12)
        q_grid = []
        for x in q_xs:
            z_lo = float(eval_z_shoulder(x)) - 0.010
            frac = smootherstep(-0.715, -0.340, x)
            z_hi = z_lo + 0.035 + (1.222 - z_lo - 0.035) * (frac ** 0.72)
            y_lo = float(eval_y_belt(x)) - 0.016
            y_hi = y_lo - (z_hi - z_lo) * 0.48
            q_grid.append([(x, sign * (y_lo + (y_hi - y_lo) * s + 0.010 * math.sin(math.pi * s)), z_lo + (z_hi - z_lo) * s)
                           for s in np.linspace(0.0, 1.0, 7)])
        create_quad_grid(f"TSC_Glass_Quarter_{tag}", q_grid, material=mats["quarter_glass"], parent=body_pivot, smooth=True, flip_faces=(sign > 0))
        b_pts = [
            (-0.339, sign * (float(eval_y_belt(-0.339)) - 0.016), float(eval_z_shoulder(-0.339)) - 0.006),
            (-0.339, sign * (float(eval_y_belt(-0.339)) - 0.168), 1.224),
        ]
        create_tube(f"TSC_Glass_Quarter_Seal_{tag}", b_pts, radius=0.0028, segments=8, material=mats["soft_top"], parent=body_pivot)

    return piv


def build_soft_top_stowed(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    piv = ensure_empty("Pivot_Soft_Top_Stowed", cfg.PIVOT_LOCATIONS["Pivot_Soft_Top_Stowed"], parent=body_pivot)

    from .tonneau import build as build_tonneau
    build_tonneau(piv, mats)
    return piv


# ---------------------------------------------------------------------------
# 2. Sleek Curved Gentian Blue Active Turbo S Rear Wing (B3!)
# ---------------------------------------------------------------------------
def build_active_wing(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    """
    Sculpted curved Gentian Blue 992.2 Turbo S deployable wing in studio cradle pose (B3: lowered -24 mm,
    sleek curved outer tips, low subtle dark cradle recess underneath instead of tall black box!).
    """
    piv = ensure_empty("Pivot_Active_Wing", cfg.PIVOT_LOCATIONS["Pivot_Active_Wing"], parent=body_pivot)
    piv["wingOffset"] = [-0.035 * cfg.EXPORT_SCALE, 0.055 * cfg.EXPORT_SCALE, 0.0]
    piv["wingTilt"] = 0.14

    return piv


# ---------------------------------------------------------------------------
# 3. Front 992.2 Active Aero (5 Vertical Flaps/Side RECESSED Flush Inside Bumper!)
# ---------------------------------------------------------------------------
def build_front_aero(body_pivot: bpy.types.Object, mats: dict):
    """5 vertical dark active flaps flush-recessed at exact photo height Z=[0.192, 0.378] (view-35/48!)."""
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        y0, y1 = 0.365, 0.725
        z0, z1 = 0.192, 0.378

        # Dark backing plenum deep inside bumper pocket
        plen_grid = []
        for s in np.linspace(0.0, 1.0, 11):
            yy = y0 + (y1 - y0) * s
            xx = query_front_surface_x(sign * yy, 0.285, unrecessed=True) - 0.072
            plen_grid.append([(xx, sign * yy, z0), (xx, sign * yy, z1)])
        create_quad_grid(f"TSC_Front_Intake_Plenum_{tag}", plen_grid, material=mats["shadow"], parent=body_pivot, flip_faces=(sign < 0))

        # Smooth rounded-corner superellipse matte-black surround bezel hugging curved front bumper (photo 36!)
        ym, zm = 0.5 * (y0 + y1), 0.5 * (z0 + z1)
        hy, hz = 0.5 * (y1 - y0), 0.5 * (z1 - z0)
        perim = []
        for a in np.linspace(0.0, 2.0 * math.pi, 36, endpoint=False):
            ca, sa = math.cos(a), math.sin(a)
            yy = ym + hy * math.copysign(abs(ca) ** 0.38, ca)
            zz = zm + hz * math.copysign(abs(sa) ** 0.38, sa)
            perim.append((query_front_surface_x(sign * yy, zz, unrecessed=True) - 0.014, sign * yy, zz))
        create_tube(f"TSC_Front_Intake_Frame_{tag}", perim, radius=0.0080, segments=10, material=mats["matte_trim"], parent=body_pivot, cyclic=True)

        # Recessed transverse radiator fins remain visible between the five shutters.
        fins = []
        for height in np.linspace(z0+0.008,z1-0.006,22):
            for yy in np.linspace(y0+0.004, y1-0.004,11):
                xx = query_front_surface_x(sign*yy, 0.285, unrecessed=True) - 0.050
                fins.extend([(xx,sign*yy,height), (xx+.001,sign*yy,height+.0026)])
        fin_faces = []
        for row in range(22):
            for col in range(10):
                i = row*22+col*2
                fin_faces.append((i,i+2,i+3,i+1))
        create_mesh_object(f'TSC_Front_Intake_Cooling_Fins_{tag}',fins,fin_faces,
                           material=mats['matte_trim'],parent=body_pivot,smooth=False)

        # 5 INDIVIDUAL VERTICAL ACTIVE COOLING FLAPS recessed cleanly behind curved bumper skin!
        flap_verts, flap_faces = [], []
        for k in range(5):
            frac = (k + 0.5) / 5.0
            yy_c = y0 + (y1 - y0) * frac
            xx_surf = query_front_surface_x(sign * yy_c, 0.285, unrecessed=True)
            xx_front = xx_surf - 0.028
            fw = 0.034
            f_depth = 0.022
            # Exact tangent along curved bumper corner: yaw = -sign * atan(dx/d|y|) so flaps curve BACK with corner!
            dx_dy = (query_front_surface_x(sign * (yy_c + 0.015), 0.285, unrecessed=True) -
                     query_front_surface_x(sign * (yy_c - 0.015), 0.285, unrecessed=True)) / 0.030
            yaw = -sign * math.atan(dx_dy)
            cy, sy = math.cos(yaw), math.sin(yaw)

            base_i = len(flap_verts)
            zs_f = np.linspace(z0 + 0.006, z1 - 0.006, 7)
            for zz in zs_f:
                bow = 0.006 * math.sin(math.pi * (zz - z0) / (z1 - z0))
                loc_pts = [
                    (+f_depth * 0.5 + bow, -fw), (+f_depth * 0.5 + bow, +fw),
                    (-f_depth * 0.5 + bow, +fw * 0.88), (-f_depth * 0.5 + bow, -fw * 0.88),
                ]
                for lx, ly in loc_pts:
                    flap_verts.append((xx_front + lx * cy - ly * sy, sign * yy_c + lx * sy + ly * cy, zz))
            for iz in range(len(zs_f) - 1):
                a = base_i + 4 * iz
                b = base_i + 4 * (iz + 1)
                flap_faces.extend([(a, a + 1, b + 1, b), (a + 1, a + 2, b + 2, b + 1), (a + 2, a + 3, b + 3, b + 2), (a + 3, a, b, b + 3)])
            flap_faces.append((base_i, base_i + 3, base_i + 2, base_i + 1))
            tb = base_i + 4 * (len(zs_f) - 1)
            flap_faces.append((tb, tb + 1, tb + 2, tb + 3))
        create_mesh_object(f"TSC_Active_Flap_{tag}", flap_verts, flap_faces, material=mats["intake_grille"], parent=body_pivot, smooth=False)

    # Recessed center lower radiator duct + 7 crisp horizontal slats (exact view-35/48 height!)
    x_rad = query_front_surface_x(0.0, 0.245, unrecessed=True) - 0.055
    create_rounded_box("TSC_Front_Radiator", (x_rad, 0.0, 0.245), (0.032, 0.580, 0.128), material=mats["shadow"], parent=body_pivot, bevel_width=0.004)
    for iz, zz in enumerate(np.linspace(0.192, 0.298, 7)):
        pts = [(query_front_surface_x(y, zz, unrecessed=True) - 0.032, y, zz) for y in np.linspace(-0.280, 0.280, 11)]
        create_tube(f"TSC_Front_Grille_Center_{iz}", pts, radius=0.0038, segments=6, material=mats["intake_grille"], parent=body_pivot)

    # Slim satin-black lower front chin splitter hugging bottom bumper edge tightly (exact view-35 chin height!)
    sp_grid = []
    for y in np.linspace(-0.82, 0.82, 41):
        xx = query_front_surface_x(y, 0.148, unrecessed=True)
        z_b = float(eval_z_bot(min(xx, cfg.X_NOSE)))
        sp_grid.append([
            (xx + 0.012, y, z_b + 0.008),
            (xx + 0.014, y, z_b - 0.018),
            (xx - 0.115, y * 0.94, z_b - 0.018),
            (xx - 0.115, y * 0.94, z_b + 0.012),
        ])
    create_quad_grid("TSC_Front_Splitter", sp_grid, material=mats["matte_trim"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True)


# ---------------------------------------------------------------------------
# 4. Side Skirts & Sleek Flush-Inset Turbo Rear-Quarter Air Intakes
# ---------------------------------------------------------------------------
def build_side_aero_and_intakes(body_pivot: bpy.types.Object, mats: dict):
    guide_finish=make_pbr("Mat_Turbo_Intake_Guide","#505258",metallic=.35,roughness=.37)
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        sk_grid = []
        for x in np.linspace(-0.795, 0.790, 24):
            y_out = eval_flank_y(float(x), float(eval_z_bot(float(x))) + 0.02)
            z_b = float(eval_z_bot(float(x)))
            fin_h = 0.020 * smootherstep(-0.48, -0.76, x)
            sk_grid.append([
                (x, sign * (y_out + 0.010), z_b + 0.028 + fin_h),
                (x, sign * (y_out + 0.012), z_b + 0.000),
                (x, sign * (y_out - 0.068), z_b - 0.002),
                (x, sign * (y_out - 0.068), z_b + 0.026),
            ])
        create_quad_grid(f"TSC_Side_Skirt_{tag}", sk_grid, material=mats["matte_trim"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True)

        # Sleek Flush-Inset Turbo S Rear-Quarter Air Intake Scoop (B5: shifted -3 cm aft, 1 sculpted horizontal vane!)
        n_loop = 36
        ang = np.linspace(0.0, 2.0 * math.pi, n_loop, endpoint=False)
        scoop_ring, scoop_in = [], []
        for a in ang:
            v = math.sin(a)
            u = math.cos(a)
            cz = 0.689 + 0.128 * v
            half_w = 0.067 * (0.89 + 0.23 * v)
            cx = -0.799 - 0.091 * v + half_w * u
            y_flank = eval_flank_y(cx, cz)
            y_outer = y_flank + 0.002
            scoop_ring.append((cx, sign * y_outer, cz))
            scoop_in.append((cx - 0.011, sign * (y_flank - 0.022), cz))

        create_tube(f"TSC_Side_Intake_Bezel_{tag}", scoop_ring, radius=0.0045, segments=10, material=mats["matte_trim"], parent=body_pivot, cyclic=True)

        duct_verts = scoop_ring + scoop_in + [(-0.819, sign * (eval_flank_y(-.819,.689)-.035), .689)]
        c_idx = 2 * n_loop
        duct_faces = []
        for i in range(n_loop):
            i2 = (i + 1) % n_loop
            if sign > 0:
                duct_faces.append((i, i2, n_loop + i2, n_loop + i))
                duct_faces.append((c_idx, n_loop + i, n_loop + i2))
            else:
                duct_faces.append((i2, i, n_loop + i, n_loop + i2))
                duct_faces.append((c_idx, n_loop + i2, n_loop + i))
        create_mesh_object(f"TSC_Side_Intake_{tag}", duct_verts, duct_faces, material=mats["shadow"], parent=body_pivot, smooth=True)

        # The visible guide runs diagonally from the lower forward tip up the duct.
        guide = []
        for v in np.linspace(-.90,.84,15):
            z = .689+.128*v
            width = .067*(.89+.23*v)*math.sqrt(1-v*v)
            x = -.799-.091*v+.24*width
            flank = eval_flank_y(x,z)
            guide.append([(x-.025,sign*(flank-.012),z),(x-.020,sign*(flank-.003),z),
                          (x+.006,sign*(flank+.001),z),(x+.015,sign*(flank-.011),z)])
        create_quad_grid(f"TSC_Side_Intake_Vane_{tag}", guide, material=guide_finish, parent=body_pivot, smooth=True)
