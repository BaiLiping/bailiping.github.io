"""
Convertible Soft-Top (UP & Stowed DOWN) and Active Aerodynamics for the
2026 Porsche 911 Turbo S Cabriolet (992.2 T-Hybrid) — v3 Polished:
  - Pivot_Soft_Top        : Completely smooth C2 woven black fabric dome + accurately tapered
                            flush smoked rear glass (WIDER at rear bottom, NARROWER at top front!)
                            with sleek flush 5 mm perimeter seal (ZERO raised roof notch!)
  - Pivot_Soft_Top_Stowed : Folded matte-black horseshoe Z-fold fabric tonneau cover (roof DOWN state!)
  - Pivot_Active_Wing     : Bold, sleek sculpted curved Gentian Blue Turbo S deployable wing
                            with clean recessed under-cradle & horizontal LED 3rd brake light
  - Front Active Aero     : 5 vertical active cooling flaps per side nestled RECESSED inside the
                            front bumper intakes above a crisp Gentian Blue chin bar + splitter
  - Side Aero & Intakes   : Satin-black side skirts + accurately slanted Turbo rear-quarter intakes
  - Rear Diffuser & Tips  : Recessed exhaust pocket + 4 vertical diffuser strakes + outboard gills +
                            unobstructed figure-8 Turbonite exhaust bezels framing @mechanicals' twin pipes!
"""

import math
import numpy as np
import bpy
from mathutils import Vector

from . import config as cfg
from .geom_utils import (
    ensure_empty,
    pchip_eval,
    smootherstep,
    create_quad_grid,
    create_solidified_panel,
    create_mesh_object,
    create_rounded_box,
    create_tube,
)
from .body_shell import (
    eval_flank_y,
    eval_y_max,
    eval_y_belt,
    eval_z_bot,
    eval_z_shoulder,
    eval_rear_deck_z,
    eval_front_wrap_xy,
    front_surface_x_at_y,
    rear_surface_x_at_y,
    query_front_surface_x,
    query_rear_surface_x,
)


def eval_soft_top_z(x):
    return pchip_eval(cfg.SOFT_TOP_X, cfg.SOFT_TOP_Z, x)


def eval_soft_top_rail_y(x):
    return pchip_eval(cfg.SOFT_TOP_X, cfg.SOFT_TOP_RAIL_Y, x)


def eval_soft_top_base_y(x):
    return pchip_eval(cfg.SOFT_TOP_X, cfg.SOFT_TOP_BASE_Y, x)


def _eval_soft_top_pt(x: float, u: float):
    au = abs(u)
    sign = 1.0 if u >= 0 else -1.0
    z_c = float(eval_soft_top_z(x))
    y_rail = float(eval_soft_top_rail_y(x))
    y_base = float(eval_soft_top_base_y(x))

    sail_blend = 1.0 - smootherstep(-0.86, -0.34, x)
    # Unbroken sleek coupe-like side arch flowing cleanly from windshield header (-0.002, 1.206)
    z_arch = cfg.Z_HEADER_SIDE + 0.022 * math.sin(math.pi * np.clip((0.01 - x) / 0.54, 0.0, 1.0)) - 0.15 * smootherstep(-0.34, -0.82, x)
    z_deck = float(eval_z_shoulder(x)) + 0.008
    z_edge = z_arch * (1.0 - sail_blend) + z_deck * sail_blend
    y_edge = (y_rail + 0.010) * (1.0 - sail_blend) + y_base * sail_blend

    # Narrower, tauter trapezoidal roof crown matching 4K rear (13) & front (36)!
    y = sign * (y_edge * (0.74 * au + 0.26 * (au ** 0.88)))
    crown_pow = 2.25 * (1.0 - sail_blend) + 1.80 * sail_blend
    z = z_edge + (z_c - z_edge) * (1.0 - au ** crown_pow)
    bow = 0.0015 * (math.exp(-((x + 0.35) / 0.04) ** 2) + math.exp(-((x + 0.72) / 0.04) ** 2)) * (1.0 - au * au)
    return (float(x), float(y), float(z + bow))


# ---------------------------------------------------------------------------
# 1. Convertible Soft-Top UP (Pivot_Soft_Top) & Stowed DOWN (Pivot_Soft_Top_Stowed)
# ---------------------------------------------------------------------------
def build_soft_top_up(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    piv = ensure_empty("Pivot_Soft_Top", cfg.PIVOT_LOCATIONS["Pivot_Soft_Top"], parent=body_pivot)

    xs = np.linspace(cfg.X_SOFT_TOP_REAR, cfg.X_HEADER_CENTER + 0.016, 52)
    us = np.linspace(-1.0, 1.0, 49)
    grid = [[_eval_soft_top_pt(float(x), float(u)) for u in us] for x in xs]

    # Build SOLID uncut fabric roof first, then slice the curved rounded-trapezoid rear window
    # cleanly via Blender Boolean DIFFERENCE (ZERO stair-stepped fabric corner notches!)
    fab_ob = create_quad_grid("TSC_Soft_Top_Fabric", grid, material=mats["soft_top"], parent=piv, smooth=True)
    sol = fab_ob.modifiers.new("CanvasThick", "SOLIDIFY")
    sol.thickness = 0.008
    sol.offset = -1.0

    # Smooth analytical curved trapezoid rear window (B5 + #39: shifted 9 cm aft, wider rounded upper corners,
    # and recessed flush -8 mm into the black fabric contour so ZERO shiny bulge above soft-top silhouette!)
    def _rear_win_pt(s_x: float, s_y: float, dz: float = 0.0):
        x_w = -1.138 + 0.202 * s_x  # -1.340 (rear bottom) .. -0.936 (front top) — 9 cm aft per view-41!
        t_g = 0.5 * (s_x + 1.0)     # 0 at rear bottom -> 1 at front top
        gw = (0.455 - 0.055 * t_g) * math.sqrt(max(0.28, 1.0 - (abs(s_x) ** 6.0) * 0.16))
        y_w = s_y * gw
        y_base = float(eval_soft_top_base_y(x_w))
        y_rail = float(eval_soft_top_rail_y(x_w))
        sail = 1.0 - smootherstep(-0.86, -0.34, x_w)
        y_edge = (y_rail + 0.012) * (1.0 - sail) + y_base * sail
        u_approx = np.clip(y_w / max(y_edge, 0.2), -0.95, 0.95)
        _, _, pz = _eval_soft_top_pt(x_w, float(u_approx))
        return (x_w, y_w, pz + dz)

    # Build exact smooth vertical prism cutter matching the rounded trapezoid perimeter!
    perim_loop = []
    for sy in np.linspace(-1.0, 1.0, 16, endpoint=False):
        perim_loop.append(_rear_win_pt(-1.0, sy))
    for sx in np.linspace(-1.0, 1.0, 12, endpoint=False):
        perim_loop.append(_rear_win_pt(sx, +1.0))
    for sy in np.linspace(1.0, -1.0, 16, endpoint=False):
        perim_loop.append(_rear_win_pt(+1.0, sy))
    for sx in np.linspace(1.0, -1.0, 12, endpoint=False):
        perim_loop.append(_rear_win_pt(sx, -1.0))

    # Extrude vertical cutter prism in parent-local coords of piv so Boolean aligns 100%!
    piv_off = np.array([piv.location.x, piv.location.y, piv.location.z])
    c_bot = [(p[0] - piv_off[0], p[1] - piv_off[1], p[2] - piv_off[2] - 0.25) for p in perim_loop]
    c_top = [(p[0] - piv_off[0], p[1] - piv_off[1], p[2] - piv_off[2] + 0.25) for p in perim_loop]
    nc = len(perim_loop)
    c_verts = c_bot + c_top
    c_faces = [tuple(range(nc - 1, -1, -1)), tuple(range(nc, 2 * nc))]
    c_faces += [(i, (i + 1) % nc, nc + (i + 1) % nc, nc + i) for i in range(nc)]
    c_me = bpy.data.meshes.new("_RearWinCutterTmp")
    c_me.from_pydata(c_verts, [], c_faces)
    c_me.update()
    c_ob = bpy.data.objects.new("_RearWinCutterTmp", c_me)
    bpy.context.scene.collection.objects.link(c_ob)
    c_ob.parent = piv

    bmod = fab_ob.modifiers.new("RearWinCut", "BOOLEAN")
    bmod.operation = "DIFFERENCE"
    bmod.solver = "FLOAT"
    bmod.object = c_ob
    deps = bpy.context.evaluated_depsgraph_get()
    deps.update()
    eo = fab_ob.evaluated_get(deps)
    cut_me = bpy.data.meshes.new_from_object(eo, preserve_all_data_layers=True, depsgraph=deps)
    cut_me.name = "TSC_Soft_Top_Fabric"
    old_fme = fab_ob.data
    fab_ob.modifiers.clear()
    fab_ob.data = cut_me
    if old_fme.users == 0:
        bpy.data.meshes.remove(old_fme)
    bpy.data.objects.remove(c_ob, do_unlink=True)
    bpy.data.meshes.remove(c_me)
    for p in fab_ob.data.polygons:
        p.use_smooth = True

    g_grid = [[_rear_win_pt(sx, sy, dz=-0.015 - 0.006 * (1.0 - sx * sx) * (1.0 - sy * sy)) for sy in np.linspace(-1.0, 1.0, 23)] for sx in np.linspace(-1.0, 1.0, 17)]
    create_quad_grid("TSC_Glass_Rear", g_grid, material=mats["rear_glass"], parent=piv, smooth=True)

    # Ultra-sleek flush recessed perimeter gasket (sits -9 mm flush inside fabric opening!)
    perim_seal = [(p[0], p[1], p[2] - 0.009) for p in perim_loop]
    create_tube("TSC_Rear_Window_Seal", perim_seal, radius=0.0040, segments=8, material=mats["soft_top"], parent=piv, cyclic=True)

    # Fixed rear quarter side glass panes + ultra-thin frameless matte-black B-seal (auto-hides on roof DOWN!)
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        q_xs = np.linspace(-0.715, -0.340, 12)
        q_grid = []
        for x in q_xs:
            z_lo = float(eval_z_shoulder(x)) - 0.010
            frac = smootherstep(-0.715, -0.340, x)
            z_hi = z_lo + 0.035 + (1.222 - z_lo - 0.035) * (frac ** 0.72)
            y_lo = float(eval_y_belt(x)) - 0.016
            y_hi = y_lo - (z_hi - z_lo) * 0.48
            q_grid.append([(x, sign * (y_lo + (y_hi - y_lo) * s + 0.010 * math.sin(math.pi * s)), z_lo + (z_hi - z_lo) * s)
                           for s in np.linspace(0.0, 1.0, 7)])
        create_quad_grid(f"TSC_Glass_Quarter_{tag}", q_grid, material=mats["quarter_glass"], parent=body_pivot, smooth=True, flip_faces=(sign > 0))
        b_pts = [
            (-0.339, sign * (float(eval_y_belt(-0.339)) - 0.016), float(eval_z_shoulder(-0.339)) - 0.006),
            (-0.339, sign * (float(eval_y_belt(-0.339)) - 0.168), 1.224),
        ]
        create_tube(f"TSC_Glass_Quarter_Seal_{tag}", b_pts, radius=0.0028, segments=8, material=mats["soft_top"], parent=body_pivot)

    return piv


def build_soft_top_stowed(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    piv = ensure_empty("Pivot_Soft_Top_Stowed", cfg.PIVOT_LOCATIONS["Pivot_Soft_Top_Stowed"], parent=body_pivot)

    xs = np.linspace(-1.415, -0.785, 18)
    us = np.linspace(-1.0, 1.0, 25)
    grid = []
    for x in xs:
        t = (x - (-1.415)) / (-0.785 - (-1.415))
        hw = 0.605 + 0.095 * math.sin(math.pi * (0.15 + 0.70 * t))
        # B3: Lowered -24 mm so stowed soft top hugs rear tonneau tightly with ZERO amber halo in view-46!
        z_base = float(eval_rear_deck_z(min(x, -1.28), 0.0)) - 0.004 if x < -1.28 else (0.996 - 0.048 * smootherstep(-1.28, -0.785, x))
        row = []
        for u in us:
            y = u * hw
            au = abs(u)
            crown = 0.013 * (1.0 - au ** 2.4) * math.sin(math.pi * np.clip(t * 0.9 + 0.05, 0.0, 1.0))
            edge_drop = -0.022 * smootherstep(0.80, 1.0, au)
            row.append((x, y, z_base + crown + edge_drop))
        grid.append(row)
    create_solidified_panel("TSC_Soft_Top_Stowed", grid, thickness=0.012, material=mats["soft_top"], parent=piv, smooth=True)

    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        arm_pts = [(-0.80, sign * 0.705, 0.942), (-0.65, sign * 0.715, 0.922), (-0.52, sign * 0.720, 0.902)]
        create_tube(f"TSC_Tonneau_Side_{tag}", arm_pts, radius=0.020, segments=10, material=mats["soft_top"], parent=piv)

    return piv


# ---------------------------------------------------------------------------
# 2. Sleek Curved Gentian Blue Active Turbo S Rear Wing (B3!)
# ---------------------------------------------------------------------------
def build_active_wing(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    """
    Sculpted curved Gentian Blue 992.2 Turbo S deployable wing in studio cradle pose (B3: lowered -24 mm,
    sleek curved outer tips, low subtle dark cradle recess underneath instead of tall black box!).
    """
    piv = ensure_empty("Pivot_Active_Wing", cfg.PIVOT_LOCATIONS["Pivot_Active_Wing"], parent=body_pivot)
    piv["wingOffset"] = [-0.035 * cfg.EXPORT_SCALE, 0.055 * cfg.EXPORT_SCALE, 0.0]
    piv["wingTilt"] = 0.14

    n_span = 47
    half_span = 0.725
    ys_span = np.linspace(-half_span, half_span, n_span)

    wing_sections = []
    for y in ys_span:
        u = abs(y) / half_span
        x_le = -1.890 + 0.155 * (u ** 2.1)
        chord = 0.285 * (1.0 - 0.34 * (u ** 2.0))
        # P2: Bold curved Gentian Blue 992.2 spoiler blade with thick rounded-vertical trailing rear face
        # so the spoiler reads boldly in rich Gentian Blue straight from behind (view-12 & view-46!)
        z_mid = 0.922 - 0.034 * (u ** 2.0) - 0.008 * smootherstep(0.75, 1.0, u)
        thick = 0.034 * (1.0 - 0.42 * (u ** 2.0))

        ring = []
        # The rear edge has two distinct surfaces. Its underside stands clear
        # of the lid even with the active spoiler parked in its factory cradle.
        for s, thickness in [(1,-.27),(.93,-.47),(.64,-.48),(.24,-.38),(.055,-.21),
                             (0,0),(.06,.23),(.23,.42),(.58,.51),(.86,.43),(.98,.27),(1,.12)]:
            x = x_le - s * chord - .034
            camber = .008 * math.sin(math.pi * s) + .014 * s*s
            z = z_mid + .028 + camber + thick * thickness
            ring.append((x, y, z))
        wing_sections.append(ring)

    blade = create_quad_grid(
        "TSC_Active_Wing_Mainplane",
        wing_sections,
        material=mats["paint"],
        parent=piv,
        cyclic_v=True,
        cap_u0=True,
        cap_u1=True,
        smooth=True,
    )

    blade.data.materials.append(mats["shadow"])
    for face in blade.data.polygons:
        if face.normal.z < -.46:
            face.material_index = 1

    # Sculpted Gentian Blue painted center spoiler pedestal base (matches real Turbo S photo 13/46!)
    # with a sleek dark recessed undercut shadow groove directly beneath the mainplane blade!
    fairing_grid = []
    for y in np.linspace(-0.51, 0.51, 31):
        u = abs(y) / 0.51
        x_back = -2.140 + 0.065 * (u ** 2.0)
        z_bot_f = float(eval_rear_deck_z(x_back, abs(y))) - 0.010
        z_top_f = 0.941 - 0.020 * (u ** 2.0)
        fairing_grid.append([
            (x_back + 0.165, y, z_bot_f),
            (x_back, y, z_bot_f + 0.006),
            (x_back + 0.012, y, z_top_f),
            (x_back + 0.170, y, z_top_f),
        ])
    create_quad_grid("TSC_Active_Wing_Base", fairing_grid, material=mats["paint"], parent=piv, cyclic_v=True, cap_u0=True, cap_u1=True, smooth=True)

    throat = []
    for y in np.linspace(-.527,.527,39):
        u = abs(y)/.527
        x = -2.145+.066*u*u
        high = .947-.020*u*u
        low = .875 + .052*u**7
        throat.append([(x+.020,y,low),(x,y,low+.005),(x-.001,y,high-.006),(x+.012,y,high)])
    create_quad_grid("TSC_Active_Wing_ShadowRecess", throat, material=mats["gloss_black"], parent=piv, smooth=True)

    brake_pts = [(-2.160 + 0.022 * (y / 0.24) ** 2, y, 0.958 - 0.006 * (y / 0.24) ** 2) for y in np.linspace(-0.22, 0.22, 15)]
    create_tube("TSC_Third_Brake", brake_pts, radius=0.0038, segments=8, material=mats["taillight_clear"], parent=piv)

    return piv


# ---------------------------------------------------------------------------
# 3. Front 992.2 Active Aero (5 Vertical Flaps/Side RECESSED Flush Inside Bumper!)
# ---------------------------------------------------------------------------
def build_front_aero(body_pivot: bpy.types.Object, mats: dict):
    """5 vertical dark active flaps flush-recessed at exact photo height Z=[0.192, 0.378] (view-35/48!)."""
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        y0, y1 = 0.365, 0.725
        z0, z1 = 0.192, 0.378

        # Dark backing plenum deep inside bumper pocket
        plen_grid = []
        for s in np.linspace(0.0, 1.0, 11):
            yy = y0 + (y1 - y0) * s
            xx = query_front_surface_x(sign * yy, 0.285, unrecessed=True) - 0.072
            plen_grid.append([(xx, sign * yy, z0), (xx, sign * yy, z1)])
        create_quad_grid(f"TSC_Front_Intake_Plenum_{tag}", plen_grid, material=mats["shadow"], parent=body_pivot, flip_faces=(sign < 0))

        # Smooth rounded-corner superellipse matte-black surround bezel hugging curved front bumper (photo 36!)
        ym, zm = 0.5 * (y0 + y1), 0.5 * (z0 + z1)
        hy, hz = 0.5 * (y1 - y0), 0.5 * (z1 - z0)
        perim = []
        for a in np.linspace(0.0, 2.0 * math.pi, 36, endpoint=False):
            ca, sa = math.cos(a), math.sin(a)
            yy = ym + hy * math.copysign(abs(ca) ** 0.38, ca)
            zz = zm + hz * math.copysign(abs(sa) ** 0.38, sa)
            perim.append((query_front_surface_x(sign * yy, zz, unrecessed=True) - 0.014, sign * yy, zz))
        create_tube(f"TSC_Front_Intake_Frame_{tag}", perim, radius=0.0080, segments=10, material=mats["matte_trim"], parent=body_pivot, cyclic=True)

        # Recessed transverse radiator fins remain visible between the five shutters.
        fins = []
        for height in np.linspace(z0+0.008,z1-0.006,22):
            for yy in np.linspace(y0+0.004, y1-0.004,11):
                xx = query_front_surface_x(sign*yy, 0.285, unrecessed=True) - 0.050
                fins.extend([(xx,sign*yy,height), (xx+.001,sign*yy,height+.0026)])
        fin_faces = []
        for row in range(22):
            for col in range(10):
                i = row*22+col*2
                fin_faces.append((i,i+2,i+3,i+1))
        create_mesh_object(f'TSC_Front_Intake_Cooling_Fins_{tag}',fins,fin_faces,
                           material=mats['matte_trim'],parent=body_pivot,smooth=False)

        # 5 INDIVIDUAL VERTICAL ACTIVE COOLING FLAPS recessed cleanly behind curved bumper skin!
        flap_verts, flap_faces = [], []
        for k in range(5):
            frac = (k + 0.5) / 5.0
            yy_c = y0 + (y1 - y0) * frac
            xx_surf = query_front_surface_x(sign * yy_c, 0.285, unrecessed=True)
            xx_front = xx_surf - 0.028
            fw = 0.034
            f_depth = 0.022
            # Exact tangent along curved bumper corner: yaw = -sign * atan(dx/d|y|) so flaps curve BACK with corner!
            dx_dy = (query_front_surface_x(sign * (yy_c + 0.015), 0.285, unrecessed=True) -
                     query_front_surface_x(sign * (yy_c - 0.015), 0.285, unrecessed=True)) / 0.030
            yaw = -sign * math.atan(dx_dy)
            cy, sy = math.cos(yaw), math.sin(yaw)

            base_i = len(flap_verts)
            zs_f = np.linspace(z0 + 0.006, z1 - 0.006, 7)
            for zz in zs_f:
                bow = 0.006 * math.sin(math.pi * (zz - z0) / (z1 - z0))
                loc_pts = [
                    (+f_depth * 0.5 + bow, -fw), (+f_depth * 0.5 + bow, +fw),
                    (-f_depth * 0.5 + bow, +fw * 0.88), (-f_depth * 0.5 + bow, -fw * 0.88),
                ]
                for lx, ly in loc_pts:
                    flap_verts.append((xx_front + lx * cy - ly * sy, sign * yy_c + lx * sy + ly * cy, zz))
            for iz in range(len(zs_f) - 1):
                a = base_i + 4 * iz
                b = base_i + 4 * (iz + 1)
                flap_faces.extend([(a, a + 1, b + 1, b), (a + 1, a + 2, b + 2, b + 1), (a + 2, a + 3, b + 3, b + 2), (a + 3, a, b, b + 3)])
            flap_faces.append((base_i, base_i + 3, base_i + 2, base_i + 1))
            tb = base_i + 4 * (len(zs_f) - 1)
            flap_faces.append((tb, tb + 1, tb + 2, tb + 3))
        create_mesh_object(f"TSC_Active_Flap_{tag}", flap_verts, flap_faces, material=mats["intake_grille"], parent=body_pivot, smooth=False)

    # Recessed center lower radiator duct + 7 crisp horizontal slats (exact view-35/48 height!)
    x_rad = query_front_surface_x(0.0, 0.245, unrecessed=True) - 0.055
    create_rounded_box("TSC_Front_Radiator", (x_rad, 0.0, 0.245), (0.032, 0.580, 0.128), material=mats["shadow"], parent=body_pivot, bevel_width=0.004)
    for iz, zz in enumerate(np.linspace(0.192, 0.298, 7)):
        pts = [(query_front_surface_x(y, zz, unrecessed=True) - 0.032, y, zz) for y in np.linspace(-0.280, 0.280, 11)]
        create_tube(f"TSC_Front_Grille_Center_{iz}", pts, radius=0.0038, segments=6, material=mats["intake_grille"], parent=body_pivot)

    # Slim satin-black lower front chin splitter hugging bottom bumper edge tightly (exact view-35 chin height!)
    sp_grid = []
    for y in np.linspace(-0.82, 0.82, 41):
        xx = query_front_surface_x(y, 0.148, unrecessed=True)
        z_b = float(eval_z_bot(min(xx, cfg.X_NOSE)))
        sp_grid.append([
            (xx + 0.012, y, z_b + 0.008),
            (xx + 0.014, y, z_b - 0.018),
            (xx - 0.115, y * 0.94, z_b - 0.018),
            (xx - 0.115, y * 0.94, z_b + 0.012),
        ])
    create_quad_grid("TSC_Front_Splitter", sp_grid, material=mats["matte_trim"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True)


# ---------------------------------------------------------------------------
# 4. Side Skirts & Sleek Flush-Inset Turbo Rear-Quarter Air Intakes
# ---------------------------------------------------------------------------
def build_side_aero_and_intakes(body_pivot: bpy.types.Object, mats: dict):
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        sk_grid = []
        for x in np.linspace(-0.795, 0.790, 24):
            y_out = eval_flank_y(float(x), float(eval_z_bot(float(x))) + 0.02)
            z_b = float(eval_z_bot(float(x)))
            fin_h = 0.020 * smootherstep(-0.48, -0.76, x)
            sk_grid.append([
                (x, sign * (y_out + 0.010), z_b + 0.028 + fin_h),
                (x, sign * (y_out + 0.012), z_b + 0.000),
                (x, sign * (y_out - 0.068), z_b - 0.002),
                (x, sign * (y_out - 0.068), z_b + 0.026),
            ])
        create_quad_grid(f"TSC_Side_Skirt_{tag}", sk_grid, material=mats["matte_trim"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True)

        # Sleek Flush-Inset Turbo S Rear-Quarter Air Intake Scoop (B5: shifted -3 cm aft, 1 sculpted horizontal vane!)
        n_loop = 36
        ang = np.linspace(0.0, 2.0 * math.pi, n_loop, endpoint=False)
        scoop_ring, scoop_in = [], []
        for a in ang:
            v = math.sin(a)
            u = math.cos(a)
            cz = 0.689 + 0.128 * v
            half_w = 0.067 * (0.89 + 0.23 * v)
            cx = -0.799 - 0.091 * v + half_w * u
            y_flank = eval_flank_y(cx, cz)
            y_outer = y_flank + 0.002
            scoop_ring.append((cx, sign * y_outer, cz))
            scoop_in.append((cx - 0.011, sign * (y_flank - 0.022), cz))

        create_tube(f"TSC_Side_Intake_Bezel_{tag}", scoop_ring, radius=0.0045, segments=10, material=mats["matte_trim"], parent=body_pivot, cyclic=True)

        duct_verts = scoop_ring + scoop_in + [(-0.819, sign * (eval_flank_y(-.819,.689)-.035), .689)]
        c_idx = 2 * n_loop
        duct_faces = []
        for i in range(n_loop):
            i2 = (i + 1) % n_loop
            if sign > 0:
                duct_faces.append((i, i2, n_loop + i2, n_loop + i))
                duct_faces.append((c_idx, n_loop + i, n_loop + i2))
            else:
                duct_faces.append((i2, i, n_loop + i, n_loop + i2))
                duct_faces.append((c_idx, n_loop + i2, n_loop + i))
        create_mesh_object(f"TSC_Side_Intake_{tag}", duct_verts, duct_faces, material=mats["shadow"], parent=body_pivot, smooth=True)

        # The visible guide runs diagonally from the lower forward tip up the duct.
        guide = []
        for v in np.linspace(-.90,.84,15):
            z = .689+.128*v
            width = .067*(.89+.23*v)*math.sqrt(1-v*v)
            x = -.799-.091*v+.42*width
            flank = eval_flank_y(x,z)
            guide.append([(x-.010,sign*(flank-.017),z),(x-.004,sign*(flank-.002),z),
                          (x+.010,sign*(flank+.001),z),(x+.014,sign*(flank-.010),z)])
        create_quad_grid(f"TSC_Side_Intake_Vane_{tag}", guide, material=mats["matte_trim"], parent=body_pivot, smooth=True)


# ---------------------------------------------------------------------------
# 5. Wide Matte-Black Rear Diffuser & Flush-Tucked Figure-8 Exhaust Bezels
# ---------------------------------------------------------------------------
def build_rear_diffuser_and_exhaust_bezels(body_pivot: bpy.types.Object, mats: dict):
    """
    Wide wraparound matte-black lower rear diffuser fascia + 4 vertical diffuser strakes +
    flush-tucked Turbonite figure-8 exhaust bezels aligned 100% via BVH raycast & exact yaw!
    """
    ys = np.linspace(-.813,.813,87)
    diff_grid=[]
    for y in ys:
        ay=abs(y)
        ztop=.407-.013*(ay/.813)**2
        zbot=.202+.009*(ay/.813)**4
        row=[]
        for f in np.linspace(0,1,13):
            z=ztop+(zbot-ztop)*f
            body_x=query_rear_surface_x(y,z,unrecessed=True)
            well=math.exp(-((ay-.514)/.137)**6-((z-.281)/.067)**6)
            rolled=.009*math.cos(math.pi*2*f)
            row.append((body_x-.009+rolled+.029*well,y,z))
        diff_grid.append(row)
    create_quad_grid("TSC_Rear_Diffuser",diff_grid,material=mats["matte_trim"],parent=body_pivot,smooth=True)
    for y in np.linspace(-.772,.772,31):
        if .355<abs(y)<.67:continue
        high=.376-.009*abs(y);low=.237
        x=query_rear_surface_x(y,high,unrecessed=True)
        bot=query_rear_surface_x(y,low,unrecessed=True)
        pts=[(x-.011,y,high),((x+bot)/2-.013,y,(high+low)/2),(bot-.011,y,low)]
        create_tube(f"TSC_Valance_Rib_{int(y*1000)}",pts,radius=.0036,segments=6,material=mats["matte_trim"],parent=body_pivot)

    # 4 matte-black vertical diffuser strakes (2 bold center fins + 2 outer dividers)
    for sy_off, thick, depth in [(-0.048, 0.018, 0.048), (+0.048, 0.018, 0.048), (-0.345, 0.015, 0.038), (+0.345, 0.015, 0.038)]:
        sx = query_rear_surface_x(sy_off, 0.305, unrecessed=True)
        create_rounded_box(
            f"TSC_Diffuser_Strake_{int(round(sy_off * 1000))}",
            (sx - 0.006, sy_off, 0.305),
            (depth, thick, 0.175),
            material=mats["matte_trim"],
            parent=body_pivot,
            bevel_width=0.005,
        )

    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        # Sculpted wraparound vertical rear bumper corner vent + bold central divider vane (B4!)
        vent_grid = []
        for s in np.linspace(0.0, 1.0, 9):
            vy = 0.658 + 0.095 * s
            vx = query_rear_surface_x(sign * vy, 0.305, unrecessed=True)
            vent_grid.append([
                (vx + 0.025, sign * vy, 0.382 - 0.020 * s),
                (vx - 0.003, sign * vy, 0.382 - 0.020 * s),
                (vx - 0.003, sign * vy, 0.228 - 0.015 * s),
                (vx + 0.025, sign * vy, 0.228 - 0.015 * s),
            ])
        create_quad_grid(f"TSC_Rear_CornerVent_{tag}", vent_grid, material=mats["shadow"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True)
        vx_v = query_rear_surface_x(sign * 0.705, 0.302, unrecessed=True) - 0.004
        create_rounded_box(
            f"TSC_Rear_AirCurtain_{tag}",
            (vx_v, sign * 0.705, 0.302),
            (0.018, 0.010, 0.135),
            material=mats["matte_trim"],
            parent=body_pivot,
            bevel_width=0.003,
        )

        # Lower Gentian Blue painted wrap winglet under each outer exhaust corner
        wing_pts = []
        for s in np.linspace(0.0, 1.0, 10):
            wy = 0.38 + 0.38 * s
            wx = query_rear_surface_x(sign * wy, 0.205, unrecessed=True) - 0.004
            wing_pts.append((wx, sign * wy, 0.206 - 0.016 * s))
        create_tube(f"TSC_Rear_Bumper_Lip_{tag}", wing_pts, radius=0.011, segments=10, material=mats["paint"], parent=body_pivot)

        # Crisp 992.2 Turbo S Twin-D Squarish-Rounded Turbonite Exhaust Bezel — 100% FLUSH WITH CURVED TAIL (B4!)
        ex_y = sign * cfg.EXHAUST_CUTOUT_Y
        ex_z = cfg.EXHAUST_CUTOUT_Z
        ex_x = query_rear_surface_x(ex_y, ex_z, unrecessed=True) + 0.006
        dx_dy = (query_rear_surface_x(sign * (cfg.EXHAUST_CUTOUT_Y + 0.02), ex_z, unrecessed=True) -
                 query_rear_surface_x(sign * (cfg.EXHAUST_CUTOUT_Y - 0.02), ex_z, unrecessed=True)) / 0.04
        yaw = -sign * math.atan(dx_dy)

        n_b = 56
        bezel_ring_rear, bezel_ring_front = [], []
        cy_a, sy_a = math.cos(yaw), math.sin(yaw)
        w_half = cfg.EXHAUST_CUTOUT_W * 0.5
        h_half = cfg.EXHAUST_CUTOUT_H * 0.5
        for i in range(n_b):
            th = 2.0 * math.pi * (i / n_b)
            ct, st = math.cos(th), math.sin(th)
            # Sharper squarish-rounded twin-D superellipse (0.36 / 0.40 instead of soft 0.58 / 0.62!)
            ly = w_half * math.copysign(abs(ct) ** 0.36, ct)
            pinch = 1.0 - 0.14 * math.exp(-((ly / (w_half * 0.22)) ** 2))
            lz = h_half * pinch * math.copysign(abs(st) ** 0.40, st)
            wx_r = ex_x - 0.007 * cy_a - ly * sy_a
            wy_r = ex_y - 0.007 * sy_a + ly * cy_a
            wx_f = ex_x + 0.072 * cy_a - ly * sy_a
            wy_f = ex_y + 0.072 * sy_a + ly * cy_a
            bezel_ring_rear.append((wx_r, wy_r, ex_z + lz))
            bezel_ring_front.append((wx_f, wy_f, ex_z + lz))

        create_tube(f"TSC_Exhaust_Bezel_{tag}", bezel_ring_rear, radius=0.0075, segments=14, material=mats["turbonite"], parent=body_pivot, cyclic=True)
        sleeve_verts = bezel_ring_rear + bezel_ring_front
        sleeve_faces = [(i, (i + 1) % n_b, n_b + (i + 1) % n_b, n_b + i) for i in range(n_b)]
        create_mesh_object(f"TSC_Exhaust_Sleeve_{tag}", sleeve_verts, sleeve_faces, material=mats["shadow"], parent=body_pivot, smooth=True)
