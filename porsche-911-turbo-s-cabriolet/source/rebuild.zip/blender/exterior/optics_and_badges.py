"""
Optics, Windshield/A-Pillars, Wipers, Taillight Bar, Side Markers & 3D Badges for the
2026 Porsche 911 Turbo S Cabriolet (992.2 T-Hybrid):
  - Windshield + Gentian Blue A-pillar/header frame + black frit + twin aeroblade wipers
  - Flush compact 992.2 HD-Matrix LED headlights (dark housing + twin projectors + crisp 4-bar DRLs + clear cover)
  - Full-width sculpted 992.2 LED taillight bar aligned 100% to `rear_surface_x_at_y()` (ZERO floating corners!)
  - 3D Turbonite `P O R S C H E` lettering, `turbo S` badge, wide EU `911` plate, flush red rear reflectors & front side markers
"""

import math
import numpy as np
import bpy
from mathutils import Vector

from . import config as cfg
from .geom_utils import (
    smootherstep,
    create_quad_grid,
    create_solidified_panel,
    create_mesh_object,
    create_rounded_box,
    create_tube,
)
from .body_shell import (
    eval_front_hood_z,
    eval_flank_y,
    rear_surface_x_at_y,
    query_rear_surface_x,
    query_body_ray,
    get_headlight_basis,
    HL_MAJOR_A,
    HL_MINOR_B,
)


# ---------------------------------------------------------------------------
# 1. Windshield, Painted A-Pillar Frame, Cowl Plenum & Twin Wipers
# ---------------------------------------------------------------------------
def eval_windshield_pt(t: float, v: float):
    av = abs(v)
    x_cowl = cfg.X_COWL_CENTER - (cfg.X_COWL_CENTER - cfg.X_COWL_SIDE) * (av ** 2.2)
    z_cowl = cfg.Z_COWL_CENTER + (cfg.Z_COWL_SIDE - cfg.Z_COWL_CENTER) * (av ** 2.0)
    y_cowl = v * 0.732

    x_head = cfg.X_HEADER_CENTER - (cfg.X_HEADER_CENTER - cfg.X_HEADER_SIDE) * (av ** 2.1)
    z_head = cfg.Z_HEADER_CENTER - (cfg.Z_HEADER_CENTER - cfg.Z_HEADER_SIDE) * (av ** 2.1)
    # Encloses @interior's TSC_Trim_WindshieldHeader cleanly with sleek 992 trapezoidal rake!
    y_head = v * 0.582

    dome = 0.014 * math.sin(math.pi * t) * (1.0 - 0.6 * av * av)
    x = x_cowl + (x_head - x_cowl) * t + dome
    y = y_cowl + (y_head - y_cowl) * t
    z = z_cowl + (z_head - z_cowl) * t + 0.008 * math.sin(math.pi * t)
    return (x, y, z)


def build_windshield_and_frame(body_pivot: bpy.types.Object, mats: dict):
    ts = np.linspace(0.02, 0.96, 18)
    vs = np.linspace(-0.96, 0.96, 29)
    glass_grid = [[eval_windshield_pt(t, v) for v in vs] for t in ts]
    create_solidified_panel("TSC_Glass_Windshield", glass_grid, thickness=0.005, material=mats["glass"], parent=body_pivot)

    # Continuous U-shaped Gentian Blue painted A-pillars & upper windshield header bow
    frame_spine = []
    for t in np.linspace(0.0, 1.0, 14):
        frame_spine.append(("R", eval_windshield_pt(t, -1.0)))
    for v in np.linspace(-0.94, 0.94, 21):
        frame_spine.append(("T", eval_windshield_pt(1.0, v)))
    for t in np.linspace(1.0, 0.0, 14):
        frame_spine.append(("L", eval_windshield_pt(t, +1.0)))

    frame_sections = []
    n_pts = len(frame_spine)
    for i, (kind, pt) in enumerate(frame_spine):
        p = np.array(pt, dtype=np.float64)
        p_prev = np.array(frame_spine[max(0, i - 1)][1], dtype=np.float64)
        p_next = np.array(frame_spine[min(n_pts - 1, i + 1)][1], dtype=np.float64)
        tang = p_next - p_prev
        tang /= max(np.linalg.norm(tang), 1e-6)

        out_hint = np.array([0.45, p[1], p[2] - 0.72])
        out_hint -= np.dot(out_hint, tang) * tang
        out_hint /= max(np.linalg.norm(out_hint), 1e-6)
        side = np.cross(tang, out_hint)
        side /= max(np.linalg.norm(side), 1e-6)

        r_out = 0.026 if kind == "T" else 0.025
        r_side = 0.036 if kind == "T" else 0.028
        ring = []
        for a in np.linspace(0.0, 2.0 * math.pi, 14, endpoint=False):
            ca, sa = math.cos(a), math.sin(a)
            ro = r_out * (0.75 if ca > 0 else 1.25)
            ring.append(tuple(p + out_hint * (ro * ca) + side * (r_side * sa)))
        frame_sections.append(ring)

    create_quad_grid("TSC_Windshield_Frame", frame_sections, material=mats["paint"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True, smooth=True)

    frit_pts = [eval_windshield_pt(t, -0.965) for t in np.linspace(0.02, 0.97, 10)]
    frit_pts += [eval_windshield_pt(0.975, v) for v in np.linspace(-0.92, 0.92, 16)]
    frit_pts += [eval_windshield_pt(t, +0.965) for t in np.linspace(0.97, 0.02, 10)]
    frit_pts += [eval_windshield_pt(0.025, v) for v in np.linspace(0.92, -0.92, 16)]
    create_tube("TSC_Windshield_Frit", frit_pts, radius=0.011, segments=8, material=mats["gloss_black"], parent=body_pivot, cyclic=True)

    cowl_grid = []
    for v in np.linspace(-0.96, 0.96, 23):
        p0 = eval_windshield_pt(0.0, v)
        cowl_grid.append([(p0[0] + 0.040, p0[1], p0[2] - 0.015), (p0[0], p0[1], p0[2] - 0.002), (p0[0] - 0.055, p0[1], p0[2] - 0.008)])
    create_quad_grid("TSC_Cowl_Plenum", cowl_grid, material=mats["matte_trim"], parent=body_pivot)

    w1_pts = [(x + 0.014, y, z + 0.006) for (x, y, z) in [eval_windshield_pt(0.045 + 0.020 * s, 0.05 + 0.72 * s) for s in np.linspace(0.0, 1.0, 10)]]
    create_tube("TSC_Wiper_L", w1_pts, radius=0.006, segments=8, material=mats["matte_trim"], parent=body_pivot)
    w2_pts = [(x + 0.014, y, z + 0.006) for (x, y, z) in [eval_windshield_pt(0.032 + 0.018 * s, -0.62 + 0.68 * s) for s in np.linspace(0.0, 1.0, 10)]]
    create_tube("TSC_Wiper_R", w2_pts, radius=0.006, segments=8, material=mats["matte_trim"], parent=body_pivot)


# ---------------------------------------------------------------------------
# 2. 100% FLUSH Raycasted 992.2 HD-Matrix 4-Point LED Headlights
# ---------------------------------------------------------------------------
def build_headlights(body_pivot: bpy.types.Object, mats: dict):
    """
    100% FLUSH 992.2 Porsche oval HD-Matrix LED headlights projected directly via
    3D BVH raycast onto the smooth UN-RECESSED Class-A front fender barrel!
    Zero protruding frog-eye rings from front, side, or 3/4 views!
    """
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        c_hl, n_hl, u_hl, v_hl = get_headlight_basis(sign)
        a_maj = HL_MAJOR_A * 0.96
        b_min = HL_MINOR_B * 0.96
        n_ring = 48
        angs = np.linspace(0.0, 2.0 * math.pi, n_ring, endpoint=False)

        # 100.0% FLUSH raycast directly onto the glass-smooth UNDEFORMED Class-A fender barrel!
        # Because body_shell.py now clips the oval analytically WITHOUT distorting a single fender vertex,
        # exact raycast guarantees ZERO step/gap underneath the headlight from EVERY 3/4 & front angle!
        c_hit, _ = query_body_ray(c_hl + n_hl * 0.45, -n_hl, unrecessed=True, max_dist=1.2)
        c_anchor = c_hit if c_hit is not None else c_hl
        a_maj = HL_MAJOR_A * 0.945
        b_min = HL_MINOR_B * 0.945

        def _surf_pt(ru: float, rv: float, offset_n: float = 0.0):
            base = c_hl + u_hl * (a_maj * ru) + v_hl * (b_min * rv)
            hit_p, _ = query_body_ray(base + n_hl * 0.45, -n_hl, unrecessed=True, max_dist=1.2)
            if hit_p is not None:
                p = hit_p + n_hl * offset_n
            else:
                r2 = ru * ru + rv * rv
                p = (c_anchor + u_hl * (a_maj * ru) + v_hl * (b_min * rv)) - n_hl * (0.028 * r2 - offset_n)
            return (float(p.x), float(p.y), float(p.z))

        # 1. Razor-flush dark glossy perimeter bezel hugging the EXACT analytical fender cutout!
        bezel_pts = [_surf_pt(math.cos(a), math.sin(a), offset_n=0.0005) for a in angs]
        create_tube(f"TSC_Headlight_Bezel_{tag}", bezel_pts, radius=0.0068, segments=10, material=mats["gloss_black"], parent=body_pivot, cyclic=True)

        # 2. Deep jet-black internal optical housing cup recessed -62 mm cleanly inside the cutout!
        cup_grid = []
        for s in [0.0, 0.25, 0.65, 1.0]:
            rad = 1.00 - 0.16 * s
            off = -0.001 - 0.060 * s
            cup_grid.append([_surf_pt(rad * math.cos(a), rad * math.sin(a), offset_n=off) for a in angs])
        create_quad_grid(f"TSC_Headlight_Housing_{tag}", cup_grid, material=mats["shadow"], parent=body_pivot, cyclic_v=True, cap_u1=True)

        # 3. Twin central dark-anodized HD-Matrix projector barrels inside deep dark optical bowl
        for idx, du_p in enumerate([-0.19, +0.19]):
            p_ring = [_surf_pt(du_p + 0.16 * math.cos(a), 0.18 * math.sin(a), offset_n=-0.036) for a in np.linspace(0, 2 * math.pi, 20, endpoint=False)]
            create_tube(f"TSC_Headlight_Projector_{tag}_{idx}", p_ring, radius=0.0030, segments=8, material=mats["turbonite"], parent=body_pivot, cyclic=True)

        # 4. REFINED SLIM 992.2 4-POINT SEGMENTED LED LIGHT GUIDES (P1: subtle dark-smoked fine blades!)
        for idx, (du_f, dv_f) in enumerate([(-0.34, -0.43), (-0.34, +0.43), (+0.34, -0.43), (+0.34, +0.43)]):
            pc = Vector(_surf_pt(du_f, dv_f, offset_n=-0.024))
            for sub, dz_sub in enumerate([-0.0038, +0.0038]):
                p0 = (pc.x, pc.y - 0.015, pc.z + dz_sub)
                p1 = (pc.x, pc.y + 0.015, pc.z + dz_sub)
                create_tube(f"TSC_Headlight_DRL_{tag}_{idx}_{sub}", [p0, p1], radius=0.0016, segments=8, material=mats["drl_white"], parent=body_pivot)

        # 5. Silky-smooth fender-conforming clear polycarbonate cover lens (+3 mm center, +1 mm bezel!)
        n_rad = 8
        lens_rings = []
        for ir in range(1, n_rad + 1):
            r_f = ir / n_rad
            dome = 0.004 * (1.0 - r_f * r_f) + 0.001
            lens_rings.append([_surf_pt(r_f * math.cos(a), r_f * math.sin(a), offset_n=dome) for a in angs])
        apex = _surf_pt(0.0, 0.0, offset_n=0.005)
        lens_verts = [apex] + [pt for ring in lens_rings for pt in ring]
        lens_faces = [(0, 1 + j, 1 + (j + 1) % n_ring) for j in range(n_ring)]
        for ir in range(n_rad - 1):
            b0 = 1 + ir * n_ring
            b1 = 1 + (ir + 1) * n_ring
            for j in range(n_ring):
                j2 = (j + 1) % n_ring
                lens_faces.append((b0 + j, b1 + j, b1 + j2, b0 + j2))
        create_mesh_object(f"TSC_Headlight_Lens_{tag}", lens_verts, lens_faces, material=mats["headlight_lens"], parent=body_pivot, smooth=True)
        # The reflector sits within the housing, behind the independently
        # reflecting outer lens. Its pattern comes from Porsche studio frame 36.
        from .surface_details import material, uv_by_vertex
        reflector_material = material("HD Matrix reflector", "matrix-reflector.png", 0.18, 0.46, 0.40)
        reflector = [tuple(Vector(p) - n_hl*0.019) for p in lens_verts]
        optic = create_mesh_object(f"TSC_Headlight_Reflector_{tag}", reflector, lens_faces,
                                   material=reflector_material, parent=body_pivot)
        uv = [(0.5, 0.5)]
        for ir in range(1, n_rad+1):
            for a in angs:
                uv.append((0.5-0.5*ir/n_rad*math.sin(a), 0.5+0.5*ir/n_rad*math.cos(a)))
        uv_by_vertex(optic, np.array(uv))



# ---------------------------------------------------------------------------
# 3. Full-Width 992.2 LED Taillight Bar, 3D PORSCHE Lettering, Badges & Reflectors
# ---------------------------------------------------------------------------
_LETTER_STROKES = {
    "P": [((0, 0), (0, 1)), ((0, 1), (0.85, 1)), ((0.85, 1), (1, 0.85)), ((1, 0.85), (1, 0.58)), ((1, 0.58), (0.85, 0.45)), ((0.85, 0.45), (0, 0.45))],
    "O": [((0.15, 0), (0.85, 0)), ((0.85, 0), (1, 0.18)), ((1, 0.18), (1, 0.82)), ((1, 0.82), (0.85, 1)), ((0.85, 1), (0.15, 1)), ((0.15, 1), (0, 0.82)), ((0, 0.82), (0, 0.18)), ((0, 0.18), (0.15, 0))],
    "R": [((0, 0), (0, 1)), ((0, 1), (0.85, 1)), ((0.85, 1), (1, 0.85)), ((1, 0.85), (1, 0.58)), ((1, 0.58), (0.85, 0.45)), ((0.85, 0.45), (0, 0.45)), ((0.55, 0.45), (1, 0))],
    "S": [((1, 0.85), (0.85, 1)), ((0.85, 1), (0.15, 1)), ((0.15, 1), (0, 0.85)), ((0, 0.85), (0, 0.62)), ((0, 0.62), (0.15, 0.50)), ((0.15, 0.50), (0.85, 0.50)), ((0.85, 0.50), (1, 0.38)), ((1, 0.38), (1, 0.15)), ((1, 0.15), (0.85, 0)), ((0.85, 0), (0.15, 0)), ((0.15, 0), (0, 0.15))],
    "C": [((1, 0.85), (0.85, 1)), ((0.85, 1), (0.15, 1)), ((0.15, 1), (0, 0.82)), ((0, 0.82), (0, 0.18)), ((0, 0.18), (0.15, 0)), ((0.15, 0), (0.85, 0)), ((0.85, 0), (1, 0.15))],
    "H": [((0, 0), (0, 1)), ((1, 0), (1, 1)), ((0, 0.50), (1, 0.50))],
    "E": [((1, 1), (0, 1)), ((0, 1), (0, 0)), ((0, 0), (1, 0)), ((0, 0.50), (0.82, 0.50))],
    "T": [((0, 1), (1, 1)), ((0.5, 1), (0.5, 0))],
    "U": [((0, 1), (0, 0.2)), ((0, 0.2), (0.2, 0)), ((0.2, 0), (0.8, 0)), ((0.8, 0), (1, 0.2)), ((1, 0.2), (1, 1))],
    "B": [((0, 0), (0, 1)), ((0, 1), (0.8, 1)), ((0.8, 1), (0.95, 0.85)), ((0.95, 0.85), (0.95, 0.60)), ((0.95, 0.60), (0.8, 0.50)), ((0.8, 0.50), (0, 0.50)), ((0.8, 0.50), (1, 0.38)), ((1, 0.38), (1, 0.15)), ((1, 0.15), (0.82, 0)), ((0.82, 0), (0, 0))],
    "Y": [((0, 1), (0.5, 0.48)), ((1, 1), (0.5, 0.48)), ((0.5, 0.48), (0.5, 0))],
    "I": [((0.5, 0), (0.5, 1))],
    "D": [((0, 0), (0, 1)), ((0, 1), (0.75, 1)), ((0.75, 1), (1, 0.78)), ((1, 0.78), (1, 0.22)), ((1, 0.22), (0.75, 0)), ((0.75, 0), (0, 0))],
    "-": [((0.15, 0.48), (0.85, 0.48))],
    " ": [],
    "9": [((0.15, 0), (0.85, 0)), ((0.85, 0), (1, 0.2)), ((1, 0.2), (1, 0.85)), ((1, 0.85), (0.85, 1)), ((0.85, 1), (0.15, 1)), ((0.15, 1), (0, 0.85)), ((0, 0.85), (0, 0.58)), ((0, 0.58), (0.15, 0.46)), ((0.15, 0.46), (1, 0.46))],
    "1": [((0.25, 0.80), (0.60, 1)), ((0.60, 1), (0.60, 0)), ((0.20, 0), (1.0, 0))],
    # Refined lowercase script glyphs for authentic Porsche `turbo S` & `t-hybrid` italic emblems!
    "t": [((0.35, 0.95), (0.35, 0.14)), ((0.35, 0.14), (0.52, 0.0)), ((0.52, 0.0), (0.88, 0.0)), ((0.08, 0.66), (0.82, 0.66))],
    "u": [((0.12, 0.64), (0.12, 0.16)), ((0.12, 0.16), (0.30, 0.0)), ((0.30, 0.0), (0.76, 0.0)), ((0.76, 0.0), (0.90, 0.16)), ((0.90, 0.64), (0.90, 0.0))],
    "r": [((0.16, 0.0), (0.16, 0.64)), ((0.16, 0.46), (0.42, 0.64)), ((0.42, 0.64), (0.88, 0.64))],
    "b": [((0.14, 0.98), (0.14, 0.0)), ((0.14, 0.48), (0.36, 0.64)), ((0.36, 0.64), (0.74, 0.64)), ((0.74, 0.64), (0.92, 0.46)), ((0.92, 0.46), (0.92, 0.18)), ((0.92, 0.18), (0.74, 0.0)), ((0.74, 0.0), (0.14, 0.0))],
    "o": [((0.26, 0.0), (0.74, 0.0)), ((0.74, 0.0), (0.92, 0.18)), ((0.92, 0.18), (0.92, 0.46)), ((0.92, 0.46), (0.74, 0.64)), ((0.74, 0.64), (0.26, 0.64)), ((0.26, 0.64), (0.08, 0.46)), ((0.08, 0.46), (0.08, 0.18)), ((0.08, 0.18), (0.26, 0.0))],
    "h": [((0.14, 0.98), (0.14, 0.0)), ((0.14, 0.48), (0.36, 0.64)), ((0.36, 0.64), (0.76, 0.64)), ((0.76, 0.64), (0.90, 0.48)), ((0.90, 0.48), (0.90, 0.0))],
    "y": [((0.12, 0.64), (0.48, 0.06)), ((0.90, 0.64), (0.32, -0.22))],
    "i": [((0.50, 0.0), (0.50, 0.64)), ((0.50, 0.84), (0.50, 0.94))],
    "d": [((0.88, 0.98), (0.88, 0.0)), ((0.88, 0.48), (0.66, 0.64)), ((0.66, 0.64), (0.28, 0.64)), ((0.28, 0.64), (0.10, 0.46)), ((0.10, 0.46), (0.10, 0.18)), ((0.10, 0.18), (0.28, 0.0)), ((0.28, 0.0), (0.88, 0.0))],
}


def _build_3d_text(name: str, text: str, x_fn, y_center: float, z_bot: float,
                   letter_w: float, letter_h: float, spacing: float, stroke_r: float,
                   depth: float, material, parent, italic_shear: float = 0.0):
    verts, faces = [], []
    n = len(text)
    total_w = n * letter_w + (n - 1) * spacing
    y_start = y_center + total_w * 0.5
    for idx, ch in enumerate(text):
        strokes = _LETTER_STROKES.get(ch, [])
        yl_char = y_start - idx * (letter_w + spacing)
        for (u0, v0), (u1, v1) in strokes:
            y0, z0 = yl_char - (u0 + italic_shear * v0) * letter_w, z_bot + v0 * letter_h
            y1, z1 = yl_char - (u1 + italic_shear * v1) * letter_w, z_bot + v1 * letter_h
            dy, dz = y1 - y0, z1 - z0
            seg_len = max(math.hypot(dy, dz), 1e-6)
            ny, nz = -dz / seg_len * stroke_r, dy / seg_len * stroke_r
            x0, x1 = x_fn(y0), x_fn(y1)
            b = len(verts)
            verts.extend([
                (x0, y0 + ny, z0 + nz), (x0, y0 - ny, z0 - nz), (x1, y1 - ny, z1 - nz), (x1, y1 + ny, z1 + nz),
                (x0 - depth, y0 + ny, z0 + nz), (x0 - depth, y0 - ny, z0 - nz), (x1 - depth, y1 - ny, z1 - nz), (x1 - depth, y1 + ny, z1 + nz),
            ])
            faces.extend([
                (b + 4, b + 5, b + 6, b + 7), (b, b + 1, b + 5, b + 4),
                (b + 1, b + 2, b + 6, b + 5), (b + 2, b + 3, b + 7, b + 6), (b + 3, b, b + 4, b + 7),
            ])
    if verts:
        create_mesh_object(name, verts, faces, material=material, parent=parent, smooth=False)


def build_taillight_and_rear_details(body_pivot: bpy.types.Object, mats: dict):
    """
    Stage B4 rear signature:
      - Lowered (-12 mm) dark smoked full-width 992.2 LED taillight bar (Z=[0.694, 0.758])
      - Sleeker recessed metallic `P O R S C H E` letters & toned-down lower reverse blade
      - Lowercase italic Turbonite `turbo S` script
      - Beveled matte Gentian Blue `911` showplate (zero white glare)
      - Wider & lower red rear reflectors directly over the black diffuser corner vents
    """
    ys = np.linspace(-0.775, 0.775, 49)

    # 1. Deep smoked full-width taillight cavity seated flush in Z=[0.694, 0.758] channel
    h_grid = []
    for y in ys:
        u = abs(y) / 0.775
        z_hi = 0.758 - 0.008 * (u ** 2.4)
        z_lo = 0.694 + 0.010 * (u ** 2.6)
        xb_top = query_rear_surface_x(y, z_hi, unrecessed=True)
        xb_bot = query_rear_surface_x(y, z_lo, unrecessed=True)
        xb_in = query_rear_surface_x(y, 0.726, unrecessed=False)
        h_grid.append([
            (xb_in + 0.022, y, z_hi),
            (xb_top - 0.002, y, z_hi - 0.002),
            (xb_bot - 0.002, y, z_lo + 0.002),
            (xb_in + 0.022, y, z_lo),
        ])
    create_quad_grid("TSC_Taillight_Housing", h_grid, material=mats["taillight_smoked"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True)

    # 2. UNBROKEN CONTINUOUS GLOWING RED UPPER LED LIGHT BLADE sitting proud of dark housing!
    red_grid = []
    for y in np.linspace(-0.768, 0.768, 49):
        u = abs(y) / 0.775
        z_hi = 0.755 - 0.008 * (u ** 2.4)
        z_lo = z_hi - 0.014
        xb_top = query_rear_surface_x(y, z_hi, unrecessed=True)
        xb_bot = query_rear_surface_x(y, z_lo, unrecessed=True)
        red_grid.append([
            (xb_top + 0.004, y, z_hi),
            (xb_top - 0.007, y, z_hi - 0.0015),
            (xb_bot - 0.007, y, z_lo + 0.0015),
            (xb_bot + 0.004, y, z_lo),
        ])
    create_quad_grid("TSC_Taillight_Bar", red_grid, material=mats["taillight_red"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True)

    # 3. Subtle toned-down smoked lower reverse & indicator blades (B4: 7 mm thin, dark smoked silver)
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        c_grid = []
        for s in np.linspace(0.0, 1.0, 14):
            y = sign * (0.335 + 0.420 * s)
            u = abs(y) / 0.775
            z_lo = 0.698 + 0.010 * (u ** 2.6)
            z_hi = z_lo + 0.007
            xb_out = query_rear_surface_x(y, z_lo + 0.004, unrecessed=True)
            c_grid.append([(xb_out + 0.003, y, z_hi), (xb_out - 0.005, y, z_hi), (xb_out - 0.005, y, z_lo), (xb_out + 0.003, y, z_lo)])
        create_quad_grid(f"TSC_Taillight_Reverse_{tag}", c_grid, material=mats["taillight_clear"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True)

    # 4. Sleeker recessed metallic `P O R S C H E` lettering inside dark smoked cavity (B4!)
    _build_3d_text(
        "TSC_Rear_Porsche",
        "PORSCHE",
        x_fn=lambda y: query_rear_surface_x(y, 0.716, unrecessed=True) - 0.004,
        y_center=0.0,
        z_bot=0.709,
        letter_w=0.036,
        letter_h=0.0125,
        spacing=0.042,
        stroke_r=0.0018,
        depth=0.003,
        material=mats["porsche_lettering"],
        parent=body_pivot,
    )

    # 5. Sleek lowercase italic satin-Turbonite `turbo S` emblem centered cleanly below taillight bar (B4!)
    _build_3d_text(
        "TSC_Rear_TurboSBadge",
        "turbo S",
        x_fn=lambda y: query_rear_surface_x(y, 0.654, unrecessed=False) - 0.001,
        y_center=0.0,
        z_bot=0.646,
        letter_w=0.019,
        letter_h=0.020,
        spacing=0.005,
        stroke_r=0.0018,
        depth=0.0032,
        material=mats["turbonite"],
        parent=body_pivot,
        italic_shear=0.28,
    )

    # Subtle circular right-side rear tow-hook cap (car_spec.md Section 2)
    tx_r = query_rear_surface_x(-0.44, 0.468, unrecessed=False)
    tow_pts = [(tx_r - 0.002, -0.44 + 0.020 * math.cos(a), 0.468 + 0.020 * math.sin(a)) for a in np.linspace(0, 2 * math.pi, 18, endpoint=False)]
    create_tube("TSC_Rear_TowHookCap", tow_pts, radius=0.0015, segments=6, material=mats["shadow"], parent=body_pivot, cyclic=True)

    # 6. Recessed matte Gentian Blue EU `911` showplate + slim black bezel surround (B4: ZERO glare!)
    x_plate = query_rear_surface_x(0.0, 0.500, unrecessed=False) - 0.005
    create_rounded_box("TSC_License_Plate_Frame", (x_plate + 0.002, 0.0, 0.500), (0.006, 0.526, 0.118), material=mats["matte_trim"], parent=body_pivot, bevel_width=0.003)
    create_rounded_box("TSC_License_Plate", (x_plate, 0.0, 0.500), (0.007, 0.516, 0.108), material=mats["plate_blue"], parent=body_pivot, bevel_width=0.002)
    # 7. Crisp taller horizontal red rear reflectors perched cleanly atop outer corner vents (#50: +8 mm taller/higher!)
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        ref_grid = []
        for s in np.linspace(0.0, 1.0, 14):
            y = sign * (0.470 + 0.250 * s)
            xb = query_rear_surface_x(y, 0.425, unrecessed=True)
            z_lo, z_hi = 0.410, 0.440
            ref_grid.append([(xb + 0.010, y, z_hi), (xb - 0.005, y, z_hi), (xb - 0.005, y, z_lo), (xb + 0.010, y, z_lo)])
        create_quad_grid(f"TSC_Reflector_{tag}", ref_grid, material=mats["reflector_red"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True)

    # 8. Flush smoked horizontal front fender side markers (zero blade protrusion!)
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        sm_pts = [(float(x), sign * (eval_flank_y(float(x), 0.545) + 0.001), 0.545) for x in np.linspace(1.605, 1.775, 10)]
        create_tube(f"TSC_SideMarker_{tag}", sm_pts, radius=0.0065, segments=8, material=mats["sidemarker"], parent=body_pivot)
