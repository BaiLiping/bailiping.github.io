"""
Optics, Windshield/A-Pillars, Wipers, Taillight Bar, Side Markers & 3D Badges for the
2026 Porsche 911 Turbo S Cabriolet (992.2 T-Hybrid):
  - Windshield + Gentian Blue A-pillar/header frame + black frit + twin aeroblade wipers
  - Flush compact 992.2 HD-Matrix LED headlights (dark housing + twin projectors + crisp 4-bar DRLs + clear cover)
  - Full-width sculpted 992.2 LED taillight bar aligned 100% to `rear_surface_x_at_y()` (ZERO floating corners!)
  - 3D Turbonite `P O R S C H E` lettering, `turbo S` badge, wide EU `911` plate, flush red rear reflectors & front side markers
"""

import math
import numpy as np
import bpy
import bmesh
from mathutils import Vector

from . import config as cfg
from .geom_utils import (
    smootherstep,
    create_quad_grid,
    create_solidified_panel,
    create_mesh_object,
    create_rounded_box,
    create_tube,
)
from .body_shell import (
    eval_front_hood_z,
    eval_hood_hw,
    eval_flank_y,
    rear_surface_x_at_y,
    query_rear_surface_x,
    query_body_ray,
    get_headlight_basis,
    HL_MAJOR_A,
    HL_MINOR_B,
)


# ---------------------------------------------------------------------------
# 1. Windshield, Painted A-Pillar Frame, Cowl Plenum & Twin Wipers
# ---------------------------------------------------------------------------
def eval_windshield_pt(t: float, v: float):
    av = abs(v)
    x_cowl = cfg.X_COWL_CENTER - (cfg.X_COWL_CENTER - cfg.X_COWL_SIDE) * (av ** 2.2)
    z_cowl = cfg.Z_COWL_CENTER + (cfg.Z_COWL_SIDE - cfg.Z_COWL_CENTER) * (av ** 2.0)
    y_cowl = v * 0.732

    x_head = cfg.X_HEADER_CENTER - (cfg.X_HEADER_CENTER - cfg.X_HEADER_SIDE) * (av ** 2.1)
    z_head = cfg.Z_HEADER_CENTER - (cfg.Z_HEADER_CENTER - cfg.Z_HEADER_SIDE) * (av ** 2.1)
    # Encloses @interior's TSC_Trim_WindshieldHeader cleanly with sleek 992 trapezoidal rake!
    y_head = v * 0.620

    dome = 0.014 * math.sin(math.pi * t) * (1.0 - 0.6 * av * av)
    x = x_cowl + (x_head - x_cowl) * t + dome
    y = y_cowl + (y_head - y_cowl) * t
    z = z_cowl + (z_head - z_cowl) * t + 0.008 * math.sin(math.pi * t)
    return (x, y, z)


def build_windshield_and_frame(body_pivot: bpy.types.Object, mats: dict):
    ts = np.linspace(0.0, 1.0, 34)
    vs = np.linspace(-.992,.992,53)
    glass_grid = [[eval_windshield_pt(t, v) for v in vs] for t in ts]
    create_solidified_panel("TSC_Glass_Windshield", glass_grid, thickness=0.005, material=mats["glass"], parent=body_pivot)

    # Continuous U-shaped Gentian Blue painted A-pillars & upper windshield header bow
    frame_spine = []
    for t in np.linspace(0.0, 1.0, 14):
        frame_spine.append(("R", eval_windshield_pt(t, -1.0)))
    for v in np.linspace(-0.94, 0.94, 21):
        frame_spine.append(("T", eval_windshield_pt(1.0, v)))
    for t in np.linspace(1.0, 0.0, 14):
        frame_spine.append(("L", eval_windshield_pt(t, +1.0)))

    frame_sections = []
    n_pts = len(frame_spine)
    centre = np.array(eval_windshield_pt(0.5, 0.0), dtype=np.float64)
    # Flush A-pillar/header strip: a flat face level with the outer glass surface that runs
    # 34 mm out from the glass edge and rolls under, as the profile and overhead frames show.
    profile = [(-0.012, 0.0015), (0.004, 0.0035), (0.020, 0.0035), (0.030, 0.0005), (0.036, -0.006),
               (0.037, -0.015), (0.033, -0.023), (0.020, -0.027), (0.002, -0.026), (-0.012, -0.018)]
    for i, (kind, pt) in enumerate(frame_spine):
        p = np.array(pt, dtype=np.float64)
        p_prev = np.array(frame_spine[max(0, i - 1)][1], dtype=np.float64)
        p_next = np.array(frame_spine[min(n_pts - 1, i + 1)][1], dtype=np.float64)
        tang = p_next - p_prev
        tang /= max(np.linalg.norm(tang), 1e-6)
        # outward normal of the screen (forward-up) and the in-plane direction away from the glass
        out_hint = np.array([0.45, 0.0, 0.72]) if kind == "T" else np.array([0.45, p[1] * 0.35, 0.72])
        out_hint -= np.dot(out_hint, tang) * tang
        out_hint /= max(np.linalg.norm(out_hint), 1e-6)
        away = p - centre
        away -= np.dot(away, tang) * tang + np.dot(away, out_hint) * out_hint
        away /= max(np.linalg.norm(away), 1e-6)
        ring = [tuple(p + away * a + out_hint * b) for a, b in profile]
        frame_sections.append(ring)

    create_quad_grid("TSC_Windshield_Frame", frame_sections, material=mats["paint"], parent=body_pivot, cyclic_v=True, cap_u0=True, cap_u1=True, smooth=True)

    frit_pts = [eval_windshield_pt(t, -0.965) for t in np.linspace(0.02, 0.97, 10)]
    frit_pts += [eval_windshield_pt(0.975, v) for v in np.linspace(-0.92, 0.92, 16)]
    frit_pts += [eval_windshield_pt(t, +0.965) for t in np.linspace(0.97, 0.02, 10)]
    frit_pts += [eval_windshield_pt(0.025, v) for v in np.linspace(0.92, -0.92, 16)]
    create_tube("TSC_Windshield_Frit", frit_pts, radius=0.011, segments=8, material=mats["gloss_black"], parent=body_pivot, cyclic=True)

    cowl_grid = []
    for v in np.linspace(-0.96, 0.96, 23):
        p0 = eval_windshield_pt(0.0, v)
        cowl_grid.append([(p0[0] + 0.040, p0[1], p0[2] - 0.015), (p0[0], p0[1], p0[2] - 0.002), (p0[0] - 0.055, p0[1], p0[2] - 0.008)])
    create_quad_grid("TSC_Cowl_Plenum", cowl_grid, material=mats["matte_trim"], parent=body_pivot)

    # The rear corners of the bonnet follow the foot of the windshield.
    # Carry the centre strip on the hinged lid and attach the two scuttle
    # corners to the body so opening the bonnet exposes the plenum.
    hood_half = float(eval_hood_hw(.79))-.0025
    lid = bpy.data.objects["Pivot_Front_Lid"]
    def aft_cowl(y):
        x,_,z=eval_windshield_pt(0,np.clip(y/.732,-1,1))
        return x+.022, z-.012-.003*min(abs(y)/.732,1)**2

    patch=[]
    for y in np.linspace(-hood_half+.001,hood_half-.001,72):
        x0,z0=aft_cowl(y)
        z1=float(eval_front_hood_z(.788,y))
        patch.append([((1-t)*x0+t*.788,y,(1-t)*z0+t*z1+.004*math.sin(math.pi*t))
                      for t in np.linspace(0,1,9)])
    create_quad_grid("TSC_Cowl_Plenum_Painted_Bonnet",patch,material=mats["paint"],parent=lid)

    # Continue the fixed fender skin to the foot of each A-pillar. Using the
    # actual rear row of the fender gives a welded, smooth painted panel and
    # keeps the opening seam exclusively on the hinged bonnet edge.
    shell=bpy.data.objects["TSC_Body_Shell"]
    bm=bmesh.new()
    bm.from_mesh(shell.data)
    for sign in (-1,1):
        edge_points=set()
        for edge in bm.edges:
            a,b=edge.verts
            if (edge.is_boundary and .80<a.co.x<.83 and abs(a.co.x-b.co.x)<.00001
                    and min(sign*a.co.y,sign*b.co.y)>.50 and min(a.co.z,b.co.z)>.80):
                edge_points.update(edge.verts)
        rim=sorted(edge_points,key=lambda vertex:vertex.co.y)
        if len(rim)<3:
            raise ValueError("Missing rear boundary on the front fender")
        previous=rim
        for t in np.linspace(1,0,12)[1:]:
            row=[]
            for v in rim:
                x1,y,z1=v.co
                x0,z0=aft_cowl(y)
                # Match the tangent of the adjacent hood-height field at
                # the welded edge instead of leaving a crease across paint.
                blend=t*t*(3-2*t)
                x=(1-t)*x0+t*x1
                xy_slope=(float(eval_front_hood_z(x1+.002,y))-float(eval_front_hood_z(x1-.002,y)))/.004
                z=(1-blend)*z0+blend*z1+xy_slope*(x1-x0)*t*t*(t-1)
                row.append(bm.verts.new((x,y,z)))
            for j in range(len(row)-1):
                face=bm.faces.new((row[j],previous[j],previous[j+1],row[j+1]))
                face.smooth=True
            previous=row
    bm.normal_update()
    bm.to_mesh(shell.data)
    bm.free()
    shell.data.update()
    w1_pts = [(x + 0.014, y, z + 0.006) for (x, y, z) in [eval_windshield_pt(0.045 + 0.020 * s, 0.05 + 0.72 * s) for s in np.linspace(0.0, 1.0, 10)]]
    create_tube("TSC_Wiper_L", w1_pts, radius=0.006, segments=8, material=mats["matte_trim"], parent=body_pivot)
    w2_pts = [(x + 0.014, y, z + 0.006) for (x, y, z) in [eval_windshield_pt(0.032 + 0.018 * s, -0.62 + 0.68 * s) for s in np.linspace(0.0, 1.0, 10)]]
    create_tube("TSC_Wiper_R", w2_pts, radius=0.006, segments=8, material=mats["matte_trim"], parent=body_pivot)


# ---------------------------------------------------------------------------
# 2. 100% FLUSH Raycasted 992.2 HD-Matrix 4-Point LED Headlights
# ---------------------------------------------------------------------------
def build_headlights(body_pivot: bpy.types.Object, mats: dict):
    """
    100% FLUSH 992.2 Porsche oval HD-Matrix LED headlights projected directly via
    3D BVH raycast onto the smooth UN-RECESSED Class-A front fender barrel!
    Zero protruding frog-eye rings from front, side, or 3/4 views!
    """
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        c_hl, n_hl, u_hl, v_hl = get_headlight_basis(sign)
        a_maj = HL_MAJOR_A * 0.96
        b_min = HL_MINOR_B * 0.96
        n_ring = 48
        angs = np.linspace(0.0, 2.0 * math.pi, n_ring, endpoint=False)

        # 100.0% FLUSH raycast directly onto the glass-smooth UNDEFORMED Class-A fender barrel!
        # Because body_shell.py now clips the oval analytically WITHOUT distorting a single fender vertex,
        # exact raycast guarantees ZERO step/gap underneath the headlight from EVERY 3/4 & front angle!
        c_hit, _ = query_body_ray(c_hl + n_hl * 0.45, -n_hl, unrecessed=True, max_dist=1.2)
        c_anchor = c_hit if c_hit is not None else c_hl
        a_maj = HL_MAJOR_A * 0.945
        b_min = HL_MINOR_B * 0.945

        def _surf_pt(ru: float, rv: float, offset_n: float = 0.0):
            base = c_hl + u_hl * (a_maj * ru) + v_hl * (b_min * rv)
            hit_p, _ = query_body_ray(base + n_hl * 0.45, -n_hl, unrecessed=True, max_dist=1.2)
            if hit_p is not None:
                p = hit_p + n_hl * offset_n
            else:
                r2 = ru * ru + rv * rv
                p = (c_anchor + u_hl * (a_maj * ru) + v_hl * (b_min * rv)) - n_hl * (0.028 * r2 - offset_n)
            return (float(p.x), float(p.y), float(p.z))

        # 1. Razor-flush dark glossy perimeter bezel hugging the EXACT analytical fender cutout!
        bezel_pts = [_surf_pt(math.cos(a), math.sin(a), offset_n=0.0005) for a in angs]
        create_tube(f"TSC_Headlight_Bezel_{tag}", bezel_pts, radius=0.0068, segments=10, material=mats["gloss_black"], parent=body_pivot, cyclic=True)

        # 2. Deep jet-black internal optical housing cup recessed -62 mm cleanly inside the cutout!
        cup_grid = []
        for s in [0.0, 0.25, 0.65, 1.0]:
            rad = 1.00 - 0.16 * s
            off = -0.001 - 0.060 * s
            cup_grid.append([_surf_pt(rad * math.cos(a), rad * math.sin(a), offset_n=off) for a in angs])
        create_quad_grid(f"TSC_Headlight_Housing_{tag}", cup_grid, material=mats["shadow"], parent=body_pivot, cyclic_v=True, cap_u1=True)

        # 3. Twin central dark-anodized HD-Matrix projector barrels inside deep dark optical bowl
        for idx, du_p in enumerate([-0.19, +0.19]):
            p_ring = [_surf_pt(du_p + 0.16 * math.cos(a), 0.18 * math.sin(a), offset_n=-0.036) for a in np.linspace(0, 2 * math.pi, 20, endpoint=False)]
            create_tube(f"TSC_Headlight_Projector_{tag}_{idx}", p_ring, radius=0.0030, segments=8, material=mats["turbonite"], parent=body_pivot, cyclic=True)

        # 4. REFINED SLIM 992.2 4-POINT SEGMENTED LED LIGHT GUIDES (P1: subtle dark-smoked fine blades!)
        for idx, (du_f, dv_f) in enumerate([(-0.34, -0.43), (-0.34, +0.43), (+0.34, -0.43), (+0.34, +0.43)]):
            pc = Vector(_surf_pt(du_f, dv_f, offset_n=-0.024))
            for sub, dz_sub in enumerate([-0.0038, +0.0038]):
                p0 = (pc.x, pc.y - 0.015, pc.z + dz_sub)
                p1 = (pc.x, pc.y + 0.015, pc.z + dz_sub)
                create_tube(f"TSC_Headlight_DRL_{tag}_{idx}_{sub}", [p0, p1], radius=0.0016, segments=8, material=mats["drl_white"], parent=body_pivot)

        # 5. Silky-smooth fender-conforming clear polycarbonate cover lens (+3 mm center, +1 mm bezel!)
        n_rad = 8
        lens_rings = []
        for ir in range(1, n_rad + 1):
            r_f = ir / n_rad
            dome = 0.004 * (1.0 - r_f * r_f) + 0.001
            lens_rings.append([_surf_pt(r_f * math.cos(a), r_f * math.sin(a), offset_n=dome) for a in angs])
        apex = _surf_pt(0.0, 0.0, offset_n=0.005)
        lens_verts = [apex] + [pt for ring in lens_rings for pt in ring]
        lens_faces = [(0, 1 + j, 1 + (j + 1) % n_ring) for j in range(n_ring)]
        for ir in range(n_rad - 1):
            b0 = 1 + ir * n_ring
            b1 = 1 + (ir + 1) * n_ring
            for j in range(n_ring):
                j2 = (j + 1) % n_ring
                lens_faces.append((b0 + j, b1 + j, b1 + j2, b0 + j2))
        create_mesh_object(f"TSC_Headlight_Lens_{tag}", lens_verts, lens_faces, material=mats["headlight_lens"], parent=body_pivot, smooth=True)
        # The reflector sits within the housing, behind the independently
        # reflecting outer lens. Its pattern comes from Porsche studio frame 36.
        from .surface_details import material, uv_by_vertex
        reflector_material = material("HD Matrix reflector", "matrix-reflector.png", 0.18, 0.46, 0.40)
        reflector = [tuple(Vector(p) - n_hl*0.019) for p in lens_verts]
        optic = create_mesh_object(f"TSC_Headlight_Reflector_{tag}", reflector, lens_faces,
                                   material=reflector_material, parent=body_pivot)
        uv = [(0.5, 0.5)]
        for ir in range(1, n_rad+1):
            for a in angs:
                uv.append((0.5-0.5*ir/n_rad*math.sin(a), 0.5+0.5*ir/n_rad*math.cos(a)))
        uv_by_vertex(optic, np.array(uv))



# ---------------------------------------------------------------------------
# 3. Full-Width 992.2 LED Taillight Bar, 3D PORSCHE Lettering, Badges & Reflectors
# ---------------------------------------------------------------------------
def build_taillight_and_rear_details(body_pivot: bpy.types.Object, mats: dict):
    """
    Stage B4 rear signature:
      - Lowered (-12 mm) dark smoked full-width 992.2 LED taillight bar (Z=[0.694, 0.758])
      - Sleeker recessed metallic `P O R S C H E` letters & toned-down lower reverse blade
      - Lowercase italic Turbonite `turbo S` script
      - Beveled matte Gentian Blue `911` showplate (zero white glare)
      - Wider & lower red rear reflectors directly over the black diffuser corner vents
    """
    # Subtle circular right-side rear tow-hook cap (car_spec.md Section 2)
    tx_r = query_rear_surface_x(-0.44, 0.468, unrecessed=False)
    tow_pts = [(tx_r - 0.002, -0.44 + 0.020 * math.cos(a), 0.468 + 0.020 * math.sin(a)) for a in np.linspace(0, 2 * math.pi, 18, endpoint=False)]
    create_tube("TSC_Rear_TowHookCap", tow_pts, radius=0.0015, segments=6, material=mats["shadow"], parent=body_pivot, cyclic=True)

    # 6. Recessed matte Gentian Blue EU `911` showplate + slim black bezel surround (B4: ZERO glare!)
    x_plate = query_rear_surface_x(0.0, 0.500, unrecessed=False) - 0.005
    create_rounded_box("TSC_License_Plate_Frame", (x_plate + 0.002, 0.0, 0.500), (0.006, 0.526, 0.118), material=mats["matte_trim"], parent=body_pivot, bevel_width=0.003)
    create_rounded_box("TSC_License_Plate", (x_plate, 0.0, 0.500), (0.007, 0.516, 0.108), material=mats["plate_blue"], parent=body_pivot, bevel_width=0.002)
    # 8. Flush smoked horizontal front fender side markers (zero blade protrusion!)
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        sm_pts = [(float(x), sign * (eval_flank_y(float(x), 0.545) + 0.001), 0.545) for x in np.linspace(1.605, 1.775, 10)]
        create_tube(f"TSC_SideMarker_{tag}", sm_pts, radius=0.0065, segments=8, material=mats["sidemarker"], parent=body_pivot)
