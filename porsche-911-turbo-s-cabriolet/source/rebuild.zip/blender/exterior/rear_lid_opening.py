"""Service opening and stationary weather seal underneath the hinged rear grille."""
import math

import bmesh
import bpy
import numpy as np
from mathutils import Vector

from .geom_utils import create_mesh_object, create_quad_grid
from .materials import make_pbr


def opening_outline(grille_point):
    # The two long edges sweep forward with the lid toward the sides of the car.
    # Sample them in Y to carry that sweep through the middle of each edge.
    radius = .021
    pts = []
    for cy, cs, angle in [(.464, .873, 0), (-.464, .873, 90),
                          (-.464, .127, 180), (.464, .127, 270)]:
        for step in range(6):
            a = math.radians(angle + step * 18)
            pts.append((cy + radius * math.cos(a), cs + radius * math.sin(a) / .267))
    ring = []
    for (y0, s0), (y1, s1) in zip(pts, pts[1:] + pts[:1]):
        steps = max(1, math.ceil(abs(y1 - y0) / .060))
        for t in np.arange(steps) / steps:
            y = (1 - t) * y0 + t * y1
            s = (1 - t) * s0 + t * s1
            ring.append((float(y), float(s), Vector(grille_point(y, s))))
    return ring


def excise_deck_skin(shell, outline):
    bm = bmesh.new()
    bm.from_mesh(shell.data)
    points = [p for _, _, p in outline]
    # Only the upper band behind the cockpit participates in the vertical cuts.
    candidates = [f for f in bm.faces if -.67 < f.calc_center_median().y < .67
                  and -2.11 < f.calc_center_median().x < -1.48
                  and f.calc_center_median().z > .81]
    faces = set(candidates)
    for a, b in zip(points, points[1:] + points[:1]):
        x0, x1 = sorted((a.x, b.x))
        y0, y1 = sorted((a.y, b.y))
        nearby = []
        for face in faces:
            if not face.is_valid:
                continue
            vs = [v.co for v in face.verts]
            if min(p.x for p in vs) <= x1 + .0001 and max(p.x for p in vs) >= x0 - .0001 and min(p.y for p in vs) <= y1 + .0001 and max(p.y for p in vs) >= y0 - .0001:
                nearby.append(face)
        if nearby:
            edges = {e for f in nearby for e in f.edges}
            verts = {v for e in edges for v in e.verts}
            result = bmesh.ops.bisect_plane(bm, geom=[*nearby, *edges, *verts], dist=1e-7,
                                           plane_co=a, plane_no=Vector((b.y - a.y, a.x - b.x, 0)).normalized())
            faces.update(g for g in result['geom'] if isinstance(g, bmesh.types.BMFace))

    def inside(p):
        intersections = 0
        for a, b in zip(points, points[1:] + points[:1]):
            if (a.y > p.y) != (b.y > p.y):
                cross_x = a.x + (p.y - a.y) * (b.x - a.x) / (b.y - a.y)
                intersections += cross_x > p.x
        return intersections % 2

    removed = [f for f in faces if f.is_valid and inside(f.calc_center_median())]
    if not removed:
        raise ValueError('Rear service opening does not intersect the deck skin')
    bmesh.ops.delete(bm, geom=removed, context='FACES')
    bm.to_mesh(shell.data)
    bm.free()
    shell.data.update()


def fit_fan_guards(fan):
    # On the Cabriolet service-bay photograph each fan has a fine perforated
    # guard coplanar with the sloped shroud. Its outer rim hides the fasteners.
    verts, faces = [], []
    radius = .0078
    slope = math.tan(math.radians(15.0))

    def loop(cx, cy, r, steps, height):
        ids = []
        for j in range(steps):
            angle = 2 * math.pi * j / steps
            x = cx + r * math.cos(angle)
            y = cy + r * math.sin(angle)
            ids.append(len(verts))
            verts.append((x, y, .898 + slope * (x + 1.821) + height))
        return ids

    def strip(a, b):
        for j in range(len(a)):
            k = (j + 1) % len(a)
            faces.append((a[j], a[k], b[k], b[j]))

    for cy in (-.235, .235):
        cx = -1.821
        bottom = loop(cx, cy, .118, 64, -.015)
        edge = loop(cx, cy, .117, 64, .001)
        lip = loop(cx, cy, .104, 64, .004)
        inner = loop(cx, cy, .102, 64, .002)
        strip(bottom, edge)
        strip(edge, lip)
        strip(lip, inner)
        for col in range(-10, 11):
            for row in range(-10, 11):
                dx = 1.5 * radius * col
                dy = math.sqrt(3) * radius * (row + .5 * (col % 2))
                if math.hypot(dx, dy) > .107:
                    continue
                outer = loop(cx + dx, cy + dy, radius, 6, .001)
                hole = loop(cx + dx, cy + dy, radius - .0014, 6, .001)
                strip(outer, hole)

    material = make_pbr('Mat_Service_Fan_Guard', '#343537', metallic=.30, roughness=.52)
    guard = create_mesh_object('TSC_Service_Fan_Guard', verts, faces, material,
                               parent=fan.parent, smooth=False, recalc_normals=False)
    # The joined mesh uses the fan module's existing exploded-view motion.
    bpy.ops.object.select_all(action='DESELECT')
    fan.select_set(True)
    guard.select_set(True)
    bpy.context.view_layer.objects.active = fan
    bpy.ops.object.join()


def build(shell, parent, grille_point):
    ring = opening_outline(grille_point)
    # Ray-cast before clipping to place the static rubber lip on the actual painted surface.
    rows = []
    floor = []
    for y, s, point in ring:
        outer = Vector(grille_point(y * 1.020, .5 + (s - .5) * 1.05))
        hit, top, _, _ = shell.ray_cast(Vector((outer.x, outer.y, 1.25)), Vector((0, 0, -1)))
        if not hit:
            raise ValueError('Service opening misses the rear deck')
        lip = top.z + .002
        inner = Vector(grille_point(y * .981, .5 + (s - .5) * .957))
        bottom = (inner.x, inner.y, .757)
        rows.append([(outer.x, outer.y, lip), (point.x, point.y, lip + .001),
                     (inner.x, inner.y, lip - .008), bottom])
        floor.append(bottom)
    excise_deck_skin(shell, ring)
    rubber = make_pbr('Mat_Service_Bay_Seal', '#27282a', metallic=.03, roughness=.60)
    create_quad_grid('TSC_Rear_Service_Shroud_Return', rows, material=rubber,
                     parent=parent, cyclic_u=True, smooth=False)
    create_mesh_object('TSC_Rear_Service_Shroud_Floor', floor,
                       [tuple(reversed(range(len(floor))))], material=rubber, parent=parent,
                       smooth=False)
    # Locate the existing twin fans and filler cap below the registered opening.
    fan = bpy.data.objects.get('TSC_Eng_IntakePlenum_FanShroud')
    if fan:
        fan.location.x -= .141
        fan.location.z += .035
        bpy.context.view_layer.update()
        fit_fan_guards(fan)
