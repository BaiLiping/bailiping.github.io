"""Photo-fitted 992.2 tail valance in the final metric body frame.

The hook at each corner wraps from a vertical slot behind the rear wheel to a
tapering upper outlet. Its outline was triangulated on Porsche views 06, 07,
12 and 19. Depths inside the apertures are inferred.
"""
import math

import bmesh
import bpy
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

from .geom_utils import create_mesh_object, create_quad_grid, pchip_eval
from .materials import create_all_materials, make_pbr


# Along the left bumper corner, s increases from the tail towards the wheel.
TANGENT = Vector((0.857493, 0.514496, 0.0))
NORMAL = Vector((-TANGENT.y, TANGENT.x, 0.0))
# z, rearward edge of slot, wheel-side edge of slot, metres.
OUTLET = np.array([
    [.252, -1.108, -1.105], [.260, -1.126, -1.100],
    [.280, -1.139, -1.099], [.365, -1.149, -1.107],
    [.438, -1.161, -1.115], [.487, -1.173, -1.124],
    [.504, -1.186, -1.130], [.514, -1.212, -1.136],
    [.523, -1.235, -1.145], [.538, -1.261, -1.177],
    [.557, -1.291, -1.230], [.572, -1.315, -1.278],
    [.583, -1.335, -1.327],
])


def _mirrored(point, side):
    return Vector((point.x, side * point.y, point.z))


def _unit_ramp(v):
    v = float(np.clip(v, 0, 1))
    return v * v * (3 - 2 * v)


def _inside(pt, boundary):
    x, y = pt
    inside = False
    for a, b in zip(boundary, np.roll(boundary, -1, axis=0)):
        if (a[1] > y) != (b[1] > y):
            if x < a[0] + (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]):
                inside = not inside
    return inside


def _cut_opening(obj, boundary, along, side, outer_shell=False):
    """Split the actual skin along a polygon in the local s/z projection."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    direction = _mirrored(along, side)
    lo, hi = boundary.min(axis=0), boundary.max(axis=0)
    def nearby(face):
        center = face.calc_center_median()
        if center.x > -1.53 or center.y * side < .22:
            return False
        if outer_shell and center.dot(_mirrored(NORMAL, side)) < 1.54:
            return False
        s = center.dot(direction)
        return lo[0] - .09 < s < hi[0] + .09 and lo[1] - .065 < center.z < hi[1] + .065
    for a, b in zip(boundary, np.roll(boundary, -1, axis=0)):
        ds, dz = b - a
        normal = (direction * float(dz) - Vector((0, 0, float(ds)))).normalized()
        plane = direction * float(a[0]) + Vector((0, 0, float(a[1])))
        selected = []
        for f in bm.faces:
            if not nearby(f):
                continue
            # Restrict each cut to the local segment and its adjacent faces.
            # Blender also splits the edges shared with unselected neighbours.
            verts = [v.co for v in f.verts]
            min_s, max_s = min(v.dot(direction) for v in verts), max(v.dot(direction) for v in verts)
            min_z, max_z = min(v.z for v in verts), max(v.z for v in verts)
            if min_s <= max(a[0], b[0]) + .002 and max_s >= min(a[0], b[0]) - .002 and min_z <= max(a[1], b[1]) + .002 and max_z >= min(a[1], b[1]) - .002:
                selected.append(f)
        edges = {e for f in selected for e in f.edges}
        verts = {v for e in edges for v in e.verts}
        if selected:
            bmesh.ops.bisect_plane(bm, geom=[*selected, *edges, *verts], dist=1e-7,
                                   plane_co=plane, plane_no=normal)
    removed = []
    for f in bm.faces:
        if nearby(f):
            v = f.calc_center_median()
            if _inside((v.dot(direction), v.z), boundary):
                removed.append(f)
    if not removed:
        raise ValueError(f'Empty outlet cut in {obj.name}')
    bmesh.ops.delete(bm, geom=removed, context='FACES')
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


def _double_tailpipes(tag, side, surface):
    old = bpy.data.objects.get('TSC_Exhaust_Tip_'+tag)
    if old is None:
        return
    parent = old.parent
    bpy.data.objects.remove(old, do_unlink=True)
    soot = make_pbr('Tailpipe soot', '#101113', roughness=.90, specular_ior=.17)
    metal = make_pbr('Tailpipe inner sleeve', '#313238', metallic=.30, roughness=.52)
    verts, faces, outer_rows, feed_faces = [], [], [], []
    steps = 48
    # Follow the rotated rear bumper at each barrel. The outer lip ends
    # behind the surround and the inner wall runs back to a dark baffle.
    for offset in (-.051, .051):
        y0, z0 = .580+offset,.332
        base = len(verts)
        for radius, depth in ((.032,.119),(.034,.060),(.035,.025),(.034,.023),
                              (.029,.025),(.028,.056),(.025,.113)):
            for angle in np.linspace(0,2*np.pi,steps,endpoint=False):
                y=y0+radius*np.cos(angle)
                z=z0+radius*np.sin(angle)
                p=surface(y,z)
                p[0]+=depth
                verts.append(_mirrored(Vector(p),side))
        for row in range(6):
            for j in range(steps):
                a=base+steps*row+j
                b=base+steps*row+(j+1)%steps
                if row in (2,3):
                    outer_rows.append(len(faces))
                faces.append((a,b,b+steps,a+steps))
        faces.append(tuple(base+6*steps+j for j in range(steps)))

        # Continue the inlet ring itself into the silencer's side wall. The
        # two necks turn inboard at different X stations, as in the factory
        # three-quarter powertrain illustration. The bumper lips stay fixed.
        inlet = Vector(surface(y0, z0)) + Vector((.119, 0, 0))
        port = Vector((-2.084, .417, .320) if offset < 0 else (-2.029, .417, .341))
        control1 = inlet + Vector((.041, 0, 0))
        control2 = port + Vector((0, (inlet.y - port.y) * .42, 0))
        previous = [base + j for j in range(steps)]
        for station in range(1, 15):
            t = station / 14
            u = 1 - t
            center = u**3 * inlet + 3*u*u*t * control1 + 3*u*t*t * control2 + t**3 * port
            tangent = (u*u*(control1-inlet) + 2*u*t*(control2-control1) + t*t*(port-control2)).normalized()
            lateral = Vector((0, 0, 1)).cross(tangent).normalized()
            upward = tangent.cross(lateral)
            radius = .032 - .004 * math.sin(t * math.pi / 2)
            current = []
            for angle in np.linspace(0, 2*math.pi, steps, endpoint=False):
                radial = math.cos(angle)*lateral + math.sin(angle)*upward
                current.append(len(verts))
                verts.append(_mirrored(center + radius*radial, side))
            for j in range(steps):
                k = (j+1) % steps
                feed_faces.append(len(faces))
                loop = (previous[j], previous[k], current[k], current[j])
                faces.append(loop if side > 0 else loop[::-1])
            previous = current
    titanium = bpy.data.materials['Mat_Titanium_Exhaust']
    obj=create_mesh_object('TSC_Exhaust_Tip_'+tag,verts,faces,[soot,metal,titanium],parent=parent,
                           recalc_normals=False)
    for idx in outer_rows:
        obj.data.polygons[idx].material_index=1
    for idx in feed_faces:
        obj.data.polygons[idx].material_index=2


def rebuild_rear_valance():
    mats = create_all_materials()
    shell = bpy.data.objects['TSC_Body_Shell']
    parent = shell.parent
    boot = bmesh.new()
    boot.from_mesh(shell.data)
    body = BVHTree.FromBMesh(boot)
    boot.free()

    def skin(s, z):
        origin = TANGENT * float(s) + NORMAL * 2.1 + Vector((0, 0, float(z)))
        pt = body.ray_cast(origin, -NORMAL, 1.0)[0]
        if pt is None:
            raise ValueError(f'No corner skin under outlet ({s:.3f}, {z:.3f})')
        return pt

    # The wheel-side skin overlaps the return in three-quarter views.
    traced = OUTLET.copy()
    traced[:, 1] += .16 * (traced[:, 2] - traced[:, 1])
    outline = np.column_stack((np.r_[traced[:, 1], traced[::-1, 2]],
                               np.r_[traced[:, 0], traced[::-1, 0]]))
    # Retreat the old painted substrate behind the new diffuser channels.
    # Leave the skin supporting the outer ducts intact.
    for v in shell.data.vertices:
        x, y, z = v.co
        s = x*TANGENT.x + abs(y)*TANGENT.y
        if x < -1.80 and z < .455 and s < -1.20:
            v.co.x += .095 * _unit_ramp((.455-z)/.045) * _unit_ramp((-1.20-s)/.13)
        if x < -1.60 and .23 < z < .62 and s > -1.54:
            outer = np.interp(z,traced[:,0],traced[:,2])
            # A slight crown above the rising outlet picks up the studio light.
            # Keep the traced boundary itself fixed for the rolled edging.
            distance = s-outer
            if 0 < distance < .13:
                crown = .012 * np.sin(np.pi*distance/.13)**2
                crown *= _unit_ramp((z-.36)/.12)*_unit_ramp((.62-z)/.08)
                v.co += _mirrored(NORMAL, 1 if y>0 else -1)*crown
    shell.data.update()
    trim = make_pbr('Rear valance graphite moulding', '#414348', roughness=.58, specular_ior=.32)
    throat = make_pbr('Corner outlet black lining', '#101113', roughness=.82, specular_ior=.17)
    satin = make_pbr('Gentian satin outlet return', '#182343', metallic=.56,
                     roughness=.32, coat_weight=.34, coat_roughness=.19)
    inset_satin = make_pbr('Outlet inner bevel', '#202332', metallic=.34,
                           roughness=.48, coat_weight=.12)
    for side, tag in [(1,'L'),(-1,'R')]:
        _cut_opening(shell, outline, TANGENT, side, outer_shell=True)
        # On 06, the oblique opening displays a painted rolled edge and a
        # darker reveal. Below the reflector the inboard moulding crosses
        # behind the reveal, almost closing the slot as it meets the rocker.
        lip, wall, back = [], [], []
        zs = np.unique(np.r_[traced[:,0], .267, .302, .405, .424, .455, .475])
        for z in zs:
            s1, s2 = (np.interp(z,traced[:,0],traced[:,i]) for i in (1,2))
            w = s2-s1
            rise = _unit_ramp((z-.252)/.065)
            turn = _unit_ramp((z-.485)/.054)
            end = _unit_ramp((.583-z)/.030)
            depth = (.001+.032*rise)*(.27+.73*end)
            near = .19+.14*turn
            far = (.78-.19*rise)*(1-turn)+.17*turn
            def point(u, d):
                return _mirrored(skin(s1+w*u,z)-NORMAL*d,side)
            # Each edge rolls into the opening in section, producing an
            # actual oblique highlight even under a moving environment.
            lip.append([point(u,d) for u,d in
                        ((1.02,-.00015),(1.,-.00080),(.97,.0004),(1-near*.58,depth*.10),
                         (1-near,depth*.26),(1-near-.035,depth*.65))])
            wall.append([point(u,d) for u,d in
                         ((-.008,-.0002),(far*.25,depth*.04),(far*.74,depth*.12),
                          (far,depth*.23),(far+.035,depth*.75))])
            back.append([point(u,depth) for u in np.linspace(-.03,1.03,5)])
        outer = create_quad_grid('TSC_Rear_Bumper_Outlet_Lip_'+tag,lip,
                                 material=[mats['paint'],satin,throat],parent=parent)
        for f in outer.data.polygons:
            f.material_index = (0,1,1,1,2)[f.index % 5]
        inner = create_quad_grid('TSC_Rear_AirCurtain_Throat_'+tag,wall,
                                 material=[trim,inset_satin,throat],parent=parent)
        for f in inner.data.polygons:
            f.material_index = 2 if f.index % 4 == 3 else int(f.center.z > .514)
        create_quad_grid('TSC_Rear_AirCurtain_Plenum_'+tag,back,material=throat,parent=parent)

    # A single valance, with two ramped centre channels and a medial spine.
    # The outermost sections turn forwards toward each actual corner aperture.
    stations = np.array([0,.19,.36,.45,.58,.70,.78,.82,.85,.873])
    aft = np.array([-2.312,-2.303,-2.273,-2.252,-2.212,-2.155,-2.085,-2.031,-1.961,-1.853])
    shoulder = np.array([.438,.438,.438,.437,.431,.429,.425,.423,.421,.422])
    bottom = np.array([.229,.229,.229,.232,.233,.236,.242,.246,.253,.261])
    # Interpolation tables retain tangency at the transitions between the
    # rear-facing fascia and the much steeper outer return.
    sam = np.linspace(0,stations[-1],501)
    xs = pchip_eval(stations,aft,sam)
    highs = pchip_eval(stations,shoulder,sam)
    lows = pchip_eval(stations,bottom,sam)
    def facesurface(y,z):
        ay=abs(y)
        x=np.interp(ay,sam,xs)
        top=np.interp(ay,sam,highs)
        floor=np.interp(ay,sam,lows)
        v=np.clip((z-floor)/(top-floor),0,1)
        side_limit=.432-.038*v
        channel = _unit_ramp((side_limit-ay)/.026)*_unit_ramp((ay-.014)/.041)
        channel *= _unit_ramp((.90-v)/.14)*_unit_ramp((v-.07)/.11)
        # The ramps lean into the bumper most deeply along their upper edge.
        depth=channel*(.030+.062*v)
        lower_roll=.016*(1-_unit_ramp(v/.15))
        top_roll=.016*_unit_ramp((v-.84)/.16)
        point=np.array([x+depth+lower_roll+top_roll,y,z])
        if ay > .755:
            s=np.interp(z,traced[:,0],traced[:,1])-.003
            corner=skin(s,z)+NORMAL*.0012
            # Close the valance right against the inner rim of the outlet.
            reference=np.array([aft[-1]+lower_roll+top_roll,stations[-1]])
            point[:2]+=(np.array(corner[:2])-reference)*_unit_ramp((ay-.755)/(.873-.755))*[1,1 if y>0 else -1]
            # Follow the outside skin around the last turn. Interpolating the
            # very different face tangents here had recessed the graphite part
            # underneath the blue fascia short of the vertical outlet.
            here = Vector((point[0],abs(point[1]),z))
            along = here.dot(TANGENT)
            if along > s-.15:
                gap = (skin(along,z)-here).dot(NORMAL)
                reveal = max(0,gap+.0015)*_unit_ramp((along-s+.15)/.055)
                point[:2] += np.array((NORMAL.x,NORMAL.y*(1 if y>0 else -1)))*reveal
        return point
    yg=np.unique(np.r_[np.linspace(-.873,.873,129),[-.447,-.427,-.395,-.039,-.014,0,.014,.039,.395,.427,.447]])
    vg=np.unique(np.r_[np.linspace(0,1,23),.07,.125,.80,.89,.94])
    grid=[]
    for y in yg:
        high, low=np.interp(abs(y),sam,highs),np.interp(abs(y),sam,lows)
        row=[facesurface(y,low+(high-low)*v) for v in vg]
        # The lowest silhouette is a rolled underside below the visible
        # ramp. Its side sweep rises into the painted outer blades.
        drop=(.022+.009*_unit_ramp(abs(y)/.36))*(1-_unit_ramp((abs(y)-.70)/.17))
        row[:0]=[row[0]+[.068,0,-drop+.003],row[0]+[.023,0,-drop],
                 row[0]+[.011,0,-drop+.002]]
        row.append(row[-1]+[.036,0,-.003])
        grid.append(row)
    channel_mat = make_pbr('Graphite diffuser channel', '#343538', roughness=.64, specular_ior=.24)
    valance=create_quad_grid('TSC_Rear_Diffuser',grid,material=[trim,channel_mat],parent=parent)
    for face in valance.data.polygons:
        y,z=abs(face.center.y),face.center.z
        if .036 < y < .43-.037*(z-.23)/.205 and .246 < z < .409:
            face.material_index=1
    for side,tag in [(1,'L'),(-1,'R')]:
        # Photographed twin-lobed metal surround. Cut the black fascia all the
        # way through so the independent silencer's barrels are visible.
        cy,cz=.580,.332
        ring=[]
        for a in np.linspace(0,2*np.pi,64,endpoint=False):
            c,s=math.cos(a),math.sin(a)
            u=math.copysign(abs(c)**.53,c)
            v=math.copysign(abs(s)**.50,s)
            y=cy+.104*u+v*.007
            z=cz+.049*v*(1-.16*math.exp(-(u/.16)**2))+.003*u
            ring.append((y,z))
        cut=np.array(ring)
        _cut_opening(valance,cut,Vector((0,1,0)),side)
        bezel=[]; sleeve=[]
        for y,z in cut:
            p=facesurface(y,z)
            a=np.arctan2((z-cz)/.049,(y-cy)/.104)
            edge=np.array([0,np.cos(a),np.sin(a)])
            bezel.append([_mirrored(Vector(p+edge*expand+[d,0,0]),side)
                for expand,d in ((.005,.001),(.008,-.004),(.004,-.011),(-.002,-.013),(-.007,-.008),(-.008,.001))])
            sleeve.append([_mirrored(Vector(p+edge*expand+[d,0,0]),side)
                for expand,d in ((-.007,-.006),(-.007,.015),(-.014,.060))])
        create_quad_grid('TSC_Exhaust_Bezel_'+tag,bezel,material=mats['turbonite'],parent=parent,cyclic_u=True)
        create_quad_grid('TSC_Exhaust_Sleeve_'+tag,sleeve,material=throat,parent=parent,cyclic_u=True)
        _double_tailpipes(tag,side,facesurface)
        # Broad painted horizontal blade from the exhaust pocket around to
        # the outboard rim. Its dark underside follows the same sweep.
        blade=[]
        for y in np.linspace(.445,.874,48):
            low=np.interp(y,sam,lows)
            p=facesurface(y,low)
            p[2]-=.021*(1-_unit_ramp((y-.72)/.15))
            t=(y-.445)/(.874-.445)
            depth=.030+.012*np.sin(np.pi*t)
            blade.append([_mirrored(Vector(p+[dx,0,dz]),side) for dx,dz in
                          ((.041,.011),(.002,.003),(-depth,-.008),(-depth+.004,-.014),(.040,-.009))])
        create_quad_grid('TSC_Rear_Bumper_Lip_'+tag,blade,material=mats['paint'],parent=parent,
                         cyclic_v=True,cap_u0=True,cap_u1=True)
        # Three shallow impressed ribs in the outer wrap, as seen on 06/19.
        for idx,y0 in enumerate((.724,.774,.814)):
            grid=[]
            for v in np.linspace(0,1,10):
                y=y0+.007*(v-.5)**2
                z=.276+.103*v
                p=facesurface(y,z)
                end=np.sin(np.pi*v)**.4
                grid.append([_mirrored(Vector(p+[d,-e*end,0]),side) for d,e in
                             ((-.001,-.004),(-.0035,0),(-.001,.004))])
            create_quad_grid(f'TSC_Rear_Diffuser_Outer_Rib_{tag}_{idx+1}',grid,material=trim,parent=parent)
        # Reflector is a tapered lens with a black gasket. It follows the
        # painted surface above the diffuser almost all the way to the duct.
        strip=[]; gasket=[]
        for u in np.linspace(0,1,37):
            y=.575+.287*u
            z=.467+.005*np.cos(np.pi*u)-.006*u
            hit=body.ray_cast(Vector((-3.25,y,z)),Vector((1,0,0)),2.)[0]
            if hit is None:
                raise ValueError('Missing reflector substrate')
            h=.017*np.interp(u,[0,.04,.10,.90,.97,1],[.36,.9,1,1,.83,.30])
            for span,d,rows in [(h+.003,.008,gasket),(h,.012,strip)]:
                rows.append([_mirrored(Vector((hit.x-d+off,y,z+vz*span)),side)
                             for off,vz in ((.009,-1),(.001,-1),(0,0),(.001,1),(.009,1))])
        create_quad_grid('TSC_Rear_Bumper_Reflector_Gasket_'+tag,gasket,material=throat,parent=parent)
        create_quad_grid('TSC_Reflector_'+tag,strip,material=mats['reflector_red'],parent=parent)
