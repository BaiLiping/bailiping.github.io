"""
Precision math, spline, lofting, smoothing, and BVH utilities for Blender 5.2.
"""

import math
import numpy as np
import bpy
import bmesh
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree


# ---------------------------------------------------------------------------
# Monotonic Cubic Hermite (PCHIP) Interpolation & Smooth Blends
# ---------------------------------------------------------------------------
def pchip_eval(xs, ys, x):
    """Fritsch-Carlson monotonic cubic Hermite spline (overshoot-free automotive curves)."""
    xs = np.asarray(xs, dtype=np.float64)
    ys = np.asarray(ys, dtype=np.float64)
    scalar = np.isscalar(x)
    xq = np.atleast_1d(np.asarray(x, dtype=np.float64))
    n = len(xs)
    h = np.diff(xs)
    delta = np.diff(ys) / h
    d = np.zeros(n, dtype=np.float64)

    for i in range(1, n - 1):
        if delta[i - 1] * delta[i] > 0.0:
            w1 = 2.0 * h[i] + h[i - 1]
            w2 = h[i] + 2.0 * h[i - 1]
            d[i] = (w1 + w2) / (w1 / delta[i - 1] + w2 / delta[i])

    # Endpoints (shape-preserving one-sided 3-point formula)
    d0 = ((2.0 * h[0] + h[1]) * delta[0] - h[0] * delta[1]) / (h[0] + h[1])
    if d0 * delta[0] <= 0.0:
        d0 = 0.0
    elif delta[0] * delta[1] < 0.0 and abs(d0) > 3.0 * abs(delta[0]):
        d0 = 3.0 * delta[0]
    d[0] = d0

    dn = ((2.0 * h[-1] + h[-2]) * delta[-1] - h[-1] * delta[-2]) / (h[-1] + h[-2])
    if dn * delta[-1] <= 0.0:
        dn = 0.0
    elif delta[-1] * delta[-2] < 0.0 and abs(dn) > 3.0 * abs(delta[-1]):
        dn = 3.0 * delta[-1]
    d[-1] = dn

    xc = np.clip(xq, xs[0], xs[-1])
    idx = np.searchsorted(xs, xc, side="right") - 1
    idx = np.clip(idx, 0, n - 2)
    t = (xc - xs[idx]) / h[idx]
    t2 = t * t
    t3 = t2 * t
    h00 = 2.0 * t3 - 3.0 * t2 + 1.0
    h10 = t3 - 2.0 * t2 + t
    h01 = -2.0 * t3 + 3.0 * t2
    h11 = t3 - t2
    out = h00 * ys[idx] + h10 * h[idx] * d[idx] + h01 * ys[idx + 1] + h11 * h[idx] * d[idx + 1]
    return float(out[0]) if scalar else out


def smoothstep(edge0, edge1, x):
    t = np.clip((x - edge0) / (edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def smootherstep(edge0, edge1, x):
    t = np.clip((x - edge0) / (edge1 - edge0), 0.0, 1.0)
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)


def gauss(x, mu, sigma):
    return np.exp(-0.5 * ((x - mu) / sigma) ** 2)


# ---------------------------------------------------------------------------
# Blender Object, Empty & Mesh Creation Helpers
# ---------------------------------------------------------------------------
def ensure_empty(name: str, location=(0.0, 0.0, 0.0), parent=None, collection=None) -> bpy.types.Object:
    obj = bpy.data.objects.new(name, None)
    obj.empty_display_type = "PLAIN_AXES"
    obj.empty_display_size = 0.12
    obj.location = Vector(location)
    col = collection or bpy.context.scene.collection
    col.objects.link(obj)
    if parent is not None:
        obj.parent = parent
    return obj


def to_local_coords(verts, parent=None):
    """Convert world-space coordinates to parent-local coordinates (for child meshes under Pivot_*)."""
    arr = np.asarray(verts, dtype=np.float64)
    if parent is None:
        return arr
    # Compute cumulative parent world offset (assuming zero rotation / unit scale during build)
    offset = Vector((0.0, 0.0, 0.0))
    cur = parent
    while cur is not None:
        offset += cur.location
        cur = cur.parent
    return arr - np.array([offset.x, offset.y, offset.z], dtype=np.float64)


def create_mesh_object(
    name: str,
    verts,
    faces,
    material=None,
    parent=None,
    smooth: bool = True,
    recalc_normals: bool = True,
    weighted_normal: bool = False,
    world_coords: bool = True,
) -> bpy.types.Object:
    """Create a clean Blender mesh object, optionally converting world coords to parent local space."""
    pts = to_local_coords(verts, parent) if world_coords else np.asarray(verts, dtype=np.float64)
    me = bpy.data.meshes.new(name)
    me.from_pydata(pts.tolist(), [], faces)
    if material is not None:
        if isinstance(material, (list, tuple)):
            for m in material:
                me.materials.append(m)
        else:
            me.materials.append(material)
    me.update(calc_edges=True)

    if recalc_normals or smooth:
        bm = bmesh.new()
        bm.from_mesh(me)
        if recalc_normals:
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        if smooth:
            for f in bm.faces:
                f.smooth = True
        bm.to_mesh(me)
        bm.free()

    me.validate(verbose=False)
    ob = bpy.data.objects.new(name, me)
    bpy.context.scene.collection.objects.link(ob)
    if parent is not None:
        ob.parent = parent

    if weighted_normal:
        mod = ob.modifiers.new("WeightedNormal", "WEIGHTED_NORMAL")
        mod.keep_sharp = True

    return ob


def create_quad_grid(
    name: str,
    grid_xyz,
    material=None,
    parent=None,
    cyclic_u: bool = False,
    cyclic_v: bool = False,
    cap_u0: bool = False,
    cap_u1: bool = False,
    smooth: bool = True,
    recalc_normals: bool = True,
    world_coords: bool = True,
    flip_faces: bool = False,
) -> bpy.types.Object:
    """
    Create a clean quad mesh from a 3D array of shape (Nu, Nv, 3).
    Optionally closes cyclic U or V loops and adds end caps.
    """
    arr = np.asarray(grid_xyz, dtype=np.float64)
    nu, nv, _ = arr.shape
    verts = arr.reshape(-1, 3)

    faces = []
    u_lim = nu if cyclic_u else nu - 1
    v_lim = nv if cyclic_v else nv - 1
    for i in range(u_lim):
        i2 = (i + 1) % nu
        for j in range(v_lim):
            j2 = (j + 1) % nv
            a = i * nv + j
            b = i2 * nv + j
            c = i2 * nv + j2
            d = i * nv + j2
            if flip_faces:
                faces.append((a, d, c, b))
            else:
                faces.append((a, b, c, d))

    if cap_u0 and cyclic_v:
        # Cap start ring using centroid fan (avoids huge non-planar ngon)
        c0 = verts[:nv].mean(axis=0)
        c0_idx = len(verts)
        verts = np.vstack([verts, c0[None, :]])
        for j in range(nv):
            j2 = (j + 1) % nv
            faces.append((c0_idx, j2, j) if not flip_faces else (c0_idx, j, j2))

    if cap_u1 and cyclic_v:
        base = (nu - 1) * nv
        c1 = verts[base:base + nv].mean(axis=0)
        c1_idx = len(verts)
        verts = np.vstack([verts, c1[None, :]])
        for j in range(nv):
            j2 = (j + 1) % nv
            faces.append((c1_idx, base + j, base + j2) if not flip_faces else (c1_idx, base + j2, base + j))

    return create_mesh_object(
        name,
        verts,
        faces,
        material=material,
        parent=parent,
        smooth=smooth,
        recalc_normals=recalc_normals,
        world_coords=world_coords,
    )


def create_solidified_panel(
    name: str,
    grid_xyz,
    thickness: float,
    material=None,
    parent=None,
    offset: float = -1.0,
    smooth: bool = True,
    world_coords: bool = True,
) -> bpy.types.Object:
    """Create a smooth quad surface with Solidify thickness & subtle edge bevel for crisp automotive reflections."""
    ob = create_quad_grid(
        name, grid_xyz, material=material, parent=parent, smooth=smooth,
        recalc_normals=True, world_coords=world_coords,
    )
    if thickness > 0.0:
        sol = ob.modifiers.new("Solidify", "SOLIDIFY")
        sol.thickness = thickness
        sol.offset = offset
        sol.use_rim = True
        sol.use_even_offset = True
    return ob


def create_rounded_box(
    name: str,
    center,
    dimensions,
    material=None,
    parent=None,
    bevel_width: float = 0.008,
    bevel_segments: int = 3,
    rotation=(0.0, 0.0, 0.0),
    world_coords: bool = True,
) -> bpy.types.Object:
    """Create a smooth beveled box in world or local space."""
    loc = to_local_coords([center], parent)[0] if world_coords else np.asarray(center, dtype=np.float64)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    sx, sy, sz = dimensions
    for v in bm.verts:
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz
    if bevel_width > 0.0:
        bmesh.ops.bevel(
            bm,
            geom=list(bm.edges),
            offset=min(bevel_width, 0.45 * min(sx, sy, sz)),
            segments=bevel_segments,
            affect="EDGES",
            clamp_overlap=True,
        )
    for f in bm.faces:
        f.smooth = True
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    if material is not None:
        me.materials.append(material)
    ob = bpy.data.objects.new(name, me)
    ob.location = Vector(loc.tolist())
    ob.rotation_euler = rotation
    bpy.context.scene.collection.objects.link(ob)
    if parent is not None:
        ob.parent = parent
    return ob


def create_cylinder(
    name: str,
    center,
    radius: float,
    depth: float,
    axis: str = "Y",
    segments: int = 48,
    material=None,
    parent=None,
    bevel: float = 0.0,
    world_coords: bool = True,
) -> bpy.types.Object:
    """Create a smooth cylinder aligned along X, Y, or Z."""
    loc = to_local_coords([center], parent)[0] if world_coords else np.asarray(center, dtype=np.float64)
    bm = bmesh.new()
    bmesh.ops.create_cone(
        bm, cap_ends=True, cap_tris=False, segments=segments,
        radius1=radius, radius2=radius, depth=depth,
    )
    if axis == "Y":
        bmesh.ops.rotate(bm, cent=(0, 0, 0), matrix=Matrix.Rotation(math.pi / 2.0, 3, "X"), verts=bm.verts)
    elif axis == "X":
        bmesh.ops.rotate(bm, cent=(0, 0, 0), matrix=Matrix.Rotation(math.pi / 2.0, 3, "Y"), verts=bm.verts)
    if bevel > 0.0:
        cap_edges = [e for e in bm.edges if len(e.link_faces) == 2 and abs(e.link_faces[0].normal.dot(e.link_faces[1].normal)) < 0.5]
        if cap_edges:
            bmesh.ops.bevel(bm, geom=cap_edges, offset=bevel, segments=3, affect="EDGES", clamp_overlap=True)
    for f in bm.faces:
        f.smooth = True
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    if material is not None:
        me.materials.append(material)
    ob = bpy.data.objects.new(name, me)
    ob.location = Vector(loc.tolist())
    bpy.context.scene.collection.objects.link(ob)
    if parent is not None:
        ob.parent = parent
    return ob


def create_tube(
    name: str,
    points,
    radius: float,
    segments: int = 16,
    material=None,
    parent=None,
    cyclic: bool = False,
    world_coords: bool = True,
) -> bpy.types.Object:
    """Create a smooth cylindrical tube swept along a 3D polyline."""
    pts = to_local_coords(points, parent) if world_coords else np.asarray(points, dtype=np.float64)
    cu = bpy.data.curves.new(name, "CURVE")
    cu.dimensions = "3D"
    cu.resolution_u = 4
    cu.bevel_depth = radius
    cu.bevel_resolution = max(2, segments // 4)
    cu.use_fill_caps = not cyclic
    sp = cu.splines.new("POLY")
    sp.points.add(len(pts) - 1)
    for p, co in zip(sp.points, pts):
        p.co = (float(co[0]), float(co[1]), float(co[2]), 1.0)
    sp.use_cyclic_u = cyclic
    ob = bpy.data.objects.new(name, cu)
    bpy.context.scene.collection.objects.link(ob)
    if parent is not None:
        ob.parent = parent
    if material is not None:
        cu.materials.append(material)
    return ob


def build_bvh(obj: bpy.types.Object) -> BVHTree:
    """Build a world-space BVHTree from an evaluated Blender mesh object."""
    deps = bpy.context.evaluated_depsgraph_get()
    eo = obj.evaluated_get(deps)
    me = eo.to_mesh()
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.transform(obj.matrix_world)
    bvh = BVHTree.FromBMesh(bm)
    bm.free()
    eo.to_mesh_clear()
    return bvh
