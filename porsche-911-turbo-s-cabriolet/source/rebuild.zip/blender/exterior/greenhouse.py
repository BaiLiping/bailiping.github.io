"""Shared greenhouse targets for the raised soft top, side glass and windscreen.

All targets are in assembled (post silhouette-fit) Blender metres. They were measured on the
Porsche studio frames through their calibrated cameras (refine/tools/camgeo.py back-projection):
  - the side-window top line (canvas lower edge) in the left profile (view-04), back-projected
    onto the plane y = 0.60;
  - the windscreen header corners and roof edge in the overhead (view-42) and profile frames.
The silhouette fit (surface_fit.py) moves rest-space parts by a smooth field; helpers here
evaluate that field so that parts built in rest space land on these assembled targets.
"""
import math
import numpy as np

from .geom_utils import pchip_eval

# Side-window top line (x, z) in assembled metres, front (A-pillar top) to the quarter-glass tip.
WINDOW_X = [0.115, 0.010, -0.110, -0.240, -0.370, -0.500, -0.620, -0.750, -0.870, -1.000, -1.060]
WINDOW_Z = [1.178, 1.190, 1.197, 1.196, 1.189, 1.170, 1.120, 1.055, 0.990, 0.925, 0.895]
# Inward lean of the side glass (metres of |y| per metre of height), from the overhead roof edge
# (|y| ~0.595 at z ~1.19) and the belt (|y| ~0.75 at z ~0.86) in assembled space.
GLASS_LEAN = 0.46
# Split between the frameless door glass and the fixed quarter glass (assembled x at the belt
# and at the window line). The B-seal leans back toward the top, as in the profile frames.
GLASS_SPLIT_X = -0.50
GLASS_SPLIT_TOP_X = -0.58
WINDOW_TIP_X = -1.055


def window_z(x):
    """Assembled height of the side-window top line at assembled x; takes float/array, returns same."""
    xs, zs = WINDOW_X[::-1], WINDOW_Z[::-1]
    return pchip_eval(xs, zs, np.clip(x, xs[0], xs[-1]))


def field_displacement(points):
    """Silhouette-fit field displacement at rest points (n,3); returns (n,3) (zeros if no fit)."""
    from .surface_fit import FIT_PATH, displacement, field_weight
    pts = np.atleast_2d(np.asarray(points, dtype=np.float64))
    if not FIT_PATH.exists():
        return np.zeros_like(pts)
    field = np.load(FIT_PATH)['field']
    return displacement(pts, field) * field_weight(pts)


def fitted(points):
    """Rest points (n,3) -> assembled positions under the fit field; returns (n,3)."""
    pts = np.atleast_2d(np.asarray(points, dtype=np.float64))
    return pts + field_displacement(pts)


def rest_of(points, iterations=12):
    """Assembled points (n,3) -> rest points whose fitted position is the target; returns (n,3)."""
    target = np.atleast_2d(np.asarray(points, dtype=np.float64))
    rest = target.copy()
    for _ in range(iterations):
        rest += target - fitted(rest)
    return rest


def belt_rest(x, sign):
    """Rest-space glass foot on the door/quarter belt at rest x; takes float and side sign, returns (3,)."""
    from .body_shell import eval_y_belt, eval_z_shoulder
    return np.array([x, sign * (float(eval_y_belt(x)) - 0.016), float(eval_z_shoulder(x)) - 0.014])


def glass_lean(x):
    """Inward lean of the side glass at assembled x: the quarter glass leans in more toward the
    rear so the lower sail matches the rear (12) and rear three-quarter outlines; returns float."""
    return GLASS_LEAN + 0.24 * float(smooth01((GLASS_SPLIT_X - x) / 0.50))


def section_power(x):
    """Crown-to-edge exponent of the canvas cross-section at assembled x (larger = squarer)."""
    return 4.5 - 1.9 * float(smooth01((-0.45 - x) / 0.45))


def split_x(fraction):
    """Assembled x of the door/quarter split at a height fraction (0 belt, 1 top); returns float."""
    return GLASS_SPLIT_X + (GLASS_SPLIT_TOP_X - GLASS_SPLIT_X) * fraction


def glass_top(x, sign, foot):
    """Assembled side-glass top point above an assembled foot point; returns (3,) array.

    Takes: assembled x for the window line, side sign, assembled foot (3,) on the belt.
    The glass rises from the foot along a plane leaning GLASS_LEAN inward and stops 4 mm under
    the canvas edge, so the canvas laps the glass from outside.
    """
    z_top = max(float(window_z(x)) - 0.004, foot[2] + 0.012)
    y_top = abs(foot[1]) - (z_top - foot[2]) * glass_lean(x)
    return np.array([foot[0], sign * y_top, z_top])


def canvas_edge(x, sign):
    """Assembled canvas lower edge (window top line) at assembled x for one side; returns (3,).

    The canvas edge sits 7 mm outboard of the glass top and 4 mm above it.
    """
    foot = fitted(belt_rest(x, sign))[0]
    top = glass_top(x, sign, foot)
    return np.array([x, sign * (abs(top[1]) + 0.007), top[2] + 0.004])


def smooth01(t):
    """Smoothstep on [0,1]; takes float/array, returns same."""
    t = np.clip(t, 0.0, 1.0)
    return t * t * (3 - 2 * t)


def tip_weight(x):
    """The fit's smoothstep helper (identical to surface_fit.tip_weight); takes array, returns array."""
    return smooth01(x)


def windshield_assembled(rest):
    """Assembled positions of windscreen-family rest points, replicating surface_fit's terms.

    Takes: rest points (n,3) of the glass/frame/frit/wipers.
    Returns: (n,3) assembled points (field + forward bow of the screen base + scuttle rake).
    """
    p = np.atleast_2d(np.asarray(rest, dtype=np.float64))
    d = field_displacement(p)
    bow = np.clip(1 - (np.abs(p[:, 1]) / .738) ** 2, 0, 1)
    longitudinal = np.clip((p[:, 0] - .10) / .68, 0, 1)
    d[:, 0] += .184 * bow * longitudinal
    xx, yy, zz = (p + d).T
    centre = np.clip(1 - (np.abs(yy) / .74) ** 2, 0, 1)
    rake = tip_weight((xx - .08) / .83) * (1 - tip_weight((xx - .93) / .48))
    d[:, 2] -= .075 * centre * rake * tip_weight((zz - .54) / .16)
    return p + d


def a_pillar_assembled(sign, n=40):
    """Assembled points along the windscreen glass side edge, base (t=0) to header (t=1).

    Takes: side sign and sample count. Returns: (n,3) array.
    """
    from .optics_and_badges import eval_windshield_pt
    rest = np.array([eval_windshield_pt(t, sign * 1.0) for t in np.linspace(0, 1, n)])
    return windshield_assembled(rest)
