"""Apply a smooth symmetric displacement measured from the configurator silhouettes.

Coordinates and control displacements are in Blender metres. Cubic B-spline
weights keep the painted panels tangent across control-cell boundaries.
"""
import json
import os
from itertools import product
from pathlib import Path
import numpy as np

FIT_PATH = Path(__file__).with_name('silhouette_field.npz')
ORIGIN = np.array([-2.40, 0.0, 0.0])
SPACING = np.array([0.32, 0.24, 0.225])
SHAPE = (16, 6, 7)
# Parts placed in assembled coordinates by their builders; the fit must not move them again.
ASSEMBLED_PARTS = ('TSC_Glass_Door_', 'TSC_Glass_Quarter_')
# The canvas edge now follows the measured window line (greenhouse.py), so the old
# inward 'sail' pull of the canvas and side glass is retired.
SAIL_CORRECTION = False
# Map the lamp region with the affine part of the measured lamp-surface patch (see object_delta).
LAMP_AFFINE = not os.environ.get('TSC_LAMP_CUBIC')
# Length over which the windscreen-base bow and scuttle rake fade into the bonnet (m). The
# original 0.60 / 0.48 m compressed the rear of the bonnet by up to 46% and left humps.
APRON_RUN = float(os.environ.get('TSC_APRON_RUN', '1.05'))
RAKE_RUN = float(os.environ.get('TSC_RAKE_RUN', '0.85'))
# Lateral fade of the nose offset (|y| from, to). 0.37-0.565 m folded the fender below each lamp.
# Ahead of the front wheel the body is built to measured targets in assembled coordinates (body_shell:
# lamp frame from headlamp_fit.json, crown from the profile frames), so the lattice field dies out
# between these two x values. TSC_FIELD_FADE=off keeps the field everywhere.
_FADE = os.environ.get('TSC_FIELD_FADE', '0.95,1.30')
FIELD_FADE = () if _FADE == 'off' else tuple(float(v) for v in _FADE.split(','))
# The earlier front corrections stacked on the field (lamp-surface affine, crest shift, barrel lift,
# intake lift, lamp placement). TSC_LEGACY_FRONT=1 restores them, with the field, for comparison.
LEGACY_FRONT = bool(os.environ.get('TSC_LEGACY_FRONT'))
if LEGACY_FRONT:
    FIELD_FADE = ()
NOSE_FADE = tuple(float(v) for v in os.environ.get('TSC_NOSE_FADE', '0.30,0.72').split(','))


def spline_basis(points):
    local = np.array(points, dtype=np.float64)
    local[:, 1] = np.abs(local[:, 1])
    grid = (local - ORIGIN) / SPACING
    base = np.floor(grid).astype(int)
    f = grid - base
    weights = ((1-f)**3/6, (3*f**3-6*f**2+4)/6,
               (-3*f**3+3*f**2+3*f+1)/6, f**3/6)
    for dx, dy, dz in product(range(4), repeat=3):
        ix = np.clip(base[:, 0]+dx-1, 0, SHAPE[0]-1)
        iy = np.clip(base[:, 1]+dy-1, 0, SHAPE[1]-1)
        iz = np.clip(base[:, 2]+dz-1, 0, SHAPE[2]-1)
        idx = (ix*SHAPE[1]+iy)*SHAPE[2]+iz
        yield idx, weights[dx][:, 0]*weights[dy][:, 1]*weights[dz][:, 2]


def field_weight(points):
    """Share of the lattice field applied at rest points, per axis; returns (n,3).

    Ahead of FIELD_FADE the front is built to measured targets (body_shell), so there the field's x
    component is dropped everywhere, and all three components are dropped on the deck (lid, fender
    tops and bumper top inboard of the flank top), round the headlamps and on the nose. On the
    fender flanks round the front wheel the field's y and z still shape the straight-on outline.
    """
    pts = np.atleast_2d(points)
    w = np.ones((len(pts), 3))
    if not FIELD_FADE:
        return w
    from .body_shell import eval_y_belt, eval_z_shoulder, get_headlight_basis, HL_MAJOR_A, HL_MINOR_B
    def ease(t):
        t = np.clip(t, 0, 1)
        return t * t * (3 - 2 * t)
    x, y, z = pts.T
    ahead = ease((x - FIELD_FADE[0]) / (FIELD_FADE[1] - FIELD_FADE[0]))
    inboard = 1 - ease((np.abs(y) - (eval_y_belt(x) - 0.07)) / 0.06)
    z_floor = 0.55 + (eval_z_shoulder(x) - 0.60) * ease((x - 1.80) / 0.15)
    deck = inboard * ease((z - (z_floor - 0.04)) / 0.06)
    lamp = np.zeros(len(pts))
    for sign in (1.0, -1.0):
        c, n, u, v = (np.array(vec) for vec in get_headlight_basis(sign))
        d = pts - c
        r = np.hypot(d @ u / (HL_MAJOR_A * 0.945), d @ v / (HL_MINOR_B * 0.945))
        lamp = np.maximum(lamp, (1 - ease((r - 1.25) / 0.75)) * (np.abs(d @ n) < 0.25))
    # Ahead of the front wheel the bumper is built whole: the field's sideways push there sheared its
    # face against the deck above it into waves.
    nose = ease((x - 1.72) / 0.18)
    off = ahead * np.maximum(np.maximum(deck, lamp), nose)
    w[:, 0] = 1 - ahead
    w[:, 1] = 1 - off
    w[:, 2] = 1 - off
    return w


def displacement(points, field):
    d = np.zeros(np.shape(points), dtype=np.float64)
    for indices, weights in spline_basis(points):
        d += field[indices] * weights[:, None]
    d[:, 1] *= np.sign(points[:, 1])
    return d


def lamp_placements(objects):
    """Affine maps that carry each rest-space headlamp onto its photo-fitted outline.

    Takes: scene objects (the rest-space TSC_Headlight_Bezel_L/R give each lamp's rest centre).
    Returns: list of dicts {sign, c_rest, R_rest (3x3 cols u,v,n), a_rest, b_rest, M (3x3), c_fit};
    empty if headlamp_fit.json is missing. The fit (refine/tools/fit_lamp.py) is a planar ellipse
    matched to the lamp outline in eight calibrated frames (front, front three-quarters, overhead).
    """
    fit_path = FIT_PATH.with_name('headlamp_fit.json')
    if not LEGACY_FRONT or not fit_path.is_file():
        return []
    from .body_shell import get_headlight_basis, HL_MAJOR_A, HL_MINOR_B
    fit = json.loads(fit_path.read_text())
    out = []
    for sign, tag in ((1.0, 'L'), (-1.0, 'R')):
        bezel = next((o for o in objects if o.name == f'TSC_Headlight_Bezel_{tag}'), None)
        if bezel is None:
            continue
        if bezel.type == 'CURVE':
            co = np.array([list(q.co[:3]) for sp in bezel.data.splines for q in sp.points] +
                          [list(q.co) for sp in bezel.data.splines for q in sp.bezier_points])
        else:
            co = np.empty(len(bezel.data.vertices) * 3); bezel.data.vertices.foreach_get('co', co)
        mw = np.array(bezel.matrix_world)
        c_rest = (co.reshape(-1, 3) @ mw[:3, :3].T + mw[:3, 3]).mean(0)
        _, n_hl, u_hl, v_hl = get_headlight_basis(sign)
        R_rest = np.column_stack([np.array(u_hl), np.array(v_hl), np.array(n_hl)])
        mirror = np.array([1.0, sign, 1.0])
        c_fit = np.array(fit['center']) * mirror
        n_f = np.array(fit['normal']) * mirror
        u_f = np.array(fit['u_axis']) * mirror
        v_f = np.array(fit['v_axis']) * mirror
        if u_f @ R_rest[:, 0] < 0:
            u_f = -u_f
        if v_f @ R_rest[:, 1] < 0:
            v_f = -v_f
        a_rest, b_rest = HL_MAJOR_A * 0.945, HL_MINOR_B * 0.945
        F = np.column_stack([u_f * (fit['a'] / a_rest), v_f * (fit['b'] / b_rest), n_f])
        # The rest ring follows the curved fender; fit its depth as a quadratic in (u, v) so the
        # lamp can be flattened onto the planar photo outline.
        ring = (co.reshape(-1, 3) @ mw[:3, :3].T + mw[:3, 3] - c_rest) @ R_rest
        uu, vv = ring[:, 0] / a_rest, ring[:, 1] / b_rest
        # Harmonic basis (well conditioned on the ring, smooth inside it).
        A = np.column_stack([np.ones_like(uu), uu, vv, uu * uu - vv * vv, 2 * uu * vv])
        depth = np.linalg.lstsq(A, ring[:, 2], rcond=None)[0]
        out.append(dict(sign=sign, c_rest=c_rest, R_rest=R_rest, a_rest=a_rest, b_rest=b_rest,
                        F=F, c_fit=c_fit, depth=depth))
    return out


def object_delta(name, points, field, lamp, terminal=False, lamps=()):
    """Silhouette-fit displacement of one part, as a pure function of its world points.

    Takes: object name, (n,3) world points (metres), the fitted lattice field, the lamp-surface
    record (lamp_surface.json) and whether the part is an exhaust terminal (kept fixed).
    Returns: (n,3) displacement that apply_to_body adds to the points.
    """
    center, projection = np.array(lamp['center']), np.array(lamp['projection'])
    old_surface, target = np.array(lamp['oldSurface']), np.array(lamp['target'])
    delta = displacement(points, field) * field_weight(points)
    fitted = points + delta
    side = np.sign(fitted[:, 1])
    # Keep the published overhangs and maximum mirror span while fitting skin.
    def tip_weight(x):
        t = np.clip(x, 0, 1)
        return t*t*(3-2*t)
    delta[:,0] += .0097*tip_weight((fitted[:,0]-1.33)/.90)
    delta[:,0] -= .0126*tip_weight((-fitted[:,0]-1.35)/.947)
    delta[:,1] += side*.00545*tip_weight((abs(fitted[:,1])-.92)/.091)
    intake = tip_weight((points[:,0]-1.72)/.30)*tip_weight((.58-points[:,2])/.15)
    across = np.clip((np.abs(points[:,1])-.37)/.36,0,1)
    if LEGACY_FRONT:
        delta[:,2] += intake*tip_weight((points[:,2]-.14)/.20)*(.004+.043*across)
    # Fair the painted annulus into the measured lens plane. The bezel,
    # polycarbonate outer lens and internal optical pack keep their depths.
    mapped = points + delta
    near = (mapped[:,0]>1.34) & (np.abs(mapped[:,1])>.36) & (mapped[:,2]>.38)
    if LEGACY_FRONT and np.any(near):
        local = mapped[near].copy()
        half = np.sign(local[:,1])
        local[:,1] = np.abs(local[:,1])
        uv = (local-center)@projection
        r = np.linalg.norm(uv,axis=1)
        u,v = (uv/np.maximum(r[:,None],1.)).T
        poly=np.stack([np.ones(len(u)),u,v,u*u,u*v,v*v,u**3,u*u*v,u*v*v,v**3],axis=1)
        # Affine part of the old surface patch only: the full cubic sheared the round lamp
        # outline into a teardrop in the straight-on frame (35).
        old = poly[:, :3]@old_surface[:3] if LAMP_AFFINE else poly@old_surface
        desired = target[:3]+u[:,None]*target[3:6]+v[:,None]*target[6:9]
        depth=np.linalg.norm(local-old,axis=1)
        weight=tip_weight((2.25-r)/1.21)*tip_weight((.24-depth)/.17)
        shift=(desired-old)*weight[:,None]
        shift[:,1]*=half
        delta[near]+=shift
    if terminal:
        delta[:] = 0
    fitted = points + delta
    x,y,z = fitted.T
    lateral = np.abs(y)
    # The crest is independently located in the straight-on and overhead frames.
    # Carry its measured offset through the lid, shutline and adjacent fascia.
    nose = np.exp(-((x-1.93)/.239)**2) * (1-tip_weight((lateral-NOSE_FADE[0])/(NOSE_FADE[1]-NOSE_FADE[0])))
    nose *= tip_weight((z-.400)/.170) * (1-tip_weight((z-.76)/.15))
    if LEGACY_FRONT:
        delta[:,0] += .104*nose
        delta[:,2] -= .087*nose
    # The release photos locate the light bar, plate and exhaust bezels in
    # both rear and three-quarter views. Fair into the unaltered wing and arches.
    rear = tip_weight((-x-1.68)/.325) * (1-tip_weight((lateral-.76)/.145))
    shoulder = tip_weight((z-.135)/.121) * (1-tip_weight((z-.747)/.119))
    delta[:,2] += rear*shoulder*(.044+.012*np.exp(-((lateral-.41)/.21)**2))
    mid = rear * np.exp(-((z-.45)/.20)**2) * (1-tip_weight((-x-2.270)/.039))
    delta[:,0] += .018*mid
    tip = rear * np.exp(-((lateral-.515)/.177)**2) * np.exp(-((z-.276)/.123)**2)
    delta[:,1] += np.sign(y)*.072*tip
    # A deeper centre frame and rounded outer exhaust shoulders are visible
    # beneath the reflector blades, including on the opposite quarter.
    delta[:,0] += .037*tip
    # Views 10–16 show the canvas turning inwards above the beltline.
    # Carry that change through the adjoining side glass and quarter seals.
    if SAIL_CORRECTION and name.startswith(('TSC_Soft_Top_Fabric','TSC_Glass_Door_',
                            'TSC_Glass_Quarter_')):
        above_belt = tip_weight((z-.950)/.125)
        shoulder = .022*(1-tip_weight((z-1.185)/.105))
        # Round the shoulder into the crown along the top of each sail.
        shoulder += .024*np.exp(-((z-1.251)/.027)**2)
        sail = tip_weight((lateral-.38)/.17)*above_belt*shoulder
        sail *= tip_weight((-x-.17)/.19)*(1-tip_weight((-x-1.20)/.17))
        delta[:,1] -= np.sign(y)*sail
    # The 4K overhead and opposing profiles show a markedly bowed base
    # to the windscreen. Both ends die back into the A-pillars. Move the
    # cowl, wipers and aft bonnet lip together, with the header held fixed.
    # Keep the frunk rim below the bonnet shutline as the scuttle moves.
    apron = name.startswith(("TSC_Front_Lid","TSC_Frunk_Tub","TSC_Cowl_Plenum","TSC_Body_Shell"))
    windshield = name.startswith(("TSC_Glass_Windshield","TSC_Windshield","TSC_Wiper_"))
    if apron or windshield:
        xx,yy,zz=points.T
        bow=np.clip(1-(np.abs(yy)/.738)**2,0,1)
        if windshield:
            longitudinal=np.clip((xx-.10)/.68,0,1)
        else:
            longitudinal=tip_weight((xx-.38)/.39)*(1-tip_weight((xx-.78)/APRON_RUN))
            longitudinal*=tip_weight((zz-.61)/.17)
        delta[:,0]+=.184*bow*longitudinal
    # The silhouette fit must not pull a wheel opening away from a fixed
    # axle. Register the rear fender edge, rolled lip and liner together.
    arch_part = name == 'TSC_Body_Shell' or name.startswith((
        'TSC_Fender_Lip_R', 'TSC_Wheelhouse_Liner_R', 'TSC_Wheelhouse_Wall_R'))
    if arch_part:
        from . import config as cfg
        dx = points[:,0]-cfg.ARCH_REAR_X
        dz = points[:,2]-cfg.ARCH_REAR_Z
        radius = np.hypot(dx,dz)
        ux,uz = dx/np.maximum(radius,.001),dz/np.maximum(radius,.001)
        # Studio side views show a narrower clearance at the crown and
        # more lateral freedom as the cheek drops behind the tire.
        clearance_radius=.378+.016*ux**2
        weight=(1-tip_weight((radius-.405)/.043))*tip_weight((abs(points[:,1])-.43)/.09)
        shift=clearance_radius-cfg.ARCH_REAR_R
        wanted_x=cfg.X_REAR_AXLE+dx+shift*ux
        wanted_z=cfg.Z_WHEEL_REAR+dz+shift*uz
        delta[:,0]+=weight*(wanted_x-points[:,0]-delta[:,0])
        delta[:,2]+=weight*(wanted_z-points[:,2]-delta[:,2])
        # Rear and rear-three-quarter silhouettes place the shoulder
        # crest farther outboard as it runs away from the wheel opening.
        # Keep the crown clearance and the measured maximum body width.
        xf,yf,zf=(points+delta).T
        aft=tip_weight((xf+1.82)/.105)*(1-tip_weight((xf+1.41)/.17))
        flank=tip_weight((abs(yf)-.80)/.085)
        shoulder=.016*np.exp(-((zf-.727)/.087)**2)+.010*np.exp(-((zf-.640)/.115)**2)
        cheek=.013*np.exp(-((zf-.237)/.077)**2)
        widening=np.minimum((shoulder+cheek)*aft*flank,np.maximum(.951-abs(yf),0.))
        delta[:,1]+=np.sign(yf)*widening
    # Fit the windscreen rake in the side views without losing its bowed
    # plan outline. The dashboard and wipers follow the adjusted scuttle.
    cowl_parts=("TSC_Glass_Windshield","TSC_Windshield","TSC_Wiper_",
                "TSC_Dash_Upper","TSC_Dash_Top","TSC_Dash_Brow","TSC_Dash_CenterSpeaker",
                "TSC_SportChrono","TSC_Dash_Defrost","TSC_Cowl_Plenum",
                "TSC_Front_Lid","TSC_Frunk_Tub","TSC_Body_Shell")
    xx,yy,zz=(points+delta).T
    if name.startswith(cowl_parts):
        centre=np.clip(1-(np.abs(yy)/.74)**2,0,1)
        rake=tip_weight((xx-.08)/.83)*(1-tip_weight((xx-.93)/RAKE_RUN))
        delta[:,2]-=.075*centre*rake*tip_weight((zz-.54)/.16)
    if name.startswith(("TSC_Body_Shell","TSC_Front_Lid","TSC_Headlight",
                            "TSC_Fender","TSC_SideMarker")):
        barrel=np.exp(-((xx-1.83)/.28)**2)*tip_weight((np.abs(yy)-.28)/.26)
        if LEGACY_FRONT:
            delta[:,2]+=.040*barrel*tip_weight((zz-.37)/.25)
    # Carry each headlamp, and the paint ring around its opening, onto the photo-fitted outline
    # with one affine map; blend back to the silhouette fit within 1.9 lamp radii.
    for L in lamps:
        local = (points - L['c_rest']) @ L['R_rest']
        r = np.hypot(local[:, 0] / L['a_rest'], local[:, 1] / L['b_rest'])
        if name.startswith('TSC_Headlight_'):
            w = (np.sign(points[:, 1]) == L['sign']).astype(float)
        elif name.startswith('TSC_SideMarker'):
            continue
        else:
            w = 1 - tip_weight((r - 1.04) / 0.86)
            w *= 1 - tip_weight((np.abs(local[:, 2]) - 0.10) / 0.12)
            w *= (np.sign(points[:, 1]) == L['sign'])
        if not np.any(w > 0):
            continue
        uu = local[:, 0] / L['a_rest']; vv = local[:, 1] / L['b_rest']
        # Outside the ring use the ring depth at the same angle (radial projection onto it).
        rr = np.maximum(np.hypot(uu, vv), 1.0)
        cu, cv = uu / rr, vv / rr
        ring_depth = np.column_stack([np.ones_like(cu), cu, cv, cu * cu - cv * cv, 2 * cu * cv]) @ L['depth']
        flat = local.copy()
        if name.startswith('TSC_Headlight_'):
            flat[:, 2] -= ring_depth
        else:
            # Inboard the paint meets the lamp on its plane; outboard the fender keeps its own
            # depth and hoods the lamp, which is why the side frames (03, 04) show only a sliver.
            flat[:, 2] -= ring_depth * (1 - tip_weight(vv / 0.6))
        placed = L['c_fit'] + flat @ L['F'].T
        delta = delta * (1 - w[:, None]) + (placed - points) * w[:, None]
    return delta

_BODY_INPUTS = {}


def body_delta(points):
    """Displacement the build gives the painted body (TSC_Body_Shell) at rest points.

    Takes: (n,3) rest points. Returns: (n,3), zero when the fit is switched off or missing.
    """
    pts = np.atleast_2d(np.asarray(points, dtype=np.float64))
    if os.environ.get('TSC_NO_FIT') or not FIT_PATH.is_file():
        return np.zeros_like(pts)
    if not _BODY_INPUTS:
        _BODY_INPUTS['field'] = np.load(FIT_PATH)['field']
        _BODY_INPUTS['lamp'] = json.loads(FIT_PATH.with_name('lamp_surface.json').read_text())
    return object_delta('TSC_Body_Shell', pts, _BODY_INPUTS['field'], _BODY_INPUTS['lamp'])


def body_rest_of(points, iterations=8):
    """Assembled body points (n,3) -> rest points the build carries onto them; returns (n,3)."""
    target = np.atleast_2d(np.asarray(points, dtype=np.float64))
    rest = target.copy()
    for _ in range(iterations):
        rest += target - (rest + body_delta(rest))
    return rest


def apply_to_body(objects):
    if not FIT_PATH.is_file():
        return
    field = np.load(FIT_PATH)['field']
    lamp = json.loads(FIT_PATH.with_name('lamp_surface.json').read_text())
    center, projection = np.array(lamp['center']), np.array(lamp['projection'])
    old_surface, target = np.array(lamp['oldSurface']), np.array(lamp['target'])
    lamps = lamp_placements(list(objects))

    for obj in objects:
        if obj.type not in ('MESH','CURVE'):
            continue
        parent = obj.parent
        while parent and parent.name not in ('Pivot_Body_Assembly', 'Pivot_Interior_Cabin'):
            parent = parent.parent
        terminal = obj.name.startswith("TSC_Exhaust_Tip_")
        if not parent and not terminal:
            continue
        # Built directly in assembled coordinates from the photo targets (greenhouse.py).
        if obj.name.startswith(ASSEMBLED_PARTS):
            continue
        # The pressure skin and its fittings move together in their assembled
        # coordinates. Preserve rigid wheel/axle datums and mechanical assemblies.
        mesh = obj.data
        if mesh.users > 1:
            obj.data = mesh = mesh.copy()
        if obj.type == 'CURVE':
            elements = []
            for spline in mesh.splines:
                elements.extend((v, 'co') for v in spline.points)
                for v in spline.bezier_points:
                    elements.extend((v, name) for name in ('co', 'handle_left', 'handle_right'))
            if not elements:
                continue
            coords = np.array([getattr(v, key)[:3] for v,key in elements], dtype=np.float64)
        else:
            coords = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
            mesh.vertices.foreach_get('co', coords)
            coords = coords.reshape(-1, 3)
        transform = np.array(obj.matrix_world)
        points = coords @ transform[:3, :3].T + transform[:3, 3]
        delta = object_delta(obj.name, points, field, lamp, terminal, lamps)
        coords += delta @ np.linalg.inv(transform[:3, :3]).T
        if obj.type == 'CURVE':
            for (v,key), xyz in zip(elements, coords):
                vec = getattr(v,key)
                vec[:3] = xyz
        else:
            mesh.vertices.foreach_set('co', coords.ravel())
            mesh.update()
