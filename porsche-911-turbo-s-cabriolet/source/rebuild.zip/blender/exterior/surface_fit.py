"""Apply a smooth symmetric displacement measured from the configurator silhouettes.

Coordinates and control displacements are in Blender metres. Cubic B-spline
weights keep the painted panels tangent across control-cell boundaries.
"""
import json
from itertools import product
from pathlib import Path
import numpy as np

FIT_PATH = Path(__file__).with_name('silhouette_field.npz')
ORIGIN = np.array([-2.40, 0.0, 0.0])
SPACING = np.array([0.32, 0.24, 0.225])
SHAPE = (16, 6, 7)


def spline_basis(points):
    local = np.array(points, dtype=np.float64)
    local[:, 1] = np.abs(local[:, 1])
    grid = (local - ORIGIN) / SPACING
    base = np.floor(grid).astype(int)
    f = grid - base
    weights = ((1-f)**3/6, (3*f**3-6*f**2+4)/6,
               (-3*f**3+3*f**2+3*f+1)/6, f**3/6)
    for dx, dy, dz in product(range(4), repeat=3):
        ix = np.clip(base[:, 0]+dx-1, 0, SHAPE[0]-1)
        iy = np.clip(base[:, 1]+dy-1, 0, SHAPE[1]-1)
        iz = np.clip(base[:, 2]+dz-1, 0, SHAPE[2]-1)
        idx = (ix*SHAPE[1]+iy)*SHAPE[2]+iz
        yield idx, weights[dx][:, 0]*weights[dy][:, 1]*weights[dz][:, 2]


def displacement(points, field):
    d = np.zeros(np.shape(points), dtype=np.float64)
    for indices, weights in spline_basis(points):
        d += field[indices] * weights[:, None]
    d[:, 1] *= np.sign(points[:, 1])
    return d


def apply_to_body(objects):
    if not FIT_PATH.is_file():
        return
    field = np.load(FIT_PATH)['field']
    lamp = json.loads(FIT_PATH.with_name('lamp_surface.json').read_text())
    center, projection = np.array(lamp['center']), np.array(lamp['projection'])
    old_surface, target = np.array(lamp['oldSurface']), np.array(lamp['target'])

    for obj in objects:
        if obj.type not in ('MESH','CURVE'):
            continue
        parent = obj.parent
        while parent and parent.name not in ('Pivot_Body_Assembly', 'Pivot_Interior_Cabin'):
            parent = parent.parent
        terminal = obj.name.startswith("TSC_Exhaust_Tip_")
        if not parent and not terminal:
            continue
        # The pressure skin and its fittings move together in their assembled
        # coordinates. Preserve rigid wheel/axle datums and mechanical assemblies.
        mesh = obj.data
        if mesh.users > 1:
            obj.data = mesh = mesh.copy()
        if obj.type == 'CURVE':
            elements = []
            for spline in mesh.splines:
                elements.extend((v, 'co') for v in spline.points)
                for v in spline.bezier_points:
                    elements.extend((v, name) for name in ('co', 'handle_left', 'handle_right'))
            if not elements:
                continue
            coords = np.array([getattr(v, key)[:3] for v,key in elements], dtype=np.float64)
        else:
            coords = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
            mesh.vertices.foreach_get('co', coords)
            coords = coords.reshape(-1, 3)
        transform = np.array(obj.matrix_world)
        points = coords @ transform[:3, :3].T + transform[:3, 3]
        delta = displacement(points, field)
        fitted = points + delta
        side = np.sign(fitted[:, 1])
        # Keep the published overhangs and maximum mirror span while fitting skin.
        def tip_weight(x):
            t = np.clip(x, 0, 1)
            return t*t*(3-2*t)
        delta[:,0] += .0097*tip_weight((fitted[:,0]-1.33)/.90)
        delta[:,0] -= .0126*tip_weight((-fitted[:,0]-1.35)/.947)
        delta[:,1] += side*.00545*tip_weight((abs(fitted[:,1])-.92)/.091)
        intake = tip_weight((points[:,0]-1.72)/.30)*tip_weight((.58-points[:,2])/.15)
        across = np.clip((np.abs(points[:,1])-.37)/.36,0,1)
        delta[:,2] += intake*tip_weight((points[:,2]-.14)/.20)*(.004+.043*across)
        # Fair the painted annulus into the measured lens plane. The bezel,
        # polycarbonate outer lens and internal optical pack keep their depths.
        mapped = points + delta
        near = (mapped[:,0]>1.34) & (np.abs(mapped[:,1])>.36) & (mapped[:,2]>.38)
        if np.any(near):
            local = mapped[near].copy()
            half = np.sign(local[:,1])
            local[:,1] = np.abs(local[:,1])
            uv = (local-center)@projection
            r = np.linalg.norm(uv,axis=1)
            u,v = (uv/np.maximum(r[:,None],1.)).T
            poly=np.stack([np.ones(len(u)),u,v,u*u,u*v,v*v,u**3,u*u*v,u*v*v,v**3],axis=1)
            old = poly@old_surface
            desired = target[:3]+u[:,None]*target[3:6]+v[:,None]*target[6:9]
            depth=np.linalg.norm(local-old,axis=1)
            weight=tip_weight((2.25-r)/1.21)*tip_weight((.24-depth)/.17)
            shift=(desired-old)*weight[:,None]
            shift[:,1]*=half
            delta[near]+=shift
        if terminal:
            delta[:] = 0
        fitted = points + delta
        x,y,z = fitted.T
        lateral = np.abs(y)
        # The crest is independently located in the straight-on and overhead frames.
        # Carry its measured offset through the lid, shutline and adjacent fascia.
        nose = np.exp(-((x-1.93)/.239)**2) * (1-tip_weight((lateral-.37)/.195))
        nose *= tip_weight((z-.400)/.170) * (1-tip_weight((z-.76)/.15))
        delta[:,0] += .104*nose
        delta[:,2] -= .087*nose
        # The release photos locate the light bar, plate and exhaust bezels in
        # both rear and three-quarter views. Fair into the unaltered wing and arches.
        rear = tip_weight((-x-1.68)/.325) * (1-tip_weight((lateral-.76)/.145))
        shoulder = tip_weight((z-.135)/.121) * (1-tip_weight((z-.747)/.119))
        delta[:,2] += rear*shoulder*(.044+.012*np.exp(-((lateral-.41)/.21)**2))
        mid = rear * np.exp(-((z-.45)/.20)**2) * (1-tip_weight((-x-2.270)/.039))
        delta[:,0] += .018*mid
        tip = rear * np.exp(-((lateral-.515)/.177)**2) * np.exp(-((z-.276)/.123)**2)
        delta[:,1] += np.sign(y)*.072*tip
        # A deeper centre frame and rounded outer exhaust shoulders are visible
        # beneath the reflector blades, including on the opposite quarter.
        delta[:,0] += .037*tip
        # Views 10–16 show the canvas turning inwards above the beltline.
        # Carry that change through the adjoining side glass and quarter seals.
        if obj.name.startswith(('TSC_Soft_Top_Fabric','TSC_Glass_Door_',
                                'TSC_Glass_Quarter_')):
            above_belt = tip_weight((z-.950)/.125)
            shoulder = .022*(1-tip_weight((z-1.185)/.105))
            # Round the shoulder into the crown along the top of each sail.
            shoulder += .024*np.exp(-((z-1.251)/.027)**2)
            sail = tip_weight((lateral-.38)/.17)*above_belt*shoulder
            sail *= tip_weight((-x-.17)/.19)*(1-tip_weight((-x-1.20)/.17))
            delta[:,1] -= np.sign(y)*sail
        # The 4K overhead and opposing profiles show a markedly bowed base
        # to the windscreen. Both ends die back into the A-pillars. Move the
        # cowl, wipers and aft bonnet lip together, with the header held fixed.
        # Keep the frunk rim below the bonnet shutline as the scuttle moves.
        apron = obj.name.startswith(("TSC_Front_Lid","TSC_Frunk_Tub","TSC_Cowl_Plenum","TSC_Body_Shell"))
        windshield = obj.name.startswith(("TSC_Glass_Windshield","TSC_Windshield","TSC_Wiper_"))
        if apron or windshield:
            xx,yy,zz=points.T
            bow=np.clip(1-(np.abs(yy)/.738)**2,0,1)
            if windshield:
                longitudinal=np.clip((xx-.10)/.68,0,1)
            else:
                longitudinal=tip_weight((xx-.38)/.39)*(1-tip_weight((xx-.78)/.60))
                longitudinal*=tip_weight((zz-.61)/.17)
            delta[:,0]+=.184*bow*longitudinal
        # The silhouette fit must not pull a wheel opening away from a fixed
        # axle. Register the rear fender edge, rolled lip and liner together.
        arch_part = obj.name == 'TSC_Body_Shell' or obj.name.startswith((
            'TSC_Fender_Lip_R', 'TSC_Wheelhouse_Liner_R', 'TSC_Wheelhouse_Wall_R'))
        if arch_part:
            from . import config as cfg
            dx = points[:,0]-cfg.ARCH_REAR_X
            dz = points[:,2]-cfg.ARCH_REAR_Z
            radius = np.hypot(dx,dz)
            ux,uz = dx/np.maximum(radius,.001),dz/np.maximum(radius,.001)
            # Studio side views show a narrower clearance at the crown and
            # more lateral freedom as the cheek drops behind the tire.
            clearance_radius=.378+.016*ux**2
            weight=(1-tip_weight((radius-.405)/.043))*tip_weight((abs(points[:,1])-.43)/.09)
            shift=clearance_radius-cfg.ARCH_REAR_R
            wanted_x=cfg.X_REAR_AXLE+dx+shift*ux
            wanted_z=cfg.Z_WHEEL_REAR+dz+shift*uz
            delta[:,0]+=weight*(wanted_x-points[:,0]-delta[:,0])
            delta[:,2]+=weight*(wanted_z-points[:,2]-delta[:,2])
            # Rear and rear-three-quarter silhouettes place the shoulder
            # crest farther outboard as it runs away from the wheel opening.
            # Keep the crown clearance and the measured maximum body width.
            xf,yf,zf=(points+delta).T
            aft=tip_weight((xf+1.82)/.105)*(1-tip_weight((xf+1.41)/.17))
            flank=tip_weight((abs(yf)-.80)/.085)
            shoulder=.016*np.exp(-((zf-.727)/.087)**2)+.010*np.exp(-((zf-.640)/.115)**2)
            cheek=.013*np.exp(-((zf-.237)/.077)**2)
            widening=np.minimum((shoulder+cheek)*aft*flank,np.maximum(.951-abs(yf),0.))
            delta[:,1]+=np.sign(yf)*widening
        # Fit the windscreen rake in the side views without losing its bowed
        # plan outline. The dashboard and wipers follow the adjusted scuttle.
        cowl_parts=("TSC_Glass_Windshield","TSC_Windshield","TSC_Wiper_",
                    "TSC_Dash_Upper","TSC_Dash_Top","TSC_Dash_CenterSpeaker",
                    "TSC_SportChrono","TSC_Dash_Defrost","TSC_Cowl_Plenum",
                    "TSC_Front_Lid","TSC_Frunk_Tub","TSC_Body_Shell")
        xx,yy,zz=(points+delta).T
        if obj.name.startswith(cowl_parts):
            centre=np.clip(1-(np.abs(yy)/.74)**2,0,1)
            rake=tip_weight((xx-.08)/.83)*(1-tip_weight((xx-.93)/.48))
            delta[:,2]-=.075*centre*rake*tip_weight((zz-.54)/.16)
        if obj.name.startswith(("TSC_Body_Shell","TSC_Front_Lid","TSC_Headlight",
                                "TSC_Fender","TSC_SideMarker")):
            barrel=np.exp(-((xx-1.83)/.28)**2)*tip_weight((np.abs(yy)-.28)/.26)
            delta[:,2]+=.040*barrel*tip_weight((zz-.37)/.25)
        coords += delta @ np.linalg.inv(transform[:3, :3]).T
        if obj.type == 'CURVE':
            for (v,key), xyz in zip(elements, coords):
                vec = getattr(v,key)
                vec[:3] = xyz
        else:
            mesh.vertices.foreach_set('co', coords.ravel())
            mesh.update()
