"""
Official dimensional datums and factory-measured parametric curves for the
2026 Porsche 911 Turbo S Cabriolet (992.2, model code 992652) — T-Hybrid.

Every spine curve below is directly calibrated against:
  - Official Porsche EU Technical Data PDF (MY T 10/2025)
  - Official Porsche 5000x1485 orthographic side view (`side view.png`)
  - Official Porsche vector top view (`top view.svg`)
  - 4K studio photographs (04 left, 13 rear, 27 right, 36 front, 42 overhead)

Coordinate convention inside Blender (1:1 real-world METERS, Z-up right-handed):
  +X : Forward (front bumper nose = +2.241 m)
  -X : Rearward (rear bumper tail = -2.310 m)
  +Y : Car's LEFT (driver side, LHD)
  -Y : Car's RIGHT (passenger / fuel-filler side)
  +Z : Upward from ground plane (Z = 0.0 is tire contact patch)
"""

import numpy as np

EXPORT_SCALE = 1000.0 / 18.0  # 55.55555555555556 (1:18 mm GT3 standard)

# Official Factory Dimensions (m)
LENGTH = 4.551
WIDTH_BODY = 1.900
WIDTH_MIRRORS = 2.033
HEIGHT = 1.304
WHEELBASE = 2.450

TRACK_FRONT = 1.583
TRACK_REAR = 1.588

X_FRONT_AXLE = +WHEELBASE * 0.5       # +1.2250 m
X_REAR_AXLE = -WHEELBASE * 0.5        # -1.2250 m

FRONT_OVERHANG = 1.016
REAR_OVERHANG = 1.085

X_NOSE = X_FRONT_AXLE + FRONT_OVERHANG   # +2.2410 m
X_TAIL = X_REAR_AXLE - REAR_OVERHANG     # -2.3100 m

HALF_WIDTH_MAX = WIDTH_BODY * 0.5        # 0.9500 m
HALF_WIDTH_MIRRORS = WIDTH_MIRRORS * 0.5 # 1.0165 m

# Wheels, Tires & PCCB Brakes (255/35 ZR20 F, 325/30 ZR21 R)
TIRE_FRONT_WIDTH = 0.255
RIM_FRONT_DIAM = 20.0 * 0.0254           # 0.5080 m
TIRE_FRONT_OD = RIM_FRONT_DIAM + 2.0 * (TIRE_FRONT_WIDTH * 0.35)  # 0.6865 m
TIRE_FRONT_R = TIRE_FRONT_OD * 0.5       # 0.34325 m

TIRE_REAR_WIDTH = 0.325
RIM_REAR_DIAM = 21.0 * 0.0254            # 0.5334 m
TIRE_REAR_OD = RIM_REAR_DIAM + 2.0 * (TIRE_REAR_WIDTH * 0.30)     # 0.7284 m
TIRE_REAR_R = TIRE_REAR_OD * 0.5         # 0.36420 m

Y_WHEEL_FRONT = TRACK_FRONT * 0.5        # 0.7915 m
Y_WHEEL_REAR = TRACK_REAR * 0.5          # 0.7940 m

# Wheel hub Z == tire radius so circular spinning tires stay mathematically tangent to Z = 0
Z_WHEEL_FRONT = TIRE_FRONT_R             # 0.34325 m
Z_WHEEL_REAR = TIRE_REAR_R               # 0.36420 m

# Wheel-arch cutout geometry (tight athletic PASM Turbo S stance)
ARCH_FRONT_X = X_FRONT_AXLE - 0.003      # +1.222 m
ARCH_FRONT_Z = Z_WHEEL_FRONT + 0.002     # 0.345 m
ARCH_FRONT_R = 0.376

ARCH_REAR_X = X_REAR_AXLE + 0.003        # -1.222 m
ARCH_REAR_Z = Z_WHEEL_REAR + 0.002       # 0.366 m
ARCH_REAR_R = 0.398

ROTOR_FRONT_R = 0.210                    # 420 mm PCCB
ROTOR_REAR_R = 0.205                     # 410 mm PCCB

# Key Vertical & Longitudinal Styling Datums (m)
Z_GROUND = 0.000
Z_UNDERBODY = 0.125
Z_ROCKER_BOTTOM = 0.130
Z_CHIN_BOTTOM = 0.120

# Greenhouse & Convertible Soft-Top Stations (calibrated to 4K overlays 04/06/12/35/44 + interior header!)
X_COWL_CENTER = +0.775
X_COWL_SIDE = +0.648
Z_COWL_CENTER = 0.848
Z_COWL_SIDE = 0.860

# Header measured in the overhead (42) and profile (04) frames: corners at x=0.11, |y|=0.60, z=1.18
# after the silhouette fit; rest-space values below include the fit's offsets.
X_HEADER_CENTER = +0.140
X_HEADER_SIDE = +0.115
Z_HEADER_CENTER = 1.246
Z_HEADER_SIDE = 1.1805

X_ROOF_PEAK = -0.250
Z_ROOF_PEAK = HEIGHT                     # 1.304 m exact!
X_SOFT_TOP_REAR = -1.440
Z_SOFT_TOP_REAR = 1.012

# Closures & Aero Stations
X_HOOD_REAR = +0.785
# Front lid outline in assembled coordinates, measured on the overhead (42) and straight-on (35)
# frames (tools/measure_lid.py): side shut line HOOD_SIDE_*, front edge bowed forward as
# x = X_HOOD_FRONT - HOOD_FRONT_BOW * y^2, rounded corners. body_shell carries it to rest space.
X_HOOD_FRONT = +2.133
HOOD_FRONT_BOW = 0.32
HOOD_SIDE_X = [1.000, 1.070, 1.200, 1.315, 1.433, 1.548, 1.657, 1.777, 1.860, 1.977, 2.100]
HOOD_SIDE_Y = [0.660, 0.646, 0.620, 0.594, 0.5665, 0.537, 0.508, 0.474, 0.4325, 0.403, 0.375]
# Lid edge height along the shut line (triangulated, rms 5 mm), continued ahead of the lid as the
# bumper-top centreline; and the lid's dome above that edge (dished where the windscreen base sits low).
LID_EDGE_X = [1.000, 1.100, 1.200, 1.300, 1.400, 1.500, 1.600, 1.700, 1.800, 1.850, 1.900, 1.950, 2.000, 2.050, 2.100, 2.133, 2.180, 2.240, 2.300]
LID_EDGE_Z = [0.852, 0.846, 0.835, 0.819, 0.798, 0.771, 0.738, 0.700, 0.655, 0.630, 0.604, 0.578, 0.553, 0.530, 0.513, 0.505, 0.475, 0.438, 0.425]
LID_DOME_X = [1.000, 1.100, 1.200, 1.300, 1.400, 1.500, 1.850, 2.000, 2.100]
LID_DOME_Z = [-0.046, -0.044, -0.028, -0.004, 0.015, 0.022, 0.022, 0.010, 0.000]
# Front-lid half-width (rest metres) inverted from the overhead photo's shut lines (view-42 raycast
# onto the body, then through surface_fit.object_delta): a strong forward taper from the cowl.
HOOD_HW_X = [0.700, 0.7315, 0.922, 1.104, 1.261, 1.404, 1.553, 1.688, 1.794, 1.861, 1.928, 1.972]
HOOD_HW_Y = [0.703, 0.7025, 0.6885, 0.6535, 0.6296, 0.5949, 0.5422, 0.5149, 0.4699, 0.4184, 0.3904, 0.3643]
HOOD_CORNER_R = 0.035                    # rounded front corners of the lid (smooth-minimum width)
X_DOOR_FRONT = +0.635
X_DOOR_REAR = -0.490

X_GRILLE_FRONT = -1.455
X_GRILLE_REAR = -1.875

X_TAILLIGHT_CENTER = -2.248
Z_TAILLIGHT_CENTER = 0.758               # Verified against 4K rear (13) & side view.png!

# Exhaust bezel centers — tucked cleanly inside the tapered rear bumper corner (ZERO protrusion!)
EXHAUST_CUTOUT_X = -2.195
EXHAUST_CUTOUT_Y = 0.515
EXHAUST_CUTOUT_Z = 0.298
EXHAUST_CUTOUT_W = 0.245
EXHAUST_CUTOUT_H = 0.102

PIVOT_LOCATIONS = {
    "Pivot_Body_Assembly":     (0.0, 0.0, 0.0),
    "Pivot_Door_L":            (+0.630, +0.828, 0.540),
    "Pivot_Door_R":            (+0.630, -0.828, 0.540),
    "Pivot_Front_Lid":         (+0.798,  0.000, 0.838),
    "Pivot_Fuel_Flap":         (+1.014, -0.875, 0.779),
    "Pivot_Fuel_Cap":          (+0.918, -0.840, 0.779),
    "Pivot_Soft_Top":          (-1.050,  0.000, 0.950),
    "Pivot_Soft_Top_Stowed":   (-1.050,  0.000, 0.950),
    "Pivot_Rear_Lid":          (-1.440,  0.000, 0.985),
    "Pivot_Active_Wing":       (-1.950,  0.000, 0.900),
    "Pivot_Drivetrain_Chassis":(0.0, 0.0, 0.0),
    "Pivot_Flat6_Engine":      (0.0, 0.0, 0.0),
    "Pivot_Exhaust_System":    (0.0, 0.0, 0.0),
    "Pivot_Interior_Cabin":    (0.0, 0.0, 0.0),
    "Pivot_Corner_FL":         (X_FRONT_AXLE, +Y_WHEEL_FRONT, Z_WHEEL_FRONT),
    "Pivot_Corner_FR":         (X_FRONT_AXLE, -Y_WHEEL_FRONT, Z_WHEEL_FRONT),
    "Pivot_Corner_RL":         (X_REAR_AXLE,  +Y_WHEEL_REAR,  Z_WHEEL_REAR),
    "Pivot_Corner_RR":         (X_REAR_AXLE,  -Y_WHEEL_REAR,  Z_WHEEL_REAR),
}


def as_shared_dict() -> dict:
    return {
        "EXPORT_SCALE": EXPORT_SCALE,
        "LENGTH": LENGTH,
        "WIDTH_BODY": WIDTH_BODY,
        "WIDTH_MIRRORS": WIDTH_MIRRORS,
        "HEIGHT": HEIGHT,
        "WHEELBASE": WHEELBASE,
        "TRACK_FRONT": TRACK_FRONT,
        "TRACK_REAR": TRACK_REAR,
        "X_FRONT_AXLE": X_FRONT_AXLE,
        "X_REAR_AXLE": X_REAR_AXLE,
        "X_NOSE": X_NOSE,
        "X_TAIL": X_TAIL,
        "HALF_WIDTH_MAX": HALF_WIDTH_MAX,
        "TIRE_FRONT_WIDTH": TIRE_FRONT_WIDTH,
        "TIRE_FRONT_OD": TIRE_FRONT_OD,
        "TIRE_FRONT_R": TIRE_FRONT_R,
        "RIM_FRONT_DIAM": RIM_FRONT_DIAM,
        "TIRE_REAR_WIDTH": TIRE_REAR_WIDTH,
        "TIRE_REAR_OD": TIRE_REAR_OD,
        "TIRE_REAR_R": TIRE_REAR_R,
        "RIM_REAR_DIAM": RIM_REAR_DIAM,
        "Y_WHEEL_FRONT": Y_WHEEL_FRONT,
        "Y_WHEEL_REAR": Y_WHEEL_REAR,
        "Z_WHEEL_FRONT": Z_WHEEL_FRONT,
        "Z_WHEEL_REAR": Z_WHEEL_REAR,
        "ARCH_FRONT_X": ARCH_FRONT_X,
        "ARCH_FRONT_Z": ARCH_FRONT_Z,
        "ARCH_FRONT_R": ARCH_FRONT_R,
        "ARCH_REAR_X": ARCH_REAR_X,
        "ARCH_REAR_Z": ARCH_REAR_Z,
        "ARCH_REAR_R": ARCH_REAR_R,
        "ROTOR_FRONT_R": ROTOR_FRONT_R,
        "ROTOR_REAR_R": ROTOR_REAR_R,
        "Z_UNDERBODY": Z_UNDERBODY,
        "Z_ROCKER_BOTTOM": Z_ROCKER_BOTTOM,
        "EXHAUST_CUTOUT_X": EXHAUST_CUTOUT_X,
        "EXHAUST_CUTOUT_Y": EXHAUST_CUTOUT_Y,
        "EXHAUST_CUTOUT_Z": EXHAUST_CUTOUT_Z,
        "EXHAUST_CUTOUT_W": EXHAUST_CUTOUT_W,
        "EXHAUST_CUTOUT_H": EXHAUST_CUTOUT_H,
        "PIVOT_LOCATIONS": PIVOT_LOCATIONS,
    }


# ---------------------------------------------------------------------------
# Factory-Calibrated Spine Curves (EXACT shadow-free measurements from
# `side view.png`, `top view.svg`, and 4K views 04 / 13 / 36 / 42!)
# ---------------------------------------------------------------------------

# 1. Exact Coke-Bottle Half-Width Planform Y_max(x) (from 4K overhead 42.jpeg & top view.svg)
#    Widebody rear haunch = 0.950 @ -1.225, pinched door waist = 0.842 @ 0.0, front arch = 0.915 @ +1.225,
#    sleek tapered elliptical nose (0.350 @ +2.20) & sleek elliptical tail (0.624 @ -2.15, 0.316 @ -2.28)!
BODY_HALF_WIDTH_X = [
    -2.310, -2.280, -2.230, -2.150, -2.050, -1.950, -1.800, -1.600, -1.420,
    -1.225, -1.000, -0.780, -0.490, -0.250,  0.000,  0.300,  0.635,  0.950,
     1.225,  1.450,  1.650,  1.850,  1.960,  2.050,  2.130,  2.200,  2.241,
]
BODY_HALF_WIDTH_Y = [
     0.000,  0.322,  0.495,  0.640,  0.730,  0.790,  0.854,  0.908,  0.942,
     0.954,  0.942,  0.908,  0.858,  0.845,  0.842,  0.848,  0.862,  0.892,
     0.915,  0.908,  0.875,  0.802,  0.712,  0.570,  0.470,  0.350,  0.000,
]

# 2. Exact Lower Rocker, Flush Front Chin & Rear Departure Sweep Z_bot(x) (calibrated to 04/06/35!)
BODY_Z_BOT_X = [
    -2.310, -2.280, -2.200, -2.050, -1.850, -1.620, -1.225, -0.820,  0.000,
     0.820,  1.225,  1.620,  1.850,  2.000,  2.150,  2.241,
]
BODY_Z_BOT_Z = [
     0.228,  0.220,  0.200,  0.180,  0.158,  0.142,  0.132,  0.130,  0.130,
     0.130,  0.132,  0.130,  0.130,  0.140,  0.152,  0.165,
]

# 3. Exact Outer Fender Crest / Beltline Shoulder Z_shoulder(x)
#    Smooth full continuous cylindrical front fender barrels rolling seamlessly into nose (ZERO diagonal kink!)
BODY_Z_SHOULDER_X = [
    -2.310, -2.260, -2.200, -2.100, -1.950, -1.780, -1.580, -1.350, -1.225,
    -1.000, -0.780, -0.490, -0.200,  0.000,  0.320,  0.635,  0.850,  1.050,
     1.225,  1.420,  1.600,  1.700,  1.750,  1.800,  1.850,  1.950,  2.050,  2.150,  2.241,
]
# Ahead of x = 1.4 the deck's outer edge is set so the measured top line of both profile frames
# (25, 04) comes out: 0.840 at 1.40, 0.808 at 1.60, 0.773 at 1.70, 0.695 at 1.80, 0.612 at 1.95.
BODY_Z_SHOULDER_Z = [
     0.570,  0.718,  0.772,  0.825,  0.874,  0.908,  0.930,  0.938,  0.936,
     0.924,  0.898,  0.868,  0.858,  0.856,  0.858,  0.858,  0.862,  0.864,
     0.862,  0.836,  0.805,  0.759,  0.707,  0.655,  0.634,  0.596,  0.552,  0.480,  0.440,
]

# 4. Exact Centerline Top Deck Z_center(x) (Y = 0)
#    Smooth gentle C2 valley hood (8-10 cm below raised barrels -> ZERO 14 cm lateral cliff or diagonal pinch!)
BODY_Z_CENTER_X = [
    -2.310, -2.260, -2.200, -2.080, -1.920, -1.720, -1.520, -1.350, -1.150,
    -0.600,  0.785,  1.000,  1.225,  1.450,  1.650,  1.850,  2.025,  2.130,  2.200,  2.241,
]
BODY_Z_CENTER_Z = [
     0.565,  0.715,  0.772,  0.828,  0.878,  0.924,  0.966,  0.986,  0.986,
     0.910,  0.840,  0.788,  0.734,  0.676,  0.618,  0.556,  0.494,  0.450,  0.415,  0.382,
]

# 5. Half-width at Upper Shoulder / Beltline Y_belt(x)
#    Shaved upper fender shoulder under mirrors (0.728 @ 0.635, 0.762 @ 0.95) & sculpted rear tumblehome!
BODY_Y_BELT_X = [
    -2.310, -2.260, -2.150, -1.950, -1.750, -1.500, -1.225, -0.950, -0.680,
    -0.490,  0.000,  0.400,  0.635,  0.950,  1.225,  1.520,  1.780,  1.960,  2.100,  2.200,  2.241,
]
BODY_Y_BELT_Y = [
     0.000,  0.295,  0.515,  0.638,  0.686,  0.710,  0.718,  0.718,  0.718,
     0.722,  0.724,  0.726,  0.728,  0.762,  0.798,  0.802,  0.772,  0.692,  0.548,  0.340,  0.000,
]

# 6. Sleek Cabriolet Soft-Top UP Profile (B5: fuller convex rear C-pillar slope & lowered header!)
SOFT_TOP_X = [
    -1.440, -1.320, -1.160, -0.980, -0.780, -0.560, -0.380, -0.240, -0.060,  0.060,  0.140,
]
SOFT_TOP_Z = [
     1.015,  1.102,  1.186,  1.248,  1.286,  1.302,  1.304,  1.304,  1.294,  1.274,  1.250,
]
SOFT_TOP_RAIL_Y = [
     0.425,  0.478,  0.515,  0.540,  0.552,  0.556,  0.554,  0.548,  0.544,  0.542,  0.540,
]
SOFT_TOP_BASE_Y = [
     0.540,  0.625,  0.692,  0.732,  0.744,  0.736,  0.720,  0.695,  0.655,  0.610,  0.578,
]
