"""Map optical artwork and material detail onto the individual rigid parts."""
from pathlib import Path
import bpy
import numpy as np

TEXTURES = Path(__file__).with_name('textures')


def material(name, file, metallic, roughness, emission=0):
    mat = bpy.data.materials.get(name)
    if mat:
        return mat
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    node = mat.node_tree.nodes.get('Principled BSDF')
    node.inputs['Metallic'].default_value = metallic
    node.inputs['Roughness'].default_value = roughness
    image = bpy.data.images.load(str(TEXTURES/file), check_existing=True)
    image.pack()
    tex = mat.node_tree.nodes.new('ShaderNodeTexImage')
    tex.image = image
    mat.node_tree.links.new(tex.outputs['Color'], node.inputs['Base Color'])
    if emission:
        mat.node_tree.links.new(tex.outputs['Color'], node.inputs['Emission Color'])
        node.inputs['Emission Strength'].default_value = emission
    return mat


def uv_by_vertex(obj, coords):
    mesh = obj.data
    uv = mesh.uv_layers.active or mesh.uv_layers.new()
    indices = np.empty(len(mesh.loops), dtype=np.int32)
    mesh.loops.foreach_get('vertex_index', indices)
    uv.data.foreach_set('uv', np.asarray(coords[indices],dtype='f4').ravel())


def apply_graphics():
    plate = bpy.data.objects['TSC_License_Plate']
    xyz = np.array([v.co for v in plate.data.vertices])
    uv = (xyz[:,[1,2]]-xyz[:,[1,2]].min(0))/np.ptp(xyz[:,[1,2]],axis=0)
    uv[:,0]=1-uv[:,0]
    uv_by_vertex(plate,uv)
    plate.data.materials[0]=material('Porsche 911 studio plate','studio-plate.png',.06,.55,.19)
    crest = bpy.data.objects['TSC_Nose_Crest']
    xyz = np.array([v.co for v in crest.data.vertices])
    pos = (xyz[:,:2]-xyz[:,:2].min(0))/np.maximum(np.ptp(xyz[:,:2],axis=0),1e-6)
    uv_by_vertex(crest, np.stack((pos[:,1],1-pos[:,0]), axis=1))
    crest.data.materials[0] = material('Turbonite enamel crest','turbonite-crest.png',.30,.35)
    alloy = bpy.data.materials['Mat_Turbonite_Alloy']
    metal = alloy.node_tree.nodes.get('Principled BSDF')
    metal.inputs['Base Color'].default_value = (.125,.116,.104,1)
    metal.inputs['Roughness'].default_value = .38
    for side in ('FL','FR','RL','RR'):
        cap = bpy.data.objects['TSC_CenterCrestCap_'+side]
        xyz = np.array([v.co for v in cap.data.vertices])
        pos = xyz[:,[0,2]]; uv = (pos-pos.min(0))/np.ptp(pos,axis=0)
        if side.endswith('L'):
            uv[:,0] = 1-uv[:,0]
        uv_by_vertex(cap, uv)
        cap.data.materials.clear()
        cap.data.materials.append(material('Centre-lock enamel and lock ring','wheel-cap.png',.26,.40,.16))
        # The optical map is restricted to the outward sidewall. The tread and
        # inner bead keep their separate rubber and moulded geometry.
        tire = bpy.data.objects['TSC_Tire_'+side]
        mesh = tire.data
        xyz = np.array([v.co for v in mesh.vertices])
        mid = (xyz.max(0)+xyz.min(0))/2
        rel = xyz-mid
        radius = np.hypot(rel[:,0],rel[:,2])
        outer = radius.max()
        rear = side.startswith('R')
        bead = .2667 if rear else .254
        angle = np.arctan2(rel[:,0],rel[:,2])/(2*np.pi) + .5
        if side.endswith('R'):
            angle = 1-angle
        tex_uv = np.stack((angle, np.clip((radius-bead)/(outer-bead),0,1)), axis=1)
        layer = mesh.uv_layers.active or mesh.uv_layers.new()
        texture_mat = material(('Rear' if rear else 'Front')+' P Zero sidewall',
                               'rear-sidewall.webp' if rear else 'front-sidewall.webp',.04,.74)
        slot = len(mesh.materials);mesh.materials.append(texture_mat)
        side_sign = 1 if side.endswith('L') else -1
        for face in mesh.polygons:
            verts = np.asarray(face.vertices)
            outward = np.mean(rel[verts,1])*side_sign
            if outward < .73*np.max(rel[:,1]*side_sign) or np.min(radius[verts]) < bead*.99:
                continue
            if mesh.materials[face.material_index].name != 'Mat_Tire_Rubber':
                continue
            face.material_index = slot
            uvs=tex_uv[verts].copy()
            if np.ptp(uvs[:,0])>.5:
                uvs[uvs[:,0]<.5,0]+=1
            for loop, uv in zip(face.loop_indices,uvs):
                layer.data[loop].uv=uv
        rotor = bpy.data.objects['TSC_PCCB_Rotor_'+side]
        xyz = np.array([v.co for v in rotor.data.vertices])
        plane = xyz[:,[0,2]]
        uv_by_vertex(rotor, (plane-plane.min(0))/np.ptp(plane,axis=0)*4)
        for i, mat in enumerate(rotor.data.materials):
            if mat.name=='Mat_PCCB_Ceramic_Rotor':
                rotor.data.materials[i]=material('PCCB carbon ceramic friction surface','friction-surface.jpg',.22,.64)
