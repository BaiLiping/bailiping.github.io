"""
Main entrypoint for the Exterior Body, Closures, Aero, Soft-Top & Optics package.
Implements the shared contract:
    build(rig_root: bpy.types.Object, cfg_dict: dict = None, **opts) -> dict[str, bpy.types.Object]
"""

import bpy

from . import config as cfg
from .geom_utils import ensure_empty
from .materials import create_all_materials
from .body_shell import build_body_shell
from .closures import build_front_lid, build_doors, build_fuel_flap, build_rear_lid
from .aero_and_top import (
    build_soft_top_up,
    build_soft_top_stowed,
    build_active_wing,
    build_front_aero,
    build_side_aero_and_intakes,
    build_rear_diffuser_and_exhaust_bezels,
)
from .optics_and_badges import build_windshield_and_frame, build_headlights, build_taillight_and_rear_details


def build(
    rig_root: bpy.types.Object,
    cfg_dict: dict = None,
    include_door_cards: bool = False,
    roof_state: str = "up",
) -> dict:
    """
    Build all exterior body assemblies under `rig_root` in real-world meters (Blender Z-up).
    Returns dict mapping Pivot_* names to their Blender Empty objects.
    """
    mats = create_all_materials()
    body_piv = ensure_empty("Pivot_Body_Assembly", cfg.PIVOT_LOCATIONS["Pivot_Body_Assembly"], parent=rig_root)

    pivots = {"Pivot_Body_Assembly": body_piv}

    # 1. Main wide-body 992.2 shell + rolled wheel arches + sealed wheelhouse liners + frunk tub
    build_body_shell(body_piv, mats, excise_closures=True)

    # 2. Hinged closures on exact physical pivot axes
    pivots["Pivot_Front_Lid"] = build_front_lid(body_piv, mats)
    pivots.update(build_doors(body_piv, mats, include_door_cards=include_door_cards))
    pivots.update(build_fuel_flap(body_piv, mats))
    pivots["Pivot_Rear_Lid"] = build_rear_lid(body_piv, mats)

    # 3. Convertible Soft-Top (UP & Stowed DOWN) + Active Turbo S Rear Wing + Aero & Intakes
    piv_top_up = build_soft_top_up(body_piv, mats)
    piv_top_stowed = build_soft_top_stowed(body_piv, mats)
    pivots["Pivot_Soft_Top"] = piv_top_up
    pivots["Pivot_Soft_Top_Stowed"] = piv_top_stowed

    # Default assembled state: soft-top UP visible, stowed tonneau hidden (viewer swaps visibility on toggle!)
    show_stowed = (roof_state == "down")
    for ob in [piv_top_up, *piv_top_up.children_recursive]:
        ob.hide_viewport = show_stowed
        ob.hide_render = show_stowed
    for ob in [piv_top_stowed, *piv_top_stowed.children_recursive]:
        ob.hide_viewport = not show_stowed
        ob.hide_render = not show_stowed

    pivots["Pivot_Active_Wing"] = build_active_wing(body_piv, mats)
    build_front_aero(body_piv, mats)
    build_side_aero_and_intakes(body_piv, mats)
    build_rear_diffuser_and_exhaust_bezels(body_piv, mats)

    # 4. Windshield/A-pillars/wipers, 4-point HD-Matrix headlights, full-width taillight bar & badges
    build_windshield_and_frame(body_piv, mats)
    build_headlights(body_piv, mats)
    build_taillight_and_rear_details(body_piv, mats)

    return pivots
