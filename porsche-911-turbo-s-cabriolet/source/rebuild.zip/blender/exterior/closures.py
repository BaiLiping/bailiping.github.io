"""
Hinged & Separable Exterior Closures for the 2026 Porsche 911 Turbo S Cabriolet (992.2):
  - Pivot_Front_Lid  : Precision-fitted 992 frunk hood (3 mm dark-rimmed shutline) + underside liner + Turbonite crest
  - Pivot_Door_L / R : Exact-match door shells (3 mm dark-rimmed shutline), SportDesign mirrors,
                       flush handles, frameless curved side glass, t-hybrid side script
  - Pivot_Fuel_Flap  : Circular right-front fender fuel door hinged at FRONT edge (per photo 26!) + Pivot_Fuel_Cap
  - Pivot_Rear_Lid   : Rear engine service decklid & 24-slat black longitudinal louvered cooling grille
"""

import math
import numpy as np
import bpy
from mathutils import Vector

from . import config as cfg
from .geom_utils import (
    ensure_empty,
    smootherstep,
    create_quad_grid,
    create_solidified_panel,
    create_mesh_object,
    create_rounded_box,
    create_cylinder,
    create_tube,
)
from .emblems import emblem
from .materials import make_pbr
from .body_shell import (
    eval_front_hood_z,
    eval_hood_hw,
    eval_flank_y,
    eval_y_max,
    eval_y_belt,
    eval_z_bot,
    eval_z_shoulder,
    eval_rear_deck_z,
    query_side_surface_y,
    query_body_ray,
    FUEL_CENTER_X,
    FUEL_CENTER_Z,
    FUEL_RADIUS,
)


def build_front_lid(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    """Build hinged Pivot_Front_Lid with exact 992 straight nose edge & crisp dark-rimmed 3 mm shutline."""
    piv = ensure_empty("Pivot_Front_Lid", cfg.PIVOT_LOCATIONS["Pivot_Front_Lid"], parent=body_pivot)

    xs = np.linspace(0.788, 2.022, 38)
    us = np.linspace(-1.0, 1.0, 35)
    grid = []
    for x in xs:
        hood_hw = eval_hood_hw(x) - 0.0025
        row = []
        for u in us:
            y = u * hood_hw
            z = float(eval_front_hood_z(x, y))
            row.append((x, y, z))
        grid.append(row)

    ob = create_quad_grid("TSC_Front_Lid", grid, material=[mats["paint"], mats["shadow"]], parent=piv, smooth=True, recalc_normals=False, flip_faces=False)
    sol = ob.modifiers.new("HoodThick", "SOLIDIFY")
    sol.thickness = 0.005
    sol.offset = -1.0
    sol.use_rim = True
    sol.material_offset = 1
    sol.material_offset_rim = 1
    es = ob.modifiers.new("EdgeSplit", "EDGE_SPLIT")
    es.split_angle = math.radians(40.0)

    # Underside inner panel
    in_grid = []
    for x in np.linspace(0.84, 1.96, 12):
        hw = eval_hood_hw(x) - 0.05
        row = [(x, u * hw, float(eval_front_hood_z(x, u * hw)) - 0.015) for u in np.linspace(-1.0, 1.0, 11)]
        in_grid.append(row)
    create_quad_grid("TSC_Front_Lid_Inner", in_grid, material=mats["shadow"], parent=piv, flip_faces=True)

    # Turbonite Porsche Nose Crest centered near straight leading edge (X ≈ +1.915)
    cx = 1.915
    cz = float(eval_front_hood_z(cx, 0.0)) + 0.0025
    pitch = math.atan2(float(eval_front_hood_z(cx + 0.03, 0.0)) - float(eval_front_hood_z(cx - 0.03, 0.0)), 0.06)
    crest_pts = [
        (0.034,  0.000), (0.012,  0.021), (-0.022,  0.024), (-0.030,  0.018),
        (-0.030, -0.018), (-0.022, -0.024), (0.012, -0.021),
    ]
    verts_top, verts_bot = [], []
    cp, sp = math.cos(pitch), math.sin(pitch)
    for dx, dy in crest_pts:
        wx = cx + dx * cp
        wz = cz + dx * sp
        verts_bot.append((wx, dy, wz - 0.001))
        verts_top.append((wx - 0.0025 * sp, dy, wz + 0.0025 * cp))
    n = len(crest_pts)
    faces = [tuple(range(n, 2 * n))] + [(i, (i + 1) % n, n + (i + 1) % n, n + i) for i in range(n)]
    create_mesh_object("TSC_Nose_Crest", verts_bot + verts_top, faces, material=mats["turbonite"], parent=piv, smooth=False)

    return piv


def _build_side_mirror(sign: float, tag: str, door_piv: bpy.types.Object, mats: dict):
    """
    Sleek 992 SportDesign door-mounted mirror reaching exact WIDTH_MIRRORS = 2.033 m (|Y_tip| = 1.0165 m).
    B5: Shifted -4.7 cm aft (mx_base=0.398) & fuller vertical cap (rz=0.062) locking view-41 & view-35!
    """
    mx_base = 0.398
    mz_base = eval_z_shoulder(mx_base) - 0.036
    my_base = sign * (eval_flank_y(mx_base, mz_base) - 0.005)

    # Sturdy gloss-black aerodynamic base pedestal & V-stalk
    stalk_grid = []
    for t in np.linspace(0.0, 1.0, 10):
        sx = mx_base - 0.042 * t
        sy = sign * (abs(my_base) + 0.088 * t)
        sz = mz_base + 0.056 * t
        ax = 0.062 * (1.0 - 0.30 * t)
        az = 0.020 * (1.0 - 0.18 * t)
        ring = [(sx + ax * math.cos(a), sy, sz + az * math.sin(a)) for a in np.linspace(0.0, 2.0 * math.pi, 18, endpoint=False)]
        stalk_grid.append(ring)
    create_quad_grid(f"TSC_Mirror_Stalk_{tag}", stalk_grid, material=mats["gloss_black"], parent=door_piv, cyclic_v=True, cap_u0=True, cap_u1=True)

    # Loft from the rounded nose to a clipped rear face. The mirror glass and
    # its rubber gasket share this perimeter, including the swept outer corner.
    y_out=cfg.HALF_WIDTH_MIRRORS
    y_in=abs(my_base)+.028
    mid=(y_in+y_out)/2
    half=(y_out-y_in)/2
    perimeter=[]
    for a in np.linspace(0,2*math.pi,61)[:-1]:
        c,s=math.cos(a),math.sin(a)
        across=math.copysign(abs(c)**.62,c)
        height=math.copysign(abs(s)**.56,s)
        perimeter.append((across,height))
    def section(scale,forward):
        ring=[]
        for lateral,vertical in perimeter:
            u=lateral*scale
            z=mz_base+.096-.013*u+vertical*scale*(.058-.007*u)
            y=mid+half*u
            x=mx_base-.116-.039*u+.004*vertical+forward
            ring.append((x,sign*y,z))
        return ring
    cap=[section(a,b) for a,b in [(1,-.001),(.996,.012),(.94,.049),(.78,.080),
                                   (.53,.106),(.24,.118),(.04,.121)]]
    create_quad_grid(f"TSC_Mirror_{tag}",cap,material=mats["paint"],parent=door_piv,
                     cyclic_v=True,cap_u1=True)
    gasket=[section(1,-.001),section(.972,-.005),section(.898,-.005),section(.875,.003)]
    create_quad_grid(f"TSC_Mirror_Seal_{tag}",gasket,material=mats["gloss_black"],
                     parent=door_piv,cyclic_v=True)
    mirror=make_pbr("Mat_Exterior_Mirror_Glass","#a1aeb3",metallic=.69,roughness=.145,
                    coat_weight=.42,coat_roughness=.065)
    face=[section(.885,.002),section(.69,.0005),section(.38,-.0005),section(.035,-.001)]
    create_quad_grid(f"TSC_Mirror_Glass_{tag}",face,material=mirror,parent=door_piv,
                     cyclic_v=True,cap_u1=True)


def _build_door_handle(sign: float, tag: str, door_piv: bpy.types.Object, mats: dict):
    """Flush pull with an asymmetric thumb pocket on the rear of the door."""
    hx,hz=-.311,.710
    def position(u,v,depth):
        x=hx+u*.096+.010*v
        z=hz+v*.025
        y=query_side_surface_y(x,z,sign,unrecessed=True)
        return (x,sign*(y+depth),z)
    def contour(scale,offset,depth):
        return [position(scale*u,v*scale+offset,depth)
                for u,v in points]
    points=[]
    for a in np.linspace(0,2*math.pi,65)[:-1]:
        cs,sn=math.cos(a),math.sin(a)
        u=math.copysign(abs(cs)**.63,cs)
        v=math.copysign(abs(sn)**.65,sn)*(1-.28*max(0,u))
        points.append((u,v))
    pocket=[contour(1,0,.0015),contour(.95,0,.004),contour(.82,0,.006)]
    create_quad_grid(f"TSC_Door_Handle_Recess_{tag}",pocket,material=mats["gloss_black"],
                     parent=door_piv,cyclic_v=True,cap_u1=True)
    face=[contour(.92,.035,.005),contour(.85,.095,.009),
          contour(.61,.17,.011),contour(.20,.22,.012)]
    create_quad_grid(f"TSC_Door_Handle_{tag}",face,material=mats["paint"],parent=door_piv,
                     cyclic_v=True,cap_u1=True)


def _build_door_glass(sign: float, tag: str, door_piv: bpy.types.Object, mats: dict):
    """Frameless curved 992 Cabriolet side door glass (single-sided -> ZERO thick bright-silver B-pillar edge!)."""
    xs = np.linspace(-0.338, 0.608, 22)
    grid = []
    for x in xs:
        z_low = eval_z_shoulder(x) - 0.014
        if x > cfg.X_HEADER_SIDE:
            frac = np.clip((0.612 - x) / (0.612 - cfg.X_HEADER_SIDE), 0.0, 1.0)
            z_high = 0.888 + (cfg.Z_HEADER_SIDE - 0.888) * (frac ** 0.94)
        else:
            z_high = cfg.Z_HEADER_SIDE + 0.020 * math.sin(math.pi * np.clip((cfg.X_HEADER_SIDE - x) / 0.48, 0.0, 1.0))

        y_low = eval_y_belt(x) - 0.016
        y_high = y_low - (z_high - z_low) * 0.43
        row = []
        for s in np.linspace(0.0, 1.0, 10):
            bow = 0.012 * math.sin(math.pi * s)
            row.append((x, sign * (y_low + (y_high - y_low) * s + bow), z_low + (z_high - z_low) * s))
        grid.append(row)

    create_quad_grid(f"TSC_Glass_Door_{tag}", grid, material=mats["glass"], parent=door_piv, smooth=True, flip_faces=(sign > 0))


def build_doors(body_pivot: bpy.types.Object, mats: dict, include_door_cards: bool = False) -> dict:
    """Build hinged Pivot_Door_L and Pivot_Door_R with exact 3 mm dark-rimmed shutlines."""
    pivots = {}
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        name = f"Pivot_Door_{tag}"
        piv = ensure_empty(name, cfg.PIVOT_LOCATIONS[name], parent=body_pivot)
        pivots[name] = piv

        # Exact 1.8 mm panel gap matching body_shell door aperture X in [-0.490, +0.635]
        # Raycast every vertex directly onto _SHELL_UNRECESSED_BVH -> 0.000 mm Class-A seam continuity!
        # Broad rear door radius and shallow sill crease from both side profiles.
        # Keep the material around that radius on the fixed rear quarter.
        xs_d = np.linspace(-.4882,.6332,43)
        ts=np.linspace(0,1,39)
        def door_edge_z(t):
            return .214+(.834-.214)*(1-math.cos(math.pi*t))*.5
        def limits(z):
            h=max(0,min(1,(z-.214)/.482))
            rounded=1-math.sqrt(max(0,1-(1-h)**2))
            lift=max(0,min(1,(z-.214)/.101))
            toe=1-math.sqrt(max(0,1-(1-lift)**2))
            return -.4882+.288*rounded,.6332-.054*toe
        def skin(x,z):
            y=query_side_surface_y(float(x),float(z),sign,unrecessed=True)
            return (x,sign*y,z)
        grid=[]
        for j,x0 in enumerate(xs_d):
            u=j/(len(xs_d)-1)
            row=[]
            for t in ts:
                z=door_edge_z(t)
                aft,fore=limits(z)
                x=aft+(fore-aft)*u
                z+=t**4*(float(eval_z_shoulder(x))-.834)
                row.append(skin(x,z))
            grid.append(row)
        def fixed_infill(name,rows):
            create_quad_grid(f"TSC_Fender_{name}_{tag}",
                             rows,material=mats["paint"],parent=body_pivot)
        for end,old,label in [(0,-.490,"Rear_Door_Return"),(-1,.635,"Front_Door_Return")]:
            rows=[]
            for x,y,z in grid[end]:
                seam=x+(-.003 if end==0 else .003)
                if abs(old-seam)<.002:
                    seam=old+(.0006 if end==0 else -.0006)
                rows.append([skin(a,z) for a in np.linspace(old,seam,10)])
            fixed_infill(label,rows)
        sill=[]
        for x in np.linspace(-.49,.635,55):
            sill.append([skin(x,z) for z in np.linspace(.175,.2115,5)])
        fixed_infill("Door_Sill",sill)
        # Jamb follows the actual door cut and remains visible with the door open.
        shut=[r[0] for r in grid]+grid[-1][1:]
        aft=list(reversed(grid[0]))+shut[1:]
        create_quad_grid(f"TSC_Door_Jamb_Return_{tag}",
                         [[(x,y-sign*.003,z),(x,y-sign*.035,z-.002)] for x,y,z in aft],
                         material=mats["shadow"],parent=body_pivot)

        # Explicit outward winding (recalc_normals=False so open sheet never flips inward onto Solidify's dark slot 1!)
        # Grid axes: u = X increasing (-0.487 -> +0.632), v = Z increasing (0.178 -> shoulder).
        # Right-hand cross(dX, dZ) = (1,0,0) x (0,0,1) = (0,-1,0) (-Y = Right!).
        # So for LEFT (+Y) we flip_faces=True (+Y outward!), and for RIGHT (-Y) we flip_faces=False (-Y outward!)!
        ob = create_quad_grid(
            f"TSC_Door_Shell_{tag}",
            grid,
            material=[mats["paint"], mats["shadow"]],
            parent=piv,
            smooth=True,
            recalc_normals=False,
            flip_faces=(sign > 0),
        )
        sol = ob.modifiers.new("DoorThick", "SOLIDIFY")
        sol.thickness = 0.006
        sol.offset = -1.0
        sol.use_rim = True
        sol.material_offset = 1
        sol.material_offset_rim = 1
        # Split 90-deg shutline rim normals cleanly so outer Class-A door edges have ZERO vertical specular banding!
        es = ob.modifiers.new("EdgeSplit", "EDGE_SPLIT")
        es.split_angle = math.radians(40.0)

        # Gloss-black window-belt weatherstrip along top edge of door
        belt_pts = [(float(x), sign * (eval_y_belt(float(x)) - 0.005), eval_z_shoulder(float(x)) + 0.002) for x in np.linspace(-0.486, 0.631, 16)]
        create_tube(f"TSC_Door_BeltSeal_{tag}", belt_pts, radius=0.0065, segments=10, material=mats["gloss_black"], parent=piv)

        if include_door_cards:
            card_grid = []
            for x in np.linspace(-0.43, 0.56, 12):
                y_in = eval_y_belt(x) - 0.095
                z_top = eval_z_shoulder(x) - 0.020
                card_grid.append([
                    (x, sign * (y_in + 0.035), z_top),
                    (x, sign * y_in, z_top - 0.045),
                    (x, sign * (y_in - 0.025), 0.560),
                    (x, sign * (y_in - 0.010), 0.420),
                    (x, sign * (y_in + 0.015), 0.250),
                ])
            create_quad_grid(f"TSC_Door_Card_{tag}", card_grid, material=mats["cabin_leather"], parent=piv, smooth=True, flip_faces=(sign > 0))

        _build_side_mirror(sign, tag, piv, mats)
        _build_door_handle(sign, tag, piv, mats)
        _build_door_glass(sign, tag, piv, mats)

        def door_badge(u,v,depth):
            x,z=.425-sign*u,.266+v
            y=query_side_surface_y(x,z,sign,unrecessed=True)
            return x,sign*(y+.002+depth),z
        emblem(f"TSC_THybrid_Badge_{tag}","t-hybrid",.185,.021,
               door_badge,mats["turbonite"],piv)

    return pivots


def build_fuel_flap(body_pivot: bpy.types.Object, mats: dict) -> dict:
    """
    100% FLUSH circular right-front fender fuel door hinged at its FRONT edge (+1.135)
    matching studio photo (26).jpeg:
      - Raycasted curved outer flap hugs right front fender seamlessly when closed
      - Opening Pivot_Fuel_Flap reveals the dark recessed circular filler bowl, sleek hinge arm,
        and stationary silver/black metallic fuel cap (Pivot_Fuel_Cap sibling of Pivot_Fuel_Flap)!
    """
    piv_flap = ensure_empty("Pivot_Fuel_Flap", cfg.PIVOT_LOCATIONS["Pivot_Fuel_Flap"], parent=body_pivot)
    piv_cap = ensure_empty("Pivot_Fuel_Cap", cfg.PIVOT_LOCATIONS["Pivot_Fuel_Cap"], parent=body_pivot)

    fx = FUEL_CENTER_X
    fz = FUEL_CENTER_Z
    r = FUEL_RADIUS - 0.002

    # Outward fender normal at fuel-door center (~36 deg upward from -Y)
    tilt = math.radians(36.0)
    ct, st = math.cos(tilt), math.sin(tilt)
    n_out = Vector((0.0, -ct, st)).normalized()
    u_x = Vector((1.0, 0.0, 0.0))
    v_tan = Vector((0.0, st, ct)).normalized()

    # Anchor on exact smooth un-recessed right fender skin
    y_est = -query_side_surface_y(fx, fz, -1.0, unrecessed=True)
    c_est = Vector((fx, y_est, fz))
    c_hit, _ = query_body_ray(c_est + n_out * 0.40, -n_out, unrecessed=True, max_dist=1.0)
    c_anchor = c_hit if c_hit is not None else c_est

    def _flap_pt(rx: float, rv: float, n_off: float = 0.0):
        base = c_anchor + u_x * (r * rx) + v_tan * (r * rv)
        hp, _ = query_body_ray(base + n_out * 0.40, -n_out, unrecessed=True, max_dist=1.0)
        p = (hp if hp is not None else base) + n_out * n_off
        return (float(p.x), float(p.y), float(p.z))

    n = 36
    angs = np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)
    ring_out = [_flap_pt(math.cos(a), math.sin(a), n_off=+0.0012) for a in angs]
    ring_in = [_flap_pt(math.cos(a), math.sin(a), n_off=-0.0045) for a in angs]
    c_out = _flap_pt(0.0, 0.0, n_off=+0.0018)
    c_in = _flap_pt(0.0, 0.0, n_off=-0.0045)

    verts = ring_out + ring_in + [c_out, c_in]
    faces = []
    for i in range(n):
        i2 = (i + 1) % n
        faces.append((2 * n, i, i2))
        faces.append((2 * n + 1, n + i2, n + i))
        faces.append((i, n + i, n + i2, i2))
    create_mesh_object("TSC_Fuel_Flap", verts, faces, material=mats["paint"], parent=piv_flap, smooth=True)

    # Dark curved hinge arm connecting flap inner face to front hinge Pivot_Fuel_Flap (photo 26!)
    p_hinge = Vector(cfg.PIVOT_LOCATIONS["Pivot_Fuel_Flap"])
    arm_pts = [
        (p_hinge.x, p_hinge.y + 0.012, p_hinge.z),
        (fx + 0.030, c_anchor.y + 0.018 * ct, c_anchor.z - 0.018 * st),
        (fx, c_anchor.y + 0.006 * ct, c_anchor.z - 0.006 * st),
    ]
    create_tube("TSC_Fuel_Flap_Arm", arm_pts, radius=0.006, segments=8, material=mats["matte_trim"], parent=piv_flap)

    # Recessed dark matte-black circular fuel-filler bowl & outer rubber seal (visible when flap opens!)
    bowl_grid = []
    for s in [0.0, 0.22, 0.68, 1.0]:
        rad = 1.04 - 0.14 * s
        off = +0.0005 - 0.048 * s
        bowl_grid.append([_flap_pt(rad * math.cos(a), rad * math.sin(a), n_off=off) for a in angs])
    create_quad_grid("TSC_Fuel_Filler_Bowl", bowl_grid, material=mats["shadow"], parent=body_pivot, cyclic_v=True, cap_u1=True)

    seam_pts = [_flap_pt(1.03 * math.cos(a), 1.03 * math.sin(a), n_off=0.0008) for a in angs]
    create_tube("TSC_Fuel_Filler_Seal", seam_pts, radius=0.0038, segments=8, material=mats["shadow"], parent=body_pivot, cyclic=True)

    # Recessed Porsche fuel filler neck + satin-silver/dark-chrome twist cap seated inside bowl (photo 26!)
    p_neck = c_anchor - n_out * 0.036
    p_cap = c_anchor - n_out * 0.022
    create_cylinder(
        "TSC_Fuel_Filler_Neck",
        (float(p_neck.x), float(p_neck.y), float(p_neck.z)),
        radius=0.032,
        depth=0.028,
        axis="Y",
        segments=24,
        material=mats["matte_trim"],
        parent=piv_cap,
    )
    cap_ob = create_cylinder(
        "TSC_Fuel_Cap",
        (float(p_cap.x), float(p_cap.y), float(p_cap.z)),
        radius=0.035,
        depth=0.018,
        axis="Y",
        segments=24,
        material=mats["turbonite"],
        parent=piv_cap,
        bevel=0.003,
    )
    cap_ob.rotation_euler = (-tilt, 0.0, 0.0)

    return {"Pivot_Fuel_Flap": piv_flap, "Pivot_Fuel_Cap": piv_cap}


def build_rear_lid(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    """Build Pivot_Rear_Lid: rear engine service decklid + 24-slat black longitudinal louvered cooling grille."""
    piv = ensure_empty("Pivot_Rear_Lid", cfg.PIVOT_LOCATIONS["Pivot_Rear_Lid"], parent=body_pivot)

    return piv
