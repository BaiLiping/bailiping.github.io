"""
Hinged & Separable Exterior Closures for the 2026 Porsche 911 Turbo S Cabriolet (992.2):
  - Pivot_Front_Lid  : Precision-fitted 992 frunk hood (3 mm dark-rimmed shutline) + underside liner + Turbonite crest
  - Pivot_Door_L / R : Exact-match door shells (3 mm dark-rimmed shutline), SportDesign mirrors,
                       flush handles, frameless curved side glass, t-hybrid side script
  - Pivot_Fuel_Flap  : Circular right-front fender fuel door hinged at FRONT edge (per photo 26!) + Pivot_Fuel_Cap
  - Pivot_Rear_Lid   : Rear engine service decklid & 24-slat black longitudinal louvered cooling grille
"""

import math
import numpy as np
import bpy
from mathutils import Vector

from . import config as cfg
from .geom_utils import (
    ensure_empty,
    smootherstep,
    create_quad_grid,
    create_solidified_panel,
    create_mesh_object,
    create_rounded_box,
    create_cylinder,
    create_tube,
)
from .body_shell import (
    eval_front_hood_z,
    eval_hood_hw,
    eval_flank_y,
    eval_y_max,
    eval_y_belt,
    eval_z_bot,
    eval_z_shoulder,
    eval_rear_deck_z,
    query_side_surface_y,
    query_body_ray,
    FUEL_CENTER_X,
    FUEL_CENTER_Z,
    FUEL_RADIUS,
)


def build_front_lid(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    """Build hinged Pivot_Front_Lid with exact 992 straight nose edge & crisp dark-rimmed 3 mm shutline."""
    piv = ensure_empty("Pivot_Front_Lid", cfg.PIVOT_LOCATIONS["Pivot_Front_Lid"], parent=body_pivot)

    xs = np.linspace(0.788, 2.022, 38)
    us = np.linspace(-1.0, 1.0, 35)
    grid = []
    for x in xs:
        hood_hw = eval_hood_hw(x) - 0.0025
        row = []
        for u in us:
            y = u * hood_hw
            z = float(eval_front_hood_z(x, y))
            row.append((x, y, z))
        grid.append(row)

    ob = create_quad_grid("TSC_Front_Lid", grid, material=[mats["paint"], mats["shadow"]], parent=piv, smooth=True, recalc_normals=False, flip_faces=False)
    sol = ob.modifiers.new("HoodThick", "SOLIDIFY")
    sol.thickness = 0.005
    sol.offset = -1.0
    sol.use_rim = True
    sol.material_offset = 1
    sol.material_offset_rim = 1
    es = ob.modifiers.new("EdgeSplit", "EDGE_SPLIT")
    es.split_angle = math.radians(40.0)

    # Underside inner panel
    in_grid = []
    for x in np.linspace(0.84, 1.96, 12):
        hw = eval_hood_hw(x) - 0.05
        row = [(x, u * hw, float(eval_front_hood_z(x, u * hw)) - 0.015) for u in np.linspace(-1.0, 1.0, 11)]
        in_grid.append(row)
    create_quad_grid("TSC_Front_Lid_Inner", in_grid, material=mats["shadow"], parent=piv, flip_faces=True)

    # Turbonite Porsche Nose Crest centered near straight leading edge (X ≈ +1.915)
    cx = 1.915
    cz = float(eval_front_hood_z(cx, 0.0)) + 0.0025
    pitch = math.atan2(float(eval_front_hood_z(cx + 0.03, 0.0)) - float(eval_front_hood_z(cx - 0.03, 0.0)), 0.06)
    crest_pts = [
        (0.034,  0.000), (0.012,  0.021), (-0.022,  0.024), (-0.030,  0.018),
        (-0.030, -0.018), (-0.022, -0.024), (0.012, -0.021),
    ]
    verts_top, verts_bot = [], []
    cp, sp = math.cos(pitch), math.sin(pitch)
    for dx, dy in crest_pts:
        wx = cx + dx * cp
        wz = cz + dx * sp
        verts_bot.append((wx, dy, wz - 0.001))
        verts_top.append((wx - 0.0025 * sp, dy, wz + 0.0025 * cp))
    n = len(crest_pts)
    faces = [tuple(range(n, 2 * n))] + [(i, (i + 1) % n, n + (i + 1) % n, n + i) for i in range(n)]
    create_mesh_object("TSC_Nose_Crest", verts_bot + verts_top, faces, material=mats["turbonite"], parent=piv, smooth=False)

    return piv


def _build_side_mirror(sign: float, tag: str, door_piv: bpy.types.Object, mats: dict):
    """
    Sleek 992 SportDesign door-mounted mirror reaching exact WIDTH_MIRRORS = 2.033 m (|Y_tip| = 1.0165 m).
    B5: Shifted -4.7 cm aft (mx_base=0.398) & fuller vertical cap (rz=0.062) locking view-41 & view-35!
    """
    mx_base = 0.398
    mz_base = eval_z_shoulder(mx_base) - 0.036
    my_base = sign * (eval_flank_y(mx_base, mz_base) - 0.005)

    # Sturdy gloss-black aerodynamic base pedestal & V-stalk
    stalk_grid = []
    for t in np.linspace(0.0, 1.0, 10):
        sx = mx_base - 0.042 * t
        sy = sign * (abs(my_base) + 0.088 * t)
        sz = mz_base + 0.056 * t
        ax = 0.062 * (1.0 - 0.30 * t)
        az = 0.020 * (1.0 - 0.18 * t)
        ring = [(sx + ax * math.cos(a), sy, sz + az * math.sin(a)) for a in np.linspace(0.0, 2.0 * math.pi, 18, endpoint=False)]
        stalk_grid.append(ring)
    create_quad_grid(f"TSC_Mirror_Stalk_{tag}", stalk_grid, material=mats["gloss_black"], parent=door_piv, cyclic_v=True, cap_u0=True, cap_u1=True)

    # Sculpted aerodynamic Gentian Blue mirror cap spanning out to exact |Y| = 1.0165 m
    cap_grid = []
    y_in = abs(my_base) + 0.044
    y_out = cfg.HALF_WIDTH_MIRRORS  # 1.0165 m exact!
    for s in np.linspace(0.0, 1.0, 18):
        y_cur = sign * (y_in + (y_out - y_in) * s)
        x_ctr = mx_base - 0.048 - 0.072 * (s ** 1.35)
        z_ctr = mz_base + 0.094 + 0.016 * math.sin(math.pi * s) - 0.016 * (s ** 2.2)
        prof_scale = math.sin(math.pi * (0.07 + 0.86 * s)) ** 0.52
        rx = 0.098 * prof_scale
        rz = 0.062 * prof_scale
        ring = []
        for a in np.linspace(0.0, 2.0 * math.pi, 22, endpoint=False):
            ca, sa = math.cos(a), math.sin(a)
            dx = rx * (ca if ca > 0 else 0.70 * ca)
            dz = rz * sa
            ring.append((x_ctr + dx, y_cur, z_ctr + dz))
        cap_grid.append(ring)
    create_quad_grid(f"TSC_Mirror_{tag}", cap_grid, material=mats["paint"], parent=door_piv, cyclic_v=True, cap_u0=True, cap_u1=True)

    # Mirror glass facing aft (-X)
    create_rounded_box(
        f"TSC_Mirror_Glass_{tag}",
        (mx_base - 0.114, sign * (0.5 * (y_in + y_out)), mz_base + 0.094),
        (0.008, (y_out - y_in) * 0.78, 0.084),
        material=mats["chrome"],
        parent=door_piv,
        bevel_width=0.003,
        rotation=(0.0, 0.0, sign * 0.25),
    )


def _build_door_handle(sign: float, tag: str, door_piv: bpy.types.Object, mats: dict):
    """992 flush aerodynamic pop-out door handle (B5: shifted -5 cm aft & -2 cm down onto photo handle!)."""
    hx = -0.305
    hz = 0.715
    y_surf = query_side_surface_y(hx, hz, sign, unrecessed=True)

    create_rounded_box(
        f"TSC_Door_Handle_Recess_{tag}",
        (hx, sign * (y_surf - 0.003), hz),
        (0.168, 0.012, 0.036),
        material=mats["gloss_black"],
        parent=door_piv,
        bevel_width=0.010,
    )
    create_rounded_box(
        f"TSC_Door_Handle_{tag}",
        (hx, sign * (y_surf + 0.003), hz),
        (0.150, 0.011, 0.025),
        material=mats["paint"],
        parent=door_piv,
        bevel_width=0.007,
    )


def _build_door_glass(sign: float, tag: str, door_piv: bpy.types.Object, mats: dict):
    """Frameless curved 992 Cabriolet side door glass (single-sided -> ZERO thick bright-silver B-pillar edge!)."""
    xs = np.linspace(-0.338, 0.608, 22)
    grid = []
    for x in xs:
        z_low = eval_z_shoulder(x) - 0.014
        if x > cfg.X_HEADER_SIDE:
            frac = np.clip((0.612 - x) / (0.612 - cfg.X_HEADER_SIDE), 0.0, 1.0)
            z_high = 0.888 + (cfg.Z_HEADER_SIDE - 0.888) * (frac ** 0.94)
        else:
            z_high = cfg.Z_HEADER_SIDE + 0.020 * math.sin(math.pi * np.clip((cfg.X_HEADER_SIDE - x) / 0.48, 0.0, 1.0))

        y_low = eval_y_belt(x) - 0.016
        y_high = y_low - (z_high - z_low) * 0.43
        row = []
        for s in np.linspace(0.0, 1.0, 10):
            bow = 0.012 * math.sin(math.pi * s)
            row.append((x, sign * (y_low + (y_high - y_low) * s + bow), z_low + (z_high - z_low) * s))
        grid.append(row)

    create_quad_grid(f"TSC_Glass_Door_{tag}", grid, material=mats["glass"], parent=door_piv, smooth=True, flip_faces=(sign > 0))


def build_doors(body_pivot: bpy.types.Object, mats: dict, include_door_cards: bool = False) -> dict:
    """Build hinged Pivot_Door_L and Pivot_Door_R with exact 3 mm dark-rimmed shutlines."""
    pivots = {}
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        name = f"Pivot_Door_{tag}"
        piv = ensure_empty(name, cfg.PIVOT_LOCATIONS[name], parent=body_pivot)
        pivots[name] = piv

        # Exact 1.8 mm panel gap matching body_shell door aperture X in [-0.490, +0.635]
        # Raycast every vertex directly onto _SHELL_UNRECESSED_BVH -> 0.000 mm Class-A seam continuity!
        xs_d = np.linspace(-0.4882, 0.6332, 32)
        ts = np.linspace(0.0, 1.0, 26)
        grid = []
        for x in xs_d:
            z_lo = 0.1765
            z_hi = float(eval_z_shoulder(x))
            row = []
            for t in ts:
                z = z_lo + (z_hi - z_lo) * (0.5 - 0.5 * math.cos(math.pi * t))
                y_val = query_side_surface_y(float(x), float(z), sign, unrecessed=True)
                row.append((float(x), sign * y_val, float(z)))
            grid.append(row)

        # Explicit outward winding (recalc_normals=False so open sheet never flips inward onto Solidify's dark slot 1!)
        # Grid axes: u = X increasing (-0.487 -> +0.632), v = Z increasing (0.178 -> shoulder).
        # Right-hand cross(dX, dZ) = (1,0,0) x (0,0,1) = (0,-1,0) (-Y = Right!).
        # So for LEFT (+Y) we flip_faces=True (+Y outward!), and for RIGHT (-Y) we flip_faces=False (-Y outward!)!
        ob = create_quad_grid(
            f"TSC_Door_Shell_{tag}",
            grid,
            material=[mats["paint"], mats["shadow"]],
            parent=piv,
            smooth=True,
            recalc_normals=False,
            flip_faces=(sign > 0),
        )
        sol = ob.modifiers.new("DoorThick", "SOLIDIFY")
        sol.thickness = 0.006
        sol.offset = -1.0
        sol.use_rim = True
        sol.material_offset = 1
        sol.material_offset_rim = 1
        # Split 90-deg shutline rim normals cleanly so outer Class-A door edges have ZERO vertical specular banding!
        es = ob.modifiers.new("EdgeSplit", "EDGE_SPLIT")
        es.split_angle = math.radians(40.0)

        # Gloss-black window-belt weatherstrip along top edge of door
        belt_pts = [(float(x), sign * (eval_y_belt(float(x)) - 0.005), eval_z_shoulder(float(x)) + 0.002) for x in np.linspace(-0.486, 0.631, 16)]
        create_tube(f"TSC_Door_BeltSeal_{tag}", belt_pts, radius=0.0065, segments=10, material=mats["gloss_black"], parent=piv)

        if include_door_cards:
            card_grid = []
            for x in np.linspace(-0.43, 0.56, 12):
                y_in = eval_y_belt(x) - 0.095
                z_top = eval_z_shoulder(x) - 0.020
                card_grid.append([
                    (x, sign * (y_in + 0.035), z_top),
                    (x, sign * y_in, z_top - 0.045),
                    (x, sign * (y_in - 0.025), 0.560),
                    (x, sign * (y_in - 0.010), 0.420),
                    (x, sign * (y_in + 0.015), 0.250),
                ])
            create_quad_grid(f"TSC_Door_Card_{tag}", card_grid, material=mats["cabin_leather"], parent=piv, smooth=True, flip_faces=(sign > 0))

        _build_side_mirror(sign, tag, piv, mats)
        _build_door_handle(sign, tag, piv, mats)
        _build_door_glass(sign, tag, piv, mats)

        # Lower door italic lowercase Turbonite 3D `t-hybrid` script emblem (B5: shifted +6 cm forward!)
        from .optics_and_badges import _LETTER_STROKES
        text = "t-hybrid"
        lw, lh, sp, sr = 0.020, 0.022, 0.0055, 0.0017
        italic = 0.28
        total_w = len(text) * lw + (len(text) - 1) * sp
        x_start = 0.425 + sign * (total_w * 0.5)
        b_verts, b_faces = [], []
        for idx, ch in enumerate(text):
            x_char = x_start - sign * idx * (lw + sp)
            for (u0, v0), (u1, v1) in _LETTER_STROKES.get(ch, []):
                x0 = x_char - sign * ((u0 + italic * v0) * lw)
                z0 = 0.260 + v0 * lh
                x1 = x_char - sign * ((u1 + italic * v1) * lw)
                z1 = 0.260 + v1 * lh
                dx, dz = x1 - x0, z1 - z0
                slen = max(math.hypot(dx, dz), 1e-6)
                nx, nz = -dz / slen * sr, dx / slen * sr
                y0 = sign * (query_side_surface_y(x0, z0, sign, unrecessed=True) + 0.0005)
                y1 = sign * (query_side_surface_y(x1, z1, sign, unrecessed=True) + 0.0005)
                y0o = y0 + sign * 0.0022
                y1o = y1 + sign * 0.0022
                bb = len(b_verts)
                b_verts.extend([
                    (x0 + nx, y0, z0 + nz), (x0 - nx, y0, z0 - nz), (x1 - nx, y1, z1 - nz), (x1 + nx, y1, z1 + nz),
                    (x0 + nx, y0o, z0 + nz), (x0 - nx, y0o, z0 - nz), (x1 - nx, y1o, z1 - nz), (x1 + nx, y1o, z1 + nz),
                ])
                b_faces.extend([
                    (bb + 4, bb + 5, bb + 6, bb + 7), (bb, bb + 1, bb + 5, bb + 4),
                    (bb + 1, bb + 2, bb + 6, bb + 5), (bb + 2, bb + 3, bb + 7, bb + 6), (bb + 3, bb, bb + 4, bb + 7),
                ])
        if b_verts:
            create_mesh_object(f"TSC_THybrid_Badge_{tag}", b_verts, b_faces, material=mats["turbonite"], parent=piv, smooth=False)

    return pivots


def build_fuel_flap(body_pivot: bpy.types.Object, mats: dict) -> dict:
    """
    100% FLUSH circular right-front fender fuel door hinged at its FRONT edge (+1.135)
    matching studio photo (26).jpeg:
      - Raycasted curved outer flap hugs right front fender seamlessly when closed
      - Opening Pivot_Fuel_Flap reveals the dark recessed circular filler bowl, sleek hinge arm,
        and stationary silver/black metallic fuel cap (Pivot_Fuel_Cap sibling of Pivot_Fuel_Flap)!
    """
    piv_flap = ensure_empty("Pivot_Fuel_Flap", cfg.PIVOT_LOCATIONS["Pivot_Fuel_Flap"], parent=body_pivot)
    piv_cap = ensure_empty("Pivot_Fuel_Cap", cfg.PIVOT_LOCATIONS["Pivot_Fuel_Cap"], parent=body_pivot)

    fx = FUEL_CENTER_X
    fz = FUEL_CENTER_Z
    r = FUEL_RADIUS - 0.002

    # Outward fender normal at fuel-door center (~36 deg upward from -Y)
    tilt = math.radians(36.0)
    ct, st = math.cos(tilt), math.sin(tilt)
    n_out = Vector((0.0, -ct, st)).normalized()
    u_x = Vector((1.0, 0.0, 0.0))
    v_tan = Vector((0.0, st, ct)).normalized()

    # Anchor on exact smooth un-recessed right fender skin
    y_est = -query_side_surface_y(fx, fz, -1.0, unrecessed=True)
    c_est = Vector((fx, y_est, fz))
    c_hit, _ = query_body_ray(c_est + n_out * 0.40, -n_out, unrecessed=True, max_dist=1.0)
    c_anchor = c_hit if c_hit is not None else c_est

    def _flap_pt(rx: float, rv: float, n_off: float = 0.0):
        base = c_anchor + u_x * (r * rx) + v_tan * (r * rv)
        hp, _ = query_body_ray(base + n_out * 0.40, -n_out, unrecessed=True, max_dist=1.0)
        p = (hp if hp is not None else base) + n_out * n_off
        return (float(p.x), float(p.y), float(p.z))

    n = 36
    angs = np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)
    ring_out = [_flap_pt(math.cos(a), math.sin(a), n_off=+0.0012) for a in angs]
    ring_in = [_flap_pt(math.cos(a), math.sin(a), n_off=-0.0045) for a in angs]
    c_out = _flap_pt(0.0, 0.0, n_off=+0.0018)
    c_in = _flap_pt(0.0, 0.0, n_off=-0.0045)

    verts = ring_out + ring_in + [c_out, c_in]
    faces = []
    for i in range(n):
        i2 = (i + 1) % n
        faces.append((2 * n, i, i2))
        faces.append((2 * n + 1, n + i2, n + i))
        faces.append((i, n + i, n + i2, i2))
    create_mesh_object("TSC_Fuel_Flap", verts, faces, material=mats["paint"], parent=piv_flap, smooth=True)

    # Dark curved hinge arm connecting flap inner face to front hinge Pivot_Fuel_Flap (photo 26!)
    p_hinge = Vector(cfg.PIVOT_LOCATIONS["Pivot_Fuel_Flap"])
    arm_pts = [
        (p_hinge.x, p_hinge.y + 0.012, p_hinge.z),
        (fx + 0.030, c_anchor.y + 0.018 * ct, c_anchor.z - 0.018 * st),
        (fx, c_anchor.y + 0.006 * ct, c_anchor.z - 0.006 * st),
    ]
    create_tube("TSC_Fuel_Flap_Arm", arm_pts, radius=0.006, segments=8, material=mats["matte_trim"], parent=piv_flap)

    # Recessed dark matte-black circular fuel-filler bowl & outer rubber seal (visible when flap opens!)
    bowl_grid = []
    for s in [0.0, 0.22, 0.68, 1.0]:
        rad = 1.04 - 0.14 * s
        off = +0.0005 - 0.048 * s
        bowl_grid.append([_flap_pt(rad * math.cos(a), rad * math.sin(a), n_off=off) for a in angs])
    create_quad_grid("TSC_Fuel_Filler_Bowl", bowl_grid, material=mats["shadow"], parent=body_pivot, cyclic_v=True, cap_u1=True)

    seam_pts = [_flap_pt(1.03 * math.cos(a), 1.03 * math.sin(a), n_off=0.0008) for a in angs]
    create_tube("TSC_Fuel_Filler_Seal", seam_pts, radius=0.0038, segments=8, material=mats["shadow"], parent=body_pivot, cyclic=True)

    # Recessed Porsche fuel filler neck + satin-silver/dark-chrome twist cap seated inside bowl (photo 26!)
    p_neck = c_anchor - n_out * 0.036
    p_cap = c_anchor - n_out * 0.022
    create_cylinder(
        "TSC_Fuel_Filler_Neck",
        (float(p_neck.x), float(p_neck.y), float(p_neck.z)),
        radius=0.032,
        depth=0.028,
        axis="Y",
        segments=24,
        material=mats["matte_trim"],
        parent=piv_cap,
    )
    cap_ob = create_cylinder(
        "TSC_Fuel_Cap",
        (float(p_cap.x), float(p_cap.y), float(p_cap.z)),
        radius=0.035,
        depth=0.018,
        axis="Y",
        segments=24,
        material=mats["turbonite"],
        parent=piv_cap,
        bevel=0.003,
    )
    cap_ob.rotation_euler = (-tilt, 0.0, 0.0)

    return {"Pivot_Fuel_Flap": piv_flap, "Pivot_Fuel_Cap": piv_cap}


def build_rear_lid(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    """Build Pivot_Rear_Lid: rear engine service decklid + 24-slat black longitudinal louvered cooling grille."""
    piv = ensure_empty("Pivot_Rear_Lid", cfg.PIVOT_LOCATIONS["Pivot_Rear_Lid"], parent=body_pivot)

    xs = np.linspace(-1.875, -1.440, 14)
    tray_grid = []
    for x in xs:
        gw = 0.545 - 0.075 * smootherstep(-1.44, -1.87, x)
        tray_grid.append([(x, u * gw, eval_rear_deck_z(x, u * gw) - 0.024) for u in np.linspace(-1.0, 1.0, 15)])
    create_quad_grid("TSC_Rear_Lid_Tray", tray_grid, material=mats["shadow"], parent=piv)

    bezel_pts = []
    for u in np.linspace(-1.0, 1.0, 12):
        bezel_pts.append((-1.442, u * 0.545, eval_rear_deck_z(-1.442, u * 0.545) - 0.002))
    for x in np.linspace(-1.460, -1.868, 8):
        gw = 0.545 - 0.075 * smootherstep(-1.44, -1.87, x)
        bezel_pts.append((x, gw, eval_rear_deck_z(x, gw) - 0.002))
    for u in np.linspace(1.0, -1.0, 12):
        bezel_pts.append((-1.872, u * 0.470, eval_rear_deck_z(-1.872, u * 0.470) - 0.002))
    for x in np.linspace(-1.868, -1.460, 8):
        gw = 0.545 - 0.075 * smootherstep(-1.44, -1.87, x)
        bezel_pts.append((x, -gw, eval_rear_deck_z(x, -gw) - 0.002))
    create_tube("TSC_Rear_Lid_Frame", bezel_pts, radius=0.009, segments=10, material=mats["matte_trim"], parent=piv, cyclic=True)

    # 24 crisp dark matte-black longitudinal vertical slats (B3: matte aero finish -> ZERO silver glare in view-12!)
    n_slats = 24
    slat_verts, slat_faces = [], []
    x_samples = np.linspace(-1.865, -1.450, 9)
    for k in range(n_slats):
        u = -0.94 + 1.88 * (k / (n_slats - 1))
        base_idx = len(slat_verts)
        for x in x_samples:
            gw = 0.538 - 0.074 * smootherstep(-1.44, -1.87, x)
            y = u * gw
            z_top = eval_rear_deck_z(x, y) - 0.004
            z_bot = z_top - 0.024
            w = 0.0045
            slat_verts.extend([(x, y - w, z_top), (x, y + w, z_top), (x, y + w, z_bot), (x, y - w, z_bot)])
        for i in range(len(x_samples) - 1):
            a = base_idx + 4 * i
            b = base_idx + 4 * (i + 1)
            slat_faces.extend([(a, b, b + 1, a + 1), (a + 1, b + 1, b + 2, a + 2), (a + 3, a + 2, b + 2, b + 3), (a, a + 3, b + 3, b)])
    create_mesh_object("TSC_Rear_Lid_Grille", slat_verts, slat_faces, material=mats["matte_trim"], parent=piv, smooth=False)

    return piv
