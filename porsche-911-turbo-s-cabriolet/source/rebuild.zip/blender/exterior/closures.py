"""
Hinged & Separable Exterior Closures for the 2026 Porsche 911 Turbo S Cabriolet (992.2):
  - Pivot_Front_Lid  : Precision-fitted 992 frunk hood (3 mm dark-rimmed shutline) + underside liner + Turbonite crest
  - Pivot_Door_L / R : Exact-match door shells (3 mm dark-rimmed shutline), SportDesign mirrors,
                       flush handles, frameless curved side glass, t-hybrid side script
  - Pivot_Fuel_Flap  : Circular right-front fender fuel door hinged at FRONT edge (per photo 26!) + Pivot_Fuel_Cap
  - Pivot_Rear_Lid   : Rear engine service decklid & 24-slat black longitudinal louvered cooling grille
"""

import math
import numpy as np
import bpy
from mathutils import Vector

from . import config as cfg
from .geom_utils import (
    ensure_empty,
    smootherstep,
    create_quad_grid,
    create_solidified_panel,
    create_mesh_object,
    create_rounded_box,
    create_cylinder,
    create_tube,
)
from .emblems import emblem
from .materials import make_pbr
from .body_shell import (
    eval_front_hood_z,
    eval_hood_hw,
    hood_front_rest,
    eval_flank_y,
    eval_y_max,
    eval_y_belt,
    eval_z_bot,
    eval_z_shoulder,
    eval_rear_deck_z,
    query_side_surface_y,
    query_body_ray,
    FUEL_CENTER_X,
    FUEL_CENTER_Z,
    FUEL_RADIUS,
    FUEL_GAP,
    fuel_ellipse,
)


def build_front_lid(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    """Build hinged Pivot_Front_Lid with exact 992 straight nose edge & crisp dark-rimmed 3 mm shutline."""
    piv = ensure_empty("Pivot_Front_Lid", cfg.PIVOT_LOCATIONS["Pivot_Front_Lid"], parent=body_pivot)

    # Dense rows toward the nose so the rounded front corners stay round.
    x_front = hood_front_rest()
    xs = 0.788 + (x_front - 0.0030 - 0.788) * np.sin(np.linspace(0.0, 1.0, 46) * math.pi / 2)
    us = np.linspace(-1.0, 1.0, 35)
    grid = []
    for x in xs:
        hood_hw = eval_hood_hw(x) - 0.0025
        row = []
        for u in us:
            y = u * hood_hw
            z = float(eval_front_hood_z(x, y))
            row.append((x, y, z))
        grid.append(row)

    ob = create_quad_grid("TSC_Front_Lid", grid, material=[mats["paint"], mats["shadow"]], parent=piv, smooth=True, recalc_normals=False, flip_faces=False)
    sol = ob.modifiers.new("HoodThick", "SOLIDIFY")
    sol.thickness = 0.005
    sol.offset = -1.0
    sol.use_rim = True
    sol.material_offset = 1
    sol.material_offset_rim = 1
    es = ob.modifiers.new("EdgeSplit", "EDGE_SPLIT")
    es.split_angle = math.radians(40.0)

    # Underside inner panel
    in_grid = []
    for x in np.linspace(0.84, x_front - 0.06, 12):
        hw = eval_hood_hw(x) - 0.05
        row = [(x, u * hw, float(eval_front_hood_z(x, u * hw)) - 0.015) for u in np.linspace(-1.0, 1.0, 11)]
        in_grid.append(row)
    create_quad_grid("TSC_Front_Lid_Inner", in_grid, material=mats["shadow"], parent=piv, flip_faces=True)

    # Crest: measured 9 cm behind the lid's front edge in the overhead frame (assembled x = 2.044).
    from .surface_fit import body_rest_of
    cx = float(body_rest_of([[2.044, 0.0, 0.53]])[0, 0])
    cz = float(eval_front_hood_z(cx, 0.0)) + 0.0025
    pitch = math.atan2(float(eval_front_hood_z(cx + 0.03, 0.0)) - float(eval_front_hood_z(cx - 0.03, 0.0)), 0.06)
    crest_pts = [
        (0.034,  0.000), (0.012,  0.021), (-0.022,  0.024), (-0.030,  0.018),
        (-0.030, -0.018), (-0.022, -0.024), (0.012, -0.021),
    ]
    verts_top, verts_bot = [], []
    cp, sp = math.cos(pitch), math.sin(pitch)
    for dx, dy in crest_pts:
        wx = cx + dx * cp
        wz = cz + dx * sp
        verts_bot.append((wx, dy, wz - 0.001))
        verts_top.append((wx - 0.0025 * sp, dy, wz + 0.0025 * cp))
    n = len(crest_pts)
    faces = [tuple(range(n, 2 * n))] + [(i, (i + 1) % n, n + (i + 1) % n, n + i) for i in range(n)]
    create_mesh_object("TSC_Nose_Crest", verts_bot + verts_top, faces, material=mats["turbonite"], parent=piv, smooth=False)

    return piv


def _build_side_mirror(sign: float, tag: str, door_piv: bpy.types.Object, mats: dict):
    """
    Sleek 992 SportDesign door-mounted mirror reaching exact WIDTH_MIRRORS = 2.033 m (|Y_tip| = 1.0165 m).
    B5: Shifted -4.7 cm aft (mx_base=0.398) & fuller vertical cap (rz=0.062) locking view-41 & view-35!
    """
    mx_base = 0.398
    mz_base = eval_z_shoulder(mx_base) - 0.036
    my_base = sign * (eval_flank_y(mx_base, mz_base) - 0.005)

    # Sturdy gloss-black aerodynamic base pedestal & V-stalk
    stalk_grid = []
    for t in np.linspace(0.0, 1.0, 10):
        sx = mx_base - 0.042 * t
        sy = sign * (abs(my_base) + 0.088 * t)
        sz = mz_base + 0.056 * t
        ax = 0.062 * (1.0 - 0.30 * t)
        az = 0.020 * (1.0 - 0.18 * t)
        ring = [(sx + ax * math.cos(a), sy, sz + az * math.sin(a)) for a in np.linspace(0.0, 2.0 * math.pi, 18, endpoint=False)]
        stalk_grid.append(ring)
    create_quad_grid(f"TSC_Mirror_Stalk_{tag}", stalk_grid, material=mats["gloss_black"], parent=door_piv, cyclic_v=True, cap_u0=True, cap_u1=True)

    # Loft from the rounded nose to a clipped rear face. The mirror glass and
    # its rubber gasket share this perimeter, including the swept outer corner.
    y_out=cfg.HALF_WIDTH_MIRRORS
    y_in=abs(my_base)+.028
    mid=(y_in+y_out)/2
    half=(y_out-y_in)/2
    perimeter=[]
    for a in np.linspace(0,2*math.pi,61)[:-1]:
        c,s=math.cos(a),math.sin(a)
        across=math.copysign(abs(c)**.62,c)
        height=math.copysign(abs(s)**.56,s)
        perimeter.append((across,height))
    def section(scale,forward):
        ring=[]
        for lateral,vertical in perimeter:
            u=lateral*scale
            z=mz_base+.096-.013*u+vertical*scale*(.058-.007*u)
            y=mid+half*u
            x=mx_base-.116-.039*u+.004*vertical+forward
            ring.append((x,sign*y,z))
        return ring
    cap=[section(a,b) for a,b in [(1,-.001),(.996,.012),(.94,.049),(.78,.080),
                                   (.53,.106),(.24,.118),(.04,.121)]]
    create_quad_grid(f"TSC_Mirror_{tag}",cap,material=mats["paint"],parent=door_piv,
                     cyclic_v=True,cap_u1=True)
    gasket=[section(1,-.001),section(.972,-.005),section(.898,-.005),section(.875,.003)]
    create_quad_grid(f"TSC_Mirror_Seal_{tag}",gasket,material=mats["gloss_black"],
                     parent=door_piv,cyclic_v=True)
    mirror=make_pbr("Mat_Exterior_Mirror_Glass","#a1aeb3",metallic=.69,roughness=.145,
                    coat_weight=.42,coat_roughness=.065)
    face=[section(.885,.002),section(.69,.0005),section(.38,-.0005),section(.035,-.001)]
    create_quad_grid(f"TSC_Mirror_Glass_{tag}",face,material=mirror,parent=door_piv,
                     cyclic_v=True,cap_u1=True)


def _build_door_handle(sign: float, tag: str, door_piv: bpy.types.Object, mats: dict):
    """Flush pull with an asymmetric thumb pocket on the rear of the door."""
    hx,hz=-.311,.710
    def position(u,v,depth):
        x=hx+u*.096+.010*v
        z=hz+v*.025
        y=query_side_surface_y(x,z,sign,unrecessed=True)
        return (x,sign*(y+depth),z)
    def contour(scale,offset,depth):
        return [position(scale*u,v*scale+offset,depth)
                for u,v in points]
    points=[]
    for a in np.linspace(0,2*math.pi,65)[:-1]:
        cs,sn=math.cos(a),math.sin(a)
        u=math.copysign(abs(cs)**.63,cs)
        v=math.copysign(abs(sn)**.65,sn)*(1-.28*max(0,u))
        points.append((u,v))
    pocket=[contour(1,0,.0015),contour(.95,0,.004),contour(.82,0,.006)]
    create_quad_grid(f"TSC_Door_Handle_Recess_{tag}",pocket,material=mats["gloss_black"],
                     parent=door_piv,cyclic_v=True,cap_u1=True)
    face=[contour(.92,.035,.005),contour(.85,.095,.009),
          contour(.61,.17,.011),contour(.20,.22,.012)]
    create_quad_grid(f"TSC_Door_Handle_{tag}",face,material=mats["paint"],parent=door_piv,
                     cyclic_v=True,cap_u1=True)


def _build_door_glass(sign: float, tag: str, door_piv: bpy.types.Object, mats: dict):
    """Frameless 992 Cabriolet door glass, built directly in assembled (post-fit) coordinates.

    Takes: side sign (+1 left), tag, the door pivot and the material table.
    Returns: nothing; creates TSC_Glass_Door_<tag>. The foot follows the fitted belt; the top
    follows the photo-measured window line (greenhouse.WINDOW_*) and, ahead of the header corner,
    runs 14 mm inboard of the windscreen side edge. surface_fit leaves this part where it is.
    """
    from . import greenhouse as gh
    pillar = gh.a_pillar_assembled(sign)
    order = np.argsort(pillar[:, 0])
    px, py, pz = pillar[order, 0], np.abs(pillar[order, 1]), pillar[order, 2]
    grid = []
    for c, x in enumerate(np.linspace(gh.GLASS_SPLIT_X + 0.004, 0.600, 28)):
        foot = gh.fitted(gh.belt_rest(x, sign))[0]
        xf = foot[0]
        # Rear columns lean back with the B-seal; the lean fades out over the first 30 cm.
        lean = (gh.GLASS_SPLIT_TOP_X - gh.GLASS_SPLIT_X) * float(gh.smooth01(1 - (x - gh.GLASS_SPLIT_X) / 0.30))
        window = gh.glass_top(xf + lean, sign, foot)
        window[0] = xf + lean
        pillar_top = np.array([xf, sign * (np.interp(xf, px, py) - 0.014), np.interp(xf, px, pz) - 0.006])
        blend = float(gh.smooth01((xf - gh.WINDOW_X[0]) / 0.09))
        top = window * (1 - blend) + pillar_top * blend
        if top[2] < foot[2] + 0.01:
            top[2] = foot[2] + 0.01
        row = []
        for s_ in np.linspace(0.0, 1.0, 10):
            q = foot + (top - foot) * s_
            q[1] += sign * 0.010 * math.sin(math.pi * s_)
            row.append(tuple(q))
        grid.append(row)
    create_quad_grid(f"TSC_Glass_Door_{tag}", grid, material=mats["glass"], parent=door_piv, smooth=True, flip_faces=(sign > 0))


def build_doors(body_pivot: bpy.types.Object, mats: dict, include_door_cards: bool = False) -> dict:
    """Build hinged Pivot_Door_L and Pivot_Door_R with exact 3 mm dark-rimmed shutlines."""
    pivots = {}
    for sign, tag in [(+1.0, "L"), (-1.0, "R")]:
        name = f"Pivot_Door_{tag}"
        piv = ensure_empty(name, cfg.PIVOT_LOCATIONS[name], parent=body_pivot)
        pivots[name] = piv

        # Exact 1.8 mm panel gap matching body_shell door aperture X in [-0.490, +0.635]
        # Raycast every vertex directly onto _SHELL_UNRECESSED_BVH -> 0.000 mm Class-A seam continuity!
        # Broad rear door radius and shallow sill crease from both side profiles.
        # Keep the material around that radius on the fixed rear quarter.
        xs_d = np.linspace(-.4882,.6332,43)
        ts=np.linspace(0,1,39)
        def door_edge_z(t):
            return .214+(.834-.214)*(1-math.cos(math.pi*t))*.5
        def limits(z):
            h=max(0,min(1,(z-.214)/.482))
            rounded=1-math.sqrt(max(0,1-(1-h)**2))
            lift=max(0,min(1,(z-.214)/.101))
            toe=1-math.sqrt(max(0,1-(1-lift)**2))
            return -.4882+.288*rounded,.6332-.054*toe
        def skin(x,z):
            y=query_side_surface_y(float(x),float(z),sign,unrecessed=True)
            return (x,sign*y,z)
        grid=[]
        for j,x0 in enumerate(xs_d):
            u=j/(len(xs_d)-1)
            row=[]
            for t in ts:
                z=door_edge_z(t)
                aft,fore=limits(z)
                x=aft+(fore-aft)*u
                z+=t**4*(float(eval_z_shoulder(x))-.834)
                row.append(skin(x,z))
            grid.append(row)
        def fixed_infill(name,rows):
            create_quad_grid(f"TSC_Fender_{name}_{tag}",
                             rows,material=mats["paint"],parent=body_pivot)
        for end,old,label in [(0,-.490,"Rear_Door_Return"),(-1,.635,"Front_Door_Return")]:
            rows=[]
            for x,y,z in grid[end]:
                seam=x+(-.003 if end==0 else .003)
                if abs(old-seam)<.002:
                    seam=old+(.0006 if end==0 else -.0006)
                rows.append([skin(a,z) for a in np.linspace(old,seam,10)])
            fixed_infill(label,rows)
        sill=[]
        for x in np.linspace(-.49,.635,55):
            sill.append([skin(x,z) for z in np.linspace(.175,.2115,5)])
        fixed_infill("Door_Sill",sill)
        # Jamb follows the actual door cut and remains visible with the door open.
        shut=[r[0] for r in grid]+grid[-1][1:]
        aft=list(reversed(grid[0]))+shut[1:]
        create_quad_grid(f"TSC_Door_Jamb_Return_{tag}",
                         [[(x,y-sign*.003,z),(x,y-sign*.035,z-.002)] for x,y,z in aft],
                         material=mats["shadow"],parent=body_pivot)

        # Explicit outward winding (recalc_normals=False so open sheet never flips inward onto Solidify's dark slot 1!)
        # Grid axes: u = X increasing (-0.487 -> +0.632), v = Z increasing (0.178 -> shoulder).
        # Right-hand cross(dX, dZ) = (1,0,0) x (0,0,1) = (0,-1,0) (-Y = Right!).
        # So for LEFT (+Y) we flip_faces=True (+Y outward!), and for RIGHT (-Y) we flip_faces=False (-Y outward!)!
        ob = create_quad_grid(
            f"TSC_Door_Shell_{tag}",
            grid,
            material=[mats["paint"], mats["shadow"]],
            parent=piv,
            smooth=True,
            recalc_normals=False,
            flip_faces=(sign > 0),
        )
        sol = ob.modifiers.new("DoorThick", "SOLIDIFY")
        sol.thickness = 0.006
        sol.offset = -1.0
        sol.use_rim = True
        sol.material_offset = 1
        sol.material_offset_rim = 1
        # Split 90-deg shutline rim normals cleanly so outer Class-A door edges have ZERO vertical specular banding!
        es = ob.modifiers.new("EdgeSplit", "EDGE_SPLIT")
        es.split_angle = math.radians(40.0)

        # Gloss-black window-belt weatherstrip along top edge of door
        belt_pts = [(float(x), sign * (eval_y_belt(float(x)) - 0.005), eval_z_shoulder(float(x)) + 0.002) for x in np.linspace(-0.486, 0.631, 16)]
        create_tube(f"TSC_Door_BeltSeal_{tag}", belt_pts, radius=0.0065, segments=10, material=mats["gloss_black"], parent=piv)

        if include_door_cards:
            card_grid = []
            for x in np.linspace(-0.43, 0.56, 12):
                y_in = eval_y_belt(x) - 0.095
                z_top = eval_z_shoulder(x) - 0.020
                card_grid.append([
                    (x, sign * (y_in + 0.035), z_top),
                    (x, sign * y_in, z_top - 0.045),
                    (x, sign * (y_in - 0.025), 0.560),
                    (x, sign * (y_in - 0.010), 0.420),
                    (x, sign * (y_in + 0.015), 0.250),
                ])
            create_quad_grid(f"TSC_Door_Card_{tag}", card_grid, material=mats["cabin_leather"], parent=piv, smooth=True, flip_faces=(sign > 0))

        _build_side_mirror(sign, tag, piv, mats)
        _build_door_handle(sign, tag, piv, mats)
        _build_door_glass(sign, tag, piv, mats)

        def door_badge(u,v,depth):
            x,z=.425-sign*u,.266+v
            y=query_side_surface_y(x,z,sign,unrecessed=True)
            return x,sign*(y+.002+depth),z
        emblem(f"TSC_THybrid_Badge_{tag}","t-hybrid",.185,.021,
               door_badge,mats["turbonite"],piv)

    return pivots


def build_fuel_flap(body_pivot: bpy.types.Object, mats: dict) -> dict:
    """Flush oval fuel door on the right front fender, hinged on its forward edge.

    Takes: the body pivot and the material table.
    Returns: {"Pivot_Fuel_Flap", "Pivot_Fuel_Cap"} empties. The door is a thin painted panel that
    follows the fender 1.5 mm proud of it, inset by the shut gap from the opening that
    body_shell._clip_bmesh_fuel_opening cuts. Behind it sit a dark recessed bowl with a rubber rim,
    the filler neck and the cap; the short hinge arm stays hidden behind the door until it opens.
    TSC_Fuel_Hinge_Ref rides the fit with the door so place_fuel_hinge can set the assembled hinge.
    """
    c, n, u, v, a_door, b_door = fuel_ellipse()
    a_d, b_d = a_door - 0.0005, b_door - 0.0005

    def on_skin(su, sv, offset=0.0):
        """Point on the un-recessed fender at tangent-plane offset (su, sv) plus a normal offset."""
        base = c + u * su + v * sv
        hit, _ = query_body_ray(base + n * 0.30, -n, unrecessed=True, max_dist=0.8)
        p = (hit if hit is not None else base) + n * offset
        return (float(p.x), float(p.y), float(p.z))

    # The page swings the flap about a vertical axis through its pivot: put it on the forward edge.
    hinge = Vector(on_skin(a_d * 1.0, 0.0, 0.0015))
    piv_flap = ensure_empty("Pivot_Fuel_Flap", tuple(hinge), parent=body_pivot)
    piv_cap = ensure_empty("Pivot_Fuel_Cap", on_skin(0.0, 0.0, -0.020), parent=body_pivot)

    nring = 48
    angs = np.linspace(0.0, 2.0 * math.pi, nring, endpoint=False)
    # Door panel: painted outer skin 1.5 mm proud with a rolled edge, and a black inner face 4 mm in
    # (the open-flap studio frame shows the flap's underside and arm in black).
    def ring(scale, off):
        if scale == 0.0:
            return [on_skin(0.0, 0.0, off)] * nring
        return [on_skin(a_d * scale * math.cos(t), b_d * scale * math.sin(t), off) for t in angs]
    outer = [ring(sc, off) for sc, off in [(0.0, 0.0018), (0.35, 0.0017), (0.70, 0.0016), (0.93, 0.0015), (1.0, 0.0006), (1.0, -0.0025)]]
    create_quad_grid("TSC_Fuel_Flap", outer, material=mats["paint"], parent=piv_flap, cyclic_v=True, smooth=True)
    inner = [ring(1.0, -0.0025), ring(0.93, -0.0028), ring(0.0, -0.0028)]
    create_quad_grid("TSC_Fuel_Flap_Inner", inner, material=mats["matte_trim"], parent=piv_flap, cyclic_v=True, smooth=True)

    # Hinge arm behind the forward edge: invisible when shut, swings out with the door.
    arm_pts = [on_skin(a_d * 0.98, 0.0, -0.012), on_skin(a_d * 0.80, 0.0, -0.016), on_skin(a_d * 0.45, 0.0, -0.006)]
    create_tube("TSC_Fuel_Flap_Arm", arm_pts, radius=0.0045, segments=8, material=mats["matte_trim"], parent=piv_flap)

    # Recessed bowl: its rim meets the cut edge of the skin, its floor sits 45 mm in; a black rubber
    # lip runs round the rim, as in the open-flap studio frame.
    a_o, b_o = a_door + FUEL_GAP, b_door + FUEL_GAP
    bowl = []
    for scale, off in [(1.0, 0.0004), (0.99, -0.006), (0.94, -0.022), (0.86, -0.040), (0.80, -0.045)]:
        bowl.append([on_skin(a_o * scale * math.cos(t), b_o * scale * math.sin(t), off) for t in angs])
    create_quad_grid("TSC_Fuel_Filler_Bowl", bowl, material=mats["matte_trim"], parent=body_pivot, cyclic_v=True, cap_u1=True)
    lip = [on_skin(a_o * 0.955 * math.cos(t), b_o * 0.955 * math.sin(t), -0.008) for t in angs]
    create_tube("TSC_Fuel_Filler_Seal", lip, radius=0.0045, segments=8, material=mats["tire"], parent=body_pivot, cyclic=True)

    # Filler neck and the satin cap seated in the bowl, both on the fender normal.
    tilt = math.atan2(-n.z, -n.y)
    p_neck = Vector(on_skin(0.0, 0.0, -0.036))
    p_cap = Vector(on_skin(0.0, 0.0, -0.022))
    neck = create_cylinder("TSC_Fuel_Filler_Neck", tuple(p_neck), radius=0.032, depth=0.028, axis="Y", segments=24,
                           material=mats["matte_trim"], parent=piv_cap)
    neck.rotation_euler = (tilt, 0.0, 0.0)
    cap_mat = make_pbr("Mat_Fuel_Cap_Satin", "#b4b8bd", metallic=0.85, roughness=0.30)
    cap_ob = create_cylinder("TSC_Fuel_Cap", tuple(p_cap), radius=0.035, depth=0.018, axis="Y", segments=24,
                             material=cap_mat, parent=piv_cap, bevel=0.003)
    cap_ob.rotation_euler = (tilt, 0.0, 0.0)

    # Hinge reference: hinge point, +/- along the forward edge, door centre, and a point off the skin.
    eps = 0.03
    hinge_ref = [on_skin(a_d, 0.0, 0.0015), on_skin(a_d, eps, 0.0015), on_skin(a_d, -eps, 0.0015),
                 on_skin(0.0, 0.0, 0.0015), on_skin(a_d, 0.0, 0.0015 + eps)]
    create_mesh_object("TSC_Fuel_Hinge_Ref", hinge_ref, [(0, 1, 3), (0, 3, 2), (0, 4, 1)], parent=piv_flap)

    return {"Pivot_Fuel_Flap": piv_flap, "Pivot_Fuel_Cap": piv_cap}


def place_fuel_hinge():
    """Put Pivot_Fuel_Flap on the assembled forward edge of the door and record its hinge axis.

    Takes: nothing; reads TSC_Fuel_Hinge_Ref, which the fit moved together with the door, then removes it.
    Returns: None. The pivot moves (its children keep their world positions) and gets the custom
    property hingeAxis (glTF axes, unit), about which the page swings the door outward.
    """
    ref, piv = bpy.data.objects.get("TSC_Fuel_Hinge_Ref"), bpy.data.objects.get("Pivot_Fuel_Flap")
    if ref is None or piv is None:
        return
    bpy.context.view_layer.update()
    hinge, up, down, centre, out = [ref.matrix_world @ vt.co for vt in ref.data.vertices]
    axis = (up - down).normalized()
    if axis.cross(centre - hinge).dot(out - hinge) < 0:
        axis = -axis
    shift = hinge - piv.matrix_world.translation
    piv.location += shift
    for child in piv.children:
        child.location -= shift
    bpy.data.objects.remove(ref, do_unlink=True)
    piv["hingeAxis"] = [round(axis.x, 6), round(axis.z, 6), round(-axis.y, 6)]
    bpy.context.view_layer.update()
    print(f"[fuel] hinge {tuple(round(x, 4) for x in hinge)} axis {tuple(round(x, 4) for x in axis)}")


def build_rear_lid(body_pivot: bpy.types.Object, mats: dict) -> bpy.types.Object:
    """Build Pivot_Rear_Lid: rear engine service decklid + 24-slat black longitudinal louvered cooling grille."""
    piv = ensure_empty("Pivot_Rear_Lid", cfg.PIVOT_LOCATIONS["Pivot_Rear_Lid"], parent=body_pivot)

    return piv
