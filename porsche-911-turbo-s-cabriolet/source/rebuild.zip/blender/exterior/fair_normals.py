"""Feature-preserving shading-normal fairing of the painted panels (vertex positions untouched).

The silhouette fit moves the parametric skin with many local corrections. Each one is small in
position but bends the surface normal by a few degrees over 10-50 cm, which glossy paint shows as
dents and whorls. This pass diffuses face normals over a chosen radius without mixing across
creases, then stores per-corner custom normals, so reflections run fair while every silhouette and
shut line stays exactly where the fit put it. Adapted from the Civic FK8 render fix.
"""
import math
import re
import numpy as np
import bpy

PAINT = 'Mat_Gentian_Blue_Metallic'
# Small, sharp-edged painted parts keep their own normals; smoothing them rounds their edges.
SKIP = re.compile(r"Door_Handle|Fuel_Flap|Outlet_Lip|Bumper_Lip|Door_Sill|Fender_Lip")
# Small, tightly curved painted parts are faired over a short radius only.
SMALL = re.compile(r"Mirror|Windshield_Frame|Cowl_Plenum|Lamp_Return")
SMALL_SIGMA_M = 0.03


def _unit(v):
    """Normalize rows of an (n,3) array; takes array, returns array."""
    return v / np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-12)


def _ring_pairs(key, owner):
    """Pairs of distinct owners that share a key (e.g. faces around a welded vertex).

    Takes: per-corner keys and per-corner owner ids (int arrays of equal length).
    Returns: (I, J) unique ordered owner pairs, both directions, I != J.
    """
    order = np.lexsort((owner, key))
    k, o = key[order], owner[order]
    I, J = [], []
    for s in range(1, 64):
        same = k[s:] == k[:-s]
        if not same.any():
            break
        I.append(o[s:][same]); J.append(o[:-s][same])
    if not I:
        return np.zeros(0, np.int64), np.zeros(0, np.int64)
    I = np.concatenate(I); J = np.concatenate(J)
    I, J = np.concatenate([I, J]), np.concatenate([J, I])
    keep = I != J
    m = int(owner.max()) + 1
    code = np.unique(I[keep].astype(np.int64) * m + J[keep])
    return code // m, code % m


def fair_mesh(me, sigma, crease_deg, weld):
    """Diffuse face normals of one mesh over radius sigma, respecting creases, and set custom normals.

    Takes: a bpy Mesh, smoothing radius sigma and weld tolerance (mesh units), crease angle (deg).
    Returns: mean change of face normal direction in degrees.
    """
    nv, nf, nl = len(me.vertices), len(me.polygons), len(me.loops)
    co = np.empty(nv * 3); me.vertices.foreach_get('co', co); co = co.reshape(-1, 3)
    _, wid = np.unique(np.round(co / weld).astype(np.int64), axis=0, return_inverse=True)
    wid = wid.ravel()
    lv = np.empty(nl, np.int64); me.loops.foreach_get('vertex_index', lv)
    lt = np.empty(nf, np.int64); me.polygons.foreach_get('loop_total', lt)
    lf = np.repeat(np.arange(nf), lt)
    fn = np.empty(nf * 3); me.polygons.foreach_get('normal', fn); fn = fn.reshape(-1, 3)
    fa = np.empty(nf); me.polygons.foreach_get('area', fa); fa = np.maximum(fa, 1e-12)
    I, J = _ring_pairs(wid[lv], lf)
    if not len(I):
        return 0.0
    fc = np.zeros((nf, 3))
    for c in range(3):
        fc[:, c] = np.bincount(lf, co[lv, c], nf) / lt
    # Find creases on a lightly pre-smoothed field so triangulation noise is not taken for one.
    near = np.einsum('ij,ij->i', fn[I], fn[J]) > math.cos(math.radians(60))
    Ip, Jp = I[near], J[near]
    d2p = np.mean(np.sum((fc[Ip] - fc[Jp]) ** 2, axis=1)) if len(Ip) else 1.0
    pre = fn.copy()
    for _ in range(int(min(200, max(1, (sigma * 0.15) ** 2 / (0.9 * d2p))))):
        acc = pre * fa[:, None]
        for c in range(3):
            acc[:, c] += np.bincount(Ip, fa[Jp] * pre[Jp, c], nf)
        pre = _unit(acc)
    keep = np.einsum('ij,ij->i', pre[I], pre[J]) > math.cos(math.radians(crease_deg))
    I, J = I[keep], J[keep]
    d2 = np.mean(np.sum((fc[I] - fc[J]) ** 2, axis=1)) if len(I) else 1.0
    iters = int(min(3000, max(1, sigma ** 2 / (0.9 * d2))))
    n = fn.copy()
    for _ in range(iters):
        acc = n * fa[:, None]
        for c in range(3):
            acc[:, c] += np.bincount(I, fa[J] * n[J, c], nf)
        n = _unit(acc)
    # Corner normals: filtered normals of the faces around the welded vertex within the crease fan.
    A, B = _ring_pairs(wid[lv], np.arange(nl))
    ok = np.einsum('ij,ij->i', n[lf[A]], n[lf[B]]) > math.cos(math.radians(crease_deg))
    acc = n[lf] * fa[lf][:, None]
    wb = fa[lf[B]] * ok
    for c in range(3):
        acc[:, c] += np.bincount(A, wb * n[lf[B], c], nl)
    ln = _unit(acc)
    me.shade_smooth()
    me.normals_split_custom_set(ln.tolist())
    return float(np.degrees(np.arccos(np.clip(np.einsum('ij,ij->i', n, fn), -1, 1))).mean())


def apply(scale, sigma_m=0.15, crease_deg=60.0):
    """Fair every painted panel in the scene; call after the export scale has been baked.

    Takes: the export scale (mesh units per metre), smoothing radius in metres, crease angle (deg).
    Returns: list of (object name, faces, mean degrees changed).
    """
    report = []
    for ob in bpy.data.objects:
        if ob.type != 'MESH' or len(ob.data.polygons) < 60:
            continue
        if PAINT not in [m.name for m in ob.data.materials if m] or SKIP.search(ob.name):
            continue
        radius = min(sigma_m, SMALL_SIGMA_M) if SMALL.search(ob.name) else sigma_m
        dev = fair_mesh(ob.data, radius * scale, crease_deg, 2e-5 * scale)
        report.append((ob.name, len(ob.data.polygons), round(dev, 2)))
        print(f"[fair_normals] {ob.name:44s} faces={len(ob.data.polygons):6d} mean change {dev:.2f} deg", flush=True)
    return report
