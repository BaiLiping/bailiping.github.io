"""Exterior body, aero, optics & convertible top package for the 2026 Porsche 911 Turbo S Cabriolet."""
