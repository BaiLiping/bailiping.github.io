"""
Standardized PBR Materials for the 2026 Porsche 911 Turbo S Cabriolet (992.2).
Material names match web/rig_contract.md Section 3 verbatim so the Three.js
viewer applies exact clearcoat, Fresnel glazing, planar mirror, and lighting tuning.
"""

import bpy


def _srgb_to_linear(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def hex_rgba(hex_str: str, alpha: float = 1.0):
    h = hex_str.lstrip("#")
    r = _srgb_to_linear(int(h[0:2], 16) / 255.0)
    g = _srgb_to_linear(int(h[2:4], 16) / 255.0)
    b = _srgb_to_linear(int(h[4:6], 16) / 255.0)
    return (r, g, b, alpha)


def make_pbr(
    name: str,
    hex_color: str,
    metallic: float = 0.0,
    roughness: float = 0.4,
    coat_weight: float = 0.0,
    coat_roughness: float = 0.08,
    alpha: float = 1.0,
    specular_ior: float = 0.5,
    emission_hex: str = None,
    emission_strength: float = 0.0,
    backface_cull: bool = False,
) -> bpy.types.Material:
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.use_backface_culling = backface_cull
    col = hex_rgba(hex_color, 1.0)
    mat.diffuse_color = (*col[:3], alpha)
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = col
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = roughness
    if "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = specular_ior
    if "Coat Weight" in bsdf.inputs and coat_weight > 0.0:
        bsdf.inputs["Coat Weight"].default_value = coat_weight
        bsdf.inputs["Coat Roughness"].default_value = coat_roughness
    if alpha < 1.0:
        bsdf.inputs["Alpha"].default_value = alpha
        if hasattr(mat, "blend_method"):
            mat.blend_method = "BLEND"
        if hasattr(mat, "surface_render_method"):
            mat.surface_render_method = "BLENDED"
    if emission_hex is not None and emission_strength > 0.0:
        bsdf.inputs["Emission Color"].default_value = hex_rgba(emission_hex, 1.0)
        bsdf.inputs["Emission Strength"].default_value = emission_strength
    return mat


def create_all_materials() -> dict:
    """Create and return the full standardized material dictionary."""
    mats = {}

    # 1. Exterior Paint — Gentian Blue Metallic (Porsche code 1A, B6 split-matched!)
    # Deep dark rich indigo-sapphire clearcoat matching 4K studio photos across every split line!
    mats["paint"] = make_pbr(
        "Mat_Gentian_Blue_Metallic",
        "#041038",
        metallic=0.74,
        roughness=0.22,
        coat_weight=0.70,
        coat_roughness=0.055,
        specular_ior=0.48,
    )

    # 2. Convertible Fabric Soft Top — Deep matte black woven canvas
    mats["soft_top"] = make_pbr(
        "Mat_SoftTop_Fabric",
        "#0e0f12",
        metallic=0.0,
        roughness=0.96,
        specular_ior=0.10,
    )

    # 3. Satin Turbonite — 992.2 Turbo S signature dark satin charcoal-bronze titanium (synced with @mechanicals #40!)
    mats["turbonite"] = make_pbr(
        "Mat_Turbonite_Alloy",
        "#45423e",
        metallic=0.88,
        roughness=0.28,
        coat_weight=0.16,
        coat_roughness=0.18,
    )

    # 4. Gloss Black Trim (mirror stalks, window seals, rear deck trim, headlight bezel)
    mats["gloss_black"] = make_pbr(
        "Mat_Gloss_Black_Trim",
        "#0c0e11",
        metallic=0.06,
        roughness=0.14,
        coat_weight=0.65,
        coat_roughness=0.06,
    )

    # 5. Satin / Matte Dark Trim (splitter, side skirts, diffuser, side scoop surround, wipers)
    mats["matte_trim"] = make_pbr(
        "Mat_Satin_Black_Aero",
        "#131518",
        metallic=0.02,
        roughness=0.72,
        specular_ior=0.20,
    )

    # 6. Front Active Flaps & Intake Mesh (viewer attenuates envMapIntensity = 0.22)
    mats["intake_grille"] = make_pbr(
        "Mat_Front_Honeycomb",
        "#17191c",
        metallic=0.05,
        roughness=0.52,
        specular_ior=0.28,
    )

    # 7. Deep Shadow / Wheelhouse Liner / Duct Plenum
    mats["shadow"] = make_pbr(
        "Mat_Wheelhouse_Plenum",
        "#0c0d0f",
        metallic=0.0,
        roughness=0.92,
        specular_ior=0.10,
    )

    # 8. Automotive Glazing (blended, zero transmission per GT3 single-pass viewer standard)
    mats["glass"] = make_pbr(
        "Mat_Automotive_Glass",
        "#121a20",
        metallic=0.02,
        roughness=0.06,
        coat_weight=0.65,
        coat_roughness=0.04,
        alpha=0.30,
        specular_ior=0.55,
    )
    mats["rear_glass"] = make_pbr(
        "Mat_Rear_Window_Smoke",
        "#10161b",
        metallic=0.02,
        roughness=0.06,
        coat_weight=0.65,
        coat_roughness=0.04,
        alpha=0.24,
        specular_ior=0.55,
    )
    mats["rear_window_frit"] = make_pbr(
        "Mat_Rear_Window_Frit", "#192025", roughness=.14, coat_weight=.50,
        alpha=.76, specular_ior=.5,
    )
    mats["quarter_glass"] = make_pbr(
        "Mat_Fixed_Quarter_Glass",
        "#121a20",
        metallic=0.02,
        roughness=0.06,
        coat_weight=0.65,
        coat_roughness=0.04,
        alpha=0.34,
        specular_ior=0.55,
    )
    mats["headlight_lens"] = make_pbr(
        "Mat_Headlight_Clear_Lens",
        "#0b1016",
        metallic=0.0,
        roughness=0.04,
        coat_weight=0.85,
        coat_roughness=0.03,
        alpha=0.28,
        specular_ior=0.65,
    )

    # 9. Lamp Optics & Emission
    mats["drl_white"] = make_pbr(
        "Mat_Headlight_DRL_LED",
        "#dce6f2",
        metallic=0.0,
        roughness=0.22,
        emission_hex="#ceddf0",
        emission_strength=1.25,
    )
    mats["taillight_red"] = make_pbr(
        "Mat_Taillight_Red_LED",
        "#b80c14",
        metallic=0.0,
        roughness=0.18,
        coat_weight=0.35,
        coat_roughness=0.08,
        emission_hex="#ee141c",
        emission_strength=3.2,
    )
    mats["taillight_smoked"] = make_pbr(
        "Mat_Taillight_Smoked_Housing",
        "#0a0b0e",
        metallic=0.10,
        roughness=0.24,
        coat_weight=0.35,
        coat_roughness=0.08,
    )
    mats["taillight_clear"] = make_pbr(
        "Mat_Taillight_Reverse_Blade",
        "#6e7680",
        metallic=0.20,
        roughness=0.24,
        coat_weight=0.40,
        coat_roughness=0.08,
    )
    mats["reflector_red"] = make_pbr(
        "Mat_Rear_Reflector_Red",
        "#75271c",
        metallic=0.10,
        roughness=0.34,
        coat_weight=0.26,
        coat_roughness=0.17,
        specular_ior=0.36,
    )
    mats["sidemarker"] = make_pbr(
        "Mat_SideMarker_Smoked",
        "#25282e",
        metallic=0.20,
        roughness=0.15,
        coat_weight=0.75,
    )
    mats["chrome"] = make_pbr(
        "Mat_Bright_Chrome_Optics",
        "#dce0e6",
        metallic=0.96,
        roughness=0.12,
    )
    mats["titanium"] = make_pbr(
        "Mat_Titanium_Exhaust_Bezel",
        "#504e4b",
        metallic=0.88,
        roughness=0.26,
    )

    # 10. License Plate & Badges (B4: matte Gentian Blue showplate — ZERO specular glare!)
    mats["plate_blue"] = make_pbr(
        "Mat_License_Plate_Blue",
        "#0b1c48",
        metallic=0.22,
        roughness=0.58,
        coat_weight=0.08,
        specular_ior=0.30,
    )
    mats["plate_white"] = make_pbr(
        "Mat_License_Plate_Text",
        "#eef0f4",
        metallic=0.05,
        roughness=0.32,
    )
    mats["porsche_lettering"] = make_pbr(
        "Mat_Rear_Porsche_Silver",
        "#9a9ea4",
        metallic=0.86,
        roughness=0.28,
    )

    # 11. Placeholder Wheel / PCCB Materials (used only during standalone exterior blockout)
    mats["tire"] = make_pbr("Mat_Tire_Rubber", "#1c1e20", metallic=0.0, roughness=0.78, specular_ior=0.22)
    mats["caliper_yellow"] = make_pbr("Mat_PCCB_Caliper_Yellow", "#e8b90e", metallic=0.15, roughness=0.20, coat_weight=0.75)
    mats["rotor"] = make_pbr("Mat_PCCB_Ceramic_Rotor", "#4d4f52", metallic=0.25, roughness=0.68)

    # 12. Cabin Materials (Black/Slate Leather, Turbonite Accent, Matte Carbon, Rearview Mirror)
    mats["cabin_leather"] = make_pbr("Mat_Cabin_Leather_Black", "#232529", metallic=0.0, roughness=0.58, specular_ior=0.30)
    mats["cabin_perforated"] = make_pbr("Mat_Cabin_Seat_Insert", "#1c1e22", metallic=0.0, roughness=0.74, specular_ior=0.22)
    mats["cabin_carpet"] = make_pbr("Mat_Cabin_Carpet", "#17181b", metallic=0.0, roughness=0.92, specular_ior=0.12)
    mats["cabin_carbon"] = make_pbr("Mat_Cabin_Matte_Carbon", "#292c31", metallic=0.25, roughness=0.36, coat_weight=0.20)
    mats["cabin_belt"] = make_pbr("Mat_Cabin_Seatbelt_Turbonite", "#8b8373", metallic=0.0, roughness=0.72)
    mats["cabin_screen"] = make_pbr(
        "Mat_Cabin_Display_Glass", "#10141a", metallic=0.05, roughness=0.08,
        coat_weight=0.80, emission_hex="#1c2a3a", emission_strength=0.45,
    )
    mats["cabin_rearview"] = make_pbr("Mat_Cabin_Rearview", "#c8d0d8", metallic=0.95, roughness=0.04)
    mats["red_accent"] = make_pbr("Mat_Cabin_Red_Accent", "#b81d24", metallic=0.10, roughness=0.35)

    return mats
