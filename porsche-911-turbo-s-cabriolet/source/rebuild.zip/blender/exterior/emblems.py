"""Raised outlines traced from Porsche 992652 configurator and launch photographs."""
import json
from pathlib import Path
import bpy
from mathutils import Vector


def emblem(name,profile,width,height,project,material,parent):
    outlines=json.loads(Path(__file__).with_name("emblem_outlines.json").read_text())
    offset = Vector((0,0,0))
    carrier = parent
    while carrier is not None:
        offset += carrier.location
        carrier = carrier.parent
    curve=bpy.data.curves.new(name,"CURVE")
    curve.dimensions="2D"
    curve.fill_mode="BOTH"
    curve.extrude=.0008
    for ring in outlines[profile]:
        spline=curve.splines.new("POLY")
        spline.points.add(len(ring)-1)
        for point,(u,v) in zip(spline.points,ring):
            point.co=(u*width,v*height,0,1)
        spline.use_cyclic_u=True
    temporary=bpy.data.objects.new(name+"_profile",curve)
    bpy.context.scene.collection.objects.link(temporary)
    evaluated=temporary.evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh=bpy.data.meshes.new_from_object(evaluated)
    bpy.data.objects.remove(temporary,do_unlink=True)
    bpy.data.curves.remove(curve)
    for vertex in mesh.vertices:
        u,v,d=vertex.co
        vertex.co=Vector(project(u,v,d))-offset
    mesh.update()
    mesh.materials.append(material)
    obj=bpy.data.objects.new(name,mesh)
    bpy.context.scene.collection.objects.link(obj)
    obj.parent=parent
