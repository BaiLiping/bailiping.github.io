"""Measure the front end's outline in metres from the studio masks, and the same for model meshes.

Takes: one or more label=mesh.npz pairs (extract_fit_mesh output), --out directory.
Returns: nothing; writes <out>/front_targets.json and <out>/front_targets.png. For the overhead
(42), right and left profiles (25, 04) and straight-on (35) frames, each outline is back-projected
onto a fixed plane through the calibrated camera:
  plan  : overhead contour on z = 0.55  -> half-width y(x) and nose x(y)
  side  : profile contours on y = -/+0.70 for the top line z(x), and y = 0 for the nose x(z)
  front : straight-on contour on x = 1.95 -> half-width y(z)
The photo and every model go through the same mapping, so their differences are comparable.
"""
import argparse
import json
import sys
from pathlib import Path
import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
import camgeo  # noqa: E402
from silscore import CAL, Raster, camera_axes  # noqa: E402

W = 1920
H = W * 9 // 16


def contour(mask):
    """Largest external contour of a bool mask, in native 3840-wide pixels; returns (n,2)."""
    cs, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    c = max(cs, key=cv2.contourArea)[:, 0, :].astype(float)
    return (c + 0.5) * 3840 / W


def model_masks(cams, views, path):
    """Masks of one mesh in each view, rendered in a context of its own; returns dict view -> mask."""
    r = Raster(dict(np.load(path, allow_pickle=True)), W, H)
    out = {}
    for view in views:
        eye, rot, focal = camera_axes(cams[view], H)
        out[view] = r.draw(eye, rot, focal, cams[view].get('roof', 'up')).copy()
    r.ctx.release()
    return out


def binned_max(a, b, edges, sign=1.0):
    """For bins of a, the extreme (max of sign*b) value of b; returns array (nan where empty)."""
    out = np.full(len(edges) - 1, np.nan)
    idx = np.digitize(a, edges) - 1
    for k in range(len(out)):
        sel = idx == k
        if sel.any():
            out[k] = sign * np.max(sign * b[sel])
    return out


def measure(curves):
    """Reduce back-projected contours to the tables listed in the module docstring; returns dict."""
    xs = np.round(np.arange(1.30, 2.30, 0.05), 3)
    ys = np.round(np.arange(0.0, 0.86, 0.05), 3)
    zs = np.round(np.arange(0.15, 1.00, 0.05), 3)
    half = lambda v: np.r_[v - 0.025, v[-1] + 0.025]
    res = {'x': xs.tolist(), 'y': ys.tolist(), 'z': zs.tolist()}
    plan = curves['plan']
    left, right = plan[plan[:, 1] > 0], plan[plan[:, 1] < 0]
    res['plan_halfwidth_left'] = binned_max(left[:, 0], left[:, 1], half(xs)).round(4).tolist()
    res['plan_halfwidth_right'] = (-binned_max(right[:, 0], -right[:, 1], half(xs))).round(4).tolist()
    res['plan_nose_x'] = binned_max(np.abs(plan[:, 1]), plan[:, 0], half(ys)).round(4).tolist()
    for side in ['side_right', 'side_left']:
        top = curves[side + '_top']
        res[side + '_top_z'] = binned_max(top[:, 0], top[:, 2], half(xs)).round(4).tolist()
        nose = curves[side + '_nose']
        res[side + '_nose_x'] = binned_max(nose[:, 2], nose[:, 0], half(zs)).round(4).tolist()
    fr = curves['front']
    res['front_halfwidth_left'] = binned_max(fr[:, 2], fr[:, 1], half(zs)).round(4).tolist()
    res['front_halfwidth_right'] = (-binned_max(fr[:, 2], -fr[:, 1], half(zs))).round(4).tolist()
    return res


def main():
    """Rasterise, back-project, tabulate, plot; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('meshes', nargs='+')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    cams = json.loads((CAL / 'cameras.json').read_text())
    rasters = dict(item.split('=') for item in a.meshes)
    views = {'plan': ('view-42', ('z', 0.55)), 'side_right_top': ('view-25', ('y', -0.70)),
             'side_right_nose': ('view-25', ('y', 0.0)), 'side_left_top': ('view-04', ('y', 0.70)),
             'side_left_nose': ('view-04', ('y', 0.0)), 'front': ('view-35', ('x', 1.95))}
    used = sorted({vv for vv, _ in views.values()})
    mk = {v: {'photo': cv2.resize(cv2.imread(cams[v]['mask_path'], 0), (W, H), interpolation=cv2.INTER_AREA) > 127}
          for v in used}
    for label, path in rasters.items():
        for v, m in model_masks(cams, used, path).items():
            mk[v][label] = m
    labels = ['photo'] + list(rasters)
    curves = {lab: {} for lab in labels}
    for key, (view, plane) in views.items():
        for lab in labels:
            curves[lab][key] = camgeo.backproject(view, contour(mk[view][lab]), plane)
    tables = {lab: measure(curves[lab]) for lab in labels}
    (out / 'front_targets.json').write_text(json.dumps(tables, indent=1))

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(2, 2, figsize=(16, 11))
    colors = {'photo': 'k'}
    palette = ['tab:red', 'tab:blue', 'tab:green', 'tab:orange']
    for k, lab in enumerate(rasters):
        colors[lab] = palette[k % len(palette)]
    for lab in labels:
        c = curves[lab]
        p = c['plan']; sel = p[:, 0] > 1.0
        ax[0, 0].plot(p[sel, 0], p[sel, 1], '.', ms=1.5, color=colors[lab], label=lab)
        t = c['side_right_top']; sel = (t[:, 0] > 0.8) & (t[:, 2] > 0.45)
        ax[0, 1].plot(t[sel, 0], t[sel, 2], '.', ms=1.5, color=colors[lab], label=lab)
        n = c['side_right_nose']; sel = n[:, 0] > 1.9
        ax[1, 0].plot(n[sel, 0], n[sel, 2], '.', ms=1.5, color=colors[lab], label=lab)
        f = c['front']
        ax[1, 1].plot(f[:, 1], f[:, 2], '.', ms=1.5, color=colors[lab], label=lab)
    titles = ['plan (overhead 42, z=0.55): x vs y', 'right profile top line (25, y=-0.70): x vs z',
              'right profile nose (25, y=0): x vs z', 'straight-on (35, x=1.95): y vs z']
    for axx, ttl in zip(ax.ravel(), titles):
        axx.set_title(ttl); axx.set_aspect('equal'); axx.grid(alpha=0.3); axx.legend(markerscale=8)
    ax[0, 0].set_xlim(1.0, 2.35); ax[0, 1].set_xlim(0.8, 2.35); ax[0, 1].set_ylim(0.45, 1.0)
    ax[1, 0].set_xlim(1.9, 2.35); ax[1, 0].set_ylim(0.0, 0.9)
    fig.tight_layout(); fig.savefig(out / 'front_targets.png', dpi=110)
    for lab in labels:
        t = tables[lab]
        print(lab, 'plan halfwidth L', t['plan_halfwidth_left'][4:], '\n   nose x(y)', t['plan_nose_x'][:16],
              '\n   top z(x) R', t['side_right_top_z'][4:], '\n   nose x(z) R', t['side_right_nose_x'][:14],
              '\n   front halfwidth(z) L', t['front_halfwidth_left'])


if __name__ == '__main__':
    main()
