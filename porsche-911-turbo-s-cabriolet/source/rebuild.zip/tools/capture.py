"""Capture model-only renders from the live page Compare registration, one per reference frame.

Takes: --origin (served page URL), --frames (comma list of indices or 'all' / 'ext'),
       --tag (output folder under refine/renders), --scale (viewport = native / scale).
Returns: nothing; writes renders/<tag>/<frame-id>.jpg at native/scale size and prints each saved path.
"""
import argparse
import io
import json
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright

REFINE = Path(__file__).resolve().parents[1]


def parse_frames(spec, views):
    """Turn a frame spec into a list of view indices; takes the spec string and view list, returns ints."""
    if spec == 'all':
        return list(range(len(views)))
    if spec == 'ext':
        return [i for i, v in enumerate(views) if v.get('group') == 'Exterior']
    out = []
    for part in spec.split(','):
        if '-' in part:
            a, b = part.split('-')
            out.extend(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return out


def main():
    """Drive Chrome through each requested frame with Compare on and the photo hidden; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('--origin', default='http://127.0.0.1:8873/')
    ap.add_argument('--frames', default='ext')
    ap.add_argument('--tag', required=True)
    ap.add_argument('--scale', type=float, default=2.0)
    ap.add_argument('--web', default=str(REFINE / 'web'))
    a = ap.parse_args()
    views = json.loads((Path(a.web) / 'porsche-views.json').read_text())
    out = REFINE / 'renders' / a.tag
    out.mkdir(parents=True, exist_ok=True)
    errors = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path='/usr/bin/google-chrome',
                                     args=['--enable-webgl', '--use-angle=gl', '--ignore-gpu-blocklist'])
        page = browser.new_page(viewport={'width': 1280, 'height': 720}, device_scale_factor=1, reduced_motion='reduce')
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('console', lambda m: errors.append('console ' + m.text) if m.type == 'error' else None)
        page.goto(a.origin + '?frame=0&compare=1#porsche-views')
        page.wait_for_function('window.__studioDiag?.loaded && document.documentElement.classList.contains("compare-photos")', timeout=120000)
        page.add_style_tag(content='#studio-header,#photo-footer,#comparison-controls,.photo-frame::after{display:none!important}'
                                   '#photo-room{inset:0!important;grid-template-rows:100%!important}#photo-room figure{width:100%;height:100%}')
        page.eval_on_selector('#comparison-split', 'el=>{el.value="0";el.dispatchEvent(new Event("input"))}')
        for i in parse_frames(a.frames, views):
            view = views[i]
            w, h = round(view['width'] / a.scale), round(view['height'] / a.scale)
            page.set_viewport_size({'width': w, 'height': h})
            page.locator('#photo-angle').select_option(index=i, force=True)
            page.wait_for_function('id=>document.querySelector("#photo").complete && document.querySelector("#photo").currentSrc.includes(id+".webp") && window.__studioDiag.selectedView===document.querySelector("#photo-angle").selectedOptions[0].text', arg=view['id'], timeout=60000)
            page.evaluate('()=>new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(done)))')
            page.wait_for_function('window.__studioDiag.framingSettled', timeout=60000)
            box = page.locator('.photo-frame').bounding_box()
            assert max(abs(box['width'] - w), abs(box['height'] - h), abs(box['x']), abs(box['y'])) < 1.5, (i, box, w, h)
            image = Image.open(io.BytesIO(page.screenshot(type='png'))).convert('RGB')
            path = out / (view['id'] + '.jpg')
            image.save(path, quality=93, subsampling=0)
            print(i, path, flush=True)
        browser.close()
    if errors:
        print('ERRORS:', errors[:20])


if __name__ == '__main__':
    main()
