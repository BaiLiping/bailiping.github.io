"""Fit the left headlamp outline as a 3D ellipse from its photo outlines in several calibrated frames.

Takes: mesh .npz (to seed the search from the current bezel), comma list of frame ids, --out JSON.
Returns: nothing; writes the fitted ellipse {center, normal, u_axis, a, b} in assembled Blender metres
and per-view chamfer errors, and saves overlay images next to the JSON.
"""
import argparse
import json
import sys
from pathlib import Path
import cv2
import numpy as np
from PIL import Image
from scipy.optimize import minimize

sys.path.insert(0, str(Path(__file__).parent))
import camgeo  # noqa: E402

REFINE = Path(__file__).resolve().parents[1]


def bezel_points(npz):
    """Left bezel tube vertices from the extracted mesh; takes path, returns (n,3)."""
    z = np.load(npz, allow_pickle=True)
    names = list(z['names'])
    i = names.index('TSC_Headlight_Bezel_L')
    return z['positions'][np.unique(z['triangles'][z['obj'] == i])]


def ellipse_from_params(p):
    """Build ellipse frame from params [cx,cy,cz, theta, phi, a, b, psi]; returns (c, n, u, v, a, b)."""
    c = np.array(p[:3]); th, ph, a, b, psi = p[3:]
    n = np.array([np.cos(ph) * np.cos(th), np.cos(ph) * np.sin(th), np.sin(ph)])
    ref = np.array([0.0, 1.0, 0.0])
    v0 = ref - n * (n @ ref); v0 /= np.linalg.norm(v0)
    u0 = np.cross(v0, n)
    u = np.cos(psi) * u0 + np.sin(psi) * v0
    v = np.cross(n, u)
    return c, n, u, v, a, b


def sample(p, k=96):
    """Sample k points on the ellipse; takes params, returns (k,3)."""
    c, n, u, v, a, b = ellipse_from_params(p)
    t = np.linspace(0, 2 * np.pi, k, endpoint=False)
    return c + np.outer(a * np.cos(t), u) + np.outer(b * np.sin(t), v)


def photo_outline(view, seed_px):
    """Find the lamp/paint boundary along rays from the seeded outline's centre.

    Takes: view id and the seeded projected outline (k,2) in native px.
    Returns: (edge points (m,2), distance map to them, crop offset, None).
    The boundary is where blueness B-(R+G)/2 rises from the neutral lamp to the blue paint.
    """
    img = np.asarray(Image.open(REFINE / 'web/porsche-views' / f'{view}.webp').convert('RGB')).astype(float) / 255
    img = cv2.GaussianBlur(img, (0, 0), 1.2)
    blue = img[..., 2] - 0.5 * (img[..., 0] + img[..., 1])
    c = seed_px.mean(0)
    pts = []
    for q in seed_px[::2]:
        d = q - c
        r = np.linalg.norm(d)
        if r < 5:
            continue
        d /= r
        ts = np.linspace(0.70 * r, 1.30 * r, 160)
        xy = c + np.outer(ts, d)
        ok = (xy[:, 0] >= 0) & (xy[:, 0] < img.shape[1] - 1) & (xy[:, 1] >= 0) & (xy[:, 1] < img.shape[0] - 1)
        if ok.sum() < 40:
            continue
        xy, tt = xy[ok], ts[ok]
        prof = blue[xy[:, 1].astype(int), xy[:, 0].astype(int)]
        hi = np.percentile(prof, 90); lo = np.percentile(prof, 10)
        if hi - lo < 0.04:
            continue
        thr = 0.5 * (hi + lo)
        cross = np.flatnonzero((prof[:-1] < thr) & (prof[1:] >= thr))
        if not len(cross):
            continue
        k = cross[np.argmin(np.abs(tt[cross] - r))]
        pts.append(xy[k])
    pts = np.array(pts)
    x0, y0 = np.floor(pts.min(0)).astype(int) - 150
    x1, y1 = np.ceil(pts.max(0)).astype(int) + 150
    x0, y0 = max(0, x0), max(0, y0)
    h, w = y1 - y0, x1 - x0
    edge = np.zeros((h, w), np.uint8)
    for q in (pts - [x0, y0]).astype(int):
        if 0 <= q[0] < w and 0 <= q[1] < h:
            edge[q[1], q[0]] = 1
    dist = cv2.distanceTransform((1 - edge).astype(np.uint8), cv2.DIST_L2, 5)
    return pts, dist, (x0, y0), None


def main():
    """Seed from the model bezel, extract outlines, optimise the 3D ellipse, report; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('mesh'); ap.add_argument('--views', default='view-35,view-36,view-37,view-38,view-00,view-01,view-42,view-41')
    ap.add_argument('--out', default=str(REFINE / 'renders/lamp_fit.json'))
    a = ap.parse_args()
    B = bezel_points(a.mesh)
    c0 = B.mean(0)
    U, S, Vt = np.linalg.svd(B - c0)
    n0 = Vt[2] if Vt[2][0] > 0 else -Vt[2]
    th0, ph0 = np.arctan2(n0[1], n0[0]), np.arcsin(n0[2])
    proj = (B - c0) @ Vt[:2].T
    a0, b0 = np.abs(proj[:, 0]).max(), np.abs(proj[:, 1]).max()
    p0 = np.array([*c0, th0, ph0, a0, b0, 0.0])
    # align psi to the SVD major axis
    _, _, u_ax, v_ax, _, _ = ellipse_from_params(p0)
    p0[7] = np.arctan2(Vt[0] @ v_ax, Vt[0] @ u_ax)
    data = {}
    for view in a.views.split(','):
        seed = camgeo.project(view, sample(p0))
        cont, dist, off, blob = photo_outline(view, seed)
        data[view] = (cont, dist, off)
        print(view, 'contour pts', len(cont), flush=True)

    def cost(p, report=False):
        """Mean two-way chamfer distance (px) over views; takes params, returns float or dict."""
        if p[5] <= 0.02 or p[6] <= 0.02:
            return 1e6
        pts = sample(p, 128)
        errs = {}
        for view, (cont, dist, off) in data.items():
            q = camgeo.project(view, pts) - off
            qi = np.clip(np.round(q).astype(int), 0, np.array(dist.shape[::-1]) - 1)
            d1 = dist[qi[:, 1], qi[:, 0]]
            # contour -> projected polyline distance
            seg = np.concatenate([q, q[:1]])
            cc = cont - off
            d2 = np.min(np.linalg.norm(cc[:, None, :] - seg[None, :, :], axis=2), axis=1)
            errs[view] = float(np.mean(np.minimum(d1, 30))) * 0.5 + float(np.mean(np.minimum(d2, 30))) * 0.5
        return errs if report else float(np.mean(list(errs.values())))

    print('start', round(cost(p0), 2), flush=True)
    res = minimize(cost, p0, method='Nelder-Mead', options={'maxiter': 3000, 'xatol': 1e-5, 'fatol': 1e-3})
    p = res.x
    print('final', round(res.fun, 2), flush=True)
    c, n, u, v, A, Bm = ellipse_from_params(p)
    out = {'center': c.tolist(), 'normal': n.tolist(), 'u_axis': u.tolist(), 'v_axis': v.tolist(), 'a': A, 'b': Bm,
           'start': cost(p0, True), 'per_view': cost(p, True), 'params': p.tolist()}
    Path(a.out).write_text(json.dumps(out, indent=1))
    for view, (cont, dist, off) in data.items():
        img = Image.open(REFINE / 'web/porsche-views' / f'{view}.webp').convert('RGB')
        arr = np.asarray(img).copy()
        q0 = camgeo.project(view, sample(p0, 256)).astype(int)
        q1 = camgeo.project(view, sample(p, 256)).astype(int)
        cv2.polylines(arr, [cont.astype(np.int32)], True, (0, 255, 255), 2)
        cv2.polylines(arr, [q0], True, (255, 160, 0), 2)
        cv2.polylines(arr, [q1], True, (255, 0, 0), 2)
        x0, y0 = q1.min(0) - 120; x1, y1 = q1.max(0) + 120
        Image.fromarray(arr[max(0, y0):y1, max(0, x0):x1]).save(str(Path(a.out).with_name(f'lampfit_{view}.jpg')), quality=88)


if __name__ == '__main__':
    main()
