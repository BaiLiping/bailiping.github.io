"""Render surface-quality checks of the Blender master through the saved reference cameras.

Run: blender -b <master.blend> --python blender_look.py -- --frames view-00,view-35 --out DIR [--mode zebra|gloss] [--scale 0.5]
Takes: the master .blend (opened by Blender), frame ids, output dir, mode and resolution scale.
Returns: nothing; writes DIR/<frame>-<mode>.png. 'zebra' turns the paint into a mirror under horizontal
stripes so that panel waviness shows as bent stripes; 'gloss' uses a dark glossy clearcoat under a softbox.
"""
import sys
import argparse
from pathlib import Path
import bpy


def args():
    """Parse the arguments after '--'; returns an argparse namespace."""
    argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    p = argparse.ArgumentParser()
    p.add_argument('--frames', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--mode', default='zebra')
    p.add_argument('--scale', type=float, default=0.5)
    p.add_argument('--samples', type=int, default=32)
    return p.parse_args(argv)


def world(mode):
    """Build a procedural environment: stripes for zebra, softbox+horizon for gloss; returns None."""
    w = bpy.data.worlds.new('look') if 'look' not in bpy.data.worlds else bpy.data.worlds['look']
    bpy.context.scene.world = w
    w.use_nodes = True
    nt = w.node_tree
    nt.nodes.clear()
    out = nt.nodes.new('ShaderNodeOutputWorld')
    bg = nt.nodes.new('ShaderNodeBackground')
    geo = nt.nodes.new('ShaderNodeTexCoord')
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    nt.links.new(geo.outputs['Generated'], sep.inputs[0])
    if mode == 'zebra':
        # stripes in elevation: sin(k*z_dir) thresholded
        math1 = nt.nodes.new('ShaderNodeMath'); math1.operation = 'MULTIPLY'; math1.inputs[1].default_value = 40.0
        sin = nt.nodes.new('ShaderNodeMath'); sin.operation = 'SINE'
        gt = nt.nodes.new('ShaderNodeMath'); gt.operation = 'GREATER_THAN'; gt.inputs[1].default_value = 0.0
        nt.links.new(sep.outputs['Z'], math1.inputs[0])
        nt.links.new(math1.outputs[0], sin.inputs[0])
        nt.links.new(sin.outputs[0], gt.inputs[0])
        nt.links.new(gt.outputs[0], bg.inputs['Strength'])
        bg.inputs['Color'].default_value = (1, 1, 1, 1)
    else:
        # bright overhead softbox + horizon wall, dim floor
        ramp = nt.nodes.new('ShaderNodeValToRGB')
        r = ramp.color_ramp
        r.elements[0].position = 0.0; r.elements[0].color = (0.25, 0.25, 0.26, 1)
        r.elements[1].position = 1.0; r.elements[1].color = (2.6, 2.6, 2.7, 1)
        e = r.elements.new(0.5); e.color = (0.6, 0.62, 0.65, 1)
        e = r.elements.new(0.53); e.color = (1.4, 1.42, 1.45, 1)
        e = r.elements.new(0.75); e.color = (0.9, 0.9, 0.95, 1)
        mapr = nt.nodes.new('ShaderNodeMapRange')
        mapr.inputs['From Min'].default_value = -1.0
        mapr.inputs['From Max'].default_value = 1.0
        nt.links.new(sep.outputs['Z'], mapr.inputs['Value'])
        nt.links.new(mapr.outputs['Result'], ramp.inputs['Fac'])
        nt.links.new(ramp.outputs['Color'], bg.inputs['Color'])
        bg.inputs['Strength'].default_value = 1.0
    nt.links.new(bg.outputs[0], out.inputs[0])


def paint(mode):
    """Replace the body paint with a mirror (zebra) or dark clearcoat (gloss); returns None."""
    mat = bpy.data.materials.get('Mat_Gentian_Blue_Metallic')
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    b = nt.nodes.new('ShaderNodeBsdfPrincipled')
    if mode == 'zebra':
        b.inputs['Base Color'].default_value = (0.9, 0.9, 0.9, 1)
        b.inputs['Metallic'].default_value = 1.0
        b.inputs['Roughness'].default_value = 0.02
    else:
        b.inputs['Base Color'].default_value = (0.012, 0.03, 0.12, 1)
        b.inputs['Metallic'].default_value = 0.6
        b.inputs['Roughness'].default_value = 0.35
        b.inputs['Coat Weight'].default_value = 1.0
        b.inputs['Coat Roughness'].default_value = 0.03
    nt.links.new(b.outputs[0], out.inputs[0])


def main():
    """Configure renderer, then render every requested frame through its saved camera; returns None."""
    a = args()
    sc = bpy.context.scene
    sc.render.engine = 'CYCLES'
    sc.cycles.device = 'GPU'
    prefs = bpy.context.preferences.addons['cycles'].preferences
    prefs.compute_device_type = 'OPTIX'
    prefs.get_devices_for_type('OPTIX')
    for d in prefs.devices:
        d.use = d.type == 'OPTIX'
    sc.cycles.samples = a.samples
    sc.cycles.use_denoising = True
    sc.render.film_transparent = False
    sc.view_settings.view_transform = 'Standard'
    world(a.mode)
    paint(a.mode)
    for ob in bpy.data.objects:
        if ob.type == 'LIGHT':
            ob.hide_render = True
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    for fid in a.frames.split(','):
        cam = bpy.data.objects[fid]
        sc.camera = cam
        sc.render.resolution_x = int(cam['reference_width'] * a.scale)
        sc.render.resolution_y = int(cam['reference_height'] * a.scale)
        sc.render.resolution_percentage = 100
        down = cam.get('roof_state', 'up') == 'down'
        for ob in bpy.data.objects:
            n = ob.name
            if n.startswith('Pivot_Soft_Top_Stowed'):
                for o in [ob, *ob.children_recursive]:
                    o.hide_render = not down
            elif n == 'Pivot_Soft_Top':
                for o in [ob, *ob.children_recursive]:
                    o.hide_render = down
        sc.render.filepath = str(out / f'{fid}-{a.mode}.png')
        bpy.ops.render.render(write_still=True)
        print('saved', sc.render.filepath, flush=True)


main()
