"""Fit the fuel-door outline (an ellipse lying on the fender) to its shut line in the studio frames.

Takes: mesh .npz of a build without the fender pocket, --views, --seed "x,y,z,r" (assembled metres).
Returns: nothing; writes blender/exterior/fuel_fit.json (assembled centre and 64-point outline, the
build input) and renders/fuel_fit.json with the assembled centre, tangent frame,
semi-axes a (along the car) and b (up the fender), in-plane angle psi and per-view chamfer errors,
plus overlay crops renders/fuelfit_<view>.jpg.
The shut line is found along rays from the seeded centre as the darkest pixel near the seed radius.
"""
import argparse
import json
import sys
from pathlib import Path
import cv2
import numpy as np
from PIL import Image
from scipy.optimize import minimize

sys.path.insert(0, str(Path(__file__).parent))
import camgeo  # noqa: E402

REFINE = Path(__file__).resolve().parents[1]


def local_surface(npz, centre):
    """Tangent frame and quadratic height field of the shell near a point.

    Takes: mesh path and an assembled point (3,). Returns: (c, n, u, v, coeffs) with n outward (-y side),
    u along +x in the tangent plane, v up the fender, and w = coeffs @ [1,s,t,s2,st,t2].
    """
    T = camgeo.mesh_tris(npz, r'^TSC_Body_Shell$')
    P = T.reshape(-1, 3)
    P = P[np.linalg.norm(P - centre, axis=1) < 0.22]
    c = P.mean(0)
    _, _, Vt = np.linalg.svd(P - c)
    n = Vt[2] if Vt[2][1] < 0 else -Vt[2]
    u = np.array([1.0, 0, 0]) - n * n[0]; u /= np.linalg.norm(u)
    v = np.cross(n, u)
    if v[2] < 0:
        v = -v
    L = (P - c) @ np.column_stack([u, v, n])
    s, t, w = L.T
    A = np.column_stack([np.ones_like(s), s, t, s * s, s * t, t * t])
    coeffs = np.linalg.lstsq(A, w, rcond=None)[0]
    return c, n, u, v, coeffs


def ellipse_points(p, frame, k=96):
    """World points of the tangent-plane ellipse p=(s0,t0,a,b,psi) dropped onto the quadratic skin."""
    c, n, u, v, co = frame
    s0, t0, a, b, psi = p
    th = np.linspace(0, 2 * np.pi, k, endpoint=False)
    s = s0 + a * np.cos(th) * np.cos(psi) - b * np.sin(th) * np.sin(psi)
    t = t0 + a * np.cos(th) * np.sin(psi) + b * np.sin(th) * np.cos(psi)
    w = np.column_stack([np.ones_like(s), s, t, s * s, s * t, t * t]) @ co
    return c + np.outer(s, u) + np.outer(t, v) + np.outer(w, n)


def shut_line(view, seed_px):
    """Shut-line points: along rays from the seeded outline's centre, the strongest narrow dark line.

    Takes: view id and the projected seed outline (k,2). Returns (m,2) px. The line response is
    min(mean of both flanks 4-8 px away) minus the centre value, so one-sided edges (tyre, glass) score 0.
    """
    from scipy.ndimage import map_coordinates
    img = np.asarray(Image.open(REFINE / 'web/porsche-views' / f'{view}.webp').convert('L')).astype(float)
    img = cv2.GaussianBlur(img, (0, 0), 0.8)
    cen = seed_px.mean(0)
    pts = []
    for q in seed_px:
        d = q - cen; r = np.linalg.norm(d)
        if r < 8:
            continue
        d /= r
        ts = np.arange(0.50 * r, 1.40 * r, 0.5)
        xy = cen + np.outer(ts, d)
        if xy[:, 0].min() < 10 or xy[:, 1].min() < 10 or xy[:, 0].max() > img.shape[1] - 10 or xy[:, 1].max() > img.shape[0] - 10:
            continue
        prof = map_coordinates(img, [xy[:, 1], xy[:, 0]], order=1)
        k = np.arange(16, len(prof) - 16)
        left = np.mean([prof[k - j] for j in range(8, 17)], axis=0)
        right = np.mean([prof[k + j] for j in range(8, 17)], axis=0)
        resp = np.minimum(left, right) - prof[k]
        best = int(np.argmax(resp))
        if resp[best] < 12:
            continue
        pts.append(xy[k[best]])
    return np.array(pts)


def main():
    """Seed, detect, fit, report; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('mesh')
    ap.add_argument('--views', default='view-22,view-23,view-24,view-25,view-26,view-27,view-28,view-40,view-42,view-41')
    ap.add_argument('--seed', default='0.905,-0.834,0.773,0.095')
    a = ap.parse_args()
    sx, sy, sz, sr = map(float, a.seed.split(','))
    frame = local_surface(a.mesh, np.array([sx, sy, sz]))
    c = frame[0]
    p0 = np.array([*((np.array([sx, sy, sz]) - c) @ np.column_stack([frame[2], frame[3]])), sr, sr, 0.0])
    data = {}
    for view in a.views.split(','):
        seed = camgeo.project(view, ellipse_points(p0, frame))
        pts = shut_line(view, seed)
        if len(pts) < 20:
            print('skip', view, len(pts)); continue
        data[view] = pts
        print(view, 'shut-line points', len(pts), flush=True)

    def cost(p, report=False):
        """Two-way capped chamfer (px) between projected ellipse and detected shut-line points."""
        if p[2] < 0.04 or p[3] < 0.03:
            return 1e6
        errs = {}
        for view, pts in data.items():
            q = camgeo.project(view, ellipse_points(p, frame, 160))
            d1 = np.minimum(np.min(np.linalg.norm(q[:, None] - pts[None], axis=2), axis=1), 25)
            d2 = np.minimum(np.min(np.linalg.norm(pts[:, None] - q[None], axis=2), axis=1), 25)
            errs[view] = 0.5 * float(d1.mean()) + 0.5 * float(d2.mean())
        return errs if report else float(np.mean(list(errs.values())))

    print('start', round(cost(p0), 2))
    res = minimize(cost, p0, method='Nelder-Mead', options={'maxiter': 3000, 'xatol': 1e-5, 'fatol': 1e-4})
    p = res.x
    per = cost(p, True)
    print('final', round(res.fun, 2), {k: round(v_, 1) for k, v_ in per.items()})
    cc, n, u, v, co = frame
    centre = ellipse_points(np.array([p[0], p[1], 1e-6, 1e-6, 0.0]), frame, 4).mean(0)
    out = {'centre': centre.tolist(), 'n': n.tolist(), 'u': u.tolist(), 'v': v.tolist(),
           'a': float(p[2]), 'b': float(p[3]), 'psi': float(p[4]), 'per_view': per}
    (REFINE / 'renders/fuel_fit.json').write_text(json.dumps(out, indent=1))
    build_input = {'note': 'Fuel-door outline on the assembled right fender, fitted by tools/fit_fuel.py',
                   'views': sorted(per), 'chamfer_px': {k: round(v_, 2) for k, v_ in per.items()},
                   'centre': centre.tolist(), 'outline': np.round(ellipse_points(p, frame, 64), 6).tolist()}
    (REFINE / 'blender/exterior/fuel_fit.json').write_text(json.dumps(build_input, indent=1) + '\n')
    print(json.dumps({k: (np.round(v_, 4).tolist() if isinstance(v_, list) else v_) for k, v_ in out.items() if k != 'per_view'}))
    for view, pts in data.items():
        arr = np.asarray(Image.open(REFINE / 'web/porsche-views' / f'{view}.webp').convert('RGB')).copy()
        q0 = camgeo.project(view, ellipse_points(p0, frame, 200)).astype(np.int32)
        q1 = camgeo.project(view, ellipse_points(p, frame, 200)).astype(np.int32)
        cv2.polylines(arr, [q0], True, (255, 160, 0), 2)
        cv2.polylines(arr, [q1], True, (255, 0, 0), 2)
        for pt in pts.astype(int):
            cv2.circle(arr, tuple(pt), 2, (0, 255, 255), -1)
        x0, y0 = q1.min(0) - 90; x1, y1 = q1.max(0) + 90
        Image.fromarray(arr[max(0, y0):y1, max(0, x0):x1]).save(REFINE / f'renders/fuelfit_{view}.jpg', quality=88)


if __name__ == '__main__':
    main()
