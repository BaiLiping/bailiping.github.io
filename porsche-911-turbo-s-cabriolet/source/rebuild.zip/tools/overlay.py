"""Draw the projected boundary edges of chosen model parts over a reference photo.

Takes: mesh .npz (extract_fit_mesh output), view id, regex of object names, crop box (native px),
       output path, optional --width and --color. Several --parts/--color pairs may be given.
Returns: nothing; writes a JPEG. Boundary edges are edges used by one triangle (open borders,
         e.g. glass outlines); no occlusion test, so hidden borders also show.
"""
import argparse
import re
import sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).parent))
import camgeo  # noqa: E402

REFINE = Path(__file__).resolve().parents[1]
SHARP = 0.0


def boundary_segments(z, pattern):
    """Collect boundary edge segments (k,2,3) of objects whose names match pattern; returns array."""
    names = list(z['names']); tri = z['triangles']; fo = z['obj']; pos = z['positions']
    segs = []
    for i, n in enumerate(names):
        if not re.search(pattern, n):
            continue
        t = tri[fo == i]
        if not len(t):
            continue
        # weld coincident vertices so that seams of split normals do not count as borders
        _, wid = np.unique(np.round(pos[t.ravel()] / 1e-5).astype(np.int64), axis=0, return_inverse=True)
        tw = wid.reshape(-1, 3)
        e = np.concatenate([tw[:, [0, 1]], tw[:, [1, 2]], tw[:, [2, 0]]])
        e.sort(axis=1)
        u, inv, c = np.unique(e, axis=0, return_inverse=True, return_counts=True)
        rep = np.zeros(wid.max() + 1, int); rep[wid] = t.ravel()
        b = u[c == 1]
        segs.append(pos[rep[b]])
        if SHARP:
            # sharp edges: two faces whose normals differ by more than SHARP degrees
            P = pos[t]
            fn = np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0])
            fn /= np.maximum(np.linalg.norm(fn, axis=1, keepdims=True), 1e-12)
            face_of = np.tile(np.arange(len(t)), 3)
            inv = inv.ravel()
            order = np.argsort(inv, kind='stable')
            inv_s, f_s = inv[order], face_of[order]
            first = np.r_[True, inv_s[1:] != inv_s[:-1]]
            idx = np.flatnonzero(first)
            pair = idx[(np.diff(np.r_[idx, len(inv_s)]) == 2)]
            fa, fb = f_s[pair], f_s[pair + 1]
            cosang = np.einsum('ij,ij->i', fn[fa], fn[fb])
            sharp = cosang < np.cos(np.radians(SHARP))
            segs.append(pos[rep[u[inv_s[pair][sharp]]]])
    return np.concatenate(segs) if segs else np.zeros((0, 2, 3))


def main():
    """Parse args, project segments for every part group and draw over the cropped photo; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('mesh'); ap.add_argument('view'); ap.add_argument('--box', default='0,0,3840,2160')
    ap.add_argument('--parts', action='append', required=True); ap.add_argument('--color', action='append')
    ap.add_argument('--width', type=int, default=1400); ap.add_argument('--out', required=True)
    ap.add_argument('--sharp', type=float, default=0.0)
    a = ap.parse_args()
    global SHARP
    SHARP = a.sharp
    z = np.load(a.mesh, allow_pickle=True)
    photo = Image.open(REFINE / 'web/porsche-views' / f'{a.view}.webp').convert('RGB')
    x, y, w, h = map(int, a.box.split(','))
    s = a.width / w
    im = photo.crop((x, y, x + w, y + h)).resize((a.width, round(h * s)), Image.LANCZOS)
    d = ImageDraw.Draw(im)
    colors = a.color or ['#ff2020', '#20ff40', '#ffe020', '#20c0ff']
    for k, pat in enumerate(a.parts):
        segs = boundary_segments(z, pat)
        if not len(segs):
            continue
        p = camgeo.project(a.view, segs.reshape(-1, 3)).reshape(-1, 2, 2)
        for (p0, p1) in p:
            d.line([((p0[0] - x) * s, (p0[1] - y) * s), ((p1[0] - x) * s, (p1[1] - y) * s)],
                   fill=colors[k % len(colors)], width=2)
    im.save(a.out, quality=90)


if __name__ == '__main__':
    main()
