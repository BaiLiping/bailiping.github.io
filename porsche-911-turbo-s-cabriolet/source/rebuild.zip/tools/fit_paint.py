"""Fit the Gentian Blue paint look (material + its studio environment) to the Porsche studio frames.

Takes: --frames (indices), --scale (viewport = native/scale), --iters (Nelder-Mead evaluations),
       --start JSON of initial parameters (defaults to the page's PAINT_LOOK), --out JSON path.
Returns: nothing; writes the best parameter set and its per-frame scores, and prints progress.
The score compares photo and render in CIELAB over pixels that are paint in the model (page
debug=paintmask) and paint-coloured in the photo, after a light blur so that only the broad
reflection structure, not pixel noise, is matched.
"""
import argparse
import base64
import io
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageFilter
from playwright.sync_api import sync_playwright

REFINE = Path(__file__).resolve().parents[1]
ORIGIN = 'http://127.0.0.1:8874/'
STYLE = ('#studio-header,#photo-footer,#comparison-controls,.photo-frame::after{display:none!important}'
         '#photo-room{inset:0!important;grid-template-rows:100%!important}#photo-room figure{width:100%;height:100%}')
# Parameters the optimiser may move, with (low, high) bounds.
FREE = {
    'roughness': (0.15, 0.6), 'gain': (0.4, 4.0),
    'base': (0.0, 0.6), 'floor': (0.0, 1.5), 'wall': (0.0, 2.0), 'wallHi': (0.15, 0.9),
    'ceiling': (0.0, 2.5), 'box': (0.0, 3.8), 'boxSides': (0.0, 1.0), 'key': (0.0, 1.5),
    'cr': (0.003, 0.05), 'cg': (0.008, 0.10), 'cb': (0.04, 0.35),
    'envYaw': (-3.1416, 3.1416),
}


def srgb_to_lab(rgb):
    """Convert an (..., 3) sRGB array in 0..255 to CIELAB (D65); returns array of same shape."""
    c = rgb / 255.0
    c = np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
    m = np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]])
    xyz = c @ m.T / np.array([0.9505, 1.0, 1.089])
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], -1)


def photo_paint(rgb):
    """Boolean mask of paint-coloured photo pixels (blue hue, saturated); takes (h,w,3) uint8 array."""
    c = rgb.astype(float) / 255
    mx, mn = c.max(-1), c.min(-1)
    sat = (mx - mn) / np.maximum(mx, 1e-6)
    hue_blue = (c[..., 2] >= c[..., 0]) & (c[..., 2] >= c[..., 1]) & (c[..., 2] - c[..., 0] > 0.08)
    return hue_blue & (sat > 0.22) & (mx > 0.05)


def cell_error(mask, lab_r, lab_p, cell=40):
    """Local tone/contrast error: per cell, compare L* percentiles and mean chroma of paint pixels.

    Takes: paint mask (h,w), render and photo CIELAB arrays (h,w,3), cell size in px.
    Returns: mean over populated cells of |dP10|+|dP50|+|dP90| of L* plus 0.5(|da|+|db|).
    """
    h, w = mask.shape
    errs = []
    for y0 in range(0, h - cell // 2, cell):
        for x0 in range(0, w - cell // 2, cell):
            m = mask[y0:y0 + cell, x0:x0 + cell]
            if m.sum() < 0.3 * cell * cell:
                continue
            r = lab_r[y0:y0 + cell, x0:x0 + cell][m]
            p = lab_p[y0:y0 + cell, x0:x0 + cell][m]
            pr = np.percentile(r[:, 0], [10, 50, 90]); pp = np.percentile(p[:, 0], [10, 50, 90])
            errs.append(np.abs(pr - pp).sum() + 0.5 * (abs(r[:, 1].mean() - p[:, 1].mean()) + abs(r[:, 2].mean() - p[:, 2].mean())))
    return float(np.mean(errs)) if errs else float('nan')


class Session:
    """A Chrome page that can load the viewer with a paint look and capture registered frames."""

    def __init__(self, pw, views, frames, scale):
        """Launch Chrome; takes playwright, view list, frame indices and viewport scale."""
        self.browser = pw.chromium.launch(executable_path='/usr/bin/google-chrome',
                                          args=['--enable-webgl', '--use-angle=gl', '--ignore-gpu-blocklist'])
        self.page = self.browser.new_page(viewport={'width': 960, 'height': 540}, device_scale_factor=1,
                                          reduced_motion='reduce')
        self.views, self.frames, self.scale = views, frames, scale

    def load(self, query):
        """Open the views tab with Compare on and the photo hidden; takes extra query string."""
        self.page.goto(ORIGIN + '?frame=0&compare=1' + query + '#porsche-views')
        self.page.wait_for_function('window.__studioDiag?.loaded && document.documentElement.classList.contains("compare-photos")', timeout=120000)
        self.page.add_style_tag(content=STYLE)
        self.page.eval_on_selector('#comparison-split', 'el=>{el.value="0";el.dispatchEvent(new Event("input"))}')

    def grab(self, i):
        """Capture frame i at native/scale; returns (h,w,3) uint8 array."""
        view = self.views[i]
        w, h = round(view['width'] / self.scale), round(view['height'] / self.scale)
        self.page.set_viewport_size({'width': w, 'height': h})
        self.page.locator('#photo-angle').select_option(index=i, force=True)
        self.page.wait_for_function('id=>document.querySelector("#photo").currentSrc.includes(id+".webp") && window.__studioDiag.selectedView===document.querySelector("#photo-angle").selectedOptions[0].text', arg=view['id'], timeout=60000)
        self.page.evaluate('()=>new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(done)))')
        self.page.wait_for_function('window.__studioDiag.framingSettled', timeout=60000)
        return np.asarray(Image.open(io.BytesIO(self.page.screenshot(type='png'))).convert('RGB'))


def blur(a):
    """Light Gaussian blur of an RGB uint8 array; returns float array."""
    return np.asarray(Image.fromarray(a).filter(ImageFilter.GaussianBlur(2.0))).astype(float)


def main():
    """Prepare masks and photos, then run a bounded Nelder-Mead over the paint look; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('--frames', default='0,2,4,6,9,12,16,19,22,25,28,31,35,39,40,42')
    ap.add_argument('--scale', type=float, default=4.0)
    ap.add_argument('--iters', type=int, default=80)
    ap.add_argument('--start', default='')
    ap.add_argument('--out', default=str(REFINE / 'renders/paint_fit.json'))
    a = ap.parse_args()
    views = json.loads((REFINE / 'web-fit/porsche-views.json').read_text())
    frames = [int(f) for f in a.frames.split(',')]
    start = json.loads(a.start) if a.start else {}
    with sync_playwright() as pw:
        ses = Session(pw, views, frames, a.scale)
        ses.load('&debug=paintmask')
        data = {}
        for i in frames:
            m = ses.grab(i).astype(int)
            model_paint = (m[..., 0] > 128) & (m[..., 1] < 80) & (m[..., 2] < 80)
            ph = Image.open(REFINE / 'web-fit/porsche-views' / (views[i]['id'] + '.webp')).convert('RGB')
            ph = np.asarray(ph.resize((m.shape[1], m.shape[0]), Image.LANCZOS))
            mask = model_paint & photo_paint(ph)
            # erode the mask a little so edges (misregistration) do not dominate
            er = np.asarray(Image.fromarray((mask * 255).astype('u1')).filter(ImageFilter.MinFilter(5))) > 128
            data[i] = (er, srgb_to_lab(ph.astype(float)))
            print('mask', views[i]['id'], int(er.sum()), flush=True)

        def look_from(vec):
            """Map a free-parameter vector to a PAINT_LOOK override dict; takes array, returns dict."""
            d = dict(start)
            for k, v in zip(FREE, vec):
                d[k] = float(v)
            d['color'] = [d.pop('cr'), d.pop('cg'), d.pop('cb')]
            return d

        def score(vec):
            """Render all frames with this look and return the mean Lab error (lower is better)."""
            look = look_from(vec)
            ses.load('&paintenv=' + base64.b64encode(json.dumps(look).encode()).decode())
            errs = {}
            for i in frames:
                mask, lab_ph = data[i]
                lab_r = srgb_to_lab(ses.grab(i).astype(float))
                errs[views[i]['id']] = cell_error(mask, lab_r, lab_ph)
            return float(np.mean(list(errs.values()))), errs

        defaults = {'envYaw': 0.0, 'roughness': 0.34, 'gain': 1.0, 'base': 0.16, 'floor': 0.55,
                    'wall': 0.75, 'wallHi': 0.45, 'ceiling': 0.55, 'box': 1.6, 'boxSides': 0.8, 'key': 0.5,
                    'cr': 0.012, 'cg': 0.034, 'cb': 0.140}
        for k in FREE:
            if k in start:
                defaults[k] = start[k]
        if 'color' in start:
            defaults['cr'], defaults['cg'], defaults['cb'] = start['color']
        lo = np.array([FREE[k][0] for k in FREE]); hi = np.array([FREE[k][1] for k in FREE])
        x0 = np.array([defaults[k] for k in FREE])
        # Nelder-Mead in the unit box
        def f(u):
            return score(lo + np.clip(u, 0, 1) * (hi - lo))
        u0 = (x0 - lo) / (hi - lo)
        n = len(u0)
        simplex = [u0] + [np.clip(u0 + 0.15 * np.eye(n)[j] * (1 if u0[j] < 0.8 else -1), 0, 1) for j in range(n)]
        vals = []
        for u in simplex:
            vals.append(f(u)[0]); print('init', round(vals[-1], 3), flush=True)
        evals = len(simplex)
        best = (min(vals), simplex[int(np.argmin(vals))])
        while evals < a.iters:
            order = np.argsort(vals); simplex = [simplex[k] for k in order]; vals = [vals[k] for k in order]
            c = np.mean(simplex[:-1], axis=0)
            xr = c + (c - simplex[-1]); fr = f(xr)[0]; evals += 1
            if fr < vals[0]:
                xe = c + 2 * (c - simplex[-1]); fe = f(xe)[0]; evals += 1
                simplex[-1], vals[-1] = (xe, fe) if fe < fr else (xr, fr)
            elif fr < vals[-2]:
                simplex[-1], vals[-1] = xr, fr
            else:
                xc = c + 0.5 * (simplex[-1] - c); fc = f(xc)[0]; evals += 1
                if fc < vals[-1]:
                    simplex[-1], vals[-1] = xc, fc
                else:
                    for j in range(1, n + 1):
                        simplex[j] = simplex[0] + 0.5 * (simplex[j] - simplex[0])
                        vals[j] = f(simplex[j])[0]; evals += 1
            k = int(np.argmin(vals))
            if vals[k] < best[0]:
                best = (vals[k], simplex[k])
            print('eval', evals, 'best', round(best[0], 3), flush=True)
        total, per = score(lo + np.clip(best[1], 0, 1) * (hi - lo))
        look = look_from(lo + np.clip(best[1], 0, 1) * (hi - lo))
        Path(a.out).write_text(json.dumps({'score': total, 'per_frame': per, 'look': look}, indent=1))
        print('final', round(total, 3), json.dumps(look))
        ses.browser.close()


if __name__ == '__main__':
    main()
