"""Build comparison images between reference photos and captured renders.

Takes: frame ids, render tags (one or more; each becomes a row), a crop box in render pixels
       (x,y,w,h or 'full'), output width, layout 'stack' (photo then each tag) or 'grid'.
Returns: nothing; writes one JPEG to --out.
"""
import argparse
from pathlib import Path
from PIL import Image, ImageDraw

REFINE = Path(__file__).resolve().parents[1]


def load(view_id, tag):
    """Load a render for a tag, or the photo resized to the base render size when tag == 'photo'; returns Image."""
    if tag == 'photo':
        ref = next((REFINE / 'renders').glob(f'*/{view_id}.jpg'))
        size = Image.open(ref).size
        return Image.open(REFINE / 'web/porsche-views' / f'{view_id}.webp').convert('RGB').resize(size, Image.LANCZOS)
    return Image.open(REFINE / 'renders' / tag / f'{view_id}.jpg').convert('RGB')


def main():
    """Crop the same box from the photo and every tag, label and stack them; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('views', help='comma list of frame ids, e.g. view-00,view-35')
    ap.add_argument('--tags', default='base')
    ap.add_argument('--box', default='full')
    ap.add_argument('--width', type=int, default=1400)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    rows = []
    for vid in a.views.split(','):
        imgs = [('photo', load(vid, 'photo'))] + [(t, load(vid, t)) for t in a.tags.split(',')]
        for label, im in imgs:
            if a.box != 'full':
                x, y, w, h = map(int, a.box.split(','))
                im = im.crop((x, y, x + w, y + h))
            s = a.width / im.width
            im = im.resize((a.width, max(1, round(im.height * s))), Image.LANCZOS)
            ImageDraw.Draw(im).text((8, 6), f'{vid} {label}', fill=(220, 30, 30))
            rows.append(im)
    out = Image.new('RGB', (a.width, sum(r.height + 4 for r in rows)), 'white')
    y = 0
    for r in rows:
        out.paste(r, (0, y)); y += r.height + 4
    out.save(a.out, quality=90)


if __name__ == '__main__':
    main()
