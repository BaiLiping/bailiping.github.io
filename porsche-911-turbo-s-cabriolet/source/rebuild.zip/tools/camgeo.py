"""Camera geometry helpers for the calibrated studio frames (Blender world, metres).

project(view, pts) -> pixel coords (native image px); backproject(view, px, plane) -> world point
on a plane given as ('z', value) / ('y', value) / ('x', value). Camera model: pinhole at
cameras.json[view]['blender_m'] (position, target, vertical fov, roll), principal point at centre.
"""
import json
from pathlib import Path
import numpy as np

CAMS = json.loads(Path('/home/bailiping/Desktop/porsche_turbo_s_cab_work/calibration/cameras.json').read_text())


def axes(view):
    """Return (eye, R rows [right, down, forward], focal_px, w, h) for a view id."""
    cam = CAMS[view]
    w, h = cam['solved']['width'], cam['solved']['height']
    c = np.array(cam['blender_m']['position']); t = np.array(cam['blender_m']['target'])
    f = (t - c) / np.linalg.norm(t - c)
    right = np.cross(f, [0, 0, 1.0])
    if np.linalg.norm(right) < 1e-7:
        th = cam['viewer']['theta']; right = np.array([-np.sin(th), -np.cos(th), 0.])
    right /= np.linalg.norm(right)
    down = np.cross(f, right)
    roll = cam['viewer'].get('roll', 0.0)
    R = np.array([np.cos(roll) * right - np.sin(roll) * down, np.sin(roll) * right + np.cos(roll) * down, f])
    focal = h / 2 / np.tan(np.deg2rad(cam['viewer']['fov']) / 2)
    return c, R, focal, w, h


def project(view, pts):
    """Project world points (n,3) into native pixels; returns (n,2) array (x right, y down)."""
    c, R, focal, w, h = axes(view)
    q = (np.atleast_2d(pts) - c) @ R.T
    return np.stack([w / 2 + focal * q[:, 0] / q[:, 2], h / 2 + focal * q[:, 1] / q[:, 2]], 1)


def backproject(view, px, plane):
    """Intersect pixel rays (n,2 native px) with an axis plane ('x'|'y'|'z', value); returns (n,3)."""
    c, R, focal, w, h = axes(view)
    px = np.atleast_2d(px).astype(float)
    d_cam = np.stack([(px[:, 0] - w / 2) / focal, (px[:, 1] - h / 2) / focal, np.ones(len(px))], 1)
    d = d_cam @ R
    ax = 'xyz'.index(plane[0])
    s = (plane[1] - c[ax]) / d[:, ax]
    return c + s[:, None] * d


def raycast(view, px, tris):
    """Cast pixel rays into a triangle soup and return the nearest hits.

    Takes: view id, (n,2) native pixels, (m,3,3) triangles in world metres.
    Returns: (n,3) hit points (nan where the ray misses).
    """
    c, R, focal, w, h = axes(view)
    px = np.atleast_2d(px).astype(float)
    d_cam = np.stack([(px[:, 0] - w / 2) / focal, (px[:, 1] - h / 2) / focal, np.ones(len(px))], 1)
    dirs = d_cam @ R
    dirs /= np.linalg.norm(dirs, axis=1, keepdims=True)
    v0, e1, e2 = tris[:, 0], tris[:, 1] - tris[:, 0], tris[:, 2] - tris[:, 0]
    out = np.full((len(px), 3), np.nan)
    for k, d in enumerate(dirs):
        p = np.cross(d, e2)
        det = np.einsum('ij,ij->i', e1, p)
        ok = np.abs(det) > 1e-12
        inv = np.where(ok, 1.0 / np.where(ok, det, 1), 0)
        s = c - v0
        u = np.einsum('ij,ij->i', s, p) * inv
        q = np.cross(s, e1)
        v = (q @ d) * inv
        t = np.einsum('ij,ij->i', e2, q) * inv
        hit = ok & (u >= 0) & (v >= 0) & (u + v <= 1) & (t > 0)
        if hit.any():
            out[k] = c + d * t[hit].min()
    return out


def mesh_tris(npz_path, pattern):
    """Triangles (m,3,3) of objects matching a regex from an extract_fit_mesh .npz; returns array."""
    import re
    z = np.load(npz_path, allow_pickle=True)
    names = list(z['names'])
    keep = np.isin(z['obj'], [i for i, n in enumerate(names) if re.search(pattern, n)])
    return z['positions'][z['triangles'][keep]]
