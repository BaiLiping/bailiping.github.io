"""Plot cross-sections x = const of model meshes (shell, lid, lamp bezel) with the fitted lamp ring.

Takes: label=mesh.npz pairs, --x comma list of stations, --out png. Returns: nothing; writes the plot.
"""
import argparse, json, re, sys
from pathlib import Path
import numpy as np

REFINE = Path(__file__).resolve().parents[1]


def slice_x(tris, x0):
    """Segments where triangles (m,3,3) cross the plane x = x0; returns (k,2,3)."""
    d = tris[:, :, 0] - x0
    segs = []
    for (a, b, c), (da, db, dc) in zip(tris, d):
        pts = []
        for p, q, dp, dq in ((a, b, da, db), (b, c, db, dc), (c, a, dc, da)):
            if (dp < 0) != (dq < 0):
                t = dp / (dp - dq); pts.append(p + t * (q - p))
        if len(pts) == 2:
            segs.append(pts)
    return np.array(segs)


def main():
    """Slice each mesh at each station and plot y-z; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('meshes', nargs='+'); ap.add_argument('--x', default='1.60,1.70,1.80,1.90,2.00')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    xs = [float(v) for v in a.x.split(',')]
    fit = json.loads((REFINE / 'blender/exterior/headlamp_fit.json').read_text())
    c, u, v = (np.array(fit[k]) for k in ('center', 'u_axis', 'v_axis'))
    th = np.linspace(0, 2 * np.pi, 400)
    ring = c + np.outer(fit['a'] * np.cos(th), u) + np.outer(fit['b'] * np.sin(th), v)
    fig, axs = plt.subplots(1, len(xs), figsize=(4.2 * len(xs), 4.6), sharey=True)
    colors = ['tab:gray', 'tab:red', 'tab:blue', 'tab:green']
    for k, item in enumerate(a.meshes):
        lab, path = item.split('=')
        z = np.load(path, allow_pickle=True)
        names = list(z['names'])
        keep = np.isin(z['obj'], [i for i, n in enumerate(names) if re.search(r'^TSC_(Body_Shell$|Front_Lid$|Headlight_Bezel|Headlight_Lens)', n)])
        tris = z['positions'][z['triangles'][keep]]
        tris = tris[(tris[:, :, 0].max(1) > 1.3) & (tris[:, :, 1].min(1) > -0.05)]
        for ax, x0 in zip(axs, xs):
            segs = slice_x(tris[(tris[:, :, 0].min(1) <= x0) & (tris[:, :, 0].max(1) >= x0)], x0)
            for s in segs:
                ax.plot(s[:, 1], s[:, 2], '-', color=colors[k % 4], lw=1.0, label=lab if s is segs[0] else None)
    for ax, x0 in zip(axs, xs):
        near = np.abs(ring[:, 0] - x0) < 0.006
        ax.plot(ring[near, 1], ring[near, 2], 'k*', ms=7, label='photo lamp ring')
        ax.set_title(f'x = {x0}'); ax.set_aspect('equal'); ax.grid(alpha=.3); ax.set_xlim(0, 0.95); ax.set_ylim(0.3, 0.95)
    axs[0].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(a.out, dpi=100)


if __name__ == '__main__':
    main()
