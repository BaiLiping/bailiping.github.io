"""Score a model's silhouettes against the studio photo masks through the calibrated cameras.

Takes: a mesh .npz written by calibration/extract_fit_mesh.py (final assembled positions),
       --width of the evaluation raster, --out JSON path, optional --frames filter.
Returns: nothing; writes per-frame IoU, median and p95 two-way contour distance (native 4K px)
         and prints a summary table.
"""
import argparse
import json
from pathlib import Path
import cv2
import moderngl
import numpy as np

CAL = Path('/home/bailiping/Desktop/porsche_turbo_s_cab_work/calibration')


def camera_axes(camera, height):
    """Build eye, world->camera rotation rows and focal (px) from a cameras.json entry; returns tuple."""
    params = camera['viewer']
    c = np.array(camera['blender_m']['position'])
    t = np.array(camera['blender_m']['target'])
    forward = (t - c) / np.linalg.norm(t - c)
    up = np.array([0., 0., 1.])
    right = np.cross(forward, up)
    if np.linalg.norm(right) < 1e-7:
        theta = params['theta']
        right = np.array([-np.sin(theta), -np.cos(theta), 0.])
    right /= np.linalg.norm(right)
    down = np.cross(forward, right)
    roll = params.get('roll', 0.)
    rot = np.array([np.cos(roll) * right - np.sin(roll) * down,
                    np.sin(roll) * right + np.cos(roll) * down, forward])
    focal = height / 2 / np.tan(np.deg2rad(params['fov']) / 2)
    return c, rot, focal


class Raster:
    """Minimal EGL depth-tested mask rasterizer for a triangle soup split by roof state."""

    def __init__(self, mesh, width, height):
        """Upload positions and per-roof index buffers; takes mesh dict and raster size."""
        ctx = self.ctx = moderngl.create_standalone_context(backend='egl')
        self.size = (width, height)
        vbo = ctx.buffer(mesh['positions'].astype('f4').tobytes())
        self.prog = ctx.program(vertex_shader="""#version 330
            uniform mat4 T; in vec3 xyz; void main(){gl_Position=T*vec4(xyz,1.);}""",
                                fragment_shader="""#version 330
            out vec4 o; void main(){o=vec4(1.);}""")
        self.vaos = {}
        for roof, keep in [('up', mesh['states'] != 2), ('down', mesh['states'] != 1)]:
            ibo = ctx.buffer(mesh['triangles'][keep].astype('i4').tobytes())
            self.vaos[roof] = ctx.vertex_array(self.prog, [(vbo, '3f', 'xyz')], ibo)
        self.tex = ctx.texture(self.size, 1, dtype='f1')
        self.fbo = ctx.framebuffer([self.tex], ctx.depth_renderbuffer(self.size))

    def draw(self, eye, rot, focal, roof):
        """Render the silhouette for one camera; returns a bool mask (h, w)."""
        w, h = self.size
        A = np.eye(4); A[:3, :3] = rot; A[:3, 3] = -rot @ eye
        n, f = 0.02, 200.
        P = np.array([[2 * focal / w, 0, 0, 0], [0, -2 * focal / h, 0, 0],
                      [0, 0, (f + n) / (f - n), -2 * n * f / (f - n)], [0, 0, 1, 0]])
        self.prog['T'].write((P @ A).T.astype('f4').tobytes())
        self.fbo.use(); self.fbo.clear()
        self.ctx.enable(moderngl.DEPTH_TEST)
        self.vaos[roof].render()
        img = np.frombuffer(self.tex.read(), 'u1').reshape(h, w)[::-1]
        return img > 127


def contour_dist(a, b):
    """Two-way nearest-contour distances between two masks; returns concatenated distances (px)."""
    def edge(m):
        e = np.zeros(m.shape, np.uint8)
        cs, _ = cv2.findContours(m.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        cv2.drawContours(e, cs, -1, 1, 1)
        return e.astype(bool)
    ea, eb = edge(a), edge(b)
    da = cv2.distanceTransform((~eb).astype(np.uint8), cv2.DIST_L2, 5)
    db = cv2.distanceTransform((~ea).astype(np.uint8), cv2.DIST_L2, 5)
    return np.concatenate([da[ea], db[eb]])


def main():
    """Load mesh and cameras, score every masked studio frame, write and print results; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('mesh'); ap.add_argument('--width', type=int, default=1920)
    ap.add_argument('--out', required=True); ap.add_argument('--frames', default='')
    a = ap.parse_args()
    mesh = dict(np.load(a.mesh, allow_pickle=True))
    w = a.width; h = w * 9 // 16
    r = Raster(mesh, w, h)
    cams = json.loads((CAL / 'cameras.json').read_text())
    want = set(a.frames.split(',')) if a.frames else None
    res = {}
    for name, cam in cams.items():
        if not name.startswith('view-') or (want and name not in want):
            continue
        mp = cam.get('mask_path')
        if not mp or not Path(mp).exists():
            continue
        m = cv2.imread(mp, 0)
        m = cv2.resize(m, (w, h), interpolation=cv2.INTER_AREA) > 127
        eye, rot, focal = camera_axes(cam, h)
        s = r.draw(eye, rot, focal, cam.get('roof', 'up'))
        iou = np.count_nonzero(s & m) / max(1, np.count_nonzero(s | m))
        d = contour_dist(s, m) * 3840 / w
        res[name] = {'iou': round(float(iou), 5), 'med': round(float(np.median(d)), 2),
                     'p95': round(float(np.percentile(d, 95)), 2)}
    Path(a.out).write_text(json.dumps(res, indent=1))
    ious = [v['iou'] for v in res.values()]
    meds = [v['med'] for v in res.values()]
    p95s = [v['p95'] for v in res.values()]
    print(f"frames={len(res)} IoU mean={np.mean(ious):.4f} min={np.min(ious):.4f} "
          f"med(px4k) mean={np.mean(meds):.2f} p95 mean={np.mean(p95s):.2f} max={np.max(p95s):.1f}")


if __name__ == '__main__':
    main()
