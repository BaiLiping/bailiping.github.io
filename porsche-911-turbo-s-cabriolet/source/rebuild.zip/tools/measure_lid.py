"""Triangulate the front lid's shut line from the overhead (42) and straight-on (35) studio frames.

Takes: --out JSON path. Returns: nothing; writes the measured half-width hw(x) and edge height z(x)
of the lid outline (assembled metres, symmetric average of both sides) and prints them.
The overhead frame fixes the plan (its rays are near-vertical, so the assumed height barely matters);
the straight-on frame fixes the height where its ray meets |y| = hw(x). Two rounds of alternation.
Shut-line pixels are the strongest narrow dark line within a band around a seed outline.
"""
import argparse
import json
import sys
from pathlib import Path
import cv2
import numpy as np
from PIL import Image
from scipy.interpolate import PchipInterpolator, UnivariateSpline
from scipy.ndimage import map_coordinates

sys.path.insert(0, str(Path(__file__).parent))
import camgeo  # noqa: E402

REFINE = Path(__file__).resolve().parents[1]
# Seed outline: the rest-space lid plan before this measurement (config.HOOD_HW_*).
SEED_X = [0.700, 0.7315, 0.922, 1.104, 1.261, 1.404, 1.553, 1.688, 1.794, 1.861, 1.928, 1.972]
SEED_Y = [0.703, 0.7025, 0.6885, 0.6535, 0.6296, 0.5949, 0.5422, 0.5149, 0.4699, 0.4184, 0.3904, 0.3643]


def image(view):
    """Grey studio frame, lightly blurred; returns float array."""
    img = np.asarray(Image.open(REFINE / 'web/porsche-views' / f'{view}.webp').convert('L')).astype(float)
    return cv2.GaussianBlur(img, (0, 0), 1.0)


def dark_line(img, p, normal, rng):
    """Strongest narrow dark line along p + t*normal, |t| <= rng px; returns (point, response)."""
    ts = np.arange(-rng, rng + 0.5, 0.5)
    xy = p + np.outer(ts, normal)
    prof = map_coordinates(img, [xy[:, 1], xy[:, 0]], order=1)
    k = np.arange(14, len(prof) - 14)
    left = np.mean([prof[k - j] for j in range(6, 13)], axis=0)
    right = np.mean([prof[k + j] for j in range(6, 13)], axis=0)
    resp = np.minimum(left, right) - prof[k]
    b = int(np.argmax(resp))
    return xy[k[b]], float(resp[b])


def overhead_plan(xs, hw, zfun, sign):
    """Plan points of one side's shut line in the overhead frame; returns (n,2) x, |y|."""
    img = image('view-42')
    pts3 = np.column_stack([xs, sign * hw(xs), zfun(xs)])
    px = camgeo.project('view-42', pts3)
    tang = np.gradient(px, axis=0)
    nrm = np.column_stack([-tang[:, 1], tang[:, 0]]) / np.linalg.norm(tang, axis=1)[:, None]
    out = []
    for p, n, x, z in zip(px, nrm, xs, zfun(xs)):
        q, resp = dark_line(img, p, n, 34)
        if resp < 10:
            continue
        P = camgeo.backproject('view-42', q[None], ('z', float(z)))[0]
        out.append((P[0], abs(P[1])))
    return np.array(out)


def front_heights(hw, sign, xs):
    """Edge heights where straight-on rays through the detected shut line meet |y| = hw(x); returns (n,2) x, z."""
    img = image('view-35')
    c, R, f, w, h = camgeo.axes('view-35')
    seed = camgeo.project('view-35', np.column_stack([xs, sign * hw(xs), 0.52 + 0.30 * (1.95 - xs) / 0.9]))
    out = []
    for p in seed:
        q, resp = dark_line(img, p, np.array([1.0, 0.0]), 40)
        if resp < 10:
            continue
        d = np.array([(q[0] - w / 2) / f, (q[1] - h / 2) / f, 1.0]) @ R
        d /= np.linalg.norm(d)
        P = c + np.outer(np.linspace(5, 15, 8001), d)
        inside = (P[:, 0] > xs.min()) & (P[:, 0] < xs.max())
        g = sign * P[:, 1] - hw(np.clip(P[:, 0], xs.min(), xs.max()))
        idx = np.where(inside[:-1] & inside[1:] & (np.sign(g[:-1]) != np.sign(g[1:])))[0]
        if len(idx):
            out.append((P[idx[0], 0], P[idx[0], 2]))
    return np.array(out)


def front_edge():
    """The lid's front edge arc in the overhead frame on z = 0.495; returns (n,2) x, |y|."""
    img = image('view-42')
    out = []
    for y in np.linspace(-0.32, 0.32, 17):
        p = camgeo.project('view-42', np.array([[2.035, y, 0.495]]))[0]
        q, resp = dark_line(img, p, np.array([1.0, 0.0]), 60)
        if resp >= 5:
            P = camgeo.backproject('view-42', q[None], ('z', 0.495))[0]
            out.append((P[0], abs(P[1])))
    return np.array(out)


def robust_poly(xy, deg):
    """Polynomial fit of value against x with two rounds of 3-MAD outlier rejection; returns np.poly1d."""
    keep = np.ones(len(xy), bool)
    for _ in range(3):
        poly = np.poly1d(np.polyfit(xy[keep, 0], xy[keep, 1], deg))
        res = np.abs(xy[:, 1] - poly(xy[:, 0]))
        mad = np.median(res[keep]) + 1e-4
        keep = res < 3.0 * 1.4826 * mad
    return poly, keep


def main():
    """Plan from the overhead, heights from the straight-on frame, two rounds; writes JSON; returns None."""
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    xs = np.linspace(1.05, 1.86, 34)
    lo, hi = 1.05, 1.86
    hw_seed = PchipInterpolator(SEED_X, SEED_Y)
    hw = hw_seed
    zfun = lambda x: 0.52 + 0.30 * (1.95 - np.asarray(x)) / 0.95
    for rnd in range(2):
        plan = np.vstack([overhead_plan(xs, hw_seed if rnd == 0 else hw, zfun, s) for s in (+1, -1)])
        plan = plan[(plan[:, 0] > lo) & (plan[:, 0] < hi + 0.03)]
        hw_poly, keep_p = robust_poly(plan, 3)
        hw = lambda x, P=hw_poly: P(np.clip(x, lo, hi))
        heights = np.vstack([front_heights(hw, s, xs) for s in (+1, -1)])
        heights = heights[(heights[:, 0] > lo) & (heights[:, 0] < hi)]
        z_poly, keep_h = robust_poly(heights, 3)
        zfun = lambda x, P=z_poly: P(np.clip(x, lo, hi))
        print(f'round {rnd}: plan {keep_p.sum()}/{len(plan)} kept, heights {keep_h.sum()}/{len(heights)} kept, '
              f'height rms {np.std(heights[keep_h, 1] - z_poly(heights[keep_h, 0])) * 1000:.1f} mm')
    edge = front_edge()
    grid = np.round(np.arange(1.10, 1.86, 0.05), 3)
    rows = [{'x': float(g), 'hw': round(float(hw(g)), 4), 'z': round(float(zfun(g)), 4)} for g in grid]
    Path(a.out).write_text(json.dumps({'note': 'front lid shut line, overhead 42 + straight-on 35',
                                       'rows': rows, 'front_edge_x_absy': np.round(edge, 4).tolist()}, indent=1))
    for r in rows:
        print(r)
    print('front edge (x, |y|):', np.round(edge, 3).tolist())


if __name__ == '__main__':
    main()
