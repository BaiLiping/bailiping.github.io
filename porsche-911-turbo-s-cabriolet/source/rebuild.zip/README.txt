Porsche 911 Turbo S Cabriolet reconstruction
Blender 5.2, metres, Y up in the glTF export, vehicle nose toward positive Z.
The archive contains the car and rear powertrain reconstruction scripts and instrument artwork. Extract
it into the website checkout so that the sibling porsche-911-gt3 folder is
present. The script adapts that studio's existing dashboard and steering
controls. A standalone copy of the required source model is available at
https://bailiping.com/porsche-911-gt3/porsche_911_gt3_992_2.glb
Place that GLB at porsche-911-gt3/porsche_911_gt3_992_2.glb in the extracted
tree. Run this command from the porsche-911-turbo-s-cabriolet directory:
  blender -b -P source/build.py
The resulting porsche.glb and source/turbo-s-cabriolet.blend are written to
that directory. The separately downloadable Blender file has packed materials.
