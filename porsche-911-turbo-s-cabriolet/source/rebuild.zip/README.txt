2027 Porsche 911 Turbo S Cabriolet (992.2) in Gentian Blue Metallic
Rebuild with Blender 5.2 and its bundled glTF importer/exporter.

Extract the whole archive. In the porsche-911-turbo-s-cabriolet folder run

    blender -b --python-exit-code 1 -P source/build.py

Blender writes porsche.glb and source/turbo-s-cabriolet.blend. The scene uses metres.
The glTF coordinate system has +Y up, +Z forward and +X on the driver's left.
Major assemblies are separate scene roots. Each wheel and brake pivots at its hub.

The body, closures, fabric roof, upholstery, wheels and T-Hybrid running gear are
reconstructed for this model. The included 992.2 GT3 studio mesh supplies common
dashboard, steering, mirror and door-trim details. The Turbo S headlamp housings,
projectors and four-point guides are modeled separately.
The Porsche configurator and Newsroom sources, matched views, measurements and
remaining differences are documented at
https://bailiping.com/porsche-911-turbo-s-cabriolet/review.html

The packed .blend is available as a separate download on that page.
