"""Cabin screen fascia and air distributor fitted to the Jet Black cube face."""
camdata=json.loads((ROOT/'cabin-camera.json').read_text());eye=np.asarray(camdata['eye']);fwd=np.asarray(camdata['look'])-eye;fwd/=np.linalg.norm(fwd);right=np.cross(fwd,[0,0,1]);right/=np.linalg.norm(right);up=np.cross(right,fwd)
def film(u,v,xx):
 ray=fwd+right*((u-305)/305)+up*((305-v)/305);return eye+ray*((xx-eye[0])/ray[0])
def depth(u):return -.57-.00013*(u-285)
def fpos(p,extra=0):return tuple(film(*p,depth(p[0])+extra))
def band(name,profile,m):
 sections=[[fpos((u,v),dx) for dx,v in [(-.10,top),(-.02,top-.8),(0,top+.6),(0,bot-1),(-.012,bot),(-.08,bot-1)]] for u,top,bot in profile]
 ob=loft(name,sections,m,cab)
 for face in ob.data.polygons:face.use_smooth=True
 return ob
glass_frame=mat('Instrument glass perimeter','15171b',.10,.35)
band('Swept upper instrument brow',[(77,258,265),(111,232,238),(150,220,229),(187,219,224),(306,217,223),(421,218,224),(541,218,225),(674,233,240)],bk)
band('Lower dashboard leather roll',[(83,300,314),(154,292,308),(249,279,294),(361,281,293),(424,292,308),(524,308,323),(646,325,342)],bk)
def display(name,corners):
 verts=[fpos(p,.003) for p in corners]
 m=mat(name+' glass','e2ebfa',.01,.32);nt=m.node_tree;tex=nt.nodes.new('ShaderNodeTexImage');im=bpy.data.images.load(str(ROOT/(name+'.png')));im.pack();tex.image=im;b=nt.nodes.get('Principled BSDF')
 nt.links.new(tex.outputs[0],b.inputs['Base Color']);nt.links.new(tex.outputs[0],b.inputs['Emission Color']);b.inputs['Emission Strength'].default_value=.46
 ob=mesh(name,verts,[(0,1,2,3)],m,cab);uv=ob.data.uv_layers.new(name='Display graphics')
 for n,co in enumerate([(0,0),(1,0),(1,1),(0,1)]):uv.data[n].uv=co
 for i in range(4):path('Screen perimeter',[verts[i],verts[(i+1)%4]],.0024,glass_frame,cab)
display('Driver display',[(161,280),(428,291),(421,221),(179,223)])
display('Infotainment',[(422,292),(659,324),(651,228),(419,221)])
display('Hybrid readout',[(83,300),(165,289),(182,223),(113,232)])
band('Lower dashboard vent',[(84,310,335),(137,303,331),(213,294,321),(397,296,326),(440,310,337),(546,328,354),(651,344,374)],face_mat)
band('Satin climate-control blade',[(84,327,335),(96,338,345),(139,333,340),(194,326,332),(396,322,330),(439,335,343),(550,351,361),(651,364,376)],brushed)
for j in range(14):
 u=415+j*17;vv=330+(u-415)*.16;pts=[(u-7,vv),(u+7,vv+2.24),(u+6.8,vv+7),(u-7.2,vv+4.75)]
 vs=[fpos(p,.0022) for p in pts];mesh('Climate blade key',vs,[(0,1,2,3)],brushed,cab)
 pts=[(u-1.4,vv+2.3),(u+1.7,vv+2.9),(u+.7,vv+4.3),(u-1.7,vv+3.7)]
 mesh('Climate key icon',[fpos(p,.0026) for p in pts],[(0,1,2,3)],white_mark,cab)
