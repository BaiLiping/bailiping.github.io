"""Fit a perspective turntable to measured wheel hubs and hundreds of feature correspondences."""
from pathlib import Path
import cv2 as cv
import numpy as np
from scipy.optimize import least_squares
from itertools import combinations
import json
cv.setNumThreads(2)
ROOT=Path(__file__).resolve().parent
# Pixel observations on the 750 x 375 proof, measured at the center of the external cap.
hubs={1:((431,239),(573,205),-1),6:((192,228),(604,225),-1),9:((149,221),(500,236),-1),21:((580,228),(163,226),1),26:((365,239),(151,207),1)}
wheelX=(-1.3615,1.3615);wheelZ=(.3365,.35295)
land=[];pix=[];idx=[]
for frame,(front,rear,side) in hubs.items():
 for j,p in enumerate((front,rear)):
  land.append((wheelX[j],side*(.926,.935)[j],wheelZ[j]));pix.append(np.array(p)*2);idx.append(frame-1)
land=np.array(land);pix=np.array(pix);idx=np.array(idx)
def pose(params):
 D,f,elev,phase,cx,cy,tx,ty,tz=params
 ang=np.deg2rad(np.arange(30)*12+24+phase)
 c,s=np.cos(ang),np.sin(ang); e=np.deg2rad(elev)
 back=np.stack([-c*np.cos(e),-s*np.cos(e),np.sin(e)*np.ones_like(c)],axis=-1)
 rt=np.stack([s,-c,0*c],axis=-1)
 up=np.cross(back,rt)
 R=np.stack([rt,-up,-back],axis=1)
 target=np.array([tx,ty,tz]);C=target+back*D; t=-np.einsum('nij,nj->ni',R,C)
 K=np.array([[f,0,cx],[0,f,cy],[0,0,1]])
 return K,R,C,t
def hub_error(p):
 K,R,C,t=pose(p)
 q=np.einsum('nij,nj->ni',R[idx],land)+t[idx]
 uv=q@K.T;return (uv[:,:2]/uv[:,2:]-pix).ravel()
start=[10,2650,4,0,750,375,0,0,.65]
lower=[4,800,-2,-8,650,250,-.3,-.06,.48]
upper=[30,9000,18,8,850,520,.3,.06,.9]
if __name__=='__main__':
 p=least_squares(hub_error,start,bounds=(lower,upper)).x;print('hub initial',p,hub_error(p).reshape(-1,2),flush=True)
 # Match neighboring images. Reject moving reflections using the consensus fundamental matrix.
 matches=ROOT/'matches.npz'
 if not matches.exists():
  sift=cv.SIFT_create(1800); features=[]
  for i in range(1,31):
   im=cv.imread(str(ROOT/('refs/ext-%03d.png'%i)),cv.IMREAD_UNCHANGED)
   keys,desc=sift.detectAndCompute(cv.cvtColor(im,cv.COLOR_BGRA2GRAY),(im[:,:,3]>250).astype('uint8')*255)
   features.append((np.float32([k.pt for k in keys]),desc))
  bf=cv.BFMatcher();ii=[];jj=[];a=[];b=[]
  for i in range(30):
   for step in (1,2,3):
    j=(i+step)%30;ki,di=features[i];kj,dj=features[j];m=[m for m,n in bf.knnMatch(di,dj,k=2) if m.distance<.70*n.distance]
    u=ki[[k.queryIdx for k in m]];v=kj[[k.trainIdx for k in m]]
    F,ms=cv.findFundamentalMat(u,v,cv.USAC_MAGSAC,1.,.999)
    if ms is None:continue
    take=np.nonzero(ms.ravel())[0][::3]
    a.extend(u[take]);b.extend(v[take]);ii.extend([i]*len(take));jj.extend([j]*len(take))
  np.savez(matches,i=ii,j=jj,a=a,b=b)
 data=np.load(matches);i,j,a,b=[data[k] for k in ('i','j','a','b')]
 a=np.column_stack([a,np.ones(len(a))]);b=np.column_stack([b,np.ones(len(b))])
 # Symmetric epipolar distance with the rigid, equally-spaced camera ring.
 def residual(p):
  K,R,C,t=pose(p)
  ra=np.einsum('nij,nj->ni',R[i].transpose(0,2,1),(a@np.linalg.inv(K).T))
  rb=np.einsum('nij,nj->ni',R[j].transpose(0,2,1),(b@np.linalg.inv(K).T))
  baseline=C[j]-C[i];normal=np.cross(baseline,ra)
  e=np.einsum('ij,ij->i',rb,normal)/np.linalg.norm(normal,axis=1)*p[1]
  return np.r_[e, hub_error(p).repeat(28), (p[4]-750)/50,(p[5]-375)/50]
 p=least_squares(residual,p,bounds=(lower,upper),loss='soft_l1',f_scale=1.5).x
 print('ring',p,'epi median',np.median(np.abs(residual(p)[:len(a)])),'hubs',hub_error(p).reshape(-1,2))
 (ROOT/'rig.json').write_text(json.dumps(p.tolist(),indent=2))
