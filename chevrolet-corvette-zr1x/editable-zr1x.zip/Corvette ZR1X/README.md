# 2027 Chevrolet Corvette ZR1X 3LZ Coupe

Open `v2/ZR1X_v2.blend` in Blender 5.2.1 LTS. The scene uses metres with +X toward the nose and +Y toward the driver's left. The Chevrolet reference cameras collection contains a saved camera for every gallery image. Each camera's custom properties give its image dimensions, frame ID and viewer state, including component visibility and steering. Selecting a camera in Blender sets the optical view. The web studio also applies its saved assembly state.

## Rebuild the model

From the extracted directory, use Blender with its glTF import/export add-on and bundled Draco library. All geometry, fitted panels, profiles and display textures needed for a build are included. The following commands write a separate output master and GLB.

```sh
mkdir -p rebuilt
blender -b --python-exit-code 1 -P v2/build_v2.py -- --blend rebuilt/ZR1X.blend --glb rebuilt/car.glb
blender -b --python-exit-code 1 -P verify_rebuild.py -- site_v2/chevrolet-corvette-zr1x/corvette_zr1x_2027.glb rebuilt/car.glb
```

The export uses 1∶18-scale millimetres, with +Y up and +Z toward the passenger side. The verification compares decoded positions, normals, UVs, topology, per-face material assignments, scene transforms and hierarchy, interaction metadata, embedded images, material settings and bounds. File ordering and compression can vary between Blender versions.

## Sources and fitted panels

`v2/inventory.json` lists 95 source images, with configuration, original URL, size and SHA-256. `v2/cameras.json` stores the 52 gallery cameras, and `v2/frames.json` records the frame review. Camera initialization used the older, externally credited ZR1 as a visual reference. Its mesh is not part of the delivered geometry. The included `ZR1X.blend` at the archive root is the preceding **project-authored** photographic reconstruction. It is the source of the transferable exterior surfaces and wheel faces. `v2/photo_panels.blend` holds the fitted editable library used by the current master.

Open `v2/review.html` directly to inspect the included exterior originals and outline overlays offline. All 52 captured model renders and outlines are in `site_v2/chevrolet-corvette-zr1x/benchmark/`. Download the other originals to inspect the mechanical and cabin photographs alongside those same renders.

The 30 original Chevrolet orbit PNGs and seven matching 2500 × 1407 studio JPEGs are included under `refs_v2/`. To get the other originals, use Python 3.10 or later. The downloader checks the stored SHA-256 before installing each file, supports an existing Car_Photos checkout, and reports inaccessible or changed sources.

```sh
python fetch_references.py
python fetch_references.py --all --car-photos /path/to/Car_Photos
python fetch_references.py --verify-only
```

The first command retrieves the 52 gallery references. The second command also retrieves the supporting research images. For a single original, use `--id mech-lt7-front`. Files remain subject to their original photographers' and publishers' terms. The installed-bay photo stays linked to AUTO777 via Bring a Trailer in the viewer.

The raised-hood reference shows a 2027 3LZ ZTK coupe photographed by TeamRydell. Retrieve its three native detail photos with `python fetch_references.py --id detail-hood-underside --id detail-hood-open-cooling --id detail-hood-outlets`. The straight-on underside, the open front cooling compartment and the closed extractor are supplementary views. The 52 gallery cameras cover the regular comparisons.

`v2/lid-repair/factory-lid-camera.json` records the separate perspective fit for the straight-on underside. `v2/lid-repair/fit_lid_camera.py` reproduces the pose from the measured perimeter and `v2/lid-repair/inspect_lid.py` renders that camera through the working viewer. Run `python v2/lid-repair/inspect_lid.py check --factory-only` from the archive root.

To regenerate the measured panel library, run `blender -b ZR1X.blend --python-exit-code 1 -P v2/prepare_photo_panels.py`. The scripts `v2/fit_arch_profiles.py`, `v2/fit_tail_envelope.py` and `v2/fit_door_pressing.py` reconstruct secondary profile inputs. The door fit reads `body-panels.npz`. To regenerate the front fender shoulders around the headlamp lenses, install NumPy, SciPy and Shapely and run `python v2/fit_front_shoulders.py`. It reads `v2/front-shoulder-survey.npz` and writes `v2/front-shoulders.npz`. To revisit the ring and four high-resolution camera fits, run `python refs_v2/photo_cameras.py`. The additional camera corrections and their observations are in `refs_v2/additional-photo-fits.json`. The rig and its measurement units are described in `v2_rig_spec.md`.

## Reproduce the photo comparison

Use a Python environment with NumPy, SciPy, Pillow, OpenCV and Playwright. Install Chromium with `python -m playwright install chromium`, or set `CHROME_BIN` to a compatible Chrome executable. The geometry build runs offline. The 37 exterior masks and camera comparisons can also be calculated offline from the included images, vendor libraries and GLBs.

```sh
python -m pip install numpy scipy Pillow opencv-python playwright
python v2/review/benchmark.py site_v2/chevrolet-corvette-zr1x/corvette_zr1x_2027.glb review-result
python v2/review/benchmark.py v2/resume-baseline/full-as-recovered.glb recovered-result
python v2/review/benchmark.py --legacy site/chevrolet-corvette-zr1x/zr1x.glb earlier-result
```

For the production lighting, interactive viewer and all 52 comparison pairs, first download the gallery originals, then run these commands from the archive root.

```sh
python refs_v2/publish_benchmark_views.py site_v2/chevrolet-corvette-zr1x
python v2/review/studio_capture.py review-result
python v2/review/package_report.py review-result
python -m http.server 8000 --directory site_v2
```

Open `http://localhost:8000/chevrolet-corvette-zr1x/`. The report compares the final exterior with the earlier published mesh and the recovered mesh at the same camera poses. The configurator frames have a manufacturer alpha channel. The seven higher-resolution JPEGs use an estimated foreground mask with a reviewed lower edge, so their numerical scores are approximate. Powertrain, cabin and alternate-configuration frames have written observations. The original, recovered, and final model revision hashes are present in the bundled benchmark JSON. The engine photo study in `v2/review/lt7-photo-comparison.jpg` shows all four original LT7 angles alongside the recovered and revised isolated engine.

`MANIFEST.sha256` covers the files as delivered. On Linux or macOS with GNU coreutils, run `sha256sum -c MANIFEST.sha256` before regenerating outputs.
