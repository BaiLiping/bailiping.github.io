from pathlib import Path
import requests,json,concurrent.futures,hashlib
from PIL import Image
from bs4 import BeautifulSoup
root=Path(__file__).resolve().parent
dest=root/'refs';dest.mkdir(exist_ok=True)
# The handoff ships the original per-frame URLs, dimensions and checksums.
# Use this snapshot even after Chevrolet changes the default year in its configurator.
inventory_path = root / 'inventory.json'
if inventory_path.exists():
 def fetch_original(record):
  path = root / record['file']
  if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256']:
   return
  response = requests.get(record['original_url'], timeout=60)
  response.raise_for_status()
  if hashlib.sha256(response.content).hexdigest() != record['sha256']:
   raise ValueError('Original image has changed at ' + record['original_url'])
  path.parent.mkdir(parents=True, exist_ok=True)
  path.write_bytes(response.content)
 with concurrent.futures.ThreadPoolExecutor(8) as downloader:
  list(downloader.map(fetch_original, json.loads(inventory_path.read_text())))
 raise SystemExit(0)

source='https://www.chevrolet.com/performance/corvette/zr1x'
doc=BeautifulSoup(requests.get(source,timeout=30).content,'html.parser')
endpoint='https://www.chevrolet.com'+doc.find('gb-360-colorizer')['data-trims-json-endpoint']
cfg=requests.get(endpoint,timeout=30).json()['data']['colorizerModelByPath']['item']
trim=cfg['trims'][0]
exterior=next(e for e in trim['exteriors'] if e['name']=='Torch Red')
fmt=exterior['flipbook']['desktopImagePathFormat']
def grab(entry):
 id,url,caption,kind=entry
 fn=dest/(id+Path(url.split('?')[0]).suffix)
 if not fn.exists():
  r=requests.get(url,timeout=45);r.raise_for_status();fn.write_bytes(r.content)
 with Image.open(fn) as im:w,h=im.size
 return dict(id=id,original_url=url,source=source,credit='Chevrolet',width=w,height=h,subject=caption,kind=kind,file=str(fn.relative_to(root)),sha256=hashlib.sha256(fn.read_bytes()).hexdigest())
entries=[('ext-%03d'%i,'https://www.chevrolet.com'+fmt.replace('{framenumber}','%03d'%i),'Torch Red US 3LZ, closed, index %d'%i,'manufacturer turntable') for i in range(1,1+int(exterior['flipbook']['numberOfFrames']))]
seen=set()
for im in doc.find_all('img'):
 alt=im.get('alt') or ''
 src=(im.get('src') or '').split('?')[0]
 if '2027-corvette-zr1x/images/' not in src or not alt.strip() or src in seen:continue
 seen.add(src)
 entries.append(('detail-%02d'%len(seen),'https://www.chevrolet.com'+src,alt,'manufacturer detail'))
cabin=next(i for i in trim['interiors'] if i['interiorId']=='hte')
for face,v in cabin['colorizerPanorama'].items():
 if isinstance(v,dict):
  entries.append(('cabin-'+face.replace('ImgUrl',''),'https://www.chevrolet.com'+v['_path'],'Jet Black interior panorama, '+face,'cabin panorama'))
gallery_url='https://www.chevrolet.com'+doc.select_one('[data-gb-modal-id="gb-gallery-modal"]')['href']
gallery=BeautifulSoup(requests.get(gallery_url,timeout=30).content,'html.parser')
found={}
for im in gallery.select('img[src]'):
 src=im['src'].split('?')[0]
 if '/images/gallery/' in src: found.setdefault(src,im.get('alt',''))
for n,(src,alt) in enumerate(found.items(),1):
 entries.append(('press-%02d'%n,'https://www.chevrolet.com'+src,alt,'manufacturer gallery'))
with concurrent.futures.ThreadPoolExecutor(8) as e:records=list(e.map(grab,entries))
(root/'inventory.json').write_text(json.dumps(records,indent=2))
