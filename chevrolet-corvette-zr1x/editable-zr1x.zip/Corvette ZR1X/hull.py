"""Fuse the factory alpha silhouettes and geometrically consistent stereo depth estimates."""
from calibrate import *
from scipy.ndimage import gaussian_filter,distance_transform_edt,label
from skimage.measure import marching_cubes
import os
cv.setNumThreads(2)
p=json.loads((ROOT/'rig.json').read_text());K,R,C,T=pose(p)
def load(i):
 return cv.imread(str(ROOT/('refs/ext-%03d.png'%(i+1))),cv.IMREAD_UNCHANGED)
def project(pts,k,r,c):
 v=(pts-c)@r.T; xy=v[:,:2]*(k[0,0]/v[:,2:])+k[:2,2]
 return xy,v[:,2]
def at(image,xy):
 a=np.rint(xy).astype('int32');return image[a[:,1].clip(0,image.shape[0]-1),a[:,0].clip(0,image.shape[1]-1)]
def contiguous(mask):
 n,l,stats,cent=cv.connectedComponentsWithStats(mask.astype('uint8'),8);return np.isin(l,1+np.flatnonzero(stats[1:,4]>750)).astype('uint8')
def mask(i):
 im=load(i)
 # Distinguish the opaque subject from translucent contact shadows in the studio PNG.
 return cv.morphologyEx(contiguous(((im[:,:,3]>35)&(im[:,:,:3].max(axis=-1)>2))|(im[:,:,3]==255)),cv.MORPH_CLOSE,np.ones((5,5),'uint8'))
def sdf(m):return cv.distanceTransform(m,cv.DIST_L2,5)-cv.distanceTransform(1-m,cv.DIST_L2,5)
def depths():
 maps=[]
 for i in range(30):
  for step in (1,2):
   f=np.load(ROOT/'depth'/('%02d-%d.npz'%(i,step)))
   maps.append(dict(depth=f['depth'].astype('f')/1000,R=f['R'].astype('f'),K=f['K'].astype('f'),C=f['C'].astype('f')))
 valid=[]
 for n,m in enumerate(maps):
  z=m['depth'];yy,xx=np.nonzero(z);d=z[yy,xx];q=np.stack([(xx-m['K'][0,2])*d/m['K'][0,0],(yy-m['K'][1,2])*d/m['K'][0,0],d],axis=-1)@m['R']+m['C']
  votes=np.zeros(len(q),'uint8')
  for off in (-5,-4,-3,-2,2,3,4,5):
   a=maps[(n+off)%60];xy,dd=project(q,a['K'],a['R'],a['C']);votes+=np.abs(at(a['depth'],xy)-dd)<.028
  mc=z.copy();mc[yy[votes<3],xx[votes<3]]=0
  valid.append(mc)
 for m,z in zip(maps,valid):m['depth']=z
 return maps
if __name__=='__main__':
 masks=[sdf(mask(i)).astype('float32') for i in range(30)]
 maps=depths()
 step=float(os.getenv('STEP','.012'));grids=[np.arange(a,b,step,dtype='f') for a,b in [(-2.57,2.5),(-1.17,1.17),(-.04,1.39)]]
 g=np.empty(tuple(len(v) for v in grids),'f');hull=np.empty_like(g)
 for ix in range(0,len(grids[0]),4):
  pts=np.stack(np.meshgrid(grids[0][ix:ix+4],*grids[1:],indexing='ij'),axis=-1).reshape(-1,3);ds=[]
  for i,m in enumerate(masks):
   xy,z=project(pts,K,R[i],C[i]);ds.append(at(m,xy)*z/K[0,0])
  distances=np.partition(np.stack(ds),1,axis=0)
  # Second nearest silhouette tolerates a subpixel segmentation error in a single native view.
  hfield=.55*distances[0]+.45*distances[1]+.002
  valid=hfield>-.024;q=pts[valid];carves=[]
  for m in maps:
   xy,z=project(q,m['K'],m['R'],m['C']);d=at(m['depth'],xy)
   free=np.where(d>0,np.clip(d-z-.013,-.08,.08),-.08);carves.append(free)
  cvote=np.partition(np.stack(carves),-6,axis=0)[-6]
  out=hfield.copy();out[valid]=np.minimum(out[valid],-cvote)
  shape=(-1,len(grids[1]),len(grids[2]));g[ix:ix+4]=out.reshape(shape);hull[ix:ix+4]=hfield.reshape(shape)
  if ix%100==0:print('slab',ix,flush=True)
 np.savez_compressed(ROOT/'volume.npz',sdf=g,hull=hull,x=grids[0],y=grids[1],z=grids[2],step=step)
