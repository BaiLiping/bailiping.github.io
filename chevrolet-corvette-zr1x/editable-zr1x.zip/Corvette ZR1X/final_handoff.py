"""Package the editable source, write the native-photo comparison and check all its local inputs."""
import hashlib
import json
import os
import re
import subprocess
import sys
import zipfile
from pathlib import Path

from PIL import Image

root = Path(__file__).resolve().parent
public = Path(sys.argv[1]).resolve()
subprocess.run([sys.executable, str(root / 'handoff.py'), str(public)], check=True)
views, comp, sources = [json.loads((public / name).read_text()) for name in ('studio.json', 'comparison.json', 'sources.json')]
inventory = {r['id']: r for r in json.loads((root / 'inventory.json').read_text())}
assert comp['model_sha256'] == hashlib.sha256((public / 'zr1x.glb').read_bytes()).hexdigest()
assert [r['id'] for r in views['views']] == [r['id'] for r in comp['frames']]
assert {r['id'] for r in sources} == inventory.keys() and len(sources) == len(inventory)
for record in sources:
    original = root / inventory[record['id']]['file']
    assert hashlib.sha256(original.read_bytes()).hexdigest() == record['sha256'], original
    assert (public / record['tracing']).is_file(), record['tracing']
for frame in comp['frames']:
    capture = public / 'captures' / (frame['id'] + '.webp')
    with Image.open(capture) as image:
        assert image.size == (frame['width'], frame['height']), capture
        image.verify()
    if frame['id'].startswith('ext-'):
        assert capture.with_name(frame['id'] + '-edge.png').is_file(), frame['id']

offline = root / 'audit/review.html'
offline.parent.mkdir(parents=True, exist_ok=True)
prefix = Path(os.path.relpath(public, offline.parent)).as_posix() + '/'
for record in comp['frames'] + views['views']:
    record['source'] = '../' + inventory[record['id']]['file']
for record in sources:
    record['original_url'] = '../' + inventory[record['id']]['file']
    record['tracing'] = prefix + record['tracing']

studio_url = 'https://bailiping.com/chevrolet-corvette-zr1x/'
template = (public / 'review.html').read_text()
pattern = r'const \[d,c,srcRecords\]=await Promise\.all\([^\n]+?\),\$=id'
replacement = 'const [d,c,srcRecords]=' + json.dumps([comp, views, sources]) + ',$=id'
template, matched = re.subn(pattern, lambda _: replacement, template, count=1)
assert matched == 1, 'Offline manifest could not be embedded into the current review template'
template = template.replace("'captures/'", "'" + prefix + "captures/'")
template = template.replace('href="./#model"', 'href="' + studio_url + '#model"').replace("href='./?frame=", "href='" + studio_url + '?frame=')
for name in ('editable-zr1x.zip', 'sources.json', 'comparison.json', 'studio.json'):
    template = template.replace('href="' + name + '"', 'href="' + prefix + name + '"')
offline.write_text(template)

with zipfile.ZipFile(public / 'editable-zr1x.zip') as bundle:
    assert bundle.testzip() is None
    members = bundle.namelist()
    assert len(members) == len(set(members))
    for name in members:
        path = Path(name)
        assert path.parts == ('Corvette ZR1X', path.name)
        folder = public if path.name in ('studio.json', 'sources.json', 'comparison.json', 'assembly.js') else root
        assert bundle.read(name) == (folder / path.name).read_bytes(), name
    bundle.extractall(root / 'revision/archive-check')
print('Checked', len(views['views']), 'registered views,', len(sources), 'references and', len(members),
      'source archive members against', comp['model_sha256'])
