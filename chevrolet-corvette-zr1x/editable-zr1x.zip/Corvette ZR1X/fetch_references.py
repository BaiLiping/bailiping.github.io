"""Retrieve the selected native originals and verify every SHA-256 before installation."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import tempfile
import urllib.request

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--all',action='store_true',help='Also fetch images used only for background research.')
parser.add_argument('--id',action='append',help='Fetch specific frame id(s) instead of the gallery.')
parser.add_argument('--car-photos',type=Path,help='Existing checkout of the Car_Photos reference collection.')
parser.add_argument('--verify-only',action='store_true',help='Check the local originals without network access.')
args=parser.parse_args()
inventory=json.loads((ROOT/'v2/inventory.json').read_text())['frames']
selected={r['id'] for r in json.loads((ROOT/'refs_v2/chevrolet-views.json').read_text())}
mirrors=json.loads((ROOT/'reference-mirrors.json').read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fetch(row):
    dst=(ROOT/'v2'/row['original']).resolve()
    if ROOT not in dst.parents:
        raise ValueError('Unexpected path '+row['original'])
    if dst.is_file() and sha(dst)==row['sha256']:
        return row['id']+' verified'
    if args.verify_only:
        return row['id']+' ERROR missing or checksum differs'
    sources=[]
    mirror=mirrors.get(row['id'],{})
    if args.car_photos and 'path' in mirror:
        local=args.car_photos/mirror['path']
        if local.is_file():sources.append(local.resolve().as_uri())
    # Prefer the original byte-for-byte archive on GitHub when available.
    for url in [mirror.get('url'),row['original_url']]:
        if url and url not in sources:sources.append(url)
    dst.parent.mkdir(parents=True,exist_ok=True)
    errors=[]
    for url in sources:
        stage=None
        try:
            request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (ZR1X reference archive)'})
            with urllib.request.urlopen(request,timeout=35) as response,tempfile.NamedTemporaryFile(dir=dst.parent,delete=False) as fp:
                stage=Path(fp.name)
                while chunk:=response.read(1024*1024):fp.write(chunk)
            if sha(stage)!=row['sha256']:raise ValueError('SHA-256 differs')
            os.replace(stage,dst)
            return row['id']+' retrieved and verified'
        except (OSError,ValueError) as exc:
            errors.append(str(exc))
        finally:
            if stage:stage.unlink(missing_ok=True)
    return row['id']+' ERROR '+' / '.join(errors)
ids=set(args.id or [])
if ids-set(r['id'] for r in inventory):parser.error('Unknown image id')
rows=[r for r in inventory if (r['id'] in ids if ids else args.all or r['id'] in selected)]
with ThreadPoolExecutor(5) as executor:
    result=list(executor.map(fetch,rows))
print('\n'.join(result));raise SystemExit(any(' ERROR ' in msg for msg in result))
