"""Twin flag-shaped rear optics registered to the native Torch Red rear studio image."""
# Coordinates follow a 5x inspection crop of ext-014 at native pixel (425,294).
# The two arrows have different lengths, widths and slopes.
lamp_outline=np.array([(60,113),(80,86),(125,46),(151,36),(185,32),(238,35),
                       (445,49),(662,64),(871,81),(888,86),(898,96),(897,106),
                       (852,166),(852,177),(902,254),(907,268),(905,275),(535,263),
                       (171,251),(111,246),(91,236),(77,210),(64,160),(57,128)],float)
lamp_ctr=lamp_outline.mean(axis=0)
def to_rear_camera(uv):
    return (np.array([425,294])+np.array(uv)/5)*.6

# Recover a smoothly varying cover depth from the measured rear fascia, keeping
# each optical boundary on its own calibrated reference ray.
rear_center,rear_rot,(rear_cx,rear_cy,rear_fp)=backcam
def rear_basis(uv):
    u,vv=(np.asarray(uv)-[460,145])/[445,130]
    return np.array([1,u,u*u,u*u*u,u**4,vv,u*vv,vv*vv])
samples=[];depths=[]
for u in np.linspace(90,880,18):
    for vv in np.linspace(65+u*.045,228+u*.021,6):
        try:point=np.array(ray(to_rear_camera((u,vv)),backcam,0))
        except ValueError:continue
        samples.append(rear_basis((u,vv)));depths.append((point-rear_center)@rear_rot[2])
sample_matrix=np.array(samples);depths=np.array(depths)
coeff=np.linalg.lstsq(sample_matrix,depths,rcond=None)[0]
for _ in range(4):
    error=depths-sample_matrix@coeff;keep=np.abs(error-np.median(error))<max(.009,2.5*np.median(np.abs(error)))
    if np.count_nonzero(keep)>len(coeff):coeff=np.linalg.lstsq(sample_matrix[keep],depths[keep],rcond=None)[0]
def lamp_point(uv,offset,side):
    u,vv=to_rear_camera(uv);axis=rear_rot.T@np.array([(u-rear_cx)/rear_fp,(vv-rear_cy)/rear_fp,1.])
    point=rear_center+axis*(rear_basis(uv)@coeff-offset)
    point[1]*=-side
    return point

# Clip the color-mapped fascia exactly at the sealing flange. Preserve each
# surviving triangle's finish and interpolate its original normals and color
# where a cut crosses an edge.
def cut_lamp_socket():
    from mathutils.geometry import tessellate_polygon
    obj=bpy.data.objects.get('Rear fascia surface')
    if obj is None:return
    data=obj.data
    coordinates=np.array([tuple(v.co) for v in data.vertices])
    indices=np.array([tuple(face.vertices) for face in data.polygons])
    positions=coordinates.copy();positions[:,1]=-np.abs(positions[:,1])
    camera=(positions-rear_center)@rear_rot.T
    projected=(np.stack([rear_fp*camera[:,0]/camera[:,2]+rear_cx,rear_fp*camera[:,1]/camera[:,2]+rear_cy],axis=1)/.6-[425,294])*5
    aperture=lamp_ctr+(lamp_outline-lamp_ctr)*.973
    masks=[aperture[list(ids)] for ids in tessellate_polygon([[Vector((u,v,0)) for u,v in aperture]])]
    triangles=projected[indices];mx=triangles.max(axis=1);mn=triangles.min(axis=1)
    crop=(coordinates[indices][:,:,0].min(axis=1)>1.70)&np.all(mx>=aperture.min(axis=0),axis=1)&np.all(mn<=aperture.max(axis=0),axis=1)
    original_normals=np.zeros_like(coordinates)
    for loop,normal in zip(data.loops,data.corner_normals):original_normals[loop.vertex_index]=normal.vector
    attr=data.color_attributes['Surface tone']
    original_color=np.array([tuple(q.color) for q in attr.data])
    vertices=coordinates.tolist();colors=original_color.tolist();normals=original_normals.tolist()
    faces=indices[~crop].tolist();materials=[f.material_index for f,drop in zip(data.polygons,crop) if not drop]
    def subtract(poly,mask):
        # Store barycentric coordinates in the final three columns. Splitting
        # a convex polygon by a triangle yields at most three exterior pieces.
        if np.any(poly[:,:2].max(axis=0)<mask.min(axis=0)) or np.any(poly[:,:2].min(axis=0)>mask.max(axis=0)):return [poly]
        a,b,c=mask
        sign=np.sign((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))
        outside=[]
        for p,q in zip(mask,np.roll(mask,-1,axis=0)):
            d=q-p;val=sign*(d[0]*(poly[:,1]-p[1])-d[1]*(poly[:,0]-p[0]))
            if np.all(val>=-1e-8):continue
            if np.max(val)<=1e-8:return outside+[poly]
            inner=[];outer=[]
            for start,end,x,y in zip(poly,np.roll(poly,-1,axis=0),val,np.roll(val,-1)):
                (inner if x>=0 else outer).append(start)
                if (x>=0)!=(y>=0):
                    vertex=start+(end-start)*x/(x-y)
                    inner.append(vertex);outer.append(vertex)
            if len(outer)>=3:outside.append(np.asarray(outer))
            if len(inner)<3:return outside
            poly=np.asarray(inner)
        return outside
    for fi in np.flatnonzero(crop):
        source=indices[fi];original=np.column_stack([projected[source],np.eye(3)])
        pieces=[original]
        for mask in masks:
            pieces=[part for polygon in pieces for part in subtract(polygon,mask)]
            if not pieces:break
        if len(pieces)==1 and pieces[0] is original:
            faces.append(source.tolist());materials.append(data.polygons[fi].material_index);continue
        for polygon in pieces:
            polygon=polygon[np.linalg.norm(polygon[:,:2]-np.roll(polygon[:,:2],1,axis=0),axis=1)>1e-6]
            if len(polygon)<3:continue
            # Use perspective-correct weights on this physical source triangle.
            weight=polygon[:,2:]/camera[source,2];weight/=weight.sum(axis=1)[:,None]
            start=len(vertices);vertices.extend((weight@coordinates[source]).tolist())
            colors.extend((weight@original_color[source]).tolist())
            nor=weight@original_normals[source];nor/=np.maximum(np.linalg.norm(nor,axis=1,keepdims=True),1.e-12);normals.extend(nor.tolist())
            for j in range(1,len(polygon)-1):
                faces.append((start,start+j,start+j+1));materials.append(data.polygons[fi].material_index)
    new=bpy.data.meshes.new('Rear fascia with formed lamp apertures')
    new.from_pydata(vertices,[],faces)
    for m in data.materials:new.materials.append(m)
    new.polygons.foreach_set('material_index',np.asarray(materials,'i'))
    new.polygons.foreach_set('use_smooth',np.ones(len(faces),'?'))
    layer=new.color_attributes.new(name=attr.name,type=attr.data_type,domain='POINT')
    layer.data.foreach_set('color',np.asarray(colors,'f').ravel())
    new.update();new.normals_split_custom_set_from_vertices(normals);obj.data=new
    if data.users==0:bpy.data.meshes.remove(data)
cut_lamp_socket()

lamp_shell=mat('Rear optical housing graphite','1c1d21',.11,.39)
lamp_gasket=mat('Rear lamp compression seal','191a1d',.012,.72)
lamp_ruby=mat('Dark ruby optical carrier','66151c',.12,.22)
lamp_red=mat('Polished ruby light pipe','b51a27',.07,.29)
lamp_red.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=.17
lamp_red.node_tree.nodes.get('Principled BSDF').inputs['Specular IOR Level'].default_value=.24
lamp_glow=mat('Red guide optic','d92531',.03,.32)
lamp_glow.node_tree.nodes.get('Principled BSDF').inputs['Emission Color'].default_value=(.48,.004,.008,1)
lamp_glow.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=.10
lamp_glow.node_tree.nodes.get('Principled BSDF').inputs['Specular IOR Level'].default_value=.19
lamp_pocket=mat('Rear light trap','16171a',.015,.64)
reflector_silver=mat('Aluminized reflector cup','c2c2bf',.48,.30)
reflector_smoke=mat('Shade side of aluminized cup','a4a5a5',.51,.31)
reflector_bright=mat('Reflector rib silver','ccccca',.46,.28)
rear_cover=mat('Neutral clear outer lamp cover','d1d2d3',.005,.16)
rear_cover.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.065
prism_clear=mat('Clear reflector prism','c2c3c4',.025,.18)
prism_clear.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.17

rear_lamp_roots={}
for lamp_side,side_name in [(-1,'Left'),(1,'Right')]:
    group=empty(side_name+'_rear_lamp')
    group.parent=tail
    rear_lamp_roots[lamp_side]=group

def smooth_loop(points,passes=1):
    points=np.array(points,float)
    for _ in range(passes):
        nxt=np.roll(points,-1,axis=0)
        points=np.stack([.82*points+.18*nxt,.18*points+.82*nxt],axis=1).reshape(-1,2)
    return points

def rings(name,outline,layers,finish,side,cap=False):
    from mathutils.geometry import tessellate_polygon
    outline=np.array(outline);center=outline.mean(axis=0);n=len(outline);vv=[];ff=[]
    for scale,depth in layers:
        row=center+(outline-center)*scale
        vv.extend(lamp_point(p,depth,side) for p in row)
    for j in range(len(layers)-1):
        for i in range(n):
            k=(i+1)%n;ff.append((j*n+i,j*n+k,(j+1)*n+k,(j+1)*n+i))
    if cap:
        uv=center+(outline-center)*layers[-1][0]
        for tri in tessellate_polygon([[Vector((u,v,0)) for u,v in uv]]):
            # Subdivide the cover/cavity to follow the wrap toward the fender.
            tris=[np.array([uv[i] for i in tri])]
            for _ in range(2):
                fine=[]
                for a,b,c in tris:
                    ab=(a+b)/2;bc=(b+c)/2;ac=(a+c)/2
                    fine.extend([[a,ab,ac],[ab,b,bc],[ac,bc,c],[ab,bc,ac]])
                tris=fine
            for triplet in tris:
                j=len(vv);vv.extend(lamp_point(p,layers[-1][1],side) for p in triplet);ff.append((j,j+1,j+2))
    obj=mesh(name,vv,ff,finish,rear_lamp_roots[side])
    for face in obj.data.polygons:face.use_smooth=True
    return obj

arrow_edges=[
    ([(170,52),(143,55),(115,73),(84,104),(77,116),(82,136),(99,168),(118,200),
      (135,219),(159,229),(219,232),(388,243),(494,248),(516,249)],
     [(173,52),(170,63),(158,88),(147,107),(144,116),(151,128),(171,147),(192,166),
      (219,184),(249,192),(300,198),(407,211),(488,224),(516,247)]),
    ([(575,77),(552,77),(531,90),(492,125),(480,140),(485,156),(502,184),(522,216),
      (541,233),(566,244),(631,247),(755,252),(846,256),(869,257)],
     [(578,76),(573,87),(560,112),(550,136),(549,144),(557,154),(575,170),(599,190),
      (626,202),(659,208),(704,214),(783,222),(847,233),(869,255)])
]
reflector_quads=[[(213,52),(495,67),(425,119),(192,106)],[(617,76),(852,94),(786,143),(600,130)]]
pockets=[[(173,122),(442,141),(470,195),(397,199),(256,181),(204,160)],
         [(579,145),(819,160),(847,220),(774,217),(641,197),(599,172)]]

def arrow(name,edges,side):
    outer,inner=[np.array(edge,float) for edge in edges]
    fractions=[0,.02,.10,.22,.53,.78,.91,.98,1];sections=[]
    for i,(a,b) in enumerate(zip(outer,inner)):
        t=i/(len(outer)-1);rise=np.clip(np.linalg.norm(b-a)/42,.20,1)
        sections.append([lamp_point((1-u)*a+u*b,.0035+rise*np.interp(u,fractions,[0,.003,.008,.009,.01,.01,.007,.0025,0])+.0018*np.sin(pi*t),side) for u in fractions]
                        +[lamp_point(b,-.011,side),lamp_point(a,-.011,side)])
    obj=loft(name,sections,lamp_ruby,rear_lamp_roots[side]);obj.data.materials.append(lamp_red);obj.data.materials.append(lamp_glow)
    n=len(sections[0])
    for k,f0 in enumerate(obj.data.polygons):
        u=k%n;f0.use_smooth=True
        if k<(len(sections)-1)*n:f0.material_index=2 if u in (2,3,4) else 1 if u in (1,5,6) else 0

def reflector(name,quad,side):
    quad=np.array(quad,float)
    def uv(u,vv):
        return (1-vv)*(quad[0]*(1-u)+quad[1]*u)+vv*(quad[3]*(1-u)+quad[2]*u)
    outline=smooth_loop(quad);rings(name+' black pocket',outline,[(1.095,.001),(1.07,.003),(1.015,-.008),(.94,-.024)],lamp_pocket,side,True)
    verts=[];faces=[];mats=[]
    def tile(points,material):
        idx=len(verts);verts.extend(lamp_point(uv(u,vv),depth,side) for u,vv,depth in points)
        faces.append(tuple(range(idx,len(verts))));mats.append(material)
    for cell,(a,b) in enumerate(zip([.025,.262,.500,.735],[.258,.496,.731,.977])):
        center=(a+b)/2+.018*np.sin(2*cell+.3)
        # Each well has a four-sided chrome return and a smaller stepped back.
        rim=[(a,.08,-.006),(b,.08,-.006),(b,.925,-.006),(a,.925,-.006)]
        floor=[(a+.023,.213,-.015),(b-.035,.18,-.015),(b-.033,.74,-.014),(a+.03,.79,-.014)]
        for j in range(4):
            k=(j+1)%4;tile([rim[j],rim[k],floor[k],floor[j]],[1,0,2,0][j])
        for j in range(4):
            tile([floor[j],floor[(j+1)%4],(center,.43+.075*np.sin(cell*1.82),-.012)],[2,1,0,2][(j+cell)%4])
    obs=mesh(name+' faceted reflector wells',verts,faces,reflector_silver,rear_lamp_roots[side])
    obs.data.materials.append(reflector_smoke);obs.data.materials.append(reflector_bright)
    for f0,index in zip(obs.data.polygons,mats):f0.material_index=index
    # The clear inner insert carries shallow sawtooth flutes across the cells.
    verts=[];faces=[]
    for j in range(26):
        a=.018+.96*j/26;b=a+.96/26
        idx=len(verts)
        for tx,z in [(a,-.0012),((a+b)/2,.0011),(b,-.0012)]:
            for vy in [.06,.94]:verts.append(lamp_point(uv(tx,vy),z,side))
        faces.extend([(idx,idx+2,idx+3,idx+1),(idx+2,idx+4,idx+5,idx+3)])
    mesh(name+' clear prismatic insert',verts,faces,prism_clear,rear_lamp_roots[side])

for lamp_side in [-1,1]:
    outline=smooth_loop(lamp_outline)
    rings('Tail lamp sealing flange',outline,[(1.024,-.019),(1.024,-.001),(1,.002)],lamp_gasket,lamp_side)
    rings('Tail lamp molded surround',outline,[(1,-.007),(1,.003),(.985,.006),(.956,.003),(.936,-.009),(.92,-.029)],lamp_shell,lamp_side,True)
    for i,(edges,quad,pocket) in enumerate(zip(arrow_edges,reflector_quads,pockets)):
        prefix='Outboard' if i==0 else 'Inboard'
        rings(prefix+' tail lamp lower light trap',smooth_loop(pocket),[(1.02,-.004),(1,-.006),(.87,-.020),(.73,-.028)],lamp_pocket,lamp_side,True)
        arrow(prefix+' ruby arrow light guide',edges,lamp_side)
        reflector(prefix+' tail lamp',quad,lamp_side)
    cover=rings('Tail lamp clear outer cover',outline,[(.987,.014),(.975,.017)],rear_cover,lamp_side,True)
    lens_normals(cover,False)
# The most outboard sliver turns onto the quarter panel, nearly edge-on in
# frame 14. Frame 13 resolves its swept clear corner and dark lower return.
def corner_surface(name,outline,finish,depth):
    camera=frame_camera(13)
    uv=[(u*.6,vv*.6) for u,vv in outline]
    near=bounded_optic(name,uv,camera,finish,rear_lamp_roots[-1],depth)
    far_data=near.data.copy();far=bpy.data.objects.new(name+' right',far_data)
    sc.collection.objects.link(far);far.parent=rear_lamp_roots[1]
    for vert in far_data.vertices:vert.co.y=-vert.co.y
    for face in far_data.polygons:face.flip()
    for obj,side in [(near,-1),(far,1)]:
        normals=[tuple(Vector((.46+.35*(v.co.z-.77),.85*side,.095)).normalized()) for v in obj.data.vertices]
        obj.data.normals_split_custom_set_from_vertices(normals)
corner_outline=[(600,302.8),(592,303.1),(583,305.5),(575,309.8),(569,315.3),
                (566.5,319.2),(566.8,322.5),(570.3,327.9),(579,334.6),(590.5,340.5),
                (595,342.2),(584.5,332.7),(579.8,326.3),(578.2,321.1),(580,316.7),(589,308.2)]
corner_surface('Tail lamp outboard wraparound bezel',corner_outline,lamp_shell,.003)
corner_surface('Tail lamp outboard upper reflection facet',[(598,303.7),(589,305.1),(580,308.4),
    (573,312.8),(568.7,318.5),(569,320.1),(577.7,318.4),(584,312.1),(590,307.6)],chrome,.006)
corner_surface('Tail lamp outboard lower reflection facet',[(568.9,321.5),(572,326.9),(580,333.7),
    (589,338.6),(583,332.4),(577.7,326.4),(575.3,322.2)],reflector_smoke,.005)
