"""Short/long-arm layout on the four wheel datums. Mounting points are approximate."""
def build_axle_supports(axle_name, x, rear):
    axle = empty(axle_name+'_suspension')
    cradle = subassembly(axle_name+'_cradle',axle)
    # Bolt-on subframe crossmembers sit ahead of and behind the drive housing.
    for dx in (-.235,.24):
        sections=[]
        for y in np.linspace(-.49,.49,17):
            z=.206+.057*(abs(y)/.49)**2
            sections.append([(x+dx+u,y,z+v) for u,v in
                    [(-.034,-.025),(.031,-.025),(.039,-.016),(.039,.022),
                     (.028,.032),(-.029,.032),(-.038,.022),(-.038,-.016)]])
        loft('Crossmember extrusion',sections,gunmetal,cradle)
    for s in (-1,1):
        side='left' if s<0 else 'right'
        corner=subassembly(axle_name+'_'+side+'_links',axle)
        y=s*.462; center_z=.353 if rear else .3365
        smooth_pipe('Cradle side rail',[(x-.25,y,.266),(x-.14,y+s*.025,.276),
               (x+.11,y+s*.025,.278),(x+.253,y,.269)],.034,gunmetal,cradle)
        # Three-dimensional Y-shaped forgings, with thicker eyes at the bushes.
        for is_upper,at_z,inner,halfspan in [(False,.224,.45,.201),(True,.474,.513,.129)]:
            outer=.738 if is_upper else .753
            arm=subassembly(('Upper_control_arm_' if is_upper else 'Lower_control_arm_')+side,corner)
            for fore in (-1,1):
                sections=[]
                for u,w,d in [(0,.033,.024),(.10,.033,.026),(.28,.027,.022),(.66,.024,.017),(.84,.028,.018),(1,.04,.026)]:
                    xx=x+(1-u)**1.25*fore*halfspan
                    yy=s*((1-u)*inner+u*outer)
                    zz=at_z+.049*u if is_upper else at_z-.014*sin(pi*u)+.006*u
                    sections.append([(xx+w*cos(t),yy,zz+d*sin(t)) for t in np.linspace(0,2*pi,16,endpoint=False)])
                obj=loft('Forged wishbone branch',sections,cast,arm)
                for ff in obj.data.polygons[:-2]:ff.use_smooth=True
                xx=x+fore*halfspan
                ellipse_case('Control arm pivot bushing',[(xx-.026,s*inner,at_z,.032,.032),(xx+.026,s*inner,at_z,.032,.032)],rubber,arm)
                ellipse_case('Pivot sleeve',[(xx-.028,s*inner,at_z,.012,.012),(xx+.028,s*inner,at_z,.012,.012)],gunmetal,arm)
        upright=subassembly('Upright_and_bearing_'+side,corner)
        sections=[[(x+dx,s*(yy+dy),zz) for dx,dy in [(-w,-.014),(w,-.014),(w+.008,.014),(-w,.014)]]
                  for yy,zz,w in [(.752,.220,.026),(.758,.261,.036),(.763,center_z,.063),
                                  (.747,.429,.036),(.74,.524,.023)]]
        loft('Wheel bearing upright',sections,cast,upright)
        ellipse_case('Bearing hub',[(s*.741,x,center_z,.051,.051),(s*.773,x,center_z,.067,.067),
                      (s*.81,x,center_z,.060,.060)],gunmetal,upright,axis='y')
        spring=subassembly('Spring_and_damper_'+side,corner)
        lower=Vector((x-.021,s*.686,.238)); upper=Vector((x-.043,s*.537,.657 if rear else .630))
        axis=(upper-lower).normalized(); unit=axis.cross(Vector((1,0,0))).normalized(); other=axis.cross(unit)
        def sleeve(name,profile,material):
            rings=[[tuple(lower.lerp(upper,t)+(unit*cos(q)+other*sin(q))*float(r)) for q in np.linspace(0,2*pi,28,endpoint=False)] for t,r in profile]
            obj=loft(name,rings,material,spring)
            for ff in obj.data.polygons[:-2]:ff.use_smooth=True
        sleeve('Monotube damper',[(0,.020),(.11,.027),(.54,.027),(.58,.019),(.65,.018)],gunmetal)
        sleeve('Polished damper rod',[(.52,.009),(.92,.009)],lip)
        sleeve('Lower spring perch',[(.17,.027),(.20,.053),(.224,.055),(.24,.043)],gunmetal)
        sleeve('Upper spring seat',[(.84,.047),(.86,.054),(.90,.053),(.95,.027),(1,.023)],dark)
        coil=[]
        for index,t in enumerate(np.linspace(0,1,145)):
            around=t*2*pi*5.55
            rr=float(.044-.003*abs(t-.5)*2)
            coil.append(tuple(lower.lerp(upper,.217+t*.637)+(unit*cos(around)+other*sin(around))*float(rr)))
        path('Helical road spring',coil,.0072,dark,spring)
    smooth_pipe('Anti-roll bar',[(x+.12,-.677,.261),(x+.266,-.615,.261),(x+.284,-.49,.28),
         (x+.284,.49,.28),(x+.266,.615,.261),(x+.12,.677,.261)],.0125,dark,cradle)

build_axle_supports('Front',-1.3615,False)
build_axle_supports('Rear',1.3615,True)
