"""Fit the forward face of the Chevrolet cubemap to the steering rim silhouette."""
import numpy as np
from scipy.optimize import least_squares
from pathlib import Path
import json
# Evaluate the same sampled rim section as the Blender wheel builder.
import math
from math import pi,cos,sin
source=(Path(__file__).parent/'steering.py').read_text()
exec(source[source.index('steer='):source.index('wheel_leather=')])
exec(source[source.index('def wheel_point'):source.index('def smooth_object')])
exec(source[source.index('profile=wheel_spline'):source.index('rim=smooth_object')])
v=np.asarray(verts)
# Outer rim extents at the 610 px survey size. Cubemap face horizontal and vertical angles are each 90 degrees.
box=np.array([158,445,190,453]);center=np.array([301.5,314.5])
def cam(p):
 x,y,z,tilt,yaw=p;phi,theta=np.deg2rad([tilt,yaw]);forward=np.array([-np.cos(phi)*np.cos(theta),np.sin(theta)*np.cos(phi),-np.sin(phi)]);right=np.cross(forward,[0,0,1]);right/=np.linalg.norm(right);up=np.cross(right,forward);return np.array([x,y,z]),forward,right,up
def uv(v,p):
 c,fw,rt,up=cam(p);d=v-c;return np.column_stack([305+305*(d@rt)/(d@fw),305-305*(d@up)/(d@fw)])
def residual(p):
 q=uv(v,p);extent=np.array([q[:,0].min(),q[:,0].max(),q[:,1].min(),q[:,1].max()]);return np.r_[extent-box,(p[1]+.39)*190,(p[2]-.925)*45,(p[4])*0.5]
p=least_squares(residual,[-.145,-.39,.92,22,0],bounds=([-.34,-.43,.82,0,-9],[.015,-.35,1.05,55,9])).x;c,fw,*_=cam(p);print(p, residual(p));(Path(__file__).parent/'cabin-camera.json').write_text(json.dumps(dict(eye=c.tolist(),look=(c+fw).tolist()),indent=2))
