"""GT2 front seats, fitted to the Jet Black panorama and Chevrolet seat photographs."""
import math

seat_leather = mat('GT2 Jet Black leather', '333338', .015, .48)
seat_pad = mat('GT2 perforated Jet Black leather', 'ffffff', .01, .57)
seat_back = mat('GT2 graphite shell', '24272c', .22, .32)
seat_thread = mat('GT2 graphite stitching', '666669', 0, .78)
seat_belt = mat('Black woven seat belt', '292a2d', 0, .85)
seat_stamp = mat('Head restraint debossing', '252529', .02, .51)
buckle_red = mat('Seat belt release', 'af2a28', 0, .54)

# A small seamless albedo tile preserves the perforation pattern in Blender and glTF.
tile = bpy.data.images.new('GT2 leather perforations', width=64, height=64, alpha=True)
row, col = np.mgrid[:64,:64]
hole_dist = np.minimum.reduce([
    np.hypot((col - dx + 32) % 64 - 32, (row - dy + 32) % 64 - 32)
    for dx, dy in ((16,16),(48,48))
])
tone = (51 + 3*np.sin(col*.97)*np.sin(row*1.39)
        - 28*np.clip(1-(hole_dist-3.0)/1.75,0,1)) / 255.
tile.pixels.foreach_set(np.stack((tone,tone,tone*1.045,np.ones_like(tone)),axis=-1).astype('f').ravel())
tile.pack()
nodes = seat_pad.node_tree
texture = nodes.nodes.new('ShaderNodeTexImage')
texture.image = tile
nodes.links.new(texture.outputs['Color'], nodes.nodes.get('Principled BSDF').inputs['Base Color'])

def make_seat(side):
    center_y = side*.383
    rail_offset = -.182 if side < 0 else 0
    side_name = 'Driver' if side < 0 else 'Passenger'

    def xyz(x, y, z):
        return (x+rail_offset, y+center_y, z)

    def name(part):
        return side_name + ' seat ' + part

    def shaped_pad(part, stations, material, horizontal=False, exponent=.72):
        # Sections are (axis, front/bottom, rear/top, lateral center, half width).
        stations = np.asarray(stations,dtype=float)
        ring = 40
        verts = []
        for axis, low, high, lateral, half in stations:
            mid = (low+high)/2
            for i in range(ring):
                a = 2*pi*i/ring
                c, s = cos(a), sin(a)
                height = mid + (high-low)/2 * math.copysign(abs(c)**exponent,c)
                y = lateral + half * math.copysign(abs(s)**exponent,s)
                verts.append(xyz(axis,y,height) if horizontal else xyz(height,y,axis))
        faces = []
        for j in range(len(stations)-1):
            for i in range(ring):
                n = (i+1)%ring
                faces.append((j*ring+i, j*ring+n, (j+1)*ring+n, (j+1)*ring+i))
        faces += [tuple(reversed(range(ring))), tuple(range(len(verts)-ring,len(verts)))]
        if horizontal: faces = [p[::-1] for p in faces]
        obj = mesh(name(part),verts,faces,material,cab)
        for face in obj.data.polygons:
            face.use_smooth = True
        if material == seat_pad:
            uv = obj.data.uv_layers.new(name='Leather grain')
            for loop in obj.data.loops:
                x,y,z = verts[loop.vertex_index]
                uv.data[loop.index].uv = (y/.012, (x if horizontal else z)/.012)
        return obj

    def front_at_fraction(low, high, frac, exponent=.72):
        return (low+high)/2 - (high-low)/2 * (1-abs(frac)**(2/exponent))**(exponent/2)

    def cord(part, coords, radius, material=seat_thread):
        return path(name(part), [xyz(*v) for v in coords],radius,material,cab)

    # Mirrored front-to-back seat rails retain the different driver/passenger adjustment.
    for hand in (-1,1):
        roundbox(name('adjuster rail'),xyz(.026,hand*.148,.283),
                 (.47,.025,.031),dark,cab,.006)
    shaped_pad('cushion pan',[
        (-.252,.330,.349,0,.145),(-.240,.312,.364,0,.192),
        (-.168,.300,.380,0,.209),(.155,.298,.365,0,.217),(.250,.318,.368,0,.185)
    ],seat_back,horizontal=True)
    shaped_pad('perforated cushion',[
        (-.250,.363,.413,0,.117),(-.230,.348,.437,0,.147),
        (-.153,.344,.439,0,.156),(-.012,.347,.417,0,.151),
        (.115,.347,.404,0,.145),(.219,.361,.424,0,.125)
    ],seat_pad,horizontal=True)
    for hand in (-1,1):
        shape=[(-.239,.35,.412,.151,.031),(-.216,.340,.452,.166,.049),
               (-.128,.334,.474,.176,.053),(.013,.331,.471,.182,.050),
               (.150,.339,.453,.171,.053),(.229,.36,.445,.152,.05)]
        shaped_pad('thigh bolster',[(a,b,c,hand*d,e) for a,b,c,d,e in shape],
                   seat_leather,horizontal=True)
        cord('thigh bolster piping',[(a,hand*(d-.018),c-.006) for a,b,c,d,e in shape],
             .00125)
    for x,top_z in [(-.125,.433),(.009,.411)]:
        cord('cushion panel seam',[(x+.021,-.135,top_z-.009),(x+.010,-.074,top_z-.002),
                                   (x,0,top_z+.001),(x+.010,.074,top_z-.002),
                                   (x+.021,.135,top_z-.009)],.0012,seat_stamp)

    # Stop the lower shell below the shoulder opening. The shoulder bridge and two
    # side wings provide its actual boundary, so daylight remains visible through it.
    shaped_pad('bucket shell',[
        (.365,.172,.263,0,.148),(.413,.165,.277,0,.201),
        (.490,.185,.299,0,.218),(.624,.209,.323,0,.223),
        (.730,.245,.337,0,.206),(.794,.263,.346,0,.164),
        (.809,.286,.340,0,.115)
    ],seat_back)
    back_insert=[(.411,.160,.235,0,.102),(.442,.158,.255,0,.147),
                 (.501,.167,.266,0,.156),(.572,.184,.282,0,.149),
                 (.655,.205,.304,0,.145),(.742,.229,.319,0,.136),
                 (.792,.246,.323,0,.122),(.813,.271,.316,0,.086)]
    shaped_pad('perforated back panel',back_insert,seat_pad)
    cord('back panel center welt',[(a,0,z) for z,a,b,c,w in back_insert],.0014,seat_stamp)
    for z,x in [(.486,.163),(.523,.174)]:
        cord('lumbar panel welt',[(x+.010,-.139,z-.018),(x+.004,-.084,z-.015),
                                  (x,0,z+.008),(x+.004,.084,z-.015),
                                  (x+.010,.139,z-.018)],.0014,seat_stamp)

    # Each back bolster has a lower rib, a waist and a shoulder that curls up
    # to the sides of the head restraint, as seen in cabin-back and press-40.
    for hand in (-1,1):
        flank=[(.397,.141,.257,.143,.045),(.460,.110,.279,.170,.055),
               (.542,.106,.293,.186,.047),(.627,.135,.313,.189,.045),
               (.696,.168,.327,.179,.045),(.755,.197,.336,.168,.039),
               (.801,.215,.338,.168,.044),(.851,.228,.341,.170,.048),
               (.894,.237,.344,.162,.045),(.931,.261,.343,.138,.037),
               (.953,.286,.334,.119,.027),(.963,.309,.326,.109,.010)]
        shaped_pad('sculpted side and shoulder bolster',
                   [(z,a,b,hand*y,w) for z,a,b,y,w in flank],seat_leather)
        edge=[(front_at_fraction(a,b,.62)-.0013,hand*(y-w*.62),z) for z,a,b,y,w in flank]
        cord('shoulder bolster piping',edge,.00142)
        cord('shoulder topstitch',[(front_at_fraction(a,b,.51)-.001,hand*(y-w*.51),z) for z,a,b,y,w in flank],
             .0007)
    # The rounded trapezoidal opening beneath the head restraint passes through the shell.
    outer=[(-.155,.806),(-.145,.850),(-.128,.903),(-.094,.922),
           (0,.934),(.094,.922),(.128,.903),(.145,.850),(.155,.806),
           (.127,.778),(.080,.795),(0,.803),(-.080,.795),(-.127,.778)]
    inner=[(-.134,.813),(-.130,.848),(-.108,.886),(-.078,.901),
           (0,.906),(.078,.901),(.108,.886),(.130,.848),(.134,.813),
           (.118,.808),(.075,.818),(0,.824),(-.075,.818),(-.118,.808)]
    def bridge_x(z):
        return .279+.27*(z-.81)
    vv=[];ff=[];n=len(outer)
    for inset,section in [(0,outer),(0,inner),(.031,inner),(.031,outer)]:
        vv.extend(xyz(bridge_x(z)+inset,y,z) for y,z in section)
    for j in range(4):
        for i in range(n):
            ni=(i+1)%n;nj=(j+1)%4
            ff.append((j*n+i,j*n+ni,nj*n+ni,nj*n+i))
    bridge=mesh(name('carbon shoulder opening surround'),vv,ff,carbon,cab)
    bevel=bridge.modifiers.new('Rounded carbon edges','BEVEL')
    bevel.width=.0035;bevel.segments=3
    for f0 in bridge.data.polygons:f0.use_smooth=True

    head=[(.888,.274,.346,0,.063),(.902,.264,.365,0,.082),
          (.947,.254,.381,0,.099),(.999,.254,.387,0,.097),
          (1.053,.269,.382,0,.084),(1.078,.292,.365,0,.070),
          (1.084,.315,.351,0,.055)]
    shaped_pad('integral head restraint',head,seat_leather,exponent=.70)
    for hand in (-1,1):
        cord('restraint edge stitching',
             [(front_at_fraction(a,b,.78,.70)-.001,hand*w*.78,z) for z,a,b,c,w in head],.00105)
        cord('restraint outer welt',
             [(front_at_fraction(a,b,.84,.70)-.001,hand*w*.84,z) for z,a,b,c,w in head],.0014,seat_stamp)
    # Shallow crossed-flags embossing on the front leather. The emblem follows
    # the pad face, and its relief is deliberately below that of the seams.
    for hand in (-1,1):
        outline=[(0,.970),(.009,.990),(.043,1.014),(.041,.995),(.016,.979),(0,.970)]
        cord('head restraint flag embossing',[(.253+abs(y)*.07,hand*y,z) for y,z in outline],
             .00115,seat_stamp)
        for y in (.017,.027,.036):
            cord('head restraint flag field',[(.253+y*.07,hand*y,.979+(y-.017)*.78),
                                             (.253+y*.07,hand*y,.989+(y-.017)*.77)],
                 .00075,seat_stamp)

    # The parked three-point belt follows the outside flank. The separate
    # receiver sits on the inboard edge of the cushion beside the console.
    coords=[(.340,.189,.890),(.333,.196,.917),(.316,.205,.928),
            (.302,.216,.919),(.294,.220,.902),(.279,.229,.853),
            (.220,.238,.717),(.161,.237,.570),(.131,.223,.440),(.137,.207,.341)]
    strap=[];width=.043
    for x,y,z in coords:
        for edge in (-1,1):
            strap.append(xyz(x+edge*width*.43,side*(y+edge*width*.20),z))
    web=mesh(name('three point belt webbing'),strap,
             [(2*j,2*j+1,2*j+3,2*j+2) for j in range(len(coords)-1)],seat_belt,cab)
    web.modifiers.new('Woven thickness','SOLIDIFY').thickness=.002
    cord('buckle stalk',[(.059,-side*.207,.315),(.020,-side*.214,.426)],.011,seat_belt)
    roundbox(name('buckle receiver'),xyz(.013,-side*.218,.444),
             (.058,.035,.060),bk,cab,.008,ry=.20)
    roundbox(name('buckle release'),xyz(.008,-side*.218,.473),
             (.043,.026,.010),buckle_red,cab,.003,ry=.20)

for seat_side in (-1,1):
    make_seat(seat_side)
