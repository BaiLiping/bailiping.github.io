"""Fitted aero assemblies and lamp bezels. Called in the Blender builder's vehicle coordinates."""
import mathutils
from mathutils.bvhtree import BVHTree
tree=BVHTree.FromPolygons(v.tolist(),f.tolist(),all_triangles=True)
cal=json.loads((ROOT/'rig.json').read_text());D,fp,el,phase,cx,cy,tx,ty,tz=cal
def frame_camera(i):
 a=np.deg2rad((i-1)*12+24+phase);elv=np.deg2rad(el)
 back=np.array([-cos(a)*cos(elv),-sin(a)*cos(elv),sin(elv)]);rt=np.array([sin(a),-cos(a),0]);up=np.cross(back,rt)
 return np.array([tx,ty,tz])+back*D,np.stack([rt,-up,-back]),(cx*.6,cy*.6,fp*.6)
def upper_camera():
 xc,yc,dist,ax,ay,roll,fc=json.loads((ROOT/'plan_camera.json').read_text())
 rot=np.array(mathutils.Euler(tuple(np.deg2rad([ax,ay,roll])),'XYZ').to_matrix())
 rr=np.diag([1,-1,-1])@rot.T;return np.array([0,0,.62])+rr.T@np.array([0,0,-dist]),rr,(xc,yc,fc)
def ray(co,cam,push=.004):
 c,r,(cx,cy,fp)=cam;vec=r.T@np.array([(co[0]-cx)/fp,(co[1]-cy)/fp,1.])
 d=Vector(vec.tolist()).normalized();hit,n,idx,depth=tree.ray_cast(Vector(c.tolist()),d)
 if hit is None:raise ValueError('unprojected reference landmark '+str(co))
 return tuple(hit-d*push)
def patch(name,polygon,cam,m,par,push=.005):
 # Subdivide the triangular fans in source-camera coordinates to follow the curved skin exactly.
 xy=np.array(polygon,dtype=float);center=xy.mean(axis=0);vv=[];ff=[]
 for aa,bb in zip(xy,np.roll(xy,-1,axis=0)):
  sec=[list(center+u*(aa-center)+t*(bb-center)) for u,t in [(0,0),(1,0),(0,1)]]
  tri=[np.array(sec)]
  steps=5 if name in ('Main front cooling aperture','Rear diffuser') else 4 if name in ('Front cooling intake','Rear outboard cooling vent') else 3
  for _ in range(steps):
   sub=[]
   for a,b,c in tri:
    ab=(a+b)/2;bc=(b+c)/2;ca=(c+a)/2;sub.extend([[a,ab,ca],[ab,b,bc],[ca,bc,c],[ab,bc,ca]])
   tri=sub
  for triple in tri:
   try:co=[ray(pt,cam,push) for pt in triple]
   except ValueError:continue
   idx=len(vv);vv.extend(co);ff.append((idx,idx+1,idx+2))
 o=mesh(name,vv,ff,m,par)
 if name in ('Main front cooling aperture','Front cooling intake','Rear outboard cooling vent','Rear diffuser','Quad exhaust recess','Tail light pocket','Red tail optic'):
  average=Vector(((-1 if cam[0][0]<0 else 1),0,.06)).normalized()
  for fa in o.data.polygons:fa.use_smooth=True
  o.data.normals_split_custom_set_from_vertices([tuple(average)]*len(vv))
 return o
def line_on(name,coords,cam,material,r,par,push=.008):
 pts=[]
 for p1,p2 in zip(coords,coords[1:]):
  for k in range(9):
   try:pts.append(ray(np.array(p1)*(1-k/9)+np.array(p2)*k/9,cam,push))
   except ValueError:pass
 try:pts.append(ray(coords[-1],cam,push))
 except ValueError:pass
 if len(pts)>1:path(name,pts,r,material,par)
topcam=upper_camera();fcam=frame_camera(29);backcam=frame_camera(14)
lensdark=mat('Lamp graphite surround','34383b',.32,.23);lensmid=mat('Dark recessed composite','15191c',.015,.81);ice=mat('Daytime-light diffuser','e0e3da',.15,.24);ruby=mat('Tail-lamp red','bc1018',.07,.24);rb=ruby.node_tree.nodes.get('Principled BSDF');rb.inputs['Emission Color'].default_value=(.51,.004,.005,1);rb.inputs['Emission Strength'].default_value=.15;amber=mat('Amber marker','d67d36',.06,.29)
# The wing has a swept, constant-section carbon blade, a pair of central strakes and two raised endplates.
stations=[]
for yy in np.linspace(-.962,.962,41):
 frac=(abs(yy)/.962)**1.8;lead=1.981-.24*frac;chord=.386-.013*frac;zz=1.12+.012*frac
 stations.append([(lead+chord*u,yy,zz+dz) for u,dz in [(0,-.035),(.09,-.021),(.35,-.008),(.70,.007),(1,.039),(.998,.025),(.70,-.010),(.32,-.029),(.07,-.041)]])
o=loft('Carbon rear wing blade',stations,carbon,wing)
for fa in o.data.polygons:fa.use_smooth=True
for side in [-1,1]:
 yy=side*.955;xx=1.747
 sec=[]
 for dy in [-.006,.006]:
  sec.append([(xx+ux,yy+dy+side*.22*max(zz-1.12,0),zz) for ux,zz in [(0,1.119),(.029,1.147),(.077,1.167),(.159,1.190),(.300,1.217),(.397,1.231),(.375,1.201),(.368,1.119),(.353,1.096),(.054,1.090)]])
 loft('Aero wing endplate',sec,carbon,wing)
 yy=side*.412;sec=[]
 for dy in [-.015,.015]:
  sec.append([(xx,yy+dy,zz) for xx,zz in [(1.823,.943),(1.92,.953),(2.079,1.13),(2.009,1.136),(1.903,1.038)]])
 loft('Wing stanchion',sec,carbon,wing)
 sec=[]
 for dy in [-.004,.004]:
  sec.append([(xx,yy+dy,zz) for xx,zz in [(1.934,1.126),(2.043,1.156),(2.181,1.177),(2.247,1.163),(2.17,1.134)]])
 loft('Wing aero strake',sec,carbon,wing)
exec(compile((ROOT/'mirrors.py').read_text(),str(ROOT/'mirrors.py'),'exec'))
# Painted mirror shells attach to the window end of each door.
for s in [-1,1]:
 pivot=np.array(doors[s].location)
 # Interior sail and outboard gasket bridge the card, window sill and A-pillar at the mirror attachment.
 sections=[]
 for yy in [.653,.693,.747,.792]:
  shape=[(-.869,.726),(-.868,.785),(-.793,.862),(-.756,.890),(-.693,.819),(-.593,.770),(-.585,.744)]
  shear=(yy-.653)*.16
  sections.append([tuple(np.array([xx+shear,s*yy,zz-.10*(yy-.653)])-pivot) for xx,zz in shape])
 sail=loft('Triangular door mirror sail',sections,dark,doors[s])
 for face in sail.data.polygons:face.use_smooth=False
 padsection=[]
 for yy,ww,hh in [(.763,.056,.038),(.798,.058,.04),(.824,.042,.028)]:
  padsection.append([tuple(np.array([-.708+ww*cos(t),s*yy,.803+hh*sin(t)])-pivot) for t in np.linspace(0,2*pi,22,endpoint=False)])
 loft('Mirror mounting gasket',padsection,bk,doors[s])
 build_mirror(s,doors[s],pivot)
def facing_patch(name,poly,cam,m,parent,push=.008,side_copy=False):
 o=patch(name,poly,cam,m,parent,push)
 cam_pos=np.array(cam[0]);me=o.data
 for face in me.polygons:
  if np.dot(face.normal,cam_pos-np.array(face.center))<0:face.flip()
 for vert in me.vertices:vert.co-=parent.location
 if side_copy:
  par=doors[1] if parent==doors[-1] else parent
  meshcopy=me.copy();copy=bpy.data.objects.new(name+' right',meshcopy);sc.collection.objects.link(copy);copy.parent=par
  for vert in meshcopy.vertices:vert.co.y*=-1
  for poly in meshcopy.polygons:poly.flip()
 return o
# Recreate the top and trailing arms of the wishbone intake bezel from the broadside image.
sidecam=frame_camera(6)
rocker=[(294,310),(326,308),(476,304),(544,301),(625,301),(659,300),(657,307),(493,312),(340,316),(296,315)]
facing_patch('Carbon rocker blade',rocker,sidecam,carbon,body,.010,True)
# Filler cap is present only on the driver side.
painted_cap=[(610+10.3*cos(t),184+10.6*sin(t)) for t in np.linspace(0,2*pi,45)]
line_on('Flush fuel filler door',painted_cap,sidecam,dark,.0022,body,.008)
# Low front splitter and raised flics follow the nose around to the front wheel clearances.
section=[]
for yy in np.linspace(-.99,.99,61):
 amp=abs(yy);xx=np.interp(amp,[0,.36,.65,.82,.97,.99],[-2.462,-2.44,-2.346,-2.236,-2.039,-1.994]);zz=.113+.018*amp
 section.append([(xx,yy,zz+.012),(xx+.128,yy,zz+.017),(xx+.170,yy,zz+.003),(xx+.025,yy,zz-.006)])
o=loft('Front carbon splitter',section,carbon,bumper)
for ff in o.data.polygons:ff.use_smooth=True
# The upper corner vane is its own curved foil. The calibrated tip is at
# frame 06 (259,474) and frame 29 (1064,489) on the driver side. The top
# lifts 124 mm from the forward part of the blade to the tip.
flic_stations=[
 (-2.357,.391,.435,.145,.150,.006),(-2.303,.456,.542,.147,.152,.006),
 (-2.228,.583,.697,.149,.158,.006),(-2.141,.722,.836,.149,.162,.007),
 (-2.070,.815,.929,.149,.164,.008),(-2.029,.850,.969,.151,.179,.009),
 (-1.969,.891,.981,.159,.202,.011),(-1.904,.915,.985,.182,.225,.013),
 (-1.849,.931,.987,.214,.253,.015),(-1.794,.945,.988,.248,.284,.013),
 (-1.759,.954,.985,.275,.302,.008)]
for sign in [-1,1]:
 sections=[];returns=[]
 for xx in np.linspace(flic_stations[0][0],flic_stations[-1][0],67):
  y0,y1,z0,z1,th=[np.interp(xx,[s[0] for s in flic_stations],[s[i] for s in flic_stations]) for i in range(1,6)]
  sec=[]
  for fraction,rise,thickness in [(0,0,0),(.23,.11,0),(.54,.36,0),(.79,.68,0),(.95,.955,0),
                                  (1,1,-.24),(.98,.97,-1),(.77,.66,-1),(.45,.26,-.82),(0,0,-.72)]:
   sec.append((xx,sign*(y0+(y1-y0)*fraction),z0+(z1-z0)*rise+th*thickness))
  sections.append(sec)
  # The underside curls back to the inboard bumper carrier. It continues
  # below the upper foil in the quarter view; the lower splitter is separate.
  returns.append([(xx,sign*(y1-.002),z1-th*.65),(xx,sign*(y0+.58*(y1-y0)),z0-.004),
                  (xx,sign*(y0-.012),max(.130,z0-.042)),(xx,sign*(y0-.043),.120),
                  (xx,sign*(y0-.119),.119),(xx,sign*(y0-.115),max(z0-.006,.143)),
                  (xx,sign*y0,z0)])
 obj=loft('Molded corner vane underside',returns,carbon,bumper)
 for face in obj.data.polygons[:-2]:face.use_smooth=True
 obj=loft('Rising bumper flic',sections,carbon,bumper)
 for face in obj.data.polygons[:-2]:face.use_smooth=True
# These strips park at the lower windscreen edge, parallel to the cowl. The
# overhead Chevrolet reference has vehicle longitudinal X running horizontally.
for coords in [[(254,148),(248,159),(242,174),(239,192),(237,214),(237,227)],[(241,234),(242,249),(246,263),(251,279),(259,294),(267,305)]]:
 line_on('Parked windscreen wiper',coords,topcam,dark,.0026,windshield,.007)
# Vertical rear diffuser fences sit between the bumper and the flat floor.
for side in (-1,1):
 for yy in (.39,.62,.83):
  y0=side*yy;xx=2.138-.092*yy
  sec=[]
  for dy in [-.005,.005]:
   sec.append([(xx-.32,y0+dy,.175),(xx-.11,y0+dy,.151),(xx+.02,y0+dy,.167),(xx+.045,y0+dy,.267),(xx-.235,y0+dy,.241)])
  loft('Rear diffuser fence',sec,carbon,tail)
