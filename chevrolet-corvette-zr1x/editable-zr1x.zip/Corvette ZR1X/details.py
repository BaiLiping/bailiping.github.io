"""Fitted aero assemblies and lamp bezels. Called in the Blender builder's vehicle coordinates."""
import mathutils
from mathutils.bvhtree import BVHTree
tree=BVHTree.FromPolygons(v.tolist(),f.tolist(),all_triangles=True)
cal=json.loads((ROOT/'rig.json').read_text());D,fp,el,phase,cx,cy,tx,ty,tz=cal
def frame_camera(i):
 a=np.deg2rad((i-1)*12+24+phase);elv=np.deg2rad(el)
 back=np.array([-cos(a)*cos(elv),-sin(a)*cos(elv),sin(elv)]);rt=np.array([sin(a),-cos(a),0]);up=np.cross(back,rt)
 return np.array([tx,ty,tz])+back*D,np.stack([rt,-up,-back]),(cx*.6,cy*.6,fp*.6)
def upper_camera():
 xc,yc,dist,ax,ay,roll,fc=json.loads((ROOT/'plan_camera.json').read_text())
 rot=np.array(mathutils.Euler(tuple(np.deg2rad([ax,ay,roll])),'XYZ').to_matrix())
 rr=np.diag([1,-1,-1])@rot.T;return np.array([0,0,.62])+rr.T@np.array([0,0,-dist]),rr,(xc,yc,fc)
def ray(co,cam,push=.004):
 c,r,(cx,cy,fp)=cam;vec=r.T@np.array([(co[0]-cx)/fp,(co[1]-cy)/fp,1.])
 d=Vector(vec.tolist()).normalized();hit,n,idx,depth=tree.ray_cast(Vector(c.tolist()),d)
 if hit is None:raise ValueError('unprojected reference landmark '+str(co))
 return tuple(hit-d*push)
def patch(name,polygon,cam,m,par,push=.005):
 # Subdivide the triangular fans in source-camera coordinates to follow the curved skin exactly.
 xy=np.array(polygon,dtype=float);center=xy.mean(axis=0);vv=[];ff=[]
 for aa,bb in zip(xy,np.roll(xy,-1,axis=0)):
  sec=[list(center+u*(aa-center)+t*(bb-center)) for u,t in [(0,0),(1,0),(0,1)]]
  tri=[np.array(sec)]
  steps=5 if name in ('Main front cooling aperture','Rear diffuser') else 4 if name in ('Front cooling intake','Rear outboard cooling vent') else 3
  for _ in range(steps):
   sub=[]
   for a,b,c in tri:
    ab=(a+b)/2;bc=(b+c)/2;ca=(c+a)/2;sub.extend([[a,ab,ca],[ab,b,bc],[ca,bc,c],[ab,bc,ca]])
   tri=sub
  for triple in tri:
   try:co=[ray(pt,cam,push) for pt in triple]
   except ValueError:continue
   idx=len(vv);vv.extend(co);ff.append((idx,idx+1,idx+2))
 o=mesh(name,vv,ff,m,par)
 if name in ('Main front cooling aperture','Front cooling intake','Rear outboard cooling vent','Rear diffuser','Quad exhaust recess','Tail light pocket','Red tail optic'):
  average=Vector(((-1 if cam[0][0]<0 else 1),0,.06)).normalized()
  for fa in o.data.polygons:fa.use_smooth=True
  o.data.normals_split_custom_set_from_vertices([tuple(average)]*len(vv))
 return o
def line_on(name,coords,cam,material,r,par,push=.008):
 pts=[]
 for p1,p2 in zip(coords,coords[1:]):
  for k in range(9):
   try:pts.append(ray(np.array(p1)*(1-k/9)+np.array(p2)*k/9,cam,push))
   except ValueError:pass
 try:pts.append(ray(coords[-1],cam,push))
 except ValueError:pass
 if len(pts)>1:path(name,pts,r,material,par)
topcam=upper_camera();fcam=frame_camera(29);backcam=frame_camera(14)
lensdark=mat('Lamp graphite surround','34383b',.32,.23);lensmid=mat('Dark recessed composite','15191c',.015,.81);ice=mat('Daytime-light diffuser','e0e3da',.15,.24);ruby=mat('Tail-lamp red','f34842',.07,.24);rb=ruby.node_tree.nodes.get('Principled BSDF');rb.inputs['Emission Color'].default_value=(.8,.022,.018,1);rb.inputs['Emission Strength'].default_value=.52;amber=mat('Amber marker','d67d36',.06,.29)
# The flag-shaped lenses are measured in the near-head-on configurator frame.
for sign in [-1,1]:
 def fr(p):return [(x if sign<0 else 879-x,y) for x,y in p]
 patch('Headlamp housing',fr([(269,205),(273,200),(284,201),(298,209),(318,221),(339,236),(350,248),(336,245),(303,238),(280,232),(272,226)]),fcam,lensdark,body,.006)
 patch('Headlamp reflector well',fr([(276,207),(284,207),(307,222),(331,237),(340,242),(319,237),(291,232),(277,225)]),fcam,lensmid,body,.008)
 line_on('Upper daytime-running blade',fr([(276,206),(285,208),(310,225),(333,240),(342,244)]),fcam,ice,.0038,body,.012)
 line_on('Lower headlamp reflector',fr([(279,211),(280,225),(291,231),(307,233)]),fcam,metal,.0027,body,.011)
 line_on('Side headlamp marker',fr([(271,207),(273,217),(274,224)]),fcam,amber,.003,body,.012)
 # Four red tail-light signatures around black swept cavities.
 def rr(p):return [(x if sign<0 else 890-x,y) for x,y in p]
 for coords in [[(271,183),(270,190),(278,201),(311,203),(320,192)],[(318,185),(314,193),(321,201),(352,203),(360,195)]]:
  line_on('Rear red light signature',rr(coords),backcam,ruby,.0065,body,.014)
# Source 07, high coupe view: three openings and two body-color fins shape the heat extractor.
for j,poly in enumerate([[(162,190),(165,179),(181,158),(213,144),(224,140),(215,164),(205,182)],[(166,196),(205,185),(204,215),(207,249),(212,266),(176,259),(167,237)],[(176,270),(210,272),(222,300),(202,294),(184,284)]]):
 patch('Hood extraction opening',poly,topcam,lensmid,body,.007)
for coords in [[(169,192),(203,183),(218,181)],[(173,262),(198,266),(216,271)]]:
 line_on('Extractor rib',coords,topcam,dark,.005,body,.013)
# The glass panes taper to either side of the engine spine. The six louver recesses share their contour.
for coords in [[(514,147),(531,140),(611,146),(627,154),(648,179),(663,199),(533,192)],[(534,235),(663,214),(653,234),(630,261),(606,272),(529,282),(517,277)]]:
 patch('Split engine-cover glass',coords,topcam,blackglass,body,.008)
for coords in [[(523,150),(531,142),(548,143),(557,153)],[(557,153),(551,145),(572,146),(582,157)],[(581,158),(577,148),(596,149),(609,161)],[(520,276),(531,271),(550,266),(545,277)],[(551,273),(559,261),(582,256),(575,269)],[(582,265),(590,253),(609,247),(603,259)]]:
 patch('Engine-hatch cooling slot',coords,topcam,dark,body,.014)
for coords in [[(531,104),(546,99),(590,97),(601,100),(590,114),(582,118),(556,117)],[(516,326),(537,315),(591,311),(609,318),(588,325),(544,330)]]:
 patch('Fender brake-cooling inlet',coords,topcam,lensmid,body,.008)
# The wing has a swept, constant-section carbon blade, a pair of central strakes and two raised endplates.
stations=[]
for yy in np.linspace(-.962,.962,41):
 frac=(abs(yy)/.962)**1.8;lead=1.981-.24*frac;chord=.386-.013*frac;zz=1.12+.012*frac
 stations.append([(lead+chord*u,yy,zz+dz) for u,dz in [(0,-.035),(.09,-.021),(.35,-.008),(.70,.007),(1,.039),(.998,.025),(.70,-.010),(.32,-.029),(.07,-.041)]])
o=loft('Carbon rear wing blade',stations,carbon,wing)
for fa in o.data.polygons:fa.use_smooth=True
for side in [-1,1]:
 yy=side*.955;xx=1.747
 sec=[]
 for dy in [-.006,.006]:
  sec.append([(xx+ux,yy+dy,zz) for ux,zz in [(0,1.122),(.046,1.166),(.312,1.219),(.400,1.227),(.368,1.103),(.047,1.091)]])
 loft('Aero wing endplate',sec,carbon,wing)
 yy=side*.412;sec=[]
 for dy in [-.015,.015]:
  sec.append([(xx,yy+dy,zz) for xx,zz in [(1.823,.943),(1.92,.953),(2.079,1.13),(2.009,1.136),(1.903,1.038)]])
 loft('Wing stanchion',sec,carbon,wing)
 sec=[]
 for dy in [-.004,.004]:
  sec.append([(xx,yy+dy,zz) for xx,zz in [(1.934,1.126),(2.043,1.156),(2.181,1.177),(2.247,1.163),(2.17,1.134)]])
 loft('Wing aero strake',sec,carbon,wing)
# Painted mirror shells attach to the window end of each door.
for s in [-1,1]:
 pivot=np.array(doors[s].location)
 # Interior sail and outboard gasket bridge the card, window sill and A-pillar at the mirror attachment.
 sections=[]
 for yy in [.653,.693,.747,.792]:
  shape=[(-.869,.726),(-.868,.785),(-.793,.862),(-.756,.890),(-.693,.819),(-.593,.770),(-.585,.744)]
  shear=(yy-.653)*.16
  sections.append([tuple(np.array([xx+shear,s*yy,zz-.10*(yy-.653)])-pivot) for xx,zz in shape])
 sail=loft('Triangular door mirror sail',sections,dark,doors[s])
 for face in sail.data.polygons:face.use_smooth=False
 padsection=[]
 for yy,ww,hh in [(.763,.056,.038),(.798,.058,.04),(.824,.042,.028)]:
  padsection.append([tuple(np.array([-.708+ww*cos(t),s*yy,.803+hh*sin(t)])-pivot) for t in np.linspace(0,2*pi,22,endpoint=False)])
 loft('Mirror mounting gasket',padsection,bk,doors[s])
 path('Mirror mounting arm',[tuple(np.array(co)-pivot) for co in [(-.710,s*.790,.805),(-.691,s*.833,.811),(-.667,s*.879,.824),(-.643,s*.940,.884)]],.016,dark,doors[s])
 sec=[]
 for xx,w,h,zc in [(-.745,.038,.022,.901),(-.71,.088,.049,.904),(-.65,.099,.056,.907),(-.588,.082,.048,.902),(-.574,.061,.035,.901)]:
  sec.append([tuple(np.array([xx,s*(.987+w*cos(t)),zc+h*sin(t)])-pivot) for t in np.linspace(0,2*pi,30,endpoint=False)])
 o=loft('Torch Red mirror cap',sec,red,doors[s])
 for fa in o.data.polygons:fa.use_smooth=True
 sec=[]
 for xx,w,h in [(-.575,.062,.036),(-.569,.064,.036)]:
  sec.append([tuple(np.array([xx,s*(.986+w*cos(t)),.901+h*sin(t)])-pivot) for t in np.linspace(0,2*pi,28,endpoint=False)])
 loft('Mirror glass',sec,blackglass,doors[s])
# Exterior panels captured in both frontal and broadside projections meet a smooth painted shell.
jetglass=mat('Smoked side and front glazing','263039',.17,.18);jetglass.use_backface_culling=True;jetglass.surface_render_method='DITHERED';jetglass.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.65
roofmat=mat('Carbon roof panel','303238',.20,.24);roofmat.use_backface_culling=True
def facing_patch(name,poly,cam,m,parent,push=.008,side_copy=False):
 o=patch(name,poly,cam,m,parent,push)
 cam_pos=np.array(cam[0]);me=o.data
 for face in me.polygons:
  if np.dot(face.normal,cam_pos-np.array(face.center))<0:face.flip()
 for vert in me.vertices:vert.co-=parent.location
 if side_copy:
  par=doors[1] if parent==doors[-1] else parent
  meshcopy=me.copy();copy=bpy.data.objects.new(name+' right',meshcopy);sc.collection.objects.link(copy);copy.parent=par
  for vert in meshcopy.vertices:vert.co.y*=-1
  for poly in meshcopy.polygons:poly.flip()
 return o
wind=[(234,222),(236,192),(244,157),(253,138),(271,116),(288,117),(350,126),(378,133),(370,157),(363,186),(360,213),(361,245),(365,274),(373,305),(348,313),(312,324),(293,331),(278,331),(263,322),(250,298),(241,272)]
facing_patch('Laminated windshield',wind,topcam,jetglass,body,.009)
# Flat encapsulated outer frit follows the outside face of the bonded glass.
# The inside edge is finished by the independently modeled pillar and dash.
frit=mat('Outer windshield ceramic band','202126',.04,.55);frit.use_backface_culling=True
rim=np.array(wind,dtype=float);center=rim.mean(axis=0);fv=[];ff=[]
for p0,p1 in zip(rim,np.roll(rim,-1,axis=0)):
 for t in np.linspace(0,1,6,endpoint=False):
  q=(1-t)*p0+t*p1;r=q-center;r/=np.linalg.norm(r);fv.extend([ray(q+r*.75,topcam,.013),ray(q-r*.75,topcam,.013)])
n=len(fv)//2
for j in range(n):ff.append((2*j,2*((j+1)%n),2*((j+1)%n)+1,2*j+1))
fr=mesh('Windshield perimeter rubber',fv,ff,frit,body)
for fa in fr.data.polygons:
 if np.dot(fa.normal,topcam[0]-np.array(fa.center))<0:fa.flip()

facing_patch('Carbon roof outer skin',[(378,132),(417,136),(468,140),(482,144),(491,164),(498,185),(500,221),(496,255),(490,278),(480,286),(424,296),(374,305),(365,272),(361,244),(360,211),(364,175)],topcam,roofmat,roof,.011)
for cam,par in [(frame_camera(6),doors[-1])]:
 pane=[(340,184),(350,169),(366,154),(387,144),(410,134),(437,129),(462,127),(493,128),(527,131),(554,135),(574,138),(583,143),(569,153),(550,164),(525,171),(494,176),(446,181),(399,185),(364,187)]
 facing_patch('Tinted side glazing',pane,cam,jetglass,par,.010,True)
# Recreate the top and trailing arms of the wishbone intake bezel from the broadside image.
sidecam=frame_camera(6)
wish=[(480,193),(498,191),(525,194),(552,197),(577,200),(605,198),(647,194),(666,193),(657,203),(640,209),(599,216),(590,219),(574,238),(552,263),(542,271),(563,242),(573,218),(568,212),(553,208),(523,203),(497,198)]
facing_patch('Wishbone side-inlet bezel',wish,sidecam,carbon,body,.012,True)
rocker=[(294,310),(326,308),(476,304),(544,301),(625,301),(659,300),(657,307),(493,312),(340,316),(296,315)]
facing_patch('Carbon rocker blade',rocker,sidecam,carbon,body,.010,True)
quarter=[(625,169),(645,158),(667,153),(684,153),(697,155),(675,159),(648,163)]
facing_patch('Quarter panel cooling inlet',quarter,sidecam,carbon,body,.009,True)
# Backlight spine and rear lamps each have their own bounded geometry.
rearCam=frame_camera(14);frontCam=frame_camera(29)
for sign in [-1,1]:
 def rr(p):return [(x if sign<0 else 889-x,y) for x,y in p]
 for poly in [[(270,180),(313,184),(309,192),(315,204),(276,204),(263,196)],[(315,184),(362,187),(357,195),(363,207),(320,205),(312,197)]]:
  patch('Tail light pocket',rr(poly),rearCam,lensmid,body,.014)
 for poly in [[(263,193),(271,183),(269,194),(277,201),(308,201),(314,204),(274,204)],[(313,193),(319,186),(318,194),(325,201),(356,201),(361,205),(322,205)]]:
  patch('Red tail optic',rr(poly),rearCam,ruby,body,.020)
 for poly in [[(280,184),(308,186),(304,191),(279,190)],[(325,187),(355,189),(351,193),(325,191)]]:
  patch('Tail clear inner optic',rr(poly),rearCam,metal,body,.020)
 patch('Rear outboard cooling vent',rr([(265,224),(340,227),(351,242),(348,248),(265,248),(262,244)]),rearCam,lensmid,body,.012)
 for yy in (230,236,242):line_on('Rear vent louvers',rr([(266,yy),(301,yy+1),(342,yy+3)]),rearCam,carbon,.0045,body,.018)
 # Undertray and side inlets on the front fascia.
 def fr(p):return [(x if sign<0 else 880-x,y) for x,y in p]
 poly=[(271,255),(309,266),(338,273),(342,279),(335,292),(332,316),(327,319),(275,314)]
 patch('Front cooling intake',fr(poly),frontCam,lensmid,body,.012)
 for yy in [274,283,293,303,311]:
  line_on('Front horizontal intake slat',fr([(275,yy-2),(300,yy+1),(329,yy+3)]),frontCam,carbon,.0039,body,.022)
 for xx in [282,301,319]:line_on('Front vertical mesh bar',fr([(xx,275),(xx+6,313)]),frontCam,carbon,.0023,body,.017)
 # Side flic in the front bumper corner.

patch('Main front cooling aperture',[(311,268),(355,276),(402,282),(445,282),(488,280),(535,273),(567,265),(553,286),(539,293),(519,318),(509,322),(359,322),(352,318),(339,293),(330,288)],frontCam,lensmid,body,.015)
for yy in [289,299,309,318]:
 line_on('Front grille rail',[(351,yy-4),(393,yy+1),(445,yy+2),(490,yy),(528,yy-4)],frontCam,carbon,.0045,body,.021)
for xx in range(369,513,23):
 line_on('Grille lattice',[(xx,301),(xx+5,313),(xx+14,316),(xx+21,305)],frontCam,carbon,.0043,body,.027)
# Filler cap is present only on the driver side.
painted_cap=[(610+10.3*cos(t),184+10.6*sin(t)) for t in np.linspace(0,2*pi,45)]
line_on('Flush fuel filler door',painted_cap,sidecam,dark,.0022,body,.008)
# The steep return surfaces of the cooling ports sit behind each door hem.
for sign in [-1,1]:
 vv=[];ff=[]
 for jj,(zz,xx,yi,yo) in enumerate([(.325,.292,.847,.919),(.4,.353,.802,.944),(.54,.451,.746,.967),(.65,.526,.753,.973),(.71,.58,.792,.954)]):
  for l in range(5):
   u=l/4;vv.append((xx+.007-.008*sin(u*pi),sign*(yi+(yo-yi)*u),zz))
  if jj:ff.extend([((jj-1)*5+k,jj*5+k,jj*5+k+1,(jj-1)*5+k+1) for k in range(4)])
 o=mesh('Recessed inlet return',vv,ff,lensmid,body)
 for face in o.data.polygons:face.use_smooth=True
# Rear diffuser surround, trapezoidal center muffler recess and the four individual tailpipe lips.
patch('Rear diffuser',[(251,259),(365,253),(386,248),(500,248),(523,253),(636,257),(633,308),(623,318),(568,313),(549,325),(343,325),(324,314),(269,314),(256,308)],rearCam,carbon,body,.012)
patch('Quad exhaust recess',[(388,282),(495,282),(508,306),(496,315),(393,315),(380,305)],rearCam,lensmid,body,.018)
for xx in [406,431,455,480]:
 center=np.array(ray((xx,299),rearCam,.023));sections=[]
 for off,rad in [(-.013,.052),(.011,.055),(.017,.049),(.015,.044),(-.015,.044)]:
  sections.append([tuple(center+[off,rad*cos(t),rad*sin(t)]) for t in np.linspace(0,2*pi,40,endpoint=False)])
 mesh('Round exhaust tip',[p for sec in sections for p in sec],[(j*40+i,j*40+(i+1)%40,(j+1)*40+(i+1)%40,(j+1)*40+i) for j in range(4) for i in range(40)],lip,body)
plate=mat('Neutral rear plate','727678',.12,.54)
patch('Rear plate recess',[(410,207),(475,207),(475,235),(411,235)],rearCam,plate,body,.014)
line_on('Rear center brake light',[(388,181),(501,181)],rearCam,ruby,.008,body,.014)
for sign in [-1,1]:
 def rr(p):return [(x if sign<0 else 888-x,y) for x,y in p]
 line_on('Rear diffuser outer rib',rr([(266,260),(360,258),(382,254)]),rearCam,dark,.007,body,.025)
 line_on('Rear diffuser strake',rr([(323,312),(337,282),(382,281)]),rearCam,dark,.009,body,.025)
# Two small crossed-flag marks carry independently colored fields at the front and rear.
for cam,center in [(frontCam,(439,251)),(topcam,(679,207))]:
 ux,uy=center
 for off,m in [(-1,metal),(1,red)]:
  patch('Crossed flag field',[(ux,uy+4),(ux+off*10,uy-3),(ux+off*12,uy-5),(ux+off*4,uy-3)],cam,m,body,.017)
def painted_seam(name,points,cam,rad=.0035,reflect=False,group=body):
 vv=[]
 for p0,p1 in zip(points,points[1:]):
  for j in range(5):
   q=np.asarray(p0)*(1-j/5)+np.asarray(p1)*(j/5)
   try:vv.append(np.array(ray(q,cam,.003)))
   except ValueError:pass
 try:vv.append(np.array(ray(points[-1],cam,.006)))
 except ValueError:pass
 path(name,[tuple(co-np.asarray(group.location)) for co in vv],rad,dark,group)
 if reflect:
  group2=doors[1] if group==doors[-1] else group
  path(name,[tuple(co*np.array([1,-1,1])-np.asarray(group2.location)) for co in vv],rad,dark,group2)
painted_seam('Front closure perimeter',[(161,203),(161,241),(170,269),(187,291),(210,306),(237,319),(258,324)],topcam,.0028)
painted_seam('Front closure perimeter',[(161,203),(171,177),(192,153),(218,135),(250,121),(271,117)],topcam,.0028)
painted_seam('Door front and lower shut line',[(333,190),(322,200),(315,216),(311,233),(313,255),(317,282),(322,306),(351,306),(410,302),(482,294),(514,287),(540,275),(551,258),(562,237)],sidecam,.0034,True,doors[-1])
painted_seam('Door shoulder shut line',[(561,237),(565,220),(564,202),(557,184),(550,165)],sidecam,.0031,True,doors[-1])
for sign in [-1,1]:
 def fr(pp):return [(x if sign<0 else 880-x,y) for x,y in pp]
 patch('Projector silver inset',fr([(291,219),(302,222),(306,228),(302,232),(294,230),(291,226)]),fcam,metal,body,.016)
 patch('Projector optic',fr([(296,221),(301,222),(303,225),(301,228),(296,228),(294,225)]),fcam,ice,body,.019)
 line_on('Headlamp lens rim',fr([(272,205),(281,204),(300,214),(328,234)]),fcam,lip,.0027,body,.016)
# Distributed custom normals produce a continuous optical reflection across the curved glazing.
for obj in [o for o in bpy.data.objects if o.type=='MESH' and o.name.startswith(('Laminated windshield','Tinted side glazing','Carbon roof outer skin','Split engine-cover glass'))]:
 nw=[]
 for vt in obj.data.vertices:
  xx,yy,zz=vt.co+obj.parent.location
  if obj.name.startswith('Laminated'):normal=Vector((-.46,.43*yy,1))
  elif obj.name.startswith('Tinted'):normal=Vector((-.075*(.1-xx),np.sign(yy),.34+.1*(zz-.9)))
  elif obj.name.startswith('Split'):normal=Vector((.20,.16*yy,1))
  else:normal=Vector((.018*xx,.23*yy,1))
  nw.append(tuple(normal.normalized()))
 for face in obj.data.polygons:face.use_smooth=True
 obj.data.normals_split_custom_set_from_vertices(nw)

# Low front splitter and raised flics follow the nose around to the front wheel clearances.
section=[]
for yy in np.linspace(-.99,.99,61):
 amp=abs(yy);xx=np.interp(amp,[0,.36,.65,.82,.97,.99],[-2.462,-2.44,-2.346,-2.236,-2.039,-1.994]);zz=.113+.018*amp
 section.append([(xx,yy,zz+.012),(xx+.128,yy,zz+.017),(xx+.170,yy,zz+.003),(xx+.025,yy,zz-.006)])
o=loft('Front carbon splitter',section,carbon,body)
for ff in o.data.polygons:ff.use_smooth=True
for ss in [-1,1]:
 face=[(-2.072,ss*.927,.137),(-1.93,ss*.97,.155),(-1.822,ss*.982,.208),(-1.866,ss*.974,.244),(-1.98,ss*.952,.180)]
 secs=[[tuple(np.array(p)+[0,ss*off,0]) for p in face] for off in [-.004,.004]];loft('Rising bumper flic',secs,carbon,body)
# Fine molded finishing trim and neutral plate lettering on the closed rear.
pocket=[(370,203),(378,201),(511,201),(517,205),(502,238),(497,244),(390,244),(384,241)]
line_on('License pocket edge',pocket+[pocket[0]],rearCam,dark,.0044,body,.012)
pk=ray((443,220),rearCam,.024)
cu=bpy.data.curves.new('Rear plate lettering','FONT');cu.body='CHEVROLET';cu.size=.031;cu.align_x='CENTER';cu.align_y='CENTER';cu.materials.append(dark)
ob=bpy.data.objects.new('Chevrolet plate lettering',cu);sc.collection.objects.link(ob);ob.parent=body;ob.location=pk;ob.rotation_euler=(pi/2,0,pi/2)
# These strips park at the lower windscreen edge, parallel to the cowl. The
# overhead Chevrolet reference has vehicle longitudinal X running horizontally.
for coords in [[(254,148),(248,159),(242,174),(239,192),(237,214),(237,227)],[(241,234),(242,249),(246,263),(251,279),(259,294),(267,305)]]:
 line_on('Parked windscreen wiper',coords,topcam,dark,.0026,body,.007)
# Vertical rear diffuser fences sit between the bumper and the flat floor.
for side in (-1,1):
 for yy in (.39,.62,.83):
  y0=side*yy;xx=2.138-.092*yy
  sec=[]
  for dy in [-.005,.005]:
   sec.append([(xx-.32,y0+dy,.175),(xx-.11,y0+dy,.151),(xx+.02,y0+dy,.167),(xx+.045,y0+dy,.267),(xx-.235,y0+dy,.241)])
  loft('Rear diffuser fence',sec,carbon,body)
