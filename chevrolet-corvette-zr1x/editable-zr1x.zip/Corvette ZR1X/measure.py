import bpy,numpy as np,json
from mathutils import Vector
from pathlib import Path
root=Path(__file__).resolve().parent
group={}
for o in bpy.context.scene.objects:
 if o.type not in ['MESH','CURVE','FONT']:continue
 parent=o
 while parent.parent:parent=parent.parent
 graph=bpy.context.evaluated_depsgraph_get();ob=o.evaluated_get(graph);me=ob.to_mesh()
 if len(me.vertices)==0: ob.to_mesh_clear();continue
 vv=np.empty(len(me.vertices)*3,np.float32);me.vertices.foreach_get('co',vv);m=np.array(o.matrix_world);p=vv.reshape(-1,3)@m[:3,:3].T+m[:3,3]
 for key in ['whole',parent.name]+(['body datum'] if parent.name in ['Body','Door_L','Door_R','Roof_panel'] and 'mirror' not in o.name.lower() else []):
  group.setdefault(key,[]).extend([p.min(0),p.max(0)])
 ob.to_mesh_clear()
res={k:{'min':np.min(v,axis=0).round(5).tolist(),'max':np.max(v,axis=0).round(5).tolist(),'span':np.ptp(v,axis=0).round(5).tolist()} for k,v in group.items()}
(root/'dimensions.json').write_text(json.dumps(res,indent=2))
