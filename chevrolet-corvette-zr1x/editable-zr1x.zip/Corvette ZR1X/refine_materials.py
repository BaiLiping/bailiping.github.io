from hull import *
from scipy.spatial.transform import Rotation
a=np.load(ROOT/'skin.npz');v,f,c=a['v'],a['f'],a['color'].astype(float);n=np.load(ROOT/'smoothed_normals.npy')
x,y,z=v.T;ay=np.abs(y)
p=json.loads((ROOT/'rig.json').read_text());K,R,C,t=pose(p)
cx,cy,D,ax,aycam,roll,fp=json.loads((ROOT/'plan_camera.json').read_text());rot=Rotation.from_euler('xyz',[ax,aycam,roll],degrees=True).as_matrix()
r=np.diag([1,-1,-1])@rot.T;cc=np.array([0,0,.62])+r.T@[0,0,-D];kk=np.array([[fp,0,cx],[0,fp,cy],[0,0,1.]])
uv=project(v,kk,r,cc)[0];mirror=v.copy();mirror[:,1]=-abs(mirror[:,1]);side=project(mirror,K,R[5],C[5])[0]*.6
def inside(points,xy):
 img=np.zeros((450,900),'uint8');cv.fillPoly(img,[np.array(points,'int32')],255);return at(img,xy)>100
glazing=inside([(234,221),(237,187),(245,152),(254,134),(274,117),(300,119),(351,127),(376,134),(363,165),(357,205),(358,240),(363,278),(373,305),(338,316),(299,332),(276,330),(263,322),(251,301),(242,268)],uv)
roof=inside([(380,134),(415,138),(468,139),(482,141),(497,179),(500,222),(497,260),(491,280),(470,286),(416,295),(378,303),(368,264),(365,221),(369,177)],uv)
sidepane=inside([(338,184),(351,163),(379,149),(406,137),(435,129),(471,126),(503,128),(544,134),(570,139),(581,145),(563,155),(542,165),(505,171),(453,178),(402,183),(367,185)],side)
top=(n[:,2]>.18)&(z>.71)&(x> -2.05)&(x<1.88)
# Generate clean paint and glazing masks from the calibrated overhead press view and the broadside frame.
# Seam, grille and lens evidence is retained in the remaining regions of the fitted skin.
red=np.array([199.,23.,29.]);original=a['paint'];paint=original.copy()
c[original]=.19*c[original]+.81*red
hood=top&(x<-.63)&(ay<.60);c[hood]=red;paint[hood]=True
greenhouse=(x>-1.23)&(x<.85)&(z>.797)
c[greenhouse]=red;paint[greenhouse]=True
glass=(glazing&greenhouse&(n[:,2]>.22))|(greenhouse&sidepane&(ay>.5)&(n[:,2]<.92))
# Soft tint gradient approximates the factory glass while leaving the panel to respond to the scene lighting.
c[glass]=np.column_stack([23+13*np.clip((z-.81)/.40,0,1),28+15*np.clip((z-.81)/.40,0,1),31+17*np.clip((z-.81)/.40,0,1)])[glass];paint[glass]=False
roofzone=roof&greenhouse&(n[:,2]>.52);c[roofzone]=[39,41,46];paint[roofzone]=False
# Door sheets in the factory photos are solid red between the shoulder and the lower sill.
edge=.29+.31*np.clip((z-.31)/.42,0,1)
doorfield=(x>-.93)&(x<edge-.04)&(z>.205)&(z<.724)&(ay>.65)&(n[:,2]<.86)
c[doorfield]=red;paint[doorfield]=True
sideblade=(x>.03)&(x<1.01)&(z>.737)&(z<.87)&(ay>.79)&(~a['paint'])
sidebaffle=(abs(x-edge)<.041)&(z>.315)&(z<.72)&(ay>.712)&(ay<.99)&(n[:,0]<-.29)
c[sidebaffle]=[20,22,25];paint[sidebaffle]=False
# Preserve the front face from its near-normal view. This avoids neighboring views dragging grille slats over paint.
for i,mask in [(28,(x<-1.85)&(z>.15)&(z<.675)&(n[:,0]<-.58)),(13,(x>1.7)&(z>.22)&(z<.855)&(n[:,0]>.59))]:
 coords,_=project(v,K,R[i],C[i]);orig=load(i)[:,:,[2,1,0]];vals=at(orig,coords).astype(float);isred=(vals[:,0]-np.maximum(vals[:,1],vals[:,2]))>22
 c[mask]=np.where(isred[:,None],.84*red+.16*vals,vals)[mask];paint[mask]=isred[mask]
# On the final build, separate editable panels carry the optical, aero and lighting details.
# Restore continuous base paint below those pieces to prevent photographic ghosts along their edges.
well=np.zeros(len(x),bool)
for ax,rad in zip(wheelX,wheelZ):
 well|=(ay>.604)&(np.hypot(x-ax,z-rad)<rad+.023)
clean=(z>.155)&(~well)
c[clean]=[216,36,33];paint[clean]=True;cutWindows=glass.copy();glass[:]=False
# The broad belt feature follows the owner's chosen aero configuration.
c[sidebaffle]=[32,32,33];paint[sidebaffle]=False
sill=(z<.16)|((z<.184)&(ay>.65))
c[sill]=[31,31,34];paint[sill]=False
front=(x<-1.73)&(z<.27)&(~well)
uvfront=project(v,K,R[28],C[28])[0]*.6
boundary=329-5*np.clip(np.abs(uvfront[:,0]-440)/186,0,1)**1.8
lower=uvfront[:,1]>boundary
c[front]=np.where(lower[:,None],[34,34,37],[216,36,33])[front];paint[front]=~lower[front]
np.savez_compressed(ROOT/'finalskin.npz',v=v,f=f,color=np.uint8(np.clip(c,0,255)),paint=paint,glass=glass,cutWindows=cutWindows)
