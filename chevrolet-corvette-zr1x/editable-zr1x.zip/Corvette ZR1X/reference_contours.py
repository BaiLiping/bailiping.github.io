"""Publish measured contours as an alternative when a browser cannot embed Chevrolet's images."""
from pathlib import Path
from PIL import Image
import cv2 as cv,numpy as np,json,sys
from hull import mask
root=Path(__file__).parent;out=Path(sys.argv[1]);records=json.loads((root/'inventory.json').read_text());views=json.loads((out/'studio.json').read_text())['views']
for i,view in enumerate(views):
 id=view['id'];src=next(q for q in records if q['id']==id);im=cv.imread(str(root/src['file']));H,W=im.shape[:2]
 if i<30:
  fg=mask(i).astype('uint8');d=np.int16(im);red=((d[:,:,2]-np.maximum(d[:,:,1],d[:,:,0])>22)*fg).astype('uint8')
  field=np.full((H,W,3),255,'uint8');field[fg!=0]=[223,225,227];field[red!=0]=[211,216,230]
  soft=cv.bilateralFilter(im,9,38,7);ed=cv.Canny(soft,59,133);ed=cv.bitwise_and(ed,fg*255)
  for a,col in [(ed,(135,140,144)),(cv.morphologyEx(red,cv.MORPH_GRADIENT,np.ones((3,3),'uint8')),(107,105,117)),(cv.morphologyEx(fg,cv.MORPH_GRADIENT,np.ones((3,3),'uint8')),(63,74,94))]:
   cs,_=cv.findContours(a,cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE)
   for c in cs:
    if cv.arcLength(c,False)>19:cv.polylines(field,[cv.approxPolyDP(c,.9,False)],False,col,1,cv.LINE_AA)
 else:
  shrink=min(1,1500/W);im=cv.resize(im,(round(W*shrink),round(H*shrink)));ed=cv.Canny(cv.bilateralFilter(im,9,37,7),48,121)
  field=np.full(im.shape,255,'uint8');cs,_=cv.findContours(ed,cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE)
  for c in cs:
   if cv.arcLength(c,False)>18:cv.polylines(field,[cv.approxPolyDP(c,1.,False)],False,(112,119,125),1,cv.LINE_AA)
 cv.imwrite(str(out/'captures'/(id+'-reference.webp')),field,[cv.IMWRITE_WEBP_QUALITY,90])
