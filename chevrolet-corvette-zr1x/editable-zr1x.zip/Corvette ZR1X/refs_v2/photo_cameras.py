"""Recover viewer poses from shared landmarks in the Chevrolet studio images.

The 30-view rig.json was independently solved from the same wheel centers and
multi-view feature correspondences. For the seven larger images, triangulate
matching details from two or more source views and fit a camera with robust
pixel residuals. Retain the starting camera for angles without adequate data.
"""
import json
import math
from collections import defaultdict
from pathlib import Path
import sys

import cv2
import numpy as np
from scipy.optimize import least_squares

REFS = Path(__file__).resolve().parent
WORK = REFS.parent
S = 1000 / 18
def ring_pose(params):
    distance, focal, elevation, phase, cx, cy, *target = params
    theta = np.deg2rad(np.arange(30) * 12 + 24 + phase)
    elevation = math.radians(elevation)
    zero = np.zeros_like(theta)
    back = np.column_stack([-np.cos(theta)*math.cos(elevation), -np.sin(theta)*math.cos(elevation), zero+math.sin(elevation)])
    right = np.column_stack([np.sin(theta), -np.cos(theta), zero])
    rotation = np.stack([right, -np.cross(back, right), -back],axis=1)
    eye = target + back * distance
    translation = -np.einsum('nij,nj->ni',rotation,eye)
    return np.array([[focal,0,cx],[0,focal,cy],[0,0,1]]), rotation, eye, translation

cv2.setNumThreads(2)
cv2.setRNGSeed(814)


def project(points, params, w, h):
    theta, phi, radius, fov, cx, cy, cz = params
    st, ct = np.sin(theta), np.cos(theta)
    sp, cp = np.sin(phi), np.cos(phi)
    back = np.array([sp * ct, cp, sp * st])
    right = np.array([-st, 0., ct]) * -1
    up = np.cross(back, right)
    distance = radius * np.tan(np.deg2rad(15)) / np.tan(np.deg2rad(fov / 2))
    q = points - np.array([cx,cy,cz]) - distance * back
    z = np.maximum(1e-3, q @ -back)
    focal = .5 * h / np.tan(np.deg2rad(.5 * fov))
    return np.column_stack([.5 * w + focal * (q @ right) / z, .5 * h - focal * (q @ up) / z])


def save_pose(params):
    th, ph, rad, fov, *center = params
    return dict(theta=round(th,7), phi=round(ph,7), radius=round(rad,5), fov=round(fov,6), center=np.round(center,5).tolist())


def vector(viewer):
    return np.array([viewer[k] for k in ['theta','phi','radius','fov']] + viewer['center'])


def v2(pts):
    return pts[..., [0,2,1]] * np.array([-S, S, S])


def ring_fit(params, ring):
    K, rotation, eyes, translation = ring
    target = v2(np.array(params[6:]))
    fov = math.degrees(2 * math.atan(375 / K[1,1]))
    estimated = {}
    for i in range(30):
        ray = v2(eyes[i]) - target
        distance = np.linalg.norm(ray)
        theta = math.atan2(ray[2], ray[0])
        phi = math.acos(ray[1] / distance)
        radius = distance * math.tan(math.radians(fov/2)) / math.tan(math.pi/12)
        pose = save_pose([theta, phi, radius, fov, *target])
        pose['principalPoint'] = [K[0,2]/1500, K[1,2]/750]
        estimated[f'view-{i:02d}'] = {
            'pose':pose,
            'method':'Wheel-center and multi-view feature calibration on the original 30 Chevrolet images; retained principal point and focal length.'
        }
    return estimated


def features(im, n):
    detector = cv2.SIFT_create(nfeatures=n, contrastThreshold=.028)
    keys, descriptors = detector.detectAndCompute(im, None)
    return np.float32([k.pt for k in keys]), descriptors


def high_fit(ring, initial):
    K, R, C, T = ring
    projections = K @ np.concatenate([R,T[:,:,None]],axis=2)
    flipbook=[]
    for i in range(30):
        raw = cv2.imread(str(REFS/f'studio_360/view-{i:02d}.png'),cv2.IMREAD_UNCHANGED)
        gray=cv2.cvtColor(raw[:,:,:3],cv2.COLOR_BGR2GRAY)
        gray[raw[:,:,3]<220]=255
        flipbook.append(features(gray,3500))
    results = {}
    for fid, selection in [(32,[29,0,1,2,3]),(33,[0,1,2,3,4,5,6]),(34,[7,8,9,10,11,12]),(35,[15,16,17,18,19,20])]:
        if not selection:
            continue
        initial_pose = initial[f'view-{fid}']['viewer']
        p0 = vector(initial_pose)
        img=cv2.imread(str(next((REFS/'studio_hi').glob(f'view-{fid}*.jpg'))),cv2.IMREAD_GRAYSCALE)
        high_xy, high_d=features(img,11000)
        candidates=defaultdict(list)
        for i in selection:
            ref_xy,ref_d=flipbook[i]
            flann=cv2.FlannBasedMatcher(dict(algorithm=1,trees=4),dict(checks=70))
            rows=flann.knnMatch(high_d,ref_d,k=2)
            for m,n in rows:
                if m.distance<.82*n.distance:
                    candidates[m.queryIdx].append((i,ref_xy[m.trainIdx]))
        X=[]; Y=[]
        for idx, obs in candidates.items():
            if len(obs)<2: continue
            rays=[]
            for i,uv in obs:
                p=projections[i]; rays.extend((uv[0]*p[2]-p[0],uv[1]*p[2]-p[1]))
            point=np.linalg.svd(np.array(rays),full_matrices=False)[2][-1]
            point=point[:3]/point[3]
            if any(abs(point[i])>b for i,b in enumerate([2.65,1.18,1.45])) or point[2]<-.02:continue
            repro=np.array([projections[i]@np.r_[point,1] for i,_ in obs])
            if np.max(np.linalg.norm(repro[:,:2]/repro[:,2:] - np.array([uv for _,uv in obs]),axis=1))>2.8:continue
            X.append(v2(point)); Y.append(high_xy[idx])
        X,Y=np.array(X),np.array(Y)
        if len(X)<20:
            print(fid,len(X),'insufficient matched points',flush=True);continue
        initial_eps=np.linalg.norm(project(X,p0,2500,1407)-Y,axis=1)
        viable=np.where(initial_eps<150)[0]; train=viable[::2]; test=viable[1::2]
        def fit(ids):
            def err(p):
                # The look-at point may move along the view axis without changing projection.
                return np.r_[(project(X[ids],p,2500,1407)-Y[ids]).ravel(), (p[4:]-p0[4:])*.04]
            delta=np.array([.35,.22,.45*p0[2],15,25,25,25])
            return least_squares(err,p0,bounds=(p0-delta,p0+delta),loss='soft_l1',f_scale=2.5,x_scale='jac',max_nfev=240).x
        if len(train)<10: continue
        p=fit(train)
        for cutoff in [35,18,10]:
            fair=train[np.linalg.norm(project(X[train],p,2500,1407)-Y[train],axis=1)<cutoff]
            if len(fair)>=9:
                p=fit(fair)
        hold=np.linalg.norm(project(X[test],p,2500,1407)-Y[test],axis=1)
        mask=hold<12
        hold_count=int(mask.sum())
        # Require spatial coverage in both axes and independent held-out agreement.
        bv=Y[test][mask]
        if len(bv): span=np.ptp(bv,axis=0)
        else:span=[0,0]
        print(fid,len(X),len(test),hold_count,span,'before/after (inlier/all)',np.median(initial_eps[test][mask]),np.median(hold[mask]),np.median(initial_eps[test]),np.median(hold),flush=True)
        if hold_count<10 or hold_count<len(test)/2 or span[0]<580 or span[1]<180 or np.median(hold)>10 or np.median(hold)>=np.median(initial_eps[test]):continue
        results[f'view-{fid}']={'pose':save_pose(p),'method':'Triangulated matching features from the 30-view Chevrolet ring; held-out landmarks in this 2500-pixel view.', 'holdout_inliers':hold_count, 'holdout_candidates':len(test), 'landmark_inlier_threshold_px':12,'holdout_median_px':float(np.round(np.median(hold[mask]),2)),'starting_median_on_same_inliers_px':float(np.round(np.median(initial_eps[test][mask]),2)), 'holdout_all_median_px':round(float(np.median(hold)),2),'initial_all_median_px':round(float(np.median(initial_eps[test])),2),'holdout_span_px':[round(float(dim),1) for dim in span]}
    return results

if __name__=='__main__':
    start=json.loads((REFS/'initial-exterior-poses.json').read_text())
    params=json.loads((REFS/'ring-calibration.json').read_text())
    ring=ring_pose(params)
    results=ring_fit(params,ring)
    results.update(high_fit(ring,start))
    (REFS/'photo-camera-fits.json').write_text(json.dumps(results,indent=2)+'\n')
