"""Prepare native reference assets, frame metadata and photo-calibrated viewer poses."""
import argparse
import hashlib
import json
import math
import shutil
from pathlib import Path

from PIL import Image

REFS = Path(__file__).resolve().parent
V2 = REFS.parent / "v2"
S = 1000 / 18
COVERAGE = {
    "mech-hybrid-plan": "2026 ZR1X hybrid layout",
    "mech-lt7-34": "Shared LT7 from the 2025 ZR1",
    "mech-lt7-side": "Shared LT7 from the 2025 ZR1",
    "mech-lt7-front": "Shared LT7 from the 2025 ZR1",
    "mech-lt7-rear": "Shared LT7 from the 2025 ZR1",
    "mech-bay-top": "2027 Arctic White ZR1X 3LZ",
    "mech-dct-cutaway": "C8 TR-9080 architecture",
    "mech-dct-rear34": "C8 E-Ray rear transaxle",
    "mech-edu-front-render": "C8 E-Ray front electric drive",
    "mech-batt-cutaway-hi": "C8 E-Ray tunnel battery",
    "mech-brake-alcon": "2026 ZR1X brake",
    "cabin-front": "2027 ZR1X 3LZ, Jet Black",
    "cabin-3screen-dash": "ZR1X instrument panel, blue trim"
}


def dump(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def intrinsic(pose, w, h):
    th, ph = pose["theta"], pose["phi"]
    center = pose["center"]
    tangent = math.tan(math.radians(pose["fov"] / 2))
    distance = pose["radius"] * math.tan(math.pi / 12) / tangent
    direction = [math.sin(ph) * math.cos(th), math.cos(ph), math.sin(ph) * math.sin(th)]
    eye = [x + distance * d for x, d in zip(center, direction)]
    return {"position_v2_mm18": [round(v, 4) for v in eye], "target_v2_mm18": center,
            "position_m": [round(v / S, 5) for v in eye], "target_m": [round(v / S, 5) for v in center],
            "fy": round(h / (2 * tangent), 3), "cx": w * pose.get("principalPoint",[.5,.5])[0], "cy": h * pose.get("principalPoint",[.5,.5])[1], "width": w, "height": h}


def main(route):
    inventory = json.loads((V2 / "inventory.json").read_text())
    inventory_by_id = {r["id"]: r for r in inventory["frames"]}
    views = json.loads((REFS / "chevrolet-views.json").read_text())
    cameras = json.loads((V2 / "cameras.json").read_text())
    photo_fits = json.loads((REFS / "photo-camera-fits.json").read_text())
    extra = REFS / "additional-photo-fits.json"
    if extra.exists():
        photo_fits.update(json.loads(extra.read_text()))
    dump_dir = REFS / "chevrolet-views"
    dump_dir.mkdir(exist_ok=True)
    if route:
        (route / "chevrolet-views").mkdir(parents=True, exist_ok=True)
    for frame in views:
        fid = frame["id"]
        record = inventory_by_id[fid]
        original = (V2 / record["original"]).resolve()
        assert hashlib.sha256(original.read_bytes()).hexdigest() == record["sha256"]
        image = Image.open(original)
        assert image.size == (record["width"],record["height"])
        # Keep original image bytes except the alpha-backed orbit. Composite its
        # factory ground shadow onto white, then preserve those exact pixels.
        is_orbit = fid.startswith("view-") and int(fid[5:]) < 30
        if is_orbit:
            file = dump_dir / (fid + ".webp")
            rgba = image.convert("RGBA")
            composite = Image.new("RGB", rgba.size, "white")
            composite.paste(rgba, mask=rgba.getchannel("A"))
            if not file.exists() or Image.open(file).convert('RGB').tobytes() != composite.tobytes():
                composite.save(file, "WEBP", lossless=True, method=4)
        else:
            file = dump_dir / (fid + original.suffix.lower())
            if not file.exists() or hashlib.sha256(file.read_bytes()).hexdigest() != record["sha256"]:
                shutil.copy2(original, file)
        # Retain distinct publisher attribution and the configuration of component shots.
        credit = record["credit"]
        if fid in COVERAGE:
            credit += " · " + COVERAGE[fid]
        camera = cameras["frames"][fid]
        if fid in photo_fits:
            fit = photo_fits[fid].copy()
            frame["pose"] = fit.pop("pose")
            camera["viewer"] = frame["pose"]
            camera["photo_calibration"] = fit
            camera["solved"] = intrinsic(frame["pose"], *image.size)
            camera["checks"] = [fit["method"]]
            if "limitation" in fit:
                camera["checks"].append(fit["limitation"])
                frame["comparisonNote"] = fit["limitation"]
                credit += {"Powertrain": " · Approximate component alignment", "Interior": " · Approximate cabin alignment", "Exterior": " · Approximate steering alignment"}[frame["group"]]
            if "proxy_metrics" in camera:
                camera["initial_proxy_metrics"] = camera.pop("proxy_metrics")
        if fid.startswith('view-') and int(fid[5:])>=30:
            record['note'] = 'Matching GKZ, HTE, SOG, C2Z, CFV, FEJ and TOM option codes supplied to the GM CGI endpoint, image preset gmds11.'
        camera['solved'].update(width=image.width,height=image.height)
        camera['solved'].pop('webp_width',None); camera['solved'].pop('webp_height',None)
        content_hash=hashlib.sha256(file.read_bytes()).hexdigest()[:12]
        frame.update(image=f"./chevrolet-views/{file.name}?v={content_hash}",credit=credit,source=record["source"],originalUrl=record["original_url"],width=image.width,height=image.height)
        if fid == "mech-bay-top":
            frame["image"] = record["original_url"]
            if route:
                prior_copy = route / "chevrolet-views" / file.name
                if prior_copy.exists() and hashlib.sha256(prior_copy.read_bytes()).hexdigest() == record["sha256"]:
                    prior_copy.unlink()
        elif route:
            shutil.copy2(file, route / "chevrolet-views" / file.name)
    cameras["coord_system"]["principal_point"] = "When pose.principalPoint is present it is the normalized original image principal point [cx/width, cy/height]; otherwise the optical axis crosses the image center."
    cameras["calibration_proxy"]["note"] = "The 2025 reference mesh initialized the exterior poses. Frames with photo_calibration use refinements from the Chevrolet images. Initial proxy metrics describe the old initialization only."
    dump(V2 / "cameras.json", cameras)
    dump(V2 / "inventory.json", inventory)
    dump(REFS / "inventory.json", inventory)
    dump(REFS / "chevrolet-views.json", views)
    if route:
        dump(route / "chevrolet-views.json", views)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("route", type=Path, nargs="?")
    main(parser.parse_args().route)
