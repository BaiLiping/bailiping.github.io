from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from scipy.ndimage import gaussian_filter
p=Path(__file__).resolve().parent
a=np.load(p/'skin.npz');v,f=a['v'],a['f'];vf=v[f];n=np.cross(vf[:,1]-vf[:,0],vf[:,2]-vf[:,0]);fn=n/(np.linalg.norm(n,axis=1)[:,None]+1e-18)
N=np.zeros_like(v)
for k in range(3):np.add.at(N,f[:,k],n)
N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-20)
tree=cKDTree(v);out=np.empty_like(N)
for j in range(0,len(v),1600):
 q=v[j:j+1600];dist,idx=tree.query(q,k=128,workers=3);base=N[j:j+1600];neighbors=N[idx];w=np.exp(-.5*(dist/.048)**2)*np.clip((np.einsum('ijk,ik->ij',neighbors,base)+.42)/1.42,.0,1)**.8
 result=np.einsum('ij,ijk->ik',w,neighbors);out[j:j+1600]=result/np.maximum(np.linalg.norm(result,axis=1)[:,None],1e-10)
np.save(p/'smoothed_normals.npy',out)
