"""ZR1X steering wheel traced from the driver's forward 3LZ panorama.

The rim, divided spokes, switch pads and emblem remain independent geometry.
All positions are converted to the installed steering-column plane.
"""
steer=(-.493,-.390,.712)
wheel_leather=mat('Graphite wheel leather','242528',.04,.55)
wheel_hub=mat('Horn pad leather','343539',.025,.55)
switch_black=mat('Recessed wheel switch','202124',.04,.49)
wheel_edge=mat('Satin spoke trim','a2a5aa',.71,.32)
wheel_stitch=mat('Wheel twin stitching','7b7c7c',.06,.73)
icon_white=mat('Switch symbol','e0e1df',.08,.51)
wheel_dark=mat('Emblem enamel','141519',.18,.28)

def wheel_point(px,py,depth=0):
    dz=(308-py)*.00053
    return (steer[0]-.26*dz+depth,steer[1]+(px-334)*.000544,steer[2]+dz)

def wheel_spline(points,steps=5):
    points=np.asarray(points,dtype=float)
    values=[]
    for k,b in enumerate(points):
        a=points[k-1];c=points[(k+1)%len(points)];d=points[(k+2)%len(points)]
        for t in np.arange(steps)/steps:
            values.append(.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t))
    return np.asarray(values)

def smooth_object(ob):
    for face in ob.data.polygons:face.use_smooth=True
    return ob

# Pack a subtle repeating two-by-two twill tile for the upper and lower rim.
weave=bpy.data.images.new('Graphite carbon twill',width=96,height=96,alpha=False)
y,x=np.mgrid[:96,:96];xcell=x//12;ycell=y//12
horizontal=(xcell-ycell)%4<2
ridge=np.where(horizontal,np.cos((y%12-5.5)*pi/12),np.cos((x%12-5.5)*pi/12))
filament=np.where(horizontal,np.cos(y*pi),np.cos(x*pi))
shade=np.clip(.12+.095*ridge+.038*filament+.05*horizontal,.05,.34).astype('float32')
rgba=np.stack((shade,shade*.99,shade*.99,np.ones_like(shade)),axis=2)
weave.pixels.foreach_set(rgba.ravel());weave.pack()
wheel_carbon=mat('Exposed gloss carbon wheel','333438',.29,.31)
node=wheel_carbon.node_tree.nodes.new('ShaderNodeTexImage');node.image=weave;node.extension='REPEAT'
wheel_carbon.node_tree.links.new(node.outputs['Color'],wheel_carbon.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])

profile=wheel_spline([(334,49),(445,53),(518,73),(561,105),(592,159),(615,231),(623,307),(615,384),(592,464),(567,515),(527,550),(453,570),(334,578),(220,571),(144,551),(102,523),(77,481),(54,418),(38,345),(36,272),(46,206),(66,148),(96,101),(148,72),(234,53)],6)
sides=18;verts=[];faces=[];classify=[];layers=len(profile)
for i,(x,y) in enumerate(profile):
    before=profile[i-1];after=profile[(i+1)%layers]
    tangent=after-before;out=np.array([tangent[1],-tangent[0]])/np.linalg.norm(tangent)
    # The heavy grips broaden toward the side spokes.
    width=31.5+5*math.exp(-((y-331)/75)**2)
    for j in range(sides):
        theta=2*pi*j/sides
        px,py=np.array((x,y))+out*width*cos(theta)
        verts.append(wheel_point(px,py,.019*sin(theta)))
    for j in range(sides):
        faces.append((i*sides+j,((i+1)%layers)*sides+j,((i+1)%layers)*sides+(j+1)%sides,i*sides+(j+1)%sides))
        classify.append(2 if y<60 and abs(x-334)<9 else int(y<120 or y>511))
rim=smooth_object(mesh('Carbon and leather steering wheel rim',verts,faces,wheel_leather,cab))
rim.data.materials.append(wheel_carbon);rim.data.materials.append(wheel_edge)
uv=rim.data.uv_layers.new(name='Twill grain')
for face,material_id in zip(rim.data.polygons,classify):
    face.material_index=material_id;i,j=divmod(face.index,sides)
    for li,coord in zip(face.loop_indices,[(i,j),(i+1,j),(i+1,j+1),(i,j+1)]):
        uv.data[li].uv=(coord[0]*25/layers,coord[1]*3/sides)

def wheel_panel(name,border,depth,material,edge=.0018,smoothing=3):
    loop=wheel_spline(border,smoothing) if smoothing>1 else np.array(border,dtype=float)
    middle=np.mean(loop,axis=0)
    rings=[(.96,depth-.011),(1,depth-.005),(.991,depth-.001),(.965,depth)]
    sections=[[wheel_point(*(middle+(xy-middle)*scale),offset) for xy in loop] for scale,offset in rings]
    ob=loft(name,sections,material,cab)
    for f in ob.data.polygons[:-2]:f.use_smooth=True
    return ob

outer=[(265,222),(397,222),(429,246),(462,292),(474,343),(462,391),(429,463),(399,493),(341,502),(267,497),(238,478),(213,438),(196,380),(193,324),(211,281),(238,243)]
inner=[(299,286),(377,286),(396,294),(413,317),(424,347),(415,387),(396,425),(382,442),(349,447),(291,446),(274,438),(262,416),(247,364),(246,340),(261,308),(277,291)]
wheel_panel('Stitched polygonal horn pad',outer,.038,wheel_hub)
wheel_panel('Horn emblem bezel',inner,.0405,wheel_edge)
core=np.asarray(inner);core=(core-[334,365])*.943+[334,365];wheel_panel('Horn emblem panel',core,.0418,wheel_leather)
for ratio in (.935,.960):
    loop=wheel_spline(outer,7);base=np.array([334,354]);loop=base+(loop-base)*ratio
    for i in range(0,len(loop)-1,2):
        path('Horn pad topstitch',[wheel_point(*loop[i],.0386),wheel_point(*((loop[i]+loop[i+1])*.5),.0386)],.00038,wheel_stitch,cab)
for sign in (-1,1):
    def mirror(px):return 334+sign*(px-334)
    def outline(coords):return [(mirror(x),y) for x,y in coords]
    spoke=[(410,238),(433,248),(503,286),(573,333),(594,354),(609,418),(604,449),(587,460),(559,455),(450,412),(438,393),(446,366)]
    wheel_panel('Swept steering spoke surround',outline(spoke),.0175,wheel_edge)
    inset=[(430,260),(461,275),(549,325),(586,353),(594,383),(597,431),(586,447),(562,442),(462,405),(453,389),(455,349)]
    wheel_panel('Steering spoke switch fascia',outline(inset),.0202,switch_black)
    cluster=[(508,357),(566,357),(584,369),(588,397),(578,405),(516,405),(506,395)]
    wheel_panel('Rocker control bezel',outline(cluster),.0225,wheel_dark)
    slider=[(533,375),(554,375),(555,395),(533,395)]
    wheel_panel('Steering knurled roller',outline(slider),.0255,dark)
    for k in range(5):
        px=mirror(535+4*k)
        path('Roller serration',[wheel_point(px,376,.026),wheel_point(px,394,.026)],.00038,wheel_edge,cab)
    for px,py in [(506,382),(578,382),(547,344),(547,419)]:
        if px!=547:
            dx=3 if px<540 else -3
            arr=[(px+dx,py-4),(px,py),(px+dx,py+4)]
        else:
            dy=2.5 if py<360 else -2.5
            arr=[(px-6,py+dy),(px,py),(px+6,py+dy)]
        path('Steering switch graphic',[wheel_point(mirror(xx),yy,.024) for xx,yy in arr],.00065,icon_white,cab)
    paddle=[(526,231),(539,229),(547,244),(551,306),(540,317),(525,303)]
    wheel_panel('Column shift paddle',outline(paddle),-.030,carbon)
    path('Paddle shift mark',[wheel_point(mirror(530),241,-.029),wheel_point(mirror(542),241,-.029)],.00065,icon_white,cab)
    if sign>0:path('Upshift mark',[wheel_point(mirror(536),235,-.029),wheel_point(mirror(536),247,-.029)],.00065,icon_white,cab)

# Crossed-flags emblem. Checkered inboard flag and red outer flag are modeled
# on a single polished outline. Each quadrilateral follows its swept field.
def flag_mesh(name,corners,depth,material):
    return mesh(name,[wheel_point(x,y,depth) for x,y in corners],[tuple(range(len(corners)-1,-1,-1))],material,cab)
badge=[(295,327),(334,364),(377,326),(369,365),(343,388),(337,407),(333,401),(328,387),(303,365)]
flag_mesh('Crossed flags alloy bezel',badge,.0435,wheel_edge)
L=np.array([(299,333),(335,367),(331,385),(306,361)])
R=np.array([(335,368),(374,332),(367,359),(340,386)])
flag_mesh('Left flag black enamel',L,.0440,wheel_dark)
flag_mesh('Right flag red enamel',R,.0440,red)
def bilinear(p,u,v):
    return (1-v)*((1-u)*p[0]+u*p[1])+v*((1-u)*p[3]+u*p[2])
for i in range(4):
    for j in range(2):
        if (i+j)%2==0:
            flag_mesh('Chequered flag enamel',[bilinear(L,a,b) for a,b in [(i/4,j/2),((i+1)/4,j/2),((i+1)/4,(j+1)/2),(i/4,(j+1)/2)]],.0444,icon_white)
flag_mesh('Red flag motif',[(349,361),(364,347),(361,354),(355,360),(357,358),(355,365),(348,373)],.0444,wheel_dark)
