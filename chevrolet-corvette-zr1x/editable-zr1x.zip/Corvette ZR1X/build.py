"""Rebuild the ZR1X studio master and its production GLB with Blender 5.2."""
from pathlib import Path
import bpy,numpy as np,math,sys,json
from mathutils import Vector
from math import pi,sin,cos
ROOT=Path(__file__).resolve().parent
OUT=Path(sys.argv[sys.argv.index('--')+1]) if '--' in sys.argv else ROOT/'export'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
sc=bpy.context.scene
def lin(c):return c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4
def mat(name,hex,metal=0,rough=.4):
 c=tuple(lin(int(hex[i:i+2],16)/255) for i in [0,2,4])
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF')
 b.inputs['Base Color'].default_value=(*c,1);b.inputs['Roughness'].default_value=rough;b.inputs['Metallic'].default_value=metal;m.use_backface_culling=False;return m
skin=mat('Torch Red • reconstructed surface','ffffff',.04,.31)
trim=mat('Studio-fit trim and carbon','ffffff',.01,.76)
glass=mat('Neutral tinted laminated glazing','ffffff',.04,.18)
for m in [skin,trim,glass]:
 nt=m.node_tree;b=nt.nodes.get('Principled BSDF');a=nt.nodes.new('ShaderNodeVertexColor');a.layer_name='Surface tone';nt.links.new(a.outputs['Color'],b.inputs['Base Color'])
 b.inputs['Specular IOR Level'].default_value=.44 if m==skin else .18;m.use_backface_culling=True
skin.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=.20
glass.surface_render_method='DITHERED';glass.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.98
rubber=mat('Pilot Sport sidewall','1e2022',.02,.74);tread=mat('Tread channels','111319',.01,.81);alloy=mat('Satin forged graphite','494b51',.60,.32);lip=mat('Machined edge','777c82',.73,.26);rotor=mat('Carbon ceramic rotor','48494b',.38,.65);holes=mat('Rotor drilling','252629',.02,.8)
dark=mat('Black anodized metal','282a30',.25,.47);blue=mat('Black Alcon caliper','303034',.23,.40);bk=mat('Jet Black cabin','22252a',.03,.73);pad=mat('Seat bolster leather','3a3c40',0,.53);metal=mat('Brushed interior trim','81868c',.56,.33);suede=mat('Perforated seat insert','292b30',.005,.88);red=mat('Torch Red accent','c52330',.05,.49);linen=mat('Contrasting stitching','848484',0,.81);blackglass=mat('Smoked engine glass','262f34',.26,.2);carbon=mat('Graphite carbon aero','2f3035',.25,.34)
def empty(name,loc=(0,0,0)):
 o=bpy.data.objects.new(name,None);sc.collection.objects.link(o);o.location=loc;return o
def mesh(name,v,f,m,parent=None):
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.materials.append(m);me.update();o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);o.parent=parent;return o
def roundbox(name,c,dim,m,parent,rad=.022,ry=0,rz=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=c);o=bpy.context.object;o.name=name;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.rotation_euler=(0,ry,rz);o.data.materials.append(m);o.parent=parent
 if rad:
  mod=o.modifiers.new('Softened edges','BEVEL');mod.width=rad;mod.segments=3;mod=o.modifiers.new('Planar faces','WEIGHTED_NORMAL')
 return o
def path(name,points,r,m,parent,cyclic=False):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=r;cu.bevel_resolution=2;s=cu.splines.new('POLY');s.points.add(len(points)-1)
 for pp,co in zip(s.points,points):pp.co=(*co,1)
 s.use_cyclic_u=cyclic;o=bpy.data.objects.new(name,cu);sc.collection.objects.link(o);o.parent=parent;cu.materials.append(m);return o
def loft(name,sections,m,parent):
 n=len(sections[0]);f=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i) for j in range(len(sections)-1) for i in range(n)];f+=[tuple(range(n-1,-1,-1)),tuple(range((len(sections)-1)*n,len(sections)*n))]
 return mesh(name,[v for sec in sections for v in sec],f,m,parent)
body=empty('Body');cab=empty('Cockpit');wing=empty('Carbon_Aero');roof=empty('Roof_panel');doors={}
for s,side in [(-1,'L'),(1,'R')]:doors[s]=empty('Door_'+side,(-.93,s*.84,.64))
d=np.load(ROOT/'finalskin.npz');v,f,c=d['v'],d['f'],d['color'];smoothed=np.load(ROOT/'smoothed_normals.npy');pos=v[f].mean(axis=1);x,y,z=pos.T;ay=abs(y)
g=np.zeros(len(f),int);g[(x>1.63)&(z>1.015)]=1
g[(x>-.435)&(x<.27)&(z>1.125)&(ay<.59)]=2
doorfront=-.94+.25*np.clip((z-.78)/.31,0,1)
doorback=.285+.28*np.clip((z-.29)/.42,0,1)-.16*np.clip((z-.77)/.35,0,1)
door=(x>doorfront)&(x<doorback)&(ay>(.745-.15*np.clip((z-.82)/.33,0,1)))&(z>.205)&(z<1.144)&(g==0)
g[door&(y<0)]=3;g[door&(y>0)]=4
for j,parent in enumerate([body,wing,roof,doors[-1],doors[1]]):
 sel=np.where((g==j)&(~d["cutWindows"][f].all(axis=1)))[0];
 if len(sel)==0:continue
 ids,ind=np.unique(f[sel].ravel(),return_inverse=True);tris=ind.reshape(-1,3).astype('int32')
 vv=v[ids]-np.array(parent.location);name=['Exterior shell','High rear wing','Removable carbon roof','Left outer door','Right outer door'][j]
 me=bpy.data.meshes.new(name);me.vertices.add(len(vv));me.vertices.foreach_set('co',vv.astype('f').ravel());me.loops.add(tris.size);me.loops.foreach_set('vertex_index',tris.ravel());me.polygons.add(len(tris));me.polygons.foreach_set('loop_start',np.arange(0,tris.size,3,dtype='int32'))
 for m in (skin,trim,glass):me.materials.append(m)
 faceMat=np.where(d['paint'][f[sel]].mean(axis=1)>.5,0,np.where(d['glass'][f[sel]].mean(axis=1)>.6,2,1))
 me.polygons.foreach_set('material_index',faceMat.astype('int32'));me.polygons.foreach_set('use_smooth',np.ones(len(tris),bool))
 a=me.color_attributes.new(name='Surface tone',type='BYTE_COLOR',domain='POINT');tone=np.column_stack([c[ids]/255,np.ones(len(ids))]).astype('f');a.data.foreach_set('color_srgb',tone.ravel());me.update();me.normals_split_custom_set_from_vertices(smoothed[ids].tolist())
 o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);o.parent=parent
# Height samples relative to the reconstructed painted top for trim fitted to its contour.
def top(x,y):
 a=(np.abs(v[:,0]-x)<.023)&(np.abs(v[:,1]-y)<.023)
 if np.any(a):return float(v[a,2].max())
 k=np.argmin((v[:,0]-x)**2+(v[:,1]-y)**2-.00005*v[:,2]);return float(v[k,2])
def surface(name,stations,m,parent):
 verts=[];faces=[];N=14
 for j,(xx,y0,y1,off) in enumerate(stations):
  for k in range(N+1):
   yy=y0+(y1-y0)*k/N;verts.append((xx,yy,top(xx,yy)+off))
  if j:faces.extend([((j-1)*(N+1)+k,j*(N+1)+k,j*(N+1)+k+1,(j-1)*(N+1)+k+1) for k in range(N)])
 o=mesh(name,verts,faces,m,parent)
 for fa in o.data.polygons:fa.use_smooth=True
 return o
exec(compile((ROOT/'details.py').read_text(),str(ROOT/'details.py'),'exec'))
for j in range(5):
 xx=.57+j*.18
 surface('Engine spine vent',[(xx,-.12,.12,.012),(xx+.035,-.126,.126,.023),(xx+.07,-.123,.123,.011)],carbon,body)
# Independently editable tire/rim/brake assemblies. Axle-center track and tire section dimensions in meters.
def wheels(k,s):
 x,r,halftrack,width,rim=[(-1.3615,.3365,.8425,.275,.254),(1.3615,.35295,.839,.345,.2667)][k]
 name=('Front_' if k==0 else 'Rear_')+('left' if s<0 else 'right');grp=empty(name,(x,s*halftrack,r));a=width/2
 def radial(name,profile,material,count=88):
  vv=[];ff=[]
  for rr,yy in profile:
   for n in range(count):
    phi=2*pi*n/count;vv.append((rr*cos(phi),s*yy,rr*sin(phi)))
  for j in range(len(profile)-1):
   for n in range(count):
    ids=(j*count+n,j*count+(n+1)%count,(j+1)*count+(n+1)%count,(j+1)*count+n);ff.append(ids if s<0 else ids[::-1])
  o=mesh(name,vv,ff,material,grp)
  for fa in o.data.polygons:fa.use_smooth=True
  return o
 prof=[(rim-.003,-a+.014),(rim+.014,-a+.002),(.91*r,-a),(.97*r,-a+.01),(r,-a+.031)]
 for frac in [-.55,-.26,.17,.49]:
  y0=a*frac;prof.extend([(r,y0-.0045),(r-.004,y0-.002),(r-.004,y0+.002),(r,y0+.0045)])
 prof.extend([(r,a-.031),(.97*r,a-.01),(.91*r,a),(rim+.012,a-.003),(rim-.003,a-.012),(rim-.003,-a+.014)])
 radial('Performance tire',prof,rubber);front=a-.01
 radial('Rim and inner barrel',[(rim,-a+.018),(rim,front),(rim-.008,front+.003),(rim-.016,front-.003),(rim-.016,-a+.018)],alloy)
 radial('Rim flange',[(rim-.013,front+.001),(rim+.005,front+.003),(rim+.010,front-.001),(rim+.012,front-.005)],alloy)
 for rr in (rim+.016,r-.022):
  radial('Molded sidewall ring',[(rr-.0013,a-.001),(rr,a+.0003),(rr+.0016,a-.001)],rubber)
 radial('Faceted hub cap',[(0,front-.052),(.041,front-.051),(.048,front-.057),(.077,front-.043),(.083,front-.058),(.06,front-.073),(0,front-.07)],alloy,50)
 radial('16.5 inch carbon-ceramic rotor',[(.045,front-.090),(.20955,front-.090),(.20955,front-.105),(.045,front-.105)],rotor,80)
 for n in range(5):
  angle=2*pi*n/5+.22
  for split in [-1,1]:
   sec=[]
   for rr,turn,yr,w in [(0.052,0,front-.05,.019),(.099,.023*split,front-.04,.013),(.17,.13*split,front-.023,.010),(rim-.010,.255*split,front-.008,.014)]:
    phi=angle+turn;aa=np.array([cos(phi),0,sin(phi)]);bb=np.array([-sin(phi),0,cos(phi)]);center=rr*aa+np.array([0,s*yr,0]);sec.append([tuple(center+bb*dw+np.array([0,s*dy,0])) for dw,dy in [(-w,-.009),(-w*.77,.002),(w*.85,.003),(w,-.01)]])
   o=loft('Forked forged spoke',sec,alloy,grp)
   sec=[]
   for rr,turn,ww in [(.105,.015*split,.0092),(.145,.19*split,.008),(.208,.39*split,.0076),(rim-.011,.39*split,.008)]:
    phi=angle+turn;aa=np.array([cos(phi),0,sin(phi)]);bb=np.array([-sin(phi),0,cos(phi)]);center=rr*aa+[0,s*(front-.036+.024*rr/rim),0]
    sec.append([tuple(center+bb*dw+[0,s*dy,0]) for dw,dy in [(-ww,-.006),(-ww,.002),(ww,.002),(ww,-.006)]])
   loft('Cross-braced spoke web',sec,alloy,grp)
  phi=angle+.51;bolt=(.054*cos(phi),s*(front-.024),.054*sin(phi))
  bpy.ops.mesh.primitive_cylinder_add(vertices=6,radius=.009,depth=.011,location=bolt,rotation=(pi/2,0,0));o=bpy.context.object;o.name='Wheel nut';o.parent=grp;o.data.materials.append(lip)
 # Disc drillings and vented caliper are actual editable meshes.
 vv=[];ff=[]
 for n in range(30):
  for q in range(3):
   phi=2*pi*(n+.29*q)/30;rr=.145+.020*q;cx,cz=rr*cos(phi),rr*sin(phi);idx=len(vv)
   vv.extend([(cx+.0034*cos(t*2*pi/7),s*(front-.089),cz+.0034*sin(t*2*pi/7)) for t in range(7)]);ff.append(tuple(range(idx,idx+7)) if s<0 else tuple(range(idx+6,idx-1,-1)))
 mesh('Carbon rotor perforations',vv,ff,holes,grp)
 roundbox('Alcon caliper',(.168,s*(front-.078),.033),(.074,.059,.191),blue,grp,.024,ry=-.17)
 return grp
for k in range(2):
 for s in [-1,1]:wheels(k,s)
# The driver sits on the left facing negative X. Coordinates stay in vehicle space until export.
roundbox('Cockpit tub',(-.1,0,.227),(1.69,1.4,.083),bk,cab,.041)
roundbox('Front footwell liner',(-.873,0,.453),(.15,1.345,.423),bk,cab,.04,ry=-.05)
roundbox('Rear bulkhead',(.39,0,.65),(.13,1.36,.74),bk,cab,.064,ry=.13)
roundbox('Instrument panel carrier',(-.8,0,.72),(.35,1.47,.18),bk,cab,.07,ry=.04)
roundbox('Dashboard brow',(-.79,0,.786),(.29,1.45,.07),pad,cab,.031)
exec(compile((ROOT/'cabin_trim.py').read_text(),str(ROOT/'cabin_trim.py'),'exec'))
for s in [-1,1]:
 yy=s*.383;offset=-.182 if s<0 else 0
 roundbox('GT2 seat cushion',(.043+offset,yy,.386),(.56,.438,.112),suede,cab,.048,ry=-.05)
 for sy in [-1,1]:
  roundbox('Seat thigh bolster',(.042+offset,yy+sy*.187,.423),(.475,.089,.106),pad,cab,.043,ry=-.04)
  roundbox('Seat rib bolster',(.285+offset,yy+sy*.163,.671),(.129,.112,.42),pad,cab,.051,ry=.18)
 roundbox('Sculpted bucket back',(.286+offset,yy,.682),(.132,.351,.517),suede,cab,.064,ry=.19)
 roundbox('Integrated head restraint',(.338+offset,yy,.953),(.109,.228,.198),pad,cab,.051,ry=.12)
 for q in range(6):
  xx=offset-.12+q*.054;path('Seat cushion seam',[(xx,yy-.114,.434),(xx-.011,yy,.44),(xx,yy+.114,.434)],.0018,bk,cab)
 # Door card and contrast topstitch follow the hinge as the closures open.
 par=doors[s];pivot=np.array(par.location)
 def in_door(v):return tuple(np.asarray(v)-pivot)
 roundbox('Inner door card',in_door((-.255,s*.675,.535)),(1.22,.046,.417),bk,par,.022)
 path('Door grab rail',[in_door(vv) for vv in [(-.65,s*.661,.679),(-.33,s*.653,.49),(-.11,s*.655,.469),(.16,s*.659,.48)]],.017,metal,par)
 if s>0:roundbox('Window switch panel',in_door((-.38,s*.648,.514)),(.23,.04,.034),dark,par,.008,ry=.14)
 path('Upper door stitch',[in_door(vv) for vv in [(-.79,s*.681,.72),(-.33,s*.67,.739),(.16,s*.678,.742)]],.0021,linen,par)
# Inner A-pillar molding follows the windshield edge in the forward panorama.
cc=json.loads((ROOT/'cabin-camera.json').read_text());pillar_eye=np.array(cc['eye']);pf=np.array(cc['look'])-pillar_eye;pf/=np.linalg.norm(pf);pr=np.cross(pf,[0,0,1]);pr/=np.linalg.norm(pr);pu=np.cross(pr,pf)
def molding_point(x,u,v):
 ray=pf+pr*(u/305-1)+pu*(1-v/305)
 return pillar_eye+ray*((x-pillar_eye[0])/ray[0])
for sign in [-1,1]:
 sections=[]
 for xx,left,right in [(-.938,(89,228),(178,224)),(-.836,(58,202),(156,202)),(-.72,(16,137),(123,140)),(-.632,(-14,76),(100,85)),(-.54,(-50,4),(74,4)),(-.436,(-97,-121),(26,-103))]:
  lo=molding_point(xx,*left);hi=molding_point(xx,*right);mid=(lo+hi)*.5;radius=(hi-lo)*.5
  sec=[]
  for th in np.linspace(0,2*pi,24,endpoint=False):
   p=mid+radius*cos(th)+np.array([0,-.019*sin(th),.0135*sin(th)])
   p[1]=-sign*p[1];sec.append(p)
  sections.append(sec)
 pillar=loft('Windshield pillar lining',sections,bk,cab)
 for f0 in pillar.data.polygons:f0.use_smooth=True
 sections=[];pivot=np.array(doors[sign].location)
 for xx,top_z in [(-.91,.775),(-.76,.816),(-.65,.830),(-.43,.834),(-.20,.827),(.14,.801),(.34,.783)]:
  yz=[(.650,top_z-.122),(.653,top_z-.053),(.666,top_z-.018),(.692,top_z),(.727,top_z+.001),(.770,top_z-.010),(.780,top_z-.044),(.757,top_z-.131)]
  sections.append([np.asarray([xx,sign*yy,zz])-pivot for yy,zz in yz])
 rail=loft('Sculptured inner window sill',sections,bk,doors[sign])
 for f0 in rail.data.polygons:f0.use_smooth=True
roundbox('Front roof header',(-.414,0,1.141),(.082,1.119,.055),bk,cab,.019)
roundbox('Headliner',(-.064,0,1.168),(.61,1.052,.037),bk,roof,.018)
path('Mirror stalk',[(-.638,0,1.072),(-.571,0,1.035)],.012,bk,cab)
roundbox('Rear view mirror',(-.557,0,1.044),(.034,.219,.058),dark,cab,.014)
exec(compile((ROOT/'steering.py').read_text(),str(ROOT/'steering.py'),'exec'))
exec(compile((ROOT/'dash.py').read_text(),str(ROOT/'dash.py'),'exec'))
for y in [-.46,-.319]:roundbox('Pedal',(-.824,y,.328),(.026,.053,.101),metal,cab,.008,ry=.24)
# Physical links indicated by Chevrolet's propulsion description. External housings are schematic.
drive=empty('Powertrain')
roundbox('LT7 crankcase',(1.035,0,.475),(.57,.491,.335),dark,drive,.063)
for s in [-1,1]:
 roundbox('Twin cam bank covers',(1.035,s*.202,.66),(.568,.172,.129),metal,drive,.048)
 for j in range(4):roundbox('Coil housing',(.848+.121*j,s*.209,.725),(.063,.116,.026),dark,drive,.011)
 roundbox('Turbocharger housing',(1.07,s*.328,.432),(.171,.145,.158),alloy,drive,.057)
roundbox('Rear dual-clutch transaxle housing',(1.545,0,.457),(.385,.395,.279),alloy,drive,.071)
roundbox('Front drive unit',(-1.368,0,.351),(.333,.482,.237),alloy,drive,.055)
roundbox('Battery tunnel',(-.191,0,.265),(1.12,.286,.179),dark,drive,.042)
# The 3D parts use meters. Keep the original, editable hierarchy in the native Blender master.
sc.unit_settings.system='METRIC';sc.unit_settings.length_unit='METERS'
sc.world=bpy.data.worlds.new('Studio world');sc.world.color=(.24,.24,.24)
bpy.context.scene.render.engine='CYCLES'
exec(compile((ROOT/'saved_cameras.py').read_text(),str(ROOT/'saved_cameras.py'),'exec'))
add_comparison_cameras(json.loads((ROOT/'studio.json').read_text())['views'])
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'ZR1X.blend'),compress=True)
bpy.ops.export_scene.gltf(filepath=str(OUT/'zr1x.glb'),export_format='GLB',export_apply=True,export_animations=False,export_yup=True,export_draco_mesh_compression_enable=True,export_draco_mesh_compression_level=6,export_draco_position_quantization=14,export_draco_texcoord_quantization=14)
