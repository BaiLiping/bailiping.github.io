"""Rebuild the ZR1X studio master and its production GLB with Blender 5.2."""
from pathlib import Path
import bpy,numpy as np,math,sys,json
from mathutils import Vector
from math import pi,sin,cos
ROOT=Path(__file__).resolve().parent
OUT=Path(sys.argv[sys.argv.index('--')+1]) if '--' in sys.argv else ROOT/'export'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
sc=bpy.context.scene
def lin(c):return c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4
def mat(name,hex,metal=0,rough=.4):
 c=tuple(lin(int(hex[i:i+2],16)/255) for i in [0,2,4])
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF')
 b.inputs['Base Color'].default_value=(*c,1);b.inputs['Roughness'].default_value=rough;b.inputs['Metallic'].default_value=metal;m.use_backface_culling=False;return m
skin=mat('Torch Red • reconstructed surface','ffffff',.04,.31)
trim=mat('Studio-fit trim and carbon','ffffff',.01,.76)
glass=mat('Neutral tinted laminated glazing','ffffff',.04,.18)
for m in [skin,trim,glass]:
 nt=m.node_tree;b=nt.nodes.get('Principled BSDF');a=nt.nodes.new('ShaderNodeVertexColor');a.layer_name='Surface tone';nt.links.new(a.outputs['Color'],b.inputs['Base Color'])
 b.inputs['Specular IOR Level'].default_value=.44 if m==skin else .18;m.use_backface_culling=True
skin.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=.20
glass.surface_render_method='DITHERED';glass.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.98
rubber=mat('Pilot Sport sidewall','1e2022',.02,.74);tread=mat('Tread channels','111319',.01,.81);alloy=mat('Satin forged graphite','414449',.45,.46);lip=mat('Machined edge','777c82',.73,.26);rotor=mat('Carbon ceramic rotor','515255',.22,.71);holes=mat('Rotor drilling','191b1c',.015,.84)
dark=mat('Black anodized metal','282a30',.25,.47);blue=mat('Black Alcon caliper','303034',.23,.40);bk=mat('Jet Black cabin','22252a',.03,.73);pad=mat('Seat bolster leather','3a3c40',0,.53);metal=mat('Brushed interior trim','81868c',.56,.33);suede=mat('Perforated seat insert','292b30',.005,.88);red=mat('Torch Red accent','c52330',.05,.49);linen=mat('Contrasting stitching','848484',0,.81);blackglass=mat('Smoked engine glass','262f34',.26,.2);carbon=mat('Graphite carbon aero','2f3035',.25,.34)
def empty(name,loc=(0,0,0)):
 o=bpy.data.objects.new(name,None);sc.collection.objects.link(o);o.location=loc;return o
def mesh(name,v,f,m,parent=None):
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.materials.append(m);me.update();o=bpy.data.objects.new(name,me);sc.collection.objects.link(o);o.parent=parent;return o
def roundbox(name,c,dim,m,parent,rad=.022,ry=0,rz=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=c);o=bpy.context.object;o.name=name;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.rotation_euler=(0,ry,rz);o.data.materials.append(m);o.parent=parent
 if rad:
  mod=o.modifiers.new('Softened edges','BEVEL');mod.width=rad;mod.segments=3;mod=o.modifiers.new('Planar faces','WEIGHTED_NORMAL')
 return o
def path(name,points,r,m,parent,cyclic=False):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=r;cu.bevel_resolution=2;s=cu.splines.new('POLY');s.points.add(len(points)-1)
 for pp,co in zip(s.points,points):pp.co=(*co,1)
 s.use_cyclic_u=cyclic;o=bpy.data.objects.new(name,cu);sc.collection.objects.link(o);o.parent=parent;cu.materials.append(m);return o
def loft(name,sections,m,parent):
 n=len(sections[0]);f=[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i) for j in range(len(sections)-1) for i in range(n)];f+=[tuple(range(n-1,-1,-1)),tuple(range((len(sections)-1)*n,len(sections)*n))]
 return mesh(name,[v for sec in sections for v in sec],f,m,parent)
body=empty('Body');cab=empty('Cockpit');wing=empty('Carbon_Aero');roof=empty('Roof_panel');doors={}
for s,side in [(-1,'L'),(1,'R')]:doors[s]=empty('Door_'+side,(-.93,s*.84,.64))
exec(compile((ROOT/'bodywork.py').read_text(),str(ROOT/'bodywork.py'),'exec'))
# Height samples relative to the reconstructed painted top for trim fitted to its contour.
def top(x,y):
 a=(np.abs(v[:,0]-x)<.023)&(np.abs(v[:,1]-y)<.023)
 if np.any(a):return float(v[a,2].max())
 k=np.argmin((v[:,0]-x)**2+(v[:,1]-y)**2-.00005*v[:,2]);return float(v[k,2])
def surface(name,stations,m,parent):
 verts=[];faces=[];N=14
 for j,(xx,y0,y1,off) in enumerate(stations):
  for k in range(N+1):
   yy=y0+(y1-y0)*k/N;verts.append((xx,yy,top(xx,yy)+off))
  if j:faces.extend([((j-1)*(N+1)+k,j*(N+1)+k,j*(N+1)+k+1,(j-1)*(N+1)+k+1) for k in range(N)])
 o=mesh(name,verts,faces,m,parent)
 for fa in o.data.polygons:fa.use_smooth=True
 return o
exec(compile((ROOT/'details.py').read_text(),str(ROOT/'details.py'),'exec'))
exec(compile((ROOT/'exterior_details.py').read_text(),str(ROOT/'exterior_details.py'),'exec'))
exec(compile((ROOT/'glazing.py').read_text(),str(ROOT/'glazing.py'),'exec'))
exec(compile((ROOT/'exterior_badges.py').read_text(),str(ROOT/'exterior_badges.py'),'exec'))
exec(compile((ROOT/'rolling_gear.py').read_text(),str(ROOT/'rolling_gear.py'),'exec'))
# The driver sits on the left facing negative X. Coordinates stay in vehicle space until export.
exec(compile((ROOT/'cabin_structure.py').read_text(),str(ROOT/'cabin_structure.py'),'exec'))
exec(compile((ROOT/'cabin_trim.py').read_text(),str(ROOT/'cabin_trim.py'),'exec'))
exec(compile((ROOT/'seats.py').read_text(),str(ROOT/'seats.py'),'exec'))
for s in [-1,1]:
 # Door card and contrast topstitch follow the hinge as the closures open.
 par=doors[s];pivot=np.array(par.location)
 def in_door(v):return tuple(np.asarray(v)-pivot)
 roundbox('Inner door card',in_door((-.255,s*.675,.535)),(1.22,.046,.417),bk,par,.022)
 path('Door grab rail',[in_door(vv) for vv in [(-.65,s*.661,.679),(-.33,s*.653,.49),(-.11,s*.655,.469),(.16,s*.659,.48)]],.017,metal,par)
 if s>0:roundbox('Window switch panel',in_door((-.38,s*.648,.514)),(.23,.04,.034),dark,par,.008,ry=.14)
 path('Upper door stitch',[in_door(vv) for vv in [(-.79,s*.681,.72),(-.33,s*.67,.739),(.16,s*.678,.742)]],.0021,linen,par)
# Inner A-pillar molding follows the windshield edge in the forward panorama.
cc=json.loads((ROOT/'cabin-camera.json').read_text());pillar_eye=np.array(cc['eye']);pf=np.array(cc['look'])-pillar_eye;pf/=np.linalg.norm(pf);pr=np.cross(pf,[0,0,1]);pr/=np.linalg.norm(pr);pu=np.cross(pr,pf)
def molding_point(x,u,v):
 ray=pf+pr*(u/305-1)+pu*(1-v/305)
 return pillar_eye+ray*((x-pillar_eye[0])/ray[0])
for sign in [-1,1]:
 sections=[]
 # Fit the panorama silhouette from the eye, while keeping the trim inboard
 # of the external post. The near, wrapped surface meets the top of the dash.
 sections_for_pillar=[(-.811,(85,253),(178,245)),(-.793,(89,228),(178,224)),(-.714,(58,202),(156,202)),
                      (-.624,(16,137),(123,140)),(-.558,(-14,76),(100,85)),
                      (-.495,(-50,4),(74,4)),(-.425,(-97,-121),(26,-103))]
 for xx,left,right in sections_for_pillar:
  lo=molding_point(xx,*left);hi=molding_point(xx,*right)
  mid=(lo+hi)*.5;radius=(hi-lo)*.5;section=[]
  for th in np.linspace(0,2*pi,30,endpoint=False):
   point=mid+radius*cos(th)+np.array([.012*sin(th),-.008*sin(th),.013*sin(th)])
   hit,_,_,_=tree.ray_cast(Vector((float(point[0]),-1.32,float(point[2]))),Vector((0,1,0)))
   if hit is not None:point[1]=max(point[1],hit.y+.016)
   point[1]=-sign*point[1];section.append(point)
  sections.append(section)
 pillar=loft('Windshield pillar lining',sections,bk,cab)
 for face in pillar.data.polygons:face.use_smooth=True
 sections=[];pivot=np.array(doors[sign].location)
 for xx,top_z in [(-.91,.775),(-.76,.816),(-.65,.830),(-.43,.834),(-.20,.827),(.14,.801),(.34,.783)]:
  yz=[(.650,top_z-.122),(.653,top_z-.053),(.666,top_z-.018),(.692,top_z),(.727,top_z+.001),(.770,top_z-.010),(.780,top_z-.044),(.757,top_z-.131)]
  sections.append([np.asarray([xx,sign*yy,zz])-pivot for yy,zz in yz])
 rail=loft('Sculptured inner window sill',sections,bk,doors[sign])
 for f0 in rail.data.polygons:f0.use_smooth=True
for label,xa,xb,w,parent in [('Front roof header',-.46,-.396,.56,cab),('Headliner',-.391,.365,.555,roof)]:
 sections=[]
 for yy in np.linspace(-w,w,47):
  # The native roof is curved in both axes. The lining tracks its inner face.
  sections.append([(xx,yy,surface_z(xx,yy)-off) for xx,off in [(xa,.019),(xb,.019),(xb,.043),(xa,.043)]])
 lining=loft(label,sections,bk,parent)
 for face in lining.data.polygons:face.use_smooth=True
path('Mirror stalk',[(-.638,0,1.072),(-.571,0,1.035)],.012,bk,cab)
roundbox('Rear view mirror',(-.557,0,1.044),(.034,.219,.058),dark,cab,.014)
exec(compile((ROOT/'steering.py').read_text(),str(ROOT/'steering.py'),'exec'))
exec(compile((ROOT/'dash.py').read_text(),str(ROOT/'dash.py'),'exec'))
for y in [-.46,-.319]:roundbox('Pedal',(-.824,y,.328),(.026,.053,.101),metal,cab,.008,ry=.24)
exec(compile((ROOT/'propulsion.py').read_text(),str(ROOT/'propulsion.py'),'exec'))
exec(compile((ROOT/'suspension.py').read_text(),str(ROOT/'suspension.py'),'exec'))
# The 3D parts use meters. Keep the original, editable hierarchy in the native Blender master.
sc.unit_settings.system='METRIC';sc.unit_settings.length_unit='METERS'
sc.world=bpy.data.worlds.new('Studio world');sc.world.color=(.24,.24,.24)
bpy.context.scene.render.engine='CYCLES'
exec(compile((ROOT/'carbon_finish.py').read_text(),str(ROOT/'carbon_finish.py'),'exec'))
exec(compile((ROOT/'saved_cameras.py').read_text(),str(ROOT/'saved_cameras.py'),'exec'))
add_comparison_cameras(json.loads((ROOT/'studio.json').read_text())['views'])
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'ZR1X.blend'),compress=True)
bpy.ops.export_scene.gltf(filepath=str(OUT/'zr1x.glb'),export_format='GLB',export_apply=True,export_animations=False,export_yup=True,export_draco_mesh_compression_enable=True,export_draco_mesh_compression_level=6,export_draco_position_quantization=14,export_draco_texcoord_quantization=14)
