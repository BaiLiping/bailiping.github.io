"""Install each saved Three.js comparison projection in the Blender master."""
import math
from mathutils import Matrix,Vector
import json,bpy
def add_comparison_cameras(records):
 coll=bpy.data.collections.get('Registered reference cameras')
 if coll:return
 coll=bpy.data.collections.new('Registered reference cameras');bpy.context.scene.collection.children.link(coll)
 for view in records:
  def xyz(q):return Vector((q[0],-q[2],q[1]))
  p=xyz(view['position']);direction=(xyz(view['target'])-p).normalized();back=-direction
  right=xyz(view.get('up',[0,1,0])).cross(back).normalized();up=back.cross(right)
  ca=bpy.data.cameras.new(view['id']);ca.type='PERSP';ca.sensor_fit='VERTICAL';ca.sensor_height=32.;ca.lens=16./math.tan(math.radians(view['fov'])/2)
  w,h=view['imageSize'];cx,cy=view.get('principalPoint',(w/2,h/2))
  ca.shift_x=(w/2-cx)/h;ca.shift_y=(cy-h/2)/h;ca.display_size=.1
  ob=bpy.data.objects.new(view['id']+' · '+view['label'],ca);coll.objects.link(ob)
  ob.matrix_world=Matrix((right,up,back)).transposed().to_4x4();ob.location=p
  ob['source_width']=w;ob['source_height']=h;ob['source_url']=view['source'];ob['frame_id']=view['id']
  if view['id']=='ext-001':bpy.context.scene.camera=ob
 bpy.context.scene.render.resolution_x=1500;bpy.context.scene.render.resolution_y=750;bpy.context.scene.render.resolution_percentage=100
