"""Door drop glass, fixed quarter lights and painted cant rails fitted to the profile and overhead photographs."""
import bmesh
cam6=frame_camera(6)
eye6,rotation6,intrinsics6=cam6
# The seal slopes slightly forward from its top to its foot in the profile photograph.
def traced_ray(u,v0):
    cx0,cy0,fp0=intrinsics6
    return rotation6.T@np.array([(u-cx0)/fp0,(v0-cy0)/fp0,1])
plane_normal=np.cross(traced_ray(539.3,134),traced_ray(536.5,167))
plane_normal/=np.linalg.norm(plane_normal)
if plane_normal[0]<0: plane_normal=-plane_normal
seal_material=mat('Door glass run channel','18191b',.015,.51)
rail_paint=mat('Torch Red roof edge','c70f16',.05,.31)
rail_paint.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=.38
for material,color,alpha,ior in [(glazing,'13181a',.918,1.38),(side_glazing,'0e1011',.955,1.34),(hatch_glass,'1b2021',.92,1.42)]:
    surf=material.node_tree.nodes.get('Principled BSDF')
    rgb=tuple(lin(int(color[i:i+2],16)/255) for i in (0,2,4))
    surf.inputs['Base Color'].default_value=(*rgb,1.)
    surf.inputs['Alpha'].default_value=alpha
    surf.inputs['IOR'].default_value=ior
    if material==glazing:
        surf.inputs['Specular IOR Level'].default_value=.43
        surf.inputs['Metallic'].default_value=0
        surf.inputs['Roughness'].default_value=.19

# Trace the two sides of the painted strip independently in the registered
# factory plan. The removable panel cuts cross the curved strip obliquely.
roof_plan=upper_camera()
rail_trace=np.asarray([
    (274,112.8,118.0),(282,112.1,115.7),(290,111.8,115.5),
    (302,112.7,117.6),(314,114.3,119.7),(327,116.5,122.1),
    (340,119.1,124.8),(354,122.2,127.9),(368,125.0,130.9),
    (382,127.2,133.6),(395,128.5,135.2),(411,129.5,136.8),
    (429,130.0,138.3),(448,130.3,140.0),(469,130.1,142.0),
    (485,130.0,144.0),(499,130.0,145.8),(507,131.0,146.6),
],dtype=float)
def rail_lines(u):
    # Piecewise Hermite interpolation gives each traced edge a continuous tangent.
    x=rail_trace[:,0]
    i=int(np.clip(np.searchsorted(x,u)-1,0,len(x)-2))
    h=x[i+1]-x[i];t=np.clip((u-x[i])/h,0,1)
    values=rail_trace[:,1:];slopes=np.gradient(values,x,axis=0)
    # A small inboard adjustment reconciles the overhead trace with the
    # physical pillar width in the body-color front and side photographs.
    inboard=np.interp(u,[274,310,355,383,425,470,507],[0,3.4,3.4,2.2,1.4,.9,0])
    return (np.array([.39*inboard,inboard])+(2*t**3-3*t*t+1)*values[i]+(t**3-2*t*t+t)*h*slopes[i]
        +(-2*t**3+3*t*t)*values[i+1]+(t**3-t*t)*h*slopes[i+1])


# Match the meeting edge of the original fitted windshield and carbon roof
# to the same curve. In the visual hull the two sharp corners left a colored
# triangle between the panes. Reform their existing edges and the steel that
# shares those vertices, preserving the panel apertures when disassembled.
def reshape_cant_edge():
    center,rotation,(cx0,cy0,focal)=roof_plan
    def upper_uv(points):
        view=(points-center)@rotation.T
        return view[:,:2]*(focal/view[:,2:])+[cx0,cy0]
    trace_u=np.arange(273,484,.25)
    def edge_trace(labels,inner):
        ids=[panel_names.index(label) for label in labels]
        edges=shell_boundary(panel_faces[np.isin(panel_groups,ids)])
        edges=edges[np.all(shell_points[edges][:,:,1]>.1,axis=1)]
        a,b=upper_uv(shell_points)[edges].transpose(1,0,2)
        result=[]
        for u in trace_u:
            crossing=(a[:,0]<u)!=(b[:,0]<u)
            first,last=a[crossing],b[crossing]
            y=first[:,1]+(last[:,1]-first[:,1])*(u-first[:,0])/(last[:,0]-first[:,0])
            result.append((y.min() if inner else y.max()) if y.size else np.nan)
        values=np.asarray(result);valid=np.isfinite(values)
        return np.interp(trace_u,trace_u[valid],values[valid])
    current_inner=edge_trace(('Roof panel','Windshield'),True)
    current_outer=edge_trace(('Right side glass',),False)
    outer,inner=np.array([rail_lines(u) for u in trace_u]).T
    def smoothstep(t):
        t=np.clip(t,0,1);return t*t*(3-2*t)
    weight=smoothstep((trace_u-276)/23)*smoothstep((483-trace_u)/15)
    # Ahead of the mirror the quarter view shows the painted wing below the
    # A-pillar foot. Restrict the edge fit to the upper window opening.
    current_outer=np.minimum(current_outer,current_inner-2.0)
    inner=current_inner+(inner-current_inner)*weight
    outer=current_outer+(outer-current_outer)*weight*smoothstep((trace_u-307)/17)
    for name in ('Body surface','Windshield surface','Windshield applique',
                 'Roof panel surface','Roof panel applique','Roof panel folded edge',
                 'Left side glass surface','Left side glass applique',
                 'Right side glass surface','Right side glass applique'):
        obj=bpy.data.objects[name];data=obj.data
        xyz=np.empty(len(data.vertices)*3,np.float32);data.vertices.foreach_get('co',xyz)
        xyz=xyz.reshape(-1,3);world=xyz+np.asarray(obj.parent.location)
        canonical=world.copy();canonical[:,1]=np.abs(canonical[:,1]);uv=upper_uv(canonical)
        old_in=np.interp(uv[:,0],trace_u,current_inner)
        old_out=np.interp(uv[:,0],trace_u,current_outer)
        new_in=np.interp(uv[:,0],trace_u,inner)
        new_out=np.interp(uv[:,0],trace_u,outer)
        lateral=uv[:,1]
        across=np.clip((lateral-old_out)/(old_in-old_out),0,1)
        amount=(1-across)*(new_out-old_out)+across*(new_in-old_in)
        amount*=smoothstep(1-np.maximum(old_out-lateral,0)/24)
        amount*=smoothstep(1-np.maximum(lateral-old_in,0)/36)
        selected=(uv[:,0]>trace_u[0])&(uv[:,0]<trace_u[-1])&(world[:,2]>.73)&(np.abs(amount)>.0001)
        normals=None
        if name.endswith(' surface') and data.has_custom_normals:
            normals=np.zeros_like(xyz)
            for loop,n in zip(data.loops,data.corner_normals):
                normals[loop.vertex_index]=n.vector
        for i in np.flatnonzero(selected):
            u,v0=uv[i]
            # Apply the change between two surface hits so the glass seal and
            # the folded flange retain their depth relative to the skin.
            original=np.asarray(ray((u,v0),roof_plan,0))
            fitted=np.asarray(ray((u,v0+amount[i]),roof_plan,0))
            offset=fitted-original;offset[1]*=np.sign(world[i,1]);xyz[i]+=offset
        data.vertices.foreach_set('co',xyz.ravel());data.update()
        if normals is not None:data.normals_split_custom_set_from_vertices(normals.tolist())

reshape_cant_edge()

for side_sign,word in [(-1,'Left'),(1,'Right')]:
    door=doors[side_sign]
    normal=plane_normal.copy();normal[1]*=-side_sign
    point=eye6.copy();point[1]*=-side_sign
    # Bisect both the pane and its perimeter applique on the same world plane.
    for suffix in ['surface','applique']:
        original=bpy.data.objects[word+' side glass '+suffix]
        for front in (True,False):
            bm=bmesh.new();bm.from_mesh(original.data)
            bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),
               plane_co=Vector(point)-door.location,plane_no=Vector(normal),dist=.000001,
               clear_outer=front,clear_inner=not front)
            parent=door if front else body
            if not front:bmesh.ops.translate(bm,vec=door.location,verts=list(bm.verts))
            title=word+(' door drop glass ' if front else ' fixed quarter light ')+suffix
            data=bpy.data.meshes.new(title);bm.to_mesh(data);bm.free()
            for m in original.data.materials:data.materials.append(m)
            if suffix=='surface':
                ns=[]
                for vert in data.vertices:
                    vx,vy,vz=vert.co+(door.location if front else Vector((0,0,0)))
                    ns.append(tuple(Vector((.06*vx,side_sign,.57+.38*(vz-.9))).normalized()))
                data.normals_split_custom_set_from_vertices(ns)
            obj=bpy.data.objects.new(title,data);sc.collection.objects.link(obj);obj.parent=parent
        bpy.data.objects.remove(original,do_unlink=True)

    def mapped(u,v0,push):
        for dy in [0,.5,1,1.8,2.8,4.0]:
            try:
                point=np.asarray(ray((u,v0+dy),cam6,push))
                point[1]*=-side_sign
                return point
            except ValueError:continue
        raise ValueError('No roof rail surface at '+str((u,v0)))
    channel=[]
    for t in np.linspace(0,1,31):
        u=539.3-2.8*t;v0=134+33*t
        channel.append([mapped(u+du,v0,.0026+height) for du,height in [(-1.5,0),(-1,.001),(0,.0014),(1.2,0)]])
    grid_surface(word+' quarter window front seal',channel,seal_material,body)
    # Side-view rays become tangent to the pillar near the header. Cast from
    # above so every cross section stays on the same edge of the windshield.
    cuts=[('A-pillar',(306,306),(387.2,380.1),body),
          ('removable roof',(387.4,380.3),(470.2,471.6),roof),
          ('sail panel',(470.5,471.9),(499.8,503.5),body)]
    for title,start,end,parent in cuts:
        rows=[]
        for along in np.linspace(0,1,max(12,int((end[0]-start[0])/1.2))):
            row=[]
            for across in np.linspace(0,1,7):
                start_u=(1-across)*start[0]+across*start[1]
                end_u=(1-across)*end[0]+across*end[1]
                u=start_u+along*(end_u-start_u)
                outer,inner=rail_lines(u)
                v0=outer+(inner-outer)*across
                q=np.asarray(ray((u,v0),roof_plan,.0018+.0007*sin(pi*across)))
                q[1]=side_sign*abs(q[1])
                row.append(q)
            rows.append(row[::-1] if side_sign>0 else row)
        grid_surface(word+' '+title+' roof rail molding',rows,rail_paint,parent)
