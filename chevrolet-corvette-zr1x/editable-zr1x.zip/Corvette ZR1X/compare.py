from hull import *
from PIL import Image,ImageDraw,ImageFilter
from scipy.ndimage import distance_transform_edt
from pathlib import Path
import sys,hashlib
out=Path(sys.argv[1]);dest=out/'captures';dest.mkdir(exist_ok=True)
views=json.loads((out/'studio.json').read_text())['views'];inventory=json.loads((ROOT/'inventory.json').read_text());rev=hashlib.sha256((out/'zr1x.glb').read_bytes()).hexdigest();metrics=[]
def show(im):
 bg=Image.new('RGB',im.size,'#fafafa');bg.paste(im,mask=im.getchannel('A') if 'A'in im.mode else None);return bg
for j,view in enumerate(views):
 id=view['id'];rec=next(q for q in inventory if q['id']==id);im=Image.open(ROOT/rec['file']);actual=Image.open(ROOT/('renders/'+id+'.png'))
 row=dict(id=id,source=rec['original_url'],width=im.width,height=im.height,kind=rec['kind'])
 actual.save(dest/(id+'.webp'),quality=87,method=4)
 if j<30:
  m=mask(j)>0;g=np.array(actual)[:,:,3]>40
  # Outer silhouette only; keep the wing gap and glazing for pair inspection separately.
  def boundary(mask):
   cnt,_=cv.findContours(mask.astype('uint8'),cv.RETR_EXTERNAL,cv.CHAIN_APPROX_NONE);cnt=sorted(cnt,key=cv.contourArea,reverse=True)[0]
   a=np.zeros(mask.shape,'uint8');cv.drawContours(a,[cnt],-1,1,1);return a.astype(bool)
  e1,e2=boundary(m),boundary(g);err=np.r_[distance_transform_edt(~e1)[e2],distance_transform_edt(~e2)[e1]];xs=np.where(m)[1];span=int(xs.max()-xs.min()+1)
  row.update(overlap=round((m&g).sum()/(m|g).sum(),4),median_px=round(float(np.median(err)),1),p95_px=round(float(np.percentile(err,95)),1),span=span,p95_percent=round(100*np.percentile(err,95)/span,2))
  ol=np.zeros((*m.shape,4),'uint8');ol[cv.dilate(e2.astype('uint8'),np.ones((3,3),'uint8'))>0]=[0,155,187,255]
  Image.fromarray(ol).save(dest/(id+'-edge.png'),optimize=True)
 pair=Image.new('RGB',(840,500),'#fafafa')
 for k,xx in enumerate([im,actual]):
  corrected=show(xx);box=corrected.getbbox()
  if j<30:corrected=corrected.crop((0,126,1500,630))
  corrected.thumbnail((820,238));pair.paste(corrected,((840-corrected.width)//2,k*245))
 ImageDraw.Draw(pair).text((8,477),id,fill='black');pair.save(ROOT/('audit/pair-'+id+'.jpg'))
 metrics.append(row)
(ROOT/'metrics.json').write_text(json.dumps(dict(model_sha256=rev,frames=metrics),indent=2))
