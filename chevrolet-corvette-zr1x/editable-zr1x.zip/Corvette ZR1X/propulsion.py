"""External assemblies fitted to the GM TechLink ZR1X plan, engine and battery plates.

X is positive rearward. The plan's 372-pixel axle spacing corresponds to 2.723 m.
Housings are reconstructed envelopes. The internal gears and cells are omitted.
"""
cast = mat('Cast aluminum housing','a6a7a5',.62,.42)
gunmetal = mat('Machined gunmetal','606365',.58,.36)
boost_blue = mat('ZR1X blue intake finish','37769c',.47,.36)
heat = mat('Turbine shield','9c8b75',.65,.44)
hv = mat('Orange high-voltage insulation','e87525',.04,.50)
strap = mat('Battery retaining brackets','ae9162',.56,.46)
label_white = mat('Silver painted lettering','dedfdd',.27,.33)
drive = empty('Powertrain')

def subassembly(name, parent):
    obj = empty(name)
    obj.parent = parent
    return obj

engine = subassembly('LT7_engine',drive)
trans = subassembly('Rear_transaxle',drive)
edu = subassembly('Front_electric_drive',drive)
pack = subassembly('Tunnel_battery',drive)

def ellipse_case(name, stations, material, parent, axis='x', steps=40):
    # Each casting station supplies longitude, transverse/vertical center and radii.
    sections = []
    for axial,u0,z0,ru,rz in stations:
        ring=[]
        for j in range(steps):
            t=2*pi*j/steps
            u=u0+ru*cos(t); z=z0+rz*sin(t)
            ring.append((axial,u,z) if axis=='x' else (u,axial,z))
        sections.append(ring if axis=='x' else ring[::-1])
    obj=loft(name,sections,material,parent)
    for f0 in obj.data.polygons[:-2]: f0.use_smooth=True
    return obj

def sculpted_cover(name, stations, m, parent):
    # Crown and shoulders of each stamped rectangular cover.
    profile=[(-.73,-1),(.73,-1),(.98,-.63),(1,.02),(.91,.57),(.60,.93),(0,1),(-.60,.93),(-.91,.57),(-1,.02),(-.98,-.63)]
    sections=[[(x,y+h*u,z+v*d) for u,v in profile] for x,y,z,h,d in stations]
    obj=loft(name,sections,m,parent)
    for f0 in obj.data.polygons[:-2]: f0.use_smooth=True
    return obj

def smooth_pipe(name, points, radius, material, parent, resolution=6):
    data=bpy.data.curves.new(name,'CURVE');data.dimensions='3D';data.resolution_u=resolution
    data.bevel_depth=radius;data.bevel_resolution=3;data.use_fill_caps=True
    spline=data.splines.new('BEZIER');spline.bezier_points.add(len(points)-1)
    for p,pt in zip(spline.bezier_points,points):
        p.co=pt;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
    obj=bpy.data.objects.new(name,data);sc.collection.objects.link(obj);obj.parent=parent;data.materials.append(material)
    return obj

def section_ring(name,x,y,z,r,thick,material,parent,axis='x',width=.008):
    # Open annular profile. Solid end caps would cover the friction face and fittings.
    verts=[];faces=[];n=64
    stations=[(-width/2,r),(-width*.36,r+thick),(width*.36,r+thick),(width/2,r),(width/2,r-.00065),(-width/2,r-.00065)]
    for depth,rr in stations:
        for j in range(n):
            u=y+rr*cos(2*pi*j/n);v=z+rr*sin(2*pi*j/n)
            verts.append((x+depth,u,v) if axis=='x' else (u,x+depth,v))
    for i in range(len(stations)):
        k=(i+1)%len(stations)
        for j in range(n):faces.append((i*n+j,i*n+(j+1)%n,k*n+(j+1)%n,k*n+j))
    ob=mesh(name,verts,faces,material,parent)
    for f0 in ob.data.polygons:f0.use_smooth=True
    return ob

def bolt_array(name, centers, radius, thickness, material, parent, axis='x'):
    vertices=[];faces=[]
    for x,y,z in centers:
        first=len(vertices)
        for off,r in [(0,radius*.92),(thickness*.17,radius),(thickness*.84,radius),(thickness,radius*.83)]:
            for k in range(6):
                u=r*cos(k*pi/3);v=r*sin(k*pi/3)
                vertices.append({'x':(x+off,y+u,z+v),'y':(x+u,y+off,z+v),'z':(x+u,y+v,z+off)}[axis])
        for j in range(3):
            for k in range(6):
                a=first+6*j+k;b=first+6*j+(k+1)%6
                faces.append((a,b,b+6,a+6))
        faces.append(tuple(first+18+k for k in range(6)))
    return mesh(name,vertices,faces,material,parent)

def engine_mark(text, location, size, material, parent):
    cu=bpy.data.curves.new(text,'FONT');cu.body=text;cu.size=size;cu.align_x='CENTER';cu.align_y='CENTER'
    cu.materials.append(material);ob=bpy.data.objects.new('Intake plaque '+text,cu);sc.collection.objects.link(ob)
    ob.location=location;ob.rotation_euler.z=-pi/2;ob.parent=parent
    return ob

# Separate bank castings sit in a V over the crankcase and dry sump. The top
# cover and large charge hoses follow the blue intake in GM's isolated LT7 image.
block=subassembly('Crankcase_and_sump',engine)
sculpted_cover('Dry sump and crankcase',[(.515,0,.433,.151,.135),(.55,0,.433,.195,.14),
   (.72,0,.43,.208,.145),(1.10,0,.43,.213,.141),(1.19,0,.428,.185,.14)],cast,block)
sculpted_cover('Sump pan lip',[(.53,0,.288,.137,.015),(.57,0,.286,.18,.022),
    (1.10,0,.286,.182,.022),(1.16,0,.29,.151,.016)],gunmetal,block)
for side in (-1,1):
    suff='L' if side<0 else 'R'
    bank=subassembly('Cylinder_bank_'+suff,engine)
    banksec=[]
    for xx,width in [(.54,.94),(.58,1),(.70,1),(1.09,1),(1.145,.96)]:
        banksec.append([(xx,side*yy*width,zz) for yy,zz in
                [(.06,.39),(.14,.355),(.333,.539),(.349,.612),(.253,.682),(.124,.60),(.065,.48)]])
    loft('Canted cylinder bank and head',banksec,cast,bank)
    cover=sculpted_cover('DOHC cam cover',[(.548,side*.245,.627,.091,.045),(.575,side*.245,.643,.104,.054),
              (1.097,side*.245,.643,.104,.054),(1.14,side*.245,.627,.087,.043)],dark,bank)
    for j in range(4):
        xx=.624+j*.131
        obj=roundbox('Ignition coil', (xx,side*.251,.702),(.069,.071,.033),gunmetal,bank,.009)
        smooth_pipe('Coil harness branch',[(xx,side*.254,.706),(xx+.023,side*.299,.715),
                    (xx+.035,side*.326,.684),(xx+.046,side*.33,.655)],.0055,dark,bank)
    bolt_array('Valve-cover fasteners',[(x,side*y,.675) for x in [.576,.72,.85,.98,1.104] for y in [.174,.31]],.006,.008,lip,bank,'z')
    turbo=subassembly('Maniturbo_'+suff,engine)
    center=(.90,side*.38,.496)
    # A spiral volute varies in tube radius about the impeller axis; its outlet
    # merges tangentially with the charge pipe. The neighboring can is the heat shield.
    sections=[]
    for angle in np.linspace(-.25*pi,1.66*pi,57):
        phase=(angle+.25*pi)/(1.91*pi)
        center_radius=.066+.018*phase
        rr=.014+.033*phase
        sections.append([(center[0]+(center_radius+rr*cos(b))*cos(angle),
                          center[1]+side*rr*sin(b),center[2]+(center_radius+rr*cos(b))*sin(angle))
                          for b in np.linspace(0,2*pi,24,endpoint=False)])
    vol=loft('Turbocharger compressor volute',sections,cast,turbo)
    for f0 in vol.data.polygons:f0.use_smooth=True
    ellipse_case('Turbine housing and heat shield',[(.96,side*.378,.496,.080,.076),(.99,side*.381,.494,.092,.085),
                 (1.07,side*.384,.495,.095,.09),(1.105,side*.385,.492,.074,.072)],heat,turbo)
    for xx in (1.001,1.079): section_ring('Shield clamp',xx,side*.384,.496,.086,.003,gunmetal,turbo)
    smooth_pipe('Compressor outlet hose',[(.865,side*.409,.544),(.802,side*.40,.605),(.764,side*.346,.696),
                (.796,side*.245,.742),(.814,side*.113,.752)],.038,rubber,turbo)
    # The larger intake curves around the upper rear of each bank on the GM plate.
    smooth_pipe('Turbo inlet duct',[(1.158,side*.213,.571),(1.103,side*.306,.592),
                (1.005,side*.399,.62),(.917,side*.462,.608),(.895,side*.484,.547),
                (.901,side*.448,.499)],.045,dark,turbo)
    for yy in (.133,.189):
        section_ring('Charge hose band',side*yy,.814,.75,.038,.0024,lip,turbo,axis='y')
intake=subassembly('Intake_and_charge_coolers',engine)
# Two blue raised rails flank the perforated spine visible in Chevrolet detail 13.
# Profile knots also supply the changing height for hardware fitted to its crown.
stations=[(.545,.070,.728),(.578,.124,.782),(.653,.145,.817),(.818,.146,.823),
          (1.011,.140,.809),(1.086,.127,.791),(1.111,.104,.773)]
gx,gw,gz=np.array(stations).T
def crown(xx):return float(np.interp(xx,gx,gz))
for side in (-1,1):
    sections=[]
    profile=[(.286,0),(.29,.015),(.37,.024),(.60,.030),(.78,.028),(.93,.018),(1.0,-.004),
             (.99,-.038),(.85,-.064),(.44,-.066),(.26,-.047)]
    for xx,hw,ztop in stations:
        sections.append([(xx,side*hw*yy,ztop+zz) for yy,zz in profile])
    rail=loft('Blue cast plenum shoulder',sections,boost_blue,intake)
    for poly in rail.data.polygons[:-2]:poly.use_smooth=True
sculpted_cover('Charge air plenum carrier',[(.553,0,.735,.068,.016),(.581,0,.752,.113,.037),
    (.667,0,.766,.135,.040),(.86,0,.765,.135,.043),(1.04,0,.748,.125,.038),
    (1.096,0,.734,.102,.032),(1.109,0,.729,.087,.024)],dark,intake)
# A repeatable pebbled cobalt finish sits on the two powder-coated castings.
rng=np.random.default_rng(81)
samples=128
grain=np.clip(rng.normal(.0,.28,(samples,samples)),-.64,.82)
coat=boost_blue.node_tree
bs=coat.nodes.get('Principled BSDF')
texels=np.empty((samples,samples,4),'f')
texels[:,:,:3]=np.clip(np.array([.15,.37,.51])*(1+grain[:,:,None]),0,1)
texels[:,:,3]=1
texture=bpy.data.images.new('Cobalt plenum powder coat',width=samples,height=samples,alpha=False)
texture.colorspace_settings.name='sRGB';texture.pixels.foreach_set(texels.ravel());texture.pack()
sample=coat.nodes.new('ShaderNodeTexImage');sample.image=texture
coat.links.new(sample.outputs['Color'],bs.inputs['Base Color'])
bs.inputs['Roughness'].default_value=.43
for part in intake.children:
    if part.type!='MESH' or not part.name.startswith('Blue cast plenum shoulder'):continue
    data=part.data;uv=data.uv_layers.new(name='Powder coat')
    for poly in data.polygons:
        axis=max(range(3),key=lambda axis:abs(poly.normal[axis]))
        proj=[(1,2),(0,2),(0,1)][axis]
        for k in poly.loop_indices:
            co=data.vertices[data.loops[k].vertex_index].co
            uv.data[k].uv=(co[proj[0]]/.06,co[proj[1]]/.06)
sculpted_cover('Intake center trim',[(x,0,z+.008,w*.337,.009) for x,w,z in stations],carbon,intake)
screen=mat('Airbox perforation shadow','191b1c',.1,.60)
bright=mat('Polished plenum fasteners','d0d2d4',.65,.22)
plate=mat('Satin builder plaque','b6c1c7',.45,.27)
vv=[];ff=[]
for col in range(6):
    for row in range(31):
        xx=.602+row*.0105+(col%2)*.00525
        yy=(col-2.5)*.0092
        start=len(vv)
        for j in range(6):
            px=xx+.0056*cos(pi*j/3);py=yy+.0056*sin(pi*j/3)
            vv.append((px,py,crown(px)+.0176))
        ff.append(tuple(start+j for j in range(6)))
mesh('Perforated plenum center insert',vv,ff,screen,intake)
for xx in (.617,.715,.816,.916):
    for side in (-1,1):
        ys=[side*.035,side*.020,0]
        tri=[(xx-.020,ys[0]),(xx+.005,ys[0]),(xx+.036,ys[2]),(xx+.020,ys[2])]
        verts=[(x,y,crown(x)+h) for h in (.019,.025) for x,y in tri]
        mesh('Plenum bridge',verts,[(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)],gunmetal,intake)
    bolt_array('Plenum bridge cap screws',[(xx,side*.030,crown(xx)+.026) for side in (-1,1)],.007,.0035,bright,intake,axis='z')
xx=1.049; tilt=-math.atan((crown(xx+.002)-crown(xx-.002))/.004)
roundbox('Plenum builder identification plaque',(xx,0,crown(xx)+.021),(.075,.067,.004),plate,intake,.002,ry=tilt)
roundbox('Builder plaque inscription field',(xx+.008,0,crown(xx+.008)+.025),(.044,.058,.003),dark,intake,.001,ry=tilt)
for content,xloc,size,material in [('CORVETTE',xx-.021,.0068,dark),('LT7',xx+.005,.013,label_white)]:
    mark=engine_mark(content,(xloc,0,crown(xloc)+.029),size,material,intake);mark.rotation_euler.y=tilt
for side,m in [(-1,label_white),(1,red)]:
    xy=[(.956,0),(.921,side*.048),(.941,side*.044),(.972,0)]
    mesh('Plenum crossed flag',[(x,y,crown(x)+.032) for x,y in xy],[(0,1,2,3)],m,intake)
ellipse_case('Flywheel flange',[(1.142,0,.448,.14,.14),(1.159,0,.448,.166,.166),(1.193,0,.448,.162,.162)],gunmetal,block)
bolt_array('Flywheel fasteners',[(1.193,.13*cos(t),.448+.13*sin(t)) for t in np.linspace(0,2*pi,10,endpoint=False)],.008,.007,lip,block)
# Rear DCT: wide bellhousing at the block, tapering ribbed case behind the rear outputs.
case_stations=[(1.185,0,.445,.174,.175),(1.209,0,.441,.195,.193),(1.285,0,.415,.194,.183),
 (1.351,0,.400,.218,.171),(1.46,0,.396,.196,.160),(1.555,0,.402,.168,.159),
 (1.703,0,.408,.153,.148),(1.79,0,.410,.145,.13),(1.837,0,.41,.111,.099),(1.934,0,.409,.079,.074)]
ellipse_case('Dual clutch transaxle main casting',case_stations,cast,trans)
for xx,yy,zz,hw,ht in case_stations[1:-1]:
    ellipse_case('Casting rib and casing seam',[(xx-.005,yy,zz,hw+.002,ht+.002),
               (xx-.002,yy,zz,hw+.009,ht+.009),(xx+.004,yy,zz,hw+.009,ht+.009),(xx+.007,yy,zz,hw,ht)],gunmetal,trans)
for t in np.linspace(0,2*pi,10,endpoint=False):
    path('Transaxle longitudinal web',[(xx,hw*cos(t),zz+ht*sin(t)) for xx,yy,zz,hw,ht in case_stations[2:-1]],.0055,cast,trans)
roundbox('Transmission oil pan',(1.543,0,.269),(.372,.251,.058),dark,trans,.026)
bolt_array('Bellhousing flange bolts',[(1.213,.183*cos(t),.441+.183*sin(t)) for t in np.linspace(0,2*pi,12,endpoint=False)],.008,.009,lip,trans)
# Compact transverse motor and reduction casting share the front axle.
ellipse_case('Traction motor housing',[(-.22,-1.359,.365,.104,.11),(-.198,-1.359,.365,.137,.138),
  (-.162,-1.359,.365,.142,.143),(-.014,-1.359,.365,.139,.140),(.028,-1.359,.365,.122,.12)],cast,edu,axis='y')
ellipse_case('Front final drive carrier',[(.010,-1.35,.344,.13,.12),(.04,-1.35,.344,.151,.132),
   (.112,-1.335,.347,.149,.135),(.161,-1.348,.352,.127,.12),(.208,-1.355,.346,.086,.092)],gunmetal,edu,axis='y')
for yy in (-.178,-.151,-.121,-.092,-.063,-.034):
    section_ring('Motor jacket rib',yy,-1.359,.365,.141,.004,cast,edu,axis='y')
section_ring('Front carrier bolted flange',.142,-1.347,.347,.125,.007,cast,edu,axis='y',width=.014)
bolt_array('Motor end-cover bolts',[(-1.359+.117*cos(t),-.206,.365+.117*sin(t)) for t in np.linspace(0,2*pi,10,endpoint=False)],.006,-.008,gunmetal,edu,axis='y')
for i in range(3):
    y0=-.052+i*.038
    roundbox('Three-phase terminal',(-1.203,y0,.38),(.043,.032,.045),hv,edu,.008)
    smooth_pipe('Phase lead to central pack',[(-1.198,y0,.38),(-1.137,y0,.365),(-1.066,y0,.304),(-.952,y0,.291)],.010,hv,edu)
# Axle shafts and convoluted CV boots connect both power units to their wheel hubs.
for axle,x,zc,parent in [('Front',-1.3615,.3365,edu),('Rear',1.3615,.35295,trans)]:
    for side in (-1,1):
        joint=subassembly(axle+'_halfshaft_'+('L' if side<0 else 'R'),parent)
        def shaft(name,sections,m):
            return ellipse_case(name,[(side*y,x,zc,r,r) for y,r in sections],m,joint,axis='y',steps=32)
        shaft('Output flange',[(.19,.062),(.209,.066),(.238,.055),(.252,.039)],cast)
        shaft('Axle shaft',[(.235,.018),(.74,.018),(.764,.025),(.819,.021)],gunmetal)
        for start in (.252,.679):
            prof=[(start,.036)]
            for n in range(5):
                rr=.039-.002*n if start<.4 else .032+.002*n
                prof.extend([(start+.013*n+.003,rr-.006),(start+.013*n+.007,rr+.006),
                             (start+.013*n+.010,rr+.006)])
            prof.append((start+.073,.026));shaft('CV joint bellows',prof,rubber)
        shaft('Hub spline and shoulder',[(.752,.034),(.77,.044),(.792,.044),(.807,.026),(.84,.025)],cast)
# Four bracketed sections and forward electronics cover follow GM's pack cutaway.
tray=roundbox('Tunnel battery base tray',(-.379,0,.188),(1.165,.234,.024),gunmetal,pack,.012)
roundbox('Battery tray gasket',(-.379,0,.203),(1.153,.222,.011),hv,pack,.006)
roundbox('Pack electronics casing',(-.756,0,.278),(.369,.187,.153),cast,pack,.018)
roundbox('Electronics top cover',(-.756,0,.360),(.368,.195,.037),dark,pack,.011)
for k in range(4):
    xx=-.475+.18*k
    roundbox('Battery module outer case',(xx,0,.282),(.171,.191,.153),dark,pack,.008)
    for s0 in (-1,1):
        roundbox('Module side panel',(xx,s0*.098,.283),(.139,.010,.112),gunmetal,pack,.006)
    path('Module retaining strap',[(xx-.065,-.105,.207),(xx-.065,-.102,.358),
       (xx-.064,-.095,.365),(xx-.064,.095,.365),(xx-.064,.102,.357),(xx-.064,.105,.207)],.0057,strap,pack)
    roundbox('Battery top connector',(xx+.012,0,.364),(.084,.110,.018),gunmetal,pack,.006)
for s0 in (-1,1):
    smooth_pipe('Battery insulated interconnect',[(-.84,s0*.071,.369),(-.64,s0*.072,.374),
       (-.51,s0*.068,.366),(-.39,s0*.065,.372),(.149,s0*.065,.369)],.0048,hv,pack)
bolt_array('Battery tray edge fasteners',[(xx,s*.108,.204) for xx in np.linspace(-.924,.176,11) for s in (-1,1)],.0045,.003,lip,pack,axis='z')

# The rear-facing LT7 photograph resolves the intake runners below the cover,
# rear cover bolts, two dark turbine outlets and bright clutch mounting face.
cast_edge=mat('Machined casting edges','95999d',.76,.34)
shield_mat=mat('Stainless heat shield','bdb3a2',.76,.37)
plug_blue=mat('Pack connector key','426a85',.10,.44)
plug_red=mat('Connector latch','ac3534',.04,.45)
runner=subassembly('Intake_runners_and_fuel_rails',engine)
sculpted_cover('Valley intake body',[(.566,0,.668,.079,.071),(.605,0,.674,.112,.081),
       (.78,0,.674,.123,.092),(1.049,0,.664,.112,.087),(1.10,0,.653,.092,.073)],gunmetal,runner)
for s0 in (-1,1):
    side_name='L' if s0<0 else 'R'
    bank=bpy.data.objects['Cylinder_bank_'+side_name]
    turbo=bpy.data.objects['Maniturbo_'+side_name]
    for j in range(4):
        xx=.611+.131*j
        smooth_pipe('Cast intake runner',[(xx-.015,s0*.093,.712),(xx,s0*.129,.692),
                   (xx+.007,s0*.167,.662),(xx+.013,s0*.198,.636)],.029,cast,runner)
        smooth_pipe('Injector feed branch',[(xx,s0*.156,.704),(xx,s0*.174,.702),
                   (xx+.01,s0*.18,.681)],.007,metal,runner)
        roundbox('Coil connector locking tab',(xx+.024,s0*.274,.708),(.022,.024,.017),gunmetal,bank,.004)
        roundbox('Connector seal',(xx+.032,s0*.280,.71),(.007,.016,.008),heat,bank,.001)
        smooth_pipe('Exhaust collector branch',[(xx,s0*.31,.523),(xx+.012,s0*.351,.5),
                  (.91+.035*j,s0*.373,.474)],.025,heat,turbo)
    smooth_pipe('Bank injection rail',[(.577,s0*.157,.705),(.776,s0*.155,.707),(1.084,s0*.153,.705)],.0105,cast_edge,runner)
    smooth_pipe('Cam harness loom',[(.555,s0*.320,.66),(.66,s0*.333,.66),(.91,s0*.337,.658),
                   (1.039,s0*.332,.651),(1.13,s0*.309,.608),(1.146,s0*.267,.541)],.009,rubber,bank)
    # Bright longitudinal ridges on the cam/cylinder-head mating flange.
    for off in [-.021,.019]:
        path('Cam cover flange',[(xx,s0*(yy+off),zz) for xx,yy,zz in
               [(.555,.275,.65),(.59,.29,.672),(1.09,.29,.672),(1.14,.27,.648)]],.0054,cast_edge,bank)
    for j in range(6):
        xx=.6+.095*j
        path('Cylinder head casting web',[(xx,s0*.157,.406),(xx+.023,s0*.248,.495),
                   (xx+.029,s0*.315,.55)],.0085,cast,bank)
    # Cast turbine exit is a hollow-looking bore bounded by its mounting flange.
    ellipse_case('Turbine outlet flange',[(1.101,s0*.385,.492,.076,.073),
         (1.112,s0*.385,.492,.08,.077),(1.119,s0*.385,.492,.079,.076)],shield_mat,turbo)
    ellipse_case('Turbine outlet bore',[(1.1195,s0*.385,.492,.055,.053),
         (1.1205,s0*.385,.492,.055,.053)],holes,turbo)
    bolt_array('Outlet flange nuts',[(1.12,s0*.385+.066*cos(t),.492+.062*sin(t))
                for t in np.linspace(.15,2*pi+.15,5,endpoint=False)],.006,.005,cast_edge,turbo)
    # Port shields use pressed seams and a bright rolled outer edge.
    for xx in (.981,1.02,1.061):
        path('Formed heat shield ridge',[(xx+.003*sin(t*2),s0*(.383+.093*cos(t)),.493+.086*sin(t))
            for t in np.linspace(-.22,2.65,22)],.0046,shield_mat,turbo)
    # Visible engine bank end plate on either side of the flywheel.
    center_y=s0*.245
    plate=ellipse_case('Cam end cover',[(1.130,center_y,.625,.107,.064),
                     (1.142,center_y,.625,.106,.062),(1.148,center_y,.625,.092,.056)],gunmetal,bank)
    bolt_array('Cam cover end bolts',[(1.145,center_y+.092*cos(t),.625+.049*sin(t))
                     for t in np.linspace(0,2*pi,6,endpoint=False)],.0065,.007,cast_edge,bank)
    # Fitted cam-end leads and harness clips cross the back of the block.
    smooth_pipe('Rear bank breather hose',[(1.103,s0*.269,.656),(1.147,s0*.236,.675),
                     (1.158,s0*.163,.637),(1.153,s0*.141,.595)],.009,rubber,bank)
# Cast engine backplate behind the machined flywheel and its circular fastener pattern.
for s0 in (-1,1):
    for j in range(3):
        path('Bell flange buttress',[(1.14,s0*(.074+.045*j),.43),
                 (1.164,s0*(.108+.053*j),.49),(1.141,s0*(.143+.044*j),.54+.024*j)],.012,cast,block)
ellipse_case('Flywheel machined friction annulus',[(1.194,0,.448,.15,.15),(1.198,0,.448,.148,.148)],cast_edge,block)
ellipse_case('Flywheel center recess',[(1.1986,0,.448,.086,.086),(1.199,0,.448,.086,.086)],dark,block)
ellipse_case('Crank drive flange',[(1.199,0,.448,.061,.061),(1.203,0,.448,.060,.060)],cast,block)
bolt_array('Crank flange bolt circle',[(1.203,.044*cos(t),.448+.044*sin(t))
                  for t in np.linspace(0,2*pi,8,endpoint=False)],.006,.004,gunmetal,block)
for radius in [.106,.136,.145]:
    section_ring('Flywheel facing groove',1.198,0,.448,radius,.001,gunmetal,block,width=.0015)
ring_gear=mat('LT7 ring gear steel','7d8286',.50,.32)
outline=[]
for tooth in range(108):
    for phase,rr in [(0,.158),(.21,.163),(.64,.163),(.87,.158)]:
        t=2*pi*(tooth+phase)/108
        outline.append((rr*cos(t),.448+rr*sin(t)))
teeth=[];faces=[];n=len(outline)
for ax,inner in [(1.179,False),(1.195,False),(1.195,True),(1.179,True)]:
    for yy,zz in outline:
        if inner:
            ratio=.150/math.hypot(yy,zz-.448);yy*=ratio;zz=.448+(zz-.448)*ratio
        teeth.append((ax,yy,zz))
for i in range(4):
    for j in range(n):faces.append((i*n+j,i*n+(j+1)%n,((i+1)%4)*n+(j+1)%n,((i+1)%4)*n+j))
mesh('Starter ring gear',teeth,faces,ring_gear,block)
for side in (-1,1):
    tur=bpy.data.objects['Maniturbo_'+('L' if side<0 else 'R')]
    for yy in [.148,.171]:
        section_ring('Charge hose cuff bead',side*yy,.814,.752,.039,.0022,rubber,tur,axis='y',width=.004)
    for j in range(5):
        tx=.944+.013*j
        u=(tx-.944)/.052
        for phase in (0,.23):
            tt=(u+phase)*pi
            smooth_pipe('Turbine shield pressing',[(tx-.012+.004*cos(tt),side*(.412+.049*v),.501+.071*(1-v*v)**.5) for v in np.linspace(-.7,.8,6)],.0032,shield_mat,tur)
    section_ring('Turbine V-band coupling',1.074,side*.384,.495,.09,.0038,bright,tur,width=.010)
    roundbox('V-band clamp adjuster',(1.074,side*.438,.560),(.016,.038,.012),bright,tur,.003)
# Front drive face: a lobed accessory cover with crank and idler pulleys.
ellipse_case('Timing cover lower boss',[(.475,0,.436,.116,.124),(.507,0,.437,.137,.149),(.542,0,.445,.143,.16)],cast,block)
for y0,z0,r in [(0,.425,.073),(-.139,.547,.041),(.153,.547,.052)]:
    ellipse_case('Accessory belt pulley',[(.451,y0,z0,r*.88,r*.88),(.455,y0,z0,r,r),(.482,y0,z0,r,r)],gunmetal,block)
    ellipse_case('Pulley hub',[(.444,y0,z0,r*.33,r*.33),(.454,y0,z0,r*.35,r*.35)],cast,block)
    bolt_array('Pulley retaining bolt',[(.443,y0,z0)],.010,-.005,gunmetal,block)
path('Accessory belt',[(.468,.153+.055*cos(t),.547+.055*sin(t)) for t in np.linspace(-.46,.54*pi,8)]
    +[(.468,-.139+.044*cos(t),.547+.044*sin(t)) for t in np.linspace(.5*pi,1.24*pi,10)]
    +[(.468,.077*cos(t),.425+.077*sin(t)) for t in np.linspace(1.23*pi,1.80*pi,9)],.008,rubber,block,True)
# The DCT main casting is asymmetric. Its side bosses link the low input shaft,
# countershaft bores, hydraulic cover and final drive near the axle centerline.
for s0 in (-1,1):
    centers=[(1.231,.119,.433,.073,.077),(1.31,.143,.423,.082,.083),
             (1.442,.134,.412,.084,.08),(1.58,.109,.402,.071,.07),
             (1.727,.096,.412,.06,.064),(1.801,.09,.414,.043,.046)]
    ellipse_case('Countershaft casting lobe',[(xx,s0*y,zz,hw,hh) for xx,y,zz,hw,hh in centers],cast,trans)
    for xx in (1.32,1.39,1.48,1.56,1.64):
        yy=np.interp(xx,[1.30,1.44,1.7],[.209,.203,.161])
        for dz in (-1,1):
            path('Triangulated case web',[(xx-.032,s0*(yy-.033),.401+.08*dz),
                     (xx+.024,s0*(yy+.001),.412),(xx+.062,s0*(yy-.046),.413+.078*dz)],.0068,cast_edge,trans)
    for xx,zz in [(1.27,.412),(1.34,.51),(1.49,.493),(1.62,.472),(1.73,.453)]:
        yy=s0*np.interp(xx,[1.27,1.46,1.73],[.184,.182,.134])
        bolt_array('Transaxle case bolt',[(xx,yy,zz)],.008,s0*.008,lip,trans,axis='y')
roundbox('Mechatronic cover',(1.465,0,.559),(.237,.20,.038),gunmetal,trans,.016)
for j in range(10):
    roundbox('Hydraulic cover fin',(1.37+.021*j,0,.584),(.006,.159,.013),cast_edge,trans,.002)
smooth_pipe('External oil line',[(1.30,-.166,.480),(1.315,-.208,.513),(1.462,-.218,.512),
                 (1.577,-.176,.501),(1.59,-.15,.467)],.0068,gunmetal,trans)
ellipse_case('Reduction cover stepped boss',[(.151,-1.396,.377,.076,.076),(.174,-1.396,.377,.078,.076),
                 (.196,-1.396,.377,.067,.066)],cast,edu,axis='y')
for t in np.linspace(0,2*pi,8,endpoint=False):
    path('Reduction cover radial web',[(-1.396+.069*cos(t),.186,.377+.061*sin(t)),
             (-1.351+.116*cos(t),.160,.35+.106*sin(t))],.0045,cast_edge,edu)
for xx,yy,zz in [(-1.42,-.136,.462),(-1.283,-.131,.455),(-1.436,.106,.431)]:
    roundbox('Drive unit mounting ear',(xx,yy,zz),(.055,.041,.046),cast,edu,.009)
    bolt_array('Mounting eye sleeve',[(xx,yy,zz+.021)],.014,.004,gunmetal,edu,axis='z')
roundbox('Phase terminal cap',(-1.225,-.01,.406),(.09,.13,.057),dark,edu,.014)
bolt_array('Terminal cover screws',[(-1.225+dx,-.01+dy,.436) for dx in [-.030,.030] for dy in [-.046,.046]],.005,.004,lip,edu,axis='z')
# The GM battery cutaway exposes a louvered cover, metal front face and stepped
# brackets over each of the four sections. The ribs remain readable at close range.
for j in range(18):
    xx=-.915+.016*j
    for side0 in (-1,1):
        roundbox('Electronics lid vent',(xx,side0*.044,.380),(.0085,.051,.0028),holes,pack,.001)
for j in range(4):
    xx=-.475+.18*j
    for s0 in (-1,1):
        roundbox('Retaining strap foot',(xx-.061,s0*.106,.222),(.043,.012,.028),strap,pack,.004)
        roundbox('Module side cover rail',(xx,s0*.104,.279),(.115,.005,.010),dark,pack,.002)
        for dx in (-.052,.052):
            bolt_array('Side lid screw',[(xx+dx,s0*.103,.313),(xx+dx,s0*.103,.249)],.004,s0*.0035,lip,pack,axis='y')
    roundbox('Module terminal connector',(xx,0,.376),(.05,.052,.020),dark,pack,.004)
    roundbox('Terminal locking bar',(xx+.006,.010,.388),(.012,.027,.006),strap,pack,.0015)
endx=-.944
for y0,z0,m in [(-.043,.31,plug_red),(.046,.285,plug_blue)]:
    roundbox('Battery keyed connector',(endx,y0,z0),(.021,.063,.044),m,pack,.008)
    roundbox('Connector socket',(endx-.011,y0,z0),(.003,.044,.026),holes,pack,.004)
bolt_array('Battery end plate fasteners',[(endx-.002,y,z) for y in [-.076,.076] for z in [.225,.343]],.006,-.004,lip,pack)
