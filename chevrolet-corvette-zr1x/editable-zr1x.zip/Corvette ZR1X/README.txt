2027 Chevrolet Corvette ZR1X 3LZ Coupe — Torch Red (GKZ)
US-market coupe with the carbon aero high wing. The interior uses Jet Black (HTE).

EDIT OR EXPORT
Open ZR1X.blend in Blender 5.2.1. Distances are meters. Positive Blender X runs toward the tail, positive Z runs up, and the driver sits at negative Y. Body, roof, doors, wing, cockpit, powertrain and wheels are separately editable. The exported GLB uses the standard glTF Y-up convention.

Rebuild the GLB directly from the included final section mesh, display graphics and procedural assemblies:
blender -b -t 4 -P build.py -- ./export

REPRODUCE THE EXTERIOR FIT
The saved calibration and final fitted mesh let you edit the source without fetching any images. The reconstruction scripts require Python 3, numpy, scipy, opencv-python, Pillow, beautifulsoup4, requests, scikit-image, trimesh, fast-simplification and moderngl with an EGL implementation. Download Chevrolet's original reference files locally with acquire.py. Its manifest preserves native image dimensions and source URLs.

Run calibrate.py and refine.py to fit the exterior rig, then stereo.py, hull.py, surfaces.py and normals.py. planview.py fits the overhead comparison and refine_materials.py outputs finalskin.npz. The supplied plan camera was fitted before the final surface revisions and frozen to preserve registration. instruments.py recreates the three original dashboard illustrations. build.py uses finalskin.npz, smoothed_normals.npy, rig.json and plan_camera.json. The forward 90-degree cubemap camera is fitted to the steering-rim extents. The captured screen corners locate the instrument fascia. steering.py, dash.py and cabin_trim.py build the wheel, instruments, selector bridge, carpeted tunnel and door controls. Powertrain housings are schematic. Gear internals and factory body tooling data were unavailable.

COMPARE
studio.json holds 30 full-resolution manufacturer turntable cameras, the overhead coupe press camera and the fitted forward cabin camera. comparison.json records results for the published GLB. inventory.json indexes the Chevrolet sources. The published viewer exports one transparent native-size GLB render per saved view. Exterior errors are symmetric nearest distances between outer silhouettes; the contours omit cast shadows. They measure the images used for reconstruction. The overhead image shows a low-wing configuration. Cabin fit uses the Jet Black panorama and the editable controls retain approximate depths and materials.
