2027 Chevrolet Corvette ZR1X 3LZ Coupe
Torch Red (GKZ), Carbon Fiber Aero Package with high wing, Jet Black GT2 cabin.

EDIT AND EXPORT
Open ZR1X.blend in Blender 5.2.1. Distances are meters. Positive Blender X runs toward the tail, positive Z runs up, and the driver sits at negative Y. Door hinges and wheel centers are the assembly pivots. The glass, roof, hood, hatch, fascias, floor, wheels, brakes, suspension and propulsion components can be edited separately.

To regenerate the native master and Draco-compressed glTF export, run the following in this directory.

blender -b -t 4 --python-exit-code 1 -P build.py -- ./export

The command writes ZR1X.blend in this source directory and export/zr1x.glb in the output directory. Blender can create a .blend1 backup of an existing master. The build uses the included fitted mesh and textures. Blender generates and packs the seat leather and coated carbon-fiber maps. No network connection is needed to build or edit the model. To check a rebuild, put the published zr1x.glb in a separate directory and run the following. The check compares the scene hierarchy, mesh names and primitive counts, material assignments, vertex channel bounds and embedded image names.

python verify_archive.py /path/to/published-model --rebuilt ./export/zr1x.glb --model-only

MODEL SOURCES
fit_panels.py cuts the body panels and fits the hood, roof, glazing and the section through the side inlet. bodywork.py builds panel meshes, openings and inner returns. exterior_details.py places the aerodynamic components. front_optics.py and rear_optics.py shape the lamp recesses, reflectors, guides and covers. mirrors.py fits the mirror envelope from multiple camera angles. glazing.py separates the moving door glass from each fixed rear quarter light. badge-profiles.json supplies the traced model and rear lettering. rolling_gear.py reconstructs the wheel pattern from Chevrolet’s left profile. propulsion.py uses the GM TechLink engine photograph, driveline plan and battery cutaway. suspension.py represents the short/long-arm layout on the wheel datums. The holes in the brake friction ring run through both faces. The forms of castings, suspension mountings and internal plumbing are approximate. The master represents the exposed vehicle assemblies. Gearbox internals, individual battery cells and fasteners hidden inside closed assemblies have limited source coverage.

seats.py, cabin_structure.py, cabin_trim.py, steering.py and dash.py construct the GT2 seats, tub, instrument carrier, controls and door trim. The instrument graphics are original illustrations. The forward camera is registered to the Jet Black cabin panorama.

REFERENCE AND FIT
inventory.json records source URLs, dimensions and file hashes. Run python acquire.py to download the reference set into refs and validate each image against its recorded SHA-256. Create an audit directory for the diagnostic plots before running the fitting scripts. Offline rebuilds use the supplied fitted panels directly. To repeat the exterior fit, the Python environment needs NumPy, SciPy, OpenCV, Pillow, Beautiful Soup, Requests, scikit-image, trimesh, fast-simplification, Shapely and ModernGL with EGL. Run calibrate.py, refine.py, stereo.py, hull.py, surfaces.py, normals.py, planview.py and refine_materials.py, then fit_panels.py. badge_profiles.py regenerates the lettering outlines.

studio.json contains 30 manufacturer turntable cameras, the overhead Blade Silver coupe, the forward cabin and the independent Nürburgring photograph of a yellow high-wing coupe. assembly.js defines the 30 exploded-view assemblies, individual component selection, and studio lighting used by the website. The overhead car uses low rear aero, and the track car has different wheels and paint. comparison.json identifies the published GLB by SHA-256. Its silhouette metrics compare the 30 outer contours at native resolution. Lighting, details inside the contours and unseen surfaces require separate visual checks.
