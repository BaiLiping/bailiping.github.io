"""Generate a local feature tracing for each indexed Chevrolet reference."""
import json,sys,re
from pathlib import Path
from PIL import Image
import cv2 as cv,numpy as np
from concurrent.futures import ThreadPoolExecutor
root=Path(__file__).resolve().parent;dest=Path(sys.argv[1]);cv.setNumThreads(1)
records=json.loads((root/'inventory.json').read_text());pub=json.loads((dest/'sources.json').read_text());slots={q['id']:q for q in pub}
matched={v['id'] for v in json.loads((dest/'studio.json').read_text())['views']}
out=dest/'reference-tracings';out.mkdir(exist_ok=True)
seen={}
for r in records:
 q=slots[r['id']]
 if r['id']=='detail-31':q['status']='excluded';q['subject']='Interview portrait';q['note']='Person portrait. It supplies no vehicle geometry.'
 if r['id']=='press-27':q['subject']='Overhead front of the black ZR1X with a red stripe'
 if r['id'].startswith('cabin-'):q['subject']='Jet Black cabin panorama, '+r['id'].removeprefix('cabin-')+' face'
 q['tracing']=('captures/'+q['id']+'-reference.webp') if r['id'] in matched else ('reference-tracings/'+r['id']+'.webp')
 if r['sha256'] in seen:q['duplicate_of']=seen[r['sha256']]
 else:seen[r['sha256']]=r['id']
def trace(r):
 if r['id'].startswith('ext-'):return
 q=slots[r['id']];im=np.array(Image.open(root/r['file']).convert('RGB'))[:,:,::-1].copy();h,w=im.shape[:2]
 scale=min(1,1500/max(h,w));im=cv.resize(im,(round(w*scale),round(h*scale)),interpolation=cv.INTER_AREA)
 # Use component boundaries and nested intensity contours at multiple scales; these reveal small controls and mechanical detail.
 gray=cv.cvtColor(im,cv.COLOR_BGR2GRAY);smooth=cv.bilateralFilter(gray,7,27,7)
 denoised=cv.GaussianBlur(smooth,(3,3),.7);field=np.full((*smooth.shape,3),250,'uint8')
 threshold_levels=np.unique(np.percentile(denoised,[13,31,50,70,85]).astype(int))
 for t in threshold_levels:
  contours,_=cv.findContours(np.uint8(denoised>t)*255,cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE)
  for c in contours:
   if cv.arcLength(c,True)<31:continue
   cv.polylines(field,[cv.approxPolyDP(c,1.2,True)],True,(209,209,204),1,cv.LINE_AA)
 for l,hi,col in [(28,68,(150,153,154)),(52,112,(77,84,89))]:
  e=cv.Canny(smooth,l,hi,L2gradient=True);cs,_=cv.findContours(e,cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE)
  for c in cs:
   if cv.arcLength(c,False)>12:cv.polylines(field,[cv.approxPolyDP(c,.67,False)],False,col,1,cv.LINE_AA)
 file=dest/q['tracing'];cv.imwrite(str(file),field,[cv.IMWRITE_WEBP_QUALITY,92])
with ThreadPoolExecutor(4) as pool:list(pool.map(trace,records))
(dest/'sources.json').write_text(json.dumps(pub,indent=2))
