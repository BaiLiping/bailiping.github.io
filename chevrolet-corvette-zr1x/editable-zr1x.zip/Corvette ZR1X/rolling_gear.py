"""ZR1X twenty-spoke wheel, Pilot Sport tire and J59 brake in axle-local coordinates."""
bright_fastener=mat('Polished wheel nuts','b7bab9',.71,.25)
rubber=mat('Road tire sidewall','363738',.02,.79)
caliper_ink=mat('White caliper lettering','dfdfdb',.025,.48)
sidewall_letters=mat('Molded tire lettering','444547',.03,.69)

def rolling_corner(axle, side):
    x, radius, track, width, rim, bolt_radius = [
        (-1.3615, .3365, .8425, .275, .2540, .060),
        ( 1.3615, .35295,.8390, .345, .2667, .065),
    ][axle]
    corner = ('Front_' if axle == 0 else 'Rear_') + ('left' if side < 0 else 'right')
    root = empty(corner, (x, side * track, radius))
    groups = {}
    for name in ['Tire', 'Wheel_face', 'Brake_disc', 'Brake_caliper']:
        groups[name] = empty(name + '_' + corner)
        groups[name].parent = root
    tire, wheel, disc, caliper = groups.values()
    a = width / 2
    front = a - .012

    def ring(name, profile, material, parent, count=120, smooth=True):
        vertices = []
        faces = []
        for r0, y0 in profile:
            vertices.extend((r0*cos(2*pi*k/count), side*y0, r0*sin(2*pi*k/count)) for k in range(count))
        for j in range(len(profile)-1):
            for k in range(count):
                k2 = (k+1) % count
                ids = (j*count+k, j*count+k2, (j+1)*count+k2, (j+1)*count+k)
                faces.append(ids if side < 0 else ids[::-1])
        obj = mesh(name, vertices, faces, material, parent)
        if smooth:
            for f0 in obj.data.polygons: f0.use_smooth = True
        return obj

    profile = [(rim-.005,-a+.014),(rim+.014,-a+.002),(.91*radius,-a),(.97*radius,-a+.010),(radius,-a+.030)]
    for lane in [-.51,-.17,.19,.52]:
        y0 = a * lane
        profile.extend([(radius,y0-.004),(radius-.005,y0-.0025),(radius-.005,y0+.0025),(radius,y0+.004)])
    profile.extend([(radius,a-.030),(.97*radius,a-.010),(.91*radius,a),(rim+.012,a-.002),(rim-.005,a-.012),(rim-.005,-a+.014)])
    ring('Tire casing and circumferential grooves',profile,rubber,tire,160)
    for rr in (rim+.016,radius-.025):
        ring('Molded sidewall bead',[(rr-.0015,a-.001),(rr,a+.00025),(rr+.0013,a-.001)],rubber,tire)
    # Tread sipes cross the blocks and turn down both rounded shoulders.
    vv, ff = [], []
    for k in range(78):
        for s0 in (-1,1):
            segment = []
            for n,(yf,rf) in enumerate([(.22,1),(.49,1),(.76,1),(.89,.985),(.975,.951)]):
                phi = 2*pi*(k+.22*(s0+1)/2)/78 + s0*(.041*yf-.023*yf*yf)
                wid = .0025 + .0020 * yf
                for delta in (-wid,wid):
                    segment.append((radius*(rf+.0010)*cos(phi+delta),side*s0*a*yf,radius*(rf+.0010)*sin(phi+delta)))
            start = len(vv);vv.extend(segment)
            ff.extend((start+2*n,start+2*n+1,start+2*n+3,start+2*n+2) for n in range(4))
    mesh('Shoulder block sipes',vv,ff,tread,tire)
    ring('Inner wheel barrel',[(rim,-a+.016),(rim,front),(rim-.008,front),(rim-.014,front-.004),(rim-.014,-a+.016),(rim,-a+.016)],alloy,wheel)
    ring('Beveled outer lip',[(rim-.011,front),(rim-.004,front+.004),(rim+.005,front+.004),(rim+.011,front),(rim+.012,front-.004)],alloy,wheel)
    ring('Forged wheel center',[(.002,front-.067),(.051,front-.067),(.064,front-.056),(.056,front-.050),(.029,front-.038),(.002,front-.038)],alloy,wheel)
    ring('Hub flange bevel',[(.025,front-.040),(.030,front-.034),(.033,front-.034),(.037,front-.043)],alloy,wheel)
    ring('Crossed flags center cap',[(0,front-.034),(.027,front-.034),(.031,front-.038),(.031,front-.044)],dark,wheel)
    # One of five repeated sectors traced on the front wheel in Chevrolet frame 006.
    # Coordinates are millimeters in the radial plane, Z pointing down in the reference.
    for k in range(5):
        angle = 2*pi*k/5
        def to_corner(u,down,depth):
            return (u*cos(angle)+down*sin(angle), side*depth, u*sin(angle)-down*cos(angle))
        def spoke(name, knots):
            sections = []
            for j,(u,down,w,depth) in enumerate(knots):
                prev = knots[max(0,j-1)]; nxt = knots[min(j+1,len(knots)-1)]
                du,dv = nxt[0]-prev[0],nxt[1]-prev[1]
                length = math.hypot(du,dv); nx,nz = -dv/length,du/length
                sec = []
                for q,dy in [(-1,-.011),(-.74,-.001),(-.62,.0006),(.62,.0006),(.74,-.001),(1,-.011),(.82,-.019),(-.83,-.019)]:
                    # Template pixels at 242 px/rim radius on the front wheel.
                    scale = rim / 242
                    sec.append(to_corner((u+q*1.67*w*nx)*scale,(down+q*1.67*w*nz)*scale,front+depth+dy))
                sections.append(sec)
            loft(name,sections,alloy,wheel)
        spoke('Main spoke trunk',[(0,25,10,-.045),(0,65,9,-.033),(0,115,7,-.022),(0,124,6,-.021)])
        for branch in (-1,1):
            spoke('Fork to rim',[(0,119,6,-.022),(branch*43,160,5,-.012),(branch*77,193,4,-.005),(branch*125,211,4,-.002)])
            spoke('Lug pocket brace',[(branch*16,56,6,-.044),(branch*39,79,5,-.038),(branch*50,147,3.4,-.019),(branch*58,239,3.5,-.003)])
            # This cross brace terminates on the adjacent sector's narrow spoke,
            # immediately beside the lug pocket at the same depth.
            spoke('Lug surround bridge',[(branch*39,79,4.5,-.038),(branch*61,62,4.4,-.041),
                                         (branch*80,61,4.0,-.037)])
        angle_lug = angle + pi/2
        cx,cz=bolt_radius*cos(angle_lug),bolt_radius*sin(angle_lug)
        polar=ring('Cast lug socket',[(.012,front-.044),(.013,front-.035),(.017,front-.033),(.023,front-.041),(.023,front-.054),(.012,front-.054)],alloy,wheel,36)
        polar.location.x,polar.location.z=cx,cz
        for name,rr,deep,material,sides in [('Counterbored lug well',.015,front-.039,holes,24),('Capped lug nut',.0105,front-.025,bright_fastener,6)]:
            obj = ring(name,[(0,deep-.008),(rr,deep-.008),(rr,deep-.001),(rr*.82,deep),(0,deep)],material,wheel,sides,False)
            obj.location.x, obj.location.z=cx,cz
    for sign,m in [(-1,metal),(1,red)]:
        verts=[(sign*u,side*(front-.032),z) for u,z in [(0,-.018),(.021,.011),(.018,-.002),(.005,-.019)]]
        mesh('Crossed flag on hub',verts,[(0,1,2,3)],m,wheel)
    # Raised tire identification follows the curved band on the outer sidewall.
    for word,angle0,font_size in [('MICHELIN',1.23,.017),('PILOT SPORT',-1.57,.013),('275/30 ZR20' if axle==0 else '345/25 ZR21',2.72,.0105)]:
        spacing=font_size*.78/(radius-.024)
        for j,ch in enumerate(word):
            if ch==' ':continue
            t=angle0+(len(word)/2-j)*spacing*side*(-1)
            radial=Vector((cos(t),0,sin(t)))
            face_dir=Vector((0,side,0))
            baseline=radial.cross(face_dir).normalized()
            cu=bpy.data.curves.new('Sidewall type','FONT');cu.body=ch;cu.size=font_size;cu.align_x='CENTER';cu.align_y='CENTER'
            cu.materials.append(sidewall_letters)
            ob=bpy.data.objects.new('Molded sidewall '+word,cu);sc.collection.objects.link(ob);ob.parent=tire
            ob.location=radial*(radius-.029)+face_dir*(a+.0004)
            from mathutils import Matrix
            ob.rotation_euler=Matrix((baseline,radial,face_dir)).transposed().to_euler()
    # Brake ring: planar annular friction faces, with a distinct bell and vented edge.
    friction = front-.077
    # A drilled ring is open on both friction surfaces. Build each wedge around
    # its swept drilling so the perforation stays visible through the isolated part.
    faces,vertices,materials=[],[],[]
    def add_face(ids,slot=0):
        faces.append(ids if side<0 else ids[::-1])
        materials.append(slot)
    radial_breaks=(.111,.152,.178,.20955)
    sectors=40
    for k in range(sectors):
        for row,(inside,outside) in enumerate(zip(radial_breaks,radial_breaks[1:])):
            t0=2*pi*k/sectors
            dt=2*pi/sectors
            hole_t=t0+dt*(.25+.22*row)
            hole_r=(inside+outside)/2+.0025
            cx,cz=hole_r*cos(hole_t),hole_r*sin(hole_t)
            outer=[]
            for t in np.linspace(t0,t0+dt,5):outer.append((outside*cos(t),outside*sin(t)))
            for r in np.linspace(outside,inside,4)[1:]:outer.append((r*cos(t0+dt),r*sin(t0+dt)))
            for t in np.linspace(t0+dt,t0,5)[1:]:outer.append((inside*cos(t),inside*sin(t)))
            for r in np.linspace(inside,outside,4)[1:-1]:outer.append((r*cos(t0),r*sin(t0)))
            unit=[]
            for px,pz in outer:
                length=math.hypot(px-cx,pz-cz)
                unit.append(((px-cx)/length,(pz-cz)/length))
            n=len(unit);start=len(vertices)
            for rr,depth in [(None,friction),(.0036,friction),(.0031,friction-.0007),
                             (.0031,friction-.0283),(.0036,friction-.029),(None,friction-.029)]:
                points=outer if rr is None else [(cx+dx*rr,cz+dz*rr) for dx,dz in unit]
                vertices.extend((px,side*depth,pz) for px,pz in points)
            for layer in range(5):
                for j in range(n):
                    a0=start+layer*n+j;b0=start+layer*n+(j+1)%n
                    add_face((a0,b0,b0+n,a0+n),1 if layer in (1,2,3) else 0)
    drilled=mesh('Perforated carbon ceramic friction ring',vertices,faces,rotor,disc)
    drilled.data.materials.append(holes)
    drilled.data.polygons.foreach_set('material_index',np.asarray(materials,'i'))
    ring('Outer disc vent channel',[(.207,friction-.001),(.207,friction-.029)],holes,disc)
    ring('Rotor hat',[(.029,friction+.014),(.099,friction+.014),(.116,friction+.003),(.119,friction),(.116,friction-.016),(.029,friction-.016)],dark,disc)
    vane_v,vane_f=[],[]
    for k in range(85):
        phi=2*pi*k/85; start=len(vane_v)
        for dy in (0,-.029):
            for dt in (-.012,.012):
                vane_v.append((.2094*cos(phi+dt+.45*dy),side*(friction+dy),.2094*sin(phi+dt+.45*dy)))
        vane_f.append(tuple(start+i for i in (0,1,3,2)))
    mesh('Disc cooling vanes',vane_v,vane_f,rotor,disc)
    # The front caliper is aft of its axle. The rear unit sits forward of its axle.
    hand=1 if axle==0 else -1
    sections=[]
    for t in np.linspace(-.56,.61,15):
        sec=[]
        for rr,dy in [(.172,-.020),(.175,.019),(.186,.028),(.208,.028),(.218,.020),(.221,-.025),(.211,-.050),(.175,-.049)]:
            if abs(t)>.47: rr=.197+(rr-.197)*.80
            sec.append((hand*rr*cos(t),side*(friction+dy),rr*sin(t)))
        sections.append(sec)
    obj=loft('Alcon monobloc caliper',sections,blue,caliper)
    for fa in obj.data.polygons:fa.use_smooth=True
    cu=bpy.data.curves.new('Caliper marking','FONT');cu.body='CORVETTE';cu.align_x='CENTER';cu.align_y='CENTER';cu.size=.018;cu.materials.append(caliper_ink)
    mark=bpy.data.objects.new('Corvette caliper lettering',cu);sc.collection.objects.link(mark);mark.parent=caliper
    mark.location=(hand*.198,side*(friction+.033),.001)
    # Local letter X follows the disc tangent; letter Z faces the wheel.
    from mathutils import Matrix
    mark.rotation_euler=Matrix(((0,-side,0),(0,0,side),(-1,0,0))).to_euler()

for axle in (0,1):
    for side in (-1,1):
        rolling_corner(axle, side)
