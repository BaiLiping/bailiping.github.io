from calibrate import *
import sys
out=Path(sys.argv[1]);p=json.loads((ROOT/'rig.json').read_text());K,R,C,T=pose(p)
def gl(x):v=np.array(x);return [round(float(q),7) for q in (v[0],v[2],-v[1])]
records=json.loads((ROOT/'inventory.json').read_text());views=[]
for i,r in enumerate(records[:30]):
 a=(24+12*i)%360;side='left' if a<180 else 'right';b=a if a<=180 else 360-a
 angle='front' if b<6 else ('rear' if b>174 else ((('front '+side) if b<77 else ('rear '+side) if b>103 else side+' profile')))
 views.append(dict(id=r['id'],label='%02d · %s'%(i+1,angle.title()),position=gl(C[i]),target=gl(p[6:]),up=gl([0,0,1]),fov=np.rad2deg(2*np.arctan(375/K[1,1])),imageSize=[1500,750],principalPoint=[round(K[0,2],5),round(K[1,2],5)],source=r['original_url']))
from scipy.spatial.transform import Rotation
xc,yc,D,ax,ay,roll,fp=json.loads((ROOT/'plan_camera.json').read_text())
rot=Rotation.from_euler('xyz',[ax,ay,roll],degrees=True).as_matrix()
r=np.diag([1,-1,-1])@rot.T;cc=np.array([0,0,.62])+r.T@np.array([0,0,-D])
source=next(q for q in records if q['id']=='press-07')
views.append(dict(id='press-07',label='Overhead · Blade Silver coupe',position=gl(cc),target=gl(cc+r[2]*D),up=gl(-r[1]),fov=float(np.rad2deg(2*np.arctan(225/fp))),imageSize=[2000,1000],principalPoint=[xc*2000/900,yc*1000/450],source=source['original_url']))
pano=next(q for q in records if q['id']=='cabin-front')
driver=json.loads((ROOT/'cabin-camera.json').read_text())
views.append(dict(id='cabin-front',label='Cockpit · Jet Black panorama',position=gl(driver['eye']),target=gl(driver['look']),up=gl([0,0,1]),fov=90,imageSize=[pano['width'],pano['height']],source=pano['original_url']))
views.append(json.loads((ROOT/'ring-high-camera.json').read_text()))
parts={'Body':[0,.67,0],'Carbon_Aero':[.51,1.17,0],'Roof_panel':[0,1.63,0],'Door_L':[0,.57,.92],'Door_R':[0,.57,-.92],'Cockpit':[0,1.22,0],'Powertrain':[.2,.06,0],'Front_left':[-.27,0,.81],'Front_right':[-.27,0,-.81],'Rear_left':[.27,0,.81],'Rear_right':[.27,0,-.81]}
manifest=dict(title='2027 Chevrolet Corvette ZR1X',subtitle='3LZ Coupe · Torch Red · Carbon Fiber Aero Package',model='zr1x.glb',poster='poster.webp',home=gl([-6.6,-5.35,1.65]),target=gl([-.02,0,.56]),eye=gl(driver['eye']),look=gl(driver['look']),views=views,parts=[dict(node=k,offset=v) for k,v in parts.items()],actions=[dict(label='Open doors',nodes=[dict(node='Door_L',axis='y',degrees=-52),dict(node='Door_R',axis='y',degrees=52)]),dict(label='Remove roof panel',nodes=[dict(node='Roof_panel',hidden=True)])],review='review.html')
launch='https://news.chevrolet.com/newsroom.detail.html/Pages/news/us/en/2025/jun/0617-2026-Corvette-ZR1X-hypercar.html'
guide='https://www.chevrolet.com/performance/corvette/zr1x'
techlink='https://gm-techlink.com/wp-content/uploads/2026/02/GM_TechLink_02_Mid-January_2026.pdf'
manifest['inspectionLabel']='Powertrain'
manifest['inspections']=[
 dict(id='powertrain',label='ZR1X hybrid powertrain',show=['Powertrain'],direction=[-2.6,2.3,3.85],note='The front electric drive and rear LT7 each drive a pair of half-shafts. The orange phase leads connect the electric axle to the battery in the center tunnel. The component spacing follows GM’s overhead powertrain illustration.',source=techlink+'#page=3'),
 dict(id='rear-powertrain',label='Rear LT7 V8 and transaxle',show=['LT7_engine','Rear_transaxle'],direction=[2.4,1.7,3.25],note='The blue intake sits above the two cylinder banks. The outer castings carry the twin turbochargers. The bellhousing joins the engine to the ribbed eight-speed dual-clutch transaxle ahead of its tapered tail case.',source=techlink+'#page=2'),
 dict(id='front-electric-drive',label='Front electric drive unit',show=['Front_electric_drive'],direction=[-1.8,1.9,2.8],note='The compact motor, final-drive case, three orange phase leads and two half-shafts share the front axle. The ribs, fasteners and CV boots are reconstructed external details.',source=techlink+'#page=3'),
 dict(id='hybrid-battery',label='Central hybrid battery',show=['Tunnel_battery'],direction=[-2.0,1.75,3.35],note='The 1.9 kWh battery sits low between the seats. GM’s exposed pack illustration guides the long tray, bracketed sections, electronics cover and orange insulated connections.',source=techlink+'#page=3')
]
(out/'studio.json').write_text(json.dumps(manifest,indent=2))
