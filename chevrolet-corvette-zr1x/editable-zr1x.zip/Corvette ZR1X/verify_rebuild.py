"""Compare decoded geometry, topology, material assignments and embedded assets of two delivered GLBs using Blender."""
import hashlib
import json
from pathlib import Path
import struct
import sys
import bpy
import numpy as np

def hashbytes(data):
    return hashlib.sha256(data).hexdigest()

def describe(path):
    with open(path,'rb') as f:
        header=f.read(12); n,tag=struct.unpack('<II',f.read(8)); gltf=json.loads(f.read(n)); n,tag=struct.unpack('<II',f.read(8)); payload=f.read(n)
    images={}
    for image in gltf.get('images',[]):
        view=gltf['bufferViews'][image['bufferView']]
        start=view.get('byteOffset',0); images[image['name']]=hashbytes(payload[start:start+view['byteLength']])
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=str(path))
    geometry={}; bounds=[]; hierarchy={}
    for obj in bpy.context.scene.objects:
        hierarchy[obj.name]={'parent':obj.parent.name if obj.parent else None,'transform':np.round(np.asarray(obj.matrix_world),5).tolist()}
        if obj.type!='MESH':continue
        mesh=obj.data
        verts=np.empty(len(mesh.vertices)*3,np.float32);mesh.vertices.foreach_get('co',verts)
        uv=np.empty(len(mesh.loops)*2,np.float32)
        tex={}
        for layer in mesh.uv_layers:
            layer.data.foreach_get('uv',uv);tex[layer.name]=hashbytes(uv.tobytes())
        corners=np.empty(len(mesh.loops),np.int32);mesh.loops.foreach_get('vertex_index',corners)
        material=np.empty(len(mesh.polygons),np.int32);mesh.polygons.foreach_get('material_index',material)
        normals=np.array([n.vector[:] for n in mesh.corner_normals],dtype=np.float32)
        geo={'positions':hashbytes(verts.tobytes()),'polygon_vertices':hashbytes(corners.tobytes()),'normals':hashbytes(normals.tobytes()),'uv':tex,'material_indices':hashbytes(material.tobytes()),'slots':[m.name if m else None for m in mesh.materials],'vertices':len(mesh.vertices),'faces':len(mesh.polygons)}
        geometry[obj.name]=geo
        world=np.asarray(obj.matrix_world); points=verts.reshape(-1,3)@world[:3,:3].T+world[:3,3]
        bounds.extend((points.min(0),points.max(0)))
    mats={m.get('name',str(i)):m for i,m in enumerate(gltf['materials'])}
    nodes={m['name']:m.get('extras') for m in gltf['nodes'] if 'extras' in m}
    return {'geometry':geometry,'hierarchy':hierarchy,'bounds':np.round([np.min(bounds,0),np.max(bounds,0)],5).tolist(),'images':images,'materials':mats,'extras':nodes,'textures':gltf.get('textures',[]),'samplers':gltf.get('samplers',[])}

if __name__=='__main__':
    args=sys.argv[sys.argv.index('--')+1:]
    if len(args)<2:raise ValueError('Pass the reference and rebuilt GLB after --')
    a,b=[describe(Path(p).resolve()) for p in args[:2]]
    errors=[]
    for k in a:
        if a[k]!=b[k]:
            changed=[n for n in set(a[k])|set(b[k]) if a[k].get(n)!=b[k].get(n)] if isinstance(a[k],dict) else []
            errors.append([k,len(changed),changed[:10]])
    print('Model comparison',json.dumps({'meshes':len(a['geometry']),'nodes':len(a['hierarchy']),'materials':len(a['materials']),'images':len(a['images']),'bounds':a['bounds'],'differences':errors}))
    if errors:raise RuntimeError('Semantic GLB comparison failed.')
