"""Door mirror housings fitted to Chevrolet 3LZ exterior frames 29, 1, 3, 6, 9, 11 and 13."""
# Each ordered convex outline excludes the separate mounting stalk. Coordinates are
# native 1500×750 studio pixels relative to the local crop's upper-left corner.
mirror_outlines={
 29:((982,248),[(20,46),(21,34),(23,26),(26,21),(30,18),(47,15),(63,14),(71,14),(75,16),(77,20),(80,29),(81,35),(75,44),(69,52),(65,54),(36,57),(26,54),(22,50)]),
 1:((892,251),[(17,47),(19,36),(22,31),(30,25),(39,20),(50,17),(65,15),(84,14),(89,16),(94,23),(97,32),(94,38),(84,51),(80,54),(74,55),(30,55),(22,52)]),
 3:((760,253),[(16,45),(18,38),(22,29),(29,25),(44,20),(59,16),(78,14),(90,13),(95,14),(98,17),(102,29),(102,34),(95,46),(90,53),(86,55),(60,56),(31,53),(20,50)]),
 6:((544,252),[(29,45),(31,38),(35,31),(41,26),(50,22),(62,18),(77,15),(87,14),(92,14),(94,17),(95,28),(95,35),(91,52),(88,56),(84,57),(56,56),(47,53),(32,50)]),
 9:((397,248),[(46,40),(49,31),(53,23),(57,19),(68,16),(76,15),(81,16),(86,18),(88,22),(89,30),(89,41),(85,52),(82,56),(76,57),(57,55),(51,51)]),
 11:((368,244),[(44,35),(45,29),(50,21),(54,18),(59,16),(68,16),(78,17),(86,19),(90,21),(92,25),(92,41),(90,45),(83,53),(78,57),(70,56),(55,53),(50,49)]),
 13:((396,240),[(37,35),(40,22),(43,18),(48,17),(61,17),(75,19),(84,21),(87,23),(89,30),(90,43),(88,47),(77,55),(72,57),(66,57),(52,55),(48,52),(42,46),(38,40)])
}
def mirror_projection(frame):
    center,rotation,(cx,cy,fp)=frame_camera(frame)
    k=np.array([[fp,0,cx],[0,fp,cy],[0,0,1]])/.6
    k[2,2]=1
    return center,k@rotation

def convex_polygon(points):
    p=sorted(set(tuple(x) for x in points))
    def edge(sequence):
        result=[]
        for x,y in sequence:
            while len(result)>1:
                (ax,ay),(bx,by)=result[-2:]
                if (bx-ax)*(y-ay)-(by-ay)*(x-ax)>0:break
                result.pop()
            result.append((x,y))
        return result
    return np.array(edge(p)[:-1]+edge(p[::-1])[:-1])

mirror_planes=[]
for frame,(origin,outline) in mirror_outlines.items():
    center,matrix=mirror_projection(frame)
    hull=convex_polygon(np.array(outline)+origin)
    for a,b in zip(hull,np.roll(hull,-1,axis=0)):
        line=np.cross([*a,1],[*b,1]);normal=line@matrix
        mirror_planes.append((normal,normal@center))
# Calibrated rear glass plane, fitted to the outlines in frames 9, 11 and 13.
# The asymmetric viewing angle directs the glass inboard toward the driver's eye.
mirror_center=np.array([-.57696,-.990,.900])
mirror_axis=np.array([1,.41852,.0566]);mirror_axis/=np.linalg.norm(mirror_axis)
mirror_across=np.cross([0,0,1],mirror_axis);mirror_across/=np.linalg.norm(mirror_across)
mirror_up=np.cross(mirror_axis,mirror_across)

def mirror_section(depth):
    origin=mirror_center+depth*mirror_axis
    poly=np.array([[-.2,-.1],[.2,-.1],[.2,.1],[-.2,.1]])
    for n,plane in mirror_planes:
        s=poly@np.array([n@mirror_across,n@mirror_up])+n@origin-plane
        if np.all(s>=0):continue
        clipped=[]
        for a,b,sa,sb in zip(poly,np.roll(poly,-1,axis=0),s,np.roll(s,-1)):
            if sa>=0:clipped.append(a)
            if (sa>=0)!=(sb>=0):clipped.append(a+(b-a)*(sa/(sa-sb)))
        if len(clipped)<3:return None
        poly=np.array(clipped)
    for _ in range(3):
        nxt=np.roll(poly,-1,axis=0)
        poly=np.stack([.75*poly+.25*nxt,.25*poly+.75*nxt],axis=1).reshape(-1,2)
    mid=poly.mean(axis=0);delta=poly-mid
    angles=np.arctan2(delta[:,1],delta[:,0]);order=np.argsort(angles)
    angles=angles[order];radius=np.linalg.norm(delta[order],axis=1)
    theta=np.linspace(-pi,pi,80,endpoint=False)
    radii=np.interp(theta,angles,radius,period=2*pi)
    xy=mid+np.stack([np.cos(theta)*radii,np.sin(theta)*radii],axis=1)
    return origin+xy[:,0,None]*mirror_across+xy[:,1,None]*mirror_up

mirror_rings=[ring for depth in np.linspace(-.245,-.003,56) if (ring:=mirror_section(depth)) is not None]
# A glass retaining bezel has the traced, softly clipped trapezoidal perimeter.
glass_curve=[(48,21),(50,20.1),(58,20.2),(70,21.1),(80,22.8),(82.7,24.4),(84.2,27.8),
            (84.7,35.8),(84.6,40.1),(83.2,42.4),(78,47.2),(72.6,51.8),(69,53.3),
            (60,53.2),(53.4,52.4),(50.4,51.1),(47,48.4),(43.6,42.7),(42,38.1),(42.6,33.2),(44,27.2),(45.7,23.1)]
center,matrix=mirror_projection(13)
glass_pixels=np.array(glass_curve)+mirror_outlines[13][0]
rays=np.column_stack([glass_pixels,np.ones(len(glass_pixels))])@np.linalg.inv(matrix).T
glass_edge=center+rays*(((mirror_center-center)@mirror_axis)/(rays@mirror_axis))[:,None]
for _ in range(2):
    other=np.roll(glass_edge,-1,axis=0)
    glass_edge=np.stack([.75*glass_edge+.25*other,.25*glass_edge+.75*other],axis=1).reshape(-1,3)
glass_mid=glass_edge.mean(axis=0)
rim_delta=glass_edge-glass_mid;ang=np.arctan2(rim_delta@mirror_up,rim_delta@mirror_across)
sort=np.argsort(ang);theta=np.linspace(-pi,pi,80,endpoint=False)
glass_edge=glass_mid+np.array([np.interp(theta,ang[sort],rim_delta[sort,j],period=2*pi) for j in range(3)]).T
bezel_edge=glass_mid+1.10*(glass_edge-glass_mid)+.002*mirror_axis
mirror_rings.append(bezel_edge)
# Fair the fitted silhouette sections into the continuous injection-molded skin.
surface_rings=np.array(mirror_rings)
for _ in range(13):
    smoothed=.58*surface_rings+.21*(np.roll(surface_rings,1,1)+np.roll(surface_rings,-1,1))
    smoothed[1:-1]=.54*smoothed[1:-1]+.23*(smoothed[:-2]+smoothed[2:])
    smoothed[-1]=bezel_edge
    surface_rings=smoothed
mirror_rings=surface_rings
surface_faces=[(j*80+k,j*80+(k+1)%80,(j+1)*80+(k+1)%80,(j+1)*80+k)
               for j in range(len(mirror_rings)-1) for k in range(80)]
mirror_tree=BVHTree.FromPolygons(mirror_rings.reshape(-1,3).tolist(),surface_faces)
def cheek_landmark(u,v):
    camera,matrix=mirror_projection(6)
    xy=np.asarray(mirror_outlines[6][0])+[u,v]
    direction=Vector((np.linalg.inv(matrix)@np.array([*xy,1])).tolist()).normalized()
    hit,normal,index,_=mirror_tree.ray_cast(Vector(camera.tolist()),direction)
    return None if hit is None else np.array(hit)


# The red-to-black break climbs toward the rear outside cheek. Three registered
# views locate that cut across the leading face and the outboard shoulder.
mirror_seams={
 29:([18,27,42,56,65,69,75,81],[45,48,46,43,40,32,25,20],.19),
 3:([15,21,33,49,60,66,73,80,91,101],[44,48,48,47,45,40,31,26,22,19],.37),
 6:([28,34,43,50,55,59,65,74,84,94],[44,49,48,47,44,37,30,25,22,20],.44)
}
def mirror_color_boundary(points):
    score=np.zeros(len(points))
    for frame,(u,vv,weight) in mirror_seams.items():
        center,projection=mirror_projection(frame)
        q=(points-center)@projection.T;uv=q[:,:2]/q[:,2:]-mirror_outlines[frame][0]
        score+=weight*(np.interp(uv[:,0],u,vv)-uv[:,1])
    return score

mirror_red=mat('Torch Red mirror lacquer','c91720',.04,.24)
mirror_red.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=.45
mirror_lower=mat('Satin black mirror housing','1b1d20',.12,.32)
mirror_lip=mat('Mirror glass seal','202226',.018,.64)
mirror_lens=mat('Silvered door mirror','a6adb0',.91,.12)
mirror_lens.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=.2

def build_mirror(side,door,pivot):
    def local(point):
        return np.array([point[0],-side*point[1],point[2]])-pivot
    # Insert the seam vertices into both shells so the finished cap detaches.
    parts=[([],[],{}) for _ in range(2)]
    def add_face(part,polygon):
        vs,fs,lookup=part;idx=[]
        for p in polygon:
            key=tuple(np.round(p,7))
            if key not in lookup:lookup[key]=len(vs);vs.append(local(p))
            idx.append(lookup[key])
        if len(set(idx))>2:fs.append(idx if side<0 else idx[::-1])
    stack=np.asarray(mirror_rings);fields=mirror_color_boundary(stack.reshape(-1,3)).reshape(stack.shape[:2])
    fields[-1]=np.minimum(fields[-1],-1)
    for j in range(1,len(stack)):
        for k in range(stack.shape[1]):
            kk=(k+1)%stack.shape[1]
            corners=np.array([stack[j-1,k],stack[j-1,kk],stack[j,kk],stack[j,k]])
            values=np.array([fields[j-1,k],fields[j-1,kk],fields[j,kk],fields[j,k]])
            for part,sign in zip(parts,[1,-1]):
                poly=[]
                for a,b,sa,sb in zip(corners,np.roll(corners,-1,axis=0),sign*values,np.roll(sign*values,-1)):
                    if sa>=0:poly.append(a)
                    if (sa>=0)!=(sb>=0):poly.append(a+(b-a)*(sa/(sa-sb)))
                add_face(part,poly)
    add_face(parts[0],stack[0,::-1])
    for (vertices,faces,_),name,m in zip(parts,['Torch Red mirror cap','Lower mirror housing'],[mirror_red,mirror_lower]):
        obj=mesh(name,vertices,faces,m,door)
        for face in obj.data.polygons:face.use_smooth=True
        wall=obj.modifiers.new('Injection molded shell','SOLIDIFY');wall.thickness=.0018
    def make_ring(name,outer,inner,m):
        pts=[local(p) for p in np.concatenate([outer,inner])];n=len(outer)
        faces=[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
        obj=mesh(name,pts,faces if side<0 else [f[::-1] for f in faces],m,door)
        for face in obj.data.polygons:face.use_smooth=True
        return obj
    make_ring('Mirror glass surround',bezel_edge,glass_edge-.002*mirror_axis,mirror_lip)
    pts=[local(glass_mid-.002*mirror_axis)]+[local(p-.002*mirror_axis) for p in glass_edge]
    n=len(glass_edge)
    faces=[(0,j+1,(j+1)%n+1) for j in range(n)]
    mesh('Mirror glass',pts,faces if side<0 else [f[::-1] for f in faces],mirror_lens,door)
    # Slender horizontal molded lip visible on the lower black cheek in frame 6.
    cheek=[]
    for u,z in [(55,39),(58,37.8),(63,36.2),(69,35.4),(78,34.8),(86,34.3),(90,33.8),(92,33.1)]:
        center=cheek_landmark(u,z)
        above=cheek_landmark(u,z-.85);below=cheek_landmark(u,z+.9)
        if center is None or above is None or below is None:continue
        raised=center+np.array([0,-.0033,.0008])
        cheek.append([local(above),local(raised),local(below),local(center+np.array([0,.002,0]))])
    if len(cheek)>1:
        blade=loft('Mirror lower housing character line',cheek,mirror_lower,door)
        for face in blade.data.polygons:face.use_smooth=True
    # The blade departs the sail nearly horizontally, then flares into the
    # inboard underside of the head; its rounded blade is much wider fore-aft.
    arm=[]
    for xx,yy,zz,w,h,tilt in [(-.745,.788,.801,.064,.020,.12),(-.751,.819,.806,.076,.020,.12),
                (-.724,.848,.813,.061,.017,.12),(-.691,.878,.820,.054,.014,.10),
                (-.665,.908,.826,.049,.013,.10),(-.631,.938,.836,.046,.015,.11),
                (-.609,.954,.847,.043,.016,.13)]:
        sec=[]
        for t in np.linspace(0,2*pi,30,endpoint=False):
            xoff=w*np.sign(cos(t))*abs(cos(t))**.75
            sec.append(local([xx+xoff,-yy,zz+h*sin(t)-tilt*xoff]))
        arm.append(sec)
    stalk=loft('Mirror mounting arm',arm,mirror_lower,door)
    for face in stalk.data.polygons:
        if side>0:face.flip()
        face.use_smooth=True
