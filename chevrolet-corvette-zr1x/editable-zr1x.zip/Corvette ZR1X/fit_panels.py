"""Fit pressed-panel sections and cut continuous panel edges on the calibrated exterior.

Run this outside Blender after refine_materials.py. The cut mesh is shipped in
the editable archive so rebuilding the GLB requires only Blender.
"""
from pathlib import Path
import json
import cv2 as cv
import numpy as np
from scipy.ndimage import map_coordinates, gaussian_filter
from scipy.spatial.transform import Rotation
from scipy.spatial import cKDTree
from calibrate import pose

ROOT = Path(__file__).resolve().parent
data = np.load(ROOT / 'finalskin.npz')
source = data['v'].astype(float)
tri = data['f']
normal = np.load(ROOT / 'smoothed_normals.npy')
K, R, C, _ = pose(json.loads((ROOT/'rig.json').read_text()))
px, py, distance, ax, ay, roll, focal = json.loads((ROOT/'plan_camera.json').read_text())
plan_rotation = np.diag([1,-1,-1]) @ Rotation.from_euler('xyz',[ax,ay,roll],degrees=True).as_matrix().T
plan_center = np.array([0,0,.62]) + plan_rotation.T @ [0,0,-distance]

def project(points, frame):
    if frame == 'top':
        view = (points-plan_center) @ plan_rotation.T
        return view[:,:2] * (focal/view[:,2:]) + [px,py]
    view = (points-C[frame-1]) @ R[frame-1].T
    return (view[:,:2] * (K[0,0]/view[:,2:]) + K[:2,2]) * .6

def smooth(a,b,value):
    t = np.clip((value-a)/(b-a),0,1)
    return t*t*(3-2*t)

from scipy.interpolate import PchipInterpolator
# Symmetric smooth envelopes from the upper and side surfaces. Position
# corrections are applied as displacements, preserving thickness and winding.
from scipy.ndimage import distance_transform_edt
def envelope(coords, height, step, smoothing):
    origin=coords.min(0)-2*step
    ids=np.rint((coords-origin)/step).astype(int)
    h=np.full(tuple(ids.max(0)+3),-10.,float)
    np.maximum.at(h,tuple(ids.T),height)
    fill=distance_transform_edt(h<-9,return_distances=False,return_indices=True)
    h=gaussian_filter(h[tuple(fill)],smoothing)
    def sample(a,b):
        uv=(np.asarray([a,b]).T-origin)/step
        return map_coordinates(h,uv.T,order=1,mode='nearest')
    return sample
sky=normal[:,2]>.25
top_guide=envelope(np.column_stack([source[sky,0],abs(source[sky,1])]),source[sky,2],.013,(2.1,1.5))
walls=(abs(normal[:,1])>.2)&(abs(source[:,1])>.65)
side_guide=envelope(source[walls][:,[0,2]],abs(source[walls,1]),.012,(2.5,1.5))
hood_profile=PchipInterpolator([-2.53,-2.40,-2.30,-2.19,-2.11,-2.02,-1.980,-1.958,-1.93,-1.87,-1.64,-1.554,-1.528,-1.500,-1.395,-1.27,-1.15,-1.0],
 [.34,.440,.505,.579,.626,.664,.675,.677,.667,.648,.650,.661,.697,.714,.754,.79,.812,.84])
green_profile=PchipInterpolator([-1.55,-1.39,-1.24,-1.08,-.84,-.62,-.48,-.40,-.29,-.11,.13,.31,.46,.63,.84,1.10,1.35,1.60,1.80],
 [.78,.799,.835,.897,1.008,1.108,1.168,1.186,1.201,1.213,1.216,1.208,1.195,1.169,1.132,1.09,1.04,.995,.975])
door_profile=PchipInterpolator([-.4,-.22,0,.10,.25,.52,.78,.92,1,1.11,1.29,1.55],
 [.005,.022,.049,.039,.005,-.054,-.043,-.014,0,-.017,-.044,-.080])
def top_hood(x,y):
    # Fully covered region used to prevent the general fairing pass from
    # rounding off a deliberately pressed surface.
    return (1-smooth(.56,.67,y))*smooth(-2.25,-2.10,x)*(1-smooth(-1.34,-1.19,x))
rear_mask=(source[:,0]>1.76)&(abs(source[:,1])<.67)&(source[:,2]>.51)&(source[:,2]<.90)&(normal[:,0]>.55)
def rear_terms(y,z):
    t=z-.7; q=y*y
    return np.column_stack([np.ones(len(y)),q,t,t*t,q*t,q*q,t*t*t])
M=rear_terms(source[rear_mask,1],source[rear_mask,2]);v0=source[rear_mask,0]
coef=np.linalg.lstsq(M,v0,rcond=None)[0]
for iteration in range(3):
    w=1/np.maximum(.008,abs(M@coef-v0))
    coef=np.linalg.lstsq(M*w[:,None],v0*w,rcond=None)[0]
def rear_surface(y,z):
    width=.275+.107*np.clip((z-.589)/.198,0,1)
    depth=smooth(.578,.638,z)*(1-smooth(.758,.817,z))*(1-smooth(width-.043,width+.034,abs(y)))
    return rear_terms(y,z)@coef-.044*depth
def inlet_edge(z):
    return .296+.322*np.clip((z-.282)/.416,-.08,1.14)

def inlet_sidewall(x,z):
    # Smooth quarter-panel envelope. The scoop has depth across the car but
    # its mouth is only a few millimeters wide when viewed along the rear axle.
    lip=inlet_edge(z)
    rear_width=np.interp(z,[.16,.24,.34,.55,.67,.75,.84,.91],
                            [.949,.982,1.002,1.005,1.003,.989,.945,.910])
    rear_width-=.022*(1-smooth(.42,.90,x))
    top=.629+.075*(x+.84); low=.287+.063*(x+.85)
    pos=(z-low)/(top-low)
    door=(.965-.038*smooth(-.9,.4,x))+door_profile(np.clip(pos,-.4,1.55))*(.49+.91*smooth(-.82,.51,x))
    open_height=smooth(.28,.47,z)*(1-smooth(.635,.76,z))
    door_end=rear_width-.179*open_height
    door+=smooth(-.13,lip-.030,x)*(door_end-door)
    return door+(rear_width-door)*smooth(lip-.014,lip+.010,x)

def inlet_weight(x,z,a):
    return smooth(-.34,-.08,x)*(1-smooth(.90,1.04,x))*smooth(.204,.273,z)*(1-smooth(.839,.917,z))*smooth(.675,.735,a)

def reshape(points):
    x,y,z=points.T;a=abs(y);new=points.copy()
    cap=top_guide(x,a)
    high=smooth(.44,.565,z)
    for axle,radius in [(-1.3615,.3365),(1.3615,.35295)]:
        high*=smooth(radius+.022,radius+.066,np.hypot(x-axle,z-radius))
    # The carbon lip obscures the depressed outlet from a frontal viewpoint.
    # The photographed centerline, side fences and fender shoulders bound the fold.
    hx=np.clip(x-.55*a*a,-2.53,-1)
    hood=hood_profile(hx)+.033*np.exp(-((a-(.10+.26*(x+2.34)))/.038)**2)*smooth(-2.375,-2.24,x)*(1-smooth(-2.05,-1.95,x))
    hw=(1-smooth(.52,.74,a))*smooth(-2.38,-2.18,x)*(1-smooth(-1.34,-1.15,x))*high
    new[:,2]+=(hood-z)*hw
    gx=np.clip(x,-1.55,1.8)
    gz=green_profile(gx)-(.13+.045*smooth(-1.31,-.2,x))*a*a-.77*np.maximum(a-.53,0)**1.73
    gw=(1-smooth(.63,.79,a))*smooth(-1.47,-1.22,x)*(1-smooth(1.41,1.77,x))*high
    new[:,2]+=(gz-z)*gw
    # Backbone and shoulders remain higher than the split back glass.
    new[:,2]-=.047*smooth(.39,.62,x)*(1-smooth(1.45,1.80,x))*smooth(.91,1.00,z)*smooth(.076,.17,a)*(1-smooth(.39,.65,a))
    oldw=side_guide(x,z)
    near_side=smooth(.64,.755,a)
    shoulder=.621+.082*(x+.86)
    lower=.287+.063*(x+.85)
    pos=(z-lower)/(shoulder-lower)
    broad=(.965-.038*smooth(-.9,.4,x)) + door_profile(np.clip(pos,-.4,1.55))*(.49+.91*smooth(-.82,.51,x))
    edge=.286+.31*np.clip((z-.31)/.42,0,1)
    seal=.018
    dw=smooth(-1.03,-.75,x)*(1-smooth(edge-.105,edge+seal,x))*smooth(.165,.25,z)*(1-smooth(.729,.834,z))*near_side
    new[:,1]=np.sign(y)*(a+(broad-oldw)*dw)
    shaped=inlet_sidewall(x,z)
    mix=inlet_weight(x,z,a)
    new[:,1]=np.sign(y)*((1-mix)*abs(new[:,1])+mix*shaped)
    # The rear plate is set into a molded, sloping trapezoidal surround.
    tailmask=smooth(1.77,1.94,x)*smooth(.51,.55,z)*(1-smooth(.846,.91,z))*(1-smooth(.51,.66,a))
    new[:,0]+=(rear_surface(y,z)-x)*tailmask
    # The original opacity hull wrapped the black corner flic into the red
    # fascia. Both front projections show the painted bumper curving inboard
    # below the radiator. Cut to its RED silhouette and fit the upper aero
    # element independently. Use the far corner, away from the other wheels.
    side_points=new.copy();side_points[:,1]=abs(side_points[:,1])
    flic_zone=smooth(-2.40,-2.23,x)*(1-smooth(-1.754,-1.675,x))*smooth(.104,.132,z)*(1-smooth(.294,.344,z))*smooth(.68,.795,a)
    correction=np.zeros(len(x))
    for frame,edge in [(29,[420,420,420,423,427,433,439,453,509]),
                       (1,[246,247,249,250,250,249,265,307,502])]:
        uv=project(side_points,frame)/.6
        inner=np.interp(uv[:,1],[468,478,488,498,508,518,528,538,546],edge)
        shifted=side_points.copy();shifted[:,1]+=.002
        rate=(uv[:,0]-project(shifted,frame)[:,0]/.6)/.002
        delta=np.maximum(0,inner-uv[:,0])/np.maximum(rate,45)
        correction=np.maximum(correction,np.minimum(.099,delta))
    new[:,1]-=np.sign(y)*correction*flic_zone
    return new

v = reshape(source)
# Smooth low-frequency photogrammetric surface noise on the roof and fender
# crowns; preserve the silhouette edge, pressed ridges and the wheel openings.
x,y,z = v.T
def fair_height(v):
    x,y,z=v.T; step=.012; nx=401; ny=171
    i=np.clip(np.rint((x+2.48)/step).astype(int),0,nx-1)
    j=np.clip(np.rint((y+1.02)/step).astype(int),0,ny-1)
    top=np.full((nx,ny),-2.,float)
    upper=(normal[:,2]>.25)&(z>.45)
    np.maximum.at(top,(i[upper],j[upper]),z[upper])
    good=top>-.2
    from scipy.ndimage import distance_transform_edt
    idx=distance_transform_edt(~good,return_distances=False,return_indices=True)
    top=top[tuple(idx)]
    fair=gaussian_filter(top,(3.1,2.4))
    current=map_coordinates(fair,[(x+2.48)/step,(y+1.02)/step],order=1,mode='nearest')
    w=smooth(.42,.82,normal[:,2])*(1-smooth(.02,.065,abs(current-z)))
    # The hood outlet has a pressed lip and sharp change in slope.
    w*=1-.95*top_hood(x,abs(y))
    w*=1-inlet_weight(x,z,abs(y))
    v[:,2]+=(current-z)*w*.84
fair_height(v)
x,y,z=v.T
# Blend the original measured low-frequency normals with the local Jacobian of each
# pressed surface. The resulting broad highlights remain continuous across the cut edges.
base=source.copy();jac=np.empty((len(v),3,3));eps=.001
for i in range(3):
    dx=np.eye(3)[i]*eps
    jac[:,:,i]=(reshape(base+dx)-reshape(base-dx))/(eps*2)
normal = (np.cross(jac[:,:,1],jac[:,:,2])*normal[:,0,None]+np.cross(jac[:,:,2],jac[:,:,0])*normal[:,1,None]+np.cross(jac[:,:,0],jac[:,:,1])*normal[:,2,None])
normal /= np.maximum(np.linalg.norm(normal,axis=1)[:,None],1e-10)
# Empirical normals on the flowing glass and upper sheet metal from a local
# quadratic fit to the fair top surface; these also remove the hull's horizontal stair-steps.
topsel=(normal[:,2]>.48)&(z>.45)
pts=v[topsel]; tindex=np.flatnonzero(topsel); tree=cKDTree(pts[:,:2])
for start in range(0,len(pts),1000):
    q=pts[start:start+1000];dist,index=tree.query(q[:,:2],k=84,workers=3)
    rel=pts[index]-q[:,None,:]; w=np.exp(-.5*(dist/.036)**2)*np.exp(-.5*(rel[:,:,2]/.055)**2)
    X=np.concatenate([rel[:,:,:2],np.ones((*rel.shape[:2],1))],axis=2)
    xw=X*w[:,:,None]; M=np.einsum('nki,nkj->nij',xw,X)
    sol=np.linalg.solve(M+np.eye(3)*1e-7,np.einsum('nki,nk->ni',xw,rel[:,:,2])[:,:,None])[:,:,0]
    n=np.column_stack([-sol[:,0],-sol[:,1],np.ones(len(q))]);n/=np.linalg.norm(n,axis=1)[:,None]
    ids=tindex[start:start+len(q)];fwt=smooth(.48,.85,normal[ids,2])*.89
    normal[ids]=normal[ids]*(1-fwt[:,None])+n*fwt[:,None]
normal/=np.maximum(np.linalg.norm(normal,axis=1)[:,None],1e-10)

side_sel=(abs(y)>.74)&(np.abs(normal[:,1])>.5)&(x>-1.02)&(x<.65)&(z>.163)&(z<.859)
P=v[side_sel].copy();P[:,1]=abs(P[:,1]);indices=np.flatnonzero(side_sel)
tree=cKDTree(P[:,[0,2]])
for start in range(0,len(P),900):
    q=P[start:start+900];d,nb=tree.query(q[:,[0,2]],k=128,workers=3);r=P[nb]-q[:,None,:]
    w=np.exp(-.5*(d/.035)**2)*np.exp(-.5*(r[:,:,1]/.069)**2)
    A=np.concatenate([r[:,:,[0,2]],np.ones((*r.shape[:2],1))],axis=2);aw=A*w[:,:,None]
    M=np.einsum('nki,nkj->nij',aw,A)
    sol=np.linalg.solve(M+np.eye(3)*1e-7,np.einsum('nki,nk->ni',aw,r[:,:,1])[:,:,None])[:,:,0]
    ids=indices[start:start+len(q)];N=np.stack([-sol[:,0],np.sign(y[ids]),-sol[:,1]],axis=1);N/=np.linalg.norm(N,axis=1)[:,None]
    mix=(smooth(-1.02,-.88,x[ids])*(1-smooth(.51,.65,x[ids]))*smooth(.16,.24,z[ids])*(1-smooth(.74,.86,z[ids])))
    normal[ids]=(1-mix[:,None])*normal[ids]+mix[:,None]*N
# A continuous reflection flows from the pressed door into the quarter, even
# where the intake changes the normal rapidly across the car.
mix=inlet_weight(x,z,abs(y))
deriv=.005
dx=(inlet_sidewall(x+deriv,z)-inlet_sidewall(x-deriv,z))/(2*deriv)
dz=(inlet_sidewall(x,z+deriv)-inlet_sidewall(x,z-deriv))/(2*deriv)
analytic=np.column_stack([-dx,np.sign(y),-dz]);analytic/=np.maximum(np.linalg.norm(analytic,axis=1)[:,None],1e-10)
normal=normal*(1-mix[:,None])+analytic*mix[:,None]
tailnorm=smooth(1.77,1.94,x)*smooth(.53,.57,z)*(1-smooth(.846,.91,z))*(1-smooth(.51,.66,abs(y)))
step=.004
nx=(rear_surface(y+step,z)-rear_surface(y-step,z))/(2*step)
nz=(rear_surface(y,z+step)-rear_surface(y,z-step))/(2*step)
ref=np.column_stack([np.ones(len(v)),-nx,-nz]);ref/=np.linalg.norm(ref,axis=1)[:,None]
normal=(1-tailnorm[:,None])*normal+tailnorm[:,None]*ref
# The carbon corner blades were separated from the silhouette hull. Smooth
# the highlights on the neighboring painted bumper across its cut transition.
corner=(x<-1.65)&(z<.48)&(abs(y)>.66)
corner_ids=np.flatnonzero(corner)
original_normals=np.load(ROOT/'smoothed_normals.npy')
neighbors=cKDTree(v)
for start in range(0,len(corner_ids),600):
    ids=corner_ids[start:start+600]
    dist,near=neighbors.query(v[ids],k=115,workers=3)
    direction=original_normals[ids]
    like=np.einsum('ijk,ik->ij',original_normals[near],direction)
    weights=np.exp(-.5*(dist/.037)**2)*np.clip((like+.36)/1.36,0,1)**.65
    rel=v[near]-v[ids,None]
    cent=np.einsum('ij,ijk->ik',weights,rel)/np.maximum(weights.sum(axis=1)[:,None],1e-8)
    rel-=cent[:,None];cov=np.einsum('nki,nkj->nij',rel*weights[:,:,None],rel)
    _,axes=np.linalg.eigh(cov);near_normal=axes[:,:,0]
    near_normal*=np.sign(np.einsum('ij,ij->i',near_normal,direction))[:,None]
    blend=smooth(.65,.79,abs(y[ids]))*(1-smooth(.34,.48,z[ids]))*(1-smooth(-1.8,-1.64,x[ids]))
    normal[ids]=normal[ids]*(1-blend[:,None])+near_normal*blend[:,None]
wind_outline=[(234,223),(236,193),(243,159),(252,139),(269,118),(285,116),(320,121),(350,127),(376,133),(366,166),(360,198),(360,226),(362,253),(366,279),(374,305),(345,314),(306,327),(288,331),(274,328),(260,316),(247,291),(240,264)]
roof_outline=[(376,133),(418,137),(467,140),(482,143),(492,164),(499,192),(501,217),(499,247),(494,271),(481,286),(442,293),(403,299),(374,305),(367,276),(362,248),(360,218),(361,194),(366,163)]
side_outline=[(342,184),(350,170),(365,157),(385,145),(409,135),(432,129),(461,126),(491,127),(526,131),(553,135),(573,139),(582,144),(567,154),(550,164),(522,171),(488,176),(451,180),(410,184),(368,186)]
door_outline=[(332,187),(353,181),(404,175),(451,169),(507,163),(548,158),(557,181),(566,204),(565,222),(559,243),(548,260),(535,272),(514,282),(483,291),(449,297),(390,302),(324,308),(318,285),(314,260),(311,238),(313,222),(318,207),(324,195)]
hood_outline=[(145,225),(148,204),(158,178),(177,151),(203,131),(231,118),(267,111),(280,114),(273,124),(259,140),(249,159),(241,185),(235,218),(237,248),(247,281),(260,308),(282,332),(276,339),(247,334),(219,322),(191,304),(171,283),(157,261),(149,242)]
hatch_outline=[(482,141),(517,128),(557,125),(610,129),(640,142),(658,165),(680,196),(684,207),(678,226),(657,255),(631,275),(601,281),(555,290),(518,293),(482,287),(494,268),(500,237),(500,196),(493,166)]
tail_port=[(265,225),(336,228),(348,237),(352,247),(349,250),(264,248),(262,244)]
front_port=[(275,257),(308,265),(338,275),(342,279),(333,292),(333,313),(328,319),(276,315),(273,307)]
center_port=[(316,270),(356,279),(399,284),(442,285),(484,282),(531,275),(561,269),(549,286),(534,291),(517,320),(510,323),(360,323),(352,318),(338,293),(330,287)]
rear_diff=[(262,262),(320,259),(365,257),(385,251),(500,251),(524,255),(579,256),(623,260),(626,273),(625,306),(618,311),(567,310),(550,321),(346,321),(325,311),(275,310),(265,305)]
front=project(v,29);back=project(v,14);top=project(v,'top')
sidev=v.copy();sidev[:,1]=-abs(sidev[:,1]);side=project(sidev,6)
mirror=v.copy();mirror[:,1]*=-1;top_mirror=project(mirror,'top')

def field(poly,uv):
    # Signed distance in pixels evaluated at subpixel locations.
    scale=3;mask=np.zeros((450*scale,900*scale),np.uint8)
    cv.fillPoly(mask,[np.rint(np.asarray(poly)*scale).astype(np.int32)],1)
    dist=cv.distanceTransform(mask,cv.DIST_L2,5)-cv.distanceTransform(1-mask,cv.DIST_L2,5)
    return map_coordinates(dist,[uv[:,1]*scale,uv[:,0]*scale],order=1,mode='nearest')/scale

def reflected(poly,center):
    return [(2*center-u,w) for u,w in poly]
# Each region is divided in the original triangles, including an interpolated
# crossing at each boundary. Adjacent panels therefore have the same clean edge.
labels=['Body','Windshield','Left side glass','Right side glass','Roof panel','Front closure','Rear closure','Left door','Right door','Front central duct','Front outer duct L','Front outer duct R','Rear vent L','Rear vent R','Diffuser inset','Front fascia','Rear fascia','Underfloor','Hatch glazing']
zones=[]
def add(poly,uv,limit):
    value=field(poly,uv)
    if uv is top:
        value=(value+field(poly,top_mirror))*.5
    zones.append(np.minimum(value,limit))
add(wind_outline,top,(z-.77)*200)
for side_sign in [-1,1]:
    add(side_outline,side,np.minimum((np.abs(y)-.52)*200,(side_sign*y-.1)*200))
add(roof_outline,top,(z-1.03)*200)
add(hood_outline,top,(z-.45)*200)
add(hatch_outline,top,(z-.92)*200)
for side_sign in [-1,1]:
    add(door_outline,side,np.minimum((abs(y)-.66)*250,(side_sign*y-.1)*200))
for poly in [center_port,front_port,reflected(front_port,440)]:
    add(poly,front,(-1.725-x)*250)
for poly in [tail_port,reflected(tail_port,444)]:
    add(poly,back,(x-1.72)*250)
add(rear_diff,back,(x-1.72)*250)
zones += [(-1.75+.11*(abs(y)-.70)-x)*100,(x-1.83+.09*(abs(y)-.70))*100]
zones.append(np.minimum((.26-z)*200, (.89-abs(y))*200))
# Hatch glazing is cut before its carrier. Its paired panes reveal the engine.
rear_z=(z-.92)*200
side_distance=abs(y)
inner_width=.160-.068*np.clip((x-.53)/1.07,0,1)
outer_width=np.interp(x,[.47,.63,1.17,1.42,1.62],[.38,.48,.40,.27,.09])
ends=np.minimum((x-.46)-.27*np.clip(side_distance/.45,0,1)**1.6,1.67-x-.41*side_distance)
hatch_glass=200*np.minimum.reduce([side_distance-inner_width,outer_width-side_distance,ends])
zones.insert(5,np.minimum(hatch_glass,rear_z))
labels.insert(6,labels.pop())
# Inside the quarter intake the rearward sweep of the door ends at the
# transverse duct wall. Its dark return stops short of the painted outer lip.
side_edge=inlet_edge(z)
side_opening=200*np.minimum.reduce([x-side_edge+.109,side_edge+.068-x,z-.284,.751-z,abs(y)-.65])
zones.insert(0,side_opening)
labels.insert(1,'Side inlet return')
signals=np.stack(zones,axis=1)
# Attribute columns hold physical position, smooth normal, RGB and all cut fields.
colors=np.tile(np.uint8([194,14,20]),(len(v),1))
# The wheel-well liners and the undertray have independent finishes. All
# exposed painted surfaces have a continuous Torch Red base coat.
for axle,radius in [(-1.3615,.3365),(1.3615,.35295)]:
    well=(abs(y)>.60)&(np.hypot(x-axle,z-radius)<radius+.019)
    colors[well]=[26,27,29]
attrs=np.concatenate([v,normal,colors,signals],axis=1).astype(np.float32)
faces=tri.copy();sets=[];newattrs=[attrs];offset=len(attrs)
for label in range(1,len(labels)):
    col=9+label-1
    # Track any vertices created by preceding cuts before testing the next one.
    if len(newattrs)>1:
        attrs=np.concatenate(newattrs,axis=0);newattrs=[attrs]
    sv=attrs[faces,col];keep=sv>0;inside=keep.all(axis=1);cross=keep.any(axis=1)&~inside
    fin=[faces[inside]];fout=[faces[~inside&~cross]]
    for count in (1,2):
        cutfaces=faces[cross&(keep.sum(axis=1)==count)]
        if not len(cutfaces):continue
        signs=attrs[cutfaces,col]>0
        pivot=np.argmax(signs if count==1 else ~signs,axis=1);row=np.arange(len(cutfaces))
        a=cutfaces[row,pivot];b=cutfaces[row,(pivot+1)%3];c=cutfaces[row,(pivot+2)%3]
        arr=attrs[a]
        def crossing(end):
            global offset
            other=attrs[end];alpha=arr[:,col]/(arr[:,col]-other[:,col])
            A=arr+(other-arr)*alpha[:,None];newattrs.append(A);idx=np.arange(offset,offset+len(A));offset+=len(A);return idx
        ab=crossing(b);ca=crossing(c)
        single=np.column_stack([a,ab,ca]);t1=np.column_stack([ab,b,c]);t2=np.column_stack([ab,c,ca])
        (fin if count==1 else fout).append(single);(fout if count==1 else fin).extend([t1,t2])
    sets.append(np.concatenate(fin));faces=np.concatenate(fout)
if len(newattrs)>1:attrs=np.concatenate(newattrs,axis=0)
sets=[faces]+sets
# A steep transverse return cannot be represented on the coarse visual-hull
# triangles. Replace the full cut strip with a ruled panel sampled ACROSS the
# duct. Its four boundaries coincide with the fitted sheet metal on either side.
transverse=np.unique(np.r_[np.linspace(-.109,-.018,11),np.linspace(-.018,.014,23),np.linspace(.014,.068,9)])
heights=np.linspace(.284,.751,103)
ss,zz=np.meshgrid(transverse,heights)
xx=inlet_edge(zz.ravel())+ss.ravel();zz=zz.ravel();yy=inlet_sidewall(xx,zz)
dx=(inlet_sidewall(xx+.0004,zz)-inlet_sidewall(xx-.0004,zz))/.0008
dz=(inlet_sidewall(xx,zz+.0004)-inlet_sidewall(xx,zz-.0004))/.0008
sidetone=np.tile([194.,14.,20.],(len(xx),1))
shadow=(smooth(.32,.685,zz)*.56+.28+.21*np.clip((yy-.806)/.18,0,1))
liner=np.column_stack([155*(1-np.clip(shadow,0,1))**1.35+15,9+6*shadow,12+7*shadow])
shade=(smooth(-.017,-.012,ss.ravel())*(1-smooth(.008,.012,ss.ravel()))*smooth(.32,.39,zz)*(1-smooth(.68,.733,zz)))
sidetone+=(liner-sidetone)*shade[:,None]
pieces=[]
row=np.arange(len(xx)).reshape(len(heights),len(transverse))
aa,bb,cc,dd=[arr.ravel() for arr in [row[:-1,:-1],row[:-1,1:],row[1:,1:],row[1:,:-1]]]
triangles=np.vstack([np.column_stack([aa,bb,cc]),np.column_stack([aa,cc,dd])])
for sign in (-1,1):
    ns=np.column_stack([-dx,sign*np.ones(len(xx)),-dz]);ns/=np.linalg.norm(ns,axis=1)[:,None]
    vv=np.column_stack([xx,sign*yy,zz])
    faceindices=triangles if sign==-1 else triangles[:,[0,2,1]]
    mirrored=vv.copy();mirrored[:,1]=-abs(mirrored[:,1]);local_side=project(mirrored,6)
    is_door=(field(door_outline,local_side)>0)&(ss.ravel()<-.018)
    on_door=is_door[faceindices].sum(axis=1)>=2
    panel_label='Left door' if sign<0 else 'Right door'
    sets[labels.index(panel_label)]=np.vstack([sets[labels.index(panel_label)],faceindices[on_door]+len(attrs)])
    pieces.append(faceindices[~on_door]+len(attrs))
    generated=np.zeros((len(xx),attrs.shape[1]),attrs.dtype)
    generated[:,:9]=np.column_stack([vv,ns,sidetone])
    attrs=np.vstack([attrs,generated])
sets[labels.index('Side inlet return')]=np.vstack(pieces)
# Merge coincident interpolated cut vertices to share smooth shading and
# recover aperture perimeter edges for physical duct return walls.
faces=np.concatenate(sets)
idx,inv=np.unique(np.round(attrs[:,:3],6),axis=0,return_index=True,return_inverse=True)[1:]
np.savez_compressed(ROOT/'body-panels.npz',hood_profile=hood_profile(np.linspace(-2.53,-1,1301)).astype('f'),side_z=heights,side_y=inlet_sidewall(inlet_edge(heights)+.025,heights),guide=v.astype('f'),v=attrs[idx,:3],n=attrs[idx,3:6],rgb=attrs[idx,6:9].clip(0,255).astype('uint8'),f=inv[faces].astype('i'),group=np.repeat(np.arange(len(sets)),[len(s) for s in sets]).astype('uint8'),labels=labels)
print([(name,len(rows)) for name,rows in zip(labels,sets)],flush=True)
