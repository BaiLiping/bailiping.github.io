"""Build the editable exterior from fused occupancy and multi-view surface-color estimates."""
from hull import *
from scipy import ndimage
from scipy.spatial import cKDTree
from skimage.measure import marching_cubes
import trimesh,moderngl,fast_simplification
v=np.load(ROOT/'volume.npz');x,y,z=[v[k] for k in 'xyz'];step=float(v['step'])
X,Y,Z=np.ogrid[:len(x),:len(y),:len(z)];X=x[X];Y=y[Y];Z=z[Z];ay=np.abs(Y)
raw=v['sdf'];h=v['hull']
from section_fit import fair_sections
s=fair_sections(raw,h,x,y,z,step)
# The oblique views show the front-facing black return wall behind each door.
# Reconstruct the indentation; the low-angle silhouettes alone bridge this concavity.
edge=.29+.31*np.clip((Z-.31)/.42,0,1)
profile=np.interp(Z,[.11,.18,.28,.34,.48,.65,.72,.77,.84],[.98,.96,.935,.895,.855,.87,.90,.91,.845])
taper=np.clip((X+.98)/.28,0,1)*np.clip((edge+.015-X)/.03,0,1)
depth=.14*np.clip((X+.39)/.95,0,1)*np.clip((Z-.27)/.12,0,1)*np.clip((.73-Z)/.10,0,1)
limit=1.015*(1-taper)+(profile-depth)*taper
# Preserve mirrors mounted above the door belt; both tracks are physically narrower than the mirror span.
s=np.minimum(s,np.where((Z<.79)|(X<-.84)|(X>-.37),limit-ay,1))
# Remove the low-camera ghost of the wing and the fender-mounted mirrors. Programmed assemblies replace them.
s=np.minimum(s,np.where((X>1.6)&(Z>1.003),1.003-Z,1.))
s=np.minimum(s,np.where((X>-.89)&(X<-.28)&(Z>.81),.829-ay,1.))
# Pull the intake surfaces into the front fascia. Shape and preserve a physical lip around all three ducts.
frontPolys=[[(271,256),(306,266),(337,273),(340,283),(332,295),(330,316),(274,315)],[(315,269),(357,277),(401,282),(443,283),(487,280),(534,273),(559,267),(543,289),(523,300),(516,319),(357,320),(350,313),(337,291)]]
frontPolys.append([(880-u,w) for u,w in frontPolys[0]])
mi=np.zeros((450,900),'uint8')
for poly in frontPolys:cv.fillPoly(mi,[np.array(poly,'int32')],1)
field=cv.distanceTransform(mi,cv.DIST_L2,5)
before=s.copy();xf=x[:,None,None];Y2,Z2=np.meshgrid(y,z,indexing='ij')
for i,xx in enumerate(x):
 if xx> -1.76:break
 p3=np.stack([np.full_like(Y2,xx),Y2,Z2],axis=-1).reshape(-1,3)
 uv,_=project(p3,K,R[28],C[28]);depth=.105*np.clip(at(field,uv*.6).reshape(Y2.shape)/7,0,1)
 target_index=(i-depth/step).clip(0,len(x)-1);lo=target_index.astype(int);frac=target_index-lo
 iy,iz=np.ogrid[:len(y),:len(z)]
 s[i]=before[lo,iy,iz]*(1-frac)+before[lo+1,iy,iz]*frac
# Clip the wheel solids to create open wheelhouses for independently editable rolling assemblies.
for k,ax in enumerate(wheelX):
 rr=wheelZ[k]+.014
 carved=np.maximum(np.sqrt((X-ax)**2+(Z-wheelZ[k])**2)-rr,.615-ay)
 s=np.minimum(s,carved)
# Most stereo observations converge on the deck. Isolate the high wing for a separate aero assembly.
s=gaussian_filter(s,.85)
for dim in range(3):
 for edge in (0,-1):
  sl=[slice(None)]*3;sl[dim]=edge;s[tuple(sl)]=-.08
verts,faces,_,_=marching_cubes(s,0,spacing=(step,step,step),allow_degenerate=False)
verts+=np.array([x[0],y[0],z[0]]);faces=faces[:,::-1].copy()
verts,faces=fast_simplification.simplify(verts,faces,target_count=75000)
geo=trimesh.Trimesh(verts,faces,process=False)
if geo.volume<0:geo.invert()
# Remesh long triangles for sampling fine exterior details, independent of the geometric simplification.
verts,faces=trimesh.remesh.subdivide_to_size(geo.vertices,geo.faces,max_edge=.026,max_iter=7)
geo=trimesh.Trimesh(verts,faces,process=True)
pieces=geo.split(only_watertight=False);pieces=[m for m in pieces if len(m.faces)>80];geo=trimesh.util.concatenate(pieces)
verts,faces,normals=[np.ascontiguousarray(a) for a in (geo.vertices,geo.faces,geo.vertex_normals)]
print('mesh',len(verts),len(faces),geo.bounds,flush=True)
ctx=moderngl.create_standalone_context(backend='egl')
pr=ctx.program(vertex_shader="""#version 330
in vec3 p;uniform mat4 m;out float depthZ;void main(){gl_Position=m*vec4(p,1);depthZ=gl_Position.w;}""",fragment_shader="""#version 330
in float depthZ;out float val;void main(){val=depthZ;}""")
buf=ctx.buffer(verts.astype('f').tobytes());fb=ctx.framebuffer(ctx.texture((1500,750),1,dtype='f4'),ctx.depth_renderbuffer((1500,750)));vao=ctx.simple_vertex_array(pr,buf,'p',index_buffer=ctx.buffer(faces.astype('i').tobytes()))
ctx.enable(moderngl.DEPTH_TEST);fb.use()
K,R,C,t=pose(p);colors=[];weights=[]
for i in range(30):
 im=load(i)[:,:,[2,1,0]]
 cam=np.vstack([np.column_stack([R[i],t[i]]),[0,0,0,1]])
 fx,fy=K[0,0],K[1,1];cx,cy=K[:2,2]
 S=np.array([[2*fx/1500,0,2*cx/1500-1,0],[0,-2*fy/750,1-2*cy/750,0],[0,0,1.0002,-.20002],[0,0,1,0]])
 pr['m'].write((S@cam).T.astype('f').tobytes());fb.clear();vao.render()
 depth=np.frombuffer(fb.read(components=1,dtype='f4'),dtype='f4').reshape(750,1500)[::-1]
 xy,d=project(verts,K,R[i],C[i]);seen=at(depth,xy)
 dir=C[i]-verts;dir/=np.linalg.norm(dir,axis=1)[:,None];dot=np.einsum('ij,ij->i',normals,dir)
 weight=np.maximum(dot,.005)**4*np.exp(-np.minimum(np.abs(seen-d),.12)*160)
 rgb=at(im,xy);weights.append(weight);colors.append(rgb)
w=np.stack(weights,axis=1);rgb=np.stack(colors,axis=1)
# Normalize the four most frontal, unoccluded observations. Accumulate in sRGB to preserve dark trim.
idx=np.argpartition(w,-4,axis=1)[:,-4:];a=np.arange(len(w))[:,None];ww=w[a,idx]**1.8
c=np.einsum('ni,nij->nj',ww/(ww.sum(axis=1,keepdims=True)+1e-40),rgb[a,idx]);maximum=w.max(axis=1)
vx,vy,vz=verts.T;ay=np.abs(vy)
# Locations unseen by the low studio camera ring are bounded using the official overhead hood and engine-cover details.
unseen=maximum<.00008;roof=(vx>-.56)&(vx<.37)&(vz>1.04)&(ay<.68)
rear=(vx>.36)&(vx<1.65)&(ay<(.61-.095*(vx-.4)))&(vz>.92)
def stripe(val):
 return np.broadcast_to(val,(len(vx),3))
c=np.where((unseen&(vz>.53))[:,None],[177,19,24],c)
c=np.where((unseen&(vz<.53))[:,None],[24,25,27],c)
c=np.where((roof&(normals[:,2]>.50)&((maximum<.01)|(ay<.53)))[:,None],[39,40,45],c)
c=np.where((rear&(normals[:,2]>.55))[:,None],np.where((ay<.045)[:,None],[42,41,43],[36,43,44]),c)
wing=(vx>1.56)&(vz>1.065);c[wing]=np.clip(c[wing].mean(axis=1)[:,None]*.38+17,18,54)
well=np.zeros(len(vx),bool)
for ax,r in zip(wheelX,wheelZ):well |= (ay>.605)&(np.hypot(vx-ax,vz-r)<r+.026)
c[well]=[20,20,22]
edge3=.29+.31*np.clip((vz-.31)/.42,0,1)
baffle=(np.abs(vx-edge3)<.042)&(vz>.315)&(vz<.72)&(ay>.72)&(ay<.987)&(normals[:,0]<-.32)
c[baffle]=[21,20,23]

# Strong red chroma tags Torch Red fibers; preserve the observed creases but suppress moving studio highlights.
chroma=(c[:,0]-np.maximum(c[:,1],c[:,2]));paint=(chroma>21)&(~wing)
vmean=np.clip((c[:,0]-100)/155,0,1)
c[paint,0]=np.clip(146+vmean[paint]*83,145,229);c[paint,1]=np.clip(c[paint,1]*.35+8,8,74);c[paint,2]=np.clip(c[paint,2]*.35+9,9,76)
# The true high wing is dark carbon at all viewing angles, including its mounts.
glasspart=(~paint)&(vz>.855)&(vx> -1.2)&(vx<.68)&(~roof)&(ay<.86)
np.savez_compressed(ROOT/'skin.npz',v=verts.astype('f'),f=faces.astype('i'),color=c.clip(0,255).astype('uint8'),paint=paint,glass=glasspart)
