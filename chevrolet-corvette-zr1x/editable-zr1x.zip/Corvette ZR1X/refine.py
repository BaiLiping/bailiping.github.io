from calibrate import *
# Full-size offsets measured at enlarged wheel-cap crops, registered to first-pass camera targets.
base=[15.3308606,4435.49441,2.21359570,1.06365083,750.314009,274.262733,-.0960338357,-.0171117368,.9]
K,R,C,t=pose(base)
ids=[1,3,6,7,9,11,18,21,24,26]
dxy=[((8,1),(-2,0)),((0,0),(-21,0)),((0,0),(-10,-1)),((0,0),(-4,0)),((3,-1),(10,-1)),((8,0),(12,0)),((-15,0),(-9,-1)),((-1,0),(4,0)),((7,0),(21,0)),((6,0),(25,0))]
points=[]
for n,(i,dx) in enumerate(zip(ids,dxy)):
 j=i-1
 for k in (0,1):
  v=[wheelX[k],np.sign(C[j,1])*(.926,.935)[k],wheelZ[k]]
  w=(R[j]@v+t[j])@K.T;u=w[:2]/w[2:];points.append((j,k,np.sign(C[j,1]),u+dx[k]))
data=np.load(ROOT/'matches.npz');i,j,a,b=[data[k] for k in ('i','j','a','b')]
a=np.column_stack([a,np.ones(len(a))]);b=np.column_stack([b,np.ones(len(b))])
def residual(p,returns=False):
 K,R,C,t=pose(p[:9]);ra=np.einsum('nij,nj->ni',R[i].transpose(0,2,1),a@np.linalg.inv(K).T);rb=np.einsum('nij,nj->ni',R[j].transpose(0,2,1),b@np.linalg.inv(K).T)
 normal=np.cross(C[j]-C[i],ra);e=np.einsum('ij,ij->i',rb,normal)/np.linalg.norm(normal,axis=1)*p[1]
 h=[]
 for f,k,s,q in points:
  v=[wheelX[k],s*p[9+k],wheelZ[k]]
  u=(R[f]@v+t[f])@K.T;h.extend(u[:2]/u[2:]-q)
 if returns:return np.array(h).reshape(-1,2)
 return np.r_[e,np.repeat(h,5),(p[4]-750)/10,(p[5]-375)/20]
sol=least_squares(residual,np.r_[base,.926,.935],bounds=(np.r_[lower,.77,.77],np.r_[upper,1.,1.]),loss='soft_l1',f_scale=1.3).x
print(sol,residual(sol,True))
(ROOT/'rig.json').write_text(json.dumps(sol[:9].tolist()))
