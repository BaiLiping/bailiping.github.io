"""Sculpted outlet, radiator inlets, body side wishbone and Corvette optics."""
# Query from above for an exact section, avoiding wheel-well/cockpit surfaces.
def surface_z(x,y):
    hit, _, _, _ = tree.ray_cast(Vector((x,y,2)),Vector((0,0,-1)))
    return hit.z if hit is not None else top(x,y)

def grid_surface(name,rows,material,parent):
    count=len(rows[0])
    faces=[(j*count+i,(j+1)*count+i,(j+1)*count+i+1,j*count+i+1)
           for j in range(len(rows)-1) for i in range(count-1)]
    o=mesh(name,[tuple(p) for row in rows for p in row],faces,material,parent)
    for face in o.data.polygons:face.use_smooth=True
    return o

def hood_front(a): return -1.962+.55*a*a
def hood_back(a): return -1.522+.55*a*a
def hood_z(x,y):
    q=np.clip(x-.55*y*y,-2.53,-1.)
    return float(np.interp(q,np.linspace(-2.53,-1,len(panel_data['hood_profile'])),panel_data['hood_profile']))
# The front lip is level across the center of the car. The screen sits below
# its sightline when viewed from road height. The opening narrows at each end.
rows=[];lip_sections=[];rear_rows=[]
for y in np.linspace(-.496,.496,89):
    a=abs(y);end=np.clip((a-.411)/.085,0,1)**1.65;xf=hood_front(a)+.063*end;xb=hood_back(a)-.154*end
    row=[]
    for u in np.linspace(0,1,22):
        xx=xf+.015+(xb-xf-.05)*u
        row.append((xx,y,hood_z(xx,y)+.0028))
    rows.append(row)
    # The visible face is 10 pixels deep at the middle of native ext-029.
    # The blade sweeps rearward and the two edges converge at its corners.
    span=a/.496
    outer=.680+.029*span**1.85
    height=.030*(1-span**5.6)
    lip_sections.append([(xf-.017,y,outer-.004),(xf-.024,y,outer),
                         (xf-.019,y,outer+height*.46),(xf-.009,y,outer+height),
                         (xf+.006,y,outer+height+.001),(xf+.020,y,outer+height-.003),
                         (xf+.018,y,outer-.006)])
    rear_rows.append([(xb-.038,y,hood_z(xb-.038,y)+.004),(xb-.018,y,hood_z(xb-.018,y)+.005),(xb-.010,y,hood_z(xb-.010,y)+.003)])
grid_surface('Hood air-extractor floor',rows,airbox,hood)
loft('Carbon hood outlet lip',lip_sections,carbon,hood)
grid_surface('Extractor back screen',rear_rows,return_wall,hood)
for sign in [-1,1]:
    sections=[]
    for x in np.linspace(-1.91,-1.26,46):
        t=(x+1.91)/.65;y=sign*(.258+.084*t);bottom=hood_z(x,y)
        target=.711+.049*(x+1.91)
        height=max(0,target-bottom)*np.clip((x+1.91)/.10,0,1)+.003*np.sin(pi*t)
        half=.001+.0055*np.sin(pi*t)
        sections.append([(x,y-half,bottom+.001),(x,y-half*.22,bottom+height+.002),(x,y+half*.22,bottom+height+.002),(x,y+half,bottom+.001)])
    loft('Painted extractor divider',sections,bumper_paint,hood)
# Top hatch spine has four stepped louver blades around the split backlight.
for j,xstart in enumerate([.66,.875,1.085,1.295]):
    rows=[]
    for y in np.linspace(-(.143-.015*j),(.143-.015*j),15):
        row=[]
        for u in np.linspace(0,1,8):
            xx=xstart+.154*u;row.append((xx,y,surface_z(xx,y)+.004+.022*np.sin(pi*u*.86)))
        rows.append(row)
    grid_surface('Engine cover spine louver',rows,bumper_paint,hatch)
for side_sign in [-1,1]:
    rows=[]
    for xx in np.linspace(.63,1.41,23):
        yy=side_sign*(.457-.21*(xx-.63))
        rows.append([(xx,yy,surface_z(xx,yy)+.004),(xx,yy+side_sign*.037,surface_z(xx,yy+side_sign*.037)+.003)])
    grid_surface('Backlight louver surround',rows,carbon,hatch)
    for xx in [.68,.85,1.02,1.19]:
        yy=side_sign*(.462-.21*(xx-.63)); rows=[]
        for u in np.linspace(0,1,5):
            x1=xx+.069*u;y1=yy-side_sign*.074*u
            rows.append([(x1,y1,surface_z(x1,y1)+.014),(x1+.031,y1,surface_z(x1+.031,y1)+.009)])
        grid_surface('Quarter hatch louver',rows,return_wall,hatch)
# The wishbone is an airfoil around the side inlet. The thin leading spear
# mounts to the door, with the deeper trailing arm attached to the rear quarter.
for side_sign in [-1,1]:
    upper=[(-.035,.779,.777),(.04,.784,.766),(.20,.773,.738),(.36,.762,.706),
           (.48,.756,.686),(.581,.753,.655),(.66,.753,.674),(.79,.768,.697),(.91,.781,.725),
           (.97,.789,.752),(1.012,.790,.782)]
    xs=[p[0] for p in upper]
    for subset,parent in [(upper[:5],doors[side_sign]),(upper[4:],body)]:
        rows=[]
        for xx in np.linspace(subset[0][0],subset[-1][0],44):
            zt=np.interp(xx,xs,[p[1] for p in upper]);zb=np.interp(xx,xs,[p[2] for p in upper])
            width=np.interp(xx,xs,[.903,.914,.936,.955,.969,.988,.995,1.001,1.0,1.001,.994])
            t=np.clip((xx+.035)/1.047,0,1)
            # The outer face bridges the opening. The top folds back into
            # the painted shoulder and the rear tip tapers to a single point.
            edgewidth=.007+.006*np.sin(pi*t)
            section=[]
            for u,delta in [(0,edgewidth),(.075,edgewidth+.0015),(.25,.0055),(.56,.001),(.83,.0005),(.96,.002),(1,.001)]:
                zz=zt*(1-u)+zb*u
                yy=width+delta
                section.append(np.array((xx,side_sign*yy,zz))-np.array(parent.location))
            rows.append(section)
        grid_surface('Carbon side inlet upper blade',rows,carbon,parent)
    rows=[]
    for zz in np.linspace(.326,.677,46):
        t=(zz-.326)/.351
        xx=.296+.322*np.clip((zz-.282)/.416,-.08,1.14)
        blade_width=.001+.018*t**.83
        yface=float(np.interp(zz,panel_data['side_z'],panel_data['side_y']))+.0025
        # An almost flush knife edge at the sill broadens into the cast fork.
        rows.append([(xx+.003+u*blade_width,side_sign*(yface+off*t),zz)
                      for u,off in [(0,.001),(.19,.004),(.84,.0044),(1,.001)]])
    grid_surface('Wishbone vertical inlet lip',rows,carbon,body)
    # Upper quarter cooling opening, tucked into the crest above the rear fender.
    rows=[]
    for xx in np.linspace(.58,1.20,34):
        length=(xx-.58)/.62;mid=.76+.08*length;hw=.052*np.sin(pi*length)**.67
        rows.append([(xx,side_sign*(mid+hw*u),surface_z(xx,side_sign*(mid+hw*u))+.004) for u in np.linspace(-1,1,8)])
    grid_surface('Rear brake cooling scoop',rows,return_wall,body)

# Pixel polylines are registered to each actual fascia. They are subdivided
# into contiguous strips. No fan crosses the cutouts in a boomerang optic.
def strip(name,edge1,edge2,cam,mat,parent,offset=.005):
    def sampled(poly,t):
        q=np.asarray(poly,float);L=np.r_[0,np.cumsum(np.linalg.norm(np.diff(q,axis=0),axis=1))];t*=L[-1];return np.array([np.interp(t,L,q[:,i]) for i in range(2)])
    rows=[]
    for t in np.linspace(0,1,41):
        a,b=sampled(edge1,t),sampled(edge2,t)
        rows.append([ray(a*(1-u)+b*u,cam,offset) for u in np.linspace(0,1,7)])
    return grid_surface(name,rows,mat,parent)
chrome=mat('Optic vacuum metallization','a6aab0',.8,.22)
bezel=mat('Headlamp black bezel','1b2025',.22,.21)
light_pipe=mat('Light guide polycarbonate','d4dcdd',.2,.24)
lens=mat('Clear aerodynamic lens','778890',.02,.085);lens.use_backface_culling=False
lens.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.095
def bounded_optic(name,polygon,cam,finish,parent,push):
    from mathutils.geometry import tessellate_polygon
    points=[Vector((u,w,0)) for u,w in polygon]
    faces=tessellate_polygon([points])
    uv=np.array(polygon,float);triangles=[uv[indices,:] for indices in map(list,faces)]
    for _ in range(3):
        refined=[]
        for a,b,c in triangles:
            ab=(a+b)/2;bc=(b+c)/2;ca=(c+a)/2
            refined.extend([[a,ab,ca],[ab,b,bc],[ca,bc,c],[ab,bc,ca]])
        triangles=refined
    vertices=[ray(uv,cam,push) for tri0 in triangles for uv in tri0]
    obj=mesh(name,vertices,np.arange(len(vertices)).reshape(-1,3).tolist(),finish,parent)
    for poly in obj.data.polygons:poly.use_smooth=True
    return obj
def lens_normals(obj,front):
    vectors=[]
    for vertex in obj.data.vertices:
        x,y,z=vertex.co
        direction=Vector((-.35+.15*(x+1.8),(.24+.66*abs(y))*y,1)) if front else Vector((1,.59*y,.12))
        vectors.append(tuple(direction.normalized()))
    obj.data.normals_split_custom_set_from_vertices(vectors)
exec(compile((ROOT/'front_optics.py').read_text(),str(ROOT/'front_optics.py'),'exec'))
exec(compile((ROOT/'rear_optics.py').read_text(),str(ROOT/'rear_optics.py'),'exec'))

def offset_ray(uv,cam,depth):
    p=np.array(ray(uv,cam,0))
    p[0]+=depth
    return p
def honeycomb(name,polys,cam,parent,depth,step,material):
    def inside(p,polygon):
        x,y=p; result=False
        for a,b in zip(polygon,polygon[1:]+polygon[:1]):
            if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:result=not result
        return result
    vertices=[];faces=[]
    for polygon in polys:
        poly=[Vector(q) for q in polygon]
        coords=np.array(polygon);mi,ma=coords.min(0),coords.max(0)
        dx,dy=step
        for j,cy0 in enumerate(np.arange(mi[1]+dy,ma[1],dy*1.55)):
            for cx0 in np.arange(mi[0]+dx+(j%2)*dx,ma[0],dx*2):
                corners=[(cx0+u*dx,cy0+w*dy) for u,w in [(-.55,-1),(.55,-1),(1,0),(.55,1),(-.55,1),(-1,0)]]
                if not all(inside(p,poly) for p in corners):continue
                ring=np.array([offset_ray(p,cam,depth) for p in corners])
                inn=ring.mean(axis=0)+(ring-ring.mean(axis=0))*.84
                n=len(vertices)
                vertices.extend(ring);vertices.extend(inn);vertices.extend(inn+[np.sign(depth)*.010,0,0])
                for k in range(6):
                    h=(k+1)%6;faces.extend([(n+k,n+h,n+6+h,n+6+k),(n+6+k,n+6+h,n+12+h,n+12+k)])
    if faces:mesh(name,vertices,faces,material,parent)
center=[(318,270),(356,279),(399,284),(442,285),(484,282),(531,275),(561,269),(549,286),(534,291),(517,320),(510,323),(360,323),(352,318),(338,293)]
outer=[(275,257),(307,265),(338,275),(342,279),(333,292),(333,314),(328,319),(276,314)]
def reflection(poly,axis):return [(2*axis-x,y) for x,y in poly]
honeycomb('Center radiator grille honeycomb',[center],fcam,bumper,.052,(8.,3.2),dark)
honeycomb('Side radiator grille honeycomb',[outer,reflection(outer,440)],fcam,bumper,.044,(7.,3.),dark)
def rail(name,points,cam,depth,r,material,parent):
    route=[]
    for a,b in zip(points,points[1:]):
        route.extend([offset_ray((1-t)*np.array(a)+t*np.array(b),cam,depth) for t in np.linspace(0,1,7,endpoint=False)])
    route.append(offset_ray(points[-1],cam,depth))
    return path(name,route,r,material,parent)
# Solid painted bumper crossbar above the open hexagonal radiator grille.
bridge_top=[(274,254),(296,261),(324,269),(352,276),(386,281),(417,283),(442,284),(466,283),(500,279),(532,273),(562,264),(587,256),(607,253)]
bridge_bottom=[(274,260),(297,268),(323,273),(343,281),(367,287),(393,292),(418,295),(442,296),(466,295),(493,292),(517,286),(540,282),(562,273),(585,266),(607,259)]
beam_face=mat('Molded grille bridge graphite','36383b',.15,.46)
strip('Molded carbon bumper crossbar',bridge_top,bridge_bottom,fcam,beam_face,bumper,.011)
for u in [368,394,443,490,516]:
    top_v=np.interp(u,[360,390,443,490,523],[277,281,284,281,274])
    low_v=np.interp(u,[360,390,443,490,523],[284,291,297,291,284])
    line_on('Grille bridge molded joint',[(u,top_v+1),(u+1,low_v-1)],fcam,airbox,.0017,bumper,.015)
for side_sign in [-1,1]:
    def mfront(p):return p if side_sign<0 else reflection(p,440)
    for topedge,bottomedge in [([(344,281),(370,286),(386,289)],[(344,283),(369,290),(386,291)]),
                               ([(367,289),(382,293),(395,314),(400,321)],[(371,289),(386,293),(401,312),(405,321)])]:
        strip('Grille support web',mfront(topedge),mfront(bottomedge),fcam,carbon,bumper,.004)
rail('Front bumper upper grille bridge',[(307,266),(357,276),(399,282),(442,283),(484,281),(532,273),(570,265)],fcam,-.006,.012,carbon,bumper)
rail('Center grille intermediate beam',[(344,282),(369,291),(403,297),(444,300),(483,296),(515,289),(544,280)],fcam,.012,.010,carbon,bumper)
for side_sign in [-1,1]:
    def mir(poly):return poly if side_sign<0 else reflection(poly,444)
    for y in [230,237,244]:
        rail('Rear air outlet guide vane',mir([(266,y),(300,y+1),(335,y+2),(344,y+3)]),backcam,-.024,.005,carbon,tail)
    # Diffuser forms an actual recessed black tray and a hexagonal center exhaust bezel.
    rail('Diffuser lower side sill',mir([(269,299),(275,305),(319,304),(338,282),(378,281)]),backcam,-.024,.014,carbon,tail)
    rail('Diffuser corner wall',mir([(267,263),(265,275),(267,302)]),backcam,-.006,.013,carbon,tail)
for side_sign in [-1,1]:
    def front_side(p):return p if side_sign<0 else reflection(p,440)
    for yy in [274,283,293,303,312]:
        rail('Front outer inlet vane',front_side([(276,yy-1),(288,yy),(307,yy+2),(329,yy+2)]),fcam,.022,.0038,carbon,bumper)
    rail('Lower diffuser shelf',(lambda p:p if side_sign<0 else reflection(p,444))([(272,286),(282,287),(315,287),(337,285),(381,283)]),backcam,-.062,.010,carbon,tail)
exhaust_poly=[(379,301),(388,284),(495,284),(506,303),(498,311),(389,311),(379,301)]
rail('Quad exhaust carbon surround',exhaust_poly,backcam,-.008,.011,carbon,tail)
for xx in [407,431,455,479]:
    center=np.asarray(ray((xx,298),backcam,-.006))
    sections=[]
    for longitudinal,radius in [(-.075,.047),(-.005,.051),(.011,.053),(.018,.051),(.017,.046),(-.064,.044)]:
        sections.append([center+[longitudinal,radius*cos(t),radius*sin(t)] for t in np.linspace(0,2*pi,49)])
    grid_surface('Rolled titanium outlet',sections,lip,tail)
    ring=[center+[-.052,.044*cos(t),.044*sin(t)] for t in np.linspace(0,2*pi,48,endpoint=False)]
    mesh('Tail pipe inner bore',ring,[tuple(range(48))],airbox,tail)
plate=mat('Gray license plate','64686a',.17,.38)
patch('Rear license plate',[(411,206),(474,206),(474,235),(411,235)],backcam,plate,tail,.009)
line_on('Center brake light',[(390,179),(498,179)],backcam,ruby,.004,tail,.009)
# Parked central shark fin and the crossed flag emblem, visible in front and profile references.
rows=[]
for yy in [-.010,.010]:
    rows.append([(xx,yy,surface_z(xx,yy)+dz) for xx,dz in [(.37,.002),(.45,.048),(.54,.067),(.56,.052),(.557,.003)]])
loft('Roof antenna fin',rows,graphite_roof,hatch)
