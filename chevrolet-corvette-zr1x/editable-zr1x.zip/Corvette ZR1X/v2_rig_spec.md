# 2027 Chevrolet Corvette ZR1X (v2) — Rig, Naming, Explode & Module Contract

Authoritative interface contract for bringing `https://bailiping.com/chevrolet-corvette-zr1x/` up to the `build-photo-matched-cars` standard (modeled on `porsche-911-gt3` at commit `c3b4824`). All 3D builders, camera calibration scripts, and the web viewer **must** follow this spec verbatim.

---

## 1. Target Configuration & Authoritative Dimensions

- **Vehicle**: 2027 Chevrolet Corvette ZR1X Coupe (`1YS07`), 3LZ, US-market LHD
- **Exterior**: Torch Red (`GKZ`), visible carbon-fiber removable roof panel (`C2Z`), Torch Red upper mirror caps w/ Satin Black base, black dorsal camera fin, dark `ZR1X` / `CORVETTE` badges (`EFR`/`EYT`)
- **Aero**: ZR1 Carbon Fiber Aero (`TOM`) / ZTK Track Performance (`FEJ`) — high rear wing on twin stanchions, front dive planes (canards), extended front carbon splitter, carbon side skirts (`CFV`), flow-through front hood w/ carbon extractor lip, split rear window w/ louvered carbon spine, rear hatch intake scoops
- **Wheels / Tyres / Brakes**: 20-spoke Carbon Flash (`SOJ`) forged aluminum (20×10" F, 21×13" R); Michelin Pilot Sport Cup 2 R ZP — `275/30ZR20` F (`Ø 673 mm`, `r = 0.3365 m`), `345/25ZR21` R (`Ø 706 mm`, `r = 0.3530 m`); J59 Alcon brakes — 420 mm (16.5") carbon-ceramic rotors F/R, 10-piston F / 6-piston R dark monobloc calipers w/ white `CORVETTE` script
- **Cabin**: 3LZ Jet Black (`HTE`) — redesigned 2026/2027 3-screen curved cockpit (6.6" left aux + 14" cluster + 12.7" right touchscreen, no C8 wall of buttons), carbon flat-top/bottom wheel w/ `ZR1X` plaque
- **Powertrain (1,250 hp e-AWD)**: Rear `LT7` 5.5L DOHC FPC twin-turbo V8 (1,064 hp, blue intake plenum, 7-stage dry sump) + `MLP` Tremec TR-9080 8-speed DCT (wet dual-clutch + eLSD, 2.91/1.76/1.22/0.88/0.65/0.51/0.40/0.33, Rev 2.63, 5.56:1 effective final drive) + 186 hp front-axle EDU + 1.9 kWh (300V) central tunnel Li-ion battery

| Dimension | Real-world (m) | Viewer 1:18 mm (`×1000/18`) |
| --- | --- | --- |
| Scale factor `S` | `1.000000 m` | `55.555556 u` (`1 u = 18 mm`) |
| Wheelbase `WB` | `2.723` (axles `±1.3615`) | `151.28 u` (axles `±75.64 u`) |
| Front / Rear track | `1.685` / `1.678` (`±0.8425` / `±0.8390`) | `93.61` / `93.22 u` (`±46.81` / `±46.61 u`) |
| Overall length `L` (incl. ZTK aero) | `4.860` (`4.722` body w/ carbon aero) | `270.00 u` (`262.33 u` body) |
| Width excl. / incl. mirrors `W` | `2.024` / `2.145` | `112.44` / `119.17 u` |
| Roof / ZTK wing height `H` | `1.234` / `1.285` | `68.56` / `71.39 u` |
| Front / Rear tyre loaded radius | `0.3365` / `0.3530` | `18.69` / `19.61 u` |

---

## 2. Coordinate Systems & Exact Conversion Formulas

### Canonical V2 Frames
1. **Blender Master (`ZR1X_v2.blend`) — Real-world meters, ISO/SAE Z-up**:
   - `+X_b` = **Forward** (toward front nose)
   - `+Y_b` = **Left** (US driver side)
   - `+Z_b` = **Up** (ground contact plane `Z_b = 0`)
   - Origin `(0, 0, 0)` on the ground plane midway between front (`X_b = +1.3615`) and rear (`X_b = -1.3615`) axles, on the vehicle centerline (`Y_b = 0`).
2. **Exported GLB (`corvette_zr1x_2027.glb`) — 1:18-scale millimetres, glTF Y-up (`viewer-page.md` standard)**:
   - Export via Blender `export_scene.gltf(..., export_yup=True, export_apply=True, export_draco_mesh_compression_enable=True, export_draco_mesh_compression_level=6, export_draco_position_quantization=14, export_draco_texcoord_quantization=14)` after uniformly scaling the export copy by `S = 1000 / 18 = 55.5555555556` and applying scale cleanly so every node exports with `scale = [1, 1, 1]`.
   - `+X_g =  S * X_b` (**Forward**)
   - `+Y_g =  S * Z_b` (**Up**, ground `Y_g = 0`)
   - `+Z_g = -S * Y_b` (**Right**; driver / left side is `-Z_g`)

### Exact Conversion From Legacy & Reference Sources
- **From legacy `corvette_zr1x_work` scripts / `ZR1X.blend`** (meters; `+X_old` tail, `-Y_old` left, `+Z_old` up):
  - To V2 Blender (m): `(X_b, Y_b, Z_b) = (-X_old, -Y_old, +Z_old)` *(180° Z rotation, right-handed)*
  - To V2 glTF (1:18 mm): `(X_g, Y_g, Z_g) = (-S * X_old, +S * Z_old, +S * Y_old)`
- **From `Car_Photos` reference GLB (`2025_chevrolet_corvette_zr1.glb`, reference-only!)** (`0.01× m`; `+Z_ref` fwd, `+Y_ref` up, `+X_ref` left):
  - To V2 Blender (m): `(X_b, Y_b, Z_b) = (+100 * Z_ref, +100 * X_ref, +100 * Y_ref)` *(right-handed; shift `Z_b` by `+0.0049 m` so tyres touch `Z_b = 0`)*
  - To V2 glTF (1:18 mm): `(X_g, Y_g, Z_g) = (+100 * S * Z_ref, +100 * S * Y_ref, -100 * S * X_ref)`
  - *Do not copy reference-only divergences*: 2025 2-screen dash, top-only engine shell, 10-spoke wheels, tan Brembo calipers, `ZR1` badge, black mirror caps, protruding underbody strakes, yellow paint.

---

## 3. Complete `Pivot_*` Rig Hierarchy & Hinge Specs

Every top-level assembly and articulated panel is a Blender `EMPTY` named `Pivot_*` with identity rotation and unit scale. All child meshes are stored in their parent pivot's local space. **No mesh sits directly under scene root.**

```text
ZR1X_Interactive_Rig                  (optional scene root at origin, scale 1)
├── Pivot_Drivetrain_Chassis          (anchored at [0,0,0] — NEVER moves on explode)
│   └── Spaceframe rails, central spine tunnel, front/rear aluminum cradles,
│       underfloor aero pan, SLA upper/lower control arms, coilover springs/dampers,
│       anti-roll bars, front/rear half-shafts & CV boots, steering rack,
│       front radiators, side heat exchangers, fuel tanks, frunk tub
├── Pivot_Body_Assembly               (body shell, fixed fascias, windshield, fixed quarter glass,
│   │                                  wishbone quarter lip, headlamps, taillamps, front splitter,
│   │                                  front dive planes/flics, carbon side skirts, rear diffuser,
│   │                                  wipers, dorsal camera fin, badges)
│   ├── Pivot_Door_L                  (hinged L door + drop glass + L mirror + door card + wishbone spear)
│   ├── Pivot_Door_R                  (hinged R door + drop glass + R mirror + door card + wishbone spear)
│   ├── Pivot_Front_Hood              (hinged flow-through front hood + carbon extractor lip + dividers)
│   ├── Pivot_Rear_Hatch              (hinged coupe rear engine hatch + split window glass + carbon spine louvers)
│   ├── Pivot_Roof_Panel              (removable C2Z visible carbon targa roof + headliner + Torch Red cant rails)
│   ├── Pivot_Fuel_Flap               (hinged L rear-quarter fuel filler flap)
│   └── Pivot_ZTK_Wing                (high carbon rear wing blade + twin stanchions + strakes + endplates)
├── Pivot_Interior_Cabin              (floor carpet, rear bulkhead + cabin window, 3-screen dash,
│                                      console/bridge, GT2 seats, steering column/wheel, pedals,
│                                      interior rearview mirror [Mat_Cabin_Rearview])
├── Pivot_LT7_Engine                  (crankcase/7-stage dry sump, V8 banks/heads/cam covers, coils,
│                                      blue plenum + CORVETTE LT7 plaque, runners/fuel rails,
│                                      twin maniturbos/volutes/heat shields, charge coolers/piping,
│                                      flywheel/starter ring gear, front belt/pulleys)
├── Pivot_DCT_Transaxle               (MLP Tremec TR-9080 8-speed DCT:
│   │                                  separable outer casing `ZR1X_DCT_Case_*` +
│   │                                  internal wet dual-clutch, concentric input/counter shafts,
│   │                                  8 forward + rev helical gearsets, eLSD diff, oil pan, mechatronic cover)
├── Pivot_Front_EDU                   (186 hp front-axle e-AWD unit:
│                                      separable housing `ZR1X_EDU_Case_*` + stator/rotor +
│                                      internal reduction gearset/diff + inverter/3-phase HV orange leads)
├── Pivot_Hybrid_Battery              (1.9 kWh 300V central tunnel pack:
│                                      tray, separable top cover `ZR1X_Battery_Cover_*`,
│                                      4 cell module stacks, busbars, electronics bay, HV orange interconnects)
├── Pivot_Exhaust_System              (left/right turbo downpipes, catalytic converters, crossover/muffler box,
│                                      valved quad center-exit pipes & rolled titanium tips)
├── Pivot_Corner_FL                   (steering knuckle/upright + hub + J59 10-piston Alcon caliper)
│   └── Pivot_WheelSpin_FL            (420 mm drilled CCB rotor + 20" SOJ wheel + lugs + cap + 275/30ZR20 tyre)
├── Pivot_Corner_FR                   (steering knuckle/upright + hub + J59 10-piston Alcon caliper)
│   └── Pivot_WheelSpin_FR            (420 mm drilled CCB rotor + 20" SOJ wheel + lugs + cap + 275/30ZR20 tyre)
├── Pivot_Corner_RL                   (rear upright + hub + J59 6-piston Alcon caliper)
│   └── Pivot_WheelSpin_RL            (420 mm drilled CCB rotor + 21" SOJ wheel + lugs + cap + 345/25ZR21 tyre)
└── Pivot_Corner_RR                   (rear upright + hub + J59 6-piston Alcon caliper)
    └── Pivot_WheelSpin_RR            (420 mm drilled CCB rotor + 21" SOJ wheel + lugs + cap + 345/25ZR21 tyre)
```

> **Why SLA control arms, coilovers, and half-shafts live in `Pivot_Drivetrain_Chassis`**: Matches GT3 (`porsche_911_gt3_992_2.glb`) so `S` steering rotates ONLY `Pivot_Corner_FL/FR` (knuckle + caliper + `Pivot_WheelSpin_*`) about the real wheel/kingpin `+Y` axis without swinging control arms through the fenders, while explode pulls the wheel corners outward to reveal the wishbones, coilovers, and CV half-shafts anchored cleanly to the rolling chassis.

### Concrete Pivot Coordinates & Articulation Table

All coordinates in **V2 Blender meters** `(X_b, Y_b, Z_b)` and **V2 glTF 1:18 mm** `(X_g, Y_g, Z_g)`. Body-child pivots are positioned in **world coordinates** here (set their local location relative to `Pivot_Body_Assembly`, which sits at `(0, 0, 0)`).

| Pivot Node | World Pos — V2 Blender (m) | World Pos — V2 glTF (1:18 mm) | Viewer Action (`panels` / rig) | Controls Key |
| --- | --- | --- | --- | --- |
| `Pivot_Drivetrain_Chassis` | `(0.000, 0.000, 0.000)` | `(0.00, 0.00, 0.00)` | Anchored (fixed) | — |
| `Pivot_Body_Assembly` | `(0.000, 0.000, 0.000)` | `(0.00, 0.00, 0.00)` | Lifts on explode | `E` |
| `Pivot_Door_L` | `(+0.930, +0.840, +0.640)` | `(+51.67, +35.56, -46.67)` | `axis: 'y', angle: -1.10` (`-63°`, swings left `-Z`) | `D` / `1` |
| `Pivot_Door_R` | `(+0.930, -0.840, +0.640)` | `(+51.67, +35.56, +46.67)` | `axis: 'y', angle: +1.10` (`+63°`, swings right `+Z`) | `D` / `2` |
| `Pivot_Front_Hood` | `(+1.055, 0.000, +0.805)` | `(+58.61, +44.72, 0.00)` | `axis: 'z', angle: +0.96` (`+55°`, rear-hinged, nose lifts `+Y`) | `F` |
| `Pivot_Rear_Hatch` | `(-0.375, 0.000, +1.205)` | `(-20.83, +66.94, 0.00)` | `axis: 'z', angle: -0.92` (`-53°`, front-hinged, tail lifts `+Y`) | `L` |
| `Pivot_Roof_Panel` | `(0.000, 0.000, +1.190)` | `(0.00, +66.11, 0.00)` | `lift: [0, 26, 0]` (targa top smoothly lifts `+26 u` straight up) | `T` *(roof)* |
| `Pivot_Fuel_Flap` | `(-0.645, +0.950, +0.830)` | `(-35.83, +46.11, -52.78)` | `axis: 'y', angle: -1.48` (`-85°`, front-hinged on L quarter, opens `-Z`) | `G` |
| `Pivot_ZTK_Wing` | `(-1.900, 0.000, +1.050)` | `(-105.56, +58.33, 0.00)` | Fixed to body when closed; detaches on explode | — |
| `Pivot_Corner_FL` | `(+1.3615, +0.8425, +0.3365)` | `(+75.64, +18.69, -46.81)` | Steer: `rotation.y += steerRad` (`±0.44 rad`) | `S` |
| `Pivot_Corner_FR` | `(+1.3615, -0.8425, +0.3365)` | `(+75.64, +18.69, +46.81)` | Steer: `rotation.y += steerRad` (`±0.44 rad`) | `S` |
| `Pivot_Corner_RL` | `(-1.3615, +0.8390, +0.3530)` | `(-75.64, +19.61, -46.61)` | Rear corner (non-steering) | — |
| `Pivot_Corner_RR` | `(-1.3615, -0.8390, +0.3530)` | `(-75.64, +19.61, +46.61)` | Rear corner (non-steering) | — |
| `Pivot_WheelSpin_*` | `(0, 0, 0)` local to `Pivot_Corner_*` | `(0, 0, 0)` local | Spin: `rotation.z -= wheelSpinAngle` (rolls forward `+X`) | `W` |
| `Pivot_Interior_Cabin` | `(0.000, 0.000, 0.000)` | `(0.00, 0.00, 0.00)` | Moves fwd-left on explode | — |
| `Pivot_LT7_Engine` | `(-0.820, 0.000, +0.520)` | `(-45.56, +28.89, 0.00)` | Lifts up & aft on explode | — |
| `Pivot_DCT_Transaxle` | `(-1.520, 0.000, +0.410)` | `(-84.44, +22.78, 0.00)` | Slides aft on explode; `DCT_Case_*` lifts off gearset | — |
| `Pivot_Front_EDU` | `(+1.3615, 0.000, +0.350)` | `(+75.64, +19.44, 0.00)` | Slides fwd-right on explode; `EDU_Case_*` lifts off gears | — |
| `Pivot_Hybrid_Battery` | `(+0.380, 0.000, +0.280)` | `(+21.11, +15.56, 0.00)` | Lifts up out of central spine tunnel on explode | — |
| `Pivot_Exhaust_System` | `(-1.650, 0.000, +0.320)` | `(-91.67, +17.78, 0.00)` | Slides aft below DCT on explode | — |

*(Note: verify `Pivot_Front_Hood` and `Pivot_Rear_Hatch` hinge X/Z against the final photo-matched cowl and roof-header seam lines before export so closed-to-open clearance never clips the A-pillars or rear quarters.)*

---

## 4. Mesh & Material Naming Contract

### Mesh Names (`ZR1X_<Group>_<Part>[_<Side>]`)
Use ASCII letters, digits, and underscores only (no spaces, no trailing `.001` collisions on functional parts). Merge tiny identical fasteners/clips into logical part meshes to target **~250–450 clean meshes** (down from 1,553).

| Subsystem | Required Mesh Name Prefixes |
| --- | --- |
| Body / Exterior | `ZR1X_Body_Shell`, `ZR1X_Body_Quarter_*`, `ZR1X_Front_Fascia`, `ZR1X_Front_Splitter`, `ZR1X_Front_DivePlane_L/R`, `ZR1X_Front_Grille_*`, `ZR1X_Front_Intake_*`, `ZR1X_Side_Skirt_L/R`, `ZR1X_Side_Wishbone_L/R`, `ZR1X_Rear_Fascia`, `ZR1X_Rear_Diffuser`, `ZR1X_Rear_DiffuserStrake_*`, `ZR1X_Rear_Plate`, `ZR1X_Badge_*`, `ZR1X_Roof_Fin`, `ZR1X_Wiper_L/R` |
| Openings / Aero | `ZR1X_Door_Shell_L/R`, `ZR1X_Door_Handle_L/R`, `ZR1X_Door_Card_L/R`, `ZR1X_Mirror_Cap_L/R`, `ZR1X_Mirror_Base_L/R`, `ZR1X_Mirror_Glass_L/R`, `ZR1X_Front_Hood`, `ZR1X_Hood_ExtractorLip`, `ZR1X_Hood_Divider_L/R`, `ZR1X_Rear_Hatch`, `ZR1X_Hatch_SpineLouvers`, `ZR1X_Hatch_Scoop_L/R`, `ZR1X_Roof_CarbonPanel`, `ZR1X_Roof_CantRail_L/R`, `ZR1X_Roof_Headliner`, `ZR1X_Fuel_Flap`, `ZR1X_Wing_Mainplane`, `ZR1X_Wing_Endplate_L/R`, `ZR1X_Wing_Stanchion_L/R`, `ZR1X_Wing_Strake_L/R` |
| Glazing & Optics | `ZR1X_Glass_Windshield`, `ZR1X_Glass_Door_L/R`, `ZR1X_Glass_Quarter_L/R`, `ZR1X_Glass_Hatch_L/R`, `ZR1X_Glass_CabinBulkhead`, `ZR1X_Headlight_Clear_Lens_L/R`, `ZR1X_Headlight_Housing_L/R`, `ZR1X_Headlight_DRL_L/R`, `ZR1X_Taillight_Housing_L/R`, `ZR1X_Taillight_Lens_L/R`, `ZR1X_CHMSL` |
| Chassis & Suspension | `ZR1X_Chassis_Spaceframe`, `ZR1X_Chassis_TunnelSpine`, `ZR1X_Chassis_Undertray`, `ZR1X_Chassis_Subframe_F/R`, `ZR1X_Chassis_Radiator_*`, `ZR1X_Chassis_FuelTank_L/R`, `ZR1X_Susp_UpperArm_*`, `ZR1X_Susp_LowerArm_*`, `ZR1X_Susp_Coilover_*`, `ZR1X_Susp_ARB_F/R`, `ZR1X_Drive_Halfshaft_*` |
| Corners & Wheels | `ZR1X_Upright_FL/FR/RL/RR`, `ZR1X_Caliper_Alcon_FL/FR/RL/RR`, `ZR1X_Rotor_CCB_FL/FR/RL/RR`, `ZR1X_Wheel_Barrel_FL/FR/RL/RR`, `ZR1X_Wheel_Spokes_FL/FR/RL/RR`, `ZR1X_Wheel_CenterCap_FL/FR/RL/RR`, `ZR1X_Wheel_LugNuts_FL/FR/RL/RR`, `ZR1X_Tire_FL/FR/RL/RR` |
| LT7 Engine | `ZR1X_Eng_Crankcase`, `ZR1X_Eng_DrySump`, `ZR1X_Eng_Bank_L/R`, `ZR1X_Eng_CamCover_L/R`, `ZR1X_Eng_CoilPack_L/R`, `ZR1X_Eng_IntakePlenum`, `ZR1X_Eng_PlenumPlaque`, `ZR1X_Eng_IntakeRunners`, `ZR1X_Eng_FuelRails`, `ZR1X_Eng_Maniturbo_L/R`, `ZR1X_Eng_ChargePipe_L/R`, `ZR1X_Eng_Flywheel`, `ZR1X_Eng_BeltDrive` |
| DCT Transaxle (`MLP`) | `ZR1X_DCT_Case_Main`, `ZR1X_DCT_Case_Bellhousing`, `ZR1X_DCT_Case_Tail`, `ZR1X_DCT_Case_OilPan`, `ZR1X_DCT_Case_Mechatronic`, **`ZR1X_DCT_Int_DualClutch`**, **`ZR1X_DCT_Int_InputShafts`**, **`ZR1X_DCT_Int_CounterShafts`**, **`ZR1X_DCT_Int_GearSet_*`**, **`ZR1X_DCT_Int_eLSD`** |
| Front EDU & Battery | `ZR1X_EDU_Case_Motor`, `ZR1X_EDU_Case_Gearbox`, `ZR1X_EDU_Inverter`, `ZR1X_EDU_HVCables`, **`ZR1X_EDU_Int_StatorRotor`**, **`ZR1X_EDU_Int_ReductionGears`**, **`ZR1X_EDU_Int_FrontDiff`**, `ZR1X_Battery_Tray`, `ZR1X_Battery_Cover_Top`, `ZR1X_Battery_Electronics`, **`ZR1X_Battery_Int_Modules`**, `ZR1X_Battery_HVCables` |
| Exhaust | `ZR1X_Exh_Downpipe_L/R`, `ZR1X_Exh_Cat_L/R`, `ZR1X_Exh_Muffler`, `ZR1X_Exh_Tailpipes`, `ZR1X_Exh_Tips` |
| Cabin | `ZR1X_Cabin_Tub`, `ZR1X_Cabin_Carpet`, `ZR1X_Cabin_Bulkhead`, `ZR1X_Cabin_Dash`, `ZR1X_Cabin_DisplayAux`, `ZR1X_Cabin_DisplayCluster`, `ZR1X_Cabin_DisplayCenter`, `ZR1X_Cabin_Console`, `ZR1X_Cabin_SteeringWheel`, `ZR1X_Cabin_SeatShell_L/R`, `ZR1X_Cabin_SeatCushion_L/R`, `ZR1X_Cabin_Pedals`, `ZR1X_Cabin_RearviewMirror` |

### Viewer Regexes & Material Hooks
- `EXTERIOR_RE`: `/Body_|Front_Fascia|Front_Splitter|Front_DivePlane|Front_Grille|Front_Intake|Side_Skirt|Side_Wishbone|Rear_Fascia|Rear_Diffuser|Rear_Plate|Badge_|Roof_Fin|Wiper_|Door_Shell|Door_Handle|Mirror_|Front_Hood|Hood_|Rear_Hatch|Hatch_|Roof_CarbonPanel|Roof_CantRail|Fuel_Flap|Wing_|Glass_|Headlight_|Taillight_|CHMSL|DCT_Case_|EDU_Case_|Battery_Cover_/`
- `SHADOW_CASTER_RE`: `/Body_Shell|Body_Quarter|Front_Fascia|Front_Splitter|Rear_Fascia|Rear_Diffuser|Door_Shell|Front_Hood|Rear_Hatch|Roof_CarbonPanel|Wing_Mainplane|Wing_Endplate|Wing_Stanchion|Mirror_|Tire_|Eng_Crankcase|Exh_Muffler|Chassis_Undertray/`
- `ENCLOSED_INTERNALS_RE` *(replaces GT3 `enclosedGearbox` — hidden while assembled & X-ray off for FPS, exposed on explode / X-ray / pull / detail Compare)*: `/_(DCT|EDU|Battery)_Int_/`
- **Standardized Material Names** (clean parametric PBR — **no** baked visual-hull `Surface tone` vertex colors on exterior paint):
  - `Mat_Torch_Red_GKZ` (deep vivid Torch Red `#c81016`, clearcoat 0.72, clearcoatRoughness 0.06, roughness 0.22)
  - `Mat_Carbon_Twill_2x2` (exposed 2×2 carbon twill with clearcoat for roof, aero, split-window spine, wishbone)
  - `Mat_Glass_Windshield`, `Mat_Glass_Door`, `Mat_Glass_Quarter`, `Mat_Glass_Hatch` (hooked to GT3 Fresnel glazing shader)
  - `Mat_Headlight_Clear_Lens` (hooked to GT3 clear aerodynamic lens shader, `renderOrder = 2`)
  - `Mat_Cabin_Rearview` (hooked to `mirror-reflection.js` planar cabin mirror)
  - `Mat_Wheel_CarbonFlash_SOJ`, `Mat_CCB_Rotor_J59`, `Mat_Caliper_Alcon_Black`, `Mat_LT7_Plenum_Blue`, `Mat_HV_Orange`

---

## 5. Exploded-View Offset Contract (1:18 mm Viewer Units)

Satisfies every rule of `references/viewer-page.md#exploded-layout`:
- **Chassis anchored** (`Pivot_Drivetrain_Chassis = [0, 0, 0]`).
- **Body lift**: `108 u` = **`1.58 H_roof`** (target ~1.5 H; GT3 is 1.55 H).
- **Compact total exploded box** (verified with all `partOffset`s applied): **`496 u × 224 u × 307 u`** = **`1.84 L × 0.83 L × 1.14 L`** (target ≤ 2.0 L × 1.0 L × 1.3 L; GT3 is 1.85 L × 0.87 L × 1.20 L).
- **Max assembly travel**: `0.62 L` (limit ≤ 0.75 L).
- **Pairwise 3D AABB overlaps**: **0** across all 19 assemblies.

### `getExplodeOffset(name, ex)` (Parent-Frame Offsets in 1:18 mm)

| Pivot | Parent | Local Offset `(x, y, z)` | World Travel `÷ L` | Removal Logic |
| --- | --- | --- | --- | --- |
| `Pivot_Drivetrain_Chassis` | root | `(0, 0, 0)` | `0.00` | Anchors floor & shadow |
| `Pivot_Body_Assembly` | root | `(0, 108, 0)` | `0.40` | Straight up (`1.58 H`) |
| `Pivot_Door_L` | Body | `(-14, -4, -92)` | `0.52` | Outward left (`0.82 W`) |
| `Pivot_Door_R` | Body | `(20, 22, 96)` | `0.60` | Asymmetric right clear of cabin |
| `Pivot_Front_Hood` | Body | `(42, 42, 0)` | `0.58` | Up & forward off frunk |
| `Pivot_Roof_Panel` | Body | `(0, 48, 0)` | `0.58` | Straight up off targa opening |
| `Pivot_Rear_Hatch` | Body | `(-32, 38, 0)` | `0.55` | Up & aft off engine bay |
| `Pivot_Fuel_Flap` | Body | `(-4, 8, -22)` | `0.44` | Outward left off L quarter |
| `Pivot_ZTK_Wing` | Body | `(-64, 34, 0)` | `0.58` | Up & aft off rear deck |
| `Pivot_Interior_Cabin` | root | `(152, 46, -54)` | `0.62` | Forward & left, clear of body |
| `Pivot_Front_EDU` | root | `(104, 18, 46)` | `0.43` | Forward & right off front axle |
| `Pivot_Hybrid_Battery` | root | `(8, 34, 0)` | `0.13` | Straight up out of center tunnel |
| `Pivot_LT7_Engine` | root | `(-44, 36, 0)` | `0.21` | Up & aft out of mid-engine bay |
| `Pivot_DCT_Transaxle` | root | `(-84, 24, 0)` | `0.32` | Aft off LT7 bellhousing |
| `Pivot_Exhaust_System` | root | `(-146, -2, 0)` | `0.54` | Aft below DCT |
| `Pivot_Corner_FL` / `RL` | root | `(0, 0, -42)` | `0.16` | Outward left (`0.37 W`) |
| `Pivot_Corner_FR` | root | `(0, 0, 44)` | `0.16` | Outward right (`0.39 W`) |
| `Pivot_Corner_RR` | root | `(-24, 0, 46)` | `0.19` | Outward right & slightly aft |

### `partOffset(mesh)` (Sub-Part Separations in 1:18 mm)

| Parent Pivot | Mesh Regex | Offset `(x, y, z)` |
| --- | --- | --- |
| `Pivot_WheelSpin_*` (`side = L ? -1 : 1`) | `/Tire_/` | `(0, 0, side * 44)` |
| `Pivot_WheelSpin_*` | `/Wheel_CenterCap\|Wheel_LugNuts/` | `(0, 0, side * 54)` |
| `Pivot_WheelSpin_*` | `/Wheel_Spokes/` | `(0, 0, side * 18)` |
| `Pivot_Body_Assembly` | `/Headlight_\|Front_Grille\|Front_Intake\|Front_Splitter\|Front_DivePlane/` | `(22, 0, 0)` |
| `Pivot_Body_Assembly` | `/Taillight_\|Rear_Diffuser\|DiffuserStrake/` | `(-22, 0, 0)` |
| `Pivot_Body_Assembly` | `/Glass_Windshield\|Glass_Quarter\|Wiper_/` | `(0, 16, 0)` |
| `Pivot_Door_*` | `/Glass_Door/` | `(0, 16, 0)` |
| `Pivot_LT7_Engine` | `/Eng_IntakePlenum\|Eng_PlenumPlaque/` | `(0, 22, 0)` |
| `Pivot_LT7_Engine` | `/Eng_IntakeRunners\|Eng_FuelRails/` | `(0, 10, 0)` |
| `Pivot_DCT_Transaxle` | `/DCT_Case_/` | `(-14, 18, 16)` *(reveals `DCT_Int_*` gears/clutch/eLSD)* |
| `Pivot_Front_EDU` | `/EDU_Case_/` | `(12, 16, 12)` *(reveals `EDU_Int_*` reduction gears)* |
| `Pivot_Hybrid_Battery` | `/Battery_Cover_/` | `(0, 14, 0)` *(reveals `Battery_Int_Modules`)* |
| `Pivot_Exhaust_System` | `/Exh_Muffler\|Exh_Tips/` | `(-16, 0, 0)` |
| `Pivot_Interior_Cabin` | `/Cabin_SteeringWheel/` | `(2, 10, -16)` |
| `Pivot_Interior_Cabin` | `/Cabin_Dash\|Cabin_Display/` | `(14, 6, 0)` |
| `Pivot_Interior_Cabin` | `/Cabin_SeatCushion/` | `(0, 10, 0)` |

---

## 6. Viewer Retuning & Views-Tab Data Contract

### Starting Viewer Constants (1:18 mm)
- `FOCUS_EXTERIOR`: `(2.0, 36.0, 0.0)`, `TOP_CENTER`: `(0.0, 35.0, 0.0)`, `REAR_CENTER`: `(-34.0, 33.0, 0.0)`
- `exteriorView`: default front-left 3/4 matching calibrated `view-00` (or `deg01` front-left 3/4), retuned after camera calibration (`radius ≈ 310` at 30° equiv).
- `FOCUS_INTERIOR`: `(50.0, 38.0, -6.0)`, `cabinRadius = 46`, driver eye near `(+8.0, +48.2, -21.6)` (derived from Chevrolet `HTE` panorama registration, mirrored in Z to `-Z` left).
- `buildSpecimenFloor()` contact shadows: `axle of [-65, 65]`, `side of [-40, 40]`, underbody ovals scaled `1.06×` from GT3.
- Toolbar: **exactly 4 controls** — `Exploded view`, `Cabin view`, `Controls`, `Reset`. Strip all GT3-only items (Transmission dialog/button, clutch-pedal button, Engine/Transmission lab tabs, carbon-stripe toggle, rev audio).
- Tabs: `#model` ("3D model") and `#chevrolet-views` ("Chevrolet views"), event `match-chevrolet-view`, function `matchChevroletView`.

### `chevrolet-views.json` Schema (Studio + Detail Extension)
Use the `viewer-page.md` detail-frame list-of-objects schema so studio (`Exterior`) and mechanical/cabin (`Powertrain`, `Interior`) frames live in one ordered array (`?frame=N&compare=1#chevrolet-views` indexes the full list):
```json
[
  {
    "id": "view-00",
    "label": "Front-left 24°",
    "image": "./chevrolet-views/view-00.webp?v=...",
    "group": "Exterior",
    "credit": "Images © General Motors / Chevrolet",
    "source": "https://www.chevrolet.com/performance/corvette/zr1x",
    "width": 1500,
    "height": 750
  }
]
```
- `referenceViews` in `index.html` keys by exact `label` string and carries `{theta, phi, radius, fov, center}` plus optional detail-frame extras: `roll`, `panels`, `hide`, `isolate`, `background`.
- Every `view-NN` (360° turntable + 2500×1407 `deg01`–`deg07` ZTK renders) and every usable detail photo gets a calibrated camera in `cameras.json` with both `solved` and `viewer` forms (`radius = d * tan(fov/2) / tan(15°)`).

---

## 7. Disjoint Module & File Ownership Plan

Worktree: `/home/bailiping/Desktop/corvette_zr1x_work/site_v2` (branch `corvette-zr1x-v2` off `origin/main` `c3b4824`). Do **not** edit `/home/bailiping/Desktop/bailiping.github.io` (`main`), `/home/bailiping/Desktop/corvette_zr1x_work/site`, or `/assets/car-studio/`.

| Track / Owner | Exclusive Files Owned | Deliverable |
| --- | --- | --- |
| **1. References & Cameras** (`ref-scout` / calibrator) | `corvette_zr1x_work/refs_v2/*`, `corvette_zr1x_work/v2/inventory.json`, `corvette_zr1x_work/v2/cameras.json` | Strict-schema `inventory.json`, 2500×1407 ZTK renders + cutaways, calibrated `cameras.json` (`solved` + `viewer` poses) |
| **2. Exterior, Aero, Optics & Glazing** (exterior builder) | `corvette_zr1x_work/v2/ext_body.py`, `ext_closures.py`, `ext_aero.py`, `ext_optics.py`, `ext_glazing.py`, `ext_details.py` | Photo-matched Torch Red shell, ZTK wing/splitter/dive planes, flow-through hood, split rear window, wishbone, lamps, glass, hinged closures under `Pivot_Body_Assembly` |
| **3. Chassis, Exhaust, Powertrain & Corners** (mech builder) | `corvette_zr1x_work/v2/mech_chassis.py`, `mech_lt7.py`, `mech_dct.py`, `mech_edu_battery.py`, `mech_exhaust.py`, `mech_corners.py` | Spaceframe/subframes/SLA/coilovers/half-shafts (`Pivot_Drivetrain_Chassis`), LT7, `MLP` DCT w/ separable case + internals, front EDU w/ internals, tunnel battery, full quad exhaust, `Pivot_Corner_*` + `Pivot_WheelSpin_*` |
| **4. Cabin & Master Assembly/Export** (cabin + rig integrator) | `corvette_zr1x_work/v2/cabin_build.py`, `corvette_zr1x_work/v2/materials.py`, `corvette_zr1x_work/v2/build_v2.py` | 2027 3-screen Jet Black 3LZ cabin (`Pivot_Interior_Cabin`); master assembler writing meter-scale `ZR1X_v2.blend` and 1:18-mm Draco `corvette_zr1x_2027.glb` + automated rig/unit/naming validator |
| **5. Web Page & Site Integration** (page builder) | `site_v2/chevrolet-corvette-zr1x/*`, `site_v2/index.html`, `site_v2/cars/*`, `site_v2/site-map/*`, `site_v2/sitemap.xml` | Self-contained GT3-standard page (`index.html`, `studio.js`, `studio.css`, `mirror-reflection.js`, `vendor/*`, `chevrolet-views.json`, `chevrolet-views/*.webp`, `corvette_zr1x_2027.glb`); retire legacy `review.html`/`assembly.js`/`captures/`; run `scripts/build-cars-preview.py` & `scripts/build-search-index.py` |
| **6. Verification** (`verifier`) | `corvette_zr1x_work/v2/frames.json`, local `review.html`, scratch screenshots in `<appDataDir>/brain/<id>/` | `build_review.py frames.json --inventory inventory.json --strict` + all 8 `viewer-page.md` acceptance checks (desktop/phone/short-landscape/reduced-motion + Compare sweep on every frame) |
