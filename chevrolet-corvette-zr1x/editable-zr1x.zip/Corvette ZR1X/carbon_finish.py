"""Meter-scaled, clear-coated twill on the exposed carbon exterior panels."""
import math
import re

def apply_exterior_carbon():
    # Four tows across a 12 mm repeat. A row of two over / two under advances by
    # one tow on the next row. This gives the diagonal characteristic of a 2×2 twill.
    side_px = 128
    repeat_m = .012
    gy, gx = (np.mgrid[:side_px,:side_px] + .5) * (4 / side_px)
    horizontal = (np.floor(gx).astype(int) - np.floor(gy).astype(int)) % 4 < 2
    across = np.where(horizontal, gy, gx)
    along = np.where(horizontal, gx, gy)
    crown = np.sin(pi * (across % 1)) ** .58
    filaments = np.cos(2*pi*across*7)
    # Small height variations give the resin-impregnated cloth an uneven
    # underlying surface. The transparent finish retains its own smooth specular lobe.
    tow_lift = crown * (.77+.23*np.cos(pi*(along - np.floor(across) + .5)/2))
    height = .000039 * tow_lift + .0000017 * filaments * crown
    du = (np.roll(height,-1,axis=1)-np.roll(height,1,axis=1)) / (2*repeat_m/side_px)
    dv = (np.roll(height,-1,axis=0)-np.roll(height,1,axis=0)) / (2*repeat_m/side_px)
    normals = np.stack((-du, -dv, np.ones_like(du)), axis=-1)
    normals /= np.linalg.norm(normals,axis=-1,keepdims=True)
    shade = (36 + 5*horizontal + 8*crown + 2*filaments*crown)/255
    albedo = np.stack((shade*.97, shade*.985, shade), axis=-1)
    roughness = .302 + .009*crown - .012*horizontal

    fin = mat('Exposed carbon aero · 2x2 twill', '2b2d2f', .04, .30)
    nt = fin.node_tree
    bsdf = nt.nodes.get('Principled BSDF')
    bsdf.inputs['Coat Weight'].default_value = .68
    bsdf.inputs['Coat Roughness'].default_value = .17
    bsdf.inputs['Specular IOR Level'].default_value = .47

    def packed_map(name, pixels, space):
        tex = bpy.data.images.new(name,width=side_px,height=side_px,alpha=False)
        tex.colorspace_settings.name = space
        rgba = np.concatenate([pixels,np.ones((side_px,side_px,1))],axis=2)
        tex.pixels.foreach_set(rgba.astype('f').ravel())
        tex.pack()
        sampler = nt.nodes.new('ShaderNodeTexImage')
        sampler.image = tex
        sampler.extension = 'REPEAT'
        sampler.interpolation = 'Linear'
        return sampler.outputs['Color']

    nt.links.new(packed_map('Exterior twill albedo',albedo,'sRGB'),bsdf.inputs['Base Color'])
    nt.links.new(packed_map('Exterior twill roughness',np.repeat(roughness[:,:,None],3,axis=2),'Non-Color'),
                 bsdf.inputs['Roughness'])
    normal = nt.nodes.new('ShaderNodeNormalMap')
    normal.inputs['Strength'].default_value=.42
    nt.links.new(packed_map('Exterior twill normal',normals*.5+.5,'Non-Color'),normal.inputs['Color'])
    nt.links.new(normal.outputs['Normal'],bsdf.inputs['Normal'])

    # Set weave orientation over each large continuous panel. The secondary
    # chart is used only on the sharply folded edges perpendicular to that panel.
    top_parts = {
        'Carbon rear wing blade','Front carbon splitter','Roof panel surface',
        'Carbon hood outlet lip','Backlight louver surround'
    }
    side_parts = {
        'Aero wing endplate','Wing aero strake','Carbon rocker blade','Carbon rocker blade right',
        'Carbon side inlet upper blade','Wishbone vertical inlet lip','Rising bumper flic'
    }
    bpy.context.view_layer.update()
    for obj in sc.objects:
        basename = re.sub(r'\.\d{3}$','',obj.name)
        if obj.type!='MESH' or basename not in top_parts|side_parts:
            continue
        me=obj.data
        if len(me.materials)!=1 or me.materials[0].name not in ('Graphite carbon aero','Visible carbon roof'):
            continue
        primary = 2 if basename in top_parts else 1
        transform=np.asarray(obj.matrix_world)
        coords=np.array([tuple(v0.co) for v0 in me.vertices]) @ transform[:3,:3].T + transform[:3,3]
        loop_vertex=np.array([loop.vertex_index for loop in me.loops])
        uv=np.empty((len(loop_vertex),2), dtype='f')
        for face in me.polygons:
            normal_abs = np.abs(face.normal)
            axis = primary if normal_abs[primary]>.34 else int(np.argmax(normal_abs))
            axes = ((1,2),(0,2),(0,1))[axis]
            ids = slice(face.loop_start,face.loop_start+face.loop_total)
            flat = coords[loop_vertex[ids]][:,axes]
            # A bias layup, visible on the rocker and inlet close-ups.
            yaw = pi/4
            a,b=flat.T
            uv[ids]=np.column_stack((a*math.cos(yaw)-b*math.sin(yaw),
                                     a*math.sin(yaw)+b*math.cos(yaw)))/repeat_m
        layer=me.uv_layers.new(name='Carbon cloth in metres')
        layer.data.foreach_set('uv',uv.ravel())
        layer.active_render=True
        me.uv_layers.active=layer
        me.materials[0]=fin

apply_exterior_carbon()
