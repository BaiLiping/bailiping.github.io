"""Fit smooth longitudinal sections to the stereo volume before cutting named aero features."""
import numpy as np
from scipy.ndimage import map_coordinates,gaussian_filter,median_filter
def fair_sections(raw,hull,x,y,z,step):
 a=np.arange(360)*np.pi/180;rho=np.arange(0,1.37,.005)
 theta=np.broadcast_to(a[:,None],(len(a),len(rho)))
 yy=np.cos(theta)*rho;zz=.49+np.sin(theta)*rho
 co=np.stack([(yy-y[0])/step,(zz-z[0])/step]);rr=[]
 for j,xx in enumerate(x):
  s=raw[j];h=hull[j]
  # The low oblique rays constrain glass and glossy hood silhouettes better than specular stereo.
  top=(z[None,:]>.76)&(np.abs(y)[:,None]<.91)
  s=np.where(top,.82*h+.18*s,.44*h+.56*s)
  if xx>1.52:s=np.where(z[None,:]>max(.972,1.036-(xx-1.52)*.1),-1,s)
  if -.89<xx<-.28:s=np.where((np.abs(y)[:,None]>.824)&(z[None,:]>.802),-1,s)
  ray=map_coordinates(s,co,order=1,mode='constant',cval=-1)
  rv=np.max(np.where(ray>0,rho,0),axis=1);rr.append(rv)
 rr=np.asarray(rr);rr=.5*(rr+rr[:,(180-np.arange(360))%360])
 rr=median_filter(rr,size=(3,3),mode=('nearest','wrap')) if False else median_filter(np.pad(rr,((0,0),(2,2)),mode='wrap'),size=(3,3))[:,2:-2]
 smooth=gaussian_filter(rr,sigma=(3.2,2.4),mode=('nearest','wrap'))
 # Fair the long panels while retaining coherent creases that span adjacent camera angles.
 corr=np.clip(rr-smooth,-.005,.005);rr=smooth+.35*gaussian_filter(corr,(1.6,1.4),mode=('nearest','wrap'))
 Y,Z=np.meshgrid(y,z,indexing='ij');A=(np.arctan2(Z-.49,Y)*180/np.pi)%360;D=np.hypot(Z-.49,Y)
 idx=A.astype(int);f=A-idx;g=[]
 for j,xx in enumerate(x):
  cross=rr[j][idx]*(1-f)+rr[j][(idx+1)%360]*f-D
  blend=np.clip((xx+2.35)/.24,0,1)*np.clip((2.25-xx)/.18,0,1)
  g.append(cross*blend+raw[j]*(1-blend))
 return np.stack(g).astype('f')
