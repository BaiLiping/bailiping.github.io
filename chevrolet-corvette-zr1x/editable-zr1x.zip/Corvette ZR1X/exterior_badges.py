"""Individual cast-and-enamel exterior marks positioned in the registered views."""
badge_profiles=json.loads((ROOT/'badge-profiles.json').read_text())
badge_face=mat('Black nickel badge face','37383d',.59,.31)
badge_side=mat('Polished badge edge','676a6b',.66,.29)
badge_gold=mat('Bowtie enamel','c7a450',.32,.32)
badge_cream=mat('Flag light checks','e0e0dc',.45,.29)
badge_black=mat('Flag dark checks','141619',.13,.29)
def raised_wordmark(name,shape,mapper,cam,parent,offset):
    vv=[];faces=[];used={}
    def idx(p,depth):
        uv=mapper(*p)
        key=(round(uv[0],4),round(uv[1],4),depth)
        if key not in used:
            used[key]=len(vv)
            vv.append(ray(uv,cam,offset+depth))
        return used[key]
    for triangle in shape['triangles']:
        faces.append([idx(p,.0014) for p in triangle])
    face_count=len(faces)
    for loop in shape['edges']:
        for j,p in enumerate(loop):
            q=loop[(j+1)%len(loop)]
            faces.append((idx(p,0),idx(q,0),idx(q,.0014),idx(p,.0014)))
    ob=mesh(name,vv,faces,badge_face,parent);ob.data.materials.append(badge_side)
    for ff in ob.data.polygons:
        if ff.index>=face_count:ff.material_index=1
        elif np.dot(ff.normal,np.asarray(cam[0])-np.asarray(ff.center))<0:ff.flip()

# The badges read left-to-right on both flanks in Chevrolet's 006 and 021 frames.
for name,cam,u0,v0,width,slope in [('Left',frame_camera(6),946,429,91,-.097),('Right',frame_camera(21),514,426,95,.051)]:
    raised_wordmark(name+' ZR1X nameplate',badge_profiles['model'],
        lambda u,v:((u0+u*width)*.6,(v0+slope*u*width+7.1*v)*.6),cam,body,.006)
raised_wordmark('Corvette rear lettering',badge_profiles['rear'],
    lambda u,v:((651+u*176)*.6,(314.7+6.8*v)*.6),backcam,tail,.010)
# Convert the neutral plate text into raised characters on the local plate plane.
from mathutils import Matrix
pt=Vector(ray((443,220),backcam,.012))
right_dir=(Vector(ray((457,220),backcam,.012))-Vector(ray((429,220),backcam,.012))).normalized()
vertical=(Vector(ray((443,212),backcam,.012))-Vector(ray((443,228),backcam,.012))).normalized()
n=right_dir.cross(vertical).normalized();vertical=n.cross(right_dir).normalized()
cu=bpy.data.curves.new('Embossed plate type','FONT');cu.body='CHEVROLET';cu.size=.025
cu.align_x='CENTER';cu.align_y='CENTER';cu.space_character=1.07;cu.extrude=.0006;cu.materials.append(badge_side)
ob=bpy.data.objects.new('Chevrolet rear show plate lettering',cu);sc.collection.objects.link(ob);ob.parent=tail
ob.location=pt+n*.001;ob.rotation_euler=Matrix((right_dir,vertical,n)).transposed().to_euler()
# Lens of the rear-facing camera and two fasteners in the registration pocket.
for u0,v0,r0,m in [(442,204.5,1.25,badge_black),(415.6,208.7,.64,badge_side),(470,208.7,.64,badge_side)]:
    patch('Rear camera lens' if r0>1 else 'Plate fastener',[(u0+r0*cos(t),v0+r0*sin(t)) for t in np.linspace(0,2*pi,16,endpoint=False)],backcam,m,tail,.014)
def crossed_flags(cam,center,parent,w,h,rotated=False):
    def at(u,v):
        if rotated:return (center[0]-v*h,center[1]+u*w)
        return (center[0]+u*w,center[1]+v*h)
    def field(name,coords,m,lift):
        patch(name,[at(u,v) for u,v in coords],cam,m,parent,lift)
    for sign in (-1,1):
        field('Chrome flag outline',[(0,.54),(sign*.37,.18),(sign*.66,-.045),(sign*.72,-.05),
                   (sign*1.01,-.58),(sign*.43,-.30),(sign*.31,-.26),(0,.08)],badge_side,.012)
        # A bilinear interpolation gives the enamel its curved, tapered outline.
        low=np.array([[sign*.07,.341],[sign*.42,.065],[sign*.71,-.145],[sign*.934,-.487]])
        high=np.array([[sign*.07,.102],[sign*.405,-.220],[sign*.67,-.300],[sign*.934,-.487]])
        for column in range(3):
            for row in range(2):
                def uv(j,v):return high[j]+(low[j]-high[j])*v
                field('Checkered flag enamel' if sign<0 else 'Red flag enamel',
                  [uv(column,row/2),uv(column+1,row/2),uv(column+1,(row+1)/2),uv(column,(row+1)/2)],
                  (badge_black if (column+row)%2 else badge_cream) if sign<0 else red,.0135)
        if sign>0:
            field('Small gold Chevrolet bowtie',[(.39,-.093),(.47,-.132),(.47,-.151),(.53,-.172),(.54,-.154),
                      (.59,-.18),(.584,-.137),(.53,-.108),(.53,-.085),(.47,-.064),(.465,-.081),(.39,-.05)],badge_gold,.0144)
crossed_flags(fcam,(439.2,252.5),bumper,11.6,8.0)
crossed_flags(topcam,(678,207),hatch,10.1,7.8,True)
