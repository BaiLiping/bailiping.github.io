"""Check the review archive and, optionally, compare a clean rebuild to the viewer GLB."""
import argparse
import hashlib
import json
import os
import re
import shutil
import struct
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def model_manifest(path):
    data = path.read_bytes()
    magic, version, length, size, kind = struct.unpack_from('<4sIII4s', data)
    assert (magic, version, length, kind) == (b'glTF', 2, len(data), b'JSON'), path
    gltf = json.loads(data[20:20 + size])
    nodes = gltf['nodes']
    meshes = gltf['meshes']
    materials = gltf['materials']
    accessors = gltf['accessors']
    assert 'KHR_draco_mesh_compression' in gltf['extensionsRequired']

    node_map = {}
    for node in nodes:
        name = node['name']
        assert name not in node_map, name
        node_map[name] = {key: value for key, value in node.items() if key not in ('children', 'mesh', 'name')}
        node_map[name]['children'] = sorted(nodes[i]['name'] for i in node.get('children', []))
        if 'mesh' in node:
            node_map[name]['mesh'] = meshes[node['mesh']]['name']

    mesh_map = {}
    triangles = 0
    for mesh in meshes:
        name = mesh['name']
        assert name not in mesh_map, name
        mesh_map[name] = []
        for primitive in mesh['primitives']:
            assert primitive.get('mode', 4) == 4
            indices = accessors[primitive['indices']]['count']
            assert indices % 3 == 0
            triangles += indices // 3
            material = materials[primitive['material']]['name']
            channels = {semantic: accessors[i] for semantic, i in primitive['attributes'].items()}
            mesh_map[name].append((material, indices, channels))

    scenes = {s['name']: sorted(nodes[i]['name'] for i in s['nodes']) for s in gltf['scenes']}
    return {'scenes': scenes, 'nodes': node_map, 'meshes': mesh_map, 'triangles': triangles,
            'materials': {m['name']: m for m in materials}, 'images': sorted(i['name'] for i in gltf['images'])}


def compare_rebuild(candidate, rebuilt):
    published = model_manifest(candidate)
    reproduced = model_manifest(rebuilt)
    for key, expected in published.items():
        actual = reproduced[key]
        if expected != actual:
            if isinstance(expected, dict) and isinstance(actual, dict):
                different = [name for name in expected.keys() | actual.keys() if expected.get(name) != actual.get(name)]
                raise AssertionError(f'{key} differs for {len(different)} records, including {sorted(different)[:8]}')
            raise AssertionError(f'{key} differs: {expected!r} / {actual!r}')
    print('Rebuild matches', len(published['nodes']), 'nodes,', len(published['meshes']), 'named meshes,',
          published['triangles'], 'triangles,', len(published['materials']), 'materials and',
          len(published['images']), 'embedded images.')
    print('Byte-identical GLB:', candidate.read_bytes() == rebuilt.read_bytes(), flush=True)


def verify_review(public, native, url):
    from PIL import Image
    from playwright.sync_api import sync_playwright

    records = json.loads((public / 'sources.json').read_text())
    original = {entry['id']: entry for entry in json.loads((ROOT / 'inventory.json').read_text())}
    assert len(records) == len(original) == len({r['id'] for r in records})
    assert {r['id'] for r in records} == original.keys()
    model = public / 'zr1x.glb'
    comparisons = json.loads((public / 'comparison.json').read_text())
    assert hashlib.sha256(model.read_bytes()).hexdigest() == comparisons['model_sha256']
    for record in records:
        with Image.open(public / record['tracing']) as image:
            image.verify()
    print('Reference archive contains', len(records), 'images.', Counter(r['status'] for r in records), flush=True)
    with sync_playwright() as playwright:
        executable = os.environ.get('CHROME_PATH') or shutil.which('google-chrome')
        browser = playwright.chromium.launch(executable_path=executable, args=['--no-sandbox', '--disable-dev-shm-usage'])
        context = browser.new_context(viewport={'width': 390, 'height': 844}, service_workers='block')
        context.route(re.compile(r'^https://'), lambda route: route.abort())
        page = context.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        count_ready = "count => document.querySelector('#archive-select')?.options.length === count"
        image_ready = """([src, width]) => {const im = document.querySelector('#archive-image');
            return im.getAttribute('src') === src && im.complete && im.naturalWidth > 0 &&
            (width ? im.naturalWidth === width : document.querySelector('#archive-tag').textContent.includes('tracing'))}"""
        page.goto(url)
        page.wait_for_function(count_ready, arg=len(records))
        for i, record in enumerate(records):
            page.locator('#archive-select').select_option(str(i))
            page.wait_for_function(image_ready, arg=[record['tracing'], None])
        assert page.evaluate('document.documentElement.scrollWidth === innerWidth')
        print('All mobile tracing fallbacks decoded with external requests blocked.', flush=True)
        page.goto(native.resolve().as_uri())
        page.wait_for_function(count_ready, arg=len(records))
        page.wait_for_function("document.querySelector('#photo').complete && document.querySelector('#photo').naturalWidth === 1500")
        for i, record in enumerate(records):
            image = original[record['id']]
            page.locator('#archive-select').select_option(str(i))
            relative = os.path.relpath(ROOT / image['file'], native.parent)
            page.wait_for_function(image_ready, arg=[relative, image['width']])
        assert not errors, errors
        print('All original photographs decoded offline at their recorded width. No browser errors.', flush=True)
        browser.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('public', type=Path, nargs='?', default=ROOT / 'site/chevrolet-corvette-zr1x')
    parser.add_argument('--offline-review', type=Path, default=ROOT / 'audit/review.html')
    parser.add_argument('--url', default=os.environ.get('ZR1X_STUDIO_URL', 'http://127.0.0.1:8726/chevrolet-corvette-zr1x/').rstrip('/') + '/review.html')
    parser.add_argument('--rebuilt', type=Path, help='GLB exported from an independent, extracted source archive')
    parser.add_argument('--model-only', action='store_true', help='Check the rebuild using the Python standard library only')
    args = parser.parse_args()
    if args.model_only and not args.rebuilt:
        parser.error('--model-only requires --rebuilt')
    if args.rebuilt:
        compare_rebuild(args.public / 'zr1x.glb', args.rebuilt)
    if not args.model_only:
        verify_review(args.public, args.offline_review, args.url)
