"""Package native reference comparisons, credits and the editable Blender source bundle."""
from pathlib import Path
from PIL import Image
import json,sys,hashlib,zipfile
root=Path(__file__).resolve().parent;public=Path(sys.argv[1])
data=json.loads((root/'metrics.json').read_text());records=json.loads((root/'inventory.json').read_text())
if hashlib.sha256((public/'zr1x.glb').read_bytes()).hexdigest()!=data['model_sha256']:raise SystemExit('Capture revision mismatch')
notes=[
'The front overhang, front axle and high wing register together. The visible face of the left inlet has a softer return in the model.',
'The rear quarter sits behind the left front wheel at the same scale. The outer front cooling duct has less internal detail.',
'The low cowl, two wheel centers and start of the windscreen agree. The lamp lens has a simpler reflector.',
'The endplate clears the rear deck on the same sightline. The leading shoulder above the front wheel is rounder.',
'The left sill, roof drop and axle spacing agree in this shallow quarter view. The black sidewall markings follow the band above the outer rim.',
'Both left arches closely follow the projected wheel openings. The studio reference has more contrast along the lower door crease.',
'The falling coupe roof and rising rear haunch align in profile. Fine tire tread is simplified.',
'The contour follows the left rear quarter into the wing supports. The carbon diffuser has fewer small surface details.',
'The height of the rear deck and its sweep into the left fender agree. The model has a simpler outboard tail lamp.',
'The central four tips and both left tail lamps are visible. The plate recess in the model reads flatter.',
'The wing crosses above the split backlight at the same height. The rim flange and the carbon-ceramic rotor sit at different depths behind the spokes.',
'The rear bumper and outer lights line up with the back of the left tire. The lower diffuser has a smoother transition.',
'The left stanchion and rear wheel reveal constrain the yaw. The tip lips and lower fins have simplified cross-sections.',
'The four outlets share a centerline and the paired lamp groups span the rear. Branches of the diffuser are approximate.',
'The near rear tire and outer edge of the wing are visible. The outer tail lamp contours are simplified.',
'The right rear haunch blends into the side intake. Diffuser depth under the right corner has limited coverage.',
'The two wing supports clear the deck. The reference carries more relief around the rear registration plate.',
'The arc of the right rear fender and the roof-to-deck slope align. Five lug wells and the forked wheel webs can be compared in the close-up.',
'The curve of the sill and visible right wheelbase follow the studio frame. Brake and tread materials differ under the two lighting rigs.',
'The near hub spacing and lower edge of the side glass agree. The mirror is broader through its base.',
'Both right wheel openings and the roofline can be followed directly. The inlet lip has a softer return at its lower endpoint.',
'Roof height, arch spacing and rocker height are consistent in this right-side frame. The raised corner flic follows the lower sill in projection.',
'The long hood and rear-deck proportions agree from this side. The inner headlamp guides have simplified facets.',
'The windscreen rake and near front wheel align. The inset across the door is shallower through its middle.',
'The front opening and center splitter span the same nose. Individual cells in the grille are approximate.',
'The visible right inlet is bounded by the carbon wishbone. Its rear-facing return catches more light than the studio reference.',
'The two lamp positions converge correctly toward the nose. The raised carbon flic crosses the lower edge of the outer cooling duct.',
'The front corner and right rear tire set the camera yaw. Exact headlamp projector reflections depend on studio lighting.',
'The head-on frame checks the hood outlet, glass width and outer cooling apertures. The internal grille pattern is simplified.',
'The left mirror and both headlamps locate the front face. The lower lip and fender opening are softer at this angle.',
'Chevrolet’s Blade Silver coupe has the low rear aero configuration. The high wing on the Torch Red model remains installed. The independent plan view sets the windshield, hood outlets and split backlight positions.',
'The 90° forward camera uses the Jet Black panorama. The three displays, crossed-flags wheel, narrow selector bridge and carpeted tunnel share the factory sightline. Fine upholstery, display iconography and reflections are approximations.',
'Chevrolet’s yellow ZTK coupe is closest to the camera. Its wheel hubs, mirrors, nose and wing ends register this independent photo. The track car has different wheels, body finish and safety equipment. Lens contours and wing endplates retain visible differences.'
]
(public/'review.html').write_bytes((root/'review-template.html').read_bytes())
bounds=json.loads((root/'dimensions.json').read_text())
data['dimensions_mm']={
    'panel_width':round(1000*bounds['painted body panels']['span'][1]),
    'panel_length':round(1000*bounds['painted body panels']['span'][0]),
    'overall_length':round(1000*bounds['whole']['span'][0]),
    'overall_height':round(1000*bounds['whole']['span'][2]),
}
assert len(notes)==len(data['frames'])
profile={5,6,7,8,18,19,20,21,22}
for i,(d,note) in enumerate(zip(data['frames'],notes),1):
 d['status']='verified' if i in profile else 'limited';d['note']=note;d['revision']=data['model_sha256'][:12]
matched_ids = {frame['id'] for frame in data['frames']}
seen_hashes = {}
for r in records:
 rid = r['id']
 r['tracing'] = f'captures/{rid}-reference.webp' if rid in matched_ids else f'reference-tracings/{rid}.webp'
 if rid.startswith('cabin-'): r['subject'] = 'Jet Black cabin panorama, ' + rid.removeprefix('cabin-') + ' face'
 if rid == 'press-27': r['subject'] = 'Overhead front of the black ZR1X with a red stripe'
 if rid == 'detail-31': r['subject'] = 'Interview portrait'
 if r['sha256'] in seen_hashes: r['duplicate_of'] = seen_hashes[r['sha256']]
 else: seen_hashes[r['sha256']] = rid
 q=next((q for q in data['frames'] if q['id']==r['id']),None)
 if q:r['status']=q['status'];r['note']=q['note']
 elif r.get('note') and r['kind'] in ('Factory engineering','Chevrolet track photography'):r['status']='limited'
 elif r['kind']=='cabin panorama':r['status']='limited';r['note']='Jet Black panorama face used for cabin layout. A matching camera and capture are available for the forward face.'
 elif r['id'] in ['detail-03','detail-04','detail-22','detail-31']:r['status']='excluded';r['note']={'detail-31':'Person portrait. It supplies no vehicle geometry.','detail-03':'Person portrait.','detail-04':'Different Z06 interior and trim.','detail-22':'Chevrolet identifies the pictured engine as the LT6.'}[r['id']]
 elif r['kind']=='manufacturer gallery' and ('Convertible' in r['subject'] or 'Seating with' in r['subject']):r['status']='excluded';r['note']='Different body or upholstery configuration. Accessory details only.'
 else:r['status']='limited';r['note']='Supporting Chevrolet detail or alternate-configuration press image. No calibrated whole-car comparison recorded.'
(public/'comparison.json').write_text(json.dumps(data,indent=2));(public/'sources.json').write_text(json.dumps([{k:v for k,v in r.items() if k!='file'} for r in records],indent=2))
# Model-rendered poster, photographed camera, independent of the reference files.
im=Image.open(root/'renders/home.png').convert('RGB');im.save(public/'poster.webp',quality=91,method=4)
archive = public / 'editable-zr1x.zip'
temporary = archive.with_suffix('.zip.tmp')
with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=5) as z:
 for name in ['bodywork.py','exterior_details.py','front_optics.py','rear_optics.py','glazing.py','exterior_badges.py','badge_profiles.py','badge-profiles.json','fit_panels.py','body-panels.npz','rolling_gear.py','propulsion.py','suspension.py','seats.py','cabin_structure.py','carbon_finish.py','mirrors.py','ring-high-camera.json','steering.py','dash.py','cabin_trim.py','fit_cabin.py','cabin-camera.json','capture.py','compare.py','archive.py','reference_contours.py','handoff.py','final_handoff.py','verify_archive.py','review-template.html','ZR1X.blend','build.py','details.py','saved_cameras.py','acquire.py','calibrate.py','refine.py','stereo.py','hull.py','section_fit.py','surfaces.py','planview.py','normals.py','refine_materials.py','manifest.py','instruments.py','measure.py','finalskin.npz','smoothed_normals.npy','rig.json','plan_camera.json','dimensions.json','Driver display.png','Infotainment.png','Hybrid readout.png','inventory.json','README.txt']:
  z.write(root/name,'Corvette ZR1X/'+name)
 for name in ['comparison.json','studio.json','sources.json','assembly.js']:z.write(public/name,'Corvette ZR1X/'+name)
temporary.replace(archive)
