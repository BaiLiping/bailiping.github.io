"""Cabin shell and trim formed around the Jet Black panorama, seats and display fascia."""
pan_finish=mat('Graphite floor pan','303238',.18,.53)
rear_trim=mat('Jet Black rear partition','27292c',.01,.68)
dash_leather=mat('Jet Black instrument leather','2d2e31',.01,.58)
seam_thread=mat('Instrument thread','6a6a6b',.01,.71)
vent_shadow=mat('Air outlet interior','121418',.005,.88)

def cabin_skin(name, rows, material, thickness):
    """Thin continuous molding with a closed edge around the opening."""
    cols=len(rows[0])
    faces=[(j*cols+i,(j+1)*cols+i,(j+1)*cols+i+1,j*cols+i+1)
           for j in range(len(rows)-1) for i in range(cols-1)]
    obj=mesh(name,[point for row in rows for point in row],faces,material,cab)
    for face in obj.data.polygons:face.use_smooth=True
    wall=obj.modifiers.new('Molding wall thickness','SOLIDIFY')
    wall.thickness=thickness
    return obj

# The door apertures pinch in at the cowl and widen around the two seats.
# Each basin has a curved outer return; the central tunnel passes between them.
floor_sections=[(-.965,.60,.308,.49),(-.88,.645,.257,.46),(-.77,.664,.246,.437),
                (-.60,.677,.243,.415),(-.34,.686,.241,.402),(-.10,.688,.238,.394),
                (.12,.684,.240,.387),(.29,.663,.251,.401),(.402,.617,.30,.449)]
pan_rows=[]
for xx,w,base,crown in floor_sections:
    half=[(0,crown),(.104,crown-.003),(.140,crown-.024),(.161,base+.091),
          (.177,base+.035),(.199,base+.009),(.235,base+.001),(.37,base),
          (w-.111,base+.004),(w-.078,base+.016),(w-.052,base+.043),
          (w-.034,base+.087),(w-.03,base+.128),(w-.019,base+.140),(w,base+.144)]
    cross=[(-y,z) for y,z in reversed(half[1:])]+half
    pan_rows.append([(xx,y,z) for y,z in cross])
cabin_skin('Formed cockpit floor pan',pan_rows,pan_finish,.011)

def make_footwell_carpet(material):
    for sign,side in [(-1,'Driver'),(1,'Passenger')]:
        rows=[]
        for xx,w,base,crown in floor_sections:
            level=.288+max(0,-xx-.79)*.31+max(0,xx-.22)*.13
            profile=[(.166,level+.049),(.18,level+.020),(.202,level+.003),
                     (.25,level),(.43,level),(w-.098,level+.001),
                     (w-.070,level+.011),(w-.045,level+.040),(w-.039,level+.072)]
            rows.append([(xx,sign*y,z) for y,z in profile])
        cabin_skin(side+' molded carpet basin',rows,material,.006)

for sign,side in [(-1,'Driver'),(1,'Passenger')]:
    rows=[]
    for yy,forward in [(.166,-.009),(.19,-.016),(.23,-.023),(.34,-.027),(.50,-.023),
                       (.554,-.015),(.59,.004),(.62,.035),(.647,.072)]:
        # The sloped toe board sits behind the pedals. The outboard kick turns
        # toward the seat as it follows the inside of the front wheelhouse.
        rows.append([(x+forward,sign*yy,z) for x,z in [(-.703,.269),(-.790,.283),(-.836,.31),
                     (-.868,.357),(-.902,.430),(-.927,.518),(-.933,.598),(-.918,.627)]])
    cabin_skin(side+' toe board and kick panel',rows,rear_trim,.009)

# Below the rear light the trim rises from the tunnel into the two shoulders.
# The clear opening and its wrapped surround follow the back panorama.
rows=[]
for yy in np.linspace(-.669,.669,27):
    a=abs(yy)/.669
    lower=.261+.119*math.exp(-(yy/.19)**2)
    shoulder=.760+.093*a**4
    xx=.452-.094*a**3
    rows.append([(xx-.063,yy,lower),(xx-.042,yy,lower+.066),
                 (xx-.014,yy,.49+.03*a),(xx+.014,yy,.609+.04*a),
                 (xx+.020,yy,shoulder-.068),(xx+.021,yy,shoulder-.024),
                 (xx+.043,yy,shoulder),(xx+.076,yy,shoulder+.011)])
cabin_skin('Contoured rear bulkhead trim',rows,rear_trim,.014)

def back_window(y,z):
    return (.491+.172*(z-.78)-.048*(abs(y)/.63)**2,y,z)
rim=[]
for y in np.linspace(-.56,.56,45):
    rim.append(back_window(y,.769+.019*(y/.56)**2))
for t in np.linspace(0,1,9)[1:]:
    rim.append(back_window(.56+.043*sin(pi*t)-.061*t,.788+.265*t))
for y in np.linspace(.499,-.499,41)[1:]:
    rim.append(back_window(y,1.053+.017*(1-(y/.499)**2)))
for t in np.linspace(0,1,9)[1:-1]:
    rim.append(back_window(-(.56+.043*sin(pi*(1-t))-.061*(1-t)),1.053-.265*t))
path('Rear window weatherstrip',rim,.010,rubber,cab,True)
rear_glass=mat('Tinted rear cabin light','536169',.03,.14)
rear_glass.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.24
center=np.mean(np.array(rim),axis=0)
mesh('Rear cabin glazing',[tuple(center)]+rim,[(0,i+1,(i+1)%len(rim)+1) for i in range(len(rim))],rear_glass,cab)
for side in [-1,1]:
    rows=[]
    for t in np.linspace(0,1,13):
        inner=.576+.043*sin(pi*t)-.061*t
        outer=.671-.105*t
        z=.788+.265*t
        rows.append([back_window(side*y,z-dz) for y,dz in [(inner,0),(inner+.009,-.004),
                    ((inner+outer)/2,-.009),(outer,-.008),(outer+.012,.006)]])
    cabin_skin('Rear quarter window surround',rows,rear_trim,.011)

# The reference driver's screen band ends on the passenger side of the tunnel.
# Continue the instrument panel there with the stepped lower vent and glovebox.
dash_stations=[(-.708,-.671,.747,.620),(-.675,-.596,.784,.636),(-.614,-.583,.809,.646),
               (-.55,-.583,.816,.650),(-.43,-.596,.824,.651),(-.30,-.606,.820,.646),
               (-.15,-.622,.815,.634),(0,-.641,.810,.616),(.17,-.664,.799,.601),
               (.24,-.646,.796,.604),(.34,-.632,.793,.611),(.49,-.650,.783,.624),
               (.61,-.680,.770,.642),(.69,-.720,.753,.654)]
def dash_station(y):
    cols=np.array(dash_stations).T
    return [float(np.interp(y,cols[0],col)) for col in cols[1:]]
sections=[]
for yy in np.linspace(-.708,.69,59):
    xx,topline,base=dash_station(yy);w=abs(yy)/.71
    front=-.936+.113*w**2
    sections.append([(xx-.042,yy,topline-.007),(xx-.012,yy,topline-.018),
                     (xx-.011,yy,topline-.057),(xx-.026,yy,base+.018),
                     (xx-.057,yy,base),(front+.072,yy,base+.023),
                     (front+.007,yy,topline-.063),(front+.008,yy,topline-.045)])
carrier=loft('Swept instrument panel carrier',sections,bk,cab)
for poly in carrier.data.polygons:poly.use_smooth=True
# Coordinates on the rear lip of the existing display brow, back-projected
# from its eight panorama stations. The pad returns under that lip.
pad_edge=np.array([(-.708,-.630,.793),(-.692,-.631,.806),(-.630,-.636,.824),
                   (-.574,-.641,.825),(-.387,-.657,.826),(-.194,-.672,.824),
                   (.019,-.687,.822),(.280,-.705,.795),(.39,-.658,.791),
                   (.51,-.654,.780),(.615,-.683,.770),(.69,-.720,.754)])
rows=[]
for yy in np.linspace(-.708,.69,87):
    xx=np.interp(yy,pad_edge[:,0],pad_edge[:,1])+.013
    topline=np.interp(yy,pad_edge[:,0],pad_edge[:,2])-.0015
    w=abs(yy)/.71
    # Bring the front of the pad out to the curved lower windshield gasket.
    front=-1.319+.184*w**1.45
    cowl_height=.764+.019*w**3
    ridge_height=min(topline-.006,.804+.0015*(1-w))
    rows.append([(front,yy,cowl_height),(front+.028,yy,cowl_height+.010),
                 (.77*front+.23*xx,yy,(cowl_height+ridge_height)*.5+.005),
                 (.54*front+.46*xx,yy,ridge_height-.005),
                 (.30*front+.70*xx,yy,ridge_height),
                 (xx-.047,yy,topline-.005),(xx-.023,yy,topline),
                 (xx-.009,yy,topline-.001),(xx-.005,yy,topline-.009),
                 (xx-.007,yy,topline-.016)])
cabin_skin('Padded dashboard upper cover',rows,dash_leather,.006)
for inset in [.023,.030]:
    pts=[]
    for yy in np.linspace(.215,.671,43):
        xx=np.interp(yy,pad_edge[:,0],pad_edge[:,1])+.013
        zz=np.interp(yy,pad_edge[:,0],pad_edge[:,2])-.0015
        pts.append((xx-inset,yy,zz+.0008))
    path('Passenger dashboard twin seam',pts,.0009,seam_thread,cab)
rows=[]
for yy in np.linspace(.207,.667,39):
    xx,z,b=dash_station(yy)
    rows.append([(xx-.014,yy,z-.045),(xx+.010,yy,z-.047),(xx+.014,yy,z-.055),
                 (xx+.013,yy,z-.101),(xx+.003,yy,z-.108),(xx-.028,yy,z-.104)])
cabin_skin('Passenger instrument panel air outlet',rows,vent_shadow,.004)
for dz in [.060,.077,.094]:
    rows=[]
    for yy in np.linspace(.221,.652,31):
        xx,z,_=dash_station(yy);rows.append([(xx+.014,yy,z-dz),(xx+.022,yy,z-dz-.002),(xx+.018,yy,z-dz-.005)])
    cabin_skin('Passenger dashboard outlet vane',rows,dark,.0015)
rows=[]
for yy in np.linspace(.202,.668,37):
    xx,z,b=dash_station(yy)
    rows.append([(xx-.001,yy,z-.108),(xx+.014,yy,z-.111),(xx+.010,yy,z-.119),(xx-.013,yy,z-.124)])
cabin_skin('Passenger dashboard outlet lower trim',rows,metal,.0025)
