from calibrate import *
from scipy.spatial.transform import Rotation
from scipy.spatial import ConvexHull
from PIL import Image,ImageDraw
a=np.load(ROOT/'skin.npz');v=a['v'];x,y,z=v.T;keep=~((x>1.61)&(z>1.003)) & ~((x<-.38)&(x>-.82)&(abs(y)>.89)&(z>.78))
pts=v[keep][::4];ctr=np.array([0,0,.62])
# Outer edge through both fender crowns, fascia corners and rear bumper, measured on the high-view proof.
outline=np.array([[115,230],[119,195],[132,151],[157,115],[186,99],[232,92],[277,98],[293,103],[432,102],[496,83],[570,77],[621,72],[664,76],[696,82],[711,96],[729,123],[747,153],[740,166],[743,238],[751,249],[739,278],[712,324],[696,335],[665,341],[616,355],[579,353],[510,348],[477,347],[427,340],[368,353],[297,349],[250,362],[204,359],[176,347],[154,329],[136,298],[122,266]])
directions=np.column_stack([np.cos(np.arange(0,360,3)*np.pi/180),np.sin(np.arange(0,360,3)*np.pi/180)])
support=(outline@directions.T).max(axis=0)
def top_pose(q):
 cx,cy,D,tx,ty,roll,f=q
 # Rotate a downward-looking camera while retaining car length along horizontal.
 rot=Rotation.from_euler('xyz',[tx,ty,roll],degrees=True).as_matrix()
 rr=np.diag([1,-1,-1])@rot.T;cc=ctr+rr.T@np.array([0,0,-D])
 kk=np.array([[f,0,cx],[0,f,cy],[0,0,1.]])
 return kk,rr,cc
def proj(pts,q):
 kk,rr,cc=top_pose(q);u=((pts-cc)@rr.T)@kk.T;return u[:,:2]/u[:,2:]
def cost(q):
 uv=proj(pts,q);ext=uv[ConvexHull(uv).vertices];s=(ext@directions.T).max(axis=0);return np.r_[s-support,(q[2]-7)*.25,(q[-1]/q[2]-133)*.14]
sol=least_squares(cost,[443,217,7,0,0,0,940],bounds=([380,165,4,-20,-20,-10,350],[500,260,20,20,20,10,3000]),loss='soft_l1',f_scale=1.2).x
(ROOT/'plan_camera.json').write_text(json.dumps(sol.tolist()));print('high',sol,'median support',np.median(np.abs(cost(sol))))
im=Image.open(ROOT/'refs/press-07.jpg');im.thumbnail((900,450));d=ImageDraw.Draw(im);uv=proj(pts,sol);d.line([tuple(p) for p in uv[ConvexHull(uv).vertices]],fill='#00dfff',width=2);d.line([tuple(p) for p in outline],fill='yellow',width=1);im.save(ROOT/'audit/plan-fit.jpg')
