"""Rear engine-bay air cleaner cover on the 2027 ZR1X chassis.

The upper molding follows mechanical/mech-bay-top.jpg and mech-bay-center.jpg.
The plaque artwork is drawn in draw_bay_plaque.py from the observed text, colors and layout.
The lower casing and connections beneath the visible lip are approximate.
"""
from pathlib import Path

import bpy

from rig_utils import join_meshes, make_loft, make_mesh, make_tube


def _plaque_material():
    mat = bpy.data.materials.new("Mat_ZR1X_AirCleaner_Plaque")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    bsdf = nodes.get("Principled BSDF")
    bsdf.inputs["Metallic"].default_value = .18
    bsdf.inputs["Roughness"].default_value = .44
    image = bpy.data.images.load(str(Path(__file__).parent / "textures" / "bay-specification.png"))
    image.name = "Tex_ZR1X_AirCleaner_Plaque"
    image.pack()
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = image
    mat.node_tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    return mat


def build(pivots, mats):
    chassis = pivots["Pivot_Drivetrain_Chassis"]
    black = mats["Mat_Black_Trim_Satin"]
    rubber = mats["Mat_Rubber_Black"]
    # Longitudinal sections of the raised center cover, from its front lip to
    # the luggage-side wall. The label bed slopes down toward the rear bumper.
    sections = [
        (-1.202, .230, .722), (-1.211, .245, .744),
        (-1.226, .260, .751), (-1.248, .281, .754),
        (-1.296, .302, .751), (-1.340, .316, .740),
        (-1.435, .339, .709), (-1.458, .342, .701),
        (-1.478, .340, .690), (-1.490, .331, .676),
    ]
    rings = []
    for x, half_width, z in sections:
        # Top is flat below the badge, with rounded shoulders and a lower flange.
        shape = [(-1.00, -.066), (-.995, -.040), (-.965, -.022), (-.895, -.010),
                 (-.765, -.002), (-.64, 0), (.64, 0), (.765, -.002),
                 (.895, -.010), (.965, -.022), (.995, -.040), (1, -.066),
                 (.985, -.077), (.96, -.082), (-.96, -.082), (-.985, -.077)]
        rings.append([(x, y * half_width, z + dz) for y, dz in shape])
    parts = [make_loft("airbox molding", rings, black, chassis, auto_smooth_deg=42)]
    for side in (-1, 1):
        parts.append(make_tube(
            "airbox connection",
            [(-1.291, side*.197, .677), (-1.25, side*.204, .651),
             (-1.208, side*.212, .610), (-1.162, side*.215, .578)],
            .044, rubber, chassis, segments=24,
        ))
    join_meshes(parts, "ZR1X_Chassis_AirCleaner_Cover", chassis)

    # The label's top edge is narrower than its lower edge. Preserve its
    # rounded corners and the blue / brushed-silver face of the original.
    outline = [(0.003,.012), (.003,.030), (.137,.890), (.149,.948),
               (.161,.977), (.179,.993), (.857,.998), (.871,.988),
               (.886,.956), (.898,.899), (.998,.043), (.998,.015)]
    verts = []
    for u, v in outline:
        x = -1.435 + .095*v
        y = (.5-u)*.401
        z = .7107 + .031*v
        verts.append((x,y,z))
    face = make_mesh("ZR1X_Chassis_AirCleaner_Plaque", verts, [tuple(reversed(range(len(verts))))],
                     _plaque_material(), chassis, smooth=False)
    coords = face.data.uv_layers.new(name="UVMap")
    for loop in face.data.loops:
        coords.data[loop.index].uv = outline[loop.vertex_index]
