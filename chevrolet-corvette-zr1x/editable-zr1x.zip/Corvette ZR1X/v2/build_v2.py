"""Master assembly, rig validator, and 1:18-mm Draco GLB exporter for ZR1X v2.

Usage (Blender 5.2.1):
    blender -b -t 4 --python-exit-code 1 -P build_v2.py
    blender -b -t 4 --python-exit-code 1 -P build_v2.py -- --only cabin_build
    blender -b -t 4 --python-exit-code 1 -P build_v2.py -- --only ext,cabin --skip-export

Implements the authoritative contract in ``v2_rig_spec.md``:
1. Instantiates ``materials.create_materials()`` and all 23 ``Pivot_*`` empties
   under ``ZR1X_Interactive_Rig`` in real-world V2 Blender meters (+X fwd, +Y
   left, +Z up, ground Z=0, origin mid-wheelbase).
2. Calls ``build(pivots, mats)`` for every available ``ext_*``, ``mech_*``, and
   ``cabin_build`` module (respecting optional ``--only`` filters).
3. Runs an automated rig, naming, material, scale, and 3D exploded-view AABB
   collision validator against ``v2_rig_spec.md`` Section 3–5.
4. Saves real-world-meter ``ZR1X_v2.blend`` (compressed).
5. Uniformly converts locations & mesh vertices by ``S = 1000 / 18`` (1:18-scale
   mm, preserving unit ``[1, 1, 1]`` scale on every node), exports Draco-level-6
   ``corvette_zr1x_2027.glb`` (``+X`` fwd, ``+Y`` up, ``+Z`` right), and parses
   the written GLB JSON chunk to verify exact 1:18-mm pivot coordinates & scales.
"""

from __future__ import annotations

import argparse
import importlib
import json
import re
import struct
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import bpy
import numpy as np
from mathutils import Matrix, Vector

V2_DIR = Path(__file__).resolve().parent
if str(V2_DIR) not in sys.path:
    sys.path.insert(0, str(V2_DIR))

import materials
import rig_utils
from photo_scene import add_cameras
from rig_utils import PIVOT_SPECS, PIVOT_WORLD_POS, RIG_ROOT_NAME, SCALE_1_18, apply_modifiers, v2_to_gltf_mm


# Ordered module list across Track 2 (exterior), Track 3 (mechanicals), Track 4 (cabin)
MODULE_ORDER: Tuple[str, ...] = (
    # Track 2: Exterior, Aero, Optics & Glazing
    "ext_body",
    "ext_closures",
    "ext_aero",
    "ext_optics",
    "ext_glazing",
    "ext_details",
    # Track 3: Chassis, Powertrain, Exhaust & Corners
    "mech_chassis",
    "mech_bay",
    "mech_lt7",
    "mech_dct",
    "mech_edu_battery",
    "mech_exhaust",
    "mech_corners",
    # Track 4: 2027 3-Screen 3LZ Cabin
    "cabin_build",
    "ext_photo_fit",
)

MESH_NAME_RE = re.compile(r"^ZR1X_[A-Za-z0-9_]+$")

# Authoritative exploded-view parent-frame offsets in 1:18 mm viewer coords (+X fwd, +Y up, +Z right)
# Tuned from v2_rig_spec.md Section 5 to guarantee 0 pairwise 3D AABB overlaps across all 19 assemblies.
EXPLODE_PIVOT_OFFSETS_MM: Dict[str, Tuple[float, float, float]] = {
    "Pivot_Drivetrain_Chassis": (0.0, 0.0, 0.0),
    "Pivot_Body_Assembly":      (0.0, 121.0, 0.0),
    "Pivot_Door_L":             (-14.0, -4.0, -92.0),
    "Pivot_Door_R":             (20.0, 22.0, 96.0),
    "Pivot_Front_Hood":         (42.0, 59.0, 0.0),
    "Pivot_Roof_Panel":         (0.0, 48.0, 0.0),
    "Pivot_Rear_Hatch":         (-32.0, 38.0, 0.0),
    "Pivot_Fuel_Flap":          (-4.0, 8.0, -22.0),
    "Pivot_ZTK_Wing":           (-64.0, 34.0, 0.0),
    "Pivot_Interior_Cabin":     (152.0, 46.0, -54.0),
    "Pivot_Front_EDU":          (104.0, 18.0, 46.0),
    "Pivot_Hybrid_Battery":     (8.0, 53.0, 0.0),
    "Pivot_LT7_Engine":         (-44.0, 51.0, 0.0),
    "Pivot_DCT_Transaxle":      (-84.0, 24.0, 0.0),
    "Pivot_Exhaust_System":     (-146.0, -2.0, 0.0),
    "Pivot_Corner_FL":          (0.0, 0.0, -42.0),
    "Pivot_Corner_RL":          (0.0, 0.0, -42.0),
    "Pivot_Corner_FR":          (0.0, 0.0, 44.0),
    "Pivot_Corner_RR":          (-24.0, 0.0, 46.0),
}


def _part_offset_mm(parent_pivot_name: str, mesh_name: str) -> Tuple[float, float, float]:
    """Sub-part separation offset in 1:18 mm viewer coords (v2_rig_spec.md Section 5)."""
    if parent_pivot_name.startswith("Pivot_WheelSpin_"):
        side = -1.0 if parent_pivot_name.endswith("L") else 1.0
        if "Tire_" in mesh_name:
            return (0.0, 0.0, side * 44.0)
        if "Wheel_CenterCap" in mesh_name or "Wheel_LugNuts" in mesh_name:
            return (0.0, 0.0, side * 54.0)
        if "Wheel_Spokes" in mesh_name:
            return (0.0, 0.0, side * 18.0)
    elif parent_pivot_name == "Pivot_Body_Assembly":
        if re.search(r"Headlight_|Front_Grille|Front_Intake|Front_Splitter|Front_DivePlane", mesh_name):
            return (22.0, 0.0, 0.0)
        if re.search(r"Taillight_|Rear_Diffuser|DiffuserStrake", mesh_name):
            return (-22.0, 0.0, 0.0)
        if re.search(r"Glass_Windshield|Glass_Quarter|Wiper_", mesh_name):
            return (0.0, 16.0, 0.0)
    elif parent_pivot_name.startswith("Pivot_Door_"):
        if "Glass_Door" in mesh_name:
            return (0.0, 16.0, 0.0)
    elif parent_pivot_name == "Pivot_LT7_Engine":
        if re.search(r"Eng_IntakePlenum|Eng_PlenumPlaque", mesh_name):
            return (0.0, 22.0, 0.0)
        if re.search(r"Eng_IntakeRunners|Eng_FuelRails", mesh_name):
            return (0.0, 10.0, 0.0)
    elif parent_pivot_name == "Pivot_DCT_Transaxle":
        if "DCT_Case_" in mesh_name:
            return (-14.0, 18.0, 16.0)
    elif parent_pivot_name == "Pivot_Front_EDU":
        if "EDU_Case_" in mesh_name:
            return (12.0, 16.0, 12.0)
    elif parent_pivot_name == "Pivot_Hybrid_Battery":
        if "Battery_Cover_" in mesh_name:
            return (0.0, 14.0, 0.0)
    elif parent_pivot_name == "Pivot_Exhaust_System":
        if re.search(r"Exh_Muffler|Exh_Tips", mesh_name):
            return (-16.0, 0.0, 0.0)
    elif parent_pivot_name == "Pivot_Interior_Cabin":
        if "Cabin_SteeringWheel" in mesh_name:
            return (2.0, 10.0, -16.0)
        if re.search(r"Cabin_Dash|Cabin_Display", mesh_name):
            return (14.0, 6.0, 0.0)
        if "Cabin_SeatCushion" in mesh_name:
            return (0.0, 10.0, 0.0)
    return (0.0, 0.0, 0.0)


# ---------------------------------------------------------------------------
# Automated Rig, Naming, Scale & Exploded-View Validator
# ---------------------------------------------------------------------------

def _assembly_key(obj: bpy.types.Object) -> str:
    """Return the explodable assembly pivot owning ``obj`` (merging WheelSpin into its Corner)."""
    cur = obj.parent
    while cur is not None:
        if cur.name.startswith("Pivot_WheelSpin_"):
            return cur.parent.name if cur.parent else cur.name
        if cur.name.startswith("Pivot_"):
            return cur.name
        cur = cur.parent
    return "<ROOT>"


def _cumulative_explode_offset_mm(pivot_obj: Optional[bpy.types.Object]) -> np.ndarray:
    """Accumulate parent-chain exploded offsets in 1:18 mm glTF frame."""
    total = np.zeros(3, dtype=float)
    cur = pivot_obj
    while cur is not None:
        if cur.name in EXPLODE_PIVOT_OFFSETS_MM:
            total += np.asarray(EXPLODE_PIVOT_OFFSETS_MM[cur.name], dtype=float)
        cur = cur.parent
    return total


def validate_rig(
    pivots: Dict[str, bpy.types.Object],
    built_modules: Sequence[str],
    strict_full_bounds: bool = True,
) -> Dict[str, object]:
    """Validate rig hierarchy, naming, materials, bounds, and 3D exploded collisions."""
    bpy.context.view_layer.update()
    errors: List[str] = []
    warnings: List[str] = []

    # 1. All 23 Pivot_* empties exist at exact V2 meter coordinates
    expected_pivots = {name: (par, pos) for name, par, pos in PIVOT_SPECS}
    for pname, (par_name, expected_pos) in expected_pivots.items():
        ob = bpy.data.objects.get(pname)
        if ob is None:
            errors.append(f"Missing pivot empty: {pname}")
            continue
        if ob.type != "EMPTY":
            errors.append(f"Pivot {pname} has type {ob.type}, expected EMPTY")
        if ob.parent is None or ob.parent.name != par_name:
            actual_par = ob.parent.name if ob.parent else None
            errors.append(f"Pivot {pname} parent={actual_par}, expected {par_name}")
        actual_pos = ob.matrix_world.translation
        err = (actual_pos - Vector(expected_pos)).length
        if err > 1e-4:
            errors.append(f"Pivot {pname} world pos {tuple(round(c, 4) for c in actual_pos)} != expected {expected_pos}")
        if (Vector(ob.scale) - Vector((1.0, 1.0, 1.0))).length > 1e-5:
            errors.append(f"Pivot {pname} non-unit scale {tuple(ob.scale)}")

    # 2. Zero meshes at scene root; clean ZR1X_* naming (no spaces, no .001 suffixes); no Curves
    meshes: List[bpy.types.Object] = []
    per_pivot_counts: Dict[str, int] = {}
    total_verts = 0
    total_polys = 0

    for ob in bpy.data.objects:
        if ob.type == "CURVE":
            warnings.append(f"Stray CURVE object left in scene: {ob.name} (prefer clean meshes)")
        if ob.type != "MESH":
            continue
        meshes.append(ob)
        if ob.parent is None:
            errors.append(f"Mesh sits directly at scene root (forbidden): {ob.name}")
        elif not ob.parent.name.startswith("Pivot_"):
            errors.append(f"Mesh {ob.name} parented to {ob.parent.name} instead of a Pivot_* node")
        else:
            per_pivot_counts[ob.parent.name] = per_pivot_counts.get(ob.parent.name, 0) + 1

        if not MESH_NAME_RE.match(ob.name):
            errors.append(f"Invalid mesh name (must match ZR1X_[A-Za-z0-9_]+ with no spaces/.001): {ob.name}")

        # Check no legacy visual-hull vertex colors on exterior paint
        if ob.data and any(ca.name == "Surface tone" for ca in ob.data.color_attributes):
            errors.append(f"Legacy 'Surface tone' vertex color attribute found on {ob.name}")

        total_verts += len(ob.data.vertices)
        total_polys += len(ob.data.polygons)

    # 3. Material hook verification
    if "cabin_build" in built_modules:
        mirror_ob = bpy.data.objects.get("ZR1X_Cabin_RearviewMirror")
        if mirror_ob is None:
            errors.append("Missing ZR1X_Cabin_RearviewMirror")
        elif not mirror_ob.data.materials or mirror_ob.data.materials[0].name != "Mat_Cabin_Rearview":
            errors.append("ZR1X_Cabin_RearviewMirror must have Mat_Cabin_Rearview as primary material")

    # 4. Overall real-world-meter bounds & 3D Exploded-View AABB collision check
    depsgraph = bpy.context.evaluated_depsgraph_get()
    all_pts_m: List[np.ndarray] = []
    asm_mins_mm: Dict[str, np.ndarray] = {}
    asm_maxs_mm: Dict[str, np.ndarray] = {}

    for ob in meshes:
        eval_ob = ob.evaluated_get(depsgraph)
        me = bpy.data.meshes.new_from_object(eval_ob, depsgraph=depsgraph)
        if len(me.vertices) == 0:
            bpy.data.meshes.remove(me)
            continue
        coords = np.empty(len(me.vertices) * 3, dtype=np.float64)
        me.vertices.foreach_get("co", coords)
        bpy.data.meshes.remove(me)
        coords = coords.reshape(-1, 3)

        # Transform local verts -> V2 Blender world meters
        mw = np.asarray(ob.matrix_world, dtype=np.float64)
        world_m = coords @ mw[:3, :3].T + mw[:3, 3]
        all_pts_m.append(world_m)

        # Convert to 1:18 mm glTF frame (+X fwd, +Y up, +Z right) and apply exploded offsets
        world_mm = np.empty_like(world_m)
        world_mm[:, 0] = SCALE_1_18 * world_m[:, 0]
        world_mm[:, 1] = SCALE_1_18 * world_m[:, 2]
        world_mm[:, 2] = -SCALE_1_18 * world_m[:, 1]

        piv_off = _cumulative_explode_offset_mm(ob.parent)
        part_off = np.asarray(_part_offset_mm(ob.parent.name if ob.parent else "", ob.name), dtype=float)
        exploded_mm = world_mm + piv_off + part_off

        akey = _assembly_key(ob)
        lo = exploded_mm.min(axis=0)
        hi = exploded_mm.max(axis=0)
        if akey not in asm_mins_mm:
            asm_mins_mm[akey] = lo
            asm_maxs_mm[akey] = hi
        else:
            asm_mins_mm[akey] = np.minimum(asm_mins_mm[akey], lo)
            asm_maxs_mm[akey] = np.maximum(asm_maxs_mm[akey], hi)

    bounds_m = None
    if all_pts_m:
        stacked = np.vstack(all_pts_m)
        bmin = stacked.min(axis=0)
        bmax = stacked.max(axis=0)
        span = bmax - bmin
        bounds_m = {
            "min": [round(float(x), 4) for x in bmin],
            "max": [round(float(x), 4) for x in bmax],
            "span": [round(float(x), 4) for x in span],
        }
        is_full_car = {"ext_body", "ext_aero", "mech_corners"}.issubset(set(built_modules))
        if strict_full_bounds and is_full_car:
            if not (4.68 <= span[0] <= 4.96):
                errors.append(f"Full length {span[0]:.3f} m out of target range [4.68, 4.96] m (spec 4.860)")
            if not (1.96 <= span[1] <= 2.22):
                errors.append(f"Full width {span[1]:.3f} m out of target range [1.96, 2.22] m (spec 2.024/2.145)")
            if not (1.20 <= span[2] <= 1.36):
                errors.append(f"Full height {span[2]:.3f} m out of target range [1.20, 1.36] m (spec 1.234/1.285)")
            if abs(bmin[2]) > 0.015:
                errors.append(f"Ground contact Z_min={bmin[2]:.4f} m deviates > 15 mm from Z=0")

    # Pairwise 3D AABB collision check across exploded assemblies (tolerance 0.5 mm)
    collisions: List[str] = []
    akeys = sorted(asm_mins_mm.keys())
    for i in range(len(akeys)):
        for j in range(i + 1, len(akeys)):
            a, b = akeys[i], akeys[j]
            ov = np.minimum(asm_maxs_mm[a], asm_maxs_mm[b]) - np.maximum(asm_mins_mm[a], asm_mins_mm[b])
            if np.all(ov > 0.5):
                collisions.append(
                    f"{a} vs {b} overlap ({ov[0]:.1f}, {ov[1]:.1f}, {ov[2]:.1f}) mm"
                )
    if collisions:
        for c in collisions:
            errors.append(f"Exploded-view AABB collision: {c}")

    exploded_box_mm = None
    if asm_mins_mm:
        ex_lo = np.min(np.stack(list(asm_mins_mm.values())), axis=0)
        ex_hi = np.max(np.stack(list(asm_maxs_mm.values())), axis=0)
        ex_span = ex_hi - ex_lo
        exploded_box_mm = [round(float(x), 1) for x in ex_span]

    summary = {
        "modules_built": list(built_modules),
        "mesh_count": len(meshes),
        "total_verts": total_verts,
        "total_polys": total_polys,
        "bounds_m": bounds_m,
        "exploded_box_mm": exploded_box_mm,
        "exploded_assemblies_checked": len(akeys),
        "exploded_collisions": collisions,
        "per_pivot_mesh_counts": dict(sorted(per_pivot_counts.items())),
        "warnings": warnings,
        "errors": errors,
    }
    return summary


# ---------------------------------------------------------------------------
# Scale-to-1:18-mm & Draco GLB Export + Post-Export GLB Binary Verification
# ---------------------------------------------------------------------------

def _scale_scene_to_1_18_mm() -> None:
    """Bake modifiers and convert the scene cleanly from meters to 1:18 mm with unit node scales."""
    # 1. Bake all active modifiers at 1:1 meter scale so bevel/solidify thicknesses stay accurate
    for ob in list(bpy.data.objects):
        if ob.type == "MESH" and ob.modifiers:
            apply_modifiers(ob)

    # 2. Scale every mesh datablock's vertices uniformly by S = 1000 / 18
    scale_mat = Matrix.Scale(SCALE_1_18, 4)
    scaled_meshes = set()
    for ob in bpy.data.objects:
        if ob.type == "MESH" and ob.data is not None and ob.data.name not in scaled_meshes:
            ob.data.transform(scale_mat)
            ob.data.update()
            scaled_meshes.add(ob.data.name)

    # 3. Scale every object's local translation by S while keeping scale == [1, 1, 1]
    for ob in bpy.data.objects:
        ob.location = (
            ob.location.x * SCALE_1_18,
            ob.location.y * SCALE_1_18,
            ob.location.z * SCALE_1_18,
        )
        ob.scale = (1.0, 1.0, 1.0)
        if ob.parent is not None:
            ob.matrix_parent_inverse.identity()

    bpy.context.view_layer.update()


def verify_exported_glb(glb_path: Path) -> Dict[str, object]:
    """Parse the GLB JSON chunk and verify all 23 Pivot_* nodes, 1:18-mm coords, and unit scales."""
    raw = glb_path.read_bytes()
    magic, version, total_len = struct.unpack_from("<4sII", raw, 0)
    assert magic == b"glTF" and version == 2, f"Not a valid glTF 2.0 GLB: {glb_path}"
    chunk_len, chunk_type = struct.unpack_from("<I4s", raw, 12)
    assert chunk_type == b"JSON", "First GLB chunk is not JSON"
    gltf = json.loads(raw[20 : 20 + chunk_len].decode("utf-8"))

    nodes = gltf.get("nodes", [])
    by_name = {n.get("name"): (idx, n) for idx, n in enumerate(nodes) if n.get("name")}
    parent_of: Dict[int, int] = {}
    for p_idx, n in enumerate(nodes):
        for c_idx in n.get("children", []):
            parent_of[c_idx] = p_idx

    def world_translation(idx: int) -> np.ndarray:
        t = np.zeros(3, dtype=float)
        cur: Optional[int] = idx
        while cur is not None:
            tr = nodes[cur].get("translation")
            if tr:
                t += np.asarray(tr, dtype=float)
            cur = parent_of.get(cur)
        return t

    bad_scales = []
    for n in nodes:
        sc = n.get("scale")
        if sc is not None and np.max(np.abs(np.asarray(sc) - 1.0)) > 1e-4:
            bad_scales.append((n.get("name"), sc))

    pivot_errors = []
    for pname, _, pos_m in PIVOT_SPECS:
        if pname not in by_name:
            pivot_errors.append(f"GLB missing pivot {pname}")
            continue
        idx, _ = by_name[pname]
        actual = world_translation(idx)
        expected = np.asarray(v2_to_gltf_mm(pos_m), dtype=float)
        diff = float(np.linalg.norm(actual - expected))
        if diff > 0.02:
            pivot_errors.append(f"GLB pivot {pname} at {np.round(actual, 2).tolist()} != expected {np.round(expected, 2).tolist()}")

    assert not bad_scales, f"Non-unit node scales in exported GLB: {bad_scales[:10]}"
    assert not pivot_errors, f"GLB pivot coordinate check failed: {pivot_errors}"

    return {
        "glb_bytes": len(raw),
        "glb_mb": round(len(raw) / (1024 * 1024), 3),
        "gltf_nodes": len(nodes),
        "gltf_meshes": len(gltf.get("meshes", [])),
        "gltf_materials": len(gltf.get("materials", [])),
        "gltf_images": len(gltf.get("images", [])),
        "extensions_used": gltf.get("extensionsUsed", []),
    }


# ---------------------------------------------------------------------------
# Main Build Entrypoint
# ---------------------------------------------------------------------------

def _parse_args() -> argparse.Namespace:
    argv = sys.argv[sys.argv.index("--") + 1 :] if "--" in sys.argv else []
    parser = argparse.ArgumentParser(description="Build 2027 Chevrolet Corvette ZR1X v2 .blend and 1:18-mm Draco GLB.")
    parser.add_argument("--only", type=str, default="", help="Comma-separated module names or prefixes (e.g. cabin_build or ext,cabin)")
    parser.add_argument("--blend", type=str, default=str(V2_DIR / "ZR1X_v2.blend"), help="Output meter-scale .blend path")
    parser.add_argument("--glb", type=str, default=str(V2_DIR / "corvette_zr1x_2027.glb"), help="Output 1:18-mm Draco .glb path")
    parser.add_argument("--skip-export", action="store_true", help="Skip 1:18-mm GLB export")
    parser.add_argument("--skip-validate", action="store_true", help="Skip strict assertions on validation errors")
    return parser.parse_args(argv)


def _select_modules(only_arg: str) -> List[str]:
    available = [m for m in MODULE_ORDER if (V2_DIR / f"{m}.py").exists()]
    if not only_arg.strip():
        return available
    tokens = [t.strip() for t in only_arg.split(",") if t.strip()]
    selected = []
    for mod in available:
        if any(mod == tok or mod.startswith(tok) for tok in tokens):
            selected.append(mod)
    return selected


def main() -> None:
    args = _parse_args()
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.unit_settings.system = "METRIC"
    sc.unit_settings.length_unit = "METERS"
    sc.render.engine = "CYCLES"

    world = bpy.data.worlds.new("ZR1X_Studio_World")
    if world.node_tree is None:
        world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg is not None:
        bg.inputs["Color"].default_value = (0.28, 0.28, 0.30, 1.0)
        bg.inputs["Strength"].default_value = 0.85
    sc.world = world

    mats = materials.create_materials()
    pivots = rig_utils.create_rig(sc)

    selected = _select_modules(args.only)
    missing = [m for m in MODULE_ORDER if not (V2_DIR / f"{m}.py").exists()]
    print(f"[build_v2] Selected modules ({len(selected)}): {selected}")
    if missing:
        print(f"[build_v2] Not yet present on disk ({len(missing)}): {missing}")

    built_modules: List[str] = []
    for mod_name in selected:
        mod = importlib.import_module(mod_name)
        importlib.reload(mod)
        print(f"[build_v2] Building {mod_name}...")
        mod.build(pivots, mats)
        built_modules.append(mod_name)

    report = validate_rig(pivots, built_modules, strict_full_bounds=(not args.only))
    print("[build_v2] Validation Report:")
    print(json.dumps(report, indent=2))

    if report["errors"] and not args.skip_validate:
        raise RuntimeError(f"Rig validation failed with {len(report['errors'])} error(s): {report['errors']}")

    for obj in bpy.context.scene.objects:
        if obj.name in EXPLODE_PIVOT_OFFSETS_MM:
            obj["explodeOffset"]=list(EXPLODE_PIVOT_OFFSETS_MM[obj.name])
        elif obj.type=="MESH" and obj.parent:
            obj["explodeOffset"]=list(_part_offset_mm(obj.parent.name,obj.name))
    cameras=add_cameras(sc)
    blend_path = Path(args.blend)
    blend_path.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(blend_path), compress=True)
    print(f"[build_v2] Saved real-world-meter master: {blend_path} ({blend_path.stat().st_size / 1e6:.2f} MB)")

    if not args.skip_export:
        glb_path = Path(args.glb)
        glb_path.parent.mkdir(parents=True, exist_ok=True)
        for camera_obj in list(cameras.objects):
            bpy.data.objects.remove(camera_obj,do_unlink=True)
        _scale_scene_to_1_18_mm()
        bpy.ops.export_scene.gltf(
            filepath=str(glb_path),
            export_format="GLB",
            export_apply=True,
            export_animations=False,
            export_extras=True,
            export_yup=True,
            export_draco_mesh_compression_enable=True,
            export_draco_mesh_compression_level=6,
            export_draco_position_quantization=14,
            export_draco_texcoord_quantization=14,
        )
        glb_report = verify_exported_glb(glb_path)
        print("[build_v2] Exported 1:18-mm Draco GLB verified:")
        print(json.dumps(glb_report, indent=2))


if __name__ == "__main__":
    main()
