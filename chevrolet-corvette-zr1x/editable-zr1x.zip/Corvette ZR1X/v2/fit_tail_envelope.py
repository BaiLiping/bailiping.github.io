"""Save lower silhouette constraints from the orbit for the rear diffuser exits."""
import json
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import median_filter,gaussian_filter1d
base=Path(__file__).resolve().parent
frames=json.loads((base/'cameras.json').read_text())['frames']; out=[]
for i in [5,6,12,13,14,15,20,21]:
    fid='view-%02d'%i
    mask=np.asarray(Image.open(base.parent/'refs_v2/studio_360'/(fid+'.png')))[:,:,3]>=254
    cols=np.flatnonzero(mask.any(0))
    bottom=mask.shape[0]-1-mask[::-1].argmax(0)
    bottom=np.interp(np.arange(mask.shape[1]),cols,bottom[cols])
    bottom=gaussian_filter1d(median_filter(bottom,5),2)
    s=frames[fid]['solved']
    out.append(dict(id=fid,first=int(cols[0]),last=int(cols[-1]),bottom=bottom[::3].round(2).tolist(),camera=s))
(base/'tail-envelope.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
