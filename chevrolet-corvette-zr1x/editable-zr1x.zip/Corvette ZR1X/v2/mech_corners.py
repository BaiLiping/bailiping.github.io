"""Four rolling corners: uprights, J59 Alcon brakes, 420 mm CCB rotors, 20-spoke SOJ wheels & Cup 2 R tyres.

Populates:
- ``Pivot_Corner_FL/FR/RL/RR`` (non-spinning knuckle/upright + J59 Alcon monobloc caliper;
  ``FL/FR`` pivot about local ``+Z`` in Blender / ``+Y`` in glTF when ``S`` steers).
- ``Pivot_WheelSpin_FL/FR/RL/RR`` (child at local ``(0, 0, 0)``, spins about wheel axis):
  - ``ZR1X_Rotor_CCB_*``: 420 mm (16.5") through-drilled dark woven SiC CCB rotor + 10 floating bobbins
  - ``ZR1X_Wheel_Barrel_*``: 20x10" F / 21x13" R concave Carbon Flash forged barrel + valve stem
  - ``ZR1X_Wheel_Spokes_*``: Photo-matched slender sculpted 3D 20-spoke SOJ split-star cross-webbing face
  - ``ZR1X_Wheel_LugNuts_*``: 5 dark hex lug nuts on 5x120 mm PCD
  - ``ZR1X_Wheel_CenterCap_*``: Black center cap w/ 3D silver/red Corvette crossed flags
  - ``ZR1X_Tire_*``: Michelin Pilot Sport Cup 2 R ZP (275/30ZR20 F, 345/25ZR21 R)

Photo-matched to official 2500x1407 GM render ``06-wheel-and-side-inlet.jpg``,
``20-spoke-carbon-flash-forged-wheel.jpg``, and GM TechLink 3000x2001 J59 Alcon brake shot.
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

import bpy
import numpy as np
from mathutils import Euler, Matrix, Vector

from rig_utils import (
    TIRE_R_F,
    TIRE_R_R,
    box_project_uv,
    join_meshes,
    make_cylinder,
    make_loft,
    make_mesh,
    make_roundbox,
    make_tube,
    parent_to_pivot,
    set_smooth,
)


def _m(mats: Dict[str, bpy.types.Material], key: str, fallback: str = "Mat_Aluminum_Cast") -> bpy.types.Material:
    return mats.get(key) or mats.get(fallback) or next(iter(mats.values()))


def _ring(
    name: str,
    profile: Sequence[Tuple[float, float]],
    side: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    count: int = 80,
    smooth: bool = True,
    auto_smooth_deg: float | None = 44.0,
    uv_scale: float | None = None,
) -> bpy.types.Object:
    """Revolve a (radius, axial_y) profile around the local Y wheel axis (outboard = side * +Y)."""
    verts: List[Tuple[float, float, float]] = []
    faces: List[Tuple[int, ...]] = []
    for r0, y0 in profile:
        for k in range(count):
            a = 2.0 * math.pi * k / count
            verts.append((r0 * math.cos(a), side * y0, r0 * math.sin(a)))
    for j in range(len(profile) - 1):
        for k in range(count):
            nk = (k + 1) % count
            quad = (j * count + k, j * count + nk, (j + 1) * count + nk, (j + 1) * count + k)
            faces.append(quad if side > 0 else quad[::-1])
    return make_mesh(
        name, verts, faces, mat, pivot,
        world_coords=False, smooth=smooth, auto_smooth_deg=auto_smooth_deg,
        uv_scale=uv_scale, recalc_normals=True,
    )


def _text_mesh_local(
    name: str,
    body: str,
    local_loc: Tuple[float, float, float],
    rot_matrix: Matrix,
    size: float,
    extrude: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
) -> bpy.types.Object:
    """Bake crisp 3D lettering directly into a MESH object in pivot-local space."""
    cu = bpy.data.curves.new(name + "_font", "FONT")
    cu.body = body
    cu.size = size
    cu.align_x = "CENTER"
    cu.align_y = "CENTER"
    cu.extrude = extrude
    cu.resolution_u = 4
    f_obj = bpy.data.objects.new(name + "_fobj", cu)
    bpy.context.scene.collection.objects.link(f_obj)
    f_obj.parent = pivot
    f_obj.matrix_parent_inverse.identity()
    f_obj.location = local_loc
    f_obj.rotation_euler = rot_matrix.to_euler()

    bpy.context.view_layer.update()
    deps = bpy.context.evaluated_depsgraph_get()
    eval_obj = f_obj.evaluated_get(deps)
    me = bpy.data.meshes.new_from_object(eval_obj, preserve_all_data_layers=False, depsgraph=deps)
    me.name = name
    me.materials.append(mat)
    me.transform(f_obj.matrix_local)
    me.update()

    bpy.data.objects.remove(f_obj, do_unlink=True)
    bpy.data.curves.remove(cu)

    obj = bpy.data.objects.new(name, me)
    parent_to_pivot(obj, pivot, coords_are_world=False)
    return obj


# ---------------------------------------------------------------------------
# 1. Upright & J59 Alcon Monobloc Caliper (under Pivot_Corner_*)
# ---------------------------------------------------------------------------

def _build_upright_and_caliper(
    tag: str,
    is_rear: bool,
    side: float,
    friction: float,
    r_tire: float,
    piv_corner: bpy.types.Object,
    mats: Dict[str, bpy.types.Material],
) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    gun = _m(mats, "Mat_Gear_Steel")
    steel = _m(mats, "Mat_Steel_Machined")
    cal_mat = _m(mats, "Mat_Caliper_Alcon_Black")
    white = _m(mats, "Mat_White_Paint", "Mat_Plate_Silver")
    dark = _m(mats, "Mat_Black_Trim_Satin")

    # Local Z offsets of upper & lower ball joints relative to wheel center
    z_low = 0.224 - r_tire
    z_up = 0.522 - r_tire
    # Local Y offset of upright plane relative to wheel center (track 0.8425 / 0.8390 -> upright at ~0.755)
    y_up_in = -0.088

    # --- A) Sculpted Aluminum Steering Knuckle / Upright (ZR1X_Upright_*) ---
    uparts: List[bpy.types.Object] = []
    # Main vertical cast upright spine with upper/lower ball-joint towers
    spine_secs = []
    for yy, zz, half_x in (
        (y_up_in, z_low - 0.012, 0.028),
        (y_up_in + 0.008, z_low + 0.036, 0.040),
        (y_up_in + 0.014, 0.000, 0.068),
        (y_up_in + 0.002, z_up - 0.065, 0.038),
        (y_up_in - 0.010, z_up + 0.005, 0.024),
    ):
        spine_secs.append([
            (dx, side * (yy + dy), zz)
            for dx, dy in ((-half_x, -0.016), (half_x, -0.016), (half_x + 0.008, 0.016), (-half_x, 0.016))
        ])
    uparts.append(make_loft("tmp_upright_body", spine_secs, cast, piv_corner, world_coords=False, auto_smooth_deg=42.0))
    # Wheel bearing hub housing & inboard seal collar
    uparts.append(make_cylinder(
        "tmp_hub_brg", (0.0, side * (y_up_in - 0.024), 0.0), (0.0, side * (y_up_in + 0.046), 0.0),
        0.056, 0.066, gun, piv_corner, segments=26, world_coords=False,
    ))
    # Caliper radial mounting ears reaching toward caliper position
    x_cal_sign = 1.0 if is_rear else -1.0  # Front caliper is AFT (-X); rear caliper is FWD (+X)
    for ez in (-0.075, 0.075):
        uparts.append(make_tube(
            "tmp_cal_ear",
            [(0.0, side * y_up_in, ez * 0.65), (x_cal_sign * 0.145, side * (friction - 0.042), ez * 1.15)],
            0.015, cast, piv_corner, segments=10, world_coords=False,
        ))
    # Steering / toe-link arm projecting aft/inboard to meet tie rod
    arm_x = -0.135 if not is_rear else -0.125
    uparts.append(make_tube(
        "tmp_steer_arm",
        [(0.0, side * y_up_in, -0.042), (arm_x, side * (y_up_in - 0.018), -0.060)],
        0.015, cast, piv_corner, segments=10, world_coords=False,
    ))
    join_meshes(uparts, f"ZR1X_Upright_{tag}", piv_corner)

    # --- B) J59 Alcon Monobloc Caliper (10-piston F / 6-piston R, ZR1X_Caliper_Alcon_*) ---
    cparts: List[bpy.types.Object] = []
    # Huge curved 10-piston front (span ±0.88 rad = 101°) vs 6-piston rear (span ±0.68 rad = 78°)
    t_span = 0.68 if is_rear else 0.88
    n_pistons_side = 3 if is_rear else 5
    r_in = 0.166 if is_rear else 0.158
    r_out = 0.226 if is_rear else 0.232
    y_out = friction + (0.032 if not is_rear else 0.028)
    y_in = friction - (0.056 if not is_rear else 0.050)

    cal_secs = []
    for t in np.linspace(-t_span, t_span, 21):
        # Taper cleanly at top & bottom ends of caliper arc
        end_taper = 1.0 - 0.22 * max(0.0, (abs(t) / t_span - 0.72) / 0.28) ** 1.6
        r_mid = 0.5 * (r_in + r_out)
        # Monobloc cross-section wrapping snugly over the 34 mm CCB disc with chamfered shoulders
        raw_prof = (
            (r_in + 0.005, friction - 0.020),
            (r_in, friction + 0.018),
            (r_in + 0.014, y_out),
            (r_out - 0.018, y_out),
            (r_out - 0.003, friction + 0.016),
            (r_out, friction - 0.024),
            (r_out - 0.010, y_in),
            (r_in + 0.006, y_in),
        )
        sec = []
        for rr, yy in raw_prof:
            rr_t = r_mid + (rr - r_mid) * end_taper
            sec.append((x_cal_sign * rr_t * math.cos(t), side * yy, rr_t * math.sin(t)))
        cal_secs.append(sec)
    cparts.append(make_loft("tmp_cal_body", cal_secs, cal_mat, piv_corner, world_coords=False, auto_smooth_deg=42.0))

    # Sculpted exterior monobloc stiffening bridge ribs & staggered circular piston bosses (5 F / 3 R per side!)
    for idx_p in range(n_pistons_side):
        tp = -t_span * 0.74 + (2.0 * t_span * 0.74) * idx_p / max(1, n_pistons_side - 1)
        rp = 0.5 * (r_in + r_out) - 0.004
        # Slightly smaller leading/trailing pistons (authentic Alcon differential-bore 10-piston layout!)
        p_rad = 0.0165 if (0 < idx_p < n_pistons_side - 1) else 0.0140
        px, pz = x_cal_sign * rp * math.cos(tp), rp * math.sin(tp)
        # Outer & inner piston cap bosses
        cparts.append(make_cylinder(
            "tmp_pboss_out", (px, side * (y_out - 0.003), pz), (px, side * (y_out + 0.004), pz),
            p_rad, p_rad * 0.88, cal_mat, piv_corner, segments=16, world_coords=False,
        ))
        cparts.append(make_cylinder(
            "tmp_pboss_in", (px, side * (y_in + 0.003), pz), (px, side * (y_in - 0.004), pz),
            p_rad, p_rad * 0.88, cal_mat, piv_corner, segments=16, world_coords=False,
        ))

    # Raised central curved face crest strip carrying white CORVETTE script
    crest_secs = []
    for t in np.linspace(-t_span * 0.65, t_span * 0.65, 13):
        crest_secs.append([
            (x_cal_sign * rr * math.cos(t), side * (y_out + dy), rr * math.sin(t))
            for rr, dy in ((r_in + 0.018, 0.0), (r_in + 0.022, 0.0045), (r_out - 0.022, 0.0045), (r_out - 0.018, 0.0))
        ])
    cparts.append(make_loft("tmp_cal_crest", crest_secs, cal_mat, piv_corner, world_coords=False, auto_smooth_deg=40.0))

    # Top pad bridge window pins + stainless bleed nipples + crossover fluid tube (GM TechLink 3000x2001!)
    for t_pin in (-t_span * 0.42, t_span * 0.42):
        px, pz = x_cal_sign * (r_out - 0.008) * math.cos(t_pin), (r_out - 0.008) * math.sin(t_pin)
        cparts.append(make_cylinder(
            "tmp_pad_pin", (px, side * (y_in + 0.006), pz), (px, side * (y_out - 0.006), pz),
            0.005, 0.005, steel, piv_corner, segments=10, world_coords=False,
        ))
    # Bleed nipple at top of caliper
    bx, bz = x_cal_sign * (r_out - 0.014) * math.cos(t_span * 0.78), (r_out - 0.014) * math.sin(t_span * 0.78)
    cparts.append(make_cylinder(
        "tmp_bleed", (bx, side * (friction + 0.014), bz), (bx + x_cal_sign * 0.008, side * (friction + 0.016), bz + 0.016),
        0.0055, 0.004, dark, piv_corner, segments=10, world_coords=False,
    ))
    # Brake pad backing plates visible in radial gap
    pad_secs = []
    for t in np.linspace(-t_span * 0.78, t_span * 0.78, 9):
        pad_secs.append([
            (x_cal_sign * rr * math.cos(t), side * (friction + dy), rr * math.sin(t))
            for rr, dy in ((0.168, 0.003), (0.212, 0.003), (0.212, 0.013), (0.168, 0.013))
        ])
    cparts.append(make_loft("tmp_pad_out", pad_secs, dark, piv_corner, world_coords=False))

    # Crisp white 3D-mesh-baked "CORVETTE" lettering along outer curved face of Alcon caliper!
    r_txt = 0.5 * (r_in + r_out)
    word = "CORVETTE"
    char_step = 0.118 if not is_rear else 0.106
    # Right-handed basis: X_col = up_v x face_n, Y_col = up_v (+radial outward), Z_col = face_n (+outboard)
    # Guarantees det(rot_m) = +1 (NEVER mirrored!).
    # On FL (side=+1, x_cal=-1): X_col points -Z (top->bottom), so C is at +t and E at -t.
    # On FR (side=-1, x_cal=-1): X_col points +Z (bottom->top), so C is at -t and E at +t.
    order_sign = -1.0 if (side * x_cal_sign) < 0 else 1.0
    for idx_ch, ch in enumerate(word):
        t_ch = (idx_ch - (len(word) - 1) * 0.5) * char_step * order_sign
        cx_t = x_cal_sign * r_txt * math.cos(t_ch)
        cz_t = r_txt * math.sin(t_ch)
        face_n = Vector((0.0, side, 0.0))
        up_v = Vector((x_cal_sign * math.cos(t_ch), 0.0, math.sin(t_ch))).normalized()
        right_v = up_v.cross(face_n).normalized()
        rot_m = Matrix((right_v, up_v, face_n)).transposed()
        cparts.append(_text_mesh_local(
            f"tmp_ctxt_{idx_ch}", ch,
            (cx_t, side * (y_out + 0.0052), cz_t),
            rot_m, 0.019 if not is_rear else 0.016, 0.0008, white, piv_corner,
        ))

    join_meshes(cparts, f"ZR1X_Caliper_Alcon_{tag}", piv_corner)


# ---------------------------------------------------------------------------
# 2. 420 mm Through-Drilled CCB Rotor (under Pivot_WheelSpin_*)
# ---------------------------------------------------------------------------

def _build_ccb_rotor(
    tag: str,
    side: float,
    friction: float,
    piv_spin: bpy.types.Object,
    mats: Dict[str, bpy.types.Material],
) -> None:
    ccb = _m(mats, "Mat_CCB_Rotor_J59")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    hole_mat = _m(mats, "Mat_Dark_Mesh", "Mat_Black_Trim_Satin")
    steel = _m(mats, "Mat_Steel_Machined")

    # 420 mm (16.5", r_outer = 0.210 m) true through-drilled carbon-ceramic friction disc!
    thickness = 0.032
    radial_breaks = (0.118, 0.150, 0.180, 0.210)
    sectors = 36
    verts: List[Tuple[float, float, float]] = []
    faces: List[Tuple[int, ...]] = []
    mat_slots: List[int] = []

    def _add_face(ids: Tuple[int, int, int, int], slot: int) -> None:
        # outer_pts goes counter-clockwise in (x, z) -> (a0, b0, b0+n, a0+n) has normal along -Y.
        # Flip when side > 0 so outboard friction face normal points strictly OUTBOARD (+side * Y)!
        faces.append(ids[::-1] if side > 0 else ids)
        mat_slots.append(slot)

    for k in range(sectors):
        t0 = 2.0 * math.pi * k / sectors
        dt = 2.0 * math.pi / sectors
        for row, (r_in_row, r_out_row) in enumerate(zip(radial_breaks, radial_breaks[1:])):
            hole_t = t0 + dt * (0.24 + 0.24 * row)
            hole_r = 0.5 * (r_in_row + r_out_row) + 0.0015
            cx, cz = hole_r * math.cos(hole_t), hole_r * math.sin(hole_t)
            outer_pts = []
            for t in np.linspace(t0, t0 + dt, 4):
                outer_pts.append((r_out_row * math.cos(t), r_out_row * math.sin(t)))
            for r in np.linspace(r_out_row, r_in_row, 3)[1:]:
                outer_pts.append((r * math.cos(t0 + dt), r * math.sin(t0 + dt)))
            for t in np.linspace(t0 + dt, t0, 4)[1:]:
                outer_pts.append((r_in_row * math.cos(t), r_in_row * math.sin(t)))
            for r in np.linspace(r_in_row, r_out_row, 3)[1:-1]:
                outer_pts.append((r * math.cos(t0), r * math.sin(t0)))

            unit_dirs = []
            for px, pz in outer_pts:
                ln = math.hypot(px - cx, pz - cz)
                unit_dirs.append(((px - cx) / ln, (pz - cz) / ln))
            n_u = len(unit_dirs)
            st = len(verts)
            for rr, depth in (
                (None, friction),
                (0.0035, friction),
                (0.0030, friction - 0.0008),
                (0.0030, friction - thickness + 0.0008),
                (0.0035, friction - thickness),
                (None, friction - thickness),
            ):
                pts = outer_pts if rr is None else [(cx + dx * rr, cz + dz * rr) for dx, dz in unit_dirs]
                verts.extend((px, side * depth, pz) for px, pz in pts)
            for lay in range(5):
                is_hole = lay in (1, 2, 3)
                for j in range(n_u):
                    nj = (j + 1) % n_u
                    a0, b0 = st + lay * n_u + j, st + lay * n_u + nj
                    _add_face((a0, b0, b0 + n_u, a0 + n_u), 1 if is_hole else 0)

    # Keep exact analytical outward friction-face normals (never recalc_normals on open shell!)
    drilled = make_mesh(
        "tmp_ccb_ring", verts, faces, ccb, piv_spin,
        world_coords=False, smooth=False, recalc_normals=False,
    )
    drilled.data.materials.append(hole_mat)
    drilled.data.polygons.foreach_set("material_index", np.asarray(mat_slots, dtype="i"))
    # Clean planar UV projection on X-Z friction face so woven SiC texture maps crisply!
    box_project_uv(drilled, scale=4.8)

    rparts: List[bpy.types.Object] = [drilled]
    # Dark vented perimeter channel & 72 curved directional cooling vanes
    rparts.append(_ring("tmp_rvent", ((0.206, friction - 0.002), (0.206, friction - thickness + 0.002)), side, hole_mat, piv_spin, count=72))
    vv, vf = [], []
    for k in range(72):
        phi = 2.0 * math.pi * k / 72.0
        st = len(vv)
        for dy in (-0.001, -thickness + 0.001):
            for dt in (-0.011, 0.011):
                vv.append((0.2096 * math.cos(phi + dt + 0.42 * dy), side * (friction + dy), 0.2096 * math.sin(phi + dt + 0.42 * dy)))
        vf.append((st, st + 1, st + 3, st + 2))
    rparts.append(make_mesh("tmp_rvanes", vv, vf, ccb, piv_spin, world_coords=False, smooth=False, uv_scale=5.0, recalc_normals=True))

    # Dark anodized machined aluminum center hat (r = 0.032 .. 0.120)
    rparts.append(_ring(
        "tmp_rhat",
        (
            (0.030, friction + 0.016), (0.098, friction + 0.016), (0.115, friction + 0.004),
            (0.120, friction + 0.001), (0.120, friction - 0.016), (0.106, friction - 0.018), (0.030, friction - 0.018),
        ),
        side, dark, piv_spin, count=64,
    ))
    # 10 stainless floating rotor-to-hat mounting bobbins around perimeter (r = 0.115)
    for k in range(10):
        a = 2.0 * math.pi * k / 10.0
        bx, bz = 0.115 * math.cos(a), 0.115 * math.sin(a)
        rparts.append(make_cylinder(
            "tmp_bobbin", (bx, side * (friction - 0.012), bz), (bx, side * (friction + 0.008), bz),
            0.0075, 0.0075, steel, piv_spin, segments=12, world_coords=False,
        ))
    join_meshes(rparts, f"ZR1X_Rotor_CCB_{tag}", piv_spin)


# ---------------------------------------------------------------------------
# 3. 20-Spoke Carbon Flash (SOJ) Forged Wheel + Lugs + Cap (under Pivot_WheelSpin_*)
# ---------------------------------------------------------------------------

def _build_soj_wheel(
    tag: str,
    is_rear: bool,
    side: float,
    rim: float,
    half_w: float,
    front: float,
    piv_spin: bpy.types.Object,
    mats: Dict[str, bpy.types.Material],
) -> None:
    soj = _m(mats, "Mat_Wheel_CarbonFlash_SOJ")
    dark_chrome = _m(mats, "Mat_Badge_DarkChrome", "Mat_Black_Trim_Gloss")
    gloss_blk = _m(mats, "Mat_Black_Trim_Gloss")
    hole_mat = _m(mats, "Mat_Dark_Mesh", "Mat_Black_Trim_Satin")
    steel = _m(mats, "Mat_Steel_Machined")
    red = _m(mats, "Mat_Emblem_Red", "Mat_Torch_Red_GKZ")
    white = _m(mats, "Mat_White_Paint", "Mat_Plate_Silver")

    # Deeper concavity on wider 21x13" rear wheel vs 20x10" front wheel!
    concav = 1.24 if is_rear else 1.00
    bolt_r = 0.060  # Standard Corvette 5x120 mm bolt circle

    # --- A) Deep Concave Forged Wheel Barrel + Center Hub + Valve Stem (ZR1X_Wheel_Barrel_*) ---
    bparts: List[bpy.types.Object] = []
    # Stepped forged inner barrel
    bparts.append(_ring(
        "tmp_barrel",
        (
            (rim, -half_w + 0.016), (rim, front - 0.002), (rim - 0.008, front),
            (rim - 0.013, front - 0.005), (rim - 0.016, front - 0.055),
            (rim - 0.022, -half_w + 0.065), (rim - 0.014, -half_w + 0.016), (rim, -half_w + 0.016),
        ),
        side, soj, piv_spin, count=88,
    ))
    # Crisp rolled outer rim lip bevel
    bparts.append(_ring(
        "tmp_rlip",
        (
            (rim - 0.011, front), (rim - 0.003, front + 0.0045), (rim + 0.005, front + 0.0042),
            (rim + 0.011, front - 0.001), (rim + 0.011, front - 0.005),
        ),
        side, soj, piv_spin, count=88,
    ))
    # Forged central hub pad & stepped bore collar (recessed by concavity!)
    hub_d = front - 0.044 * concav
    bparts.append(_ring(
        "tmp_hub_pad",
        (
            (0.028, hub_d - 0.024), (0.062, hub_d - 0.024), (0.074, hub_d - 0.010),
            (0.066, hub_d - 0.002), (0.036, hub_d + 0.006), (0.028, hub_d + 0.006),
        ),
        side, soj, piv_spin, count=64,
    ))
    # 5 counterbored lug sockets
    for k in range(5):
        ang_lug = 2.0 * math.pi * k / 5.0 + math.pi / 2.0
        lx, lz = bolt_r * math.cos(ang_lug), bolt_r * math.sin(ang_lug)
        sock = _ring(
            "tmp_lsock",
            (
                (0.011, hub_d - 0.006), (0.013, hub_d + 0.003), (0.017, hub_d + 0.005),
                (0.022, hub_d - 0.003), (0.022, hub_d - 0.016), (0.011, hub_d - 0.016),
            ),
            side, soj, piv_spin, count=24,
        )
        sock.location = (lx, 0.0, lz)
        bparts.append(sock)
        well = _ring(
            "tmp_lwell",
            ((0.0, hub_d - 0.010), (0.013, hub_d - 0.010), (0.013, hub_d - 0.002), (0.0, hub_d - 0.002)),
            side, hole_mat, piv_spin, count=18, smooth=False,
        )
        well.location = (lx, 0.0, lz)
        bparts.append(well)
    # TPMS valve stem aligned cleanly in top lug-notch window (12 o'clock, 06-wheel-and-side-inlet.jpg!)
    bparts.append(make_cylinder(
        "tmp_valve", (0.0, side * (front - 0.022), rim - 0.013), (0.0, side * (front - 0.016), rim - 0.036),
        0.0045, 0.0038, steel, piv_spin, segments=10, world_coords=False,
    ))
    join_meshes(bparts, f"ZR1X_Wheel_Barrel_{tag}", piv_spin)

    # --- B) Sculpted 3D 20-Spoke Carbon Flash (SOJ) Split-Star Cross-Webbing Face (ZR1X_Wheel_Spokes_*) ---
    # Photo-matched directly to 06-wheel-and-side-inlet.jpg & 20-spoke-carbon-flash-forged-wheel.jpg:
    # Slender, razor-crisp forged beveled I-beam spokes (width ~0.95x real, NOT bloated 1.67x!)
    # so the 20-spoke cross-webbing reads sharply open & dark against the 420 mm CCB rotor & Alcon caliper!
    sparts: List[bpy.types.Object] = []
    scale = (rim - 0.008) / 242.0

    for k in range(5):
        angle = 2.0 * math.pi * k / 5.0

        def _to_local(u: float, down: float, depth: float) -> Tuple[float, float, float]:
            return (
                u * math.cos(angle) + down * math.sin(angle),
                side * depth,
                u * math.sin(angle) - down * math.cos(angle),
            )

        def _make_spoke(knots: Sequence[Tuple[float, float, float, float]]) -> bpy.types.Object:
            sections = []
            for j, (u, down, w_px, d_off) in enumerate(knots):
                prev_k = knots[max(0, j - 1)]
                next_k = knots[min(j + 1, len(knots) - 1)]
                du, dv = next_k[0] - prev_k[0], next_k[1] - prev_k[1]
                ln = max(1e-6, math.hypot(du, dv))
                nx, nz = -dv / ln, du / ln
                # Crisp sculpted forged spoke cross-section: narrow flat-beveled front face, deeper tapered rear web
                d_surf = front + d_off * concav
                sec = []
                for q, dy in (
                    (-0.92, -0.010), (-0.64, -0.0012), (-0.48, 0.0005), (0.48, 0.0005),
                    (0.64, -0.0012), (0.92, -0.010), (0.68, -0.0185), (-0.68, -0.0185),
                ):
                    hw = 1.16 * w_px * scale
                    sec.append(_to_local(u * scale + q * hw * nx, down * scale + q * hw * nz, d_surf + dy))
                sections.append(sec)
            return make_loft("tmp_spoke", sections, soj, piv_spin, world_coords=False, auto_smooth_deg=38.0)

        # 1) Primary radial spoke trunk (centered between adjacent lug nuts)
        sparts.append(_make_spoke((
            (0.0, 32.0, 9.2, -0.044), (0.0, 72.0, 8.2, -0.032), (0.0, 118.0, 6.8, -0.021), (0.0, 126.0, 6.2, -0.019),
        )))
        for br in (-1.0, 1.0):
            # 2) Wide primary Y-fork arm sweeping out to rim lip (10 rim contacts flanking the 5 lug angles!)
            sparts.append(_make_spoke((
                (0.0, 120.0, 6.0, -0.020), (br * 44.0, 162.0, 5.2, -0.011),
                (br * 84.0, 198.0, 4.6, -0.005), (br * 124.0, 214.0, 4.8, -0.002),
            )))
            # 3) Slender cross-webbing outer brace leaving lug shoulder, intersecting Y-fork -> rim (other 10 contacts!)
            sparts.append(_make_spoke((
                (br * 20.0, 58.0, 5.4, -0.043), (br * 41.0, 82.0, 4.6, -0.037),
                (br * 51.0, 152.0, 4.0, -0.017), (br * 58.0, 238.0, 4.4, -0.002),
            )))
            # 4) Scalloped lug-surround cross bridge tying adjacent sectors around each lug pocket
            sparts.append(_make_spoke((
                (br * 39.0, 80.0, 4.6, -0.037), (br * 61.0, 64.0, 4.4, -0.040), (br * 80.0, 63.0, 4.2, -0.036),
            )))
    join_meshes(sparts, f"ZR1X_Wheel_Spokes_{tag}", piv_spin)

    # --- C) 5 Black/Dark-Chrome Hex Lug Nuts (ZR1X_Wheel_LugNuts_*) ---
    lparts: List[bpy.types.Object] = []
    for k in range(5):
        ang_lug = 2.0 * math.pi * k / 5.0 + math.pi / 2.0
        lx, lz = bolt_r * math.cos(ang_lug), bolt_r * math.sin(ang_lug)
        lnut = _ring(
            "tmp_lnut",
            ((0.0, hub_d - 0.002), (0.0108, hub_d - 0.002), (0.0108, hub_d + 0.011), (0.0086, hub_d + 0.013), (0.0, hub_d + 0.013)),
            side, dark_chrome, piv_spin, count=6, smooth=False,
        )
        lnut.location = (lx, 0.0, lz)
        lparts.append(lnut)
    join_meshes(lparts, f"ZR1X_Wheel_LugNuts_{tag}", piv_spin)

    # --- D) Center Cap w/ Crisp Corvette Crossed-Flags Emblem (ZR1X_Wheel_CenterCap_*) ---
    cparts: List[bpy.types.Object] = []
    cap_y = hub_d + 0.009
    cparts.append(_ring(
        "tmp_cap_body",
        ((0.0, cap_y), (0.026, cap_y - 0.001), (0.030, cap_y - 0.005), (0.030, cap_y - 0.011)),
        side, gloss_blk, piv_spin, count=40,
    ))
    cparts.append(_ring(
        "tmp_cap_ring",
        ((0.025, cap_y - 0.0005), (0.0275, cap_y - 0.0012), (0.0275, cap_y - 0.003), (0.025, cap_y - 0.002)),
        side, steel, piv_spin, count=40,
    ))
    # Crisp 3D left (silver checkered) & right (Torch Red) crossed flags on cap face
    for s_flag, fmat in ((-1.0, white), (1.0, red)):
        pts_2d = ((0.0, -0.013), (s_flag * 0.019, 0.010), (s_flag * 0.016, -0.002), (s_flag * 0.004, -0.015))
        fv = [(u, side * (cap_y + dy), z) for dy in (0.0002, 0.0022) for u, z in pts_2d]
        cparts.append(make_mesh(
            "tmp_cflag", fv,
            [(0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7), (4, 5, 6, 7)],
            fmat, piv_spin, world_coords=False, smooth=False, recalc_normals=True,
        ))
    join_meshes(cparts, f"ZR1X_Wheel_CenterCap_{tag}", piv_spin)


# ---------------------------------------------------------------------------
# 4. Michelin Pilot Sport Cup 2 R ZP Tyre (under Pivot_WheelSpin_*)
# ---------------------------------------------------------------------------

def _build_tire(
    tag: str,
    side: float,
    radius: float,
    rim: float,
    half_w: float,
    piv_spin: bpy.types.Object,
    mats: Dict[str, bpy.types.Material],
) -> None:
    rubber = _m(mats, "Mat_Rubber_Tire")
    tread_dark = _m(mats, "Mat_Dark_Mesh", "Mat_Rubber_Tire")

    tparts: List[bpy.types.Object] = []
    # Sculpted rounded track-tyre sidewall + rim-protector bead + 4 circumferential channels
    prof = [
        (rim - 0.004, -half_w + 0.014),
        (rim + 0.010, -half_w + 0.003),
        (rim + 0.024, -half_w - 0.002),
        (0.915 * radius, -half_w),
        (0.972 * radius, -half_w + 0.011),
        (radius, -half_w + 0.032),
    ]
    for lane in (-0.50, -0.16, 0.19, 0.52):
        y0 = half_w * lane
        prof.extend([
            (radius, y0 - 0.0045),
            (radius - 0.0055, y0 - 0.0028),
            (radius - 0.0055, y0 + 0.0028),
            (radius, y0 + 0.0045),
        ])
    prof.extend([
        (radius, half_w - 0.032),
        (0.972 * radius, half_w - 0.011),
        (0.915 * radius, half_w),
        (rim + 0.024, half_w + 0.002),
        (rim + 0.010, half_w - 0.003),
        (rim - 0.004, half_w - 0.012),
        (rim - 0.004, -half_w + 0.014),
    ])
    tparts.append(_ring("tmp_tcasing", prof, side, rubber, piv_spin, count=128, auto_smooth_deg=52.0))

    # Molded outer sidewall circumferential styling ribs
    for rr in (rim + 0.017, radius - 0.024):
        tparts.append(_ring(
            "tmp_sbead",
            ((rr - 0.0018, half_w - 0.0005), (rr, half_w + 0.0008), (rr + 0.0018, half_w - 0.0005)),
            side, rubber, piv_spin, count=96,
        ))

    # Angled Michelin Pilot Sport Cup 2 R shoulder tread sipes
    vv, ff = [], []
    n_sipes = 72
    for k in range(n_sipes):
        for s0 in (-1.0, 1.0):
            seg = []
            for yf, rf in ((0.22, 1.0), (0.50, 1.0), (0.76, 1.0), (0.89, 0.986), (0.972, 0.952)):
                phi = 2.0 * math.pi * (k + 0.22 * (s0 + 1.0) * 0.5) / n_sipes + s0 * (0.042 * yf - 0.022 * yf * yf)
                wid = 0.0024 + 0.0020 * yf
                for d_ang in (-wid, wid):
                    r_p = radius * (rf + 0.0009)
                    seg.append((r_p * math.cos(phi + d_ang), side * s0 * half_w * yf, r_p * math.sin(phi + d_ang)))
            st = len(vv)
            vv.extend(seg)
            ff.extend((st + 2 * n, st + 2 * n + 1, st + 2 * n + 3, st + 2 * n + 2) for n in range(4))
    tparts.append(make_mesh("tmp_tsipes", vv, ff, tread_dark, piv_spin, world_coords=False, smooth=False, recalc_normals=True))

    join_meshes(tparts, f"ZR1X_Tire_{tag}", piv_spin)


# ---------------------------------------------------------------------------
# Public Contract
# ---------------------------------------------------------------------------

def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Populate all 4 ``Pivot_Corner_*`` and ``Pivot_WheelSpin_*`` hierarchies."""
    # Exact authoritative specs from v2_rig_spec.md:
    # Front: 20x10" SOJ, 275/30ZR20 (r=0.3365), 420 mm CCB + 10-piston Alcon
    # Rear:  21x13" SOJ, 345/25ZR21 (r=0.3530), 420 mm CCB + 6-piston Alcon
    specs = (
        ("FL", False, +1.0, TIRE_R_F, 0.275, 0.2540),
        ("FR", False, -1.0, TIRE_R_F, 0.275, 0.2540),
        ("RL", True,  +1.0, TIRE_R_R, 0.345, 0.2667),
        ("RR", True,  -1.0, TIRE_R_R, 0.345, 0.2667),
    )
    for tag, is_rear, side, radius, width, rim in specs:
        piv_corner = pivots[f"Pivot_Corner_{tag}"]
        piv_spin = pivots[f"Pivot_WheelSpin_{tag}"]
        half_w = width * 0.5
        front = half_w - 0.012
        friction = front - (0.088 if is_rear else 0.077)

        _build_upright_and_caliper(tag, is_rear, side, friction, radius, piv_corner, mats)
        _build_ccb_rotor(tag, side, friction, piv_spin, mats)
        _build_soj_wheel(tag, is_rear, side, rim, half_w, front, piv_spin, mats)
        _build_tire(tag, side, radius, rim, half_w, piv_spin, mats)
