"""LT7 5.5L DOHC flat-plane-crank twin-turbo V8 for ZR1X v2.

Populates ``Pivot_LT7_Engine`` (world pos ``(-0.820, 0.000, +0.520)``).
Photo-matched to the 6000x6000 Autoweek LT7 studio shots, GM TechLink charge-air
plumbing diagram, and Spexx/AUTO777 engine bay photos.

Exact handoff datums (V2 world meters):
- Rear flywheel / bellhousing flange: ``X = -1.195, Y = 0.000, Z = +0.448``
- Left / Right maniturbo turbine outlet flanges: ``X = -1.120, Y = ±0.385, Z = +0.492``
- Front accessory drive stays aft of ``X = -0.470`` to clear cabin rear bulkhead.
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

import bpy
import numpy as np
from mathutils import Euler, Vector

from rig_utils import (
    join_meshes,
    make_cylinder,
    make_loft,
    make_mesh,
    make_roundbox,
    make_tube,
    parent_to_pivot,
    pivot_world_pos,
    world_to_pivot_local,
)


def _m(mats: Dict[str, bpy.types.Material], key: str, fallback: str = "Mat_Aluminum_Cast") -> bpy.types.Material:
    return mats.get(key) or mats.get(fallback) or next(iter(mats.values()))


def _sculpted_cover(
    name: str,
    stations: Sequence[Tuple[float, float, float, float, float]],
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    uv_scale: float | None = None,
) -> bpy.types.Object:
    profile = (
        (-0.73, -1.0), (0.73, -1.0), (0.98, -0.63), (1.0, 0.02),
        (0.91, 0.57), (0.60, 0.93), (0.0, 1.0), (-0.60, 0.93),
        (-0.91, 0.57), (-1.0, 0.02), (-0.98, -0.63),
    )
    sections = [[(x, y + h * u, z + d * v) for u, v in profile] for x, y, z, h, d in stations]
    return make_loft(name, sections, mat, pivot, smooth=True, auto_smooth_deg=45.0, uv_scale=uv_scale)


def _ellipse_case(
    name: str,
    stations: Sequence[Tuple[float, float, float, float, float]],
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "x",
    steps: int = 32,
) -> bpy.types.Object:
    sections = []
    for axial, u0, z0, ru, rz in stations:
        ring = []
        for j in range(steps):
            t = 2.0 * math.pi * j / steps
            u = u0 + ru * math.cos(t)
            z = z0 + rz * math.sin(t)
            ring.append((axial, u, z) if axis == "x" else (u, axial, z))
        sections.append(ring if axis == "x" else ring[::-1])
    return make_loft(name, sections, mat, pivot, smooth=True, auto_smooth_deg=48.0)


def _section_ring(
    name: str,
    x: float,
    y: float,
    z: float,
    r: float,
    thick: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "x",
    width: float = 0.008,
    steps: int = 44,
) -> bpy.types.Object:
    verts = []
    faces = []
    stations = (
        (-width * 0.5, r), (-width * 0.36, r + thick), (width * 0.36, r + thick),
        (width * 0.5, r), (width * 0.5, max(0.001, r - 0.001)), (-width * 0.5, max(0.001, r - 0.001)),
    )
    for depth, rr in stations:
        for j in range(steps):
            a = 2.0 * math.pi * j / steps
            u, v = rr * math.cos(a), rr * math.sin(a)
            if axis == "x":
                verts.append((x + depth, y + u, z + v))
            else:
                verts.append((x + u, y + depth, z + v))
    for i in range(len(stations)):
        ni = (i + 1) % len(stations)
        for j in range(steps):
            nj = (j + 1) % steps
            faces.append((i * steps + j, i * steps + nj, ni * steps + nj, ni * steps + j))
    return make_mesh(name, verts, faces, mat, pivot, smooth=True, recalc_normals=True)


def _bolt_cluster(
    name: str,
    centers: Sequence[Tuple[float, float, float]],
    radius: float,
    height: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "z",
) -> bpy.types.Object:
    verts = []
    faces = []
    for cx, cy, cz in centers:
        base = len(verts)
        for off, r in ((0.0, radius), (height * 0.82, radius), (height, radius * 0.80)):
            for k in range(6):
                a = k * math.pi / 3.0
                u, v = r * math.cos(a), r * math.sin(a)
                if axis == "z":
                    verts.append((cx + u, cy + v, cz + off))
                elif axis == "x":
                    verts.append((cx + off, cy + u, cz + v))
                else:
                    verts.append((cx + u, cy + off, cz + v))
        for j in range(2):
            for k in range(6):
                nk = (k + 1) % 6
                faces.append((base + j * 6 + k, base + j * 6 + nk, base + (j + 1) * 6 + nk, base + (j + 1) * 6 + k))
        faces.append(tuple(base + 12 + k for k in range(6)))
    return make_mesh(name, verts, faces, mat, pivot, smooth=False, recalc_normals=True)


def _text_to_mesh(
    name: str,
    body: str,
    world_loc: Tuple[float, float, float],
    size: float,
    rot_euler: Tuple[float, float, float],
    extrude: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
) -> bpy.types.Object:
    """Create crisp 3D lettering converted directly to a MESH object (no FONT leftovers)."""
    cu = bpy.data.curves.new(name + "_font", "FONT")
    cu.body = body
    cu.size = size
    cu.align_x = "CENTER"
    cu.align_y = "CENTER"
    cu.extrude = extrude
    cu.resolution_u = 4
    f_obj = bpy.data.objects.new(name + "_fobj", cu)
    bpy.context.scene.collection.objects.link(f_obj)
    f_obj.location = world_to_pivot_local(world_loc, pivot)
    f_obj.rotation_euler = Euler(rot_euler, "XYZ")
    f_obj.parent = pivot
    f_obj.matrix_parent_inverse.identity()

    bpy.context.view_layer.update()
    deps = bpy.context.evaluated_depsgraph_get()
    eval_obj = f_obj.evaluated_get(deps)
    me = bpy.data.meshes.new_from_object(eval_obj, preserve_all_data_layers=False, depsgraph=deps)
    me.name = name
    me.materials.append(mat)
    # Bake local transform directly into mesh vertices so object stays at identity
    me.transform(f_obj.matrix_local)
    me.update()

    bpy.data.objects.remove(f_obj, do_unlink=True)
    bpy.data.curves.remove(cu)

    obj = bpy.data.objects.new(name, me)
    parent_to_pivot(obj, pivot, coords_are_world=False)
    return obj


# Plenum crown contour (V2 X: -0.545 front to -1.111 rear)
_PLENUM_STATIONS = (
    (-0.585, 0.069, 0.747),
    (-0.615, 0.113, 0.784),
    (-0.680, 0.130, 0.813),
    (-0.818, 0.135, 0.820),
    (-0.980, 0.131, 0.810),
    (-1.047, 0.120, 0.796),
    (-1.079, 0.095, 0.780),
)
_PX = np.array([s[0] for s in _PLENUM_STATIONS][::-1])
_PZ = np.array([s[2] for s in _PLENUM_STATIONS][::-1])


def _crown_z(xx: float) -> float:
    return float(np.interp(xx, _PX, _PZ))


# ---------------------------------------------------------------------------
# Sub-Assembly Builders
# ---------------------------------------------------------------------------

def _build_crankcase_and_sump(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    gun = _m(mats, "Mat_Gear_Steel")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    steel = _m(mats, "Mat_Steel_Machined")
    rubber = _m(mats, "Mat_Rubber_Black")

    # 1) ZR1X_Eng_Crankcase
    cparts: List[bpy.types.Object] = []
    cparts.append(_sculpted_cover(
        "tmp_block",
        (
            (-0.520, 0.0, 0.433, 0.155, 0.136),
            (-0.560, 0.0, 0.433, 0.198, 0.142),
            (-0.740, 0.0, 0.430, 0.210, 0.145),
            (-1.100, 0.0, 0.430, 0.214, 0.142),
            (-1.188, 0.0, 0.428, 0.188, 0.140),
        ),
        cast, piv,
    ))
    # Front aluminum timing cover casting (Autoweek 3/4 view)
    cparts.append(_ellipse_case(
        "tmp_timing",
        (
            (-0.486, 0.0, 0.440, 0.120, 0.128),
            (-0.508, 0.0, 0.442, 0.146, 0.156),
            (-0.542, 0.0, 0.448, 0.156, 0.168),
        ),
        cast, piv,
    ))
    # Timing cover cooling ribs & oil/coolant sensor bosses
    for s in (-1.0, 1.0):
        cparts.append(make_cylinder(
            "tmp_cam_phaser_boss",
            (-0.490, s * 0.195, 0.565), (-0.540, s * 0.195, 0.565),
            0.044, 0.048, cast, piv, segments=18,
        ))
        for j in range(3):
            cparts.append(make_tube(
                "tmp_bell_buttress",
                [
                    (-1.135, s * (0.078 + 0.046 * j), 0.430),
                    (-1.162, s * (0.110 + 0.052 * j), 0.490),
                    (-1.138, s * (0.142 + 0.044 * j), 0.540 + 0.022 * j),
                ],
                0.012, cast, piv, segments=10,
            ))
    # Rear cast bellhousing mounting plate
    cparts.append(_ellipse_case(
        "tmp_rear_plate",
        ((-1.178, 0.0, 0.448, 0.184, 0.182), (-1.188, 0.0, 0.448, 0.182, 0.180)),
        cast, piv,
    ))
    join_meshes(cparts, "ZR1X_Eng_Crankcase", piv)

    # 2) ZR1X_Eng_DrySump (finned pan + 7-stage scavenge pump + signature front-right black oil reservoir tank!)
    sparts: List[bpy.types.Object] = []
    sparts.append(_sculpted_cover(
        "tmp_pan",
        (
            (-0.534, 0.0, 0.288, 0.149, 0.024),
            (-0.600, 0.0, 0.268, 0.192, 0.047),
            (-0.876, 0.0, 0.263, 0.198, 0.050),
            (-1.070, 0.0, 0.269, 0.181, 0.043),
            (-1.164, 0.0, 0.292, 0.148, 0.022),
        ),
        gun, piv,
    ))
    # Longitudinal dry-sump pan cooling fins
    for yy in np.linspace(-0.14, 0.14, 7):
        sparts.append(make_roundbox("tmp_sfin", (-0.838, float(yy), 0.215), (0.39, 0.006, 0.010), brushed, piv, bevel=0.001))
    # External 7-stage dry-sump scavenge pump housing along lower passenger (-Y) block skirt
    sparts.append(make_cylinder(
        "tmp_7stage", (-0.58, -0.205, 0.335), (-0.96, -0.205, 0.335),
        0.042, 0.038, brushed, piv, segments=18,
    ))
    for k in range(7):
        sparts.append(_section_ring("tmp_stage_rib", -0.61 - 0.048 * k, -0.205, 0.335, 0.040, 0.005, gun, piv, width=0.012, steps=24))
    # Tall sculpted black dry-sump oil reservoir tank on forward-right (-Y, Autoweek 3/4 & side view!)
    # The front elevation shows a broad upper reservoir and a stepped,
    # narrower lower foot. The folded seam follows the outline of both shells.
    tank_profile = [(-.380,.325),(-.367,.291),(-.344,.238),(-.266,.238),
                    (-.253,.296),(-.284,.355),(-.266,.430),(-.246,.452),
                    (-.247,.615),(-.274,.680),(-.340,.697),(-.384,.632)]
    sparts.append(make_loft("tmp_tank_shell",
        [[(xx,yy,zz) for yy,zz in tank_profile] for xx in (-.625,-.606,-.506,-.488)],
        dark,piv,smooth=False))
    sparts.append(make_tube("tmp_tank_flange",
        [(-.486,yy,zz) for yy,zz in tank_profile], .004,gun,piv,cyclic=True))
    sparts.append(make_tube("tmp_tank_lower_brace",
        [(-.485,-.349,.397),(-.483,-.348,.347),(-.483,-.295,.321),
         (-.483,-.285,.295)],.008,brushed,piv,segments=8))
    sparts.append(_bolt_cluster("tmp_tank_fasteners",
        [(-.486,-.362,.603),(-.486,-.264,.603),(-.486,-.360,.433),(-.486,-.275,.444)],
        .0065,.004,steel,piv,axis="x"))
    # Oil fill neck + dexosR cap on top of tank
    sparts.append(make_cylinder("tmp_fill_neck", (-0.545, -0.315, 0.680), (-0.545, -0.315, 0.742), 0.026, 0.026, dark, piv, segments=18))
    sparts.append(make_cylinder("tmp_fill_cap", (-0.545, -0.315, 0.742), (-0.545, -0.315, 0.760), 0.032, 0.030, gun, piv, segments=18))
    # Braided oil feed/scavenge lines from tank to 7-stage pump & block
    sparts.append(make_tube(
        "tmp_oil_line1",
        [(-0.56, -0.30, 0.34), (-0.57, -0.25, 0.32), (-0.61, -0.21, 0.33)],
        0.011, rubber, piv, segments=10,
    ))
    sparts.append(make_tube(
        "tmp_oil_line2",
        [(-0.55, -0.28, 0.62), (-0.52, -0.22, 0.60), (-0.53, -0.17, 0.54)],
        0.010, steel, piv, segments=10,
    ))
    join_meshes(sparts, "ZR1X_Eng_DrySump", piv)


def _build_banks_covers_coils(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    gun = _m(mats, "Mat_Gear_Steel")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    rubber = _m(mats, "Mat_Rubber_Black")
    steel = _m(mats, "Mat_Steel_Machined")

    for s, tag in ((1.0, "L"), (-1.0, "R")):
        # Cylinder bank & 4-valve DOHC head
        bparts: List[bpy.types.Object] = []
        bank_secs = []
        for xx, wid in ((-0.54, 0.94), (-0.58, 1.0), (-0.72, 1.0), (-1.09, 1.0), (-1.145, 0.96)):
            bank_secs.append([
                (xx, s * yy * wid, zz)
                for yy, zz in ((0.06, 0.39), (0.14, 0.355), (0.335, 0.539), (0.352, 0.612), (0.255, 0.682), (0.124, 0.60), (0.065, 0.48))
            ])
        bparts.append(make_loft("tmp_bank", bank_secs, cast, piv, auto_smooth_deg=42.0))
        # Cast exterior cylinder head cooling webs
        for j in range(6):
            xx = -0.60 - 0.095 * j
            bparts.append(make_tube(
                "tmp_head_web",
                [(xx, s * 0.157, 0.406), (xx - 0.022, s * 0.248, 0.495), (xx - 0.028, s * 0.315, 0.550)],
                0.008, cast, piv, segments=8,
            ))
        # Rear cam-end cover plates & bolts (Autoweek rear view!)
        bparts.append(_ellipse_case(
            "tmp_cam_end",
            ((-1.130, s * 0.245, 0.625, 0.107, 0.064), (-1.144, s * 0.245, 0.625, 0.105, 0.061), (-1.150, s * 0.245, 0.625, 0.090, 0.055)),
            gun, piv, steps=24,
        ))
        bparts.append(_bolt_cluster(
            "tmp_cebolts",
            [(-1.148, s * 0.245 + 0.090 * math.cos(t), 0.625 + 0.048 * math.sin(t))
             for t in np.linspace(0, 2 * math.pi, 6, endpoint=False)],
            0.006, -0.006, brushed, piv, axis="x",
        ))
        # Rear breather hose
        bparts.append(make_tube(
            "tmp_breather",
            [(-1.103, s * 0.269, 0.656), (-1.147, s * 0.236, 0.675), (-1.158, s * 0.163, 0.637), (-1.153, s * 0.141, 0.595)],
            0.0085, rubber, piv, segments=10,
        ))
        join_meshes(bparts, f"ZR1X_Eng_Bank_{tag}", piv)

        # DOHC Cam Cover
        vparts: List[bpy.types.Object] = []
        vparts.append(_sculpted_cover(
            "tmp_camcov",
            (
                (-0.548, s * 0.245, 0.627, 0.092, 0.045),
                (-0.575, s * 0.245, 0.644, 0.105, 0.054),
                (-1.097, s * 0.245, 0.644, 0.105, 0.054),
                (-1.140, s * 0.245, 0.627, 0.088, 0.043),
            ),
            dark, piv,
        ))
        for off in (-0.020, 0.020):
            vparts.append(make_tube(
                "tmp_vflange",
                [(xx, s * (yy + off), zz) for xx, yy, zz in ((-0.555, 0.275, 0.650), (-0.59, 0.29, 0.672), (-1.09, 0.29, 0.672), (-1.14, 0.27, 0.648))],
                0.0052, brushed, piv, segments=8,
            ))
        vparts.append(_bolt_cluster(
            "tmp_vcbolts",
            [(x, s * y, 0.676) for x in (-0.576, -0.72, -0.85, -0.98, -1.104) for y in (0.174, 0.310)],
            0.0055, 0.007, steel, piv, axis="z",
        ))
        join_meshes(vparts, f"ZR1X_Eng_CamCover_{tag}", piv)

        # 4 Ignition Coil Packs + Harness Loom
        kparts: List[bpy.types.Object] = []
        for j in range(4):
            xx = -0.624 - j * 0.131
            kparts.append(make_roundbox("tmp_coil", (xx, s * 0.251, 0.702), (0.068, 0.070, 0.032), gun, piv, bevel=0.008))
            kparts.append(make_roundbox("tmp_clatch", (xx - 0.024, s * 0.274, 0.708), (0.020, 0.022, 0.016), dark, piv, bevel=0.003))
            kparts.append(make_tube(
                "tmp_cbranch",
                [(xx, s * 0.254, 0.706), (xx - 0.023, s * 0.299, 0.715), (xx - 0.035, s * 0.326, 0.684), (xx - 0.046, s * 0.330, 0.655)],
                0.0052, rubber, piv, segments=8,
            ))
        kparts.append(make_tube(
            "tmp_cloom",
            [(-0.555, s * 0.320, 0.660), (-0.66, s * 0.333, 0.660), (-0.91, s * 0.337, 0.658), (-1.039, s * 0.332, 0.651), (-1.130, s * 0.309, 0.608)],
            0.0085, rubber, piv, segments=10,
        ))
        join_meshes(kparts, f"ZR1X_Eng_CoilPack_{tag}", piv)


def _build_intake_and_fuel(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    blue = _m(mats, "Mat_LT7_Plenum_Blue")
    blue_bsdf = blue.node_tree.nodes.get("Principled BSDF")
    blue_bsdf.inputs["Base Color"].default_value = (0.078, 0.174, 0.362, 1.0)
    blue_bsdf.inputs["Roughness"].default_value = 0.34
    blue_bsdf.inputs["Coat Weight"].default_value = 0.34
    carbon = _m(mats, "Mat_Carbon_Twill_2x2")
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    steel = _m(mats, "Mat_Steel_Machined")
    gun = _m(mats, "Mat_Gear_Steel")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    mesh_dark = _m(mats, "Mat_Dark_Mesh", "Mat_Black_Trim_Satin")
    white = _m(mats, "Mat_White_Paint", "Mat_Plate_Silver")
    red = _m(mats, "Mat_Emblem_Red", "Mat_Torch_Red_GKZ")
    rad = _m(mats, "Mat_Radiator_Core", "Mat_Aluminum_Brushed")

    # 1) Signature Blue LT7 Sculpted Dual-Plenum Intake (ZR1X_Eng_IntakePlenum)
    pparts: List[bpy.types.Object] = []
    shoulder_prof = (
        (0.270, 0.010), (0.315, 0.015), (0.43, 0.015), (0.650, 0.011), (0.825, 0.005),
        (0.940, -0.004), (1.000, -0.013), (0.970, -0.032), (0.850, -0.044), (0.440, -0.045), (0.260, -0.031),
    )
    for s in (-1.0, 1.0):
        secs = []
        for xx, hw, ztop in _PLENUM_STATIONS:
            # Lateral bulge at mid-plenum where dual throttle bodies bolt on (Spexx 120!)
            bulge = 1.035 if (-0.98 < xx < -0.70) else 1.0
            secs.append([(xx, s * hw * bulge * yy, ztop + zz) for yy, zz in shoulder_prof])
        pparts.append(make_loft("tmp_blue_rail", secs, blue, piv, auto_smooth_deg=44.0, uv_scale=8.0))
        # Blue throttle-inlet shoulder bosses
        pparts.append(make_cylinder(
            "tmp_tb_boss", (-0.84, s * 0.122, 0.778), (-0.84, s * 0.155, 0.768),
            0.046, 0.044, blue, piv, segments=22,
        ))
    # Lower dark plenum carrier
    pparts.append(_sculpted_cover(
        "tmp_pcarrier",
        (
            (-0.553, 0.0, 0.735, 0.070, 0.018), (-0.581, 0.0, 0.752, 0.115, 0.038),
            (-0.667, 0.0, 0.766, 0.138, 0.042), (-0.860, 0.0, 0.765, 0.138, 0.044),
            (-1.040, 0.0, 0.748, 0.126, 0.039), (-1.109, 0.0, 0.729, 0.088, 0.025),
        ),
        dark, piv,
    ))
    # Central brushed-silver / carbon spine trim with 4 hex-perforated recesses (Spexx 120!)
    pparts.append(_sculpted_cover(
        "tmp_spine_trim",
        [(x, 0.0, z + 0.010, w * 0.34, 0.010) for x, w, z in _PLENUM_STATIONS],
        brushed, piv,
    ))
    # Dark hex-perforation inserts along the 4 spine windows
    hv, hf = [], []
    for col in range(6):
        for row in range(28):
            xx = -0.602 - row * 0.0108 - (col % 2) * 0.0054
            yy = (col - 2.5) * 0.0092
            st = len(hv)
            for j in range(6):
                px = xx + 0.0048 * math.cos(math.pi * j / 3.0)
                py = yy + 0.0048 * math.sin(math.pi * j / 3.0)
                hv.append((px, py, _crown_z(px) + 0.021))
            hf.append(tuple(st + j for j in range(6)))
    pparts.append(make_mesh("tmp_hex_perf", hv, hf, mesh_dark, piv, smooth=False))
    # 4 sculpted chevron spine bridges + 10 stainless cap screws
    screw_pts = []
    for xx in (-0.618, -0.716, -0.816, -0.916):
        for s in (-1.0, 1.0):
            ys = (s * 0.038, s * 0.020, 0.0)
            tri = ((xx + 0.020, ys[0]), (xx - 0.005, ys[0]), (xx - 0.036, ys[2]), (xx - 0.020, ys[2]))
            bv = [(x, y, _crown_z(x) + h) for h in (0.020, 0.027) for x, y in tri]
            pparts.append(make_mesh("tmp_pbridge", bv, [(0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7), (4, 5, 6, 7)], gun, piv, smooth=False, recalc_normals=True))
            screw_pts.append((xx, s * 0.032, _crown_z(xx) + 0.027))
    screw_pts.extend([(-0.99, s * 0.032, _crown_z(-0.99) + 0.025) for s in (-1.0, 1.0)])
    pparts.append(_bolt_cluster("tmp_pscrews", screw_pts, 0.0055, 0.004, steel, piv, axis="z"))

    # 3D Sculpted Corvette Crossed-Flags Emblem on Plenum Crown
    for s, fmat in ((1.0, white), (-1.0, red)):
        xy = ((-0.956, 0.0), (-0.918, s * 0.050), (-0.942, s * 0.046), (-0.974, 0.0))
        fv = [(x, y, _crown_z(x) + h) for h in (0.0205, 0.0255) for x, y in xy]
        pparts.append(make_mesh(
            "tmp_pflag", fv,
            [(0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7), (4, 5, 6, 7)],
            fmat, piv, smooth=False, recalc_normals=True,
        ))
    join_meshes(pparts, "ZR1X_Eng_IntakePlenum", piv)

    # 2) Builder Identification Plaque (ZR1X_Eng_PlenumPlaque)
    qparts: List[bpy.types.Object] = []
    qx = -1.045
    # Negative atan so +Y rotation pitches aft (-X) edge DOWN to hug the rear plenum slope flush!
    tilt = -math.atan((_crown_z(qx + 0.004) - _crown_z(qx - 0.004)) / 0.008)
    qz = _crown_z(qx) + 0.021
    qparts.append(make_roundbox("tmp_plaque_base", (qx, 0.0, qz), (0.074, 0.070, 0.004), brushed, piv, bevel=0.0015, rot_euler=(0.0, tilt, 0.0)))
    qparts.append(make_roundbox("tmp_plaque_field", (qx - 0.006, 0.0, qz + 0.0022), (0.044, 0.060, 0.0028), dark, piv, bevel=0.001, rot_euler=(0.0, tilt, 0.0)))
    # Crisp 3D converted typography reading CORVETTE / LT7 flush along the tilted plaque surface
    qparts.append(_text_to_mesh("tmp_txt_corv", "CORVETTE", (qx + 0.021, 0.0, qz + 0.0045 - 0.021 * math.sin(tilt)), 0.0072, (0.0, tilt, math.pi / 2.0), 0.0007, dark, piv))
    qparts.append(_text_to_mesh("tmp_txt_lt7", "LT7", (qx - 0.006, 0.0, qz + 0.0048 + 0.006 * math.sin(tilt)), 0.0155, (0.0, tilt, math.pi / 2.0), 0.0009, white, piv))
    join_meshes(qparts, "ZR1X_Eng_PlenumPlaque", piv)

    # 3) Lower Valley Body, 8 Cast Runners, Dual Throttle Bodies & Twin Charge-Air Intercoolers (ZR1X_Eng_IntakeRunners)
    rparts: List[bpy.types.Object] = []
    rparts.append(_sculpted_cover(
        "tmp_valley",
        (
            (-0.566, 0.0, 0.668, 0.080, 0.070), (-0.605, 0.0, 0.674, 0.114, 0.082),
            (-0.780, 0.0, 0.674, 0.124, 0.092), (-1.049, 0.0, 0.664, 0.112, 0.087), (-1.100, 0.0, 0.653, 0.092, 0.073),
        ),
        gun, piv,
    ))
    for s in (-1.0, 1.0):
        for j in range(4):
            xx = -0.611 - 0.131 * j
            rparts.append(make_tube(
                "tmp_runner",
                [(xx + 0.015, s * 0.093, 0.712), (xx, s * 0.130, 0.692), (xx - 0.007, s * 0.168, 0.662), (xx - 0.013, s * 0.200, 0.636)],
                0.028, cast, piv, segments=14,
            ))
        # Electronic throttle body housing bolted to plenum lateral boss
        rparts.append(make_cylinder("tmp_tb", (-0.84, s * 0.150, 0.768), (-0.84, s * 0.238, 0.754), 0.044, 0.042, brushed, piv, segments=22))
        rparts.append(make_roundbox("tmp_tb_motor", (-0.79, s * 0.215, 0.742), (0.045, 0.048, 0.052), dark, piv, bevel=0.006))
        # Side-mounted cast aluminum Charge-Air Intercooler (ICAC) above each bank (Autoweek 3/4 & side!)
        rparts.append(make_roundbox("tmp_icac_core", (-0.85, s * 0.305, 0.718), (0.220, 0.092, 0.088), rad, piv, bevel=0.008, rot_euler=(s * 0.32, 0.0, 0.0)))
        rparts.append(make_roundbox("tmp_icac_in", (-0.73, s * 0.325, 0.698), (0.068, 0.096, 0.088), cast, piv, bevel=0.012, rot_euler=(s * 0.32, 0.0, 0.0)))
        rparts.append(make_roundbox("tmp_icac_out", (-0.96, s * 0.295, 0.728), (0.060, 0.094, 0.086), cast, piv, bevel=0.012, rot_euler=(s * 0.32, 0.0, 0.0)))
    join_meshes(rparts, "ZR1X_Eng_IntakeRunners", piv)

    # 4) Twin Stainless Fuel Rails & 8 Injectors (ZR1X_Eng_FuelRails)
    fparts: List[bpy.types.Object] = []
    for s in (-1.0, 1.0):
        fparts.append(make_tube(
            "tmp_frail", [(-0.575, s * 0.158, 0.706), (-0.830, s * 0.156, 0.708), (-1.085, s * 0.154, 0.706)],
            0.0105, steel, piv, segments=12,
        ))
        for j in range(4):
            xx = -0.611 - 0.131 * j
            fparts.append(make_tube(
                "tmp_inj", [(xx, s * 0.158, 0.705), (xx, s * 0.176, 0.702), (xx - 0.008, s * 0.184, 0.678)],
                0.007, brushed, piv, segments=10,
            ))
    # Rear fuel crossover pipe
    fparts.append(make_tube(
        "tmp_fxover",
        [(-1.082, 0.154, 0.706), (-1.115, 0.095, 0.698), (-1.115, -0.095, 0.698), (-1.082, -0.154, 0.706)],
        0.0075, steel, piv, segments=10,
    ))
    join_meshes(fparts, "ZR1X_Eng_FuelRails", piv)


def _build_maniturbos_and_chargepipes(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    steel = _m(mats, "Mat_Steel_Machined")
    heat = _m(mats, "Mat_Heat_Shield").copy()
    heat.name = "Mat_LT7_Turbine_Blanket"
    bsdf = heat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (0.26, 0.171, 0.049, 1.0)
    bsdf.inputs["Metallic"].default_value = 0.58
    bsdf.inputs["Roughness"].default_value = 0.51
    exhaust_mat = _m(mats, "Mat_Titanium_Exhaust")
    gun = _m(mats, "Mat_Gear_Steel")
    rubber = _m(mats, "Mat_Rubber_Black")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    mesh_dark = _m(mats, "Mat_Dark_Mesh", "Mat_Black_Trim_Satin")

    for s, tag in ((1.0, "L"), (-1.0, "R")):
        # --- Integrated Exhaust-Manifold Turbocharger (ZR1X_Eng_Maniturbo_L/R) ---
        tparts: List[bpy.types.Object] = []
        # 4-into-1 cast exhaust manifold runners sweeping directly into turbine scroll
        for j in range(4):
            xx = -0.611 - 0.131 * j
            tparts.append(make_tube(
                "tmp_exh_run",
                [(xx, s * 0.312, 0.525), (xx - 0.015, s * 0.354, 0.502), (-0.91 - 0.036 * j, s * 0.376, 0.478)],
                0.025, exhaust_mat, piv, segments=12,
            ))

        # Spiral cast-aluminum compressor volute (forward side of turbo at X=-0.895, Autoweek side!)
        cx, cy, cz = -0.895, s * 0.382, 0.496
        vol_secs = []
        for ang in np.linspace(-0.25 * math.pi, 1.66 * math.pi, 44):
            phase = (ang + 0.25 * math.pi) / (1.91 * math.pi)
            cr = 0.064 + 0.018 * phase
            rr = 0.014 + 0.032 * phase
            vol_secs.append([
                (cx - (cr + rr * math.cos(b)) * math.cos(ang),
                 cy + s * rr * math.sin(b),
                 cz + (cr + rr * math.cos(b)) * math.sin(ang))
                for b in np.linspace(0, 2 * math.pi, 18, endpoint=False)
            ])
        tparts.append(make_loft("tmp_volute", vol_secs, cast, piv, auto_smooth_deg=55.0))
        # Compressor snout facing outboard/forward
        tparts.append(make_cylinder("tmp_comp_inlet", (cx, cy, cz), (cx, cy + s * 0.075, cz), 0.044, 0.038, cast, piv, segments=22))

        # Turbine housing wrapped in quilted gold/bronze Inconel heat shield (Autoweek side & rear!)
        tparts.append(_ellipse_case(
            "tmp_tshield",
            (
                (-0.936, s * 0.399, 0.486, 0.082, 0.080),
                (-0.975, s * 0.408, 0.482, 0.110, 0.113),
                (-1.059, s * 0.404, 0.485, 0.107, 0.110),
                (-1.106, s * 0.385, 0.492, 0.074, 0.072),
            ),
            heat, piv, steps=28,
        ))
        # Embossed shield ribs + bright V-band coupling clamp + adjuster
        for xx, yoff, rr in ((-0.964, 0.406, 0.105), (-1.066, 0.402, 0.106)):
            tparts.append(_section_ring("tmp_vband", xx, s * yoff, 0.485, rr, 0.002, steel, piv, width=0.006, steps=40))
        for ang in np.linspace(0, 2 * math.pi, 12, endpoint=False):
            seam = []
            for xx, radius in ((-0.965, 0.100), (-0.993, 0.112), (-1.027, 0.110), (-1.06, 0.106)):
                phase = ang + (xx + 1.01) * 2.4
                seam.append((xx, s * (0.406 + radius * math.cos(phase)), 0.484 + radius * math.sin(phase)))
            tparts.append(make_tube("tmp_shield_seam", seam, 0.0016, heat, piv, segments=6))
        tparts.append(make_roundbox("tmp_vadj", (-1.076, s * 0.440, 0.562), (0.018, 0.036, 0.014), steel, piv, bevel=0.003))
        # Electronic wastegate actuator canister & linkage rod
        tparts.append(make_cylinder("tmp_wg", (-0.87, s * 0.455, 0.560), (-0.93, s * 0.455, 0.560), 0.026, 0.026, dark, piv, segments=16))
        tparts.append(make_cylinder("tmp_wg_rod", (-0.93, s * 0.455, 0.560), (-1.04, s * 0.445, 0.535), 0.004, 0.004, steel, piv, segments=8))
        # Stainless oil/coolant turbo feed lines
        tparts.append(make_tube(
            "tmp_toil",
            [(-0.94, s * 0.35, 0.54), (-0.95, s * 0.41, 0.56), (-0.98, s * 0.41, 0.52)],
            0.0055, steel, piv, segments=8,
        ))

        # Exact rear 5-bolt circular turbine outlet flange at X=-1.120, Y=±0.385, Z=+0.492 (handoff to mech_exhaust.py!)
        tparts.append(_ellipse_case(
            "tmp_tout_flange",
            ((-1.102, s * 0.385, 0.492, 0.076, 0.073), (-1.114, s * 0.385, 0.492, 0.080, 0.077), (-1.121, s * 0.385, 0.492, 0.078, 0.076)),
            brushed, piv, steps=28,
        ))
        tparts.append(_ellipse_case(
            "tmp_tout_bore",
            ((-1.119, s * 0.385, 0.492, 0.054, 0.052), (-1.122, s * 0.385, 0.492, 0.054, 0.052)),
            mesh_dark, piv, steps=24,
        ))
        tparts.append(_bolt_cluster(
            "tmp_tout_nuts",
            [(-1.121, s * 0.385 + 0.066 * math.cos(t), 0.492 + 0.062 * math.sin(t))
             for t in np.linspace(0.15, 2 * math.pi + 0.15, 5, endpoint=False)],
            0.006, -0.005, steel, piv, axis="x",
        ))
        join_meshes(tparts, f"ZR1X_Eng_Maniturbo_{tag}", piv)

        # --- Charge Pipes & Turbo Air Inlet Ducts (ZR1X_Eng_ChargePipe_L/R) ---
        cparts: List[bpy.types.Object] = []
        # Swept large black composite turbo inlet duct curving from rear airbox around bank to compressor front (Autoweek rear!)
        cparts.append(make_tube(
            "tmp_inlet_duct",
            [
                (-1.165,s*.215,.565),(-1.138,s*.293,.590),(-1.084,s*.377,.648),
                (-1.016,s*.416,.696),(-.917,s*.422,.721),(-.820,s*.424,.718),
                (-.770,s*.433,.698),(-.731,s*.446,.650),(-.719,s*.455,.570),
                (-.728,s*.462,.476),(-.754,s*.467,.420),(-.786,s*.462,.398),
                (-.829,s*.455,.406),(-.866,s*.452,.449),(-.895,s*.448,.496),
            ],
            .048, dark, piv, segments=24,
        ))
        for x0,x1,yy,zz in ((-.987,-.975,.418,.708),(-.859,-.848,.424,.720)):
            cparts.append(make_cylinder("tmp_inlet_band", (x0,s*yy,zz),(x1,s*yy,zz),
                .050,.050,brushed,piv,segments=30))
        # Cast lower compressor connection visible below the outboard hose.
        cparts.append(_ellipse_case("tmp_lower_elbow_flange",
            ((-.827,s*.469,.397,.050,.055),(-.833,s*.469,.397,.055,.060),
             (-.852,s*.464,.398,.051,.057)),cast,piv,steps=30))
        cparts.append(make_tube("tmp_lower_oil_return",
            [(-.833,s*.476,.393),(-.836,s*.476,.355),(-.861,s*.456,.324),
             (-.955,s*.424,.309),(-1.017,s*.393,.349)],.010,brushed,piv,segments=14))
        # Cast outlet elbow and short black couplers are separate materials.
        cparts.append(make_tube("tmp_compressor_elbow",
            [(-.877,s*.458,.475),(-.861,s*.468,.526),(-.840,s*.467,.566),
             (-.809,s*.443,.607),(-.781,s*.418,.638)],.040,cast,piv,segments=22))
        cparts.append(make_tube("tmp_comp_to_icac",
            [(-.781,s*.418,.638),(-.768,s*.393,.661),(-.755,s*.369,.687),
             (-.742,s*.335,.702)],.036,rubber,piv,segments=20))
        cparts.append(make_cylinder("tmp_elbow_collar",(-.787,s*.422,.633),
            (-.778,s*.414,.642),.042,.042,brushed,piv,segments=28))
        # Intercooler-to-throttle-body silicone coupler
        cparts.append(make_cylinder(
            "tmp_icac_coupler", (-0.84, s * 0.236, 0.754), (-0.84, s * 0.295, 0.735),
            0.042, 0.042, rubber, piv, segments=20,
        ))
        # Stainless hose clamps on intercooler-to-throttle silicone coupler
        for cy_c in (0.248, 0.282):
            cparts.append(_section_ring("tmp_hclamp", -0.84, s * cy_c, 0.745, 0.042, 0.0028, steel, piv, axis="y", width=0.007, steps=28))
        join_meshes(cparts, f"ZR1X_Eng_ChargePipe_{tag}", piv)


def _build_flywheel_and_beltdrive(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    steel = _m(mats, "Mat_Steel_Machined")
    gun = _m(mats, "Mat_Gear_Steel")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    rubber = _m(mats, "Mat_Rubber_Black")

    # 1) Flywheel & Starter Ring Gear (ZR1X_Eng_Flywheel, Autoweek rear!)
    fwparts: List[bpy.types.Object] = []
    fwparts.append(_ellipse_case(
        "tmp_fw_disc",
        ((-1.145, 0.0, 0.448, 0.140, 0.140), (-1.162, 0.0, 0.448, 0.165, 0.165), (-1.193, 0.0, 0.448, 0.162, 0.162)),
        gun, piv, steps=44,
    ))
    fwparts.append(_ellipse_case(
        "tmp_fw_face",
        ((-1.193, 0.0, 0.448, 0.150, 0.150), (-1.198, 0.0, 0.448, 0.148, 0.148)),
        brushed, piv, steps=44,
    ))
    fwparts.append(_ellipse_case(
        "tmp_fw_recess",
        ((-1.1982, 0.0, 0.448, 0.086, 0.086), (-1.1992, 0.0, 0.448, 0.086, 0.086)),
        dark, piv, steps=36,
    ))
    # The rear photograph shows a machined, perforated annulus over a dark
    # recess. Build each sector around its bore so the holes have depth.
    vertices, faces = [], []
    half_sector = math.pi / 8
    for sector in range(8):
        direction = 2 * math.pi * sector / 8
        cd, sd = math.cos(direction), math.sin(direction)
        # Start on the outer edge. Each sector meets its neighbors at the
        # same radial boundary, including the two circular pilot-hole ends.
        perimeter = [(r * math.cos(a),r * math.sin(a))
            for r, angles in ((.093, np.linspace(-half_sector,half_sector,7)),
                              (.025, np.linspace(half_sector,-half_sector,7)))
            for a in angles]
        bore = []
        for radial, lateral in perimeter:
            alpha = math.atan2(lateral, radial-.060)
            bore.append((.060+.0155*math.cos(alpha),.0155*math.sin(alpha)))
        base=len(vertices)
        for xx,loop in ((-1.205,perimeter),(-1.205,bore),(-1.200,bore),(-1.200,perimeter)):
            vertices.extend((xx,radial*cd-lateral*sd,.448+radial*sd+lateral*cd) for radial,lateral in loop)
        count=len(perimeter)
        for band in range(4):
            for j in range(count):
                k=(j+1)%count
                near=base+band*count
                far=base+((band+1)%4)*count
                faces.append((near+j,near+k,far+k,far+j))
    fwparts.append(make_mesh("tmp_flywheel_perforated_hub",vertices,faces,brushed,piv,smooth=False))
    for radius in (.102, .138):
        fwparts.append(_section_ring("tmp_flywheel_face_ring",-1.201,0,.448,radius,.0016,steel,piv,width=.003))
    # Machined starter ring. The tooth count is illustrative.
    outline = []
    n_teeth = 96
    for tooth in range(n_teeth):
        for ph, rr in ((0.0, 0.158), (0.22, 0.164), (0.64, 0.164), (0.86, 0.158)):
            t = 2.0 * math.pi * (tooth + ph) / n_teeth
            outline.append((rr * math.cos(t), 0.448 + rr * math.sin(t)))
    tv, tf = [], []
    n_o = len(outline)
    for ax_x, is_in in ((-1.179, False), (-1.194, False), (-1.194, True), (-1.179, True)):
        for yy, zz in outline:
            if is_in:
                ratio = 0.149 / math.hypot(yy, zz - 0.448)
                yy *= ratio
                zz = 0.448 + (zz - 0.448) * ratio
            tv.append((ax_x, yy, zz))
    for i in range(4):
        ni = (i + 1) % 4
        for j in range(n_o):
            nj = (j + 1) % n_o
            tf.append((i * n_o + j, i * n_o + nj, ni * n_o + nj, ni * n_o + j))
    fwparts.append(make_mesh("tmp_ring_gear", tv, tf, steel, piv, smooth=False, recalc_normals=True))
    join_meshes(fwparts, "ZR1X_Eng_Flywheel", piv)

    # 2) Front Accessory Belt Drive, Alternator & A/C Compressor (ZR1X_Eng_BeltDrive, Autoweek 3/4!)
    # Kept strictly at X <= -0.472 so zero clash with cabin bulkhead
    bdparts: List[bpy.types.Object] = []
    # Pulley centers follow the straight-on Chevrolet studio image. The paired
    # idlers sit between the upper silver pump and the lower accessory drive.
    pulleys = (
        (0.000, 0.434, 0.072, brushed),
        (-0.158, 0.491, 0.049, cast),
        (0.169, 0.410, 0.052, gun),
        (-0.031, 0.614, 0.032, dark),
        (0.077, 0.620, 0.031, dark),
        (0.001, 0.737, 0.048, steel),
    )
    for yy, zz, radius, face_material in pulleys:
        bdparts.append(_ellipse_case("tmp_accessory_sheave",
            ((-0.516, yy, zz, radius, radius), (-0.488, yy, zz, radius, radius),
             (-0.475, yy, zz, radius * 0.91, radius * 0.91)), gun, piv, steps=40))
        bdparts.append(_ellipse_case("tmp_sheave_face",
            ((-0.477, yy, zz, radius * 0.85, radius * 0.85),
             (-0.472, yy, zz, radius * 0.79, radius * 0.79)), face_material, piv, steps=36))
        for dx in (-0.510, -0.503, -0.496, -0.489):
            bdparts.append(_section_ring("tmp_belt_rib", dx, yy, zz, radius, .0009, rubber, piv, width=.002))
        bdparts.append(_section_ring("tmp_sheave_hub", -.472, yy, zz, radius * .42, .0022, brushed, piv))
        bdparts.append(_bolt_cluster("tmp_shaft_bolt", [(-.473, yy, zz)], .010, .0028, gun, piv, axis="x"))

    # Cast pump body and mounting ears around the high central pulley.
    bdparts.append(_ellipse_case("tmp_water_pump",
        ((-.586, 0., .728, .095, .090), (-.557, 0., .734, .091, .084),
         (-.518, 0., .738, .068, .066), (-.509, 0., .738, .056, .056)), cast, piv, steps=40))
    for side in (-1, 1):
        for height in (.665, .768):
            bdparts.append(make_cylinder("tmp_pump_ear", (-.552,side*.052,.727),
                (-.557,side*.102,height), .023,.014,cast,piv,segments=16))
            bdparts.append(_bolt_cluster("tmp_ear_fastener",[(-.54,side*.098,height)],
                .008,.004,steel,piv,axis="x"))
        # Diagonal casting webs behind the belt, visible in the three-quarter image.
        for y_start, z_start, y_end, z_end in ((.03,.695,.16,.544),(.048,.544,.18,.442),(.07,.637,.13,.528)):
            bdparts.append(make_tube("tmp_timing_web",
                [(-.529,side*y_start,z_start),(-.517,side*(y_start+y_end)/2,(z_start+z_end)/2),
                 (-.530,side*y_end,z_end)], .010,cast,piv,segments=8))
    # The front timing casting flares around the crank, compressor and idler
    # bosses. Keep a broad skirt behind the exposed belt path.
    timing_outline = [(-.225,.346),(-.210,.302),(-.120,.284),(.111,.291),
                      (.207,.319),(.234,.398),(.218,.499),(.173,.575),
                      (.111,.620),(.066,.592),(-.074,.568),(-.155,.531),(-.218,.462)]
    bdparts.append(make_loft("tmp_timing_skirt",
        [[(xx,yy*scale,zz) for yy,zz in timing_outline]
         for xx,scale in ((-.590,.99),(-.554,1.0),(-.520,.96))],cast,piv,smooth=False))
    for yy,zz in ((-.202,.353),(-.126,.312),(.050,.312),(.182,.348),(.211,.447),(.154,.535)):
        bdparts.append(make_cylinder("tmp_timing_boss",(-.539,yy,zz),(-.514,yy,zz),.014,.013,cast,piv,segments=14))
        bdparts.append(_bolt_cluster("tmp_timing_screw",[(-.513,yy,zz)],.007,.0025,steel,piv,axis="x"))
    # Stepped alternator casting and longitudinal air slots.
    bdparts.append(_ellipse_case("tmp_alternator_case",
        ((-.636,.205,.675,.053,.060),(-.604,.205,.675,.065,.070),(-.548,.203,.675,.066,.068),
         (-.526,.203,.675,.052,.053)),cast,piv,steps=32))
    for phase in np.linspace(0,2*math.pi,12,endpoint=False):
        yy=.203+.061*math.cos(phase)
        zz=.675+.064*math.sin(phase)
        bdparts.append(make_cylinder("tmp_alternator_flute",(-.594,yy,zz),(-.554,yy,zz),
            .004,.004,gun,piv,segments=8))
    bdparts.append(make_cylinder("tmp_compressor_casting",(-.515,-.158,.491),(-.646,-.158,.491),
        .061,.070,cast,piv,segments=30))
    bdparts.append(make_cylinder("tmp_lower_case",(-.515,.169,.410),(-.620,.174,.418),
        .061,.071,cast,piv,segments=30))

    # Wide flat EPDM belt. Tangential runs and rounded arcs keep the belt
    # visible edge-on, particularly between the lower damper and idler.
    belt_plane=-.500
    path=[]
    for yy,zz,r,start,stop in ((-.158,.491,.053,132,263),(0.,.434,.076,263,277),
                                (.169,.410,.056,263,367),(.077,.620,.034,8,133),
                                (-.031,.614,.034,49,136)):
        for ang in np.linspace(math.radians(start),math.radians(stop),12):
            path.append((yy+r*math.cos(ang),zz+r*math.sin(ang)))
    belt_sections=[]
    for i,(yy,zz) in enumerate(path):
        prev=np.array(path[i-1]); nxt=np.array(path[(i+1)%len(path)])
        tangent=nxt-prev
        norm=np.array([tangent[1],-tangent[0]])/np.linalg.norm(tangent)
        belt_sections.append([(belt_plane+dx,yy+norm[0]*dr,zz+norm[1]*dr)
            for dx,dr in ((-.011,0),(.011,0),(.011,.004),(-.011,.004))])
    bdparts.append(make_loft("tmp_serpentine_belt",belt_sections+[belt_sections[0]],rubber,piv,cap_ends=False))
    join_meshes(bdparts, "ZR1X_Eng_BeltDrive", piv)


def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Populate ``Pivot_LT7_Engine`` with photo-matched LT7 twin-turbo V8 meshes."""
    piv = pivots["Pivot_LT7_Engine"]
    _build_crankcase_and_sump(piv, mats)
    _build_banks_covers_coils(piv, mats)
    _build_intake_and_fuel(piv, mats)
    _build_maniturbos_and_chargepipes(piv, mats)
    _build_flywheel_and_beltdrive(piv, mats)
