"""Authoritative PBR material library for the 2027 Chevrolet Corvette ZR1X (v2).

Exports ``create_materials() -> dict[str, bpy.types.Material]`` providing every
``Mat_*`` material specified in ``v2_rig_spec.md`` Section 4 plus clean
automotive helper materials. All image textures (2x2 carbon twill, dark SiC
carbon-ceramic rotor grain, perforated Napa leather, and high-res 2027 3-screen
cockpit displays) are procedurally generated and packed into ``bpy.data.images``
so both Blender (Cycles/EEVEE) and Draco glTF 2.0 export cleanly with zero
external texture files and zero baked visual-hull vertex colors.
"""

from __future__ import annotations

import math
import subprocess
import sys
from pathlib import Path
from typing import Dict

import numpy as np

try:
    import bpy
except ImportError:  # Allows running ``python3 materials.py --render-screens`` outside Blender
    bpy = None  # type: ignore[assignment]

TEX_DIR = Path(__file__).resolve().parent / "textures"


# ---------------------------------------------------------------------------
# Color & Image Packing Helpers
# ---------------------------------------------------------------------------

def _srgb_channel_to_linear(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def hex_to_linear(hex_str: str) -> tuple[float, float, float]:
    h = hex_str.lstrip("#")
    return tuple(_srgb_channel_to_linear(int(h[i : i + 2], 16) / 255.0) for i in (0, 2, 4))


def _pack_rgba_array(
    name: str,
    rgba_u8: np.ndarray,
    colorspace: str = "sRGB",
    flip_y: bool = False,
) -> bpy.types.Image:
    """Create and pack a Blender Image from an (H, W, 4) uint8 array."""
    if name in bpy.data.images:
        bpy.data.images.remove(bpy.data.images[name])
    arr = rgba_u8[::-1, :, :] if flip_y else rgba_u8
    h, w = arr.shape[:2]
    img = bpy.data.images.new(name=name, width=w, height=h, alpha=True)
    img.pixels.foreach_set((arr.astype(np.float32) / 255.0).ravel())
    img.colorspace_settings.name = colorspace
    img.pack()
    return img


def _pack_pil_image(name: str, pil_img: Image.Image, colorspace: str = "sRGB") -> bpy.types.Image:
    rgba = np.asarray(pil_img.convert("RGBA"), dtype=np.uint8)
    # PIL origin is top-left; Blender image origin is bottom-left.
    return _pack_rgba_array(name, rgba, colorspace=colorspace, flip_y=True)


def _height_to_normal_u8(height: np.ndarray, strength: float = 2.0) -> np.ndarray:
    """Convert a periodic 2D height field [0..1] to an RGBA uint8 tangent normal map."""
    dx = (np.roll(height, -1, axis=1) - np.roll(height, 1, axis=1)) * 0.5 * strength
    dy = (np.roll(height, -1, axis=0) - np.roll(height, 1, axis=0)) * 0.5 * strength
    nx = -dx
    ny = -dy
    nz = np.ones_like(height)
    inv_len = 1.0 / np.sqrt(nx * nx + ny * ny + nz * nz)
    nx *= inv_len
    ny *= inv_len
    nz *= inv_len
    out = np.empty((*height.shape, 4), dtype=np.uint8)
    out[..., 0] = np.clip((nx * 0.5 + 0.5) * 255.0, 0, 255).astype(np.uint8)
    out[..., 1] = np.clip((ny * 0.5 + 0.5) * 255.0, 0, 255).astype(np.uint8)
    out[..., 2] = np.clip((nz * 0.5 + 0.5) * 255.0, 0, 255).astype(np.uint8)
    out[..., 3] = 255
    return out


# ---------------------------------------------------------------------------
# Procedural Packed Surface Textures (glTF 2.0 compatible)
# ---------------------------------------------------------------------------

def _build_carbon_twill_textures() -> tuple[bpy.types.Image, bpy.types.Image, bpy.types.Image]:
    """Generate 128x128 seamless 2x2 diagonal carbon-fiber twill textures."""
    size = 128
    cell = 16  # 8 cells per tile -> clean 2-period 2x2 diagonal twill
    yy, xx = np.mgrid[:size, :size]
    cx = xx // cell
    cy = yy // cell
    ux = (xx % cell) / float(cell)
    uy = (yy % cell) / float(cell)

    warp = ((cx + cy) % 4) < 2  # true = horizontal tow on top, false = vertical tow on top
    # Arch profile across each tow + longitudinal fiber filaments
    arch = np.where(warp, np.sin(uy * math.pi), np.sin(ux * math.pi))
    along = np.where(warp, 0.85 + 0.15 * np.sin(ux * math.pi), 0.85 + 0.15 * np.sin(uy * math.pi))
    filament = np.where(
        warp,
        np.cos(uy * 10.0 * math.pi),
        np.cos(ux * 10.0 * math.pi),
    )

    # Deep authentic 2x2 diagonal carbon twill (sRGB ~0.06..0.19 -> linear ~0.005..0.032; never silvery!)
    tow_bias = np.where(warp, 0.038, -0.020)
    gloss_luma = np.clip(0.088 + 0.062 * arch * along + 0.015 * filament + tow_bias, 0.045, 0.195)
    matte_luma = np.clip(0.075 + 0.045 * arch * along + 0.010 * filament + tow_bias * 0.7, 0.040, 0.165)

    rgba_gloss = np.empty((size, size, 4), dtype=np.uint8)
    rgba_gloss[..., 0] = np.clip(gloss_luma * 255.0, 0, 255).astype(np.uint8)
    rgba_gloss[..., 1] = np.clip(gloss_luma * 1.01 * 255.0, 0, 255).astype(np.uint8)
    rgba_gloss[..., 2] = np.clip(gloss_luma * 1.04 * 255.0, 0, 255).astype(np.uint8)
    rgba_gloss[..., 3] = 255

    rgba_matte = np.empty((size, size, 4), dtype=np.uint8)
    rgba_matte[..., 0] = np.clip(matte_luma * 255.0, 0, 255).astype(np.uint8)
    rgba_matte[..., 1] = np.clip(matte_luma * 1.01 * 255.0, 0, 255).astype(np.uint8)
    rgba_matte[..., 2] = np.clip(matte_luma * 1.03 * 255.0, 0, 255).astype(np.uint8)
    rgba_matte[..., 3] = 255

    height = 0.70 * arch * along + 0.12 * filament + np.where(warp, 0.08, 0.0)
    normal_u8 = _height_to_normal_u8(height, strength=1.35)

    img_gloss = _pack_rgba_array("Tex_Carbon_Twill_2x2", rgba_gloss, "sRGB")
    img_matte = _pack_rgba_array("Tex_Carbon_Matte", rgba_matte, "sRGB")
    img_norm = _pack_rgba_array("Tex_Carbon_Twill_Normal", normal_u8, "Non-Color")
    return img_gloss, img_matte, img_norm


def _build_ccb_rotor_textures() -> tuple[bpy.types.Image, bpy.types.Image]:
    """Generate dark woven SiC carbon-ceramic brake rotor albedo & normal maps."""
    size = 128
    rng = np.random.default_rng(202701)
    yy, xx = np.mgrid[:size, :size]

    # Periodic multi-scale carbon-fiber cluster mottle typical of Brembo/Alcon SiC CCB discs
    base = np.zeros((size, size), dtype=np.float32)
    for freq, amp in ((2, 0.16), (4, 0.20), (8, 0.24), (16, 0.22), (32, 0.18)):
        phase_x = rng.uniform(0, 2 * math.pi)
        phase_y = rng.uniform(0, 2 * math.pi)
        angle = rng.uniform(0, math.pi)
        u = (xx * math.cos(angle) + yy * math.sin(angle)) * (2 * math.pi * freq / size)
        v = (-xx * math.sin(angle) + yy * math.cos(angle)) * (2 * math.pi * freq / size)
        base += amp * (0.5 + 0.5 * np.sin(u + phase_x) * np.cos(v + phase_y))

    # Fine isotropic carbon crystal sparkle + subtle machined sweep
    speckle = rng.normal(0.0, 0.045, size=(size, size)).astype(np.float32)
    sweep = 0.03 * np.sin(yy * (2 * math.pi * 12 / size))
    # Dark charcoal-graphite ceramic tone (sRGB ~0.18..0.32 -> realistic dark CCB, never bright grey!)
    val = np.clip(0.18 + 0.11 * base + speckle + sweep, 0.11, 0.36)

    rgba = np.empty((size, size, 4), dtype=np.uint8)
    rgba[..., 0] = np.clip(val * 0.99 * 255.0, 0, 255).astype(np.uint8)
    rgba[..., 1] = np.clip(val * 1.00 * 255.0, 0, 255).astype(np.uint8)
    rgba[..., 2] = np.clip(val * 1.04 * 255.0, 0, 255).astype(np.uint8)
    rgba[..., 3] = 255

    normal_u8 = _height_to_normal_u8(base * 0.6 + speckle * 2.5, strength=0.9)
    return (
        _pack_rgba_array("Tex_CCB_Rotor_J59", rgba, "sRGB"),
        _pack_rgba_array("Tex_CCB_Rotor_Normal", normal_u8, "Non-Color"),
    )


def _build_leather_textures() -> tuple[bpy.types.Image, bpy.types.Image]:
    """Generate subtle Napa leather micro-grain normal and perforated GT2 insert albedo."""
    size = 128
    rng = np.random.default_rng(202702)
    yy, xx = np.mgrid[:size, :size]

    # Fine organic pebble grain height for Napa leather
    grain = np.zeros((size, size), dtype=np.float32)
    for freq, amp in ((10, 0.30), (18, 0.35), (28, 0.35)):
        px, py = rng.uniform(0, 2 * math.pi, 2)
        grain += amp * np.sin(xx * 2 * math.pi * freq / size + px) * np.sin(yy * 2 * math.pi * freq / size + py)
    grain += rng.normal(0.0, 0.12, size=(size, size))
    leather_norm = _pack_rgba_array("Tex_Leather_Grain_Normal", _height_to_normal_u8(grain, strength=0.45), "Non-Color")

    # Perforated Jet Black GT2 seat insert (staggered pinholes)
    p = 64
    r, c = np.mgrid[:p, :p]
    dist = np.minimum.reduce([
        np.hypot((c - dx + p // 2) % p - p // 2, (r - dy + p // 2) % p - p // 2)
        for dx, dy in ((16, 16), (48, 48))
    ])
    hole = np.clip(1.0 - (dist - 3.2) / 1.8, 0.0, 1.0)
    tone = np.clip(0.145 + 0.012 * np.sin(c * 0.9) * np.sin(r * 1.1) - 0.105 * hole, 0.025, 0.22)
    rgba = np.empty((p, p, 4), dtype=np.uint8)
    rgba[..., 0] = np.clip(tone * 255.0, 0, 255).astype(np.uint8)
    rgba[..., 1] = np.clip(tone * 1.00 * 255.0, 0, 255).astype(np.uint8)
    rgba[..., 2] = np.clip(tone * 1.04 * 255.0, 0, 255).astype(np.uint8)
    rgba[..., 3] = 255
    perf_albedo = _pack_rgba_array("Tex_Leather_Perf_HTE", rgba, "sRGB")
    return leather_norm, perf_albedo


# ---------------------------------------------------------------------------
# High-Resolution 2027 3-Screen Cockpit Display Artwork (PIL via system python3)
# ---------------------------------------------------------------------------

def _font(size: int, bold: bool = False):
    from PIL import ImageFont
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _screen_bg(w: int, h: int, accent_blue: bool = True):
    """Render the deep midnight blue-black gradient used by the 2027 ZR1X displays."""
    from PIL import Image
    yy = np.linspace(0.0, 1.0, h, dtype=np.float32)[:, None]
    xx = np.linspace(0.0, 1.0, w, dtype=np.float32)[None, :]
    glow = np.exp(-((yy - 0.78) / 0.26) ** 2) * (0.65 + 0.35 * np.exp(-((xx - 0.5) / 0.45) ** 2))
    r = np.clip(5.0 + glow * (14.0 if accent_blue else 10.0), 0, 255)
    g = np.clip(8.0 + glow * (30.0 if accent_blue else 18.0), 0, 255)
    b = np.clip(13.0 + glow * (54.0 if accent_blue else 30.0), 0, 255)
    rgb = np.stack([r, g, b], axis=-1).astype(np.uint8)
    return Image.fromarray(rgb, mode="RGB")


def _render_screen_aux_pil():
    """6.6-inch left auxiliary display: Hybrid Battery / e-AWD telemetry (2027 HTE)."""
    from PIL import ImageDraw
    w, h = 640, 400
    im = _screen_bg(w, h)
    d = ImageDraw.Draw(im)

    white = "#f0f4f8"
    pale = "#b8cce0"
    muted = "#6e88a2"
    cyan = "#68b8f0"
    orange = "#eb6e24"

    # Title
    d.text((140, 34), "Hybrid Battery", font=_font(36, bold=True), fill=white)

    # State of charge row
    d.rounded_rectangle((175, 118, 224, 144), radius=4, outline=pale, width=3)
    d.rectangle((224, 125, 230, 137), fill=pale)
    d.text((246, 108), "85 %", font=_font(38, bold=True), fill=white)

    # Segmented SOC bar (18 slanted ticks: 2 orange reserve + 12 cyan/white active + 4 dim)
    bar_y = 172
    for j in range(18):
        x0 = 76 + j * 27
        if j < 2:
            col = orange
        elif j < 14:
            col = cyan if j >= 10 else "#dcecf8"
        else:
            col = "#1f374d"
        d.polygon([(x0, bar_y + 12), (x0 + 20, bar_y + 12), (x0 + 25, bar_y), (x0 + 5, bar_y)], fill=col)

    # Battery temperature row
    d.text((244, 224), "90 °F", font=_font(36, bold=True), fill=white)
    bar_y2 = 282
    for j in range(18):
        x0 = 76 + j * 27
        col = "#dcecf8" if j < 11 else "#1f374d"
        d.polygon([(x0, bar_y2 + 12), (x0 + 20, bar_y2 + 12), (x0 + 25, bar_y2), (x0 + 5, bar_y2)], fill=col)

    # Bottom touch-bar tray matching 2027 HTE panorama
    d.line((20, 326, w - 20, 326), fill="#264058", width=2)
    d.line((55, 352, 88, 352), fill=pale, width=3)
    d.line((55, 362, 88, 362), fill=pale, width=3)
    d.line((55, 372, 88, 372), fill=pale, width=3)
    d.arc((172, 348, 214, 384), 180, 360, fill=pale, width=3)
    d.line((170, 368, 216, 368), fill=pale, width=3)
    d.polygon([(310, 344), (288, 378), (332, 378)], outline="#d83834", fill="#401214", width=3)
    d.rounded_rectangle((418, 352, 472, 374), radius=8, outline=pale, width=3)
    d.ellipse((538, 344, 578, 382), outline=muted, width=3)
    d.line((558, 363, 570, 352), fill=cyan, width=3)
    return im


def _render_screen_cluster_pil():
    """14-inch curved driver instrument cluster (2027 ZR1X HTE)."""
    from PIL import ImageDraw
    w, h = 1400, 480
    im = _screen_bg(w, h)
    d = ImageDraw.Draw(im)

    white = "#f4f7fb"
    pale = "#c4d6e8"
    muted = "#6f8ca6"
    red = "#d92428"
    cyan = "#49a8e8"

    d.text((130, 36), "72°F", font=_font(26), fill=pale)
    d.text((1200, 36), "SE", font=_font(24), fill=pale)

    # Sweeping 2027 Corvette ZR1X horizontal tachometer (1..9 x1000 RPM)
    for i in range(9):
        x = 170 + i * 86
        y_top = 128 - int(i * 4.2)
        y_bot = 178
        if i < 6:
            fill = (24 + i * 5, 42 + i * 7, 68 + i * 10)
            outline = "#3a6a98"
        elif i == 6:
            fill = (60, 48, 56)
            outline = "#b06848"
        else:
            fill = (135 + (i - 7) * 45, 22, 26)
            outline = red
        poly = [(x, y_bot), (x + 64, y_bot), (x + 88, y_top), (x + 24, y_top)]
        d.polygon(poly, fill=fill, outline=outline)
        d.text((x + 12, y_bot + 6), str(i + 1), font=_font(22, bold=True), fill=red if i >= 7 else pale)
    d.text((960, 152), "RPM\n/1000", font=_font(16), fill=muted)

    d.line((130, 214, 1270, 214), fill="#3b6b92", width=3)

    gauges = [
        (145, 248, "175°F", "OIL"),
        (305, 248, "140°F", "COOL"),
        (145, 336, "30 psi", "OIL P"),
        (305, 336, "165°F", "TRANS"),
    ]
    for gx, gy, val, lbl in gauges:
        d.text((gx, gy), val, font=_font(30, bold=True), fill=white)
        d.text((gx, gy + 36), lbl, font=_font(15), fill=muted)

    d.text((515, 260), "0", font=_font(82, bold=True), fill=white)
    d.text((576, 312), "MPH", font=_font(22), fill=pale)
    d.text((685, 238), "P", font=_font(104, bold=True), fill=white)

    d.text((845, 262), "0 psi", font=_font(28, bold=True), fill=pale)
    d.line((845, 302, 960, 302), fill="#294864", width=6)
    d.text((845, 322), "75 %", font=_font(28, bold=True), fill=white)
    d.rectangle((845, 360, 932, 370), fill=cyan)
    d.rectangle((932, 360, 960, 370), fill="#243a50")

    d.text((1084, 134), "Tires\nWarm", font=_font(20, bold=True), fill=pale)
    d.rounded_rectangle((1080, 248, 1142, 376), radius=18, outline=muted, width=3, fill="#111d2a")
    for tx, ty in ((1022, 256), (1158, 256), (1022, 338), (1158, 338)):
        d.text((tx, ty), "30", font=_font(24, bold=True), fill=pale)
    d.text((1232, 378), "160mi", font=_font(18), fill=pale)

    d.rectangle((1288, 256, 1300, 364), fill="#1b3044")
    d.rectangle((1288, 282, 1300, 364), fill=pale)
    d.line((200, 434, 1200, 434), fill="#1d4568", width=4)
    return im


def _render_screen_center_pil():
    """12.7-inch center Google Built-in touchscreen (2027 ZR1X HTE)."""
    from PIL import ImageDraw
    w, h = 1280, 620
    im = _screen_bg(w, h)
    d = ImageDraw.Draw(im)

    white = "#f2f5f9"
    pale = "#c4d6e6"
    muted = "#6c869f"
    cyan = "#4da8e8"

    d.rectangle((0, 0, 88, h), fill="#091018")
    d.line((88, 0, 88, h), fill="#22364a", width=2)
    for idx in range(5):
        cy = 72 + idx * 82
        d.rounded_rectangle((24, cy - 18, 64, cy + 18), radius=8, outline=pale if idx < 3 else muted, width=3)

    apps = [
        ("Vehicle Status", "#3c8ce0"),
        ("myChevrolet", "#d8a434"),
        ("Google\nAssistant", "#58b878"),
        ("Play Store", "#4ab4e8"),
        ("Camera", "#94b4d0"),
        ("Performance", "#e04838"),
        ("PDR", "#d85848"),
        ("Climate", "#52a8e8"),
        ("Settings", "#96aec4"),
        ("Wi-Fi Hotspot", "#64c2a8"),
    ]
    for i, (label, col) in enumerate(apps):
        col_i = i % 5
        row_i = i // 5
        cx = 205 + col_i * 224
        cy = 134 + row_i * 188
        if i % 5 == 0:
            d.arc((cx - 32, cy - 30, cx + 32, cy + 30), 150, 390, fill=col, width=5)
            d.line((cx, cy, cx + 18, cy - 16), fill=white, width=4)
        elif i % 5 == 1:
            d.polygon(
                [(cx - 34, cy - 10), (cx + 34, cy - 10), (cx + 24, cy + 12), (cx - 24, cy + 12)],
                outline=col,
                width=4,
            )
        elif i % 5 == 2:
            d.ellipse((cx - 26, cy - 22, cx - 2, cy + 2), fill=col)
            d.ellipse((cx + 4, cy - 14, cx + 22, cy + 4), fill=pale)
            d.ellipse((cx + 2, cy + 8, cx + 16, cy + 22), fill=cyan)
        elif i % 5 == 3:
            if row_i == 0:
                d.polygon([(cx - 18, cy - 24), (cx + 26, cy), (cx - 18, cy + 24)], outline=col, width=4)
            else:
                d.ellipse((cx - 24, cy - 24, cx + 24, cy + 24), outline=col, width=5)
                d.ellipse((cx - 9, cy - 9, cx + 9, cy + 9), outline=white, width=4)
        else:
            if row_i == 0:
                d.rounded_rectangle((cx - 28, cy - 18, cx + 28, cy + 18), radius=6, outline=col, width=4)
                d.ellipse((cx - 10, cy - 10, cx + 10, cy + 10), outline=white, width=3)
            else:
                for r_arc in (12, 22, 32):
                    d.arc((cx - r_arc, cy - r_arc + 10, cx + r_arc, cy + r_arc + 10), 220, 320, fill=col, width=4)
                d.ellipse((cx - 4, cy + 10, cx + 4, cy + 18), fill=white)

        for line_i, line in enumerate(label.split("\n")):
            tw = d.textlength(line, font=_font(24))
            d.text((cx - tw / 2, cy + 42 + line_i * 28), line, font=_font(24), fill=white)

    d.line((104, 512, w - 24, 512), fill="#294258", width=2)
    items = ["72°", "SEAT", "A/C", "AUTO", "SYNC", "MAX", "SEAT", "68°"]
    for idx, txt in enumerate(items):
        tx = 148 + idx * 144
        is_temp = "°" in txt
        fnt = _font(32, bold=True) if is_temp else _font(22, bold=(txt == "A/C"))
        col = white if is_temp or txt == "A/C" else pale
        d.text((tx, 540 if is_temp else 546), txt, font=fnt, fill=col)
    return im


def render_screen_pngs(force: bool = False) -> dict[str, Path]:
    """Generate the 3 crisp 2027 ZR1X cockpit screen PNGs in ``v2/textures/``."""
    TEX_DIR.mkdir(parents=True, exist_ok=True)
    paths = {
        "aux": TEX_DIR / "screen_aux.png",
        "cluster": TEX_DIR / "screen_cluster.png",
        "center": TEX_DIR / "screen_center.png",
    }
    if not force and all(p.exists() for p in paths.values()):
        return paths
    _render_screen_aux_pil().save(paths["aux"])
    _render_screen_cluster_pil().save(paths["cluster"])
    _render_screen_center_pil().save(paths["center"])
    return paths


def _load_or_build_screen_images() -> tuple[bpy.types.Image, bpy.types.Image, bpy.types.Image]:
    """Load the 3 high-res screen PNGs into Blender and pack them (rendering on demand)."""
    expected = {
        "aux": ("Tex_Screen_Aux", TEX_DIR / "screen_aux.png"),
        "cluster": ("Tex_Screen_Cluster", TEX_DIR / "screen_cluster.png"),
        "center": ("Tex_Screen_Center", TEX_DIR / "screen_center.png"),
    }
    if not all(p.exists() for _, p in expected.values()):
        try:
            render_screen_pngs(force=True)
        except ImportError:
            subprocess.run(["python3", str(Path(__file__).resolve()), "--render-screens"], check=True)

    loaded = []
    for key in ("aux", "cluster", "center"):
        img_name, path = expected[key]
        if img_name in bpy.data.images:
            bpy.data.images.remove(bpy.data.images[img_name])
        if path.exists():
            im = bpy.data.images.load(str(path))
            im.name = img_name
            im.colorspace_settings.name = "sRGB"
            im.pack()
            loaded.append(im)
        else:
            # Pure-numpy emergency fallback (never normally hit)
            h, w = 256, 512
            yy = np.linspace(0, 1, h, dtype=np.float32)[:, None]
            rgba = np.zeros((h, w, 4), dtype=np.uint8)
            rgba[..., 0] = (10 + 18 * yy).astype(np.uint8)
            rgba[..., 1] = (20 + 38 * yy).astype(np.uint8)
            rgba[..., 2] = (34 + 68 * yy).astype(np.uint8)
            rgba[..., 3] = 255
            loaded.append(_pack_rgba_array(img_name, rgba, "sRGB"))
    return loaded[0], loaded[1], loaded[2]


# ---------------------------------------------------------------------------
# Material Constructors
# ---------------------------------------------------------------------------

def _new_principled(
    name: str,
    hex_color: str,
    metallic: float = 0.0,
    roughness: float = 0.4,
    coat_weight: float = 0.0,
    coat_roughness: float = 0.06,
    alpha: float = 1.0,
    ior: float = 1.45,
    specular: float = 0.5,
    emission_hex: str | None = None,
    emission_strength: float = 0.0,
    backface_culling: bool = False,
) -> tuple[bpy.types.Material, bpy.types.ShaderNodeBsdfPrincipled]:
    if name in bpy.data.materials:
        bpy.data.materials.remove(bpy.data.materials[name])
    m = bpy.data.materials.new(name=name)
    if m.node_tree is None:
        m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes.get("Principled BSDF")
    if bsdf is None:
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")

    lin = hex_to_linear(hex_color)
    m.diffuse_color = (*lin, alpha)
    m.use_backface_culling = backface_culling

    bsdf.inputs["Base Color"].default_value = (*lin, 1.0)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["IOR"].default_value = ior
    bsdf.inputs["Specular IOR Level"].default_value = specular
    bsdf.inputs["Coat Weight"].default_value = coat_weight
    bsdf.inputs["Coat Roughness"].default_value = coat_roughness
    bsdf.inputs["Alpha"].default_value = alpha

    if alpha < 0.999:
        if hasattr(m, "surface_render_method"):
            m.surface_render_method = "BLENDED"
        if hasattr(m, "blend_method"):
            try:
                m.blend_method = "BLEND"
            except Exception:
                pass

    if emission_hex is not None and emission_strength > 0.0:
        elin = hex_to_linear(emission_hex)
        bsdf.inputs["Emission Color"].default_value = (*elin, 1.0)
        bsdf.inputs["Emission Strength"].default_value = emission_strength

    return m, bsdf


def _link_image_texture(
    mat: bpy.types.Material,
    bsdf: bpy.types.ShaderNodeBsdfPrincipled,
    image: bpy.types.Image,
    input_name: str = "Base Color",
    also_emission: bool = False,
    emission_strength: float = 0.85,
) -> bpy.types.ShaderNodeTexImage:
    nt = mat.node_tree
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = image
    tex.extension = "REPEAT"
    nt.links.new(tex.outputs["Color"], bsdf.inputs[input_name])
    if also_emission:
        nt.links.new(tex.outputs["Color"], bsdf.inputs["Emission Color"])
        bsdf.inputs["Emission Strength"].default_value = emission_strength
    return tex


def _link_normal_map(
    mat: bpy.types.Material,
    bsdf: bpy.types.ShaderNodeBsdfPrincipled,
    normal_image: bpy.types.Image,
    strength: float = 0.35,
) -> None:
    nt = mat.node_tree
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = normal_image
    tex.extension = "REPEAT"
    nmap = nt.nodes.new("ShaderNodeNormalMap")
    nmap.inputs["Strength"].default_value = strength
    nt.links.new(tex.outputs["Color"], nmap.inputs["Color"])
    nt.links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])


# ---------------------------------------------------------------------------
# Public Contract
# ---------------------------------------------------------------------------

REQUIRED_MATERIAL_NAMES = (
    "Mat_Torch_Red_GKZ",
    "Mat_Carbon_Twill_2x2",
    "Mat_Carbon_Matte",
    "Mat_Black_Trim_Satin",
    "Mat_Black_Trim_Gloss",
    "Mat_Aluminum_Cast",
    "Mat_Aluminum_Brushed",
    "Mat_Steel_Machined",
    "Mat_Gear_Steel",
    "Mat_Titanium_Exhaust",
    "Mat_Heat_Shield",
    "Mat_Rubber_Tire",
    "Mat_Glass_Windshield",
    "Mat_Glass_Door",
    "Mat_Glass_Quarter",
    "Mat_Glass_Hatch",
    "Mat_Glass_Bulkhead",
    "Mat_Headlight_Clear_Lens",
    "Mat_Taillight_Red_Lens",
    "Mat_Taillight_White_LED",
    "Mat_Amber_Reflector",
    "Mat_Cabin_Rearview",
    "Mat_Wheel_CarbonFlash_SOJ",
    "Mat_CCB_Rotor_J59",
    "Mat_Caliper_Alcon_Black",
    "Mat_LT7_Plenum_Blue",
    "Mat_HV_Orange",
    "Mat_Leather_JetBlack_HTE",
    "Mat_Alcantara_Black",
    "Mat_Carpet_Black",
    "Mat_Stitch_Red",
    "Mat_Screen_Aux",
    "Mat_Screen_Cluster",
    "Mat_Screen_Center",
    "Mat_Plate_Silver",
    "Mat_Badge_DarkChrome",
)


def create_materials() -> Dict[str, bpy.types.Material]:
    """Create and return the full PBR material dictionary for ZR1X v2."""
    mats: Dict[str, bpy.types.Material] = {}

    # Generate packed textures once
    img_carbon_gloss, img_carbon_matte, img_carbon_norm = _build_carbon_twill_textures()
    img_ccb_albedo, img_ccb_norm = _build_ccb_rotor_textures()
    img_leather_norm, img_leather_perf = _build_leather_textures()
    img_screen_aux, img_screen_cluster, img_screen_center = _load_or_build_screen_images()

    # 1. Exterior Paint & Carbon (verified sRGB-to-linear deep vivid Torch Red & dark glossy 2x2 carbon)
    m, bsdf = _new_principled(
        "Mat_Torch_Red_GKZ",
        "b8060b",
        metallic=0.02,
        roughness=0.14,
        coat_weight=1.0,
        coat_roughness=0.035,
        specular=0.35,
    )
    # Explicit deep Torch Red linear RGB (0.47, 0.002, 0.003) — zero salmon/pink washout under AgX/ACES
    bsdf.inputs["Base Color"].default_value = (0.470, 0.0022, 0.0032, 1.0)
    m.diffuse_color = (0.470, 0.0022, 0.0032, 1.0)
    mats[m.name] = m

    m, bsdf = _new_principled(
        "Mat_Carbon_Twill_2x2",
        "121316",
        metallic=0.04,
        roughness=0.22,
        coat_weight=0.90,
        coat_roughness=0.06,
        specular=0.38,
    )
    _link_image_texture(m, bsdf, img_carbon_gloss, "Base Color")
    _link_normal_map(m, bsdf, img_carbon_norm, strength=0.30)
    mats[m.name] = m

    m, bsdf = _new_principled(
        "Mat_Carbon_Matte",
        "101114",
        metallic=0.03,
        roughness=0.48,
        coat_weight=0.08,
        coat_roughness=0.28,
        specular=0.28,
    )
    _link_image_texture(m, bsdf, img_carbon_matte, "Base Color")
    _link_normal_map(m, bsdf, img_carbon_norm, strength=0.22)
    mats[m.name] = m

    # 2. Trim & Metals
    m, _ = _new_principled("Mat_Black_Trim_Satin", "141619", metallic=0.06, roughness=0.42)
    mats[m.name] = m

    m, _ = _new_principled(
        "Mat_Black_Trim_Gloss",
        "0d0f12",
        metallic=0.14,
        roughness=0.14,
        coat_weight=0.68,
        coat_roughness=0.06,
    )
    mats[m.name] = m

    m, _ = _new_principled("Mat_Aluminum_Cast", "9ca2aa", metallic=0.84, roughness=0.36)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Aluminum_Brushed", "c0c6ce", metallic=0.88, roughness=0.24)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Steel_Machined", "d0d6dc", metallic=0.94, roughness=0.18)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Gear_Steel", "7b828b", metallic=0.92, roughness=0.22)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Titanium_Exhaust", "9f968b", metallic=0.90, roughness=0.26)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Heat_Shield", "c5c1b6", metallic=0.86, roughness=0.34)
    mats[m.name] = m

    # 3. Tires, Wheels & J59 Alcon Brakes
    m, _ = _new_principled("Mat_Rubber_Tire", "121316", metallic=0.0, roughness=0.78, specular=0.22)
    mats[m.name] = m

    m, _ = _new_principled(
        "Mat_Wheel_CarbonFlash_SOJ",
        "14161a",
        metallic=0.62,
        roughness=0.22,
        coat_weight=0.72,
        coat_roughness=0.08,
    )
    mats[m.name] = m

    m, bsdf = _new_principled(
        "Mat_CCB_Rotor_J59",
        "2b2d32",
        metallic=0.34,
        roughness=0.42,
        specular=0.45,
    )
    _link_image_texture(m, bsdf, img_ccb_albedo, "Base Color")
    _link_normal_map(m, bsdf, img_ccb_norm, strength=0.30)
    mats[m.name] = m

    m, _ = _new_principled(
        "Mat_Caliper_Alcon_Black",
        "1b1d22",
        metallic=0.44,
        roughness=0.28,
        coat_weight=0.36,
        coat_roughness=0.14,
    )
    mats[m.name] = m

    # 4. Powertrain Signature Accents
    m, _ = _new_principled(
        "Mat_LT7_Plenum_Blue",
        "164ca6",
        metallic=0.48,
        roughness=0.24,
        coat_weight=0.68,
        coat_roughness=0.10,
    )
    mats[m.name] = m

    m, _ = _new_principled(
        "Mat_HV_Orange",
        "ec5b0a",
        metallic=0.02,
        roughness=0.34,
        coat_weight=0.18,
    )
    mats[m.name] = m

    # 5. Glazing & Optics (hooked to GT3 Fresnel glazing & planar mirror shaders in Three.js)
    for gname, ghex, galpha, gcoat in (
        ("Mat_Glass_Windshield", "0b1116", 0.34, 0.90),
        ("Mat_Glass_Door", "0d141a", 0.32, 0.90),
        ("Mat_Glass_Quarter", "0a1015", 0.38, 0.90),
        ("Mat_Glass_Hatch", "0e161d", 0.22, 0.92),
        ("Mat_Glass_Bulkhead", "10181f", 0.24, 0.78),
    ):
        m, _ = _new_principled(
            gname,
            ghex,
            metallic=0.0,
            roughness=0.04,
            coat_weight=gcoat,
            coat_roughness=0.02,
            alpha=galpha,
            ior=1.52,
        )
        mats[m.name] = m

    m, _ = _new_principled(
        "Mat_Headlight_Clear_Lens",
        "e6f0f8",
        metallic=0.0,
        roughness=0.02,
        coat_weight=1.0,
        coat_roughness=0.02,
        alpha=0.12,
        ior=1.52,
    )
    mats[m.name] = m

    m, _ = _new_principled(
        "Mat_Taillight_Red_Lens",
        "c40812",
        metallic=0.04,
        roughness=0.08,
        coat_weight=0.92,
        coat_roughness=0.03,
        emission_hex="df0d16",
        emission_strength=1.4,
    )
    mats[m.name] = m

    m, _ = _new_principled(
        "Mat_Taillight_White_LED",
        "f4f8ff",
        metallic=0.0,
        roughness=0.10,
        emission_hex="f0f6ff",
        emission_strength=2.8,
    )
    mats[m.name] = m

    m, _ = _new_principled(
        "Mat_Amber_Reflector",
        "eb6e05",
        metallic=0.05,
        roughness=0.12,
        coat_weight=0.80,
        coat_roughness=0.05,
        emission_hex="d95d04",
        emission_strength=0.35,
    )
    mats[m.name] = m

    m, _ = _new_principled(
        "Mat_Cabin_Rearview",
        "d8e0e8",
        metallic=0.96,
        roughness=0.03,
    )
    mats[m.name] = m

    # 6. 3LZ Jet Black (HTE) Cabin Materials & 3-Screen Displays
    m, bsdf = _new_principled(
        "Mat_Leather_JetBlack_HTE",
        "111215",
        metallic=0.0,
        roughness=0.48,
        specular=0.32,
    )
    _link_normal_map(m, bsdf, img_leather_norm, strength=0.20)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Alcantara_Black", "141518", metallic=0.0, roughness=0.88, specular=0.18)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Carpet_Black", "101114", metallic=0.0, roughness=0.95, specular=0.10)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Stitch_Red", "cc1620", metallic=0.0, roughness=0.56)
    mats[m.name] = m

    for sname, simg in (
        ("Mat_Screen_Aux", img_screen_aux),
        ("Mat_Screen_Cluster", img_screen_cluster),
        ("Mat_Screen_Center", img_screen_center),
    ):
        m, bsdf = _new_principled(
            sname,
            "0c121a",
            metallic=0.0,
            roughness=0.22,
            coat_weight=0.12,
            coat_roughness=0.14,
            specular=0.24,
        )
        _link_image_texture(m, bsdf, simg, "Base Color", also_emission=True, emission_strength=1.08)
        mats[m.name] = m

    # 7. Plate & Dark Stealth Chrome Badges
    m, _ = _new_principled("Mat_Plate_Silver", "d8dde3", metallic=0.72, roughness=0.24)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Badge_DarkChrome", "20232a", metallic=0.94, roughness=0.18)
    mats[m.name] = m

    # 8. Clean Automotive Helper Materials (optional extras for ext/mech/cabin modules)
    m, bsdf = _new_principled("Mat_Leather_Perf_HTE", "1d1f23", metallic=0.0, roughness=0.54, specular=0.30)
    _link_image_texture(m, bsdf, img_leather_perf, "Base Color")
    _link_normal_map(m, bsdf, img_leather_norm, strength=0.14)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Stitch_Gray", "6a6d74", metallic=0.0, roughness=0.72)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Switch_Black", "111316", metallic=0.06, roughness=0.34, coat_weight=0.25)
    mats[m.name] = m

    m, _ = _new_principled("Mat_White_Paint", "eef1f4", metallic=0.02, roughness=0.34)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Emblem_Red", "cc141c", metallic=0.10, roughness=0.22, coat_weight=0.60)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Copper_Busbar", "c96e3a", metallic=0.95, roughness=0.24)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Rubber_Black", "16171a", metallic=0.0, roughness=0.68, specular=0.25)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Black_Frit", "0b0c0e", metallic=0.04, roughness=0.16, coat_weight=0.55)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Chrome_Mirror", "dde3ea", metallic=0.98, roughness=0.02)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Spring_Red", "b8161e", metallic=0.25, roughness=0.30, coat_weight=0.45)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Dark_Mesh", "0e1013", metallic=0.35, roughness=0.52)
    mats[m.name] = m

    m, _ = _new_principled("Mat_Radiator_Core", "7d848d", metallic=0.80, roughness=0.40)
    mats[m.name] = m

    return mats


if __name__ == "__main__":
    if "--render-screens" in sys.argv:
        paths = render_screen_pngs(force=True)
        print("Rendered screen PNGs:", {k: str(v) for k, v in paths.items()})
    else:
        bpy.ops.wm.read_factory_settings(use_empty=True)
        result = create_materials()
        missing = [n for n in REQUIRED_MATERIAL_NAMES if n not in result]
        assert not missing, f"Missing required materials: {missing}"
        print(f"materials.py OK: created {len(result)} materials ({len(REQUIRED_MATERIAL_NAMES)} required).")
