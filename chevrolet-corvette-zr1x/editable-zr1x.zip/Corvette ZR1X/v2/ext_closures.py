"""Hinged & removable exterior closures for the 2027 Chevrolet Corvette ZR1X (v2).

Builds:
- ``Pivot_Door_L`` / ``Pivot_Door_R``: sculpted Class-A door shells (double-sided w/ inner
  hem), flush under-spear door handles, 3LZ Jet Black leather door cards w/ brushed switch
  pods, and aerodynamic Torch Red upper / Satin Black lower wing mirrors.
- ``Pivot_Front_Hood``: flow-through front hood with real sculptural recessed cutout,
  glossy 2x2 carbon extractor lip, twin Torch Red longitudinal hood dividers/vanes,
  and recessed 3-pocket dark mesh.
- ``Pivot_Rear_Hatch``: flush fastback rear engine hatch with real twin split-window
  openings, molded 2x2 carbon window surrounds + side extraction louvers, and flush
  stepped center spine with recessed louver slots.
- ``Pivot_Roof_Panel``: removable C2Z glossy carbon-fiber targa top with Torch Red
  painted cant rails and black Alcantara headliner + latch hardware.
- ``Pivot_Fuel_Flap``: separate front-hinged flush fuel filler door on L rear quarter.
"""

from __future__ import annotations

import math
from typing import Dict, List

import bmesh
import bpy
from mathutils import Euler, Matrix, Vector

from ext_body import (
    DOOR_FRONT_X,
    FUEL_CENTER_X,
    FUEL_CENTER_Z,
    FUEL_RADIUS_X,
    FUEL_RADIUS_Z,
    HATCH_FRONT_X,
    HATCH_REAR_X,
    HOOD_FRONT_X,
    HOOD_REAR_X,
    ROOF_FRONT_X,
    ROOF_REAR_X,
    bm_add_box,
    bm_add_closed_loft,
    bm_add_thick_grid,
    body_belt_z,
    body_center_z,
    body_sill_z,
    clamp,
    door_front_cut_x,
    door_rear_cut_x,
    ease,
    finalize_bmesh,
    flank_y,
    hatch_aperture_hw,
    hatch_surface_point,
    hood_aperture_hw,
    hood_aperture_point,
    mix,
    roof_surface_point,
)


# ---------------------------------------------------------------------------
# 1. Left & Right Hinged Doors + Door Cards + Handles + Wing Mirrors
# ---------------------------------------------------------------------------

def _build_doors_and_mirrors(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        piv = pivots[f"Pivot_Door_{sfx}"]

        # === A. ZR1X_Door_Shell_L / R (Class-A double-sided outer skin + beltline return) ===
        bm = bmesh.new()
        mat_list = [mats["Mat_Torch_Red_GKZ"], mats["Mat_Black_Trim_Satin"]]

        nu, nv = 24, 16
        gap_x = 0.0045
        door_grid: List[List[Vector]] = []
        for iv in range(nv):
            tv = iv / (nv - 1)
            row = []
            for iu in range(nu):
                tu = iu / (nu - 1)
                # Evaluate approximate Z first, then refine X boundaries along exact front/rear shutlines
                x_approx = mix(-0.42, 0.90, tu)
                z0 = body_sill_z(x_approx) + 0.038
                z1 = body_belt_z(x_approx) - 0.002
                z = mix(z0, z1, tv)
                x_rear = door_rear_cut_x(z) + gap_x
                x_front = door_front_cut_x(z) - gap_x
                x = mix(x_rear, x_front, tu)
                # Re-evaluate Z bounds at exact X for crisp sill & beltline alignment
                z0 = body_sill_z(x) + 0.038
                z1 = body_belt_z(x) - 0.002
                z = mix(z0, z1, tv)
                y = flank_y(x, z, include_intake_recess=False)
                row.append(Vector((x, side * y, z)))
            door_grid.append(row)

        bm_add_thick_grid(
            bm, door_grid, thickness=0.018, outer_mat=0, inner_mat=1, rim_mat=0,
            out_hint=Vector((0.0, side, 0.0)),
        )

        # Top window-sill beltline shelf & dark rubber glass-wipe weatherstrip
        belt_grid = []
        for iu in range(nu):
            tu = iu / (nu - 1)
            p_top = door_grid[-1][iu]
            belt_grid.append([
                p_top,
                Vector((p_top.x, p_top.y - side * 0.042, p_top.z + 0.004)),
                Vector((p_top.x, p_top.y - side * 0.088, p_top.z - 0.010)),
            ])
        bm_add_thick_grid(bm, belt_grid, thickness=0.008, outer_mat=1, inner_mat=1, rim_mat=1, out_hint=Vector((0, 0, 1)))

        finalize_bmesh(f"ZR1X_Door_Shell_{sfx}", bm, mat_list, piv, auto_smooth_deg=42.0, uv_scale=4.0)

        # === B. ZR1X_Door_Handle_L / R (Flush C8 handle recessed under door wishbone spear) ===
        bm_h = bmesh.new()
        x_h = -0.18
        z_h = 0.745
        y_h = flank_y(x_h, z_h, include_intake_recess=False) - 0.012
        bm_add_box(bm_h, (x_h, side * y_h, z_h), (0.145, 0.022, 0.026), mat_index=0, bevel=0.006)
        finalize_bmesh(f"ZR1X_Door_Handle_{sfx}", bm_h, [mats["Mat_Black_Trim_Gloss"]], piv, auto_smooth_deg=35.0)

        # === C. ZR1X_Door_Card_L / R (3LZ Jet Black Napa leather interior panel + brushed switch pod) ===
        bm_c = bmesh.new()
        # 0=Jet Black leather, 1=Satin black trim, 2=Brushed aluminum switch pod, 3=Dark speaker mesh, 4=Red stitch
        mat_c = [
            mats["Mat_Leather_JetBlack_HTE"],
            mats["Mat_Black_Trim_Satin"],
            mats["Mat_Aluminum_Brushed"],
            mats["Mat_Dark_Mesh"],
            mats["Mat_Stitch_Red"],
        ]
        card_grid = []
        for iv in range(10):
            tv = iv / 9.0
            row = []
            for iu in range(12):
                tu = iu / 11.0
                z_est = mix(0.24, 0.84, tv)
                x = mix(door_rear_cut_x(z_est) + 0.045, door_front_cut_x(z_est) - 0.045, tu)
                z = mix(body_sill_z(x) + 0.115, body_belt_z(x) - 0.020, tv)
                y_out = flank_y(x, z, include_intake_recess=False)
                # Sculpted inner bolster thickness with angled armrest shelf around tv=0.45
                arm_bulge = 0.038 * math.exp(-((tv - 0.48) / 0.16) ** 2) * ease(0.05, 0.25, tu) * ease(0.95, 0.72, tu)
                y_in = y_out - 0.088 - arm_bulge
                row.append(Vector((x, side * y_in, z)))
            card_grid.append(row)
        bm_add_thick_grid(bm_c, card_grid, thickness=0.018, outer_mat=0, inner_mat=1, rim_mat=1, out_hint=Vector((0, -side, 0)))

        # Angled armrest & brushed-aluminum window/mirror switch pod (fixing #10 baseline omission!)
        y_pod = flank_y(0.32, 0.56, include_intake_recess=False) - 0.118
        bm_add_box(bm_c, (0.34, side * y_pod, 0.565), (0.190, 0.048, 0.022), mat_index=2, bevel=0.005,
                   rot_mat=Euler((0.0, -0.18, 0.0), "XYZ").to_matrix().to_4x4())
        # Twin power-window rocker switches & mirror toggle button on switch pod
        for sx in (0.30, 0.35, 0.40):
            bm_add_box(bm_c, (sx, side * (y_pod - 0.004), 0.578), (0.022, 0.018, 0.010), mat_index=1, bevel=0.002)
        # Red contrast stitch accent blade along upper door shoulder
        bm_add_box(bm_c, (0.20, side * (y_pod + 0.012), 0.725), (0.76, 0.010, 0.008), mat_index=4, bevel=0.002)
        # Lower forward Bose Performance Series speaker grille
        y_spk = flank_y(0.62, 0.34, include_intake_recess=False) - 0.095
        bm_add_box(bm_c, (0.60, side * y_spk, 0.355), (0.210, 0.016, 0.145), mat_index=3, bevel=0.008)

        finalize_bmesh(f"ZR1X_Door_Card_{sfx}", bm_c, mat_c, piv, auto_smooth_deg=42.0, uv_scale=8.0)

        # === D. Aerodynamic Wing Mirrors (Torch Red Upper Cap + Satin/Gloss Black Stalk & Base + Glass) ===
        # Matches 052-mirror-close-up.jpg, 01-front-three-quarter.jpg, 029.png (W incl. mirrors = 2.144 m!)
        # 1) ZR1X_Mirror_Base_L / R (black corner sail + sleek aero stalk + lower housing + turn LED strip)
        bm_mb = bmesh.new()
        mat_mb = [mats["Mat_Black_Trim_Gloss"], mats["Mat_Black_Trim_Satin"], mats["Mat_Taillight_White_LED"]]

        # Door-corner triangular mirror mount sail right below A-pillar (X=0.66..0.81, Z=0.815..0.895)
        sail_sec = []
        for k in range(5):
            tk = k / 4.0
            x_s = mix(0.665, 0.805, tk)
            y_s = side * (flank_y(x_s, 0.835, include_intake_recess=False) - 0.015)
            h_s = mix(0.018, 0.068, 1.0 - abs(tk - 0.35) * 1.4)
            sail_sec.append([
                Vector((x_s, y_s - side * 0.025, 0.818)),
                Vector((x_s, y_s + side * 0.018, 0.818)),
                Vector((x_s, y_s + side * 0.010, 0.818 + max(0.016, h_s))),
                Vector((x_s, y_s - side * 0.025, 0.818 + max(0.016, h_s))),
            ])
        bm_add_closed_loft(bm_mb, sail_sec, mat_index=0, cap_start=True, cap_end=True)

        # Sleek slim swept aerodynamic mirror stalk (extending outboard Y=0.79 -> Y=0.98)
        stalk_sec = []
        for k in range(10):
            tk = k / 9.0
            cy = side * mix(0.795, 0.990, tk)
            cx = mix(0.708, 0.625, tk)
            cz = mix(0.842, 0.876, tk ** 1.15)
            chord = mix(0.095, 0.075, tk)
            thick = mix(0.016, 0.013, tk)
            stalk_sec.append([
                Vector((cx + chord * 0.55, cy, cz)),
                Vector((cx + chord * 0.15, cy, cz + thick * 0.55)),
                Vector((cx - chord * 0.45, cy, cz + thick * 0.35)),
                Vector((cx - chord * 0.45, cy, cz - thick * 0.35)),
                Vector((cx + chord * 0.15, cy, cz - thick * 0.55)),
            ])
        bm_add_closed_loft(bm_mb, stalk_sec, mat_index=1, cap_start=True, cap_end=True)

        # Sleek curved aerodynamic black lower mirror housing bowl (smooth teardrop C8 profile!)
        low_sec = []
        for k in range(14):
            tk = k / 13.0
            cy = side * mix(0.892, 1.072, tk)
            cx_f = mix(0.668, 0.598, tk ** 1.35) + 0.032 * math.sin(tk * math.pi)
            cx_b = mix(0.552, 0.515, tk ** 1.2)
            cz_b = mix(0.878, 0.902, tk ** 1.4) - 0.008 * math.sin(tk * math.pi)
            cz_t = mix(0.916, 0.930, tk)
            taper = math.sin(clamp(0.04 + 0.92 * tk, 0.03, 0.98) * math.pi) ** 0.48
            mid_x = 0.5 * (cx_f + cx_b)
            hx = 0.5 * (cx_f - cx_b) * taper
            low_sec.append([
                Vector((mid_x + hx, cy, mix(cz_b, cz_t, 0.58))),
                Vector((mid_x + hx * 0.40, cy, cz_t)),
                Vector((mid_x - hx, cy, cz_t)),
                Vector((mid_x - hx, cy, cz_b + 0.008)),
                Vector((mid_x + hx * 0.25, cy, cz_b)),
            ])
        bm_add_closed_loft(bm_mb, low_sec, mat_index=0, cap_start=True, cap_end=True)

        # Slim white LED side repeater strip on outer mirror lower corner
        bm_add_box(bm_mb, (0.608, side * 1.050, 0.912), (0.042, 0.018, 0.006), mat_index=2, bevel=0.002,
                   rot_mat=Euler((0.0, 0.0, side * -0.45), "XYZ").to_matrix().to_4x4())

        finalize_bmesh(f"ZR1X_Mirror_Base_{sfx}", bm_mb, mat_mb, piv, auto_smooth_deg=44.0)

        # 2) ZR1X_Mirror_Cap_L / R (Sleek smoothly-domed Torch Red aerodynamic C8 upper mirror cap!)
        bm_mc = bmesh.new()
        cap_sec = []
        for k in range(15):
            tk = k / 14.0
            cy = side * mix(0.888, 1.073, tk)
            cx_f = mix(0.674, 0.596, tk ** 1.30) + 0.036 * math.sin(tk * math.pi)
            cx_b = mix(0.548, 0.510, tk ** 1.15)
            cz_b = mix(0.912, 0.926, tk)
            h_dome = 0.064 * (math.sin(clamp(0.05 + 0.90 * tk, 0.04, 0.97) * math.pi) ** 0.45)
            cz_t = cz_b + max(0.012, h_dome)
            w_scale = math.sin(clamp(0.04 + 0.92 * tk, 0.03, 0.98) * math.pi) ** 0.42
            mx = 0.5 * (cx_f + cx_b)
            hx = 0.5 * (cx_f - cx_b) * w_scale
            cap_sec.append([
                Vector((mx + hx, cy, mix(cz_b, cz_t, 0.25))),
                Vector((mx + hx * 0.65, cy, mix(cz_b, cz_t, 0.78))),
                Vector((mx + hx * 0.10, cy, cz_t)),
                Vector((mx - hx * 0.55, cy, mix(cz_b, cz_t, 0.92))),
                Vector((mx - hx, cy, mix(cz_b, cz_t, 0.60))),
                Vector((mx - hx, cy, cz_b)),
                Vector((mx + hx * 0.40, cy, cz_b)),
            ])
        bm_add_closed_loft(bm_mc, cap_sec, mat_index=0, cap_start=True, cap_end=True)
        finalize_bmesh(f"ZR1X_Mirror_Cap_{sfx}", bm_mc, [mats["Mat_Torch_Red_GKZ"]], piv, auto_smooth_deg=48.0, uv_scale=6.0)

        # 3) ZR1X_Mirror_Glass_L / R (Recessed aft-facing reflective mirror plate)
        bm_mg = bmesh.new()
        mg_grid = []
        for iz in range(5):
            tz = iz / 4.0
            row = []
            for iy in range(7):
                ty = iy / 6.0
                cy = side * mix(0.910, 1.055, ty)
                cz = mix(0.892, 0.966, tz) + 0.008 * math.sin(ty * math.pi) * (tz - 0.5)
                cx = mix(0.548, 0.514, ty) - 0.003
                row.append(Vector((cx, cy, cz)))
            mg_grid.append(row)
        bm_add_thick_grid(bm_mg, mg_grid, thickness=0.005, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((-1, 0, 0)))
        finalize_bmesh(f"ZR1X_Mirror_Glass_{sfx}", bm_mg, [mats["Mat_Chrome_Mirror"]], piv, auto_smooth_deg=35.0)


# ---------------------------------------------------------------------------
# 2. Flow-Through Front Hood (Pivot_Front_Hood)
# ---------------------------------------------------------------------------

def _build_front_hood(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    piv = pivots["Pivot_Front_Hood"]

    # Cutout bounds in hood coordinates (exact match to 05-top-view.jpg & 022-hood-extractor.jpg):
    # Front bridge: X = 1.79 .. 1.964
    # Rear sloped duct ramp: X = 1.064 .. 1.38
    # Cutout hole: X = 1.38 .. 1.79, |Y| <= cut_hw(x)
    def cut_hw(x: float) -> float:
        t = clamp((x - 1.36) / (1.80 - 1.36), 0.0, 1.0)
        # Wide sculpted trapezoid curving inward slightly at front extractor lip
        return mix(0.455, 0.435, t ** 1.4) + 0.032 * math.sin(t * math.pi)

    def hood_pt(x: float, s: float) -> Vector:
        # Clean 4.5 mm shutline inset from fixed fender/nose aperture
        hw = hood_aperture_hw(x)
        s_in = s * (1.0 - 0.0045 / max(0.15, hw))
        p = hood_aperture_point(x, s_in)
        p.z -= 0.0015
        return p

    # === A. ZR1X_Front_Hood (4 seamlessly joined Class-A perimeter panels + deep 3-pocket mesh) ===
    bm = bmesh.new()
    # 0=Torch Red paint, 1=Satin Black underside/recess wall, 2=Dark honeycomb extractor mesh
    mat_list = [mats["Mat_Torch_Red_GKZ"], mats["Mat_Black_Trim_Satin"], mats["Mat_Dark_Mesh"]]

    # 1) Front hood bridge (ahead of extractor cutout: X = 1.795 .. 1.964)
    front_grid = []
    for ix in range(8):
        x = mix(1.795, HOOD_FRONT_X - 0.006, ix / 7.0)
        row = [hood_pt(x, mix(-1.0, 1.0, iy / 20.0)) for iy in range(21)]
        front_grid.append(row)
    bm_add_thick_grid(bm, front_grid, thickness=0.012, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 0, 1)))

    # 2) Rear hood deck + smooth downward flow-through scoop ramp (X = 1.065 .. 1.390)
    rear_grid = []
    for ix in range(11):
        t = ix / 10.0
        x = mix(HOOD_REAR_X + 0.005, 1.390, t)
        row = []
        for iy in range(21):
            s = mix(-1.0, 1.0, iy / 20.0)
            p = hood_pt(x, s)
            # Inside the flow-through channel width (|y| < cut_hw), sweep smoothly DOWN into the duct!
            y_norm = abs(p.y) / max(0.20, cut_hw(x))
            in_ch = ease(1.12, 0.85, y_norm)
            dip = 0.072 * (t ** 1.65) * in_ch
            p.z -= dip
            row.append(p)
        rear_grid.append(row)
    bm_add_thick_grid(bm, rear_grid, thickness=0.012, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 0, 1)))

    # 3) Left & Right painted outer hood shoulders flanking the flow-through cutout (X = 1.385 .. 1.800)
    for side in (-1.0, 1.0):
        wing_grid = []
        for ix in range(14):
            x = mix(1.385, 1.800, ix / 13.0)
            hw = hood_aperture_hw(x)
            s_inner = side * clamp(cut_hw(x) / max(0.20, hw), 0.25, 0.90)
            s_outer = side * 1.0
            row = []
            for ik in range(7):
                fk = ik / 6.0
                p = hood_pt(x, mix(s_inner, s_outer, fk))
                # Roll inner cutout lip cleanly down 14 mm into duct throat
                if ik == 0:
                    p.z -= 0.016
                elif ik == 1:
                    p.z -= 0.004
                row.append(p)
            wing_grid.append(row)
        bm_add_thick_grid(bm, wing_grid, thickness=0.011, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 0, 1)))

        # Deep Satin Black inner duct sidewall dropping down from outer cutout edge to mesh screen
        wall_grid = []
        for ix in range(12):
            x = mix(1.385, 1.800, ix / 11.0)
            hw = hood_aperture_hw(x)
            s_in = side * clamp(cut_hw(x) / max(0.20, hw), 0.25, 0.90)
            p_top = hood_pt(x, s_in)
            wall_grid.append([
                Vector((p_top.x, p_top.y, p_top.z - 0.012)),
                Vector((p_top.x, p_top.y - side * 0.024, p_top.z - 0.056)),
            ])
        bm_add_thick_grid(bm, wall_grid, thickness=0.006, outer_mat=1, inner_mat=1, rim_mat=1, out_hint=Vector((0, -side, 0.3)))

    # 4) Recessed dark honeycomb extractor mesh screen spanning the entire flow-through cutout
    mesh_grid = []
    for ix in range(10):
        t = ix / 9.0
        x = mix(1.380, 1.805, t)
        hw_c = cut_hw(x) + 0.015
        row = []
        for iy in range(17):
            s = mix(-1.0, 1.0, iy / 16.0)
            y = s * hw_c
            p_surf = hood_pt(x, clamp(y / max(0.20, hood_aperture_hw(x)), -0.95, 0.95))
            # Recessed cleanly 46..54 mm below top hood skin — zero red mesh clipping!
            z_m = p_surf.z - mix(0.046, 0.054, t)
            row.append(Vector((x, y, z_m)))
        mesh_grid.append(row)
    bm_add_thick_grid(bm, mesh_grid, thickness=0.005, outer_mat=2, inner_mat=1, rim_mat=1, out_hint=Vector((0, 0, 1)))

    # Add fine 3D cross-rib mesh grating bars directly above mesh screen for realistic texture depth!
    for ix in range(7):
        xm = mix(1.43, 1.77, ix / 6.0)
        hw_m = cut_hw(xm) - 0.01
        zm = hood_pt(xm, 0.0).z - mix(0.044, 0.052, ix / 6.0)
        bm_add_box(bm, (xm, 0.0, zm + 0.004), (0.006, hw_m * 2.0, 0.006), mat_index=1)

    finalize_bmesh("ZR1X_Front_Hood", bm, mat_list, piv, auto_smooth_deg=42.0, uv_scale=4.0)

    # === B. ZR1X_Hood_ExtractorLip (Exposed 2x2 glossy carbon front extractor gurney surround!) ===
    # Smoothly conforms flush into the hood cutout leading edge & rounded corners (zero protruding horns!)
    bm_lip = bmesh.new()
    lip_sec = []
    for iy in range(25):
        s = mix(-1.0, 1.0, iy / 24.0)
        a = abs(s)
        x_front = 1.805 - 0.055 * (a ** 2.1) - 0.105 * ease(0.84, 1.0, a)
        hw_c = cut_hw(clamp(x_front, 1.38, 1.80))
        y = s * (hw_c + 0.008)
        p_h = hood_pt(clamp(x_front, 1.38, 1.84), clamp(y / max(0.20, hood_aperture_hw(clamp(x_front, 1.38, 1.84))), -0.96, 0.96))
        z_h = p_h.z
        taper = 1.0 - 0.65 * ease(0.86, 1.0, a)
        lip_sec.append([
            Vector((x_front + 0.042 * taper, y, z_h + 0.001)),
            Vector((x_front + 0.004, y, z_h + 0.007 * taper)),
            Vector((x_front - 0.022, y, z_h + 0.004 * taper)),
            Vector((x_front - 0.028, y, z_h - 0.024)),
            Vector((x_front + 0.016, y, z_h - 0.018)),
        ])
    bm_add_closed_loft(bm_lip, lip_sec, mat_index=0, cap_start=True, cap_end=True)
    finalize_bmesh("ZR1X_Hood_ExtractorLip", bm_lip, [mats["Mat_Carbon_Twill_2x2"]], piv, auto_smooth_deg=36.0, uv_scale=7.0)

    # === C. ZR1X_Hood_Divider_L / R (Twin sculpted Torch Red hood vanes dividing 3 mesh pockets!) ===
    # Exact match to 022-hood-extractor-and-front-fascia.jpg and 05-top-view.jpg!
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm_v = bmesh.new()
        vane_sec = []
        for ix in range(12):
            tx = ix / 11.0
            x = mix(1.325, 1.815, tx)
            # Slightly converges forward from Y=0.235 at rear to Y=0.195 at front lip
            y = side * mix(0.238, 0.198, tx)
            p_top = hood_pt(x, clamp(y / max(0.20, hood_aperture_hw(x)), -0.9, 0.9))
            # Sculpted dorsal airfoil spine: merges smoothly into rear hood ramp, rises boldly across cutout,
            # plunges down cleanly behind the front carbon extractor lip!
            z_crest = p_top.z + 0.010 * math.sin(tx * math.pi) - 0.022 * ease(0.82, 1.0, tx)
            z_root = p_top.z - mix(0.016, 0.052, ease(0.08, 0.88, tx))
            w_top = mix(0.014, 0.020, math.sin(tx * math.pi))
            w_bot = mix(0.042, 0.032, tx)
            vane_sec.append([
                Vector((x, y - w_top * 0.5, z_crest)),
                Vector((x, y + w_top * 0.5, z_crest)),
                Vector((x, y + w_bot * 0.5, z_root)),
                Vector((x, y - w_bot * 0.5, z_root)),
            ])
        bm_add_closed_loft(bm_v, vane_sec, mat_index=0, cap_start=True, cap_end=True)
        finalize_bmesh(f"ZR1X_Hood_Divider_{sfx}", bm_v, [mats["Mat_Torch_Red_GKZ"]], piv, auto_smooth_deg=38.0, uv_scale=5.0)


# ---------------------------------------------------------------------------
# 3. Flush Fastback Split-Window Engine Hatch (Pivot_Rear_Hatch)
# ---------------------------------------------------------------------------

def _hatch_window_y_bounds(x: float) -> tuple[float, float]:
    """Return (y_inner, y_outer) of the left split-window glass opening at station X in [-1.54, -0.56]."""
    t = clamp((x - (-1.54)) / ((-0.56) - (-1.54)), 0.0, 1.0)  # 0=rear tip, 1=front edge
    y_in = mix(0.055, 0.145, t ** 0.85)
    y_out = mix(0.185, 0.455, t ** 0.72)
    return y_in, y_out


def _build_rear_hatch(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    piv = pivots["Pivot_Rear_Hatch"]

    def hatch_pt(x: float, s: float) -> Vector:
        hw = hatch_aperture_hw(x)
        s_in = s * (1.0 - 0.0045 / max(0.15, hw))
        p = hatch_surface_point(x, s_in)
        p.z -= 0.0012
        return p

    # === A. ZR1X_Rear_Hatch (Flush Torch Red perimeter deck + Carbon molded split-window frames!) ===
    bm = bmesh.new()
    # 0=Torch Red painted hatch deck, 1=Glossy 2x2 Carbon window frames, 2=Satin Black underside, 3=Dark mesh
    mat_list = [
        mats["Mat_Torch_Red_GKZ"],
        mats["Mat_Carbon_Twill_2x2"],
        mats["Mat_Black_Trim_Satin"],
        mats["Mat_Dark_Mesh"],
    ]

    # 1) Front header bar of hatch ahead of split windows (X = -0.575 .. -0.430)
    h_front = []
    for ix in range(6):
        x = mix(-0.575, HATCH_FRONT_X - 0.005, ix / 5.0)
        h_front.append([hatch_pt(x, mix(-1.0, 1.0, iy / 20.0)) for iy in range(21)])
    bm_add_thick_grid(bm, h_front, thickness=0.012, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0, 0, 1)))

    # 2) Rear V-deck behind split windows (X = -1.960 .. -1.525) — smooth flush deck carrying rear emblem!
    h_rear = []
    for ix in range(12):
        x = mix(HATCH_REAR_X + 0.005, -1.525, ix / 11.0)
        h_rear.append([hatch_pt(x, mix(-1.0, 1.0, iy / 20.0)) for iy in range(21)])
    bm_add_thick_grid(bm, h_rear, thickness=0.012, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0, 0, 1)))

    # 3) Left & Right Torch Red outer hatch rails flanking the carbon window frames (X = -1.54 .. -0.57)
    for side in (-1.0, 1.0):
        side_rail = []
        frame_outer = []
        for ix in range(18):
            x = mix(-1.54, -0.57, ix / 17.0)
            hw = hatch_aperture_hw(x)
            y_in, y_out = _hatch_window_y_bounds(x)
            y_cf_out = min(hw - 0.012, y_out + 0.072)  # Outer edge of molded carbon window surround
            # Torch Red outer hatch border (y_cf_out .. hw)
            row_red = []
            for k in range(5):
                y = side * mix(y_cf_out, hw, k / 4.0)
                row_red.append(hatch_pt(x, clamp(y / max(0.15, hw), -1.0, 1.0)))
            side_rail.append(row_red)

            # Molded 2x2 Carbon outer window frame with recessed side vent trough (y_out .. y_cf_out)
            row_cf = []
            for k in range(6):
                fk = k / 5.0
                y = side * mix(y_out, y_cf_out, fk)
                p = hatch_pt(x, clamp(y / max(0.15, hw), -1.0, 1.0))
                # Step down cleanly at inner window ledge for glass seating
                if k == 0:
                    p.z -= 0.008
                elif k in (2, 3):
                    p.z -= 0.005  # Subtle side-vent louver channel
                row_cf.append(p)
            frame_outer.append(row_cf)

        bm_add_thick_grid(bm, side_rail, thickness=0.011, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0, 0, 1)))
        bm_add_thick_grid(bm, frame_outer, thickness=0.012, outer_mat=1, inner_mat=2, rim_mat=1, out_hint=Vector((0, 0, 1)))

        # Carbon front & rear cross-headers of each split window frame (matches 037-rear-hatch-louvers.jpg!)
        for x_bar, dx_bar in ((-0.575, 0.055), (-1.530, 0.085)):
            y0, y1 = _hatch_window_y_bounds(x_bar)
            bar_grid = []
            for ix_b in range(4):
                xb = mix(x_bar - dx_bar * 0.5, x_bar + dx_bar * 0.5, ix_b / 3.0)
                hw = hatch_aperture_hw(xb)
                bar_grid.append([
                    hatch_pt(xb, clamp(side * mix(y0 - 0.015, y1 + 0.068, ky / 6.0) / hw, -1.0, 1.0)) + Vector((0, 0, 0.002))
                    for ky in range(7)
                ])
            bm_add_thick_grid(bm, bar_grid, thickness=0.010, outer_mat=1, inner_mat=2, rim_mat=1, out_hint=Vector((0, 0, 1)))

        # 3 crisp carbon side extraction louvers + dark hex mesh pockets recessed FLUSH inside carbon frame!
        for lv_i in range(3):
            x_lv = mix(-1.32, -0.78, lv_i / 2.0)
            y_in_l, y_out_l = _hatch_window_y_bounds(x_lv)
            y_mid = side * (y_out_l + 0.036)
            p_lv = hatch_pt(x_lv, clamp(y_mid / hatch_aperture_hw(x_lv), -0.98, 0.98))
            bm_add_box(bm, (x_lv, y_mid, p_lv.z - 0.009), (0.115, 0.042, 0.005), mat_index=3, bevel=0.001,
                       rot_mat=Euler((0.0, 0.14, 0.0), "XYZ").to_matrix().to_4x4())
            # Flush recessed carbon louver vane (never pokes above fastback roofline!)
            bm_add_box(bm, (x_lv + 0.026, y_mid, p_lv.z - 0.004), (0.042, 0.044, 0.005), mat_index=1, bevel=0.0015,
                       rot_mat=Euler((0.0, 0.15, 0.0), "XYZ").to_matrix().to_4x4())

    finalize_bmesh("ZR1X_Rear_Hatch", bm, mat_list, piv, auto_smooth_deg=42.0, uv_scale=5.0)

    # === B. ZR1X_Hatch_SpineLouvers (Flush stepped Torch Red louvers + glossy carbon spine rails!) ===
    # Matches 05-top-view.jpg, 07-high-three-quarter.jpg, 037-rear-hatch-louvers.jpg:
    # ZERO bulbous humps! Sits completely flush with fastback roofline!
    bm_sp = bmesh.new()
    # 0=Carbon spine rails & recessed trough, 1=Torch Red flush louver slats, 2=Dark vent screen
    mat_sp = [mats["Mat_Carbon_Twill_2x2"], mats["Mat_Torch_Red_GKZ"], mats["Mat_Dark_Mesh"]]

    # Recessed dark carbon spine tray running between the twin split windows (X = -1.56 .. -0.56)
    tray_grid = []
    for ix in range(16):
        x = mix(-1.56, -0.56, ix / 15.0)
        y_in, _ = _hatch_window_y_bounds(x)
        hw = hatch_aperture_hw(x)
        row = []
        for iy in range(9):
            s = mix(-1.0, 1.0, iy / 8.0)
            y = s * (y_in + 0.014)
            p = hatch_pt(x, clamp(y / max(0.15, hw), -0.95, 0.95))
            # Outer edges flush with window frame, center recessed cleanly 22 mm below roofline!
            recess = 0.022 * (1.0 - (s * s) ** 2)
            row.append(Vector((x, y, p.z - recess)))
        tray_grid.append(row)
    bm_add_thick_grid(bm_sp, tray_grid, thickness=0.008, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0, 0, 1)))

    # Left & Right crisp glossy carbon spine frame rails bordering the split glass panes
    for side in (-1.0, 1.0):
        rail_sec = []
        for ix in range(14):
            x = mix(-1.56, -0.56, ix / 13.0)
            y_in, _ = _hatch_window_y_bounds(x)
            p = hatch_pt(x, clamp(side * y_in / max(0.15, hatch_aperture_hw(x)), -0.95, 0.95))
            rail_sec.append([
                Vector((x, side * (y_in - 0.016), p.z + 0.002)),
                Vector((x, side * (y_in + 0.016), p.z + 0.002)),
                Vector((x, side * (y_in + 0.014), p.z - 0.018)),
                Vector((x, side * (y_in - 0.018), p.z - 0.018)),
            ])
        bm_add_closed_loft(bm_sp, rail_sec, mat_index=0, cap_start=True, cap_end=True)

    # 5 flush-stepped sculpted Torch Red louver slats along the center spine (NEVER protruding above roofline!)
    # Look at 05-top-view.jpg & 037-rear-hatch-louvers.jpg: 5 clean curved slats stepping gently downward
    # with crisp recessed dark extraction vents between them!
    slat_xs = [(-0.75, -0.60), (-0.95, -0.78), (-1.15, -0.98), (-1.35, -1.18), (-1.53, -1.38)]
    for x0, x1 in slat_xs:
        slat_grid = []
        for ix in range(6):
            tx = ix / 5.0
            x = mix(x0, x1, tx)
            y_in, _ = _hatch_window_y_bounds(x)
            hw_s = max(0.025, y_in - 0.016)
            row = []
            for iy in range(9):
                s = mix(-1.0, 1.0, iy / 8.0)
                y = s * hw_s
                z_roof = body_center_z(x) - 0.002 - 0.008 * (s * s)
                # Forward edge dips gently down (-14 mm) into the vent slot; rear lip sits flush (-1 mm) with fastback!
                z_slat = z_roof - mix(0.001, 0.015, tx ** 1.35)
                # Subtle curved front lip sweep matching 037-rear-hatch-louvers.jpg
                x_s = x - 0.012 * (s * s)
                row.append(Vector((x_s, y, z_slat)))
            slat_grid.append(row)
        bm_add_thick_grid(bm_sp, slat_grid, thickness=0.007, outer_mat=1, inner_mat=0, rim_mat=0, out_hint=Vector((0, 0, 1)))

        # Dark vent mesh bar recessed under front edge of each louver
        x_v = x1 - 0.008
        y_in_v, _ = _hatch_window_y_bounds(x_v)
        bm_add_box(bm_sp, (x_v, 0.0, body_center_z(x_v) - 0.018), (0.024, max(0.04, (y_in_v - 0.02) * 2.0), 0.005), mat_index=2)

    finalize_bmesh("ZR1X_Hatch_SpineLouvers", bm_sp, mat_sp, piv, auto_smooth_deg=38.0, uv_scale=6.0)


# ---------------------------------------------------------------------------
# 4. Removable C2Z Visible Carbon Targa Roof (Pivot_Roof_Panel)
# ---------------------------------------------------------------------------

def _build_roof_panel(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    piv = pivots["Pivot_Roof_Panel"]

    # === A. ZR1X_Roof_CarbonPanel (Center exposed 2x2 glossy carbon targa skin) ===
    bm_c = bmesh.new()
    s_split = 0.805  # Center 80.5% is glossy carbon, outer 19.5% L/R are Torch Red cant rails!
    cf_grid = []
    for ix in range(14):
        x = mix(ROOF_REAR_X - 0.002, ROOF_FRONT_X + 0.004, ix / 13.0)
        row = [roof_surface_point(clamp(x, ROOF_REAR_X, ROOF_FRONT_X), mix(-s_split, s_split, iy / 20.0)) for iy in range(21)]
        cf_grid.append(row)
    bm_add_thick_grid(bm_c, cf_grid, thickness=0.010, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 0, 1)))
    finalize_bmesh(
        "ZR1X_Roof_CarbonPanel", bm_c,
        [mats["Mat_Carbon_Twill_2x2"], mats["Mat_Black_Trim_Satin"]],
        piv, auto_smooth_deg=42.0, uv_scale=5.5,
    )

    # === B. ZR1X_Roof_CantRail_L / R (Torch Red painted outer targa side rails sealing A-pillar to halo!) ===
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm_cr = bmesh.new()
        cr_grid = []
        for ix in range(14):
            x = mix(ROOF_REAR_X - 0.006, ROOF_FRONT_X + 0.008, ix / 13.0)
            row = []
            for ik in range(6):
                s = side * mix(s_split, 1.045, ik / 5.0)
                p = roof_surface_point(clamp(x, ROOF_REAR_X, ROOF_FRONT_X), s)
                p.x += (x - clamp(x, ROOF_REAR_X, ROOF_FRONT_X))
                if ik == 5:
                    p.z -= 0.014  # Roll outer rail neatly down over frameless door glass top!
                row.append(p)
            cr_grid.append(row)
        bm_add_thick_grid(bm_cr, cr_grid, thickness=0.012, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, side * 0.35, 1)))
        finalize_bmesh(
            f"ZR1X_Roof_CantRail_{sfx}", bm_cr,
            [mats["Mat_Torch_Red_GKZ"], mats["Mat_Black_Trim_Satin"]],
            piv, auto_smooth_deg=40.0, uv_scale=4.5,
        )

    # === C. ZR1X_Roof_Headliner (Black Alcantara inner liner + front/rear targa latches) ===
    bm_hl = bmesh.new()
    hl_grid = []
    for ix in range(10):
        x = mix(ROOF_REAR_X + 0.025, ROOF_FRONT_X - 0.025, ix / 9.0)
        row = []
        for iy in range(15):
            s = mix(-0.92, 0.92, iy / 14.0)
            p = roof_surface_point(x, s)
            p.z -= 0.016
            row.append(p)
        hl_grid.append(row)
    bm_add_thick_grid(bm_hl, hl_grid, thickness=0.008, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, 0, -1)))
    # Front twin targa latch levers & rear center latch (visible when roof lifts up!)
    for sy in (-0.34, 0.34):
        bm_add_box(bm_hl, (ROOF_FRONT_X - 0.045, sy, 1.175), (0.065, 0.042, 0.014), mat_index=1, bevel=0.003)
    bm_add_box(bm_hl, (ROOF_REAR_X + 0.045, 0.0, 1.182), (0.055, 0.085, 0.016), mat_index=1, bevel=0.003)
    finalize_bmesh(
        "ZR1X_Roof_Headliner", bm_hl,
        [mats["Mat_Alcantara_Black"], mats["Mat_Black_Trim_Satin"]],
        piv, auto_smooth_deg=40.0, uv_scale=6.0,
    )


# ---------------------------------------------------------------------------
# 5. Hinged Flush Fuel Filler Flap (Pivot_Fuel_Flap — L Quarter Only)
# ---------------------------------------------------------------------------

def _build_fuel_flap(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    piv = pivots["Pivot_Fuel_Flap"]  # World pos (-0.645, +0.950, +0.830)
    bm = bmesh.new()
    mat_list = [mats["Mat_Torch_Red_GKZ"], mats["Mat_Black_Trim_Satin"]]

    # Flush curved circular/oval lid conforming smoothly to L rear quarter flank_y(x, z)!
    # Subtle 2.5 mm gap inside the quarter bezel — NOT a drawn thick black ring!
    n_rad = 4
    n_ang = 28
    rx = FUEL_RADIUS_X - 0.003
    rz = FUEL_RADIUS_Z - 0.003

    outer_rings: List[List[bmesh.types.BMVert]] = []
    inner_rings: List[List[bmesh.types.BMVert]] = []
    c_y = flank_y(FUEL_CENTER_X, FUEL_CENTER_Z, include_intake_recess=False) + 0.0015
    v_c_out = bm.verts.new(Vector((FUEL_CENTER_X, c_y, FUEL_CENTER_Z)))
    v_c_in = bm.verts.new(Vector((FUEL_CENTER_X, c_y - 0.008, FUEL_CENTER_Z)))

    for ir in range(1, n_rad + 1):
        fr = ir / float(n_rad)
        ro, ri = [], []
        for ia in range(n_ang):
            a = 2.0 * math.pi * ia / n_ang
            px = FUEL_CENTER_X + rx * fr * math.cos(a)
            pz = FUEL_CENTER_Z + rz * fr * math.sin(a)
            py = flank_y(px, pz, include_intake_recess=False) + 0.0015
            ro.append(bm.verts.new(Vector((px, py, pz))))
            ri.append(bm.verts.new(Vector((px, py - 0.008, pz))))
        outer_rings.append(ro)
        inner_rings.append(ri)

    # Center fan
    for ia in range(n_ang):
        na = (ia + 1) % n_ang
        f1 = bm.faces.new((v_c_out, outer_rings[0][na], outer_rings[0][ia]))
        f1.material_index = 0
        f1.smooth = True
        f2 = bm.faces.new((v_c_in, inner_rings[0][ia], inner_rings[0][na]))
        f2.material_index = 1
        f2.smooth = True

    # Concentric rings
    for ir in range(n_rad - 1):
        for ia in range(n_ang):
            na = (ia + 1) % n_ang
            fo = bm.faces.new((outer_rings[ir][ia], outer_rings[ir][na], outer_rings[ir + 1][na], outer_rings[ir + 1][ia]))
            fo.material_index = 0
            fo.smooth = True
            fi = bm.faces.new((inner_rings[ir][ia], inner_rings[ir + 1][ia], inner_rings[ir + 1][na], inner_rings[ir][na]))
            fi.material_index = 1
            fi.smooth = True

    # Rim edge (satin black thin gasket reveal)
    for ia in range(n_ang):
        na = (ia + 1) % n_ang
        frim = bm.faces.new((outer_rings[-1][ia], outer_rings[-1][na], inner_rings[-1][na], inner_rings[-1][ia]))
        frim.material_index = 1
        frim.smooth = False

    # Curved black inner gooseneck hinge arm tucked cleanly INBOARD of outer quarter skin!
    hinge_sec = []
    for k in range(6):
        tk = k / 5.0
        hx = mix(-0.715, -0.648, tk)
        hy = mix(c_y - 0.016, 0.922, tk) - 0.016 * math.sin(tk * math.pi)
        hz = mix(FUEL_CENTER_Z, 0.830, tk)
        hinge_sec.append([
            Vector((hx, hy - 0.005, hz - 0.010)),
            Vector((hx, hy + 0.005, hz - 0.010)),
            Vector((hx, hy + 0.005, hz + 0.010)),
            Vector((hx, hy - 0.005, hz + 0.010)),
        ])
    bm_add_closed_loft(bm, hinge_sec, mat_index=1, cap_start=True, cap_end=True)

    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    finalize_bmesh("ZR1X_Fuel_Flap", bm, mat_list, piv, auto_smooth_deg=40.0, uv_scale=6.0)


# ---------------------------------------------------------------------------
# Module Entry Point
# ---------------------------------------------------------------------------

def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Build all hinged/removable closures (doors, mirrors, hood, hatch, roof, fuel flap)."""
    _build_doors_and_mirrors(pivots, mats)
    _build_front_hood(pivots, mats)
    _build_rear_hatch(pivots, mats)
    _build_roof_panel(pivots, mats)
    _build_fuel_flap(pivots, mats)
