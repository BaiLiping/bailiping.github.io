"""Package a reviewed candidate and its fixed-camera baselines alongside the studio."""
import os
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
V2 = HERE.parent
WORK = V2.parent
SITE = WORK / "site_v2/chevrolet-corvette-zr1x"
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("audit", type=Path)
args = ap.parse_args()
current = json.loads((args.audit / "metrics.json").read_text())
views = json.loads((SITE / "chevrolet-views.json").read_text())
inventory = json.loads((V2 / "inventory.json").read_text())
frames = {f["id"]: f for f in inventory["frames"]}
row_by_id = {f["id"]: f for f in current["frames"]}
cameras = json.loads((V2 / "cameras.json").read_text())["frames"]
site_data = SITE / "benchmark"
site_data.mkdir(exist_ok=True)
rev = current["model_sha256"]
if hashlib.sha256((SITE / "corvette_zr1x_2027.glb").read_bytes()).hexdigest() != rev:
    raise ValueError("Review and route GLB hashes differ")
camera_subset = {fid: cameras[fid]["viewer"] for fid in row_by_id}
current["studio_camera_sha256"] = hashlib.sha256(
    json.dumps(camera_subset, sort_keys=True, separators=(",", ":")).encode()
).hexdigest()
current["floor_trace_sha256"] = hashlib.sha256(
    (HERE / "floor_traces.json").read_bytes()
).hexdigest()
baselines = {}
for kind, folder in [
    ("Earlier public build", "registered-published"),
    ("Recovered build before refitting", "registered-inherited"),
]:
    d = json.loads((V2 / "resume-baseline" / folder / "metrics.json").read_text())
    baselines[kind] = {
        "model_sha256": d["model_sha256"],
        "summary": d["summary"],
        "frames": [
            {k: q[k] for k in ("id", "iou", "median_px", "p95_px")} for q in d["frames"]
        ],
    }
current["baselines"] = baselines
current[
    "method"
] += " The shaded pass uses the production studio materials and lighting, with the floor hidden. The transparent overlay combines the independently measured outer boundary with visible tonal edges."
archive = json.loads((WORK / "site/chevrolet-corvette-zr1x/sources.json").read_text())
current["earlier_sources"] = [
    {k: f[k] for k in ["id", "subject", "original_url"]} for f in archive
]
current["overview"] = (
    f"30 turntable angles at 1500 × 750 and seven Chevrolet studio images at 2500 × 1407. "
    f"The average silhouette overlap is {current['summary']['orbit']['mean_iou']:.1%} on the turntable and {current['summary']['hires']['mean_iou']:.1%} on the larger images. "
    f"The studio also offers {len(views)-37} component, cabin and alternate-configuration comparisons."
)
notes = json.loads((HERE / "observations.json").read_text())
rows = []
for v in views:
    fid = v["id"]
    src = frames[fid]
    m = row_by_id.get(fid)
    if m:
        status, note = notes[fid]
        m.update(status=status, note=note)
    else:
        status = "limited"
        note = notes[fid][1]
        m = {"id": fid, "status": status, "note": note}
        current["frames"].append(m)
    for kind, ext in [("render", "webp"), ("lines", "png")]:
        name = f"{fid}-{kind}.{ext}"
        shutil.copyfile(args.audit / name, site_data / name)
    m.update(
        render=f"benchmark/{fid}-render.webp", outline=f"benchmark/{fid}-lines.png"
    )
    local = dict(
        id=fid,
        label=v["label"],
        source=src.get("source") or v["source"],
        original_url=src.get("original_url", ""),
        credit=v["credit"],
        status=status,
        note=note,
        photo=str((V2 / src["original"]).resolve()),
    )
    if "render" in m:
        local.update(
            render=str((SITE / m["render"]).resolve()),
            outline=str((SITE / m["outline"]).resolve()),
            revision=rev,
            camera=f"cameras.json#{fid}",
        )
    rows.append(local)
shown = {f["id"] for f in views}
for src in inventory["frames"]:
    if src["id"] not in shown:
        rows.append(
            dict(
                id=src["id"],
                label=src.get("view") or src["id"],
                source=src.get("source") or src["original_url"],
                status="excluded",
                note="Supplementary archive material for "
                + src.get("system", "vehicle detail")
                + ". The curated studio uses the views identified in its camera register.",
                photo=str((V2 / src["original"]).resolve()),
            )
        )
counts = Counter(f["status"] for f in rows)
current["counts"] = {
    status: counts[status]
    for status in ("verified", "limited", "fix", "pending", "excluded")
}
current["archive_only"] = len(rows) - len(views)
current[
    "coverage"
] = f"{counts['verified']} verified for the visible features noted, {counts['fix']} with further fitting needed, {counts['limited']} limited comparisons and {counts['pending']} pending; {current['archive_only']} further images are retained as reference material."
local_output = V2 / "frames.json"
# Use paths relative to the manifest so users can move the complete work folder.

for row in rows:
    for key in ["photo", "render", "outline"]:
        if key in row:
            row[key] = os.path.relpath(row[key], local_output.parent)
local_output.write_text(
    json.dumps(dict(vehicle=inventory["vehicle"], revision=rev, frames=rows), indent=2)
    + "\n"
)
(SITE / "benchmark.json").write_text(json.dumps(current, indent=2) + "\n")
print(current["summary"], current["counts"], current["archive_only"])
