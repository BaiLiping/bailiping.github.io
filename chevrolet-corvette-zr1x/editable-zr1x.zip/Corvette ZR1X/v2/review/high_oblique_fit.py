"""Rebuild the view-31 hand-landmark calibration from Chevrolet images 32 and 33.

The recorded pixel coordinates refer to 1000 x 563 inspection copies of the
original 2500 x 1407 images. The solver uses native pixels. The wheel centers
use the physical wheelbase/radii and exposed wheel-face offsets. All other
points are triangulated from independently registered views 32 and 33.
"""
import json
from pathlib import Path
import sys
import cv2
import numpy as np
from scipy.optimize import least_squares

work = Path(__file__).resolve().parents[2]
refs = work / "refs_v2"
sys.path.insert(0, str(refs))
from photo_cameras import project, save_pose, vector

registered = json.loads((refs / "photo-camera-fits.json").read_text())
start = np.array([-1.4754, 0.8763, 349.77, 21.089, 3.07, 25.0, 0.06])


# Initial estimate retained in the acquisition-time camera register.
def projection(p):
    theta, phi, radius, fov, *center = p
    back = np.array(
        [np.sin(phi) * np.cos(theta), np.cos(phi), np.sin(phi) * np.sin(theta)]
    )
    right = np.array([np.sin(theta), 0, -np.cos(theta)])
    up = np.cross(back, right)
    eye = (
        np.array(center)
        + radius * np.tan(np.pi / 12) / np.tan(np.deg2rad(fov / 2)) * back
    )
    rotation = np.stack([right, -up, -back])
    focal = 703.5 / np.tan(np.deg2rad(fov / 2))
    K = np.array([[focal, 0, 1250], [0, focal, 703.5], [0, 0, 1]])
    A = K @ rotation
    return np.c_[A, -A @ eye]


# (feature, view-32, view-33, view-31, used to fit)
marks = [
    ("wishbone forward", (702, 228), (591, 248), (530, 328), True),
    ("wishbone aft", (835, 228), (761, 246), (716, 332), False),
    ("wishbone fork", (795, 256), (696, 270), (634, 355), False),
    ("wishbone base", (759.3, 334.8), (651.3, 330.2), (591, 396), False),
    ("lamp inner", (345, 292), (194, 296), (147, 333), True),
    ("lamp front outside", (527, 244), (336, 260), (252, 358), False),
    ("front wheel", (551, 351), (369, 345), (288, 413), True),
    ("rear wheel", (857, 325), (804, 321.7), (765, 379.5), True),
    ("fuel flap center", (790, 215), (707, 236), (660, 320), False),
    ("mirror outboard fwd", (623, 209), (472, 236), (395, 334), False),
    ("near wing endplate upper corner", (943, 118), (927, 154), (932, 251), True),
    ("hood badge", (229, 296), (137, 296), (128, 289), True),
]
pixel_scale = np.array([2.5, 1407 / 563])
P32, P33 = [projection(vector(registered[f"view-{i}"]["pose"])) for i in (32, 33)]
points = []
observed = []
for name, a, b, c, _ in marks:
    h = cv2.triangulatePoints(
        P32, P33, np.array(a) * pixel_scale, np.array(b) * pixel_scale
    ).ravel()
    x = h[:3] / h[3]
    if name == "front wheel":
        x = np.array([1.3615, 0.3365, -0.916]) * 1000 / 18
    if name == "rear wheel":
        x = np.array([-1.3615, 0.35295, -0.928]) * 1000 / 18
    if name == "hood badge":
        x[2] = 0
    points.append(x)
    observed.append(np.array(c) * pixel_scale)
X, Y = np.array(points), np.array(observed)
train = np.array([q[-1] for q in marks])


def errors(x):
    pix = (project(X[train], x, 2500, 1407) - Y[train]).ravel()
    return np.r_[pix, (x[4:] - start[4:]) * 0.035, (x[3] - start[3]) * 0.06]


delta = np.array([0.23, 0.16, 0.16 * start[2], 7, 10, 10, 10])
fit = least_squares(
    errors,
    start,
    bounds=(start - delta, start + delta),
    loss="soft_l1",
    f_scale=4,
    x_scale="jac",
    max_nfev=350,
)
for msg, p in [("initial", start), ("revised", fit.x)]:
    error = np.linalg.norm(project(X[~train], p, 2500, 1407) - Y[~train], axis=1)
    print(msg, "holdout median in native pixels", float(np.median(error)))
print(json.dumps(save_pose(fit.x), indent=2))
