"""Compare an exported Draco GLB against the native Chevrolet studio originals in inventory.json.

Run with MODEL and RESULT_DIR, and --legacy for original meter-scale +X-tail export.
The material pass uses neutral diagnostic lighting. Silhouette scores use rendered alpha;
the JPEG studio floor is estimated using its low saturation and local gradient, not used as exact truth.
"""
import os
import shutil
import argparse
import base64
import hashlib
import io
import json
import statistics
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageOps
from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
V2 = HERE.parent
WORK = Path(os.environ.get("ZR1X_WORK", V2.parent)).resolve()
VENDOR = (
    Path(os.environ.get("ZR1X_SITE", WORK / "site_v2")).resolve()
    / "chevrolet-corvette-zr1x/vendor"
)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("model", type=Path)
parser.add_argument("result", type=Path)
parser.add_argument(
    "--fit-overrides", type=Path, help="Use a fixed calibration revision for all models"
)
parser.add_argument("--legacy", action="store_true")
parser.add_argument(
    "--refresh",
    action="store_true",
    help="Replace only the selected frames in an existing audit of the same GLB",
)
parser.add_argument("--frames", nargs="*", type=int, default=list(range(37)))
args = parser.parse_args()
args.result.mkdir(parents=True, exist_ok=True)


def biggest(binary):
    n, l, stats, _ = cv2.connectedComponentsWithStats(binary.astype("uint8"), 8)
    if n <= 1:
        raise ValueError("Empty foreground")
    return (l == 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])).astype("uint8")


def photo_mask(image, index):
    if index < 30:
        return biggest(np.array(image.convert("RGBA"))[:, :, 3] >= 254)
    bgr = cv2.cvtColor(np.array(image.convert("RGB")), cv2.COLOR_RGB2BGR)
    _, s, v = cv2.split(cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV))
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    grad = np.hypot(
        cv2.Sobel(gray, cv2.CV_32F, 1, 0), cv2.Sobel(gray, cv2.CV_32F, 0, 1)
    )
    local = cv2.dilate(grad, np.ones((15, 15), "uint8"))
    foreground = (s > 22) | ((v < 110) & (local > 28)) | (v < 16)
    if index == 30:
        foreground = (s > 25) | (v < 100)
    closed = cv2.morphologyEx(
        foreground.astype("uint8"),
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13)),
    )
    clean = cv2.morphologyEx(
        closed, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    )
    # Manual lower-edge traces distinguish body and cast shadow where both are
    # close to black. Coordinates are stored at a common 1000 x 563 review size.
    trace = np.array(json.loads((HERE / "floor_traces.json").read_text())[str(index)])
    height, width = clean.shape
    ceiling = (
        np.interp(np.arange(width) * 1000 / width, trace[:, 0], trace[:, 1])
        * height
        / 563
    )
    clean[np.arange(height)[:, None] > ceiling[None, :]] = 0
    return biggest(clean)


def footprint(mask):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        raise ValueError("Empty rendered footprint")
    result = np.zeros_like(mask)
    return cv2.drawContours(result, contours, -1, 1, -1)


def contour(mask):
    outer, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(mask)
    return cv2.drawContours(out, outer, -1, 1, 1)


def distance(edge):
    return cv2.distanceTransform(1 - edge, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/model.glb":
            file = args.model
        elif path == "/":
            file = HERE / "capture.html"
        elif path.startswith("/vendor/") and Path(path).name in {
            f.name for f in VENDOR.iterdir()
        }:
            file = VENDOR / Path(path).name
        else:
            return self.send_error(404)
        body = file.read_bytes()
        self.send_response(200)
        self.send_header(
            "Content-Type",
            {
                "html": "text/html",
                "js": "application/javascript",
                "wasm": "application/wasm",
            }.get(file.suffix[1:], "application/octet-stream"),
        )
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_):
        pass


inv = {f["id"]: f for f in json.loads((V2 / "inventory.json").read_text())["frames"]}
cams = json.loads((V2 / "cameras.json").read_text())["frames"]
if args.fit_overrides:
    for fid, record in json.loads(args.fit_overrides.read_text()).items():
        cams[fid]["viewer"] = record["pose"]
server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
rows = []
with sync_playwright() as pl:
    browser = pl.chromium.launch(
        executable_path=os.environ.get("CHROME_BIN") or shutil.which("google-chrome"),
        headless=True,
        args=[
            "--no-sandbox",
            "--use-angle=gl",
            "--enable-webgl",
            "--disable-dev-shm-usage",
            "--ignore-gpu-blocklist",
        ],
    )
    page = browser.new_page()
    page.on("pageerror", lambda e: print(e, flush=True))
    page.goto(
        f"http://127.0.0.1:{server.server_port}/" + ("?legacy" if args.legacy else "")
    )
    page.wait_for_function("!!window.drawCamera", timeout=90000)
    for i in args.frames:
        fid = f"view-{i:02d}"
        ref = inv[fid]
        cam = cams[fid]["viewer"]
        path = V2 / ref["original"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != ref["sha256"]:
            raise ValueError("Reference hash mismatch: " + fid)
        raw = Image.open(path)
        w, h = raw.size
        data = page.evaluate("spec=>drawCamera(spec)", dict(pose=cam, w=w, h=h))
        render = Image.open(io.BytesIO(base64.b64decode(data))).convert("RGBA")
        m = photo_mask(raw, i)
        g = (np.array(render)[:, :, 3] >= 32).astype("uint8")
        m, g = footprint(m), footprint(g)
        a, b = contour(m), contour(g)
        # The close wheel is cropped by the image edges. These lines are
        # properties of the frame, independent of the car or camera fit.
        if i == 36:
            for e in (a, b):
                e[:3] = 0
                e[-3:] = 0
                e[:, :3] = 0
                e[:, -3:] = 0
        error = np.r_[distance(a)[b > 0], distance(b)[a > 0]]
        iou = float((g & m).sum() / (g | m).sum())
        row = dict(
            id=fid,
            label=cams[fid]["label"],
            size=[w, h],
            photo_sha256=ref["sha256"],
            iou=round(iou, 5),
            median_px=round(float(np.median(error)), 2),
            p95_px=round(float(np.percentile(error, 95)), 2),
            mask_source="manufacturer alpha" if i < 30 else "estimated JPEG foreground",
            reference=ref["source"],
        )
        span = int(np.ptp(np.where(m)[1]) + 1)
        row["pose"] = cam
        row.update(
            photo_span_px=span, p95_percent_span=round(row["p95_px"] / span * 100, 3)
        )
        rows.append(row)
        photo = Image.new("RGBA", (w, h), "white")
        photo.alpha_composite(raw.convert("RGBA"))
        photo = photo.convert("RGB")
        pred = Image.new("RGBA", (w, h), "white")
        pred.alpha_composite(render)
        pred = pred.convert("RGB")
        overlay = np.array(photo)
        edge = cv2.dilate(b, np.ones((3, 3), "uint8"))
        overlay[edge > 0] = (0, 160, 200)
        # Transparent line pass for the review. Boundary is depth-tested mesh alpha.
        # Secondary lines are local visible tonal discontinuities in the neutral pass.
        gray = cv2.cvtColor(np.asarray(pred), cv2.COLOR_RGB2GRAY)
        seams = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 1.1), 50, 100)
        line = np.zeros((h, w, 4), "uint8")
        line[:, :, :3] = (0, 136, 164)
        line[:, :, 3] = np.maximum(
            cv2.dilate(b, np.ones((3, 3), "uint8")) * 255, (seams // 2) * g
        )
        Image.fromarray(line, "RGBA").save(
            args.result / (fid + "-lines.png"), optimize=True
        )
        for tag, img in [("render", pred), ("outline", Image.fromarray(overlay))]:
            img.save(args.result / (fid + "-" + tag + ".webp"), quality=87, method=2)
        pair = Image.new("RGB", (1000, 300), "white")
        for k, img in enumerate((photo, pred)):
            panel = ImageOps.contain(img, (500, 273))
            pair.paste(panel, (k * 500 + (500 - panel.width) // 2, 4))
        ImageDraw.Draw(pair).text(
            (8, 282),
            f"{fid}, Chevrolet (left) / exported GLB (right) | IoU {iou:.3f} | p95 {row['p95_px']} px",
            fill="black",
        )
        pair.save(args.result / (fid + "-pair.jpg"), quality=88)
        print(fid, row["iou"], row["p95_px"], flush=True)
    browser.close()
server.shutdown()
if args.refresh:
    prior = json.loads((args.result / "metrics.json").read_text())
    if prior["model_sha256"] != hashlib.sha256(args.model.read_bytes()).hexdigest():
        raise ValueError("Cannot merge measurements of different GLBs")
    merged = {row["id"]: row for row in prior["frames"]}
    merged.update({row["id"]: row for row in rows})
    rows = [merged[fid] for fid in sorted(merged)]
summary = {}
for name, ids in [("orbit", range(30)), ("hires", range(30, 37))]:
    subset = [r for r in rows if int(r["id"][-2:]) in ids]
    if subset:
        summary[name] = dict(
            n=len(subset),
            mean_iou=round(statistics.mean(r["iou"] for r in subset), 5),
            mean_p95_px=round(statistics.mean(r["p95_px"] for r in subset), 2),
        )
report = dict(
    model_sha256=hashlib.sha256(args.model.read_bytes()).hexdigest(),
    method="Shipped mesh and materials, native-resolution GPU silhouette, fixed V2 cameras. Both masks are filled to their external contours. Symmetric outer-contour distance in pixels. Orbit foreground uses the manufacturer alpha. The seven JPEG foreground masks estimate the visible exterior by color, texture and a hand-traced lower boundary separating cast shadow. These seven masks are approximate. Cropped image borders are excluded from wheel-view distances.",
    summary=summary,
    frames=rows,
)
(args.result / "metrics.json").write_text(json.dumps(report, indent=2) + "\n")
print(summary)
