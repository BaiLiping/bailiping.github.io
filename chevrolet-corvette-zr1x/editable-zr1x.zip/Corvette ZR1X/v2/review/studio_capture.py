"""Recapture the aligned shaded pass using the shipped studio's actual materials and lighting.

This script serves the unmodified site locally. A Playwright-only instrumentation
hook renders the assembled car through the registered native-image projection.
Only the floor and fog are disabled to simplify comparison on white.
"""
import os
import shutil
import argparse, base64, hashlib, io, json, threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from functools import partial
from pathlib import Path
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageOps
from playwright.sync_api import sync_playwright

work = Path(os.environ.get("ZR1X_WORK", Path(__file__).resolve().parents[2])).resolve()
site = Path(os.environ.get("ZR1X_SITE", work / "site_v2")).resolve()
route = site / "chevrolet-corvette-zr1x"
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("audit", type=Path)
ap.add_argument("--frames", type=int, nargs="*", default=None)
args = ap.parse_args()
report = json.loads((args.audit / "metrics.json").read_text())
if (
    report["model_sha256"]
    != hashlib.sha256((route / "corvette_zr1x_2027.glb").read_bytes()).hexdigest()
):
    raise ValueError("Studio GLB does not match measured GLB")
views = json.loads((route / "chevrolet-views.json").read_text())
inv = {
    f["id"]: f for f in json.loads((work / "v2/inventory.json").read_text())["frames"]
}


class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass


server = ThreadingHTTPServer(("127.0.0.1", 0), partial(Quiet, directory=site))
threading.Thread(target=server.serve_forever, daemon=True).start()
hook = """
window.nativeProductCapture = ({pose,w,h,tile}) => {
  const {theta,phi,radius,fov,center,roll,principalPoint} = pose;
  const d=radius*Math.tan(Math.PI/12)/Math.tan(fov*Math.PI/360);
  const cam=new THREE.PerspectiveCamera(fov,w/h,0.3,8000);
  cam.position.set(center[0]+d*Math.sin(phi)*Math.cos(theta),center[1]+d*Math.cos(phi),center[2]+d*Math.sin(phi)*Math.sin(theta));
  cam.lookAt(...center);
  if(roll) cam.rotateZ(roll);
  if(tile)cam.setViewOffset(w,h,...tile);
  if(principalPoint){
    cam.projectionMatrix.elements[8]+=(1-2*principalPoint[0])*(tile?w/tile[2]:1);
    cam.projectionMatrix.elements[9]+=(2*principalPoint[1]-1)*(tile?h/tile[3]:1);
    cam.projectionMatrixInverse.copy(cam.projectionMatrix).invert();
  }
  if (state.explode>.001) throw Error('Car is exploded: '+state.explode);
  renderer.setPixelRatio(1);renderer.setSize(tile?tile[2]:w,tile?tile[3]:h,false);
  scene.background=new THREE.Color(pose.background || 0xffffff);scene.fog.density=0;studioFloor.visible=false;
  renderer.shadowMap.needsUpdate=true; renderer.render(scene,cam);
  return renderer.domElement.toDataURL().split(',')[1];
};
window.captureState=()=>state.explode;
window.prepareCapture=async(label)=>{
  if(!referenceViews.has(label))registerFrames(await (await fetch('./chevrolet-views.json')).json());
  if(!referenceViews.has(label))throw Error('Missing saved camera for '+label);
  matchChevroletView(label);
  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
};
"""
with sync_playwright() as pw:
    b = pw.chromium.launch(
        executable_path=os.environ.get("CHROME_BIN") or shutil.which("google-chrome"),
        headless=True,
        args=[
            "--no-sandbox",
            "--use-angle=gl",
            "--ignore-gpu-blocklist",
            "--enable-webgl",
            "--disable-dev-shm-usage",
        ],
    )
    p = b.new_page(viewport=dict(width=1000, height=650))

    def intercept(r):
        res = r.fetch()
        s = res.text()
        k = s.rindex("</script>")
        r.fulfill(response=res, body=s[:k] + hook + s[k:])

    p.route("**/chevrolet-corvette-zr1x/", intercept)
    p.on("pageerror", lambda e: print("page error", e, flush=True))
    p.goto(f"http://127.0.0.1:{server.server_port}/chevrolet-corvette-zr1x/")
    p.wait_for_function(
        "window.__zr1xModelLoaded && window.captureState && window.captureState()<.001",
        timeout=60000,
    )
    for i in args.frames if args.frames is not None else range(len(views)):
        v = views[i]
        fid = v["id"]
        w, h = v["width"], v["height"]
        p.evaluate("label=>prepareCapture(label)", v["label"])
        rendered = Image.new("RGB", (w, h))
        tile_size = 2048 if max(w, h) > 3500 else max(w, h)
        for y in range(0, h, tile_size):
            for x in range(0, w, tile_size):
                rect = [x, y, min(tile_size, w - x), min(tile_size, h - y)]
                native = p.evaluate(
                    "d=>nativeProductCapture(d)",
                    dict(
                        pose=v["pose"],
                        w=w,
                        h=h,
                        tile=rect if tile_size < max(w, h) else None,
                    ),
                )
                patch = Image.open(io.BytesIO(base64.b64decode(native))).convert("RGB")
                if patch.size != tuple(rect[2:]):
                    raise ValueError(
                        f"{fid} raster size {patch.size} differs from request {rect}"
                    )
                rendered.paste(patch, (x, y))
        rendered.save(args.audit / f"{fid}-render.webp", quality=90, method=3)
        if i < 37:
            lines = Image.open(args.audit / f"{fid}-lines.png").convert("RGBA")
            orig = np.array(lines)
            edge = orig[:, :, 3] >= 220
        else:
            orig = np.zeros((h, w, 4), "uint8")
            orig[:, :, :3] = (0, 136, 164)
            edge = np.zeros((h, w), bool)
        gray = cv2.cvtColor(np.asarray(rendered), cv2.COLOR_RGB2GRAY)
        secondary = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 1.1), 50, 100)
        orig[:, :, 3] = np.maximum(edge.astype("uint8") * 255, secondary // 2)
        Image.fromarray(orig, "RGBA").save(
            args.audit / f"{fid}-lines.png", optimize=True
        )
        ref = Image.open(work / "v2" / inv[fid]["original"]).convert("RGBA")
        photo = Image.new("RGBA", ref.size, "white")
        photo.alpha_composite(ref)
        pair = Image.new("RGB", (1000, 300), "white")
        for j, img in enumerate([photo.convert("RGB"), rendered]):
            panel = ImageOps.contain(img, (500, 273))
            pair.paste(panel, (j * 500 + (500 - panel.width) // 2, 4))
        m = next((r for r in report["frames"] if r["id"] == fid), None)
        metric = (
            f"Overlap {m['iou']:.3f}    p95 {m['p95_px']} px"
            if m
            else "Approximate comparison"
        )

        ImageDraw.Draw(pair).text(
            (8, 282),
            f"{fid}  Reference / Studio GLB    {metric}",
            fill="black",
        )
        pair.save(args.audit / f"{fid}-pair.jpg", quality=90)
        print(fid, flush=True)
    b.close()
server.shutdown()
