"""MLP Tremec TR-9080 8-speed dual-clutch transaxle with separable case & precision internals.

Populates ``Pivot_DCT_Transaxle`` (world pos ``(-1.520, 0.000, +0.410)``).
Photo-matched to GM TechLink TR-9080 exterior (`tl_17970_01_F07-trans-Corvette.jpg`)
and GM TR-9080 cutaway (`gears_03_Screen-Shot-2021-06-02-at-9.49.47-AM.png`).

- Separable outer casing (``ZR1X_DCT_Case_*``) lifts away on explode/X-ray.
- Precision internals (``ZR1X_DCT_Int_*``, matching ``ENCLOSED_INTERNALS_RE``) expose
  the concentric wet dual-clutch, concentric odd/even input shafts, twin countershafts,
  all 8 forward + reverse helical gears proportioned to the real ``MLP`` ratios
  (2.91 / 1.76 / 1.22 / 0.88 / 0.65 / 0.51 / 0.40 / 0.33, Rev 2.63), synchronizers,
  shift forks, and eLSD differential (5.56:1 effective final drive) aligned to rear
  axle ``X = -1.3615, Z = +0.3530``.
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

import bpy
import numpy as np

from rig_utils import (
    AXLE_R_X,
    TIRE_R_R,
    join_meshes,
    make_cylinder,
    make_loft,
    make_mesh,
    make_roundbox,
    make_tube,
)


def _m(mats: Dict[str, bpy.types.Material], key: str, fallback: str = "Mat_Aluminum_Cast") -> bpy.types.Material:
    return mats.get(key) or mats.get(fallback) or next(iter(mats.values()))


def _ellipse_case(
    name: str,
    stations: Sequence[Tuple[float, float, float, float, float]],
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "x",
    steps: int = 32,
    cap_ends: bool = True,
) -> bpy.types.Object:
    sections = []
    for axial, u0, z0, ru, rz in stations:
        ring = []
        for j in range(steps):
            t = 2.0 * math.pi * j / steps
            u = u0 + ru * math.cos(t)
            z = z0 + rz * math.sin(t)
            ring.append((axial, u, z) if axis == "x" else (u, axial, z))
        sections.append(ring if axis == "x" else ring[::-1])
    return make_loft(name, sections, mat, pivot, cap_ends=cap_ends, smooth=True, auto_smooth_deg=45.0)


def _bolt_cluster(
    name: str,
    centers: Sequence[Tuple[float, float, float]],
    radius: float,
    height: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "x",
) -> bpy.types.Object:
    verts, faces = [], []
    for cx, cy, cz in centers:
        base = len(verts)
        for off, r in ((0.0, radius), (height * 0.85, radius), (height, radius * 0.80)):
            for k in range(6):
                a = k * math.pi / 3.0
                u, v = r * math.cos(a), r * math.sin(a)
                if axis == "x":
                    verts.append((cx + off, cy + u, cz + v))
                elif axis == "y":
                    verts.append((cx + u, cy + off, cz + v))
                else:
                    verts.append((cx + u, cy + v, cz + off))
        for j in range(2):
            for k in range(6):
                nk = (k + 1) % 6
                faces.append((base + j * 6 + k, base + j * 6 + nk, base + (j + 1) * 6 + nk, base + (j + 1) * 6 + k))
        faces.append(tuple(base + 12 + k for k in range(6)))
    return make_mesh(name, verts, faces, mat, pivot, smooth=False, recalc_normals=True)


def _make_helical_gear(
    name: str,
    cx: float,
    cy: float,
    cz: float,
    pitch_r: float,
    width: float,
    n_teeth: int,
    helix_twist: float,
    bore_r: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "x",
) -> bpy.types.Object:
    """Create a crisp 3D helical-toothed gear with recessed hub web & central bore."""
    addendum = min(0.0042, 0.95 * math.pi * pitch_r / max(n_teeth, 10) * 0.42)
    dedendum = addendum * 1.18
    r_root = max(bore_r + 0.004, pitch_r - dedendum)
    r_tip = pitch_r + addendum
    r_web = max(bore_r + 0.003, r_root - 0.005)

    # 4 points per tooth around perimeter
    n_ring = n_teeth * 4
    verts: List[Tuple[float, float, float]] = []
    faces: List[Tuple[int, ...]] = []

    def _pt(axial: float, rad: float, ang: float) -> Tuple[float, float, float]:
        u, v = rad * math.cos(ang), rad * math.sin(ang)
        if axis == "x":
            return (cx + axial, cy + u, cz + v)
        return (cx + u, cy + axial, cz + v)

    # 4 axial stations: front rim -> front chamfer -> rear chamfer -> rear rim (twisted by helix_twist)
    axial_layers = (
        (-width * 0.50, 0.97, -helix_twist * 0.50),
        (-width * 0.44, 1.00, -helix_twist * 0.44),
        (width * 0.44, 1.00, helix_twist * 0.44),
        (width * 0.50, 0.97, helix_twist * 0.50),
    )
    for ax_off, tip_scale, twist in axial_layers:
        for k in range(n_teeth):
            for ph, is_tip in ((0.0, False), (0.20, True), (0.55, True), (0.75, False)):
                ang = 2.0 * math.pi * (k + ph) / n_teeth + twist
                rad = (r_root + (r_tip - r_root) * tip_scale) if is_tip else r_root
                verts.append(_pt(ax_off, rad, ang))

    # Outer toothed face quads
    for lay in range(3):
        a0 = lay * n_ring
        b0 = (lay + 1) * n_ring
        for i in range(n_ring):
            ni = (i + 1) % n_ring
            faces.append((a0 + i, a0 + ni, b0 + ni, b0 + i))

    # Front & rear recessed gear webs down to central bore
    front_web_idx = len(verts)
    for i in range(n_ring):
        ang = 2.0 * math.pi * i / n_ring - helix_twist * 0.50
        verts.append(_pt(-width * 0.34, r_web, ang))
    front_bore_idx = len(verts)
    for i in range(n_ring):
        ang = 2.0 * math.pi * i / n_ring - helix_twist * 0.50
        verts.append(_pt(-width * 0.52, bore_r, ang))

    rear_web_idx = len(verts)
    for i in range(n_ring):
        ang = 2.0 * math.pi * i / n_ring + helix_twist * 0.50
        verts.append(_pt(width * 0.34, r_web, ang))
    rear_bore_idx = len(verts)
    for i in range(n_ring):
        ang = 2.0 * math.pi * i / n_ring + helix_twist * 0.50
        verts.append(_pt(width * 0.52, bore_r, ang))

    for i in range(n_ring):
        ni = (i + 1) % n_ring
        faces.append((0 + ni, 0 + i, front_web_idx + i, front_web_idx + ni))
        faces.append((front_web_idx + ni, front_web_idx + i, front_bore_idx + i, front_bore_idx + ni))
        faces.append((3 * n_ring + i, 3 * n_ring + ni, rear_web_idx + ni, rear_web_idx + i))
        faces.append((rear_web_idx + i, rear_web_idx + ni, rear_bore_idx + ni, rear_bore_idx + i))
        faces.append((front_bore_idx + i, rear_bore_idx + i, rear_bore_idx + ni, front_bore_idx + ni))

    return make_mesh(name, verts, faces, mat, pivot, smooth=False, recalc_normals=True)


# ---------------------------------------------------------------------------
# 1. Separable Outer Ribbed Aluminum Casing (ZR1X_DCT_Case_*)
# ---------------------------------------------------------------------------

def _build_dct_casing(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    gun = _m(mats, "Mat_Gear_Steel")
    steel = _m(mats, "Mat_Steel_Machined")
    dark = _m(mats, "Mat_Black_Trim_Satin")

    # A) Hollow Cast-Aluminum Bellhousing Bowl (ZR1X_DCT_Case_Bellhousing, X = -1.185 .. -1.335)
    bparts: List[bpy.types.Object] = []
    # Double-walled open bowl profile (outer shell -> front mating flange -> inner hollow cavity)
    bell_st = (
        (-1.335, 0.0, 0.410, 0.214, 0.176),
        (-1.285, 0.0, 0.422, 0.196, 0.186),
        (-1.210, 0.0, 0.444, 0.198, 0.195),
        (-1.185, 0.0, 0.448, 0.186, 0.186),
        (-1.185, 0.0, 0.448, 0.162, 0.162),
        (-1.215, 0.0, 0.444, 0.168, 0.166),
        (-1.290, 0.0, 0.422, 0.166, 0.158),
        (-1.332, 0.0, 0.410, 0.178, 0.146),
    )
    bparts.append(_ellipse_case("tmp_bell", bell_st, cast, piv, steps=36, cap_ends=False))
    # Radial strengthening ribs around bellhousing flange (TR-9080 signature!)
    for t in np.linspace(0.0, 2.0 * math.pi, 14, endpoint=False):
        bparts.append(make_tube(
            "tmp_bell_rib",
            [
                (-1.192, 0.178 * math.cos(t), 0.448 + 0.178 * math.sin(t)),
                (-1.255, 0.198 * math.cos(t), 0.432 + 0.190 * math.sin(t)),
                (-1.330, 0.210 * math.cos(t), 0.410 + 0.176 * math.sin(t)),
            ],
            0.006, brushed, piv, segments=8,
        ))
    bparts.append(_bolt_cluster(
        "tmp_bell_bolts",
        [(-1.196, 0.184 * math.cos(t), 0.448 + 0.184 * math.sin(t)) for t in np.linspace(0, 2 * math.pi, 12, endpoint=False)],
        0.008, 0.009, steel, piv, axis="x",
    ))
    join_meshes(bparts, "ZR1X_DCT_Case_Bellhousing", piv)

    # B) Ribbed Main Gearcase + Top Oil-to-Water Heat Exchanger + Filter (ZR1X_DCT_Case_Main)
    mparts: List[bpy.types.Object] = []
    main_st = (
        (-1.335, 0.0, 0.408, 0.216, 0.174),
        (-1.455, 0.0, 0.400, 0.198, 0.162),
        (-1.565, 0.0, 0.404, 0.174, 0.158),
        (-1.705, 0.0, 0.408, 0.156, 0.148),
        (-1.805, 0.0, 0.410, 0.146, 0.132),
    )
    mparts.append(_ellipse_case("tmp_main_case", main_st, cast, piv, steps=36))
    # Twin side countershaft casting lobes + triangulated diamond webbing (TR-9080 photo!)
    for s in (-1.0, 1.0):
        lobes = (
            (-1.33, s * 0.142, 0.422, 0.082, 0.082),
            (-1.45, s * 0.136, 0.412, 0.084, 0.080),
            (-1.59, s * 0.112, 0.404, 0.072, 0.070),
            (-1.73, s * 0.098, 0.410, 0.062, 0.064),
            (-1.80, s * 0.090, 0.412, 0.046, 0.048),
        )
        mparts.append(_ellipse_case("tmp_lobe", lobes, cast, piv, steps=22))
        # Circular radially-ribbed axle output domes at rear axle X=-1.3615, Z=0.353
        mparts.append(_ellipse_case(
            "tmp_axle_dome",
            (
                (s * 0.150, AXLE_R_X, TIRE_R_R, 0.132, 0.132),
                (s * 0.188, AXLE_R_X, TIRE_R_R, 0.116, 0.116),
                (s * 0.205, AXLE_R_X, TIRE_R_R, 0.076, 0.076),
            ),
            cast, piv, axis="y", steps=28,
        ))
        for k in range(12):
            ang = 2.0 * math.pi * k / 12.0
            mparts.append(make_tube(
                "tmp_adome_rib",
                [
                    (AXLE_R_X + 0.074 * math.cos(ang), s * 0.202, TIRE_R_R + 0.074 * math.sin(ang)),
                    (AXLE_R_X + 0.128 * math.cos(ang), s * 0.168, TIRE_R_R + 0.128 * math.sin(ang)),
                ],
                0.005, brushed, piv, segments=6,
            ))
        # Diamond triangulated side stiffening webs
        for xx in (-1.40, -1.49, -1.58, -1.67):
            yy = float(np.interp(-xx, [1.34, 1.52, 1.74], [0.206, 0.194, 0.160]))
            for dz in (-1.0, 1.0):
                mparts.append(make_tube(
                    "tmp_truss",
                    [(xx + 0.032, s * (yy - 0.025), 0.405 + 0.072 * dz), (xx - 0.022, s * (yy + 0.004), 0.412), (xx - 0.058, s * (yy - 0.032), 0.410 + 0.068 * dz)],
                    0.0058, brushed, piv, segments=6,
                ))
    # Iconic top stacked-plate aluminum oil-to-water Heat Exchanger (tl_17970_01!)
    mparts.append(make_roundbox("tmp_hex_base", (-1.34, 0.0, 0.568), (0.210, 0.135, 0.018), cast, piv, bevel=0.004))
    for k in range(8):
        mparts.append(make_roundbox("tmp_hex_plate", (-1.34, 0.0, 0.580 + k * 0.0085), (0.198, 0.124, 0.006), brushed, piv, bevel=0.002))
    # Twin top coolant elbow ports + vertical breather/cooler standpipe (mech-dct-rear34.png!)
    for cy in (-0.036, 0.036):
        mparts.append(make_roundbox("tmp_port_blk", (-1.265, cy, 0.658), (0.036, 0.028, 0.028), cast, piv, bevel=0.004))
        mparts.append(make_cylinder("tmp_port_stub", (-1.248, cy, 0.660), (-1.202, cy, 0.660), 0.011, 0.011, steel, piv, segments=14))
    mparts.append(make_cylinder("tmp_standpipe", (-1.40, -0.088, 0.565), (-1.40, -0.088, 0.688), 0.015, 0.015, brushed, piv, segments=16))
    mparts.append(make_cylinder("tmp_standcap", (-1.40, -0.088, 0.688), (-1.40, -0.088, 0.700), 0.019, 0.018, steel, piv, segments=16))
    # External canister DCT filter + bent aluminum feed line on left (+Y) side
    mparts.append(make_cylinder("tmp_filter", (-1.27, 0.210, 0.315), (-1.27, 0.210, 0.435), 0.034, 0.032, brushed, piv, segments=20))
    mparts.append(make_tube(
        "tmp_oil_pipe",
        [(-1.27, 0.210, 0.435), (-1.27, 0.205, 0.525), (-1.30, 0.145, 0.575), (-1.32, 0.070, 0.580)],
        0.009, steel, piv, segments=10,
    ))
    join_meshes(mparts, "ZR1X_DCT_Case_Main", piv)

    # C) Rounded Horizontally-Ribbed Tail Cover (ZR1X_DCT_Case_Tail, X = -1.805 .. -1.938)
    tparts: List[bpy.types.Object] = []
    tail_st = (
        (-1.805, 0.0, 0.410, 0.146, 0.132),
        (-1.855, 0.0, 0.410, 0.122, 0.112),
        (-1.908, 0.0, 0.409, 0.095, 0.088),
        (-1.938, 0.0, 0.409, 0.068, 0.064),
    )
    tparts.append(_ellipse_case("tmp_tail", tail_st, cast, piv, steps=32))
    for rx in (-1.835, -1.868, -1.900):
        rr = float(np.interp(-rx, [1.805, 1.938], [0.144, 0.072]))
        tparts.append(_ellipse_case("tmp_trib", ((rx - 0.005, 0.0, 0.410, rr + 0.007, rr * 0.92 + 0.007), (rx + 0.005, 0.0, 0.410, rr + 0.007, rr * 0.92 + 0.007)), brushed, piv, steps=28))
    # Rear transaxle mounting ear lugs
    for s in (-1.0, 1.0):
        tparts.append(make_roundbox("tmp_rear_lug", (-1.88, s * 0.145, 0.355), (0.075, 0.065, 0.032), cast, piv, bevel=0.006))
    join_meshes(tparts, "ZR1X_DCT_Case_Tail", piv)

    # D) Finned Bottom Oil Sump Pan (ZR1X_DCT_Case_OilPan)
    oparts: List[bpy.types.Object] = []
    oparts.append(make_roundbox("tmp_opan", (-1.535, 0.0, 0.258), (0.375, 0.258, 0.052), dark, piv, bevel=0.018))
    oparts.append(make_roundbox("tmp_oflange", (-1.535, 0.0, 0.282), (0.398, 0.282, 0.014), cast, piv, bevel=0.004))
    for yy in np.linspace(-0.10, 0.10, 7):
        oparts.append(make_roundbox("tmp_ofin", (-1.535, float(yy), 0.231), (0.320, 0.006, 0.010), gun, piv, bevel=0.001))
    oparts.append(_bolt_cluster(
        "tmp_obolts",
        [(xx, s * 0.132, 0.270) for xx in np.linspace(-1.71, -1.36, 7) for s in (-1.0, 1.0)],
        0.005, -0.005, steel, piv, axis="z",
    ))
    join_meshes(oparts, "ZR1X_DCT_Case_OilPan", piv)

    # E) Mechatronic Side Control Cover (ZR1X_DCT_Case_Mechatronic)
    cparts: List[bpy.types.Object] = []
    cparts.append(make_roundbox("tmp_mech_cov", (-1.545, 0.196, 0.395), (0.235, 0.042, 0.165), brushed, piv, bevel=0.010))
    for k in range(5):
        cparts.append(make_roundbox("tmp_mrib_v", (-1.635 + k * 0.045, 0.217, 0.395), (0.007, 0.008, 0.145), cast, piv, bevel=0.002))
    for k in range(3):
        cparts.append(make_roundbox("tmp_mrib_h", (-1.545, 0.217, 0.345 + k * 0.050), (0.215, 0.008, 0.007), cast, piv, bevel=0.002))
    # Rectangular multi-pin harness connector
    cparts.append(make_roundbox("tmp_mplug", (-1.675, 0.180, 0.435), (0.036, 0.042, 0.044), dark, piv, bevel=0.005))
    join_meshes(cparts, "ZR1X_DCT_Case_Mechatronic", piv)


# ---------------------------------------------------------------------------
# 2. Precision Exposed DCT Internals (ZR1X_DCT_Int_*)
# ---------------------------------------------------------------------------

def _build_dct_internals(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    steel = _m(mats, "Mat_Steel_Machined")
    gear_mat = _m(mats, "Mat_Gear_Steel")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    copper = _m(mats, "Mat_Copper_Busbar", "Mat_Heat_Shield")

    z_in = 0.448
    y_odd, z_odd = 0.096, 0.414   # Left countershaft (odd gears 1, 3, 5, 7)
    y_evn, z_evn = -0.096, 0.414  # Right countershaft (even gears 2, 4, 6, 8, R)
    cd = math.hypot(y_odd, z_in - z_odd)  # Center distance = 0.1018 m

    # A) Concentric Wet Dual-Clutch Drum Assembly (ZR1X_DCT_Int_DualClutch, gears_03 cutaway!)
    dcparts: List[bpy.types.Object] = []
    # Outer perforated wet clutch basket (X = -1.215 .. -1.305)
    dcparts.append(make_cylinder("tmp_basket_out", (-1.218, 0.0, z_in), (-1.302, 0.0, z_in), 0.126, 0.126, gear_mat, piv, segments=36))
    # Slotted perimeter cooling windows / raised teeth around basket drum
    for k in range(24):
        a = 2.0 * math.pi * k / 24.0
        dcparts.append(make_roundbox(
            "tmp_bslot", (-1.260, 0.126 * math.cos(a), z_in + 0.126 * math.sin(a)),
            (0.068, 0.012, 0.012), brushed, piv, bevel=0.002, rot_euler=(a, 0.0, 0.0),
        ))
    # Front drive hub plate with 8 radial spokes & splined input snout (visible right in bellhousing!)
    dcparts.append(make_cylinder("tmp_front_disc", (-1.208, 0.0, z_in), (-1.220, 0.0, z_in), 0.118, 0.118, copper, piv, segments=36))
    for k in range(8):
        a = 2.0 * math.pi * k / 8.0
        dcparts.append(make_cylinder(
            "tmp_win_cut",
            (-1.205, 0.072 * math.cos(a), z_in + 0.072 * math.sin(a)),
            (-1.216, 0.072 * math.cos(a), z_in + 0.072 * math.sin(a)),
            0.018, 0.018, dark, piv, segments=12,
        ))
    dcparts.append(_make_helical_gear("tmp_input_spline", -1.196, 0.0, z_in, 0.022, 0.034, 18, 0.0, 0.008, steel, piv))
    # Concentric K1 (outer odd) & K2 (inner even) multi-plate friction discs
    for k in range(6):
        px = -1.226 - k * 0.012
        dcparts.append(make_cylinder("tmp_k1_plate", (px, 0.0, z_in), (px - 0.005, 0.0, z_in), 0.112, 0.112, steel, piv, segments=32))
        dcparts.append(make_cylinder("tmp_k2_plate", (px - 0.006, 0.0, z_in), (px - 0.010, 0.0, z_in), 0.082, 0.082, copper, piv, segments=28))
    join_meshes(dcparts, "ZR1X_DCT_Int_DualClutch", piv)

    # Real MLP Tremec TR-9080 8-speed ratios!
    # For ratio R = r_counter / r_input with r_input + r_counter = cd (0.1018 m):
    #   r_in = cd / (1 + R), r_ct = cd * R / (1 + R)
    odd_gears = [
        # (name, x_world, ratio, width, n_in, n_ct)
        ("1st", -1.475, 2.91, 0.024, 15, 44),
        ("3rd", -1.565, 1.22, 0.022, 24, 29),
        ("5th", -1.665, 0.65, 0.020, 32, 21),
        ("7th", -1.760, 0.40, 0.020, 38, 15),
    ]
    even_gears = [
        ("2nd", -1.515, 1.76, 0.024, 19, 34),
        ("4th", -1.610, 0.88, 0.022, 28, 25),
        ("6th", -1.705, 0.51, 0.020, 35, 18),
        ("8th", -1.805, 0.33, 0.020, 40, 13),
        ("Rev", -1.860, 2.40, 0.019, 16, 38),
    ]

    # B) Concentric Odd & Even Input Shafts + Input Helical Pinions (ZR1X_DCT_Int_InputShafts)
    iparts: List[bpy.types.Object] = []
    # Solid inner shaft (odd gears, extends to tail)
    iparts.append(make_cylinder("tmp_in_inner", (-1.195, 0.0, z_in), (-1.885, 0.0, z_in), 0.014, 0.014, steel, piv, segments=20))
    # Hollow outer concentric shaft (even gears, forward half)
    iparts.append(make_cylinder("tmp_in_outer", (-1.240, 0.0, z_in), (-1.620, 0.0, z_in), 0.021, 0.021, brushed, piv, segments=22))
    # Ball bearings at front & rear supports
    for bx in (-1.335, -1.878):
        iparts.append(make_cylinder("tmp_in_brg", (bx - 0.010, 0.0, z_in), (bx + 0.010, 0.0, z_in), 0.036, 0.036, brushed, piv, segments=24))
    # All 9 helical input drive gears on the concentric input shafts
    for gname, gx, ratio, gw, n_in, _ in odd_gears + even_gears:
        r_in = max(0.023, min(0.072, cd / (1.0 + ratio)))
        iparts.append(_make_helical_gear(f"tmp_in_{gname}", gx, 0.0, z_in, r_in, gw, n_in, 0.14, 0.015, gear_mat, piv))
    join_meshes(iparts, "ZR1X_DCT_Int_InputShafts", piv)

    # C) Twin Countershafts, Transfer Pinions, Shift Rails & Bronze Shift Forks (ZR1X_DCT_Int_CounterShafts)
    csparts: List[bpy.types.Object] = []
    for y_c, z_c in ((y_odd, z_odd), (y_evn, z_evn)):
        csparts.append(make_cylinder("tmp_cshaft", (-1.345, y_c, z_c), (-1.890, y_c, z_c), 0.017, 0.017, steel, piv, segments=20))
        # Tapered roller bearings
        for bx in (-1.350, -1.882):
            csparts.append(make_cylinder("tmp_cbrg", (bx - 0.011, y_c, z_c), (bx + 0.011, y_c, z_c), 0.034, 0.034, brushed, piv, segments=22))
        # Helical final-drive transfer pinion at front of each countershaft engaging the eLSD ring gear!
        csparts.append(_make_helical_gear("tmp_xfer_pin", -1.395, y_c, z_c, 0.034, 0.028, 17, -0.18, 0.017, steel, piv))

    # Reverse idler shaft & pinion
    csparts.append(make_cylinder("tmp_rev_sh", (-1.825, -0.052, 0.498), (-1.892, -0.052, 0.498), 0.011, 0.011, steel, piv, segments=14))
    csparts.append(_make_helical_gear("tmp_rev_id", -1.860, -0.052, 0.498, 0.028, 0.020, 16, 0.0, 0.011, gear_mat, piv))

    # Longitudinal shift rails + copper/bronze shift forks & springs (clearly visible in gears_03 cutaway!)
    for s in (-1.0, 1.0):
        ry = s * 0.058
        rz = 0.506
        csparts.append(make_cylinder("tmp_srail", (-1.38, ry, rz), (-1.84, ry, rz), 0.007, 0.007, steel, piv, segments=12))
        # Spiral shift-rail return spring coil sleeve
        for k in range(9):
            csparts.append(make_cylinder(
                "tmp_scoil", (-1.45 - k * 0.009, ry, rz), (-1.454 - k * 0.009, ry, rz),
                0.0125, 0.0125, copper, piv, segments=12,
            ))
        # Two bronze shift forks per rail engaging the synchronizer collars
        for fx in (-1.520, -1.712) if s > 0 else (-1.562, -1.755):
            csparts.append(make_roundbox("tmp_sfork_arm", (fx, ry + s * 0.020, rz - 0.044), (0.014, 0.054, 0.088), copper, piv, bevel=0.003))
    join_meshes(csparts, "ZR1X_DCT_Int_CounterShafts", piv)

    # D) Odd & Even Helical Countershaft Gearsets + Synchronizers (ZR1X_DCT_Int_GearSet_Odd / Even)
    for gset_name, y_c, z_c, glist, syn_xs in (
        ("ZR1X_DCT_Int_GearSet_Odd", y_odd, z_odd, odd_gears, (-1.520, -1.712)),
        ("ZR1X_DCT_Int_GearSet_Even", y_evn, z_evn, even_gears, (-1.562, -1.755)),
    ):
        gparts: List[bpy.types.Object] = []
        for gname, gx, ratio, gw, _, n_ct in glist:
            r_in = max(0.023, min(0.072, cd / (1.0 + ratio)))
            r_ct = max(0.024, cd - r_in)
            gparts.append(_make_helical_gear(f"tmp_ct_{gname}", gx, y_c, z_c, r_ct, gw, n_ct, -0.14, 0.017, gear_mat, piv))
        # Grooved sliding synchronizer hubs + bronze blocker rings between gear pairs
        for sx in syn_xs:
            gparts.append(_make_helical_gear("tmp_syn_sleeve", sx, y_c, z_c, 0.044, 0.026, 26, 0.0, 0.020, steel, piv))
            for dx in (-0.016, 0.016):
                gparts.append(make_cylinder(
                    "tmp_syn_ring", (sx + dx - 0.004, y_c, z_c), (sx + dx + 0.004, y_c, z_c),
                    0.039, 0.036, copper, piv, segments=22,
                ))
        join_meshes(gparts, gset_name, piv)

    # E) eLSD Differential + Massive Helical Final-Drive Ring Gear + 6-Bolt CV Output Flanges (ZR1X_DCT_Int_eLSD)
    eparts: List[bpy.types.Object] = []
    # Aligned EXACTLY to rear axle centerline X = -1.3615, Z = +0.3530!
    eparts.append(_make_helical_gear("tmp_ring_final", AXLE_R_X, -0.055, TIRE_R_R, 0.110, 0.030, 48, 0.18, 0.054, gear_mat, piv, axis="y"))
    # eLSD differential carrier housing & multi-plate hydraulic limited-slip clutch pack
    eparts.append(make_cylinder("tmp_diff_cage", (AXLE_R_X, -0.075, TIRE_R_R), (AXLE_R_X, 0.088, TIRE_R_R), 0.078, 0.078, brushed, piv, segments=32))
    eparts.append(make_cylinder("tmp_elsd_pack", (AXLE_R_X, 0.068, TIRE_R_R), (AXLE_R_X, 0.132, TIRE_R_R), 0.072, 0.068, copper, piv, segments=28))
    # Internal bevel spider pin & side gears visible in open window
    eparts.append(make_cylinder("tmp_spider_pin", (AXLE_R_X, 0.0, TIRE_R_R - 0.055), (AXLE_R_X, 0.0, TIRE_R_R + 0.055), 0.012, 0.012, steel, piv, segments=12))
    # Twin heavy 6-bolt machined CV output flanges extending out to Y = ±0.214 (matching rear half-shafts!)
    for s in (-1.0, 1.0):
        eparts.append(make_cylinder("tmp_out_stub", (AXLE_R_X, s * 0.085, TIRE_R_R), (AXLE_R_X, s * 0.198, TIRE_R_R), 0.032, 0.036, steel, piv, segments=22))
        eparts.append(make_cylinder("tmp_out_flange", (AXLE_R_X, s * 0.194, TIRE_R_R), (AXLE_R_X, s * 0.214, TIRE_R_R), 0.064, 0.064, copper, piv, segments=28))
        eparts.append(_bolt_cluster(
            "tmp_cv_bolts",
            [(AXLE_R_X + 0.048 * math.cos(t), s * 0.214, TIRE_R_R + 0.048 * math.sin(t))
             for t in np.linspace(0, 2 * math.pi, 6, endpoint=False)],
            0.0065, s * 0.006, steel, piv, axis="y",
        ))
    join_meshes(eparts, "ZR1X_DCT_Int_eLSD", piv)


def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Populate ``Pivot_DCT_Transaxle`` with separable TR-9080 casing and full 8-speed internals."""
    piv = pivots["Pivot_DCT_Transaxle"]
    _build_dct_casing(piv, mats)
    _build_dct_internals(piv, mats)
