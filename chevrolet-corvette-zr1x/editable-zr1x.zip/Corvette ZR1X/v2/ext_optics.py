"""Sculpted headlamps, white LED DRL boomerangs, amber side markers, twin-element red LED
taillamps, and CHMSL for the 2027 Chevrolet Corvette ZR1X (v2).

Builds under ``Pivot_Body_Assembly``:
- ``ZR1X_Headlight_Housing_L/R`` (gloss-black bucket, twin LED projectors, amber side marker)
- ``ZR1X_Headlight_DRL_L/R`` (crisp C8 white LED boomerang DRL)
- ``ZR1X_Headlight_Clear_Lens_L/R`` (flush aerodynamic outer lens using ``Mat_Headlight_Clear_Lens``)
- ``ZR1X_Taillight_Housing_L/R`` (gloss-black twin-pod bucket + upper crystal white LED clusters)
- ``ZR1X_Taillight_Lens_L/R`` (signature twin-element red LED chevron blades using ``Mat_Taillight_Red_Lens``)
- ``ZR1X_CHMSL`` (recessed horizontal upper deck red LED stop lamp)
"""

from __future__ import annotations

import math
from typing import Dict, List

import bmesh
import bpy
from mathutils import Euler, Matrix, Vector

from ext_body import (
    bm_add_box,
    bm_add_closed_loft,
    bm_add_quad_grid,
    bm_add_thick_grid,
    clamp,
    finalize_bmesh,
    mix,
)


# ---------------------------------------------------------------------------
# 1. C8 Sculpted Headlamps (Housing + Projectors + Amber Marker + DRL + Lens)
# ---------------------------------------------------------------------------

def _headlamp_surface_pt(u: float, v: float, side: float = 1.0, inset: float = 0.0) -> Vector:
    """Parametric outer surface of the swept triangular C8 headlamp lens.

    u in [0, 1]: 0 = inner nose tip (X=2.20, Y=0.45, Z=0.585) -> 1 = rear fender tip (X=1.57, Y=0.905, Z=0.778)
    v in [0, 1]: 0 = lower bumper crease -> 1 = upper fender brow edge
    """
    x_lo = mix(2.205, 1.605, u ** 0.90)
    x_hi = mix(2.185, 1.565, u ** 0.96)
    y_lo = mix(0.455, 0.885, u ** 0.86)
    y_hi = mix(0.468, 0.908, u ** 0.78)
    open_w = math.sin(clamp(u, 0.0, 1.0) * math.pi) ** 0.56
    z_mid = mix(0.596, 0.770, u ** 0.88)
    z_lo = z_mid - 0.056 * open_w
    z_hi = z_mid + 0.052 * open_w

    x = mix(x_lo, x_hi, v) + 0.016 * math.sin(v * math.pi) * open_w - inset * 0.65
    y = mix(y_lo, y_hi, v) + 0.018 * math.sin(v * math.pi) * open_w - inset * 0.55
    z = mix(z_lo, z_hi, v) + 0.014 * math.sin(v * math.pi) * open_w - inset * 0.45
    return Vector((x, side * y, z))


def _build_headlamps(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]

    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        # === A. ZR1X_Headlight_Housing_L / R (Dark gloss bucket, twin Bi-LED projectors, amber corner marker) ===
        bm_h = bmesh.new()
        # 0=Gloss black housing, 1=Brushed aluminum projector shroud, 2=White projector LED, 3=Amber side marker
        mat_h = [
            mats["Mat_Black_Trim_Gloss"],
            mats["Mat_Aluminum_Brushed"],
            mats["Mat_Taillight_White_LED"],
            mats["Mat_Amber_Reflector"],
        ]

        # Recessed dark inner housing bowl (inset 42 mm behind outer lens)
        bowl_grid: List[List[Vector]] = []
        for iu in range(14):
            u = iu / 13.0
            row = []
            for iv in range(9):
                v = iv / 8.0
                # Edges sit near lens perimeter (inset 6 mm), center drops deep (46 mm)
                d = 0.008 + 0.042 * math.sin(u * math.pi) * math.sin(v * math.pi)
                row.append(_headlamp_surface_pt(u, v, side=side, inset=d))
            bowl_grid.append(row)
        bm_add_thick_grid(bm_h, bowl_grid, thickness=0.008, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0.5, side * 0.5, 1)))

        # Twin sculpted Bi-LED projector barrels (low-beam forward + high-beam aft)
        for u_p, r_p in ((0.36, 0.025), (0.56, 0.027)):
            pc = _headlamp_surface_pt(u_p, 0.52, side=side, inset=0.030)
            # Chrome/aluminum circular bezel ring facing forward (+X, slightly outboard)
            dir_v = Vector((0.94, side * 0.34, 0.04)).normalized()
            up_v = Vector((0.0, 0.0, 1.0))
            right_v = dir_v.cross(up_v).normalized()
            up_v = right_v.cross(dir_v).normalized()

            ring_sec = []
            for depth, rad in ((-0.025, r_p * 0.90), (0.004, r_p * 1.05), (0.012, r_p * 0.86)):
                ring = []
                for s_i in range(16):
                    a = 2.0 * math.pi * s_i / 16.0
                    pt = pc + dir_v * depth + (right_v * math.cos(a) + up_v * math.sin(a)) * rad
                    ring.append(pt)
                ring_sec.append(ring)
            bm_add_closed_loft(bm_h, ring_sec, mat_index=1, cap_start=True, cap_end=False)

            # Glowing crisp white projector lens eye
            eye_sec = []
            for depth, rad in ((0.002, r_p * 0.72), (0.015, r_p * 0.45)):
                eye_sec.append([
                    pc + dir_v * depth + (right_v * math.cos(2 * math.pi * s_i / 14) + up_v * math.sin(2 * math.pi * s_i / 14)) * rad
                    for s_i in range(14)
                ])
            bm_add_closed_loft(bm_h, eye_sec, mat_index=2, cap_start=True, cap_end=True)

        # Signature amber side-marker reflector along upper-outer rear fender corner of headlamp!
        # Matches 01-front-three-quarter.jpg and 006.png!
        amb_grid = []
        for iu in range(8):
            u = mix(0.66, 0.96, iu / 7.0)
            amb_grid.append([_headlamp_surface_pt(u, mix(0.58, 0.92, iv / 4.0), side=side, inset=0.009) for iv in range(5)])
        bm_add_thick_grid(bm_h, amb_grid, thickness=0.006, outer_mat=3, inner_mat=0, rim_mat=0, out_hint=Vector((0.3, side, 0.7)))

        finalize_bmesh(f"ZR1X_Headlight_Housing_{sfx}", bm_h, mat_h, body_piv, auto_smooth_deg=38.0)

        # === B. ZR1X_Headlight_DRL_L / R (Crisp C8 White LED Boomerang Daytime Running Light!) ===
        bm_d = bmesh.new()
        drl_sec = []
        # Sweeps along the entire lower edge (u=0.04..0.88) and curls sharply up the rear wingtip!
        for k in range(18):
            tk = k / 17.0
            if tk < 0.82:
                u = mix(0.03, 0.88, tk / 0.82)
                v = mix(0.14, 0.09, tk / 0.82)
            else:
                # Sharp upward boomerang flick at rear fender corner!
                f_up = (tk - 0.82) / 0.18
                u = mix(0.88, 0.96, f_up)
                v = mix(0.09, 0.52, f_up)
            p = _headlamp_surface_pt(u, v, side=side, inset=0.008)
            r_tube = mix(0.0075, 0.0055, tk)
            drl_sec.append([
                p + Vector(( 0.004,  0.0,  r_tube)),
                p + Vector(( 0.004,  side * r_tube, 0.0)),
                p + Vector((-0.006,  0.0, -r_tube)),
                p + Vector((-0.006, -side * r_tube, 0.0)),
            ])
        bm_add_closed_loft(bm_d, drl_sec, mat_index=0, cap_start=True, cap_end=True)
        finalize_bmesh(f"ZR1X_Headlight_DRL_{sfx}", bm_d, [mats["Mat_Taillight_White_LED"]], body_piv, auto_smooth_deg=45.0)

        # === C. ZR1X_Headlight_Clear_Lens_L / R (Aerodynamic flush outer clear lens -> Mat_Headlight_Clear_Lens!) ===
        bm_l = bmesh.new()
        lens_grid: List[List[Vector]] = []
        for iu in range(16):
            u = iu / 15.0
            lens_grid.append([_headlamp_surface_pt(u, iv / 10.0, side=side, inset=-0.001) for iv in range(11)])
        # Single smooth outward-facing clear sheet (prevents double-layer glass artifacts in Three.js!)
        bm_add_quad_grid(bm_l, lens_grid, mat_index=0, flip=(side < 0), smooth=True)
        # Ensure outward normals pointing (+X, side*Y, +Z)
        for f in bm_l.faces:
            if f.normal.dot(Vector((0.45, side * 0.65, 0.65))) < 0.0:
                f.normal_flip()
        finalize_bmesh(
            f"ZR1X_Headlight_Clear_Lens_{sfx}", bm_l, [mats["Mat_Headlight_Clear_Lens"]],
            body_piv, auto_smooth_deg=60.0, uv_scale=4.0,
        )


# ---------------------------------------------------------------------------
# 2. Twin-Element Red LED Taillamps & CHMSL
# ---------------------------------------------------------------------------

def _rear_lamp_x(y_abs: float) -> float:
    """Exact curved rear transom X position along the taillight pocket (matches _rear_bumper_pt!)."""
    a = clamp(y_abs / 0.89, 0.0, 1.0)
    return -2.192 + 0.145 * (a ** 2.15)


def _build_taillamps_and_chmsl(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]

    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        # === A. ZR1X_Taillight_Housing_L / R (Crisp dark gloss twin-pod bucket + upper crystal LED clusters) ===
        bm_th = bmesh.new()
        mat_th = [mats["Mat_Black_Trim_Gloss"], mats["Mat_Taillight_White_LED"], mats["Mat_Aluminum_Brushed"]]

        # Curved gloss-black tapered outer bucket wrapping smoothly around rear bumper corner!
        bucket = []
        for iz in range(7):
            tz = iz / 6.0
            row = []
            for iy in range(15):
                ty = iy / 14.0
                ya = mix(0.305, 0.885, ty)
                # Iconic C8 tapered taillamp contour: sleek tapered inner point & swept outboard wrap!
                z_lo_l = mix(0.768, 0.788, ty ** 1.3)
                z_hi_l = mix(0.872, 0.886, math.sin(ty * math.pi * 0.82)) - 0.018 * (ty ** 2.6)
                z_mod = mix(z_lo_l, z_hi_l, tz)
                xb = _rear_lamp_x(ya) + 0.012 + 0.014 * math.sin(tz * math.pi)
                row.append(Vector((xb, side * ya, z_mod)))
            bucket.append(row)
        bm_add_thick_grid(bm_th, bucket, thickness=0.016, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((-1, side * 0.25, 0)))

        # Sleek upper crystal white LED reverse/turn cluster strips
        for y_in, y_out in ((0.355, 0.530), (0.610, 0.805)):
            for seg in range(4):
                ys = mix(y_in, y_out, (seg + 0.5) / 4.0)
                xs = _rear_lamp_x(ys) + 0.004
                zs = mix(0.842, 0.854, (ys - 0.35) / 0.50)
                bm_add_box(bm_th, (xs, side * ys, zs), (0.016, 0.034, 0.017), mat_index=1, bevel=0.003)
                bm_add_box(bm_th, (xs + 0.004, side * (ys + 0.020), zs), (0.012, 0.005, 0.019), mat_index=2)

        finalize_bmesh(f"ZR1X_Taillight_Housing_{sfx}", bm_th, mat_th, body_piv, auto_smooth_deg=38.0)

        # === B. ZR1X_Taillight_Lens_L / R (Sleek tapered C8 double-chevron red LED blades!) ===
        bm_tl = bmesh.new()
        mat_tl = [mats["Mat_Taillight_Red_Lens"], mats["Mat_Black_Trim_Gloss"]]

        for idx_c, (y_inner, y_outer) in enumerate(((0.315, 0.568), (0.584, 0.882))):
            # Taper outer blade slightly upward & wrap smoothly forward around outer corner!
            dz_out = 0.014 if idx_c == 1 else 0.0
            pts = [
                (y_inner + 0.056, 0.868),
                (y_inner + 0.014, 0.830),
                (y_inner,         0.800),
                (y_inner + 0.028, 0.774),
                (mix(y_inner, y_outer, 0.55), 0.778 + dz_out * 0.4),
                (y_outer - 0.016, 0.794 + dz_out * 0.7),
                (y_outer,         0.826 + dz_out * 0.4),
                (y_outer - 0.020, 0.860),
            ]
            sec_list = []
            for k, (ya, za) in enumerate(pts):
                xa = _rear_lamp_x(ya) - 0.003
                r_z = 0.0074 if 2 <= k <= 5 else 0.0058
                sec_list.append([
                    Vector((xa - 0.007, side * ya, za + r_z)),
                    Vector((xa + 0.015, side * ya, za + r_z * 0.85)),
                    Vector((xa + 0.015, side * ya, za - r_z * 0.85)),
                    Vector((xa - 0.007, side * ya, za - r_z)),
                ])
            bm_add_closed_loft(bm_tl, sec_list, mat_index=0, cap_start=True, cap_end=True, smooth=True)

        x_div = _rear_lamp_x(0.576) - 0.002
        bm_add_box(bm_tl, (x_div + 0.006, side * 0.576, 0.824), (0.024, 0.012, 0.092), mat_index=1, bevel=0.002)

        finalize_bmesh(f"ZR1X_Taillight_Lens_{sfx}", bm_tl, mat_tl, body_piv, auto_smooth_deg=40.0)

    # === C. ZR1X_CHMSL (Slim horizontal red LED center stop lamp under rear deck lip!) ===
    bm_ch = bmesh.new()
    ch_sec = []
    for iy in range(11):
        y = mix(-0.195, 0.195, iy / 10.0)
        x = _rear_lamp_x(abs(y)) - 0.014
        z = 0.892
        ch_sec.append([
            Vector((x - 0.005, y, z + 0.0065)),
            Vector((x + 0.016, y, z + 0.0065)),
            Vector((x + 0.016, y, z - 0.0065)),
            Vector((x - 0.005, y, z - 0.0065)),
        ])
    bm_add_closed_loft(bm_ch, ch_sec, mat_index=0, cap_start=True, cap_end=True, smooth=False)
    # Gloss-black bezel frame above & below CHMSL strip
    bm_add_box(bm_ch, (-2.186, 0.0, 0.892), (0.016, 0.415, 0.020), mat_index=1, bevel=0.003)
    finalize_bmesh("ZR1X_CHMSL", bm_ch, [mats["Mat_Taillight_Red_Lens"], mats["Mat_Black_Trim_Gloss"]], body_piv, auto_smooth_deg=35.0)


# ---------------------------------------------------------------------------
# Module Entry Point
# ---------------------------------------------------------------------------

def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Build sculpted headlamps, DRLs, clear lenses, twin-element red taillamps & CHMSL."""
    _build_headlamps(pivots, mats)
    _build_taillamps_and_chmsl(pivots, mats)
