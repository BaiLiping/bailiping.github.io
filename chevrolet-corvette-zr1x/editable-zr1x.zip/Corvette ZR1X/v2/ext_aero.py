"""ZTK Carbon Fiber Aero (TOM/FEJ), side intakes, upper hatch scoops, and open honeycomb grilles
for the 2027 Chevrolet Corvette ZR1X (v2).

Builds:
- ``Pivot_ZTK_Wing``: W-contour cambered carbon mainplane (H ~ 1.285 m at flared tips),
  curved swept twin stanchions, twin dorsal vortex strakes, and upturned flared endplates.
- ``Pivot_Body_Assembly``:
  - ``ZR1X_Front_Splitter`` (stepped center bridge + upturned corner end-winglets)
  - ``ZR1X_Front_DivePlane_L/R`` (swept front carbon canards)
  - ``ZR1X_Side_Skirt_L/R`` (clean CFV carbon rockers — ZERO protruding underbody strakes!)
  - ``ZR1X_Side_Wishbone_L/R`` (sculpted 3D carbon rear-quarter intake boomerang)
  - ``ZR1X_Hatch_Scoop_L/R`` (true 3D hooded upper rear-quarter carbon air scoops w/ mesh)
  - ``ZR1X_Front_Grille_Center/L/R`` & ``ZR1X_Rear_Fascia_Grille_L/R`` (true 3D open honeycomb)
- ``Pivot_Door_L/R``:
  - ``ZR1X_Side_Wishbone_Door_L/R`` (door-mounted leading carbon wishbone spear swinging w/ door)
"""

from __future__ import annotations

import math
from typing import Dict, List

import bmesh
import bpy
from mathutils import Euler, Matrix, Vector

from ext_body import (
    bm_add_box,
    bm_add_closed_loft,
    bm_add_thick_grid,
    body_belt_z,
    body_sill_z,
    clamp,
    door_rear_cut_x,
    ease,
    finalize_bmesh,
    flank_y,
    hatch_surface_point,
    mix,
)


# ---------------------------------------------------------------------------
# 1. ZTK High Rear Carbon Wing (Pivot_ZTK_Wing)
# ---------------------------------------------------------------------------

def _wing_section_params(y_abs: float) -> tuple[float, float, float, float]:
    """Return (x_lead, chord, z_lower, aoa_deg) for the ZTK W-contour wing at |Y| in [0, 0.93].

    Calibrated to 014.png, 05-top-view.jpg, 006.png, carbon-fiber-high-wing.jpg, and v2_rig_spec.md:
    - Overall trailing edge at center X = -2.405 m (exact L = 4.860 m with splitter at +2.455 m!)
    - Sweeps gracefully forward outboard (+0.29 m forward at wingtips!)
    - Subtle central W-contour valley dipping between stanchions & rising gently toward endplates.
    """
    t = clamp(y_abs / 0.930, 0.0, 1.0)
    # Leading edge sweeps smoothly forward from -2.135 at center to -1.845 at tip
    x_lead = -2.135 + 0.290 * (t ** 1.32)
    # Chord widens slightly across stanchion/strake zone (|Y|~0.40 -> 0.33 m), tapers subtly to 0.295 at tip
    chord = 0.272 + 0.056 * math.exp(-((y_abs - 0.42) / 0.22) ** 2) + 0.022 * t
    # W-contour Z height: subtle lower center dip (1.106), gentle crest outboard (1.124)
    z_lower = 1.106 + 0.018 * (t ** 1.15) + 0.005 * ease(0.32, 0.46, y_abs)
    # Aggressive downforce angle of attack (~14.5 deg center, ~13.0 deg outboard)
    aoa_deg = mix(14.8, 12.8, t)
    return x_lead, chord, z_lower, aoa_deg


def _airfoil_ring(x_lead: float, chord: float, y: float, z_lower: float, aoa_deg: float) -> List[Vector]:
    """Generate an inverted-camber automotive downforce airfoil ring (20 verts) at span station Y."""
    # Inverted NACA-style high-downforce profile: rounded nose, concave high-suction underside, slight top Gurney
    aoa = math.radians(aoa_deg)
    ca, sa = math.cos(aoa), math.sin(aoa)
    n_side = 10
    pts_2d: List[tuple[float, float]] = []
    # Upper surface: leading (u=0) -> trailing (u=1)
    for i in range(n_side):
        u = 0.5 * (1.0 - math.cos(math.pi * i / (n_side - 1)))  # cosine spacing for crisp nose!
        # Inverted camber: negative camber line bends UP at trailing edge for downforce
        yc = -0.055 * (4.0 * u * (1.0 - u)) * chord
        yt = 0.068 * chord * (
            2.969 * math.sqrt(max(0.0, u))
            - 1.260 * u
            - 3.516 * u * u
            + 2.843 * u ** 3
            - 1.015 * u ** 4
        )
        # Subtle Gurney lip tick at very trailing edge
        gurney = 0.009 * ease(0.90, 1.0, u)
        pts_2d.append((u * chord, yc + yt + gurney))
    # Lower surface: trailing (u=1) -> leading (u=0)
    for i in range(n_side - 2, 0, -1):
        u = 0.5 * (1.0 - math.cos(math.pi * i / (n_side - 1)))
        yc = -0.055 * (4.0 * u * (1.0 - u)) * chord
        yt = 0.068 * chord * (
            2.969 * math.sqrt(max(0.0, u))
            - 1.260 * u
            - 3.516 * u * u
            + 2.843 * u ** 3
            - 1.015 * u ** 4
        )
        pts_2d.append((u * chord, yc - yt))

    # Transform to world: +u goes AFT (-X), positive aoa lifts trailing edge UP (+Z)
    ring: List[Vector] = []
    for px, pz in pts_2d:
        rx = px * ca - pz * sa
        rz = px * sa + pz * ca
        ring.append(Vector((x_lead - rx, y, z_lower + 0.028 + rz)))
    return ring


def _build_ztk_wing(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    piv = pivots["Pivot_ZTK_Wing"]
    mat_cf = [mats["Mat_Carbon_Twill_2x2"]]

    # === A. ZR1X_Wing_Mainplane ===
    bm_w = bmesh.new()
    ys = [-0.930 + 1.860 * i / 36.0 for i in range(37)]
    sections = []
    for y in ys:
        xl, ch, zl, aoa = _wing_section_params(abs(y))
        sections.append(_airfoil_ring(xl, ch, y, zl, aoa))
    bm_add_closed_loft(bm_w, sections, mat_index=0, cap_start=True, cap_end=True, smooth=True)
    finalize_bmesh("ZR1X_Wing_Mainplane", bm_w, mat_cf, piv, auto_smooth_deg=44.0, uv_scale=6.0)

    # === B. ZR1X_Wing_Stanchion_L / R (Curved swept aerodynamic carbon stanchions!) ===
    # Matches carbon-fiber-high-wing.jpg & 03-rear-three-quarter.jpg!
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm_st = bmesh.new()
        mat_st = [mats["Mat_Carbon_Twill_2x2"], mats["Mat_Black_Trim_Gloss"]]
        st_sec = []
        y_st = side * 0.375
        for k in range(12):
            tk = k / 11.0
            z = mix(0.930, 1.132, tk)
            # Sweeps gracefully aft in a curved arc from deck plinth (-2.04..-2.14) to wing underside (-2.10..-2.31)
            x_f = mix(-2.035, -2.095, tk ** 1.35) - 0.032 * math.sin(tk * math.pi)
            x_b = mix(-2.145, -2.310, tk ** 0.85) - 0.025 * math.sin(tk * math.pi)
            half_t = mix(0.028, 0.017, ease(0.0, 0.45, tk)) + 0.008 * ease(0.80, 1.0, tk)
            y_c = y_st + side * 0.012 * math.sin(tk * math.pi * 0.7)
            # Aerodynamic teardrop airfoil cross-section
            mx = 0.5 * (x_f + x_b)
            hx = 0.5 * (x_f - x_b)
            st_sec.append([
                Vector((x_f, y_c, z)),
                Vector((mx + hx * 0.35, y_c + half_t, z)),
                Vector((mx - hx * 0.35, y_c + half_t * 0.85, z)),
                Vector((x_b, y_c + half_t * 0.25, z)),
                Vector((x_b, y_c - half_t * 0.25, z)),
                Vector((mx - hx * 0.35, y_c - half_t * 0.85, z)),
                Vector((mx + hx * 0.35, y_c - half_t, z)),
            ])
        bm_add_closed_loft(bm_st, st_sec, mat_index=0, cap_start=True, cap_end=True, smooth=True)

        # Clean low-profile gloss-black deck mounting plinth base
        bm_add_box(bm_st, (-2.090, y_st, 0.935), (0.145, 0.068, 0.016), mat_index=1, bevel=0.006)
        finalize_bmesh(f"ZR1X_Wing_Stanchion_{sfx}", bm_st, mat_st, piv, auto_smooth_deg=38.0, uv_scale=6.0)

        # === C. ZR1X_Wing_Strake_L / R (Crisp dorsal carbon vortex strake fins aligned w/ stanchions!) ===
        # Look at carbon-fiber-high-wing.jpg and 05-top-view.jpg!
        bm_sk = bmesh.new()
        xl, ch, zl, aoa = _wing_section_params(0.380)
        y_sk = side * 0.380
        sk_sec = []
        for k in range(8):
            tk = k / 7.0
            x = mix(xl - 0.015, xl - ch + 0.015, tk)
            # Upper wing surface height along chord
            z_base = zl + 0.032 + (xl - x) * math.tan(math.radians(aoa))
            # Swept triangular shark-fin dorsal strake peaking cleanly toward rear
            h_fin = 0.038 * (math.sin(tk * math.pi * 0.82) ** 0.7) * (0.25 + 0.75 * tk)
            ht = mix(0.008, 0.004, tk)
            sk_sec.append([
                Vector((x, y_sk - ht, z_base - 0.004)),
                Vector((x, y_sk + ht, z_base - 0.004)),
                Vector((x, y_sk + ht * 0.4, z_base + h_fin)),
                Vector((x, y_sk - ht * 0.4, z_base + h_fin)),
            ])
        bm_add_closed_loft(bm_sk, sk_sec, mat_index=0, cap_start=True, cap_end=True, smooth=True)
        finalize_bmesh(f"ZR1X_Wing_Strake_{sfx}", bm_sk, mat_cf, piv, auto_smooth_deg=35.0, uv_scale=6.0)

        # === D. ZR1X_Wing_Endplate_L / R (Sleek swept upturned outward-flared carbon endplates, H ~ 1.286 m!) ===
        bm_ep = bmesh.new()
        ep_grid: List[List[Vector]] = []
        for iz in range(14):
            tz = iz / 13.0
            z = mix(1.092, 1.286, tz)
            y_ep = side * (0.928 + 0.052 * (tz ** 2.30))
            # Sleek C8 ZTK swept profile: rounded forward bottom nose curving smoothly aft to a crisp top trailing peak!
            x_f = mix(-1.815, -2.075, tz ** 1.18) + 0.018 * math.sin(tz * math.pi)
            x_b = mix(-2.135, -2.238, tz ** 0.95)
            row = [Vector((mix(x_f, x_b, ix / 7.0), y_ep, z)) for ix in range(8)]
            ep_grid.append(row)
        bm_add_thick_grid(bm_ep, ep_grid, thickness=0.009, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, side, 0)))
        finalize_bmesh(f"ZR1X_Wing_Endplate_{sfx}", bm_ep, mat_cf, piv, auto_smooth_deg=38.0, uv_scale=6.0)


# ---------------------------------------------------------------------------
# 2. Front Carbon Splitter & Front Dive Planes (Canards)
# ---------------------------------------------------------------------------

def _build_front_aero(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    mat_cf = [mats["Mat_Carbon_Twill_2x2"], mats["Mat_Black_Trim_Satin"]]

    # === A. ZR1X_Front_Splitter (Extended ZTK Carbon Splitter w/ stepped center bridge & end winglets!) ===
    # Exact match to 01-front-three-quarter.jpg, 029.png, 006.png:
    # Leading tip X = +2.455 (gives exact L = 4.860 m with wing trail -2.405!)
    bm_sp = bmesh.new()
    sp_grid: List[List[Vector]] = []
    ny = 33
    nx = 8
    for ix in range(nx):
        tx = ix / (nx - 1)  # 0 = rear tucked edge under bumper, 1 = forward splitter lip
        row = []
        for iy in range(ny):
            s = mix(-1.0, 1.0, iy / (ny - 1))
            a = abs(s)
            y = s * 0.995
            # Planform curve: sharp forward nose tip (2.455) curving smoothly around outer corners to (2.055)
            x_lead = 2.455 - 0.395 * (a ** 1.55)
            x_rear = 2.180 - 0.455 * (a ** 1.45)
            x = mix(x_rear, x_lead, tx)
            # Signature ZR1X central stepped arch: raised center Z=0.148, dipping smoothly to Z=0.118 outboard (Z_min=0.106)!
            z_step = mix(0.148, 0.118, ease(0.32, 0.56, a))
            # Subtle upward bevel at very leading edge + flat aero tray underneath
            z = z_step + 0.008 * ease(0.75, 1.0, tx) * (1.0 - 0.5 * a)
            row.append(Vector((x, y, z)))
        sp_grid.append(row)
    bm_add_thick_grid(bm_sp, sp_grid, thickness=0.012, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 0, 1)))

    # Sculpted upturned splitter outer end-winglets wrapping back cleanly to the front wheel arch!
    for side in (-1.0, 1.0):
        wl_grid = []
        for ix in range(10):
            tx = ix / 9.0
            x = mix(1.725, 2.065, tx)
            # Rises in a clean curved vertical aero fin at outer corner (Z=0.105..0.220)
            h_fin = mix(0.115, 0.032, tx ** 1.2)
            wl_grid.append([
                Vector((x, side * (0.985 + 0.012 * (1.0 - tx)), 0.105)),
                Vector((x, side * (0.992 + 0.012 * (1.0 - tx)), 0.105 + h_fin * 0.55)),
                Vector((x, side * (0.982 + 0.008 * (1.0 - tx)), 0.105 + h_fin)),
            ])
        bm_add_thick_grid(bm_sp, wl_grid, thickness=0.012, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, side, 0)))

    finalize_bmesh("ZR1X_Front_Splitter", bm_sp, mat_cf, body_piv, auto_smooth_deg=36.0, uv_scale=6.5)

    # === B. ZR1X_Front_DivePlane_L / R (Swept Carbon Front Canards / Dive Planes!) ===
    # Matches 01-front-three-quarter.jpg, 029.png, 06-wheel-and-side-inlet.jpg!
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm_dp = bmesh.new()
        dp_grid = []
        for ix in range(12):
            tx = ix / 11.0  # 0 = aft high tip near front arch, 1 = forward lower root near splitter corner
            x = mix(1.755, 2.035, tx)
            z = mix(0.328, 0.192, tx ** 0.92)
            # Inboard edge hugs outer painted bumper cheek cleanly; outboard edge flares out to Y=1.022!
            y_in = flank_y(min(x, 1.97), max(z, 0.22), include_intake_recess=False) - 0.008
            w_out = mix(0.056, 0.068, math.sin(tx * math.pi) ** 0.65)
            row = []
            for ik in range(5):
                fk = ik / 4.0
                y = side * (y_in + w_out * fk)
                # Subtle upturned outer lip tip
                z_k = z + 0.014 * (fk ** 2.2)
                row.append(Vector((x, y, z_k)))
            dp_grid.append(row)
        bm_add_thick_grid(bm_dp, dp_grid, thickness=0.009, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, side * 0.4, 1)))
        finalize_bmesh(f"ZR1X_Front_DivePlane_{sfx}", bm_dp, [mats["Mat_Carbon_Twill_2x2"]], body_piv, auto_smooth_deg=35.0, uv_scale=7.0)


# ---------------------------------------------------------------------------
# 3. Carbon Side Skirts (CFV) — ZERO Protruding Underbody Track Strakes!
# ---------------------------------------------------------------------------

def _build_side_skirts(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm = bmesh.new()
        # Clean contoured carbon side skirt hugging rocker sill from X=+0.975 back to X=-0.88
        # Matches 006.png, 02-front-side-view.jpg, 06-wheel-and-side-inlet.jpg — NO hanging track strakes!
        sk_grid = []
        for ix in range(24):
            tx = ix / 23.0
            x = mix(-0.880, 0.975, tx)
            z0 = body_sill_z(x) - 0.003
            y_base = flank_y(x, z0 + 0.025, include_intake_recess=False)
            # Sleek outboard carbon blade flange (~36 mm wider in mid-rocker, tapering cleanly at ends)
            ext = 0.038 * (0.28 + 0.72 * math.sin(tx * math.pi) ** 0.45)
            # Subtle upward sculpted lip along rocker crease (never drops below Z=0.138!)
            sk_grid.append([
                Vector((x, side * (y_base - 0.030), z0)),
                Vector((x, side * (y_base + ext), z0 + 0.004)),
                Vector((x, side * (y_base + ext * 0.92), z0 + 0.024)),
                Vector((x, side * (y_base - 0.002), z0 + 0.044)),
            ])
        bm_add_thick_grid(bm, sk_grid, thickness=0.009, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, side, 0.4)))
        finalize_bmesh(
            f"ZR1X_Side_Skirt_{sfx}", bm,
            [mats["Mat_Carbon_Twill_2x2"], mats["Mat_Black_Trim_Satin"]],
            body_piv, auto_smooth_deg=38.0, uv_scale=6.5,
        )


# ---------------------------------------------------------------------------
# 4. Sculpted Carbon Wishbone Side Intake (Quarter Boomerang + Door Spear)
# ---------------------------------------------------------------------------

def _build_wishbone_intakes(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    mat_wb = [mats["Mat_Carbon_Twill_2x2"], mats["Mat_Black_Trim_Gloss"], mats["Mat_Dark_Mesh"]]

    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        # === A. ZR1X_Side_Wishbone_L / R (Bold body-conforming 2x2 carbon boomerang matching Spexx 034!) ===
        bm = bmesh.new()

        # 1) Bold upper horizontal-swept glossy carbon quarter boomerang blade (X = -0.312 .. -0.975)
        # Hugs flank_y tightly (+7 mm max) with smooth sculptural airfoil bevel — zero spiky gaps!
        up_sec = []
        for k in range(16):
            tk = k / 15.0
            x = mix(-0.312, -0.975, tk)
            z_top = mix(0.768, 0.772, tk) + 0.008 * math.sin(tk * math.pi)
            # Bold ~98 mm height at mouth, gracefully tapering to crisp sleek rounded tip at -0.975
            h_arm = mix(0.098, 0.016, tk ** 1.45) + 0.018 * math.sin(tk * math.pi)
            z_bot = z_top - h_arm
            y_surf = flank_y(x, 0.72, include_intake_recess=False)
            y_out = y_surf + mix(0.008, 0.003, tk)
            y_in = y_surf - mix(0.055, 0.016, tk)
            up_sec.append([
                Vector((x, side * y_in, z_top)),
                Vector((x, side * (y_out - 0.004), z_top)),
                Vector((x, side * (y_out + 0.004), mix(z_bot, z_top, 0.50))),
                Vector((x, side * (y_out - 0.004), z_bot)),
                Vector((x, side * y_in, z_bot)),
            ])
        bm_add_closed_loft(bm, up_sec, mat_index=0, cap_start=True, cap_end=True)

        # 2) Swept vertical boomerang intake lip descending smoothly along rear-quarter V-throat (Z=0.73 -> 0.27)
        lo_sec = []
        for k in range(16):
            tk = k / 15.0
            z = mix(0.725, 0.265, tk)
            x_lead = mix(-0.318, -0.565, tk ** 1.12) - 0.036 * math.sin(tk * math.pi)
            w_x = mix(0.082, 0.018, tk ** 1.25)
            y_surf = flank_y(x_lead - 0.03, z, include_intake_recess=False)
            y_out = y_surf + mix(0.006, 0.002, tk)
            y_in = y_surf - mix(0.072, 0.020, tk)
            lo_sec.append([
                Vector((x_lead, side * (y_out - 0.006), z)),
                Vector((x_lead - w_x * 0.40, side * (y_out + 0.003), z)),
                Vector((x_lead - w_x, side * (y_out - 0.005), z)),
                Vector((x_lead - w_x, side * y_in, z)),
                Vector((x_lead - w_x * 0.15, side * y_in, z)),
            ])
        bm_add_closed_loft(bm, lo_sec, mat_index=0, cap_start=True, cap_end=True)

        # 3) Subtle dark recessed carbon slot nestled strictly INSIDE the upper boomerang trailing pocket
        slot_sec = []
        for k in range(8):
            tk = k / 7.0
            x = mix(-0.56, -0.89, tk)
            y_s = flank_y(x, 0.72, include_intake_recess=False) + 0.001
            h_s = mix(0.034, 0.008, tk)
            slot_sec.append([
                Vector((x, side * (y_s - 0.014), 0.735 + h_s * 0.5)),
                Vector((x, side * (y_s + 0.004), 0.735 + h_s * 0.5)),
                Vector((x, side * (y_s + 0.004), 0.735 - h_s * 0.5)),
                Vector((x, side * (y_s - 0.014), 0.735 - h_s * 0.5)),
            ])
        bm_add_closed_loft(bm, slot_sec, mat_index=2, cap_start=True, cap_end=True, smooth=False)

        finalize_bmesh(f"ZR1X_Side_Wishbone_{sfx}", bm, mat_wb, body_piv, auto_smooth_deg=38.0, uv_scale=7.0)

        # === B. ZR1X_Side_Wishbone_Door_L / R (Body-hugging leading carbon spear tip mounted on Pivot_Door_L/R!) ===
        door_piv = pivots[f"Pivot_Door_{sfx}"]
        bm_d = bmesh.new()
        sp_sec = []
        for k in range(12):
            tk = k / 11.0
            x = mix(-0.306, 0.025, tk)
            z_top = mix(0.768, 0.808, tk)
            h_sp = mix(0.080, 0.008, tk ** 0.92)
            z_bot = z_top - h_sp
            y_surf = flank_y(x, 0.76, include_intake_recess=False)
            y_out = y_surf + mix(0.009, 0.003, tk)
            y_in = y_surf - mix(0.022, 0.008, tk)
            sp_sec.append([
                Vector((x, side * y_in, z_top)),
                Vector((x, side * (y_out - 0.003), z_top)),
                Vector((x, side * (y_out + 0.003), mix(z_bot, z_top, 0.50))),
                Vector((x, side * (y_out - 0.003), z_bot)),
                Vector((x, side * y_in, z_bot)),
            ])
        bm_add_closed_loft(bm_d, sp_sec, mat_index=0, cap_start=True, cap_end=True)
        finalize_bmesh(f"ZR1X_Side_Wishbone_Door_{sfx}", bm_d, [mats["Mat_Carbon_Twill_2x2"]], door_piv, auto_smooth_deg=36.0, uv_scale=7.5)


# ---------------------------------------------------------------------------
# 5. 3D Hooded Rear-Quarter Upper Air Scoops (ZR1X_Hatch_Scoop_L / R)
# ---------------------------------------------------------------------------

def _build_hatch_scoops(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    mat_sc = [mats["Mat_Carbon_Twill_2x2"], mats["Mat_Dark_Mesh"], mats["Mat_Black_Trim_Satin"]]

    # Bold sculpted 3D hooded carbon-fiber upper rear-quarter air scoops (clearly visible in side & 3/4 views!)
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm = bmesh.new()
        hood_grid: List[List[Vector]] = []
        for ix in range(14):
            tx = ix / 13.0  # 0 = rear closed trailing edge (-1.30), 1 = forward open intake lip (-0.74)
            x = mix(-1.30, -0.74, tx)
            y_center = side * mix(0.725, 0.695, tx)
            hw = mix(0.032, 0.095, math.sin(clamp(tx * 0.86 + 0.14, 0.1, 0.95) * math.pi) ** 0.50)
            z_base = mix(0.956, 0.942, tx)
            # Bold arched carbon cowl hood rising +62 mm proud above quarter shoulder so silhouette reads unmistakably!
            h_arch = 0.064 * (math.sin(clamp(tx, 0.0, 1.0) * math.pi * 0.84) ** 0.65)
            row = []
            for iy in range(9):
                sy = mix(-1.0, 1.0, iy / 8.0)
                y = y_center + sy * hw
                z = z_base + h_arch * (math.cos(sy * math.pi * 0.5) ** 1.05)
                row.append(Vector((x, y, z)))
            hood_grid.append(row)
        bm_add_thick_grid(bm, hood_grid, thickness=0.008, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0, 0, 1)))

        # Carbon surround bezel framing the recessed intake ramp ahead of the hood (X = -0.76 .. -0.60)
        ramp_grid = []
        for ix in range(6):
            tx = ix / 5.0
            x = mix(-0.76, -0.60, tx)
            y_c = side * mix(0.695, 0.678, tx)
            hw = mix(0.088, 0.024, tx ** 1.25)
            z_r = mix(0.922, 0.946, tx)
            ramp_grid.append([Vector((x, y_c + mix(-hw, hw, k / 6.0), z_r)) for k in range(7)])
        bm_add_thick_grid(bm, ramp_grid, thickness=0.006, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0, 0, 1)))

        # Deep open forward intake mouth dark mesh screen!
        bm_add_box(
            bm, (-0.82, side * 0.702, 0.964), (0.022, 0.145, 0.048), mat_index=1, bevel=0.003,
            rot_mat=Euler((0.0, -0.25, 0.0), "XYZ").to_matrix().to_4x4(),
        )
        finalize_bmesh(f"ZR1X_Hatch_Scoop_{sfx}", bm, mat_sc, body_piv, auto_smooth_deg=38.0, uv_scale=7.0)


# ---------------------------------------------------------------------------
# 6. Open 3D Honeycomb Front & Rear Grilles
# ---------------------------------------------------------------------------

def _add_honeycomb_grille(
    bm: bmesh.types.BMesh,
    x_fn,
    y0: float,
    y1: float,
    z0: float,
    z1: float,
    nx_cells: int,
    nz_cells: int,
    bar_mat: int = 0,
    frame_mat: int = 1,
    back_mat: int = 2,
    depth: float = 0.022,
    facing_x: float = 1.0,
) -> None:
    """Build a crisp 3D open-slat + hexagonal-zig-zag grille insert conforming to x_fn(y, z)."""
    # Perimeter frame bars (top, bottom, left, right)
    for is_top in (False, True):
        z = z1 if is_top else z0
        sec = []
        for k in range(7):
            y = mix(y0, y1, k / 6.0)
            x = x_fn(y, z)
            sec.append([
                Vector((x, y, z - 0.007)), Vector((x, y, z + 0.007)),
                Vector((x - facing_x * depth, y, z + 0.007)), Vector((x - facing_x * depth, y, z - 0.007)),
            ])
        bm_add_closed_loft(bm, sec, mat_index=frame_mat, cap_start=True, cap_end=True, smooth=False)

    # Horizontal aerodynamic grille louvers (matches real C8 ZR1X horizontal-hex grilles!)
    for iz in range(1, nz_cells):
        z = mix(z0, z1, iz / float(nz_cells))
        sec = []
        for k in range(9):
            y = mix(y0, y1, k / 8.0)
            x = x_fn(y, z)
            sec.append([
                Vector((x, y, z - 0.0035)), Vector((x, y, z + 0.0035)),
                Vector((x - facing_x * depth * 0.85, y, z + 0.0035)), Vector((x - facing_x * depth * 0.85, y, z - 0.0035)),
            ])
        bm_add_closed_loft(bm, sec, mat_index=bar_mat, cap_start=True, cap_end=True, smooth=False)

    # Angled diagonal honeycomb struts between horizontal bars (true 3D open hex look!)
    for iz in range(nz_cells):
        za = mix(z0, z1, iz / float(nz_cells))
        zb = mix(z0, z1, (iz + 1) / float(nz_cells))
        for iy in range(nx_cells):
            ya = mix(y0, y1, (iy + (0.25 if iz % 2 == 0 else 0.75)) / float(nx_cells))
            yb = mix(y0, y1, clamp((iy + (0.75 if iz % 2 == 0 else 0.25)) / float(nx_cells), 0.0, 1.0))
            xa = x_fn(ya, za)
            xb = x_fn(yb, zb)
            pa = Vector((xa - facing_x * 0.004, ya, za))
            pb = Vector((xb - facing_x * 0.004, yb, zb))
            mid = (pa + pb) * 0.5
            vec = pb - pa
            if vec.length < 1e-4:
                continue
            quat = Vector((0.0, 0.0, 1.0)).rotation_difference(vec.normalized())
            bm_add_box(bm, mid, (depth * 0.72, 0.0055, vec.length), mat_index=bar_mat,
                       rot_mat=quat.to_matrix().to_4x4(), smooth=False)

    # Dark recessed backing screen cleanly behind the open honeycomb bars
    bg = []
    for iz in range(4):
        z = mix(z0, z1, iz / 3.0)
        bg.append([Vector((x_fn(mix(y0, y1, ky / 6.0), z) - facing_x * (depth + 0.012), mix(y0, y1, ky / 6.0), z)) for ky in range(7)])
    bm_add_thick_grid(bm, bg, thickness=0.004, outer_mat=back_mat, inner_mat=back_mat, rim_mat=back_mat, out_hint=Vector((facing_x, 0, 0)))


def _build_grilles(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    mat_g = [mats["Mat_Black_Trim_Satin"], mats["Mat_Black_Trim_Gloss"], mats["Mat_Dark_Mesh"]]

    # === A. ZR1X_Front_Grille_Center (Deeply recessed behind front splitter, bridge & fangs!) ===
    bm_fc = bmesh.new()
    _add_honeycomb_grille(
        bm_fc,
        x_fn=lambda y, z: 2.205 - 0.16 * (y * y) + 0.04 * (z - 0.20),
        y0=-0.40, y1=0.40, z0=0.205, z1=0.382,
        nx_cells=12, nz_cells=5, depth=0.020, facing_x=1.0,
    )
    finalize_bmesh("ZR1X_Front_Grille_Center", bm_fc, mat_g, body_piv, auto_smooth_deg=35.0)

    # === B. ZR1X_Front_Grille_L / R (Deeply recessed tapered outer front radiator bays!) ===
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm_fs = bmesh.new()
        y_lo = 0.485 if side > 0 else -0.805
        y_hi = 0.805 if side > 0 else -0.485
        _add_honeycomb_grille(
            bm_fs,
            x_fn=lambda y, z: 2.132 - 0.35 * ((abs(y) - 0.36) ** 1.35) + 0.03 * (z - 0.22),
            y0=y_lo, y1=y_hi, z0=0.200, z1=0.435,
            nx_cells=8, nz_cells=6, depth=0.018, facing_x=1.0,
        )
        v_sec = []
        for k in range(6):
            y = mix(y_lo, y_hi, k / 5.0)
            x = 2.152 - 0.35 * ((abs(y) - 0.36) ** 1.35)
            z = 0.358 + 0.015 * ((abs(y) - 0.48) / 0.34)
            v_sec.append([
                Vector((x + 0.016, y, z - 0.006)), Vector((x + 0.016, y, z + 0.006)),
                Vector((x - 0.042, y, z + 0.006)), Vector((x - 0.042, y, z - 0.006)),
            ])
        bm_add_closed_loft(bm_fs, v_sec, mat_index=1, cap_start=True, cap_end=True, smooth=False)
        finalize_bmesh(f"ZR1X_Front_Grille_{sfx}", bm_fs, mat_g, body_piv, auto_smooth_deg=35.0)

    # === C. ZR1X_Rear_Fascia_Grille_L / R (Flush recessed curved trapezoidal rear corner vents!) ===
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm_rg = bmesh.new()
        y_lo = 0.465 if side > 0 else -0.825
        y_hi = 0.825 if side > 0 else -0.465
        _add_honeycomb_grille(
            bm_rg,
            # Seated cleanly FLUSH inside the carved rear fascia vent pocket (NOT sticking out like boxes!)
            x_fn=lambda y, z: -2.144 + 0.155 * ((abs(y) / 0.88) ** 2.10),
            y0=y_lo, y1=y_hi, z0=0.562, z1=0.646,
            nx_cells=8, nz_cells=3, depth=0.015, facing_x=-1.0,
        )
        finalize_bmesh(f"ZR1X_Rear_Fascia_Grille_{sfx}", bm_rg, mat_g, body_piv, auto_smooth_deg=35.0)


# ---------------------------------------------------------------------------
# Module Entry Point
# ---------------------------------------------------------------------------

def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Build ZTK wing, front splitter, dive planes, side skirts, wishbones, hatch scoops & grilles."""
    _build_ztk_wing(pivots, mats)
    _build_front_aero(pivots, mats)
    _build_side_skirts(pivots, mats)
    _build_wishbone_intakes(pivots, mats)
    _build_hatch_scoops(pivots, mats)
    _build_grilles(pivots, mats)
