"""Photo-fitted front closure, molded inner pressing and three functional screens.

The Chevrolet studio fit provides the exterior heights and the original uncut
shutline. The 2027 Rydell ZR1X face-on open-hood photo supplies the three
screens, their opaque dividers, perimeter return, latch and fastener positions.
Coordinates here are vehicle metres, before the mesh is moved onto its pivot.
"""
from collections import defaultdict
from math import cos, exp, hypot, pi, sin, sqrt
from pathlib import Path

import bpy
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import delaunay_2d_cdt
from mathutils.kdtree import KDTree


def contained(points, loop):
    """Even/odd inclusion of many XY points in a simple closed contour."""
    x, y = np.asarray(points).T
    inside = np.zeros(len(x), dtype=bool)
    for (ax, ay), (bx, by) in zip(loop, np.roll(loop, -1, axis=0)):
        if abs(ay - by) > 1.0e-10:
            inside ^= ((ay > y) != (by > y)) & (
                x < (bx - ax) * (y - ay) / (by - ay) + ax
            )
    return inside


def borders(mesh):
    # The original folded rim survived the directional lamp socket cut. Its two
    # matching XY coordinates give each vertical edge, including the missing skin.
    adjacent = defaultdict(set)
    source = np.array([tuple(v.co) for v in mesh.vertices])
    rim_z = {}
    painted = []
    fittings = []
    loose = set(range(len(source)))
    for face in mesh.polygons:
        ids = list(face.vertices)
        loose.difference_update(ids)
        if face.material_index in (0, 1):
            painted.append(ids)
        if face.material_index in (4, 6):
            fittings.append((ids, face.material_index))
        if mesh.materials[face.material_index].name != "Black anodized metal":
            continue
        coords = source[ids]
        xy = [tuple(np.round(v[:2], 6)) for v in coords]
        if len(set(xy)) != 2 or np.ptp(coords[:, 2]) < 0.014:
            continue
        a, b = sorted(set(xy))
        adjacent[a].add(b)
        adjacent[b].add(a)
        for key, p in zip(xy, coords):
            rim_z[key] = max(rim_z.get(key, 0), p[2])
    if not adjacent or any(len(v) != 2 for v in adjacent.values()):
        raise ValueError(
            "Front hood folded rim does not contain a complete closed edge"
        )
    first = min(adjacent)
    loop = [first]
    previous = None
    while True:
        choices = sorted(adjacent[loop[-1]] - {previous})
        nxt = choices[0]
        previous = loop[-1]
        if nxt == first:
            break
        loop.append(nxt)
    if len(loop) != len(adjacent):
        raise ValueError("Front hood rim contains a second contour")
    original = np.array(loop)
    top = BVHTree.FromPolygons([Vector(v) for v in source], painted, all_triangles=True)
    support = np.vstack(
        [
            source[sorted(set(i for face in painted for i in face) | loose)],
            [(x, y, rim_z[x, y]) for x, y in loop],
        ]
    )
    tree = KDTree(len(support))
    for i, (x, y, z) in enumerate(support):
        tree.insert((x, y, 0), i)
    tree.balance()

    def height(x, y):
        hit = top.ray_cast(Vector((x, y, 1.1)), Vector((0, 0, -1)))[0]
        if hit is not None:
            return hit.z
        near = tree.find_n((x, y, 0), 8)
        weights = np.array([1 / max(dist, 0.00001) ** 2 for _, _, dist in near])
        weights /= weights.sum()
        return sum(w * support[i, 2] for w, (_, i, _) in zip(weights, near))

    return original, source, painted, fittings, height


def limits(y):
    # Screen edges back-projected onto the hood from the factory face-on photo.
    a = abs(y)
    rear = np.interp(
        a,
        [0, 0.12, 0.26, 0.35, 0.48, 0.505],
        [1.514, 1.513, 1.500, 1.498, 1.487, 1.486],
    )
    front = np.interp(
        a,
        [0, 0.09, 0.20, 0.25, 0.29, 0.33, 0.396, 0.445, 0.481, 0.505],
        [1.802, 1.790, 1.771, 1.756, 1.737, 1.724, 1.687, 1.626, 1.551, 1.498],
    )
    return rear, front


def old_limits(y):
    a = abs(y)
    end = np.clip((a - 0.411) / 0.085, 0, 1) ** 1.65
    return (
        1.522 - 0.55 * a * a + 0.154 * end + 0.015,
        1.962 - 0.55 * a * a - 0.063 * end - 0.013,
    )


def map_x(x, y, to_old):
    # Move both the trough in the surveyed skin and its carbon lip along with
    # the screen. Its rear edge and the leading shutline remain separate creases.
    weight = np.clip((0.56 - abs(y)) / 0.058, 0, 1)
    if weight == 0:
        return x
    original = old_limits(y)
    current = limits(y)
    ends = [1.25, 2.04 - 0.42 * y * y]
    a, b = (current, original) if to_old else (original, current)
    position = np.interp(x, [ends[0], *a, ends[1]], [ends[0], *b, ends[1]])
    return x + weight * (position - x)


def openings():
    def band(u, t, slot):
        center = 0.27 + 0.037 * (1 - t)
        post = 0.021
        lo, hi = (
            (-center + post, center - post)
            if slot == "center"
            else (center + post, 0.501)
        )
        y = lo + (hi - lo) * u
        if slot == "right":
            y = -y
        rear, front = limits(y)
        return (rear + t * (front - rear), y)

    windows = []
    # Rounded corners in a common parametric chart, avoiding pinched edges at
    # the outside ends. All three apertures have real walls and separate wires.
    for slot in ("center", "left", "right"):
        ru = 0.035 if slot == "center" else 0.09
        rt = 0.055
        path = []
        for cu, ct, a0 in [
            (1 - ru, 1 - rt, 0),
            (ru, 1 - rt, 90),
            (ru, rt, 180),
            (1 - ru, rt, 270),
        ]:
            path.extend(
                (cu + ru * cos(a * pi / 180), ct + rt * sin(a * pi / 180))
                for a in np.linspace(a0, a0 + 90, 7)
            )
        curve = []
        for a, b in zip(path, path[1:] + path[:1]):
            count = max(
                1, round(hypot((a[0] - b[0]) * 0.65, (a[1] - b[1]) * 0.38) / 0.009)
            )
            curve.extend(
                band(
                    a[0] + (b[0] - a[0]) * i / count,
                    a[1] + (b[1] - a[1]) * i / count,
                    slot,
                )
                for i in range(count)
            )
        windows.append(np.array(curve))
    return windows


def new_mesh(name, verts, faces, indices, materials):
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    for material in materials:
        mesh.materials.append(material)
    mesh.polygons.foreach_set("material_index", np.asarray(indices, dtype="i"))
    mesh.polygons.foreach_set("use_smooth", np.ones(len(faces), dtype=bool))
    mesh.update()
    return mesh


def build(hood, fixed_pivot, mats):
    orig, source, painted, fittings, height = borders(hood.data)
    windows = openings()
    outer = orig.copy()
    # Native underside and closed nose photos show two shallow returns flanking
    # the central peak. Transfer the narrow strips ahead of this seam to the nose.
    front = orig[:, 0] > 1.80
    notch = np.interp(
        abs(orig[:, 1]),
        [0, 0.060, 0.175, 0.231, 0.35, 0.85],
        [0, 0.010, 0.037, -0.018, 0, 0],
    )
    outer[front, 0] -= notch[front]

    def original_height(x, y):
        return float(height(float(x), float(y)))

    # Independent smooth height fields for the molded underside and Class-A upper
    # face. The optical reconstruction contains small bumps and its socket cut left
    # isolated support points. Neither is stamped into the black inner composite.
    spacing = 0.008
    ax = np.arange(1.02, 2.083, spacing)
    ay = np.arange(-0.833, 0.834, spacing)
    grid = np.array([[original_height(x, y) for y in ay] for x in ax])
    samples = np.arange(-16, 17)
    fields = []
    for sigma in (0.017, 0.045):
        kernel = np.exp(-0.5 * (samples * spacing / sigma) ** 2)
        kernel /= kernel.sum()
        smooth = grid
        for direction in (0, 1):
            smooth = np.apply_along_axis(
                lambda row: np.convolve(
                    np.pad(row, (16, 16), mode="edge"), kernel, "valid"
                ),
                direction,
                smooth,
            )
        fields.append(smooth)

    def field(x, y, which):
        u, v = np.clip((x - ax[0]) / spacing, 0, len(ax) - 1.001), np.clip(
            (y - ay[0]) / spacing, 0, len(ay) - 1.001
        )
        i, j = int(u), int(v)
        u -= i
        v -= j
        arr = fields[which]
        return (1 - u) * ((1 - v) * arr[i, j] + v * arr[i, j + 1]) + u * (
            (1 - v) * arr[i + 1, j] + v * arr[i + 1, j + 1]
        )

    def skin_z(x, y):
        return field(map_x(x, y, True), y, 0)

    topology = [outer, *windows]
    points = []
    edges = []
    for loop in topology:
        start = len(points)
        points.extend(loop.tolist())
        n = len(loop)
        edges.extend((start + i, start + (i + 1) % n) for i in range(n))
    # Keep the surveyed skin vertices and their heights. The triangulation also
    # restores the lamp-projection cutouts inside the intact outer seam.
    pts = np.unique(
        source[sorted({i for f in painted for i in f}), :2].round(5), axis=0
    )
    gx, gy = np.meshgrid(np.arange(1.05, 2.05, 0.014), np.arange(-0.806, 0.807, 0.014))
    pts = np.vstack([pts, np.column_stack([gx.ravel(), gy.ravel()])])
    mask = contained(pts, outer)
    for w in windows:
        mask &= ~contained(pts, w)
    points.extend(pts[mask].tolist())
    uv, _, cells, *_ = delaunay_2d_cdt(
        [Vector(p) for p in points], edges, [], 0, 0.000002
    )
    xy = np.array([tuple(p) for p in uv])
    cells = np.array(cells, dtype=int)
    centers = xy[cells].mean(axis=1)
    keep = contained(centers, outer)
    for w in windows:
        keep &= ~contained(centers, w)
    faces = cells[keep]
    winding = (
        np.cross(xy[faces[:, 1]] - xy[faces[:, 0]], xy[faces[:, 2]] - xy[faces[:, 0]])
        < 0
    )
    faces[winding] = faces[winding][:, [0, 2, 1]]
    # Use the triangulated *actual* outline for the returns. This includes any
    # subdivisions the constraint solver introduced at the original seam.
    directed = np.concatenate([faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]])
    _, idx, mult = np.unique(
        np.sort(directed, axis=1), axis=0, return_index=True, return_counts=True
    )
    boundary = directed[idx[mult == 1]]

    def segment_distance(loop):
        distance = np.full(len(xy), np.inf)
        for a, b in zip(loop, np.roll(loop, -1, axis=0)):
            ab = b - a
            rel = xy - a
            along = np.clip(
                (rel[:, 0] * ab[0] + rel[:, 1] * ab[1]) / max(ab @ ab, 1.0e-12), 0, 1
            )
            distance = np.minimum(
                distance, np.linalg.norm(rel - along[:, None] * ab, axis=1)
            )
        return distance

    distance_outer = segment_distance(outer)
    distance = np.minimum.reduce([distance_outer, *map(segment_distance, windows)])
    z = np.array([skin_z(x, y) for x, y in xy])
    smooth = np.array([field(map_x(x, y, True), y, 1) for x, y in xy])
    towards = np.clip(distance_outer / 0.021, 0, 1)
    orig_z = np.array([original_height(x, y) for x, y in xy])
    z = (1 - towards) * orig_z + towards * z
    base = (1 - towards) * z + towards * np.minimum(smooth, z + 0.006)
    thickness = (
        0.005
        + 0.018 * (1 - np.exp(-distance / 0.023))
        + 0.014 * np.exp(-(((distance - 0.034) / 0.014) ** 2))
    )
    verts = [tuple(p) for p in np.column_stack([xy, z])]
    n = len(verts)
    verts.extend(map(tuple, np.column_stack([xy, base - thickness])))
    polys = list(map(tuple, faces))
    indices = [0] * len(polys)
    polys.extend(map(tuple, faces[:, ::-1] + n))
    indices.extend([1] * len(faces))
    for a, b in boundary:
        polys.append((b, a, a + n, b + n))
        indices.append(1)
    # Retain the original measured carbon leading lip and exterior red blade crowns.
    remap = {}
    for face, finish in fittings:
        sequence = []
        for q in face:
            if q not in remap:
                xx, yy, zz = source[q]
                dest_x = map_x(xx, yy, False)
                # Vanes terminate on the upper pressing within the hood footprint.
                if finish == 6:
                    start = 1.346 - 0.105 * abs(yy)
                    dest_x = max(dest_x, start)
                    surface = skin_z(dest_x, yy)
                    weight = np.clip((dest_x - start) / 0.045, 0, 1)
                    zz = surface + 0.001 + weight * max(0, zz - surface)
                remap[q] = len(verts)
                verts.append((dest_x, yy, zz))
            sequence.append(remap[q])
        polys.append(sequence)
        indices.append(2 if finish == 4 else 0)
    # Hexagonal wire insert. Individual apertures really transmit light and
    # remain visible from either side. A shared outer vertex joins adjacent cells.
    radius = 0.00455
    step = sqrt(3) * radius
    xs = np.arange(1.38, 1.99, 1.5 * radius)
    lattice = np.array(
        [
            (x, (j + 0.5 * (i % 2)) * step)
            for i, x in enumerate(xs)
            for j in range(-66, 67)
        ]
    )
    meets = np.zeros(len(lattice), dtype=bool)
    for loop in windows:
        center = loop.mean(axis=0)
        expanded = center + (loop - center) * [1.07, 1.05]
        meets |= contained(lattice, expanded)
    shared = {}
    wires = [(cos(i * pi / 3), sin(i * pi / 3)) for i in range(6)]
    for x, y in lattice[meets]:
        rings = []
        for scale, depth in [(1.0, 0.0055), (0.85, 0.0055), (0.85, 0.0064)]:
            ring = []
            for dx, dy in wires:
                xx = x + radius * scale * dx
                yy = y + radius * scale * dy
                key = (round(xx, 6), round(yy, 6))
                if scale == 1 and key in shared:
                    vert = shared[key]
                else:
                    vert = len(verts)
                    verts.append((xx, yy, skin_z(xx, yy) - depth))
                    if scale == 1:
                        shared[key] = vert
                ring.append(vert)
            rings.append(ring)
        for a, b in zip(rings, rings[1:]):
            for i in range(6):
                j = (i + 1) % 6
                polys.append((a[i], a[j], b[j], b[i]))
                indices.append(3)

    # Small dark screen retainers and the U-shaped metal striker in the leading
    # return. The open underside photograph identifies both mounting locations.
    inner_surface = BVHTree.FromPolygons(
        [Vector(v) for v in verts[n : 2 * n]], faces.tolist(), all_triangles=True
    )

    def underside(x, y):
        hit = inner_surface.ray_cast(Vector((x, y, 0.3)), Vector((0, 0, 1)))[0]
        if hit is None:
            raise ValueError(f"Hood hardware outside its carrier at {x:.3f}, {y:.3f}")
        return hit.z

    def mounting(x, y, radii, section, finish, count=24, offset=0.0, rotation=0.0):
        # Each backing foot conforms to the molded panel. The turned rubber and
        # steel heads have an independent axial profile and extend below the foot.
        rings = []
        cx, cy = radii
        c = cos(rotation)
        ss = sin(rotation)
        for scale, dz in section:
            ring = []
            for k in range(count):
                angle = 2 * pi * k / count
                dx = scale * cx * cos(angle)
                dy = scale * cy * sin(angle)
                px = x + dx * c - dy * ss
                py = y + dy * c + dx * ss
                ring.append(len(verts))
                verts.append((px, py, underside(px, py) + dz - offset))
            rings.append(ring)
        for a, b in zip(rings, rings[1:]):
            for k in range(count):
                j = (k + 1) % count
                polys.append((a[j], a[k], b[k], b[j]))
                indices.append(finish)
        polys.append(rings[-1][::-1])
        indices.append(finish)

    def rivet(x, y, r=0.006, offset=0.0, finish=3):
        mounting(
            x,
            y,
            (r, r),
            [(0.8, 0.001), (1, -0.0006), (0.83, -0.0028)],
            finish,
            12,
            offset,
        )

    for side in (-1, 1):
        for x, y in [
            (1.544, 0.309),
            (1.687, 0.271),
            (1.827, 0.156),
            (1.481, 0.390),
            (1.492, 0.14),
        ]:
            rivet(x, side * y)
        # Round adjustable bumper and an exposed hex-sided end, on the solid
        # shoulder of the lid. Position and diameter come from the factory view.
        bx = 1.827
        by = side * 0.414
        mounting(
            bx,
            by,
            (0.023, 0.023),
            [(0.78, 0.001), (1, -0.004), (0.97, -0.011), (0.70, -0.015)],
            1,
        )
        mounting(
            bx,
            by,
            (0.012, 0.012),
            [(1, 0.001), (0.96, -0.014), (0.78, -0.016)],
            5,
            6,
            0.014,
        )
        # The two bolted hinge shoes sit just inboard of the cowl-side corners.
        hx = 1.221
        hy = side * 0.701
        angle = -side * 0.39
        mounting(
            hx,
            hy,
            (0.082, 0.030),
            [(0.96, 0.002), (1, -0.004), (0.91, -0.011)],
            3,
            36,
            rotation=angle,
        )
        for along in (-0.048, 0.048):
            rivet(hx + along * cos(angle), hy + along * sin(angle), 0.0105, 0.011, 5)
        # Raised aft pin boss on each hinge shoe, connected to the bolted flange.
        mounting(
            hx - 0.047,
            hy + side * 0.020,
            (0.027, 0.014),
            [(0.97, 0), (1, -0.015), (0.77, -0.031)],
            1,
            24,
            0.008,
        )
    mounting(
        1.936, 0, (0.026, 0.054), [(0.93, 0.001), (1, -0.003), (0.93, -0.006)], 3, 36
    )
    for y in (-0.033, 0.033):
        rivet(1.936, y, 0.008, 0.006, 5)
    # Curved steel bail attached at two points along the lid's longitudinal axis.
    cx = 1.936
    cz = underside(cx, 0) - 0.003
    sections = []
    for angle in np.linspace(0, pi, 21):
        ring = []
        for i in range(10):
            b = 2 * pi * i / 10
            rad = 0.018 + 0.0034 * cos(b)
            ring.append(len(verts))
            verts.append(
                (
                    cx + rad * cos(angle),
                    0.0034 * sin(b),
                    cz - (0.034 + 0.0034 * cos(b)) * sin(angle),
                )
            )
        sections.append(ring)
    for a, b in zip(sections, sections[1:]):
        for i in range(10):
            j = (i + 1) % 10
            polys.append((a[i], a[j], b[j], b[i]))
            indices.append(4)
    old = hood.data
    hood.data = new_mesh(
        "Photo-fitted front lid with molded liner and three mesh screens",
        verts,
        polys,
        indices,
        [
            mats["Mat_Torch_Red_GKZ"],
            mats["Mat_Black_Trim_Satin"],
            old.materials[4],
            mats["Mat_Wheel_CarbonFlash_SOJ"],
            mats["Mat_Steel_Machined"],
            mats["Mat_Aluminum_Brushed"],
        ],
    )
    if not old.users:
        bpy.data.meshes.remove(old)
    # Preserve closed-car surface area on the fixed nose outside the new shutline.
    vertices = []
    quads = []
    for j in range(len(orig)):
        k = (j + 1) % len(orig)
        if (
            np.linalg.norm(orig[j] - outer[j]) + np.linalg.norm(orig[k] - outer[k])
            < 0.00002
        ):
            continue
        row = [outer[j], outer[k], orig[k], orig[j]]
        start = len(vertices)
        for x, y in row:
            vertices.append((x, y, original_height(x, y) - 0.0007))
        ids = [start + i for i in range(4)]
        if np.cross(row[1] - row[0], row[2] - row[0]) < 0:
            ids.reverse()
        quads.append(ids)
    # Restore the two fender shoulders independently of the moving panel. This
    # survey is the original skin inside the erroneous oblique socket cuts,
    # bounded by the measured three-dimensional lens and its sealing strip.
    survey = np.load(Path(__file__).with_name("front-shoulders.npz"))
    first_survey_vertex = len(vertices)
    vertices.extend(map(tuple, survey["v"]))
    quads.extend(map(tuple, survey["f"] + first_survey_vertex))
    nose = bpy.data.objects.new(
        "ZR1X_Body_Frunk_Nose_Return",
        new_mesh(
            "Fixed nose lip along lid shutline",
            vertices,
            quads,
            [0] * len(quads),
            [mats["Mat_Torch_Red_GKZ"]],
        ),
    )
    bpy.context.collection.objects.link(nose)
    nose.parent = fixed_pivot
    from mathutils import Matrix

    nose.data.transform(Matrix.Translation(-fixed_pivot.matrix_world.translation))
    print(
        f"Front lid restored around {len(windows)} screened apertures with {int(meets.sum())} true honeycomb cells"
    )


def seat_headlamp_bucket(mesh):
    """Place the deep reflector housing behind its lens and below the bonnet.

    Its source fitting extruded the tub 198 mm down one photographic camera
    ray. Seen from above, the deep section emerged past the fender and through
    both hood shoulders. Keep the optical front ring, guide and reflector, and
    draw the deeper stations down under the actual opening.
    """
    faces = [
        f
        for f in mesh.polygons
        if mesh.materials[f.material_index].name == "Headlamp graphite cavity"
    ]
    adjacent = defaultdict(set)
    for face in faces:
        ids = list(face.vertices)
        for i, j in zip(ids, ids[1:] + ids[:1]):
            adjacent[i].add(j)
            adjacent[j].add(i)
    unseen = set(adjacent)
    components = []
    while unseen:
        stack = [unseen.pop()]
        component = []
        while stack:
            i = stack.pop()
            component.append(i)
            neighbors = adjacent[i] & unseen
            unseen.difference_update(neighbors)
            stack.extend(neighbors)
        components.append(sorted(component))
    shell, back = sorted(components, key=len)
    front_ids, middle_ids, end_ids = np.array_split(shell, 3)
    if len(front_ids) != 18 or len(middle_ids) != 18 or len(end_ids) != 18:
        raise ValueError("Missing optical rim stations on the fitted front lamp")
    front = np.array([mesh.vertices[i].co[:] for i in front_ids])
    end = np.array([mesh.vertices[i].co[:] for i in end_ids])
    center = front.mean(axis=0)
    target = (front - center) * [0.95, 0.91, 1.0] + center - [0, 0, 0.101]
    for i, p in zip(middle_ids, 0.65 * front + 0.35 * target):
        mesh.vertices[i].co = p
    for i, p in zip(end_ids, target):
        mesh.vertices[i].co = p
    for i in back:
        p = np.asarray(mesh.vertices[i].co[:])
        w = 1 / np.maximum(np.linalg.norm(end - p, axis=1), 0.0001) ** 2
        w /= w.sum()
        mesh.vertices[i].co = p + w @ (target - end)
    mesh.update()
