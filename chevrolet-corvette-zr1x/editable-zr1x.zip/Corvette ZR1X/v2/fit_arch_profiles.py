"""Measure the red wheel opening against the tyre in the two Chevrolet profiles."""
import json
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import median_filter, gaussian_filter1d

BASE=Path(__file__).resolve().parent
frames=json.loads((BASE/'cameras.json').read_text())['frames']
angles=np.linspace(-.36,np.pi+.36,161)
profiles={"angles":angles.round(6).tolist(),"source_frames":["view-05","view-20"]}
for axle,hub,z,outer in [('front',1.3615,.3365,.965),('rear',-1.3615,.353,1.0)]:
    observations=[]
    for index,side in [(5,1),(20,-1)]:
        fid=f'view-{index:02d}'
        photo=np.asarray(Image.open(BASE.parent/'refs_v2/studio_360'/(fid+'.png')).convert('RGBA'),dtype=float)
        cam=frames[fid]['solved']
        eye=np.array(cam['position_m']);look=np.array(cam['target_m'])-eye;look/=np.linalg.norm(look)
        right=np.cross(look,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,look)
        r=np.arange(z-.015,z+.084,.001)
        a=angles[:,None]
        x=hub+r*np.cos(a);height=z+r*np.sin(a)
        points=np.stack([x,height,np.full_like(x,-side*outer)],axis=-1)-eye
        u=np.rint(cam['cx']+cam['fy']*(points@right)/(points@look)).astype(int)
        v=np.rint(cam['cy']-cam['fy']*(points@up)/(points@look)).astype(int)
        pixels=photo[v,u];red=(pixels[:,:,0]-pixels[:,:,1]>38)&(pixels[:,:,0]>75)&(pixels[:,:,3]>245)
        # Enter a continuous painted region, ignoring red glints in the wheel.
        good=red[:,:-3]&red[:,1:-2]&red[:,2:-1]&red[:,3:]
        found=np.where(good.any(axis=1),r[good.argmax(axis=1)],np.nan)
        observations.append(found)
    vals=np.nanmedian(np.array(observations),axis=0);ok=np.isfinite(vals)
    vals=np.interp(angles,angles[ok],vals[ok])
    vals=gaussian_filter1d(median_filter(vals,size=7),2.5)
    profiles[axle]=vals.round(5).tolist()
    print(axle,np.round(vals[::10],3))
(BASE/'arch-profiles.json').write_text(json.dumps(profiles,indent=2)+'\n')
