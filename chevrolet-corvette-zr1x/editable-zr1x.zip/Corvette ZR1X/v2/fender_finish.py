"""Form paint/liner boundaries on the registered Corvette wheel-opening curves."""
from pathlib import Path
import json
import math
import bmesh
import numpy as np
from mathutils import Vector

PROFILES=json.loads(Path(__file__).with_name('arch-profiles.json').read_text())
ANGLES=PROFILES['angles']

def fit_openings(mesh):
    """Split crossing triangles along the measured openings, then form the rolled lip."""
    bm=bmesh.new()
    bm.from_mesh(mesh)
    for name,axle,radius in [('front',1.3615,.3365),('rear',-1.3615,.353)]:
        profile=PROFILES[name]
        field={}
        for v in bm.verts:
            x,y,z=v.co
            r=math.hypot(x-axle,z-radius)
            if abs(r-radius)>.115 or abs(y)<.59 or z<.120:continue
            a=math.atan2(z-radius,x-axle)
            if a<-.6:a+=2*math.pi
            target=float(np.interp(a,ANGLES,profile))
            # Carry the smooth wheelhouse topology to the measured arch without
            # shifting the adjacent lamp, bonnet or rocker seam.
            edge=radius+.018
            w=max(0,1-abs(r-edge)/.094)**2 * min(1,(abs(y)-.59)/.15)
            shift=(target-edge)*w
            v.co.x+=(x-axle)/r*shift
            v.co.z+=(z-radius)/r*shift
            field[v]=r+shift-target
        faces=[f for f in bm.faces if all(v in field for v in f.verts)]
        crossing={}
        for f in faces:
            for edge in f.edges:
                a,b=edge.verts
                if field[a]*field[b]<0:crossing[edge]=(a,b)
        new={}
        for e,(a,b) in crossing.items():
            t=field[a]/(field[a]-field[b])
            _,v=bmesh.utils.edge_split(e,a,t)
            new[v]=True
            field[v]=0.
        split=[]
        for f in faces:
            hits=[v for v in f.verts if v in new]
            if len(hits)==2 and bm.edges.get(hits) is None:
                other,_=bmesh.utils.face_split(f,*hits)
                split.append(other)
        for f in faces+split:
            # These kit faces are the reconstructed painted fenders and their
            # integral dark wheelhouses. Preserve unrelated grille and badge faces.
            old=mesh.materials[f.material_index].name
            if old not in ('Torch Red • reconstructed surface','Studio-fit trim and carbon'):continue
            if sum(field[v] for v in f.verts)>=0:
                f.material_index=mesh.materials.find('Torch Red • reconstructed surface')
            else:
                f.material_index=mesh.materials.find('Studio-fit trim and carbon')
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()

def fair_paint_reflections(mesh):
    """Fair the optical normals along each continuous panel while preserving its hem."""
    paint={i for i,m in enumerate(mesh.materials) if m.name=='Mat_Torch_Red_GKZ'}
    if not paint:return
    nv=len(mesh.vertices);nl=len(mesh.loops)
    vertex=np.empty(nl,'i');mesh.loops.foreach_get('vertex_index',vertex)
    loops=np.empty(nl*3,'f');mesh.corner_normals.foreach_get('vector',loops)
    loops=loops.reshape(-1,3)
    spans=np.array([p.loop_total for p in mesh.polygons]); slots=np.array([p.material_index for p in mesh.polygons])
    painted=np.repeat(np.isin(slots,list(paint)),spans)
    normals=np.zeros((nv,3));np.add.at(normals,vertex[painted],loops[painted])
    def unit(a):return a/np.maximum(np.linalg.norm(a,axis=1,keepdims=True),1e-9)
    base=unit(normals)
    edges=np.empty(len(mesh.edges)*2,'i');mesh.edges.foreach_get('vertices',edges)
    a,b=edges[::2],edges[1::2]
    align=(base[a]*base[b]).sum(1)
    keep=align>.59
    a,b=a[keep],b[keep]
    src=np.r_[a,b];dst=np.r_[b,a]
    weight=np.tile(np.clip((align[keep]-.59)/.35,0,1),2)
    norm=base.copy()
    for i in range(22):
        aggregate=norm.copy()
        for k in range(3):aggregate[:,k]+=np.bincount(dst,weights=weight*norm[src,k],minlength=nv)
        norm=unit(.04*base+.96*unit(aggregate))
    loops[painted]=norm[vertex[painted]]
    mesh.normals_split_custom_set(loops.tolist())

def form_door_pressing(obj):
    """Use the common measured cross-sections on both doors, tapering at seams."""
    mesh=obj.data
    xyz=np.empty((len(mesh.vertices),3),'f')
    mesh.vertices.foreach_get('co',xyz.ravel())
    x=-xyz[:,0];z=xyz[:,2];y=np.abs(xyz[:,1])
    low=.283+.070*(x+.84);height=.352+.003*(x+.84);u=(z-low)/height
    samples=np.load(Path(__file__).with_name('door-pressing.npz'))
    def index(q,grid):
        f=np.clip((q-grid[0])/(grid[1]-grid[0]),0,len(grid)-1.001)
        return f.astype(int),f-f.astype(int)
    ix,tx=index(x,samples['x']);iu,tu=index(u,samples['u'])
    def sample(k):
        a=samples[k]
        return (1-tx)*((1-tu)*a[ix,iu]+tu*a[ix,iu+1])+tx*((1-tu)*a[ix+1,iu]+tu*a[ix+1,iu+1])
    def ease(a,b,v):
        t=np.clip((v-a)/(b-a),0,1)
        return t*t*(3-2*t)
    end=.296+.322*np.clip((z-.282)/.416,-.08,1.14)
    mix=ease(-.91,-.76,x)*ease(.0,.18,end-x)*ease(.19,.27,z)*ease(.84,.71,z)*ease(.77,.84,y)
    sign=np.sign(xyz[:,1]);xyz[:,1]+=sign*mix*(sample('flank')-y)
    mesh.vertices.foreach_set('co',xyz.ravel());mesh.update()
    # The normals are derivatives of this same surface, expressed in the
    # nose-forward master. Use the chain rule as its two press lines incline.
    du=sample('du');dz=du/height;dx=sample('dx')-dz*(.070+.003*u)
    fitted=np.stack([dx,sign,-dz],axis=1)
    fitted/=np.maximum(np.linalg.norm(fitted,axis=1,keepdims=True),1.e-8)
    ids=np.empty(len(mesh.loops),'i');mesh.loops.foreach_get('vertex_index',ids)
    ns=np.empty((len(ids),3),'f');mesh.corner_normals.foreach_get('vector',ns.ravel())
    a=mix[ids,None]
    ns=ns*(1-a)+fitted[ids]*a
    ns/=np.maximum(np.linalg.norm(ns,axis=1,keepdims=True),1.e-8)
    mesh.normals_split_custom_set(ns.tolist())
