"""Fixed front cooling outlet, molded surround and cowl of the ZR1X.

Reference views are Spexx's DSC_3983 and TeamRydell's photo 104, indexed
as detail-frunk-open and detail-hood-open-cooling.
The shroud transitions from the inclined central heat exchanger to the hood
extractor. The hidden transition is fitted to the heat exchanger in this model.
Coordinates are vehicle metres, +X forward.
"""
from math import copysign, cos, exp, pi, sin

import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree

from rig_utils import join_meshes, make_cylinder, make_loft, make_mesh, make_tube


def rounded_outline(half):
    """Fair the mirrored front-to-rear stations around a symmetric closed loop."""
    stations = [Vector(p) for p in half]
    stations += [Vector((x, -y, z)) for x, y, z in half[-2:0:-1]]
    result = []
    count = len(stations)
    for i in range(count):
        before, start, end, after = (stations[(i + k) % count] for k in (-1, 0, 1, 2))
        for step in range(4):
            t = step / 4
            u = 1 - t
            result.append((1 + 2*t)*u*u*start + t*u*u*(end - before)*0.34
                          + (3 - 2*t)*t*t*end + t*t*u*(start - after)*0.34)
    return result


def build(pivots, mats):
    pivot = pivots["Pivot_Drivetrain_Chassis"]
    hood = bpy.data.objects["ZR1X_Front_Hood"]
    bpy.context.view_layer.update()
    hood_geometry = hood.data
    paint = [f.vertices[:] for f in hood_geometry.polygons
             if hood_geometry.materials[f.material_index].name == "Mat_Torch_Red_GKZ"]
    closed_skin = BVHTree.FromPolygons([hood.matrix_world @ v.co for v in hood_geometry.vertices], paint)
    def below_lid(point):
        hit, _, _, _ = closed_skin.ray_cast((point.x, point.y, 1.15), (0, 0, -1))
        if hit is not None:
            point.z = min(point.z, hit.z - .043)
        return point

    plastic = mats["Mat_Black_Trim_Satin"].copy()
    plastic.name = "Mat_Molded_Cooling_Duct"
    bsdf = plastic.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (.029, .032, .036, 1)
    bsdf.inputs["Roughness"].default_value = .52
    rubber = mats["Mat_Rubber_Black"]
    mesh_black = mats["Mat_Dark_Mesh"]

    # Paired landmarks along the outer fender/cowl return, the rounded duct
    # mouth, and the central heat exchanger. Traverse from nose to windshield.
    edge = rounded_outline([
        (2.083, 0, .603), (2.060, .18, .608), (1.992, .34, .614),
        (1.910, .46, .635), (1.769, .55, .653), (1.623, .655, .702),
        (1.467, .727, .748), (1.296, .780, .762), (1.110, .81, .765),
        (1.076, .748, .775), (1.155, .620, .766), (1.196, .41, .755),
        (1.214, .210, .763), (1.214, 0, .765),
    ])
    lip = rounded_outline([
        (1.886, 0, .577), (1.880, .205, .579), (1.862, .316, .591),
        (1.832, .393, .606), (1.781, .436, .617), (1.710, .455, .623),
        (1.638, .468, .621), (1.580, .477, .619), (1.539, .467, .611),
        (1.524, .438, .607), (1.518, .384, .608), (1.536, .290, .609),
        (1.550, .152, .611), (1.556, 0, .612),
    ])
    inlet_stations = [
        (0, .202), (.160, .202), (.247, .202), (.296, .206), (.310, .219),
        (.310, .269), (.310, .324), (.310, .393), (.308, .448),
        (.297, .463), (.270, .466), (.206, .466), (.107, .466), (0, .466),
    ]
    inlet = rounded_outline([(1.945 - .655 * (z - .335), y, z) for y, z in inlet_stations])
    ring_size = len(edge)

    def between(a, b, fraction, height=0):
        return [p.lerp(q, fraction) + Vector((0, 0, height)) for p, q in zip(a, b)]

    # Roll the outer flange under both fenders, form the cowl deck, roll over
    # the weather-seal seat, then run down to the physical radiator face.
    edge = [below_lid(p) for p in edge]
    lip = [below_lid(p) for p in lip]
    flange = [p + Vector((0, 0, -.022)) for p in edge]
    shoulders = []
    for i in range(19):
        row = between(edge, lip, i/18)
        for p in row:
            # The service surround clears both front suspension tower caps.
            radius = ((p.x-1.347)/.102)**2 + ((abs(p.y)-.537)/.098)**2
            if radius < 1.6:
                p.z = max(p.z, .615 + .028*exp(-radius**2))
            below_lid(p)
        shoulders.append(row)
    rings = [flange, *shoulders, between(lip, inlet, .045, .001),
             between(lip, inlet, .25), between(lip, inlet, .70), inlet]
    panels = [(r*ring_size+i, r*ring_size+(i+1)%ring_size,
               (r+1)*ring_size+(i+1)%ring_size, (r+1)*ring_size+i)
              for r in range(len(rings)-1) for i in range(ring_size)]
    verts = [v for ring in rings for v in ring]
    deck = make_mesh("Duct_surround", verts, panels, plastic, pivot)
    solid = deck.modifiers.new("Molded wall", "SOLIDIFY")
    solid.thickness = .003
    solid.offset = -1
    parts = [deck, make_tube("Extractor_outlet_seal", lip, .0065, rubber, pivot,
                             segments=10, cyclic=True)]
    # Two molded dividers separate the broad centre outlet from each side
    # channel. Their broad forward ends merge into the lip ahead of the duct.
    for side in (-1, 1):
        sections = []
        for x, width, height, center_y in [
            (1.518, .021, .604, .314), (1.55, .018, .611, .309),
            (1.62, .013, .586, .302), (1.72, .015, .565, .295),
            (1.78, .020, .565, .289), (1.82, .032, .584, .287),
            (1.86, .043, .589, .285), (1.90, .044, .579, .282),
        ]:
            yz = [(-1, -.125), (-1, -.014), (-.82, -.004), (-.46, 0),
                  (.46, 0), (.82, -.004), (1, -.014), (1, -.125)]
            sections.append([(x, side*center_y+dy*width, height+dz) for dy, dz in yz])
        parts.append(make_loft("Outlet_divider", sections, plastic, pivot, auto_smooth_deg=42))
    # The outlet curls forward into a broad return across the middle channel.
    # Its ends roll into the two divider shoulders, as seen in the frontal photo.
    nose = []
    section = [(1.767,.544),(1.767,.566),(1.778,.589),(1.790,.599),
               (1.824,.601),(1.871,.594),(1.911,.575),(1.923,.566),(1.921,.549)]
    for i in range(35):
        fraction = (i-17)/17
        inset = abs(fraction)**8
        nose.append([(x-.024*fraction*fraction + .035*inset*(1-(x-1.767)/.156),
                      fraction*.347, z-.013*inset)
                     for x,z in section])
    parts.append(make_loft("Central_outlet_front_return", nose, plastic, pivot, auto_smooth_deg=45))
    # Position the cowl grille and service caps directly on the molded deck.
    surface = BVHTree.FromPolygons(verts, panels)
    # Tuck the inboard return of each wheelhouse beneath the service panel.
    # The actual wheel arch and tyre clearance are outboard of this joint.
    for side in ("L", "R"):
        liner = bpy.data.objects["ZR1X_Body_Front_Wheelhouse_" + side]
        inverse = liner.matrix_world.inverted()
        for vertex in liner.data.vertices:
            p = liner.matrix_world @ vertex.co
            if abs(p.y) < .70 and p.z > .59:
                hit, _, _, _ = surface.ray_cast((p.x, p.y, 1), (0, 0, -1))
                if hit is not None and p.z > hit.z-.008:
                    p.z = hit.z-.008
                    vertex.co = inverse @ p
        liner.data.update()
    def on_deck(x, y, h):
        hit, _, _, _ = surface.ray_cast((x, y, 1), (0, 0, -1))
        if hit is None:
            raise ValueError(f"Service trim outside the cooling duct flange at {(x, y)}")
        return Vector((x, y, hit.z+h))

    def service_cover(name, cx, cy, rx, ry, mat):
        ring = []
        for i in range(48):
            a = i*2*pi/48
            u, v = cos(a), sin(a)
            x = cx + rx * copysign(abs(u)**.42, u)
            y = cy + ry * copysign(abs(v)**.42, v)
            ring.append(on_deck(x, y, .002))
        raised = [p + Vector((0, 0, .004)) for p in ring]
        center = on_deck(cx, cy, .006)
        vertices = ring + raised + [center]
        faces = [(i, (i+1)%48, 48+(i+1)%48, 48+i) for i in range(48)]
        faces += [(48+i, 48+(i+1)%48, 96) for i in range(48)]
        parts.append(make_mesh(name, vertices, faces, mat, pivot))

    service_cover("Cowl_air_grille", 1.405, -.207, .038, .147, mesh_black)
    for i in range(6):
        x = 1.375 + i*.012
        rib = [on_deck(x, y, .009) for y in (-.344, -.28, -.207, -.13, -.07)]
        parts.append(make_tube("Cowl_grille_slat", rib, .0023, plastic, pivot, segments=8))
    rear_seal = [on_deck(1.509-.048*(abs(y)/.52)**2, y, .005) for y in
                 [-.52, -.45, -.34, -.20, 0, .20, .34, .45, .52]]
    parts.append(make_tube("Cowl_seal", rear_seal, .005, rubber, pivot, segments=10))
    for x, y, radius in [(1.329, .327, .030), (1.401, .511, .023)]:
        p = on_deck(x, y, .001)
        parts.append(make_cylinder("Service_cap_base", p, p+Vector((0,0,.006)),
                                   radius, radius, rubber, pivot, segments=32))
        parts.append(make_cylinder("Service_cap", p+Vector((0,0,.006)), p+Vector((0,0,.011)),
                                   radius*.77, radius*.77, plastic, pivot, segments=32))

    # The latch receiver is recessed into the fixed forward cross-panel.
    service_cover("Hood_latch_pocket", 1.992, 0, .026, .043, mesh_black)
    latch = [on_deck(1.995, y, .006) for y in (-.027, 0, .027)]
    parts.append(make_tube("Latch_catch", latch, .0035, mats["Mat_Gear_Steel"], pivot, segments=10))
    join_meshes(parts, "ZR1X_Chassis_CoolingDuct", pivot)
