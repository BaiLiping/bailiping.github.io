"""Crystal-clear Fresnel glazing and black ceramic frit surrounds for the 2027 Corvette ZR1X (v2).

Builds:
- ``Pivot_Body_Assembly``:
  - ``ZR1X_Glass_Windshield`` (``Mat_Glass_Windshield`` + ``Mat_Black_Frit`` border & mirror patch)
  - ``ZR1X_Glass_Quarter_L/R`` (``Mat_Glass_Quarter`` + ``Mat_Black_Frit`` border & B-pillar strip)
- ``Pivot_Door_L/R``:
  - ``ZR1X_Glass_Door_L/R`` (frameless coupe drop glass, ``Mat_Glass_Door`` + ``Mat_Black_Frit`` edge)
- ``Pivot_Rear_Hatch``:
  - ``ZR1X_Glass_Hatch_L/R`` (crystal-clear split rear window glass showing blue LT7 plenum beneath,
    ``Mat_Glass_Hatch`` + ``Mat_Black_Frit`` perimeter border)
"""

from __future__ import annotations

import math
from typing import Dict, List

import bmesh
import bpy
from mathutils import Vector

from ext_body import (
    bm_add_quad_grid,
    bm_add_thick_grid,
    clamp,
    finalize_bmesh,
    hatch_aperture_hw,
    hatch_surface_point,
    mix,
    side_window_point,
    windshield_point,
)
from ext_closures import _hatch_window_y_bounds


def _orient_faces_outward(bm: bmesh.types.BMesh, out_dir: Vector) -> None:
    for f in bm.faces:
        if f.normal.dot(out_dir) < 0.0:
            f.normal_flip()


# ---------------------------------------------------------------------------
# 1. Wrap-Around Windshield + Black Ceramic Frit Border
# ---------------------------------------------------------------------------

def _build_windshield(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    bm = bmesh.new()
    # 0=Fresnel Windshield Glass, 1=Black Ceramic Frit border
    mat_list = [mats["Mat_Glass_Windshield"], mats["Mat_Black_Frit"]]

    nt, ns = 16, 25
    ws_grid: List[List[Vector]] = []
    for it in range(nt):
        t = it / (nt - 1)
        ws_grid.append([windshield_point(t, mix(-1.0, 1.0, is_i / (ns - 1))) for is_i in range(ns)])

    faces = bm_add_quad_grid(bm, ws_grid, mat_index=0, flip=False, smooth=True)
    # Mark crisp outer ceramic frit band (bottom cowl strip, side A-pillar edges, upper header + mirror sensor patch!)
    bm.faces.ensure_lookup_table()
    idx = 0
    for r in range(nt - 1):
        t_mid = (r + 0.5) / (nt - 1)
        for c in range(ns - 1):
            s_mid = abs(mix(-1.0, 1.0, (c + 0.5) / (ns - 1)))
            is_frit = (
                t_mid < 0.085
                or t_mid > 0.915
                or s_mid > 0.915
                or (t_mid > 0.78 and s_mid < 0.12)  # Top-center camera / rearview mirror frit housing patch
            )
            if idx < len(faces) and is_frit:
                faces[idx].material_index = 1
            idx += 1

    _orient_faces_outward(bm, Vector((0.55, 0.0, 0.85)))
    finalize_bmesh("ZR1X_Glass_Windshield", bm, mat_list, body_piv, auto_smooth_deg=60.0, uv_scale=2.0)


# ---------------------------------------------------------------------------
# 2. Frameless Door Drop Glass (Pivot_Door_L/R) & Fixed Quarter Glass (Pivot_Body_Assembly)
# ---------------------------------------------------------------------------

def _build_side_glazing(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]

    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        # === A. ZR1X_Glass_Door_L / R (Parented to Pivot_Door_L/R -> swings open & lifts on explode!) ===
        door_piv = pivots[f"Pivot_Door_{sfx}"]
        bm_d = bmesh.new()
        mat_d = [mats["Mat_Glass_Door"], mats["Mat_Black_Frit"]]

        # Spans X = -0.125 (B-pillar seam) forward to X = +0.745 (A-pillar / mirror corner)
        nx, nh = 18, 10
        dg: List[List[Vector]] = []
        for ih in range(nh):
            # Extend slightly below beltline (-0.06 -> 1.0) so glass tucks cleanly into door slot!
            h = mix(-0.06, 0.995, ih / (nh - 1))
            row = []
            for ix in range(nx):
                x = mix(-0.122, 0.745, ix / (nx - 1))
                p = side_window_point(x, clamp(h, 0.0, 1.0), side=side)
                if h < 0.0:
                    p.z += h * 0.25
                row.append(p)
            dg.append(row)

        faces_d = bm_add_quad_grid(bm_d, dg, mat_index=0, flip=(side < 0), smooth=True)
        # Subtle black frit edge along bottom tuck and rear B-pillar edge
        idx = 0
        for r in range(nh - 1):
            for c in range(nx - 1):
                if idx < len(faces_d) and (r == 0 or c == 0 or c == nx - 2):
                    faces_d[idx].material_index = 1
                idx += 1
        _orient_faces_outward(bm_d, Vector((0.0, side, 0.35)))
        finalize_bmesh(f"ZR1X_Glass_Door_{sfx}", bm_d, mat_d, door_piv, auto_smooth_deg=60.0, uv_scale=2.0)

        # === B. ZR1X_Glass_Quarter_L / R (Sleek C8 teardrop fixed rear quarter glass + B-pillar trim) ===
        bm_q = bmesh.new()
        mat_q = [mats["Mat_Glass_Quarter"], mats["Mat_Black_Frit"]]

        nx_q, nh_q = 12, 8
        qg: List[List[Vector]] = []
        for ih in range(nh_q):
            h = ih / (nh_q - 1)
            row = []
            for ix in range(nx_q):
                x = mix(-0.435, -0.122, ix / (nx_q - 1))
                row.append(side_window_point(x, h, side=side))
            qg.append(row)

        faces_q = bm_add_quad_grid(bm_q, qg, mat_index=0, flip=(side < 0), smooth=True)
        # Slim B-pillar divider strip (1 column ~24 mm, not a thick slab!) + crisp perimeter frit
        idx = 0
        for r in range(nh_q - 1):
            for c in range(nx_q - 1):
                if idx < len(faces_q) and (r == 0 or r == nh_q - 2 or c == 0 or c == nx_q - 2):
                    faces_q[idx].material_index = 1
                idx += 1
        _orient_faces_outward(bm_q, Vector((0.0, side, 0.35)))
        finalize_bmesh(f"ZR1X_Glass_Quarter_{sfx}", bm_q, mat_q, body_piv, auto_smooth_deg=60.0, uv_scale=2.0)


# ---------------------------------------------------------------------------
# 3. Crystal-Clear Split Rear Hatch Glass (Pivot_Rear_Hatch)
# ---------------------------------------------------------------------------

def _build_hatch_split_glass(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    hatch_piv = pivots["Pivot_Rear_Hatch"]

    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm = bmesh.new()
        mat_list = [mats["Mat_Glass_Hatch"], mats["Mat_Black_Frit"]]

        nx, ny = 16, 10
        hg: List[List[Vector]] = []
        for ix in range(nx):
            x = mix(-1.515, -0.595, ix / (nx - 1))
            y_in, y_out = _hatch_window_y_bounds(x)
            hw = hatch_aperture_hw(x)
            row = []
            for iy in range(ny):
                fy = iy / (ny - 1)
                y = side * mix(y_in + 0.004, y_out - 0.004, fy)
                p = hatch_surface_point(x, clamp(y / max(0.15, hw), -0.98, 0.98))
                # Seated flush (-3 mm) inside the molded carbon window surround!
                p.z -= 0.003
                row.append(p)
            hg.append(row)

        faces = bm_add_quad_grid(bm, hg, mat_index=0, flip=(side < 0), smooth=True)
        # Subtle thin black frit edge around glass perimeter (keeps huge clear center view of blue LT7 plenum!)
        idx = 0
        for r in range(nx - 1):
            for c in range(ny - 1):
                if idx < len(faces) and (r == 0 or r == nx - 2 or c == 0 or c == ny - 2):
                    faces[idx].material_index = 1
                idx += 1
        _orient_faces_outward(bm, Vector((-0.20, 0.0, 1.0)))
        finalize_bmesh(f"ZR1X_Glass_Hatch_{sfx}", bm, mat_list, hatch_piv, auto_smooth_deg=60.0, uv_scale=2.0)


# ---------------------------------------------------------------------------
# Module Entry Point
# ---------------------------------------------------------------------------

def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Build windshield, door drop glass, quarter glass, and crystal-clear split rear hatch glass."""
    _build_windshield(pivots, mats)
    _build_side_glazing(pivots, mats)
    _build_hatch_split_glass(pivots, mats)
