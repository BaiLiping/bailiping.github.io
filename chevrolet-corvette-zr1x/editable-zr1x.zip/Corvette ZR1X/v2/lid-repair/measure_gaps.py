"""Measure unmeshed shoulder patches within the convex flank of the lid in face-on projection."""
from pathlib import Path
import sys,cv2,numpy as np,json
def gaps(image):
    binary=cv2.imread(str(image),0)>127
    mask=np.uint8(binary)
    ys,xs=np.where(binary)
    hull=cv2.convexHull(np.column_stack((xs,ys)).astype(np.int32))
    interior=np.zeros_like(mask)
    cv2.fillConvexPoly(interior,hull,1)
    # Erode the subpixel rim so a jagged outline cannot count as an interior hole.
    interior=cv2.erode(interior,np.ones((7,7),np.uint8))
    l,r,t,b=xs.min(),xs.max(),ys.min(),ys.max()
    y0,y1=round(t+(b-t)*.24),round(t+(b-t)*.52)
    roi=np.zeros_like(mask);roi[y0:y1,l:round(l+(r-l)*.29)]=1;roi[y0:y1,round(r-(r-l)*.29):r]=1
    absent=np.uint8(~binary)*interior*roi
    result={}
    for side,start,end in [('left',0,round((l+r)/2)),('right',round((l+r)/2),binary.shape[1])]:
        crop=absent[:,start:end]
        distance=cv2.distanceTransform(crop,cv2.DIST_L2,5)
        _,radius,_,center=cv2.minMaxLoc(distance)
        result[side]={'empty_pixels':int(crop.sum()),'largest_empty_diameter_px':round(radius*2,1),'center':[center[0]+start,center[1]]}
    return result
if __name__=='__main__':
    for path in sys.argv[1:]:
        p=Path(path);result={face:gaps(p/(face+'-mask.png')) for face in ['outer','under']}; (p/'shoulder-gap-measurements.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
