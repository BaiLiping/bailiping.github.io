"""Measure the three screened openings at the factory camera. Dimensions in 980×653 pixels."""
from pathlib import Path
import sys,cv2,numpy as np,json
def spans(column):
    i=np.flatnonzero(column)
    if not len(i):return []
    return [[int(a[0]),int(a[-1])] for a in np.split(i,np.where(np.diff(i)>1)[0]+1) if len(a)>9]
def measure_folder(p):
    m=cv2.imread(str(p/'factory-mask.png'),0)
    if m is None:return {}
    hole=(255-m)/255.
    fraction=cv2.blur(hole,(11,11))
    rows=[[490,222,420],[220,288,448],[795,301,447]]
    gaps={}
    for label,(x,t,b) in zip(['centre','left','right'],rows):
        groups=spans(fraction[:,x]>.23)
        candidates=[g for g in groups if g[0]<400 and g[1]>250 and g[1]<510]
        gaps[label]={'x':x,'factory_top':t,'factory_bottom':b,'screen_span': max(candidates,key=lambda g:g[1]-g[0]) if candidates else None}
    groups=spans(fraction[340,:]>.23)
    gaps['centre_width']={'y':340,'factory_left':293,'factory_right':695,
                          'screen_span':next((g for g in groups if g[0]<490<g[1]),None)}
    return gaps
if __name__=='__main__':
    for arg in sys.argv[1:]:
        p=Path(arg);m=measure_folder(p);(p/'screen-bounds.json').write_text(json.dumps(m,indent=2)+'\n');print(m)
