"""Place the reference and two factory-camera renders side by side at a common scale."""
import argparse
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
p=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument("candidate",type=Path)
parser.add_argument("output",type=Path)
args=parser.parse_args()
def font(size):
    for where in ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']:
        if Path(where).exists():return ImageFont.truetype(where,size)
    return ImageFont.load_default()
width,height,gap,margin,bar=610,407,12,16,43
out=Image.new('RGB',(3*width+2*gap+2*margin,height+bar+2*margin),(247,246,242))
draw=ImageDraw.Draw(out)
for index,(label,file) in enumerate([
        ('2027 ZR1X reference',p.parents[1]/'refs_v2/body_details/detail-hood-underside.jpg'),
        ('Previous model',p/'baseline/factory-underside.png'),
        ('Corrected model',args.candidate/'factory-underside.png')]):
    x=margin+index*(width+gap)
    draw.text((x+2,margin),label,font=font(24),fill=(24,25,28))
    im=Image.open(file).convert('RGB').resize((width,height),Image.Resampling.LANCZOS)
    out.paste(im,(x,margin+bar))
out.save(args.output,quality=94,subsampling=0)
