"""Evidence from public or worktree WebGL viewer. Browser plugin unavailable, Chromium via Playwright.
Test flow: reset assembled car, open front trunk, inspect both faces, close, then open engine hatch.
"""
import argparse
import base64
import hashlib
import os
import shutil
import http.server
import json
from pathlib import Path
from functools import partial
from threading import Thread
import cv2
import numpy as np
from playwright.sync_api import sync_playwright

parser=argparse.ArgumentParser()
parser.add_argument("label")
parser.add_argument("--url")
parser.add_argument("--glb")
parser.add_argument("--site",type=Path,default=os.environ.get("ZR1X_SITE"))
parser.add_argument("--factory-only",action="store_true")
parser.add_argument("--closed-only",action="store_true")
args=parser.parse_args()
root=Path(__file__).resolve().parent
output=root/args.label
output.mkdir(exist_ok=True)
if args.url:
    url=args.url
else:
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*values):pass
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=args.site or root.parents[1]/'site_v2'))
    Thread(target=server.serve_forever,daemon=True).start()
    url=f'http://127.0.0.1:{server.server_port}/chevrolet-corvette-zr1x/'
js="""
window.qaPanel=(key)=>state[key];
window.qaArticulation=()=>{
    rootCar.updateMatrixWorld(true);
    const terms=/Wheel_|Tire_|Rotor_CCB|Caliper_Alcon|Wheelhouse|WheelArch|Liner|CoolingDuct|FrunkTub|Fender/;
    const fixed={}, moving={};
    rootCar.traverse(o=>{
        if(!o.isMesh)return;
        const part=meshPart.get(o)||o,k=part.name+'/'+o.name;
        if(terms.test(part.name))fixed[k]=o.matrixWorld.toArray();
        if(part.parent?.name==='Pivot_Front_Hood')moving[k]=o.matrixWorld.toArray();
    });
    return {fixed,moving};
};

window.qaOrbit=(theta,phi,radius)=>{state.targetTheta=theta;state.targetPhi=phi;state.targetRadius=radius;needsRender=true;scheduleFrame()};
window.qaFocus=(x,y,z)=>{FOCUS_EXTERIOR.set(x,y,z);needsRender=true;scheduleFrame()};
window.qaProbe=(list)=>{
  const r=canvas.getBoundingClientRect();
  return list.map(([x,y])=>{
    const ray=new THREE.Raycaster();
    ray.setFromCamera(new THREE.Vector2(2*(x-r.left)/r.width-1,1-2*(y-r.top)/r.height),camera);
    const [h]=ray.intersectObjects(allPickableMeshes,false).filter(h=>h.object.visible);
    return {x,y,part:h&&(meshPart.get(h.object)||h.object).name,material:h?.object.material.name,xyz:h?[h.point.x*.018,-h.point.z*.018,h.point.y*.018].map(v=>+v.toFixed(4)):null};
  });
};
window.qaFace=(panel,face,mask)=>{
    rootCar.updateMatrixWorld(true);
    const pivot=rootCar.getObjectByName(panel);
    const temp=new THREE.Scene(),lo=new THREE.Vector3(Infinity,Infinity,Infinity),hi=new THREE.Vector3(-Infinity,-Infinity,-Infinity),q=new THREE.Vector3();
    const solid=new THREE.MeshStandardMaterial({color:0xffffff,emissive:0xffffff,side:2,toneMapped:false});
    pivot.traverse(o=>{
        if(!o.isMesh)return;
        const geometry=o.geometry;
        const copy=new THREE.Mesh(geometry,mask?solid:o.material);
        copy.matrix.copy(o.matrixWorld);copy.matrixAutoUpdate=false;temp.add(copy);
        const a=geometry.attributes.position;for(let i=0;i<a.count;i++){q.fromBufferAttribute(a,i).applyMatrix4(o.matrixWorld);lo.min(q);hi.max(q); }
    });
    
    const ctr=lo.clone().add(hi).multiplyScalar(.5);
    const extent=panel==='Pivot_Front_Hood'?52:59;
    const aspect=1.28;let c=keyLight.shadow.camera.clone();c.left=-extent*aspect;c.right=extent*aspect;c.top=extent;c.bottom=-extent;c.near=1;c.far=900;c.updateProjectionMatrix();
    const norm=new THREE.Vector3(0,face==='under'?-1:1,0).transformDirection(pivot.matrixWorld);
    const up=new THREE.Vector3(1,0,0).transformDirection(pivot.matrixWorld);
    c.up.copy(up);c.position.copy(ctr).addScaledVector(norm,250);c.lookAt(ctr);c.updateMatrixWorld();
    let w=896,h=700;
    if(face==='factory'){
        const spec=window.factoryLidCamera;w=spec.width;h=spec.height;
        c=new THREE.PerspectiveCamera(spec.fov,w/h,1,900);
        const swizzle=([x,y,z])=>new THREE.Vector3(x,z,-y);
        const pos=swizzle(spec.eye).multiplyScalar(1/.018).sub(pivot.position);
        pos.applyMatrix4(pivot.matrixWorld);
        const dir=swizzle(spec.direction).transformDirection(pivot.matrixWorld);
        c.up.copy(swizzle(spec.up).transformDirection(pivot.matrixWorld));
        c.position.copy(pos);c.lookAt(pos.clone().add(dir));c.updateMatrixWorld();
    }
    if(mask)temp.background=new THREE.Color(0x000000);
    else{
       temp.background=scene.background.clone();temp.environment=scene.environment;temp.environmentIntensity=scene.environmentIntensity;
       scene.traverse(o=>{if(o.isLight){const l=o.clone(false);l.position.setFromMatrixPosition(o.matrixWorld);temp.add(l);}});
    }
    const t=new THREE.WebGLRenderTarget(w,h);
    t.texture.colorSpace=renderer.outputColorSpace;
    const old=renderer.getRenderTarget();renderer.setRenderTarget(t);renderer.render(temp,c);
    const pixels=new Uint8Array(w*h*4);
    renderer.readRenderTargetPixels(t,0,0,w,h,pixels);renderer.setRenderTarget(old);t.dispose();solid.dispose();
    const cv=document.createElement('canvas');cv.width=w;cv.height=h;
    const ctx=cv.getContext('2d'),img=ctx.createImageData(w,h);
    for(let y=0;y<h;y++)img.data.set(pixels.subarray(y*w*4,(y+1)*w*4),(h-y-1)*w*4);
    ctx.putImageData(img,0,0);return cv.toDataURL("image/png").split(',')[1];
};
"""
probe_points=[[248,236],[249,239],[250,243],[484,239],[491,244],[499,247],[511,251],[408,255],[331,277],[563,310],[421,454]]
stats={}
with sync_playwright() as pw:
    br=pw.chromium.launch(executable_path=os.environ.get('CHROME_BIN') or shutil.which('google-chrome'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-angle=gl','--ignore-gpu-blocklist','--enable-webgl'])
    for layout,w,h in [('desktop',1280,800),('phone',390,844)]:
        page=br.new_page(viewport=dict(width=w,height=h),device_scale_factor=1,has_touch=w<500,reduced_motion="reduce")
        errors=[]
        glb_responses=[]
        page.on('response',lambda response: glb_responses.append(response) if '.glb' in response.url else None)
        page.on('pageerror',lambda e:errors.append(str(e)))
        def inject(route):
            res=route.fetch();s=res.text();i=s.rindex('</script>');route.fulfill(response=res,body=s[:i]+js+s[i:])
        if args.glb:page.route("**/*.glb*",lambda route:route.fulfill(path=str(Path(args.glb).resolve()),content_type="model/gltf-binary"))
        page.route(url,inject)
        page.goto(url)
        page.wait_for_function('window.__zr1xModelLoaded && !!window.qaPanel',timeout=90000)
        page.click('[data-command=r]');page.wait_for_timeout(1800)
        if args.closed_only:
            page.evaluate('qaFocus(83,38,0)');page.evaluate('qaOrbit(-.26,.79,186)');page.wait_for_timeout(1900)
            points=[[349,397],[350,408],[352,418],[351,423],[355,433],[357,436],[894,511],[882,517],[877,525],[869,530],[905,499],
                    [368,439],[878,514]]
            result=page.evaluate('list=>qaProbe(list)',points)
            (output/'closed-probes.json').write_text(json.dumps(result,indent=2)+'\n')
            print('Closed material picks',result,flush=True)
            for delta in (-1,1):
                page.evaluate('qaFocus(83,38,0)');page.evaluate('t=>qaOrbit(t,1.16,235)',delta*.54);page.wait_for_timeout(1150)
                page.screenshot(path=str(output/('closed-front-'+str(delta)+'.jpg')),quality=94)
            page.close();break
        closed_pose=page.evaluate('qaArticulation()')
        page.click('#more>summary');page.click('[data-panel=hood]')
        page.wait_for_function("qaPanel('hood')>.999",timeout=20000);page.wait_for_timeout(350)
        page.screenshot(path=str(output/(layout+'-front-open.jpg')),quality=93)
        stats[layout]={'errors':errors,'version':page.locator("link[rel=preload][as=fetch]").first.get_attribute('href'),'open':page.evaluate("qaPanel('hood')")}
        open_pose=page.evaluate('qaArticulation()')
        fixed_changes=[float(np.max(np.abs(np.asarray(v)-open_pose['fixed'][k]))) for k,v in closed_pose['fixed'].items()]
        hinge_changes=[float(np.max(np.abs(np.asarray(v)-open_pose['moving'][k]))) for k,v in closed_pose['moving'].items()]
        stats[layout]['fixed_meshes']=len(fixed_changes)
        stats[layout]['max_fixed_transform_change']=max(fixed_changes)
        stats[layout]['moving_hood_primitives']=sum(d>1e-4 for d in hinge_changes)
        assert max(fixed_changes)<1e-8 and all(d>1e-4 for d in hinge_changes)
        stats[layout]['glb_sha256']=hashlib.sha256(glb_responses[-1].body()).hexdigest()
        if layout=='desktop':
            cam=json.loads((root/'factory-lid-camera.json').read_text())
            page.evaluate('spec=>window.factoryLidCamera=spec',cam)
            for mask in [False,True]:
                v=page.evaluate('mask=>qaFace("Pivot_Front_Hood","factory",mask)',mask)
                (output/('factory-'+('mask' if mask else 'underside')+'.png')).write_bytes(base64.b64decode(v))
            if args.factory_only:
                page.close();break
            stats['probes']=page.evaluate('list=>qaProbe(list)',probe_points)
            for face in ['under','outer']:
                for mask in [True,False]:
                    data=page.evaluate('([face,mask])=>qaFace("Pivot_Front_Hood",face,mask)',[face,mask])
                    target=output/(face+('-mask' if mask else '-shaded')+'.png')
                    target.write_bytes(base64.b64decode(data))
                    if mask:
                        im=cv2.imread(str(target),0)
                        n, labels, sizes, centers=cv2.connectedComponentsWithStats(np.uint8(im<128))
                        holes=[{'area':int(sizes[i,4]),'center':centers[i].round(1).tolist()} for i in range(1,n) if labels[0,0]!=i and sizes[i,4]>=5]
                        stats[face+'_holes']=sorted(holes,key=lambda o:-o['area'])
            for name,theta,phi,radius in [('front',0,1.41,300),('right',.65,1.40,310),('overhead',1.8,.55,310)]:
                page.evaluate('p=>qaOrbit(...p)',[theta,phi,radius]);page.wait_for_timeout(1550)
                page.screenshot(path=str(output/(name+'-open.jpg')),quality=93)
            page.evaluate('qaFocus(67,51,0)');page.evaluate('qaOrbit(-.32,.80,222)');page.wait_for_timeout(1500)
            page.screenshot(path=str(output/'open-cooling-duct.jpg'),quality=94)
        page.keyboard.press('f')
        page.wait_for_function("qaPanel('hood')<.001",timeout=20000)
        stats[layout]['closed']=page.evaluate("qaPanel('hood')")
        if layout=='desktop':
            page.evaluate('qaFocus(83,38,0)');page.evaluate('qaOrbit(-.26,.79,186)');page.wait_for_timeout(1400)
            page.screenshot(path=str(output/'closed-above.jpg'),quality=93)
            page.evaluate('qaFocus(2,36,0)');page.keyboard.press('l');page.wait_for_function("qaPanel('hatch')>.999",timeout=20000)
            page.evaluate('qaOrbit(2.7,1.24,318)');page.wait_for_timeout(1500)
            page.screenshot(path=str(output/'engine-hatch-open.jpg'),quality=92)
            for face in ['under','outer']:
                v=page.evaluate('face=>qaFace("Pivot_Rear_Hatch",face,false)',face)
                (output/('engine-hatch-'+face+'.png')).write_bytes(base64.b64decode(v))
        page.close()
    br.close()
if not args.factory_only and not args.closed_only:(output/'inspection.json').write_text(json.dumps(stats,indent=2)+'\n')
print(json.dumps(stats,indent=2),flush=True)
