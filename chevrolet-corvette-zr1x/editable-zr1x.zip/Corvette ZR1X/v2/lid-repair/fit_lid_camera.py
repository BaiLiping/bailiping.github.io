"""Fit a normal perspective camera to landmarks on the perimeter of the raised lid.
Input positions are vehicle metres with the lid closed. The browser carries this camera on the
hood hinge to preserve the fit at any opening angle. Intermediate camera-local axes use OpenCV.
"""
from pathlib import Path
import json
import cv2
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

p=Path(__file__).resolve().parent
# The paired corners at the rear hinge and centre leading/trailing edges can be
# identified in both the photo-fitted hood export and the straight-on 2027 image.
# Pixel values below refer to the 980 × 653 thumbnail (same full-frame composition).
marks=[
  ('front centre',[2.042,0,.658],[499,14]),
  ('rear centre',[1.355,0,.769],[496,529]),
  ('rear left corner',[1.048,-.760,.809],[32,641]),
  ('rear right corner',[1.048,.760,.809],[959,636]),
]
v=np.array([a[1] for a in marks])
xy=np.array([a[2] for a in marks])
R0=np.array([[0.,1.,0.],[-1.,0.,0.],[0.,0.,1.]])
mid=np.array([1.54,0,.735])
def parts(o):
    rot=Rotation.from_rotvec(o[:3]).as_matrix() @ R0
    origin=mid-rot.T@o[3:6];f=np.exp(o[6])
    pts=(v-origin)@rot.T
    im=pts[:,:2]/pts[:,2:]*f+[490,326.5]
    return rot,origin,f,im
vertices=np.load(p/'ZR1X_Front_Hood.npz')['v']
sides=[]
for sign in [-1,1]:
    arr=[]
    for x in np.linspace(1.06,2.04,72):
        nearby=vertices[np.abs(vertices[:,0]-x)<.010]
        if len(nearby):
            arr.append(nearby[np.argmax(nearby[:,1]*sign)])
    sides.append(np.array(arr))
ref_sides=np.array([[90,196,791],[125,141,845],[150,112,873],[175,96,888],[200,88,895],[250,76,906],[300,65,915],[350,55,924],[400,46,932],[450,38,940],[500,30,947]])
def edge_errors(rot,origin,f):
    errors=[]
    for i,points in enumerate(sides):
        t=(points-origin)@rot.T
        proj=t[:,:2]/t[:,2:]*f+[490,326.5]
        ix=np.argsort(proj[:,1]);proj=proj[ix]
        errors.extend(np.interp(ref_sides[:,0],proj[:,1],proj[:,0])-ref_sides[:,1+i])
    return np.asarray(errors)
def err(o):
    rot,origin,f,im=parts(o)
    # Lens range is a soft prior; the nearly planar panel cannot identify focal length alone.
    return np.r_[((im-xy)*np.array([[3.,4.],[3.,2.],[2.,2.],[2.,2.]])).ravel(),edge_errors(rot,origin,f)*.8,(o[6]-np.log(850))*8, o[1]*25]
init=np.array([0,0,0,0,0,1.34,np.log(850)])
sol=least_squares(err,init,bounds=([-1,-.35,-.15,-.5,-.5,.3,np.log(400)],[1,.35,.15,.5,.5,6,np.log(2000)]),loss='linear')
rot,eye,fx,im=parts(sol.x)
data={'width':980,'height':653,'eye':eye.tolist(),'up':(-rot[1]).tolist(),'direction':rot[2].tolist(),
      'fov':float(np.rad2deg(2*np.arctan(653/(2*fx)))),'rms_px':float(np.sqrt(np.mean(np.sum((im-xy)**2,axis=1)))),
      'landmarks':[{ 'name':m[0], 'xyz':m[1], 'photo':m[2],'projection':q.round(2).tolist()} for m,q in zip(marks,im)],
      'side_rms_px':float(np.sqrt(np.mean(edge_errors(rot,eye,fx)**2))),'photo':'2027-zr1x-factory-open-underside.jpg','configuration':'2027 ZR1X ZTK, photo 112','projection':'pinhole',
      'units':'vehicle metres, front +X left +Y up +Z in closed hood coordinates'}
(p/'factory-lid-camera.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2))
