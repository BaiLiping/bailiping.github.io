"""Sample the top surfaces of the closed, decoded shipping GLB. Run in Blender.
blender -b -P check_duct_clearance.py -- model.glb result.json
"""
import bpy, json,sys
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from pathlib import Path

model,output=map(Path,sys.argv[sys.argv.index('--')+1:])
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(model))
world=bpy.context.evaluated_depsgraph_get()
def top_meshes(name):
    vertices,faces=[],[]
    objects=[o for o in bpy.context.scene.objects if o.name.startswith(name) and o.type=='MESH']
    for obj in objects:
        ev=obj.evaluated_get(world);m=ev.to_mesh()
        offset=len(vertices)
        vertices.extend((obj.matrix_world@v.co)*.018 for v in m.vertices)
        faces.extend(tuple(i+offset for i in poly.vertices) for poly in m.polygons)
        ev.to_mesh_clear()
    if not faces:raise RuntimeError('No faces for '+name)
    return BVHTree.FromPolygons(vertices,faces)

skin=top_meshes('ZR1X_Front_Hood')
duct=top_meshes('ZR1X_Chassis_CoolingDuct')
down=Vector((0,0,-1))
samples,exposed=0,[]
nearest=(float('inf'),None)
for x_mm in range(1040,2050,7):
    for y_mm in range(-805,806,7):
        x,y=x_mm/1000,y_mm/1000
        pos=Vector((x,y,1.3))
        top=skin.ray_cast(pos,down)[0]
        fixed=duct.ray_cast(pos,down)[0]
        if top is None or fixed is None:continue
        diff=(top.z-fixed.z)*1000
        samples+=1
        if diff < nearest[0]: nearest=(diff,(x,y))
        if diff < -.5:exposed.append((round(diff,2),x,y))
result={'sample_spacing_mm':7,'rays_with_both_surfaces':samples,'top_surface_clearance_mm':round(nearest[0],2),'tightest_xy_metres':nearest[1],'duct_protrusions_over_0_5mm':len(exposed),'worst_protrusions':sorted(exposed)[:30]}
output.write_text(json.dumps(result,indent=2)+'\n');print('CLEARANCE',result,flush=True)
