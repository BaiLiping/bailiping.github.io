"""Fair the original photo-reconstructed door surfaces along their two press lines.

The coordinate across both panels is measured relative to the diagonal rocker
and shoulder lines in the registered side views. A fairly long spatial filter
runs along these lines, while a narrow filter preserves their cross-section.
"""
import numpy as np
from scipy.ndimage import gaussian_filter, distance_transform_edt
from pathlib import Path
p=Path(__file__).resolve().parent
d=np.load(p.parent/'body-panels.npz');group=np.isin(d['group'],[list(d['labels']).index(k+' door') for k in ('Left','Right')])
pts=d['v'][np.unique(d['f'][group])]
x,y,z=pts.T
lo=.283+.070*(x+.84);hi=.635+.073*(x+.84);u=(z-lo)/(hi-lo)
gx=np.linspace(-.98,.54,182);gu=np.linspace(-.55,1.67,153)
ix=np.rint((x-gx[0])/(gx[1]-gx[0])).astype(int).clip(0,len(gx)-1)
iu=np.rint((u-gu[0])/(gu[1]-gu[0])).astype(int).clip(0,len(gu)-1)
vals=np.zeros((len(gx),len(gu)));weight=vals.copy()
np.add.at(vals,(ix,iu),np.abs(y));np.add.at(weight,(ix,iu),1)
# The window rail and the intake mouth themselves lie outside the applied patch.
weighted=gaussian_filter(weight,(9,2.8))
surf=gaussian_filter(vals,(9,2.8))/np.maximum(weighted,1.e-7)
nearest=distance_transform_edt(weighted<.001,return_distances=False,return_indices=True)
surf=surf[tuple(nearest)]
sx,su=np.gradient(surf,gx,gu)
np.savez_compressed(p/'door-pressing.npz',x=gx,u=gu,flank=surf.astype('f'),dx=sx.astype('f'),du=su.astype('f'))
