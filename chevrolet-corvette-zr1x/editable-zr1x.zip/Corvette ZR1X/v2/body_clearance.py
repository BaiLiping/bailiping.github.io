"""Photo-based clearance and small aero corrections in assembled Blender metres."""
import json
from pathlib import Path
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

def resolve_tail(obj):
    table=json.loads(Path(__file__).with_name("tail-envelope.json").read_text())
    mesh=obj.data
    v=np.empty(len(mesh.vertices)*3,'f');mesh.vertices.foreach_get('co',v)
    v=v.reshape(-1,3)
    inv=obj.matrix_world.inverted()
    world=np.asarray(obj.matrix_world);world_v=v@world[:3,:3].T+world[:3,3]
    idx=np.where((world_v[:,0]<-1.64)&(world_v[:,2]<.46))[0]
    if not len(idx):return
    points=world_v[idx][:,(0,2,1)].copy()
    points[:,2]*=-1
    corrections=[]
    for obs in table:
        cam=obs['camera'];eye=np.array(cam['position_m']);f=np.array(cam['target_m'])-eye;f/=np.linalg.norm(f)
        right=np.cross(f,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,f)
        rays=points-eye;depth=rays@f;u=cam['cx']+cam['fy']*(rays@right)/depth
        y=cam['cy']-cam['fy']*(rays@up)/depth
        bottom=np.interp(u/3,np.arange(len(obs['bottom'])),obs['bottom'])
        diff=(y-bottom+1.4)*depth/cam['fy']
        corrections.append(np.where((u>=obs['first'])&(u<=obs['last']),diff,0))
    # Allow a single occluded or aliased sample. A part is raised only when at
    # least two camera silhouettes put it outside the photographed body envelope.
    dz=np.clip(np.partition(corrections,-2,axis=0)[-2],0,.125)
    dz*=np.clip((-1.64-world_v[idx,0])/.13,0,1)
    v[idx]+=dz[:,None]*np.asarray(inv.to_3x3()@Vector((0,0,1)))[None,:]
    mesh.vertices.foreach_set('co',v.ravel());mesh.update()

def windshield_clearance(panel, pivots):
    trees=[]
    for name in ('ZR1X_Glass_Windshield','ZR1X_Roof_CarbonPanel','ZR1X_Body_Shell'):
        mesh=panel[name].data
        trees.append(BVHTree.FromPolygons([v.co for v in mesh.vertices],[p.vertices[:] for p in mesh.polygons]))
    for obj in pivots['Pivot_Interior_Cabin'].children:
        if obj.name not in ('ZR1X_Cabin_HeaderTrim','ZR1X_Cabin_Dash'):continue
        inv=obj.matrix_world.inverted()
        for v in obj.data.vertices:
            p=obj.matrix_world @ v.co
            if p.x<.16 or p.x>.95 or p.z<1.02:continue
            hits=[t.ray_cast(Vector((p.x,p.y,1.5)),Vector((0,0,-1)))[0] for t in trees]
            roof=max((h.z for h in hits if h is not None),default=0)
            if roof>1.02 and p.z>roof-.014:
                p.z=roof-.014;v.co=inv@p
