"""Class-A exterior body shell, fascias, jambs, rear diffuser, wipers, and flush camera pod
for the 2027 Chevrolet Corvette ZR1X (v2).

Exports the shared parametric Class-A surface functions and BMesh builders so
``ext_closures.py``, ``ext_aero.py``, ``ext_optics.py``, ``ext_glazing.py``, and
``ext_details.py`` share exact mathematical shutlines with zero gaps or clipping.

Coordinate system: V2 Blender meters (+X forward, +Y left, +Z up, ground Z=0,
mid-wheelbase origin, axles X = +/-1.3615 m).
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Sequence, Tuple

import bmesh
import bpy
from mathutils import Euler, Matrix, Vector

from rig_utils import (
    AXLE_F_X,
    AXLE_R_X,
    TIRE_R_F,
    TIRE_R_R,
    box_project_uv,
    parent_to_pivot,
    pivot_world_pos,
    set_smooth,
)

# ---------------------------------------------------------------------------
# Authoritative Exterior Constants (2027 ZR1X Coupe, V2 meters)
# ---------------------------------------------------------------------------

HALF_W_REAR = 1.012          # W = 2.024 m excl. mirrors (v2_rig_spec.md)
HALF_W_FRONT = 0.988         # Widebody front fender peak
ARCH_F_X = AXLE_F_X          # +1.3615
ARCH_F_Z = TIRE_R_F          # +0.3365
ARCH_F_R = 0.366             # Tight 29.5 mm tire clearance -> top Z = 0.7025

ARCH_R_X = AXLE_R_X          # -1.3615
ARCH_R_Z = TIRE_R_R          # +0.3530
ARCH_R_R = 0.384             # Tight 31.0 mm tire clearance -> top Z = 0.7370

# Panel shutline longitudinal landmarks
NOSE_TIP_X = 2.405
FRONT_BUMPER_SEAM_X = 1.725  # Vertical front bumper-to-fender seam at front arch leading edge
HOOD_FRONT_X = 1.970         # Centerline front hood cutline behind crossed-flags emblem
HOOD_REAR_X = 1.060          # Rear hood cutline at cowl (hinge X = +1.055)
DOOR_FRONT_X = 0.915         # Door front cutline behind front wheel arch
DOOR_REAR_TOP_X = -0.305     # Door rear cutline at beltline / wishbone split
DOOR_REAR_BOT_X = -0.455     # Door rear cutline at lower intake throat
ROOF_FRONT_X = 0.365         # Windshield header / targa front seam
ROOF_REAR_X = -0.415         # Targa rear seam / B-pillar halo
HATCH_FRONT_X = -0.425       # Rear engine hatch front seam (hinge X = -0.375)
HATCH_REAR_X = -1.965        # Rear engine hatch trailing seam ahead of wing stanchions
REAR_BUMPER_SEAM_X = -1.895  # Rear quarter-to-rear-bumper seam behind rear wheel arch
TAIL_X = -2.185              # Rear transom upper plane

# Fuel filler flap center & radius (L quarter only, hinge at (-0.645, +0.950, +0.830))
FUEL_CENTER_X = -0.725
FUEL_CENTER_Z = 0.835
FUEL_RADIUS_X = 0.080
FUEL_RADIUS_Z = 0.072


# ---------------------------------------------------------------------------
# Math / Interpolation Helpers
# ---------------------------------------------------------------------------

def mix(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else (hi if v > hi else v)


def ease(a: float, b: float, v: float) -> float:
    if abs(b - a) < 1e-9:
        return 1.0 if v >= b else 0.0
    t = clamp((v - a) / (b - a), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def interp_table(table: Sequence[Tuple[float, ...]], x: float, col: int = 1) -> float:
    """Monotone-safe Hermite interpolation over a sorted X table (zero overshoot ripples)."""
    n = len(table)
    if x <= table[0][0]:
        return float(table[0][col])
    if x >= table[-1][0]:
        return float(table[-1][col])
    i = 0
    while i < n - 2 and x > table[i + 1][0]:
        i += 1
    x0, y0 = table[i][0], table[i][col]
    x1, y1 = table[i + 1][0], table[i + 1][col]
    dx = max(1e-9, x1 - x0)
    t = (x - x0) / dx

    def slope(idx: int) -> float:
        return (table[idx + 1][col] - table[idx][col]) / max(1e-9, table[idx + 1][0] - table[idx][0])

    s_cur = slope(i)
    if i == 0:
        m0 = s_cur
    else:
        s_prev = slope(i - 1)
        m0 = 0.0 if s_prev * s_cur <= 0 else 2.0 * s_prev * s_cur / (s_prev + s_cur)
    if i == n - 2:
        m1 = s_cur
    else:
        s_next = slope(i + 1)
        m1 = 0.0 if s_cur * s_next <= 0 else 2.0 * s_cur * s_next / (s_cur + s_next)

    t2 = t * t
    t3 = t2 * t
    return float(
        (2 * t3 - 3 * t2 + 1) * y0
        + (t3 - 2 * t2 + t) * dx * m0
        + (-2 * t3 + 3 * t2) * y1
        + (t3 - t2) * dx * m1
    )


def arch_z(x: float, cx: float, cz: float, r: float) -> Optional[float]:
    dx = x - cx
    if abs(dx) >= r:
        return None
    return cz + math.sqrt(max(0.0, r * r - dx * dx))


# ---------------------------------------------------------------------------
# Authoritative Class-A Master Section Curves (2027 ZR1X, V2 Blender meters)
# ---------------------------------------------------------------------------

SILL_Z_TABLE = (
    (-2.18, 0.255),
    (-2.02, 0.215),
    (-1.82, 0.175),
    (-1.68, 0.158),
    (-1.02, 0.148),
    (-0.55, 0.145),
    ( 0.00, 0.144),
    ( 0.65, 0.144),
    ( 1.02, 0.146),
    ( 1.72, 0.168),
    ( 1.98, 0.180),
    ( 2.22, 0.195),
    ( 2.38, 0.220),
)

BELT_Z_TABLE = (
    (-2.18, 0.910),
    (-2.02, 0.938),
    (-1.80, 0.960),
    (-1.55, 0.985),
    (-1.36, 0.992),   # Rear haunch peak
    (-1.10, 0.980),
    (-0.82, 0.952),
    (-0.52, 0.916),
    (-0.30, 0.892),   # Rear of door window sill
    ( 0.05, 0.864),
    ( 0.40, 0.838),
    ( 0.72, 0.822),   # Base of A-pillar / mirror zone
    ( 0.92, 0.828),   # Door-fender seam
    ( 1.15, 0.840),
    ( 1.36, 0.835),   # Front fender peak above front wheel
    ( 1.58, 0.800),
    ( 1.80, 0.742),
    ( 2.00, 0.678),
    ( 2.18, 0.605),
    ( 2.32, 0.545),
    ( 2.41, 0.495),
)

MAX_Y_TABLE = (
    (-2.18, 0.640),
    (-2.10, 0.845),
    (-2.00, 0.935),
    (-1.85, 0.978),
    (-1.65, 1.000),
    (-1.36, 1.012),   # Exact 2.024 m body width
    (-1.10, 1.011),
    (-0.82, 1.004),
    (-0.54, 0.996),
    (-0.32, 0.942),
    (-0.08, 0.918),
    ( 0.25, 0.916),
    ( 0.58, 0.928),
    ( 0.88, 0.955),
    ( 1.12, 0.982),
    ( 1.36, 0.988),   # Widebody front fender
    ( 1.62, 0.982),
    ( 1.82, 0.962),
    ( 1.98, 0.902),
    ( 2.14, 0.745),
    ( 2.28, 0.540),
    ( 2.38, 0.285),
    ( 2.41, 0.080),
)

SHOULDER_Y_TABLE = (
    (-2.18, 0.560),
    (-2.04, 0.820),
    (-1.86, 0.878),
    (-1.62, 0.892),
    (-1.36, 0.896),
    (-1.05, 0.888),
    (-0.74, 0.858),
    (-0.46, 0.806),
    (-0.26, 0.752),
    ( 0.05, 0.750),
    ( 0.38, 0.768),
    ( 0.68, 0.785),
    ( 0.92, 0.818),
    ( 1.18, 0.842),
    ( 1.36, 0.845),
    ( 1.60, 0.825),
    ( 1.82, 0.780),
    ( 2.00, 0.695),
    ( 2.16, 0.540),
    ( 2.30, 0.340),
    ( 2.41, 0.040),
)

CENTERLINE_Z_TABLE = (
    (-2.18, 0.928),
    (-2.04, 0.948),
    (-1.86, 0.962),
    (-1.60, 0.996),
    (-1.35, 1.044),
    (-1.05, 1.102),
    (-0.72, 1.164),
    (-0.42, 1.204),   # Rear edge of targa roof / hatch hinge seam
    (-0.18, 1.228),
    (-0.02, 1.234),   # Roof apex exact 1.234 m
    ( 0.16, 1.226),
    ( 0.365, 1.202),  # Windshield header
    ( 0.56, 1.132),
    ( 0.78, 1.036),
    ( 0.98, 0.936),
    ( 1.15, 0.845),   # Windshield cowl base
    ( 1.22, 0.822),
    ( 1.42, 0.798),
    ( 1.65, 0.752),
    ( 1.86, 0.715),
    ( 1.97, 0.692),
    ( 2.12, 0.638),
    ( 2.26, 0.578),
    ( 2.36, 0.526),
    ( 2.405, 0.495),  # Crisp C8 beak nose tip
)

# Roof-rail outer edge (X, Y_rail, Z_rail) — aligns seamlessly with cant rail and A-pillar!
ROOF_RAIL_TABLE = (
    (-0.56, 0.505, 1.152),
    (-0.42, 0.495, 1.180),
    (-0.24, 0.528, 1.198),
    (-0.04, 0.556, 1.206),
    ( 0.16, 0.574, 1.198),
    ( 0.365, 0.594, 1.168),
    ( 0.52, 0.635, 1.102),
    ( 0.70, 0.688, 1.006),
    ( 0.88, 0.735, 0.910),
    ( 1.04, 0.768, 0.842),
)

# Side window upper opening (X, Y_top, Z_top) — seals 100% FLUSH against cant rail & sweeps
# cleanly down to the iconic C8 teardrop pointed rear quarter window at X = -0.44!
SIDE_WIN_TOP_TABLE = (
    (-0.44, 0.758, 0.978),   # Sharp C8 teardrop quarter-window rear point!
    (-0.34, 0.680, 1.078),
    (-0.22, 0.602, 1.152),
    (-0.08, 0.566, 1.186),
    ( 0.08, 0.568, 1.188),
    ( 0.24, 0.584, 1.174),
    ( 0.38, 0.610, 1.140),
    ( 0.54, 0.656, 1.064),
    ( 0.70, 0.712, 0.968),
    ( 0.86, 0.766, 0.862),
)


def body_sill_z(x: float) -> float:
    return interp_table(SILL_Z_TABLE, x, 1)


def body_belt_z(x: float) -> float:
    return interp_table(BELT_Z_TABLE, x, 1)


def body_max_y(x: float) -> float:
    return interp_table(MAX_Y_TABLE, x, 1)


def body_shoulder_y(x: float) -> float:
    return interp_table(SHOULDER_Y_TABLE, x, 1)


def body_center_z(x: float) -> float:
    return interp_table(CENTERLINE_Z_TABLE, x, 1)


def roof_rail_y(x: float) -> float:
    return interp_table(ROOF_RAIL_TABLE, x, 1)


def roof_rail_z(x: float) -> float:
    return interp_table(ROOF_RAIL_TABLE, x, 2)


def door_rear_cut_x(z: float) -> float:
    """Exact C8 door trailing shutline X(z) following the wishbone intake throat."""
    t_low = ease(0.14, 0.74, z)
    x_low = mix(-0.465, -0.320, t_low ** 0.85)
    t_hi = ease(0.74, 0.90, z)
    return mix(x_low, -0.305, t_hi)


def door_front_cut_x(z: float) -> float:
    """Door leading shutline X(z) right behind front wheel arch."""
    t = ease(0.14, 0.83, z)
    return mix(0.925, 0.885, t)


def flank_y(x: float, z: float, include_intake_recess: bool = True) -> float:
    """Smooth Class-A half-width Y(x, z) of the 2027 ZR1X widebody flank (sill to beltline)."""
    z0 = body_sill_z(x)
    z1 = body_belt_z(x)
    y_max = body_max_y(x)
    y_sh = body_shoulder_y(x)
    t = clamp((z - z0) / max(0.06, z1 - z0), 0.0, 1.0)

    if t < 0.18:
        u = t / 0.18
        y = y_max * (0.918 + 0.082 * math.sin(u * math.pi * 0.5))
    elif t < 0.72:
        u = (t - 0.18) / 0.54
        y = y_max * (1.0 - 0.022 * (u ** 1.7))
    else:
        u = (t - 0.72) / 0.28
        y_mid = y_max * 0.978
        y = mix(y_mid, y_sh, u ** 1.35)

    # C8 sculpted lower-door wedge scallop feeding air into the side wishbone intake
    if -0.52 < x < 0.92:
        sx = ease(0.92, 0.55, x) * ease(-0.52, -0.25, x)
        t_axis = mix(0.30, 0.44, ease(0.85, -0.35, x))
        sz = math.exp(-((t - t_axis) / 0.22) ** 2)
        y -= 0.044 * sx * sz
        t_ridge = mix(0.76, 0.84, ease(0.85, -0.32, x))
        y += math.exp(-((t - t_ridge) / 0.055) ** 2) * 0.015 * sx

    # Deep sculpted side radiator intake recess on rear quarter behind door seam
    if include_intake_recess and -0.92 < x < -0.26:
        x_cut = door_rear_cut_x(z)
        if -0.84 < x < x_cut + 0.05 and 0.21 < z < 0.79:
            rx = ease(-0.84, -0.50, x) * ease(x_cut + 0.05, x_cut - 0.07, x)
            rz = ease(0.21, 0.33, z) * ease(0.79, 0.67, z)
            y -= 0.195 * rx * rz

    df = abs(x - ARCH_F_X)
    dr = abs(x - ARCH_R_X)
    flare_f = math.exp(-(df / 0.34) ** 2) * math.sin(t * math.pi) * 0.014
    flare_r = math.exp(-(dr / 0.38) ** 2) * math.sin(t * math.pi) * 0.016
    return max(0.0, min(HALF_W_REAR, y + flare_f + flare_r))


def hood_aperture_hw(x: float) -> float:
    t = clamp((x - HOOD_REAR_X) / (HOOD_FRONT_X - HOOD_REAR_X), 0.0, 1.0)
    return mix(0.690, 0.390, t ** 1.55)


def hood_aperture_point(x: float, s: float) -> Vector:
    hw = hood_aperture_hw(x)
    y = s * hw
    t_fwd = clamp((x - HOOD_REAR_X) / (HOOD_FRONT_X - HOOD_REAR_X), 0.0, 1.0)
    x_act = x - (0.095 * (t_fwd ** 1.8) * (s * s))
    z_cl = body_center_z(x_act)
    z_edge = body_belt_z(x_act) - 0.008
    z = mix(z_cl, z_edge, (abs(s) ** 1.65))
    crease = 0.008 * math.exp(-((abs(s) - 0.68) / 0.14) ** 2) * (1.0 - 0.4 * t_fwd)
    return Vector((x_act, y, z + crease))


def nose_surface_pt(s: float, t: float) -> Vector:
    """Shared parametric upper nose beak surface (s in [-1, 1], t=0 hood seam -> t=1 front nose lip).

    Used by both ZR1X_Front_Fascia and ZR1X_Badge_FrontFlags so emblem sits 100% flush!
    """
    a = abs(s)
    p_seam = hood_aperture_point(HOOD_FRONT_X, s)
    # Front nose lip spans cleanly across center beak (s=0 -> X=2.405) to inner headlamp corner (|s|=1 -> X=2.14, Y=0.45)
    # Wait: nose cap wraps all the way around to headlamp lower-outer brow (|s|=1 -> Y=0.92, X=1.90)!
    x_lip = NOSE_TIP_X - 0.485 * (a ** 1.72)
    y_lip = s * 0.925
    z_lip = 0.498 + 0.068 * (a ** 1.35)
    p_lip = Vector((x_lip, y_lip, z_lip))

    u = 1.0 - (1.0 - t) ** 1.25
    p = p_seam.lerp(p_lip, u)
    p.z = mix(p_seam.z, p_lip.z, t ** 1.22) + 0.012 * math.sin(t * math.pi) * (1.0 - 0.5 * a)
    p.z += 0.006 * math.exp(-((a) / 0.08) ** 2) * math.sin(t * math.pi * 0.85)
    return p


def windshield_point(t: float, s: float) -> Vector:
    x_cl = mix(1.155, ROOF_FRONT_X, t)
    x = x_cl - mix(0.115, 0.072, t) * (s * s)
    hw = mix(0.758, 0.578, t)
    y = s * hw
    z_cl = mix(0.846, 1.202, t) + 0.014 * math.sin(t * math.pi)
    drop = mix(0.024, 0.032, t)
    z = z_cl - drop * (s * s)
    return Vector((x, y, z))


def roof_surface_point(x: float, s: float) -> Vector:
    t_f = clamp((x - ROOF_REAR_X) / (ROOF_FRONT_X - ROOF_REAR_X), 0.0, 1.0)
    x_wrap = mix(-0.040, -0.072, t_f)
    x_act = x + x_wrap * (s * s)
    hw = mix(0.495, 0.578, t_f)
    y = s * hw
    z_cl = body_center_z(x)
    bubble = 0.005 * math.sin(abs(s) * math.pi) - 0.003 * math.exp(-(s / 0.25) ** 2)
    drop = mix(0.020, 0.028, t_f)
    z = z_cl + bubble - drop * (s * s)
    return Vector((x_act, y, z))


def side_window_point(x: float, h: float, side: float = 1.0) -> Vector:
    zb = body_belt_z(x) + 0.004
    yb = body_shoulder_y(x) - 0.012
    zt = max(zb + 0.006, interp_table(SIDE_WIN_TOP_TABLE, x, 2))
    yt = interp_table(SIDE_WIN_TOP_TABLE, x, 1)
    # Taper window bottom upward cleanly toward teardrop tip (X = -0.30 .. -0.44)
    rear_t = ease(-0.24, -0.44, x)
    zb = mix(zb, zt - 0.004, rear_t ** 1.35)
    yb = mix(yb, yt + 0.004, rear_t ** 1.35)
    camber = 0.014 * math.sin(h * math.pi) * clamp((zt - zb) / 0.22, 0.0, 1.0)
    y = mix(yb, yt, h) + camber
    z = mix(zb, zt, h)
    return Vector((x, side * y, z))


def hatch_aperture_hw(x: float) -> float:
    t = clamp((x - HATCH_REAR_X) / (HATCH_FRONT_X - HATCH_REAR_X), 0.0, 1.0)
    return 0.485 + 0.145 * math.sin(t * math.pi * 0.82) * (0.35 + 0.65 * t)


def hatch_surface_point(x: float, s: float) -> Vector:
    hw = hatch_aperture_hw(x)
    y = s * hw
    z_cl = body_center_z(x)
    t_aft = clamp((HATCH_FRONT_X - x) / (HATCH_FRONT_X - HATCH_REAR_X), 0.0, 1.0)
    drop = mix(0.036, 0.006, t_aft ** 0.85)
    z = z_cl - drop * (s * s)
    return Vector((x, y, z))


# ---------------------------------------------------------------------------
# Clean BMesh Class-A Panel & Solid Geometry Helpers (Shared by ext_*.py)
# ---------------------------------------------------------------------------

def bm_add_quad_grid(
    bm: bmesh.types.BMesh,
    grid: Sequence[Sequence[Vector]],
    mat_index: int = 0,
    flip: bool = False,
    smooth: bool = True,
) -> List[bmesh.types.BMFace]:
    nr = len(grid)
    nc = len(grid[0])
    vgrid = [[bm.verts.new(p) for p in row] for row in grid]
    faces = []
    for r in range(nr - 1):
        for c in range(nc - 1):
            quad = (
                (vgrid[r][c], vgrid[r][c + 1], vgrid[r + 1][c + 1], vgrid[r + 1][c])
                if flip
                else (vgrid[r][c], vgrid[r + 1][c], vgrid[r + 1][c + 1], vgrid[r][c + 1])
            )
            try:
                f = bm.faces.new(quad)
                f.material_index = mat_index
                f.smooth = smooth
                faces.append(f)
            except ValueError:
                pass
    return faces


def _grid_vertex_normals(grid: Sequence[Sequence[Vector]], out_hint: Optional[Vector] = None) -> List[List[Vector]]:
    nr = len(grid)
    nc = len(grid[0])
    norms = [[Vector((0.0, 0.0, 0.0)) for _ in range(nc)] for _ in range(nr)]
    for r in range(nr - 1):
        for c in range(nc - 1):
            p00, p10 = grid[r][c], grid[r + 1][c]
            p11, p01 = grid[r + 1][c + 1], grid[r][c + 1]
            n = (p10 - p00).cross(p01 - p00) + (p11 - p10).cross(p00 - p10)
            if n.length > 1e-12:
                n.normalize()
                norms[r][c] += n
                norms[r + 1][c] += n
                norms[r + 1][c + 1] += n
                norms[r][c + 1] += n
    sign = 1.0
    if out_hint is not None:
        total = Vector((0.0, 0.0, 0.0))
        for r in range(nr):
            for c in range(nc):
                total += norms[r][c]
        if total.dot(out_hint) < 0.0:
            sign = -1.0
    for r in range(nr):
        for c in range(nc):
            v = norms[r][c] * sign
            norms[r][c] = v.normalized() if v.length > 1e-12 else Vector((0.0, 0.0, 1.0))
    return norms


def bm_add_thick_grid(
    bm: bmesh.types.BMesh,
    grid: Sequence[Sequence[Vector]],
    thickness: float = 0.008,
    outer_mat: int = 0,
    inner_mat: Optional[int] = None,
    rim_mat: Optional[int] = None,
    out_hint: Optional[Vector] = None,
    smooth: bool = True,
) -> None:
    if inner_mat is None:
        inner_mat = outer_mat
    if rim_mat is None:
        rim_mat = outer_mat

    nr = len(grid)
    nc = len(grid[0])
    norms = _grid_vertex_normals(grid, out_hint=out_hint)
    p00 = grid[0][0]
    raw_n = (grid[1][0] - p00).cross(grid[0][1] - p00)
    flip_outer = raw_n.dot(norms[0][0]) < 0.0

    outer_v = [[bm.verts.new(grid[r][c]) for c in range(nc)] for r in range(nr)]
    inner_v = [[bm.verts.new(grid[r][c] - norms[r][c] * thickness) for c in range(nc)] for r in range(nr)]

    def _add_f(vs, mi, sm=smooth):
        try:
            f = bm.faces.new(vs)
            f.material_index = mi
            f.smooth = sm
            return f
        except ValueError:
            return None

    for r in range(nr - 1):
        for c in range(nc - 1):
            if flip_outer:
                _add_f((outer_v[r][c], outer_v[r][c + 1], outer_v[r + 1][c + 1], outer_v[r + 1][c]), outer_mat)
                _add_f((inner_v[r][c], inner_v[r + 1][c], inner_v[r + 1][c + 1], inner_v[r][c + 1]), inner_mat)
            else:
                _add_f((outer_v[r][c], outer_v[r + 1][c], outer_v[r + 1][c + 1], outer_v[r][c + 1]), outer_mat)
                _add_f((inner_v[r][c], inner_v[r][c + 1], inner_v[r + 1][c + 1], inner_v[r + 1][c]), inner_mat)

    for c in range(nc - 1):
        q0 = (outer_v[0][c], inner_v[0][c], inner_v[0][c + 1], outer_v[0][c + 1])
        _add_f(q0[::-1] if flip_outer else q0, rim_mat, sm=False)
        q1 = (outer_v[nr - 1][c], outer_v[nr - 1][c + 1], inner_v[nr - 1][c + 1], inner_v[nr - 1][c])
        _add_f(q1[::-1] if flip_outer else q1, rim_mat, sm=False)
    for r in range(nr - 1):
        q2 = (outer_v[r][0], outer_v[r + 1][0], inner_v[r + 1][0], inner_v[r][0])
        _add_f(q2[::-1] if flip_outer else q2, rim_mat, sm=False)
        q3 = (outer_v[r][nc - 1], inner_v[r][nc - 1], inner_v[r + 1][nc - 1], outer_v[r + 1][nc - 1])
        _add_f(q3[::-1] if flip_outer else q3, rim_mat, sm=False)


def bm_add_closed_loft(
    bm: bmesh.types.BMesh,
    sections: Sequence[Sequence[Vector]],
    mat_index: int = 0,
    cap_start: bool = True,
    cap_end: bool = True,
    smooth: bool = True,
) -> None:
    ns = len(sections)
    nr = len(sections[0])
    rings = [[bm.verts.new(Vector(p)) for p in sec] for sec in sections]
    new_faces = []
    for j in range(ns - 1):
        for i in range(nr):
            ni = (i + 1) % nr
            try:
                f = bm.faces.new((rings[j][i], rings[j][ni], rings[j + 1][ni], rings[j + 1][i]))
                f.material_index = mat_index
                f.smooth = smooth
                new_faces.append(f)
            except ValueError:
                pass
    if cap_start and nr >= 3:
        try:
            f = bm.faces.new(list(reversed(rings[0])))
            f.material_index = mat_index
            f.smooth = False
            new_faces.append(f)
        except ValueError:
            pass
    if cap_end and nr >= 3:
        try:
            f = bm.faces.new(rings[-1])
            f.material_index = mat_index
            f.smooth = False
            new_faces.append(f)
        except ValueError:
            pass
    if new_faces:
        bmesh.ops.recalc_face_normals(bm, faces=new_faces)


def bm_add_box(
    bm: bmesh.types.BMesh,
    center: Sequence[float],
    size: Sequence[float],
    mat_index: int = 0,
    bevel: float = 0.0,
    segments: int = 2,
    rot_mat: Optional[Matrix] = None,
    smooth: bool = True,
) -> None:
    ret = bmesh.ops.create_cube(bm, size=1.0)
    verts = ret["verts"]
    bmesh.ops.scale(bm, vec=(size[0], size[1], size[2]), verts=verts)
    if bevel > 0.0:
        edges = list({e for v in verts for e in v.link_edges})
        b_w = min(bevel, 0.42 * min(size))
        if b_w > 1e-5:
            bev = bmesh.ops.bevel(
                bm, geom=edges, offset=b_w, offset_type="OFFSET",
                segments=segments, profile=0.5, affect="EDGES", clamp_overlap=True,
            )
            verts = [v for v in (set(verts) | set(bev["verts"])) if v.is_valid]
    xform = Matrix.Translation(Vector(center))
    if rot_mat is not None:
        xform = xform @ rot_mat
    bmesh.ops.transform(bm, matrix=xform, verts=verts)
    faces = list({f for v in verts for f in v.link_faces})
    for f in faces:
        f.material_index = mat_index
        f.smooth = smooth
    bmesh.ops.recalc_face_normals(bm, faces=faces)


def finalize_bmesh(
    name: str,
    bm: bmesh.types.BMesh,
    materials: Sequence[bpy.types.Material],
    pivot: bpy.types.Object,
    mirror_y: bool = False,
    auto_smooth_deg: Optional[float] = 42.0,
    uv_scale: float = 6.0,
    recalc_normals: bool = False,
) -> bpy.types.Object:
    if mirror_y:
        geom = list(bm.verts) + list(bm.edges) + list(bm.faces)
        ret = bmesh.ops.duplicate(bm, geom=geom)
        for e in ret["geom"]:
            if isinstance(e, bmesh.types.BMVert):
                e.co.y = -e.co.y
        dup_faces = [e for e in ret["geom"] if isinstance(e, bmesh.types.BMFace)]
        bmesh.ops.reverse_faces(bm, faces=dup_faces)

    if recalc_normals and len(bm.faces) > 0:
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    origin = pivot_world_pos(pivot)
    if origin.length_squared > 0.0:
        for v in bm.verts:
            v.co -= origin

    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    for m in materials:
        me.materials.append(m)
    me.update()

    obj = bpy.data.objects.new(name, me)
    parent_to_pivot(obj, pivot, coords_are_world=False)
    set_smooth(obj, auto_smooth_deg=auto_smooth_deg)
    box_project_uv(obj, scale=uv_scale)
    return obj


# ---------------------------------------------------------------------------
# 1. Fixed Widebody Shell (Front Fenders, Rockers, A/C-Pillars, Quarters, Halo)
# ---------------------------------------------------------------------------

def _build_body_shell(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    bm = bmesh.new()
    mat_list = [mats["Mat_Torch_Red_GKZ"], mats["Mat_Black_Trim_Satin"], mats["Mat_Carbon_Twill_2x2"]]

    # --- A. Front Fender (L, mirrored to R): stops CLEANLY at FRONT_BUMPER_SEAM_X = 1.725! ---
    # Headlamp pocket starts cleanly at X = 1.56..1.725 along upper crown — ZERO overhanging flap!
    xs_f = set()
    for i in range(28):
        xs_f.add(mix(0.895, FRONT_BUMPER_SEAM_X, i / 27.0))
    for i in range(37):
        ang = math.pi * i / 36.0
        xs_f.add(ARCH_F_X + ARCH_F_R * math.cos(ang))
    xs_f.update([ARCH_F_X - ARCH_F_R - 0.002, FRONT_BUMPER_SEAM_X])
    xs_f_sorted = sorted(x for x in xs_f if 0.890 <= x <= FRONT_BUMPER_SEAM_X)

    nv = 14
    fender_side: List[List[Vector]] = []
    fender_crown: List[List[Vector]] = []
    for x in xs_f_sorted:
        az = arch_z(x, ARCH_F_X, ARCH_F_Z, ARCH_F_R)
        z_bot = max(body_sill_z(x), az if az is not None else 0.0)
        z_top = body_belt_z(x)
        row = []
        for k in range(nv):
            z = mix(z_bot, z_top, k / (nv - 1))
            y = flank_y(x, z, include_intake_recess=False)
            row.append(Vector((x, y, z)))
        fender_side.append(row)

        p_out = row[-1]
        if x >= HOOD_REAR_X - 0.015:
            p_in = hood_aperture_point(clamp(x, HOOD_REAR_X, HOOD_FRONT_X), 1.0)
            p_in.x = x
            # Gently curve upper fender crown down to meet the swept headlamp upper brow (X > 1.55)
            hl_t = ease(1.54, FRONT_BUMPER_SEAM_X, x)
            strip = []
            for k in range(8):
                f = k / 7.0
                p = p_in.lerp(p_out, f)
                peak = 0.016 * math.sin(f * math.pi) * (1.0 - 0.72 * hl_t)
                # Subtle outer brow tuck right along headlamp upper-rear tip
                p.z += peak - 0.012 * hl_t * ease(0.25, 0.85, f)
                strip.append(p)
            fender_crown.append(strip)
        else:
            t_c = ease(0.895, HOOD_REAR_X, x)
            p_in = Vector((x, mix(0.742, hood_aperture_hw(HOOD_REAR_X), t_c), mix(0.842, body_belt_z(x) - 0.006, t_c)))
            fender_crown.append([
                p_in.lerp(p_out, k / 7.0) + Vector((0.0, 0.0, 0.010 * math.sin(k / 7.0 * math.pi)))
                for k in range(8)
            ])

    bm_add_thick_grid(bm, fender_side, thickness=0.010, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 1, 0)))
    bm_add_thick_grid(bm, fender_crown, thickness=0.010, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 0, 1)))

    # Rolled front wheel arch lip return
    arch_f_grid = []
    for i in range(33):
        ang = math.radians(-8.0 + 196.0 * i / 32.0)
        ax = ARCH_F_X + ARCH_F_R * math.cos(ang)
        az_v = max(body_sill_z(ax), ARCH_F_Z + ARCH_F_R * math.sin(ang))
        ay = flank_y(ax, az_v, include_intake_recess=False)
        arch_f_grid.append([
            Vector((ax, ay, az_v)),
            Vector((ax, ay - 0.016, az_v - 0.002)),
            Vector((ax, ay - 0.036, az_v - 0.006)),
        ])
    bm_add_thick_grid(bm, arch_f_grid, thickness=0.005, outer_mat=0, inner_mat=1, rim_mat=1, out_hint=Vector((0, 0, -1)))

    # --- B. Rocker Sill (slim clean sill directly under door bottom, X = -0.50 .. +0.94) ---
    rocker_grid = []
    for i in range(22):
        x = mix(-0.50, 0.94, i / 21.0)
        z0 = body_sill_z(x)
        y_bot = flank_y(x, z0, include_intake_recess=False)
        y_out = flank_y(x, z0 + 0.036, include_intake_recess=False)
        rocker_grid.append([
            Vector((x, y_bot - 0.085, z0 - 0.004)),
            Vector((x, y_bot - 0.016, z0)),
            Vector((x, y_bot, z0 + 0.018)),
            Vector((x, y_out, z0 + 0.038)),
            Vector((x, y_out - 0.028, z0 + 0.038)),
        ])
    bm_add_thick_grid(bm, rocker_grid, thickness=0.008, outer_mat=0, inner_mat=1, rim_mat=1, out_hint=Vector((0, 1, -0.5)))

    # --- C. Rear Quarter / Muscular Widebody Haunch (L, mirrored to R): X = REAR_BUMPER_SEAM_X .. door_rear_cut ---
    # Terminates CLEANLY at REAR_BUMPER_SEAM_X (-1.895) so ZR1X_Rear_Fascia wraps seamlessly around rear corners!
    xs_r = set()
    for i in range(34):
        xs_r.add(mix(REAR_BUMPER_SEAM_X, -0.31, i / 33.0))
    for i in range(39):
        ang = math.pi * i / 38.0
        xs_r.add(ARCH_R_X + ARCH_R_R * math.cos(ang))
    xs_r.update([ARCH_R_X - ARCH_R_R - 0.002, ARCH_R_X + ARCH_R_R + 0.002, REAR_BUMPER_SEAM_X])
    xs_r_sorted = sorted(x for x in xs_r if REAR_BUMPER_SEAM_X <= x <= -0.31)

    q_side: List[List[Vector]] = []
    q_top: List[List[Vector]] = []
    for x in xs_r_sorted:
        az = arch_z(x, ARCH_R_X, ARCH_R_Z, ARCH_R_R)
        z_bot = max(body_sill_z(x), az if az is not None else 0.0)
        z_top = body_belt_z(x)
        row = []
        for k in range(nv):
            z = mix(z_bot, z_top, k / (nv - 1))
            x_eff = min(x, door_rear_cut_x(z) - 0.002)
            y = flank_y(x_eff, z, include_intake_recess=True)
            row.append(Vector((x_eff, y, z)))
        q_side.append(row)

        p_out = row[-1]
        x_q = p_out.x
        if x_q <= HATCH_FRONT_X + 0.015:
            p_in = hatch_surface_point(clamp(x_q, HATCH_REAR_X, HATCH_FRONT_X), 1.0)
            p_in.x = x_q
        else:
            # Meet the swept C-pillar sail edge behind the teardrop rear quarter window!
            p_in = Vector((x_q, body_shoulder_y(x_q) - 0.018, body_belt_z(x_q) + 0.005))

        strip = []
        for k in range(9):
            f = k / 8.0
            p = p_in.lerp(p_out, f)
            haunch_crown = 0.024 * math.sin(f * math.pi) * ease(REAR_BUMPER_SEAM_X, -1.52, x_q) * ease(-0.35, -0.75, x_q)
            scoop_t = ease(-0.62, -0.82, x_q) * ease(-1.32, -1.12, x_q) * math.exp(-((f - 0.42) / 0.16) ** 2)
            p.z += haunch_crown - 0.014 * scoop_t
            strip.append(p)
        q_top.append(strip)

    # Build q_side with deep dark satin-black interior shading inside the carved C8 side intake cavity!
    bm_q_start = len(bm.faces)
    bm_add_thick_grid(bm, q_side, thickness=0.010, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 1, 0)))
    bm.faces.ensure_lookup_table()
    for f in bm.faces[bm_q_start:]:
        if f.material_index == 0:
            c = f.calc_center_median()
            if -0.78 < c.x < -0.31 and 0.24 < c.z < 0.76:
                y_clean = flank_y(c.x, c.z, include_intake_recess=False)
                if y_clean - c.y > 0.038:
                    f.material_index = 1
    bm_add_thick_grid(bm, q_top, thickness=0.010, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 0, 1)))

    # Rolled rear wheel arch lip return
    arch_r_grid = []
    for i in range(33):
        ang = math.radians(-8.0 + 196.0 * i / 32.0)
        ax = ARCH_R_X + ARCH_R_R * math.cos(ang)
        az_v = max(body_sill_z(ax), ARCH_R_Z + ARCH_R_R * math.sin(ang))
        ay = flank_y(ax, az_v, include_intake_recess=False)
        arch_r_grid.append([
            Vector((ax, ay, az_v)),
            Vector((ax, ay - 0.018, az_v - 0.002)),
            Vector((ax, ay - 0.042, az_v - 0.008)),
        ])
    bm_add_thick_grid(bm, arch_r_grid, thickness=0.005, outer_mat=0, inner_mat=1, rim_mat=1, out_hint=Vector((0, 0, -1)))

    # --- D. Sleek Torch Red A-Pillar (X=1.04 up to windshield header X=0.365) ---
    apillar_sections = []
    for i in range(16):
        t = i / 15.0
        p_ws = windshield_point(t, 1.0)
        x_p = p_ws.x
        y_in = p_ws.y - 0.008
        z_in = p_ws.z - 0.003
        y_out = y_in + mix(0.068, 0.050, t)
        z_out = z_in - mix(0.010, 0.012, t)
        apillar_sections.append([
            Vector((x_p + 0.010, y_in, z_in + 0.006)),
            Vector((x_p - 0.004, y_out, z_out + 0.006)),
            Vector((x_p - 0.052, y_out - 0.008, z_out - 0.020)),
            Vector((x_p - 0.058, y_in - 0.016, z_in - 0.026)),
        ])
    bm_add_closed_loft(bm, apillar_sections, mat_index=0, cap_start=True, cap_end=True)

    # --- E. Swept C-Pillar Sail Framing BEHIND the C8 Teardrop Rear Quarter Window! ---
    # Exact match to 006.png & 02-front-side-view.jpg: curves smoothly behind the pointed teardrop glass
    # from roof halo (-0.42, Z=1.18) sweeping down-and-back along the teardrop edge to (-0.44, Z=0.98)
    # and seamlessly merging into the rear quarter shoulder (-0.64 .. -0.32)!
    sail_grid: List[List[Vector]] = []
    for ih in range(12):
        h = ih / 11.0  # 0 = beltline / rear quarter junction, 1 = roof halo edge
        # Leading edge hugs cleanly BEHIND the teardrop side-window trailing curve!
        if h < 0.35:
            fh = h / 0.35
            x_lead = mix(-0.310, -0.442, fh)
            p_win = side_window_point(x_lead, fh * 0.5, side=1.0)
        else:
            fh = (h - 0.35) / 0.65
            x_lead = mix(-0.442, -0.295, fh ** 1.25)
            p_win = side_window_point(x_lead, 1.0, side=1.0)
        p_lead = Vector((p_win.x - 0.006, p_win.y + 0.008, p_win.z + 0.004))

        # Trailing edge blends smoothly into rear hatch border & rear quarter shoulder at X = -0.68..-0.48
        x_trail = mix(-0.640, -0.495, h)
        p_top_ref = hatch_surface_point(clamp(x_trail, HATCH_REAR_X, HATCH_FRONT_X), 1.0)
        p_bot_ref = Vector((x_trail, body_shoulder_y(x_trail), body_belt_z(x_trail)))
        p_trail = p_bot_ref.lerp(p_top_ref, h ** 0.85)
        if h > 0.72:
            # Blend top edge seamlessly inward to meet the rear roof halo!
            f_halo = ease(0.72, 1.0, h)
            p_lead = p_lead.lerp(Vector((-0.395, roof_rail_y(-0.395), roof_rail_z(-0.395) + 0.006)), f_halo * 0.85)
            p_trail = p_trail.lerp(Vector((-0.535, roof_rail_y(-0.535), roof_rail_z(-0.535) + 0.004)), f_halo * 0.75)

        row = []
        for k in range(6):
            fk = k / 5.0
            p = p_lead.lerp(p_trail, fk)
            p.y += 0.010 * math.sin(fk * math.pi)
            p.z += 0.006 * math.sin(fk * math.pi)
            row.append(p)
        sail_grid.append(row)
    bm_add_thick_grid(bm, sail_grid, thickness=0.014, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 1, 0.5)))

    # Mirror all L-side body geometry cleanly to R before adding centerline pieces!
    geom = list(bm.verts) + list(bm.edges) + list(bm.faces)
    ret = bmesh.ops.duplicate(bm, geom=geom)
    for e in ret["geom"]:
        if isinstance(e, bmesh.types.BMVert):
            e.co.y = -e.co.y
    dup_faces = [e for e in ret["geom"] if isinstance(e, bmesh.types.BMFace)]
    bmesh.ops.reverse_faces(bm, faces=dup_faces)

    # --- F. Centerline-Spanning Fixed Roof Halo & Windshield Header ---
    halo_grid = []
    for ix in range(8):
        x = mix(-0.545, ROOF_REAR_X, ix / 7.0)
        row = []
        for iy in range(19):
            s = mix(-1.0, 1.0, iy / 18.0)
            p = roof_surface_point(ROOF_REAR_X, s)
            p.x = x - 0.038 * (s * s)
            p.z = body_center_z(x) - 0.024 * (s * s)
            row.append(p)
        halo_grid.append(row)
    bm_add_thick_grid(bm, halo_grid, thickness=0.016, outer_mat=0, inner_mat=1, rim_mat=1, out_hint=Vector((0, 0, 1)))

    # Dark gloss/carbon windshield top header seamlessly tucked BETWEEN A-pillars (zero protruding corner bars!)
    hdr_grid = []
    for ix in range(6):
        t_h = ix / 5.0
        row = []
        for iy in range(19):
            s = mix(-0.92, 0.92, iy / 18.0)
            p0 = windshield_point(0.98, s)
            p1 = roof_surface_point(ROOF_FRONT_X, s)
            row.append(p0.lerp(p1, t_h) - Vector((0.0, 0.0, 0.004)))
        hdr_grid.append(row)
    bm_add_thick_grid(bm, hdr_grid, thickness=0.010, outer_mat=2, inner_mat=1, rim_mat=1, out_hint=Vector((0, 0, 1)))

    finalize_bmesh("ZR1X_Body_Shell", bm, mat_list, body_piv, mirror_y=False, auto_smooth_deg=44.0, uv_scale=4.0)


# ---------------------------------------------------------------------------
# 2. Inner Jambs, Wheelhouse Liners, Cowl & Closure Gutters
# ---------------------------------------------------------------------------

def _build_body_jambs(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    bm = bmesh.new()
    mat_list = [mats["Mat_Black_Trim_Satin"], mats["Mat_Torch_Red_GKZ"], mats["Mat_Dark_Mesh"]]

    # Front & Rear Wheelhouse Liners (L, mirrored to R)
    for cx, cz, r, y_in, y_out in (
        (ARCH_F_X, ARCH_F_Z, ARCH_F_R + 0.008, 0.56, 0.942),
        (ARCH_R_X, ARCH_R_Z, ARCH_R_R + 0.008, 0.52, 0.965),
    ):
        tub = []
        for i in range(25):
            ang = math.radians(-12.0 + 204.0 * i / 24.0)
            ax = cx + r * math.cos(ang)
            az = max(0.145, cz + r * math.sin(ang))
            tub.append([
                Vector((ax, y_in, az)),
                Vector((ax, mix(y_in, y_out, 0.35), az + 0.012)),
                Vector((ax, mix(y_in, y_out, 0.72), az + 0.008)),
                Vector((ax, y_out, az - 0.005)),
            ])
        bm_add_thick_grid(bm, tub, thickness=0.006, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, 0, -1)))

        wall = []
        for i in range(15):
            ang = math.radians(0.0 + 180.0 * i / 14.0)
            ax = cx + r * math.cos(ang)
            az_top = max(0.16, cz + r * math.sin(ang))
            wall.append([Vector((ax, y_in, 0.16)), Vector((ax, y_in, mix(0.16, az_top, 0.5))), Vector((ax, y_in, az_top))])
        bm_add_thick_grid(bm, wall, thickness=0.006, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, 1, 0)))

    # Front & Rear Door Jambs + Deep Recessed Side Intake Radiator Screen (strictly inboard of quarter skin!)
    fj_grid = []
    for k in range(10):
        z = mix(0.16, 0.82, k / 9.0)
        x = door_front_cut_x(z) - 0.006
        y_o = flank_y(x, z, include_intake_recess=False) - 0.014
        fj_grid.append([Vector((x, y_o, z)), Vector((x - 0.018, y_o - 0.095, z))])
    bm_add_thick_grid(bm, fj_grid, thickness=0.008, outer_mat=1, inner_mat=0, rim_mat=0, out_hint=Vector((-1, 0, 0)))

    rj_grid = []
    for k in range(12):
        z = mix(0.16, 0.88, k / 11.0)
        x = door_rear_cut_x(z) - 0.008
        y_o = flank_y(x, z, include_intake_recess=True) - 0.010
        rj_grid.append([
            Vector((x, y_o, z)),
            Vector((x - 0.055, y_o - 0.105, z)),
            Vector((x - 0.170, y_o - 0.145, z)),
        ])
    bm_add_thick_grid(bm, rj_grid, thickness=0.008, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((1, 0.5, 0)))

    # Deep dark side-radiator mesh inside the rear-quarter side intake throat (strictly inboard Y=0.72..0.85!)
    intake_screen = []
    for k in range(10):
        z = mix(0.28, 0.72, k / 9.0)
        intake_screen.append([Vector((-0.68, 0.72, z)), Vector((-0.62, 0.84, z))])
    bm_add_thick_grid(bm, intake_screen, thickness=0.006, outer_mat=2, inner_mat=0, rim_mat=0, out_hint=Vector((1, 0, 0)))

    # Mirror symmetric jambs L -> R
    geom = list(bm.verts) + list(bm.edges) + list(bm.faces)
    ret = bmesh.ops.duplicate(bm, geom=geom)
    for e in ret["geom"]:
        if isinstance(e, bmesh.types.BMVert):
            e.co.y = -e.co.y
    dup_faces = [e for e in ret["geom"] if isinstance(e, bmesh.types.BMFace)]
    bmesh.ops.reverse_faces(bm, faces=dup_faces)

    # Left-only recessed fuel filler cup (inset strictly 12 mm inside flank_y so ZERO edge pokes through closed skin!)
    y_q = flank_y(FUEL_CENTER_X, FUEL_CENTER_Z, include_intake_recess=False)
    cup_sections = []
    for d_idx, depth in enumerate((0.014, 0.058)):
        r_scale = 0.88 if d_idx == 0 else 0.72
        ring = []
        for s_i in range(20):
            a = 2.0 * math.pi * s_i / 20.0
            px = FUEL_CENTER_X + FUEL_RADIUS_X * r_scale * math.cos(a)
            pz = FUEL_CENTER_Z + FUEL_RADIUS_Z * r_scale * math.sin(a)
            py = flank_y(px, pz, include_intake_recess=False) - depth
            ring.append(Vector((px, py, pz)))
        cup_sections.append(ring)
    bm_add_closed_loft(bm, cup_sections, mat_index=0, cap_start=False, cap_end=True)
    bm_add_box(bm, (FUEL_CENTER_X, y_q - 0.048, FUEL_CENTER_Z), (0.040, 0.016, 0.040), mat_index=2, bevel=0.012)

    # Wiper Cowl Tray & Under-Hood Frunk Perimeter Gutter
    cowl_grid = []
    for ix in range(8):
        x = mix(1.03, 1.24, ix / 7.0)
        hw = mix(0.75, 0.69, ix / 7.0)
        row = [Vector((x, mix(-hw, hw, iy / 16.0), mix(0.840, 0.802, ix / 7.0) - 0.022 * (mix(-1.0, 1.0, iy / 16.0) ** 2))) for iy in range(17)]
        cowl_grid.append(row)
    bm_add_thick_grid(bm, cowl_grid, thickness=0.010, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, 0, 1)))

    for side in (-1.0, 1.0):
        gutter = []
        for i in range(12):
            x = mix(1.12, 1.94, i / 11.0)
            p_edge = hood_aperture_point(x, side)
            gutter.append([
                Vector((p_edge.x, p_edge.y, p_edge.z - 0.008)),
                Vector((p_edge.x, p_edge.y - side * 0.060, p_edge.z - 0.042)),
                Vector((p_edge.x, p_edge.y - side * 0.095, p_edge.z - 0.115)),
            ])
        bm_add_thick_grid(bm, gutter, thickness=0.008, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, -side, 1)))

    duct_floor = []
    for ix in range(10):
        x = mix(1.26, 1.88, ix / 9.0)
        hw = mix(0.46, 0.50, ix / 9.0)
        z_fl = mix(0.71, 0.52, ix / 9.0)
        duct_floor.append([Vector((x, mix(-hw, hw, iy / 12.0), z_fl + 0.012 * abs(mix(-1.0, 1.0, iy / 12.0)))) for iy in range(13)])
    bm_add_thick_grid(bm, duct_floor, thickness=0.008, outer_mat=2, inner_mat=0, rim_mat=0, out_hint=Vector((0, 0, 1)))

    for side in (-1.0, 1.0):
        hg = []
        for i in range(14):
            x = mix(HATCH_REAR_X, HATCH_FRONT_X, i / 13.0)
            p_edge = hatch_surface_point(x, side)
            hg.append([
                Vector((p_edge.x, p_edge.y, p_edge.z - 0.008)),
                Vector((p_edge.x, p_edge.y - side * 0.055, p_edge.z - 0.036)),
                Vector((p_edge.x, p_edge.y - side * 0.075, p_edge.z - 0.095)),
            ])
        bm_add_thick_grid(bm, hg, thickness=0.008, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, -side, 1)))

        tg = []
        for i in range(10):
            x = mix(ROOF_REAR_X + 0.015, ROOF_FRONT_X - 0.015, i / 9.0)
            p_edge = roof_surface_point(x, side * 0.90)
            tg.append([
                Vector((p_edge.x, p_edge.y, p_edge.z - 0.020)),
                Vector((p_edge.x, p_edge.y - side * 0.032, p_edge.z - 0.034)),
                Vector((p_edge.x, p_edge.y - side * 0.048, p_edge.z - 0.044)),
            ])
        bm_add_thick_grid(bm, tg, thickness=0.007, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, 0, 1)))

    finalize_bmesh("ZR1X_Body_Jambs", bm, mat_list, body_piv, mirror_y=False, auto_smooth_deg=45.0, uv_scale=6.0)


# ---------------------------------------------------------------------------
# 3. Seamless Wrap-Around Fixed Front Fascia (Zero Overhang Flaps, True Headlamp Pockets!)
# ---------------------------------------------------------------------------

def _build_front_fascia(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    bm = bmesh.new()
    # 0=Torch Red, 1=Gloss Black upper grille bar, 2=Satin Black inner duct walls
    mat_list = [mats["Mat_Torch_Red_GKZ"], mats["Mat_Black_Trim_Gloss"], mats["Mat_Black_Trim_Satin"]]

    # --- A. Sculpted Upper Nose Beak Cap + Seamless Inner-Fender Bridge Around Headlamps! ---
    nose_grid: List[List[Vector]] = []
    ns = 29
    nt = 14
    for it in range(nt):
        t = it / (nt - 1)
        row = []
        for is_i in range(ns):
            s = mix(-1.0, 1.0, is_i / (ns - 1))
            a = abs(s)
            p = nose_surface_pt(s, t)
            # Gentle contoured headlamp seat (zero black hole gap beside hood seam!)
            in_hl = ease(0.56, 0.70, a) * ease(0.98, 0.86, a) * ease(0.76, 0.35, t) * ease(0.02, 0.16, t)
            p.z -= 0.016 * in_hl
            row.append(p)
        nose_grid.append(row)
    bm_add_thick_grid(bm, nose_grid, thickness=0.011, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0.6, 0, 1)))

    # Smooth inner fender shoulder strips bridging hood side edge (X=1.72..1.97) to headlamp upper-inner brow
    # Eliminates any dark gap between the front fender seam (X=1.725), hood edge, and headlamp!
    for side in (-1.0, 1.0):
        bridge_grid = []
        for ix in range(10):
            tx = ix / 9.0
            x = mix(FRONT_BUMPER_SEAM_X - 0.01, HOOD_FRONT_X, tx)
            p_in = hood_aperture_point(x, side)
            # Outer edge meets the upper-inner headlamp curve seamlessly!
            p_out = Vector((
                mix(FRONT_BUMPER_SEAM_X, 2.02, tx),
                side * mix(body_shoulder_y(FRONT_BUMPER_SEAM_X) + 0.04, 0.62, tx ** 0.85),
                mix(body_belt_z(FRONT_BUMPER_SEAM_X) - 0.014, 0.665, tx),
            ))
            bridge_grid.append([
                p_in.lerp(p_out, k / 6.0) + Vector((0.0, 0.0, 0.008 * math.sin(k / 6.0 * math.pi)))
                for k in range(7)
            ])
        bm_add_thick_grid(bm, bridge_grid, thickness=0.010, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0.2, 0, 1)))

    # --- B. Smooth Beak Under-Lip Roll (seals smoothly down to dark recessed grille mouth, zero grey broadside gap!) ---
    beak_under = []
    for k in range(7):
        tk = k / 6.0
        row = []
        for is_i in range(ns):
            s = mix(-1.0, 1.0, is_i / (ns - 1))
            p_lip = nose_surface_pt(s, 1.0)
            x_in = p_lip.x - 0.088 * (tk ** 1.15)
            z_in = p_lip.z - 0.056 * math.sin(tk * math.pi * 0.55)
            row.append(Vector((x_in, p_lip.y * (1.0 - 0.025 * tk), z_in)))
        beak_under.append(row)
    bm_add_thick_grid(bm, beak_under, thickness=0.009, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0.8, 0, -0.5)))

    # --- C. Seamless Curved Front Bumper Corner Wraps (seals completely under headlamp corner, zero seam gap!) ---
    for side in (-1.0, 1.0):
        corner_grid: List[List[Vector]] = []
        for iz in range(14):
            tz = iz / 13.0
            row = []
            for ix in range(14):
                tx = ix / 13.0  # 0 = seamless join to front fender at X=1.720, 1 = curved front cheek edge!
                x_s = FRONT_BUMPER_SEAM_X - 0.006
                z_seam = mix(body_sill_z(x_s), body_belt_z(x_s), tz)
                # Rises all the way up to Z=0.618 to meet outer lower headlamp edge cleanly with ZERO triangular hole!
                z_front = mix(0.174, 0.618, tz)
                z = mix(z_seam, z_front, tx ** 0.85)
                x_f = mix(2.055, 1.985, tz) - 0.030 * ((tz - 0.45) ** 2)
                x = mix(x_s, x_f, tx)
                y_seam = flank_y(x_s, z_seam, include_intake_recess=False)
                # Tapered outer bumper cheek curving smoothly around the front corner into the angled intake surround
                y_front = mix(0.835, 0.905, tz ** 0.78)
                y = mix(y_seam, y_front, tx ** 1.55)
                row.append(Vector((x, side * y, z)))
            corner_grid.append(row)
        bm_add_thick_grid(bm, corner_grid, thickness=0.011, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0.45, side, 0.1)))

        # Curved inward-turning tapered surround lip framing outer side radiator bay smoothly
        lip_in = []
        for iz in range(10):
            tz = iz / 9.0
            z = mix(0.178, 0.485, tz)
            x0 = mix(2.045, 2.005, tz)
            y0 = side * mix(0.835, 0.865, tz)
            lip_in.append([
                Vector((x0, y0, z)),
                Vector((x0 - 0.095, y0 - side * 0.042, z)),
            ])
        bm_add_thick_grid(bm, lip_in, thickness=0.009, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0.2, -side, 0)))

        # Sleek tapered, swept-back angled Torch Red inner fangs (not thick vertical pillars!)
        fang_sec = []
        for k in range(8):
            tk = k / 7.0
            cx = mix(2.265, 2.135, tk)
            cy = side * mix(0.390, 0.485, tk ** 0.92)
            cz = mix(0.180, 0.422, tk)
            w_y = mix(0.038, 0.022, tk)
            fang_sec.append([
                Vector((cx + 0.018, cy - side * w_y * 0.5, cz)),
                Vector((cx + 0.004, cy + side * w_y * 0.5, cz)),
                Vector((cx - 0.085, cy + side * w_y * 0.35, cz)),
                Vector((cx - 0.085, cy - side * w_y * 0.35, cz)),
            ])
        bm_add_closed_loft(bm, fang_sec, mat_index=0, cap_start=True, cap_end=True)

        # Painted lower horizontal chin scoop shelf below side radiator grille
        chin = []
        for ix in range(6):
            tx = ix / 5.0
            row = []
            for iy in range(8):
                ty = iy / 7.0
                y = side * mix(0.395, 0.838, ty)
                x_lead = 2.272 - 0.235 * (ty ** 1.35)
                x = x_lead - 0.110 * tx
                z = mix(0.196, 0.174, ty) + 0.010 * tx
                row.append(Vector((x, y, z)))
            chin.append(row)
        bm_add_thick_grid(bm, chin, thickness=0.011, outer_mat=0, inner_mat=2, rim_mat=0, out_hint=Vector((0.4, 0, 1)))

    # --- D. Sleek Dark Gloss Horizontal Upper Grille Cross-Bar (recessed cleanly under painted beak!) ---
    bar_grid = []
    for k in range(6):
        tk = k / 5.0
        row = []
        for is_i in range(21):
            s = mix(-1.0, 1.0, is_i / 20.0)
            a = abs(s)
            x_b = (NOSE_TIP_X - 0.088) - 0.375 * (a ** 1.72) - 0.020 * tk
            y_b = s * 0.835
            z_top = 0.445 + 0.052 * (a ** 1.45)
            z_bot = 0.382 + 0.064 * (a ** 1.35)
            row.append(Vector((x_b, y_b, mix(z_top, z_bot, tk))))
        bar_grid.append(row)
    bm_add_thick_grid(bm, bar_grid, thickness=0.014, outer_mat=1, inner_mat=2, rim_mat=1, out_hint=Vector((1, 0, 0)))

    # --- E. Deep Dark Inner Radiator Duct Backing Box ---
    back_grid = []
    for iz in range(8):
        z = mix(0.160, 0.485, iz / 7.0)
        back_grid.append([Vector((1.96 - 0.34 * (s * s), s * 0.845, z)) for s in [mix(-1.0, 1.0, k / 16.0) for k in range(17)]])
    bm_add_thick_grid(bm, back_grid, thickness=0.010, outer_mat=2, inner_mat=2, rim_mat=2, out_hint=Vector((1, 0, 0)))

    finalize_bmesh("ZR1X_Front_Fascia", bm, mat_list, body_piv, mirror_y=False, auto_smooth_deg=42.0, uv_scale=4.0)


# ---------------------------------------------------------------------------
# 4. Seamless Wrap-Around Rear Fascia, Transom & Diffuser + Aligned Hex Bezel
# ---------------------------------------------------------------------------

def _rear_bumper_pt(s: float, tz: float) -> Vector:
    """Single continuous smoothly-rounded wrap-around rear bumper coordinate (s in [-1, 1], tz in [0, 1])."""
    a = abs(s)
    side = 1.0 if s >= 0.0 else -1.0

    corner_t = ease(0.62, 1.0, a)
    z_lo = mix(0.455, body_sill_z(REAR_BUMPER_SEAM_X) + 0.030, corner_t)
    # Softly round outer upper rear haunch shoulder (eliminates squared-off rear corners!)
    shoulder_roll = 0.022 * math.sin(ease(0.55, 0.96, a) * math.pi)
    z_hi = mix(0.938, body_belt_z(REAR_BUMPER_SEAM_X), corner_t) - shoulder_roll
    z = mix(z_lo, z_hi, tz)

    if a <= 0.70:
        u = a / 0.70
        hw = mix(0.915, 0.865, tz ** 1.25)
        y = side * (u * hw)
        x = -2.185 + 0.155 * (u ** 2.10)
        x -= 0.015 * math.exp(-((z - 0.72) / 0.09) ** 2) * (1.0 - 0.45 * u)
        x -= 0.018 * ease(0.87, 0.945, z) * (1.0 - 0.55 * (u ** 2))
    else:
        v = (a - 0.70) / 0.30
        hw_corner = mix(0.915, 0.865, tz ** 1.25)
        y_seam = flank_y(REAR_BUMPER_SEAM_X, max(z, body_sill_z(REAR_BUMPER_SEAM_X)), include_intake_recess=False)
        x_c0 = -2.030 - 0.008 * ease(0.86, 0.95, z)
        # Smooth super-elliptic corner roll matching rear quarter tangency!
        x = mix(x_c0, REAR_BUMPER_SEAM_X, v ** 1.25)
        y = side * mix(hw_corner, y_seam, math.sin(v * math.pi * 0.5))

    return Vector((x, y, z))


def _build_rear_fascia_and_diffuser(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]

    # === A. ZR1X_Rear_Fascia (Seamless wrap-around Torch Red rear bumper + deck lip + recessed pockets!) ===
    bm = bmesh.new()
    mat_list = [mats["Mat_Torch_Red_GKZ"], mats["Mat_Black_Trim_Satin"], mats["Mat_Black_Trim_Gloss"]]

    ny = 45
    nz = 17
    transom: List[List[Vector]] = []
    for iz in range(nz):
        tz = iz / (nz - 1)
        row = []
        for iy in range(ny):
            s = mix(-1.0, 1.0, iy / (ny - 1))
            p = _rear_bumper_pt(s, tz)
            ya = abs(p.y)
            z = p.z
            # Only apply rear-face recesses on transom region (|s| < 0.74)
            if abs(s) < 0.75:
                # 1. License plate trapezoid recess (|Y| < 0.24, Z in 0.59..0.79)
                w_plate = mix(0.215, 0.265, clamp((z - 0.59) / 0.20, 0.0, 1.0))
                in_plate = ease(w_plate + 0.045, w_plate - 0.015, ya) * ease(0.57, 0.61, z) * ease(0.81, 0.77, z)
                x_off = 0.068 * in_plate
                # 2. Taillight housing recess (|Y| in 0.29..0.89, Z in 0.755..0.898)
                in_tl = ease(0.26, 0.32, ya) * ease(0.91, 0.85, ya) * ease(0.74, 0.77, z) * ease(0.915, 0.885, z)
                x_off = max(x_off, 0.068 * in_tl)
                # 3. Rear corner vent pocket (|Y| in 0.44..0.85, Z in 0.545..0.665)
                in_rv = ease(0.41, 0.47, ya) * ease(0.87, 0.81, ya) * ease(0.53, 0.56, z) * ease(0.68, 0.65, z)
                x_off = max(x_off, 0.068 * in_rv)
                p.x += x_off
            row.append(p)
        transom.append(row)
    bm_add_thick_grid(bm, transom, thickness=0.012, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((-1, 0, 0)))

    # Smooth fixed rear deck top cap bridging hatch trailing seam (-1.965) cleanly onto top of rear bumper!
    deck_grid = []
    for ix in range(10):
        tx = ix / 9.0  # 0 = rear bumper top lip, 1 = hatch trailing seam (-1.965)
        row = []
        for iy in range(29):
            s = mix(-1.0, 1.0, iy / 28.0)
            p_lip = _rear_bumper_pt(s * 0.94, 1.0)
            # Front edge meets hatch trailing edge & rear quarter deck cleanly!
            x_front = mix(HATCH_REAR_X, REAR_BUMPER_SEAM_X, ease(0.55, 1.0, abs(s)))
            y_front = s * body_shoulder_y(x_front)
            z_front = mix(body_center_z(HATCH_REAR_X), body_belt_z(REAR_BUMPER_SEAM_X), abs(s) ** 1.35)
            p_f = Vector((x_front, y_front, z_front))
            p = p_lip.lerp(p_f, tx)
            p.z += 0.008 * math.sin(tx * math.pi)
            row.append(p)
        deck_grid.append(row)
    bm_add_thick_grid(bm, deck_grid, thickness=0.012, outer_mat=0, inner_mat=1, rim_mat=0, out_hint=Vector((0, 0, 1)))

    # Flush outer-corner vertical extractor accent strip (tucked cleanly inside corner profile — NO sticking-out block!)
    for side in (-1.0, 1.0):
        p_mid = _rear_bumper_pt(side * 0.77, 0.28)
        bm_add_box(bm, (p_mid.x + 0.008, p_mid.y - side * 0.008, 0.345), (0.022, 0.024, 0.215), mat_index=1, bevel=0.004)

    # Backup camera pod centered cleanly under top lip of license-plate recess
    bm_add_box(bm, (-2.165, 0.0, 0.785), (0.024, 0.046, 0.018), mat_index=1, bevel=0.004)

    # Dark inner backing wall behind lower rear diffuser (solid when diffuser explodes aft!)
    backing = []
    for iz in range(6):
        z = mix(0.22, 0.47, iz / 5.0)
        backing.append([Vector((-2.02 + 0.14 * (s * s), s * 0.84, z)) for s in [mix(-1.0, 1.0, k / 12.0) for k in range(13)]])
    bm_add_thick_grid(bm, backing, thickness=0.010, outer_mat=1, inner_mat=1, rim_mat=1, out_hint=Vector((-1, 0, 0)))

    finalize_bmesh("ZR1X_Rear_Fascia", bm, mat_list, body_piv, mirror_y=False, auto_smooth_deg=42.0, uv_scale=4.0)

    # === B. ZR1X_Rear_Diffuser (Sculpted Dark Valance + Hexagonal Quad-Exhaust Bezel aligned to mech_exhaust!) ===
    # mech_exhaust.py tip_specs: Y = (+/-0.058, +/-0.174), Z = 0.336, X_lip = -2.220 / -2.208!
    bm_d = bmesh.new()
    mat_d = [mats["Mat_Black_Trim_Satin"], mats["Mat_Black_Trim_Gloss"], mats["Mat_Dark_Mesh"]]

    val_grid = []
    for iz in range(10):
        tz = iz / 9.0
        z = mix(0.210, 0.478, tz)
        row = []
        for iy in range(29):
            s = mix(-1.0, 1.0, iy / 28.0)
            a = abs(s)
            hw = mix(0.845, 0.895, tz)
            y = s * hw
            x = -2.192 + 0.170 * (a ** 2.05) + 0.036 * ((1.0 - tz) ** 1.35)
            # Deep center cavity behind the 4 titanium exhaust tips (|Y| < 0.27, Z in 0.27..0.40)
            in_exh = ease(0.31, 0.25, abs(y)) * ease(0.24, 0.275, z) * ease(0.43, 0.395, z)
            x += 0.125 * in_exh
            # Flanking honeycomb side diffuser pockets
            in_side = ease(0.36, 0.42, abs(y)) * ease(0.80, 0.74, abs(y)) * ease(0.22, 0.26, z) * ease(0.40, 0.36, z)
            x += 0.032 * in_side
            row.append(Vector((x, y, z)))
        val_grid.append(row)
    bm_add_thick_grid(bm_d, val_grid, thickness=0.014, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((-1, 0, 0)))

    # Smooth flat lower underbody diffuser belly pan
    belly = []
    for ix in range(7):
        t = ix / 6.0
        x = mix(-1.82, -2.14, t)
        z = mix(0.168, 0.215, t ** 1.4)
        hw = mix(0.84, 0.78, t)
        belly.append([Vector((x + 0.06 * (s * s), s * hw, z)) for s in [mix(-1.0, 1.0, k / 14.0) for k in range(15)]])
    bm_add_thick_grid(bm_d, belly, thickness=0.010, outer_mat=0, inner_mat=0, rim_mat=0, out_hint=Vector((0, 0, -1)))

    # Chamfered Hexagonal Center Quad-Exhaust Bezel centered EXACTLY at Z = 0.336, lip X = -2.226!
    # Frames mech_exhaust.py's 4 rolled titanium tips (+/-0.058, +/-0.174, Z=0.336, X=-2.208..-2.220) cleanly!
    hex_pts_2d = [
        (-0.255, 0.408), ( 0.255, 0.408),
        ( 0.312, 0.336), ( 0.262, 0.264),
        (-0.262, 0.264), (-0.312, 0.336),
    ]
    hex_in_2d = [
        (-0.232, 0.390), ( 0.232, 0.390),
        ( 0.282, 0.336), ( 0.238, 0.282),
        (-0.238, 0.282), (-0.282, 0.336),
    ]
    for i in range(len(hex_pts_2d)):
        ni = (i + 1) % len(hex_pts_2d)
        y0o, z0o = hex_pts_2d[i]
        y1o, z1o = hex_pts_2d[ni]
        y0i, z0i = hex_in_2d[i]
        y1i, z1i = hex_in_2d[ni]
        x_f = -2.226
        x_b = -2.100
        ring_a = [Vector((x_f, y0o, z0o)), Vector((x_f - 0.008, y0i, z0i)), Vector((x_b, y0i, z0i)), Vector((x_b, y0o, z0o))]
        ring_b = [Vector((x_f, y1o, z1o)), Vector((x_f - 0.008, y1i, z1i)), Vector((x_b, y1i, z1i)), Vector((x_b, y1o, z1o))]
        bm_add_closed_loft(bm_d, [ring_a, ring_b], mat_index=1, cap_start=False, cap_end=False, smooth=False)

    # Sculpted trapezoidal gloss-black bridge arch framing above & beside the hexagonal bezel
    arch_sec = []
    for y_a, z_a in ((-0.45, 0.215), (-0.37, 0.422), (0.0, 0.436), (0.37, 0.422), (0.45, 0.215)):
        x_a = -2.208 + 0.032 * (abs(y_a) / 0.45) ** 2
        arch_sec.append([
            Vector((x_a - 0.012, y_a, z_a + 0.015)),
            Vector((x_a - 0.012, y_a, z_a - 0.015)),
            Vector((x_a + 0.048, y_a, z_a - 0.015)),
            Vector((x_a + 0.048, y_a, z_a + 0.015)),
        ])
    bm_add_closed_loft(bm_d, arch_sec, mat_index=1, cap_start=True, cap_end=True, smooth=False)

    # Sculpted curved lower rear diffuser side pockets w/ recessed dark honeycomb mesh & angled aero trim bars
    # (replaces flat grey rectangles with clean C8 rear valance contours!)
    for side in (-1.0, 1.0):
        pkt = []
        for iz in range(5):
            z = mix(0.255, 0.365, iz / 4.0)
            row = []
            for iy in range(7):
                ya = mix(0.415, 0.755, iy / 6.0)
                a = ya / 0.88
                x = -2.148 + 0.165 * (a ** 2.05) + 0.015 * (1.0 - iz / 4.0)
                row.append(Vector((x, side * ya, z)))
            pkt.append(row)
        bm_add_thick_grid(bm_d, pkt, thickness=0.008, outer_mat=2, inner_mat=0, rim_mat=1, out_hint=Vector((-1, 0, 0)))
        # Sleek angled horizontal gloss-black aero louver bisecting each lower side diffuser pocket
        l_sec = []
        for iy in range(7):
            ya = mix(0.415, 0.760, iy / 6.0)
            x = -2.162 + 0.165 * ((ya / 0.88) ** 2.05)
            z = mix(0.322, 0.302, iy / 6.0)
            l_sec.append([
                Vector((x - 0.008, side * ya, z + 0.007)),
                Vector((x - 0.008, side * ya, z - 0.007)),
                Vector((x + 0.028, side * ya, z - 0.007)),
                Vector((x + 0.028, side * ya, z + 0.007)),
            ])
        bm_add_closed_loft(bm_d, l_sec, mat_index=1, cap_start=True, cap_end=True, smooth=False)

    finalize_bmesh("ZR1X_Rear_Diffuser", bm_d, mat_d, body_piv, mirror_y=False, auto_smooth_deg=36.0, uv_scale=5.0)

    # === C. ZR1X_Rear_DiffuserStrake_L / R (Clean tucked low-profile under-bumper strakes — ZERO teeth!) ===
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm_s = bmesh.new()
        for y_off in (0.36, 0.60):
            strake_sec = []
            for k in range(6):
                tk = k / 5.0
                x = mix(-1.82, -2.14, tk)
                z_top = mix(0.185, 0.238, tk ** 1.3)
                z_bot = mix(0.160, 0.204, tk ** 1.3)
                y = side * (y_off + 0.010 * tk)
                strake_sec.append([
                    Vector((x, y - 0.007, z_bot)),
                    Vector((x, y + 0.007, z_bot)),
                    Vector((x, y + 0.010, z_top)),
                    Vector((x, y - 0.010, z_top)),
                ])
            bm_add_closed_loft(bm_s, strake_sec, mat_index=0, cap_start=True, cap_end=True, smooth=False)
        finalize_bmesh(f"ZR1X_Rear_DiffuserStrake_{sfx}", bm_s, [mats["Mat_Black_Trim_Gloss"]], body_piv, auto_smooth_deg=35.0)


# ---------------------------------------------------------------------------
# 5. Low Flush Black Dorsal Camera Pod & Dual Wipers
# ---------------------------------------------------------------------------

def _build_camera_pod_and_wipers(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]

    bm_f = bmesh.new()
    pod_sections = []
    for x, hw, h_top in (
        (-0.455, 0.012, 0.004),
        (-0.485, 0.022, 0.014),
        (-0.525, 0.026, 0.022),
        (-0.562, 0.024, 0.024),
        (-0.572, 0.020, 0.020),
    ):
        z0 = body_center_z(x) - 0.004
        pod_sections.append([
            Vector((x, -hw, z0)),
            Vector((x,  hw, z0)),
            Vector((x,  hw * 0.58, z0 + h_top)),
            Vector((x, -hw * 0.58, z0 + h_top)),
        ])
    bm_add_closed_loft(bm_f, pod_sections, mat_index=0, cap_start=True, cap_end=True, smooth=True)
    bm_add_box(bm_f, (-0.572, 0.0, body_center_z(-0.57) + 0.008), (0.008, 0.016, 0.012), mat_index=1, bevel=0.002)
    finalize_bmesh(
        "ZR1X_Roof_Fin", bm_f, [mats["Mat_Black_Trim_Gloss"], mats["Mat_Black_Frit"]],
        body_piv, auto_smooth_deg=38.0,
    )

    for side, sfx, x0, y0, x1, y1 in (
        ( 1.0, "L", 1.135,  0.54, 1.155,  0.02),
        (-1.0, "R", 1.150,  0.00, 1.095, -0.60),
    ):
        bm_w = bmesh.new()
        arm_sec = []
        for k in range(8):
            tk = k / 7.0
            px = mix(x0, x1, tk)
            py = mix(y0, y1, tk)
            s_ws = clamp(py / 0.75, -0.95, 0.95)
            p_ws = windshield_point(0.045 + 0.015 * math.sin(tk * math.pi), s_ws)
            pz = p_ws.z + 0.007
            arm_sec.append([
                Vector((px + 0.008, py, pz - 0.004)),
                Vector((px - 0.010, py, pz - 0.004)),
                Vector((px - 0.008, py, pz + 0.008)),
                Vector((px + 0.006, py, pz + 0.006)),
            ])
        bm_add_closed_loft(bm_w, arm_sec, mat_index=0, cap_start=True, cap_end=True, smooth=True)
        finalize_bmesh(f"ZR1X_Wiper_{sfx}", bm_w, [mats["Mat_Black_Trim_Satin"]], body_piv, auto_smooth_deg=40.0)


# ---------------------------------------------------------------------------
# Module Entry Point
# ---------------------------------------------------------------------------

def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Build fixed exterior body shell, fascias, jambs, rear diffuser, camera pod & wipers."""
    _build_body_shell(pivots, mats)
    _build_body_jambs(pivots, mats)
    _build_front_fascia(pivots, mats)
    _build_rear_fascia_and_diffuser(pivots, mats)
    _build_camera_pod_and_wipers(pivots, mats)
