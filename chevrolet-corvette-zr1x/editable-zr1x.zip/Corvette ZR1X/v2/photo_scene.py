"""Store each registered Chevrolet view in the editable, metre-scale master."""
import json
from math import radians, sin, cos, tan
from pathlib import Path
import bpy
from mathutils import Quaternion, Vector
from rig_utils import SCALE_1_18

def add_cameras(scene):
    dataset=json.loads(Path(__file__).with_name("cameras.json").read_text())
    collection=bpy.data.collections.new("Chevrolet reference cameras")
    scene.collection.children.link(collection)
    for fid,row in dataset["frames"].items():
        pose=row["viewer"]
        dims=row["solved"]
        width,height=dims["width"],dims["height"]
        theta,phi=pose["theta"],pose["phi"]
        distance=pose["radius"]*tan(radians(15))/tan(radians(pose["fov"])/2)
        # glTF [+X nose, +Y up, +Z right] to Blender metres.
        center=Vector(pose['center'])/SCALE_1_18
        position=center+distance/SCALE_1_18*Vector((sin(phi)*cos(theta),cos(phi),sin(phi)*sin(theta)))
        convert=lambda v: Vector((v.x,-v.z,v.y))
        camera=bpy.data.cameras.new(fid)
        obj=bpy.data.objects.new(fid+' '+row['label'],camera)
        obj.location=convert(position)
        look=convert(center-position)
        obj.rotation_mode='QUATERNION'
        obj.rotation_quaternion=look.to_track_quat('-Z','Y') @ Quaternion((0,0,1),pose.get('roll',0))
        camera.sensor_fit='HORIZONTAL'
        camera.sensor_width=36
        camera.lens=36*height/(2*width*tan(radians(pose['fov'])/2))
        px,py=pose.get('principalPoint',(.5,.5))
        camera.shift_x=.5-px
        camera.shift_y=(py-.5)*height/width
        camera.display_size=.09
        camera.clip_start=.01
        obj["reference_id"]=fid
        obj["image_width"]=width
        obj["image_height"]=height
        obj["viewer_pose"]=json.dumps(pose)
        collection.objects.link(obj)
        if fid=="view-00":
            scene.camera=obj
            scene.render.resolution_x=width
            scene.render.resolution_y=height
            scene.render.resolution_percentage=100
    return collection
