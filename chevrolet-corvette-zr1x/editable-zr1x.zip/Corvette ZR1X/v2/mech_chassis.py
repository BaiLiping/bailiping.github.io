"""Chassis, spaceframe, tunnel, flat undertray, cooling, fuel & SLA suspension for ZR1X v2.

Populates ``Pivot_Drivetrain_Chassis`` (anchored at world origin ``(0, 0, 0)``).
All coordinates are V2 Blender meters (+X forward, +Y left/driver, +Z up, ground Z=0).
SLA control arms, coilovers, ARBs, and CV half-shafts live here per ``v2_rig_spec.md``
so ``S`` steering pivots only ``Pivot_Corner_FL/FR`` without swinging wishbones.
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

import bpy
import numpy as np
from mathutils import Vector

from rig_utils import (
    AXLE_F_X,
    AXLE_R_X,
    TIRE_R_F,
    TIRE_R_R,
    join_meshes,
    make_cylinder,
    make_loft,
    make_mesh,
    make_roundbox,
    make_tube,
)


def _m(mats: Dict[str, bpy.types.Material], key: str, fallback: str = "Mat_Aluminum_Cast") -> bpy.types.Material:
    return mats.get(key) or mats.get(fallback) or next(iter(mats.values()))


def _ellipse_loft(
    name: str,
    stations: Sequence[Tuple[float, float, float, float, float]],
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "x",
    steps: int = 24,
    uv_scale: float | None = None,
) -> bpy.types.Object:
    sections = []
    for axial, u0, z0, ru, rz in stations:
        ring = []
        for j in range(steps):
            t = 2.0 * math.pi * j / steps
            u = u0 + ru * math.cos(t)
            z = z0 + rz * math.sin(t)
            ring.append((axial, u, z) if axis == "x" else (u, axial, z))
        sections.append(ring if axis == "x" else ring[::-1])
    return make_loft(name, sections, mat, pivot, cyclic_u=True, cap_ends=True, smooth=True, uv_scale=uv_scale)


def _beam_loft(
    name: str,
    path_pts: Sequence[Tuple[float, float, float, float, float]],
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    uv_scale: float | None = None,
) -> bpy.types.Object:
    """Loft a beveled rectangular-section aluminum extrusion along (x, y, z, half_w, half_h)."""
    profile = [
        (-1.0, -0.78), (-0.78, -1.0), (0.78, -1.0), (1.0, -0.78),
        (1.0, 0.78), (0.78, 1.0), (-0.78, 1.0), (-1.0, 0.78),
    ]
    pts = [Vector((p[0], p[1], p[2])) for p in path_pts]
    sections = []
    for idx, (x, y, z, hw, hh) in enumerate(path_pts):
        if idx == 0:
            tang = (pts[1] - pts[0]).normalized()
        elif idx == len(pts) - 1:
            tang = (pts[-1] - pts[-2]).normalized()
        else:
            tang = (pts[idx + 1] - pts[idx - 1]).normalized()
        up = Vector((0.0, 0.0, 1.0))
        if abs(tang.dot(up)) > 0.92:
            up = Vector((1.0, 0.0, 0.0))
        right = tang.cross(up).normalized()
        true_up = right.cross(tang).normalized()
        c = Vector((x, y, z))
        ring = []
        for pu, pv in profile:
            pt = c + right * (pu * hw) + true_up * (pv * hh)
            ring.append((pt.x, pt.y, pt.z))
        sections.append(ring)
    return make_loft(
        name, sections, mat, pivot,
        cyclic_u=True, cap_ends=True, smooth=True, auto_smooth_deg=42.0, uv_scale=uv_scale,
    )


def _bolt_cluster(
    name: str,
    centers: Sequence[Tuple[float, float, float]],
    radius: float,
    height: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "z",
) -> bpy.types.Object:
    verts: List[Tuple[float, float, float]] = []
    faces: List[Tuple[int, ...]] = []
    for cx, cy, cz in centers:
        base = len(verts)
        for off, r in ((0.0, radius), (height * 0.85, radius), (height, radius * 0.80)):
            for k in range(6):
                a = k * math.pi / 3.0
                u, v = r * math.cos(a), r * math.sin(a)
                if axis == "z":
                    verts.append((cx + u, cy + v, cz + off))
                elif axis == "x":
                    verts.append((cx + off, cy + u, cz + v))
                else:
                    verts.append((cx + u, cy + off, cz + v))
        for j in range(2):
            for k in range(6):
                nk = (k + 1) % 6
                faces.append((base + j * 6 + k, base + j * 6 + nk, base + (j + 1) * 6 + nk, base + (j + 1) * 6 + k))
        faces.append(tuple(base + 12 + k for k in range(6)))
    return make_mesh(name, verts, faces, mat, pivot, smooth=False, recalc_normals=True)


# ---------------------------------------------------------------------------
# 1. Aluminum Spaceframe & Engine-Bay Carbon Braces
# ---------------------------------------------------------------------------

def _build_spaceframe(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    carbon = _m(mats, "Mat_Carbon_Twill_2x2")
    steel = _m(mats, "Mat_Steel_Machined")
    dark = _m(mats, "Mat_Black_Trim_Satin")

    parts: List[bpy.types.Object] = []

    for s in (-1.0, 1.0):
        # Extruded main side rocker sills (Bedford aluminum hydroformed rails)
        parts.append(_beam_loft(
            "tmp_sill",
            [
                (1.06, s * 0.66, 0.215, 0.048, 0.052),
                (0.75, s * 0.72, 0.205, 0.054, 0.056),
                (0.00, s * 0.73, 0.205, 0.054, 0.056),
                (-0.46, s * 0.72, 0.210, 0.056, 0.058),
                (-0.96, s * 0.66, 0.235, 0.050, 0.055),
            ],
            cast, piv,
        ))

        # Front longitudinal crash rails & upper fender aprons
        parts.append(_beam_loft(
            "tmp_frail",
            [
                (0.98, s * 0.56, 0.255, 0.042, 0.046),
                (1.20, s * 0.50, 0.310, 0.040, 0.046),
                (1.52, s * 0.47, 0.345, 0.038, 0.044),
                (1.88, s * 0.44, 0.375, 0.036, 0.042),
                (2.06, s * 0.43, 0.382, 0.034, 0.038),
            ],
            cast, piv,
        ))
        parts.append(_beam_loft(
            "tmp_fupper",
            [
                (0.92, s * 0.68, 0.650, 0.026, 0.028),
                (1.22, s * 0.63, 0.660, 0.026, 0.028),
                (1.52, s * 0.58, 0.600, 0.024, 0.026),
                (1.84, s * 0.50, 0.480, 0.022, 0.024),
            ],
            cast, piv,
        ))

        # Front cast aluminum shock tower ("Bedford Six" node)
        ft_secs = []
        for zz, xc, yc, rx, ry in (
            (0.36, 1.36, s * 0.525, 0.110, 0.068),
            (0.49, 1.35, s * 0.532, 0.098, 0.064),
            (0.61, 1.34, s * 0.537, 0.082, 0.058),
            (0.655, 1.34, s * 0.537, 0.068, 0.052),
        ):
            ft_secs.append([(xc + rx * math.cos(a), yc + ry * math.sin(a), zz)
                            for a in np.linspace(0, 2 * math.pi, 20, endpoint=False)])
        parts.append(make_loft("tmp_ftower", ft_secs, cast, piv, auto_smooth_deg=45.0))
        parts.append(make_cylinder(
            "tmp_ftop_cap", (1.34, s * 0.537, 0.654), (1.34, s * 0.537, 0.666),
            0.056, 0.052, brushed, piv, segments=20,
        ))

        # Rear engine-bay main longitudinal frame rails (clear LT7 & maniturbos at Y<=0.48)
        parts.append(_beam_loft(
            "tmp_rrail",
            [
                (-0.42, s * 0.62, 0.340, 0.042, 0.048),
                (-0.78, s * 0.56, 0.365, 0.042, 0.048),
                (-1.18, s * 0.54, 0.395, 0.040, 0.046),
                (-1.58, s * 0.53, 0.435, 0.038, 0.044),
                (-1.98, s * 0.50, 0.490, 0.036, 0.040),
            ],
            cast, piv,
        ))
        # Upper engine bay side frame rails (visible under rear hatch)
        parts.append(_beam_loft(
            "tmp_rupper",
            [
                (-0.46, s * 0.66, 0.830, 0.028, 0.026),
                (-0.92, s * 0.60, 0.815, 0.026, 0.025),
                (-1.38, s * 0.56, 0.775, 0.026, 0.025),
                (-1.78, s * 0.52, 0.700, 0.024, 0.024),
            ],
            cast, piv,
        ))

        # Rear cast aluminum shock tower
        rt_secs = []
        for zz, xc, yc, rx, ry in (
            (0.39, -1.36, s * 0.525, 0.115, 0.070),
            (0.54, -1.37, s * 0.532, 0.100, 0.065),
            (0.65, -1.38, s * 0.537, 0.084, 0.060),
            (0.688, -1.38, s * 0.537, 0.068, 0.054),
        ):
            rt_secs.append([(xc + rx * math.cos(a), yc + ry * math.sin(a), zz)
                            for a in np.linspace(0, 2 * math.pi, 20, endpoint=False)])
        parts.append(make_loft("tmp_rtower", rt_secs, cast, piv, auto_smooth_deg=45.0))
        parts.append(make_cylinder(
            "tmp_rtop_cap", (-1.38, s * 0.537, 0.686), (-1.38, s * 0.537, 0.698),
            0.056, 0.052, brushed, piv, segments=20,
        ))

        # B-pillar rear hoop & firewall corner posts
        parts.append(_beam_loft(
            "tmp_bpost",
            [
                (-0.44, s * 0.71, 0.230, 0.036, 0.036),
                (-0.46, s * 0.68, 0.560, 0.034, 0.034),
                (-0.48, s * 0.64, 0.850, 0.032, 0.032),
                (-0.42, s * 0.54, 1.070, 0.028, 0.026),
            ],
            cast, piv,
        ))
        parts.append(_beam_loft(
            "tmp_apost",
            [
                (0.95, s * 0.70, 0.240, 0.034, 0.034),
                (0.96, s * 0.68, 0.640, 0.032, 0.032),
            ],
            cast, piv,
        ))

        # Signature ZR1X carbon-fiber engine bay diagonal cross-brace (Spexx 120)
        parts.append(_beam_loft(
            "tmp_cbrace",
            [
                (-0.50, s * 0.44, 0.855, 0.024, 0.015),
                (-0.92, s * 0.49, 0.820, 0.024, 0.015),
                (-1.35, s * 0.53, 0.745, 0.022, 0.014),
            ],
            carbon, piv, uv_scale=12.0,
        ))
        # Machined end clevis mounts for carbon brace
        for bx, by, bz in ((-0.50, s * 0.44, 0.855), (-1.35, s * 0.53, 0.745)):
            parts.append(make_roundbox("tmp_cbm", (bx, by, bz), (0.055, 0.055, 0.036), brushed, piv, bevel=0.005))

    # Transverse structural crossbeams
    # Front aluminum crash bumper beam
    parts.append(_beam_loft(
        "tmp_fbeam",
        [
            (2.03, -0.58, 0.375, 0.036, 0.044),
            (2.09, -0.32, 0.382, 0.038, 0.046),
            (2.12, 0.00, 0.385, 0.038, 0.046),
            (2.09, 0.32, 0.382, 0.038, 0.046),
            (2.03, 0.58, 0.375, 0.036, 0.044),
        ],
        brushed, piv,
    ))
    # Cowl cross-car beam & lower firewall crossmember
    parts.append(make_roundbox("tmp_cowl", (0.96, 0.0, 0.620), (0.075, 1.38, 0.068), cast, piv, bevel=0.010))
    parts.append(make_roundbox("tmp_fw_low", (0.98, 0.0, 0.215), (0.085, 1.36, 0.065), cast, piv, bevel=0.010))
    # Rear cabin bulkhead structural aluminum firewall crossbeam + rear hoop bar
    parts.append(make_roundbox("tmp_rb_low", (-0.42, 0.0, 0.225), (0.080, 1.40, 0.070), cast, piv, bevel=0.010))
    parts.append(make_roundbox("tmp_rb_mid", (-0.45, 0.0, 0.760), (0.072, 1.30, 0.064), cast, piv, bevel=0.010))
    parts.append(make_roundbox("tmp_rb_top", (-0.42, 0.0, 1.075), (0.060, 1.06, 0.048), cast, piv, bevel=0.010))
    # Rear bumper crash beam (clears exhaust muffler below Z=0.38)
    parts.append(_beam_loft(
        "tmp_rbeam",
        [
            (-1.98, -0.58, 0.515, 0.034, 0.042),
            (-2.03, -0.28, 0.522, 0.036, 0.044),
            (-2.05, 0.00, 0.525, 0.036, 0.044),
            (-2.03, 0.28, 0.522, 0.036, 0.044),
            (-1.98, 0.58, 0.515, 0.034, 0.042),
        ],
        brushed, piv,
    ))
    # Both installed-bay photographs leave the air-cleaner lid and badge clear.
    # The visible engine-bay braces run beside the plenum (modeled above).

    # Fasteners on top of shock towers
    bolt_pts = []
    for sx in (1.34, -1.38):
        bz = 0.666 if sx > 0 else 0.698
        for s in (-1.0, 1.0):
            for k in range(3):
                a = k * 2.0 * math.pi / 3.0 + 0.3
                bolt_pts.append((sx + 0.038 * math.cos(a), s * 0.537 + 0.038 * math.sin(a), bz))
    parts.append(_bolt_cluster("tmp_tbolts", bolt_pts, 0.006, 0.007, steel, piv, axis="z"))

    join_meshes(parts, "ZR1X_Chassis_Spaceframe", piv)


# ---------------------------------------------------------------------------
# 2. Central Structural Backbone Tunnel (housing 300V Battery)
# ---------------------------------------------------------------------------

def _build_tunnel_spine(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    steel = _m(mats, "Mat_Steel_Machined")

    parts: List[bpy.types.Object] = []
    # Twin extruded side shear walls flanking Pivot_Hybrid_Battery (Y=±0.118)
    for s in (-1.0, 1.0):
        parts.append(make_roundbox(
            "tmp_twall", (0.38, s * 0.145, 0.285), (1.36, 0.024, 0.265), cast, piv, bevel=0.006,
        ))
        # Upper diagonal tunnel reinforcement rail
        parts.append(make_roundbox(
            "tmp_tflange", (0.38, s * 0.158, 0.165), (1.38, 0.032, 0.024), brushed, piv, bevel=0.004,
        ))
    # Front and rear tunnel bulkheads sealing the battery bay
    parts.append(make_roundbox("tmp_tfwd", (1.05, 0.0, 0.285), (0.032, 0.310, 0.255), cast, piv, bevel=0.006))
    parts.append(make_roundbox("tmp_taft", (-0.29, 0.0, 0.285), (0.032, 0.310, 0.255), cast, piv, bevel=0.006))
    # Bolted lower tunnel shear plate (Spexx 126 photo shows bright bolt row flanking center spine!)
    parts.append(make_roundbox("tmp_tshear", (0.38, 0.0, 0.148), (1.36, 0.340, 0.012), brushed, piv, bevel=0.003))
    bolt_pts = [(xx, s * 0.148, 0.139) for xx in np.linspace(-0.24, 1.00, 14) for s in (-1.0, 1.0)]
    parts.append(_bolt_cluster("tmp_tbolts", bolt_pts, 0.008, 0.004, steel, piv, axis="z"))

    join_meshes(parts, "ZR1X_Chassis_TunnelSpine", piv)


# ---------------------------------------------------------------------------
# 3. Smooth Flat Aero Undertray (ZERO hanging track strakes!)
# ---------------------------------------------------------------------------

def _build_undertray(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    dark = _m(mats, "Mat_Black_Trim_Satin")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    cast = _m(mats, "Mat_Aluminum_Cast")
    steel = _m(mats, "Mat_Steel_Machined")

    parts: List[bpy.types.Object] = []

    # Main twin composite floor aero trays flanking the tunnel (Z=0.140, clean & flat)
    for s in (-1.0, 1.0):
        parts.append(make_roundbox(
            "tmp_floor_side", (0.28, s * 0.465, 0.142), (1.46, 0.560, 0.012), dark, piv, bevel=0.004,
        ))
        # Rocker edge stiffening lip (stays cleanly inside Z>=0.140)
        parts.append(make_roundbox(
            "tmp_rocker_edge", (0.24, s * 0.765, 0.148), (1.42, 0.068, 0.014), dark, piv, bevel=0.004,
        ))
        # Billet jacking lift-puck bosses (Spexx 128)
        for lx in (0.72, -0.34):
            parts.append(make_cylinder(
                "tmp_puck", (lx, s * 0.69, 0.136), (lx, s * 0.69, 0.152),
                0.032, 0.034, cast, piv, segments=18,
            ))

    # Front nose-to-axle aero underpanel (sweeps gently up behind splitter)
    front_secs = [
        [(2.14, y, 0.128) for y in np.linspace(-0.62, 0.62, 13)],
        [(1.88, y, 0.136) for y in np.linspace(-0.56, 0.56, 13)],
        [(1.62, y, 0.142) for y in np.linspace(-0.46, 0.46, 13)],
    ]
    # Extrude with 10mm thickness
    f_rows = front_secs
    for k in range(len(f_rows) - 1):
        pass
    parts.append(make_roundbox("tmp_ftray", (1.88, 0.0, 0.138), (0.56, 1.06, 0.012), dark, piv, bevel=0.004, rot_euler=(0.0, 0.025, 0.0)))

    # Front subframe bolted aluminum shear plate (Spexx 126 silver plate under front cradle)
    parts.append(make_roundbox("tmp_fshear", (1.35, 0.0, 0.144), (0.58, 0.92, 0.010), brushed, piv, bevel=0.003))

    # Rear engine/transaxle flat aero tray transitioning gently toward rear diffuser
    parts.append(make_roundbox("tmp_rtray_fwd", (-0.86, 0.0, 0.144), (0.86, 1.08, 0.012), dark, piv, bevel=0.004))
    parts.append(make_roundbox("tmp_rtray_mid", (-1.42, 0.0, 0.148), (0.48, 0.96, 0.012), brushed, piv, bevel=0.003))
    parts.append(make_roundbox(
        "tmp_rtray_aft", (-1.78, 0.0, 0.165), (0.38, 1.04, 0.012), dark, piv, bevel=0.004, rot_euler=(0.0, -0.075, 0.0),
    ))

    # Undertray mounting bolt dots
    ubolts = (
        [(xx, s * 0.42, 0.136) for xx in (1.12, 1.36, 1.58, -1.24, -1.56) for s in (-1.0, 1.0)]
        + [(xx, s * 0.72, 0.136) for xx in (-0.30, 0.10, 0.50, 0.90) for s in (-1.0, 1.0)]
    )
    parts.append(_bolt_cluster("tmp_ubolts", ubolts, 0.006, 0.003, steel, piv, axis="z"))

    join_meshes(parts, "ZR1X_Chassis_Undertray", piv)


# ---------------------------------------------------------------------------
# 4. Front & Rear Subframe Cradles (+ Steering Rack on Front)
# ---------------------------------------------------------------------------

def _build_subframes(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    gun = _m(mats, "Mat_Gear_Steel")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    rubber = _m(mats, "Mat_Rubber_Black")
    steel = _m(mats, "Mat_Steel_Machined")

    for is_rear in (False, True):
        x_axle = AXLE_R_X if is_rear else AXLE_F_X
        name = "ZR1X_Chassis_Subframe_R" if is_rear else "ZR1X_Chassis_Subframe_F"
        parts: List[bpy.types.Object] = []

        # Front & rear transverse cradle crossmembers
        for dx in (-0.238, 0.238):
            secs = []
            for y in np.linspace(-0.49, 0.49, 17):
                z = 0.204 + 0.056 * (abs(y) / 0.49) ** 2
                secs.append([
                    (x_axle + dx + u, y, z + v)
                    for u, v in (
                        (-0.032, -0.024), (0.030, -0.024), (0.038, -0.015), (0.038, 0.020),
                        (0.027, 0.030), (-0.028, 0.030), (-0.036, 0.020), (-0.036, -0.015),
                    )
                ])
            parts.append(make_loft("tmp_xmem", secs, cast, piv, auto_smooth_deg=42.0))

        # Side cradle cast rails & upper control-arm mount clevises
        for s in (-1.0, 1.0):
            y0 = s * 0.462
            parts.append(make_tube(
                "tmp_srail",
                [
                    (x_axle - 0.252, y0, 0.266),
                    (x_axle - 0.130, y0 + s * 0.024, 0.276),
                    (x_axle + 0.130, y0 + s * 0.024, 0.276),
                    (x_axle + 0.252, y0, 0.266),
                ],
                0.032, cast, piv, segments=16,
            ))
            # Subframe mounting isolator pucks
            for dx in (-0.24, 0.24):
                parts.append(make_cylinder(
                    "tmp_iso", (x_axle + dx, y0, 0.220), (x_axle + dx, y0, 0.305),
                    0.032, 0.032, gun, piv, segments=16,
                ))

        # Electric Rack-and-Pinion Steering Gear on Front Subframe (behind front axle at X=+1.18)
        if not is_rear:
            rx, rz = 1.185, 0.262
            parts.append(make_cylinder("tmp_rack_tube", (rx, -0.34, rz), (rx, 0.34, rz), 0.024, 0.024, cast, piv, segments=20))
            # EPS belt-drive motor pod on driver (+Y) side
            parts.append(make_cylinder("tmp_eps_motor", (rx + 0.045, 0.06, rz + 0.025), (rx + 0.045, 0.24, rz + 0.025), 0.040, 0.040, dark, piv, segments=20))
            parts.append(make_roundbox("tmp_eps_housing", (rx + 0.025, 0.15, rz + 0.015), (0.075, 0.060, 0.070), cast, piv, bevel=0.008))
            # Pinion input boss rising toward cabin steering column (LHD, Y=+0.34)
            parts.append(make_cylinder("tmp_pinion", (rx, 0.29, rz + 0.01), (rx - 0.08, 0.32, rz + 0.12), 0.022, 0.018, gun, piv, segments=16))
            for s in (-1.0, 1.0):
                # Convoluted rubber steering rack bellows
                b_stations = [(s * 0.34, rx, rz, 0.024, 0.024)]
                for k in range(6):
                    yy = 0.352 + k * 0.014
                    b_stations.append((s * (yy - 0.003), rx, rz, 0.018, 0.018))
                    b_stations.append((s * (yy + 0.004), rx, rz, 0.027, 0.027))
                b_stations.append((s * 0.445, rx, rz, 0.015, 0.015))
                parts.append(_ellipse_loft("tmp_rbellows", b_stations, rubber, piv, axis="y", steps=18))
                # Inner & outer tie rods to front steering knuckle arm (X=+1.22, Y=±0.735, Z=0.275)
                parts.append(make_cylinder(
                    "tmp_tierod", (rx, s * 0.44, rz), (1.225, s * 0.735, 0.274),
                    0.010, 0.010, steel, piv, segments=12,
                ))
                parts.append(make_cylinder(
                    "tmp_tr_end", (1.225, s * 0.735, 0.258), (1.225, s * 0.735, 0.290),
                    0.016, 0.014, gun, piv, segments=14,
                ))

        join_meshes(parts, name, piv)


# ---------------------------------------------------------------------------
# 5. Radiators, Charge-Cooler Cores, Fuel Tanks & Frunk Tub
# ---------------------------------------------------------------------------

def _build_radiator_unit(
    name: str,
    center: Tuple[float, float, float],
    size: Tuple[float, float, float],
    rot_euler: Tuple[float, float, float],
    piv: bpy.types.Object,
    mats: Dict[str, bpy.types.Material],
    n_fins: int = 12,
) -> None:
    core_mat = _m(mats, "Mat_Radiator_Core", "Mat_Aluminum_Brushed")
    cast = _m(mats, "Mat_Aluminum_Cast")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    parts: List[bpy.types.Object] = []

    cx, cy, cz = center
    sx, sy, sz = size
    # Main finned core block
    parts.append(make_roundbox("tmp_core", center, size, core_mat, piv, bevel=0.004, rot_euler=rot_euler))
    # Aluminum end tanks along local Y ends (or Z ends for narrow units)
    from mathutils import Euler
    rmat = Euler(rot_euler, "XYZ").to_matrix()
    c_vec = Vector(center)
    for s in (-1.0, 1.0):
        tank_off = rmat @ Vector((0.0, s * (sy * 0.5 + 0.018), 0.0))
        parts.append(make_roundbox(
            "tmp_tank", tuple(c_vec + tank_off), (sx + 0.010, 0.036, sz + 0.012),
            cast, piv, bevel=0.007, rot_euler=rot_euler,
        ))
    # Horizontal cooling tube rows across front face so they catch studio light behind grilles
    for k in range(n_fins):
        frac = -0.45 + 0.90 * k / max(1, n_fins - 1)
        off = rmat @ Vector((sx * 0.50, 0.0, frac * sz))
        parts.append(make_roundbox(
            "tmp_fin", tuple(c_vec + off), (0.006, sy * 0.96, 0.004),
            dark, piv, bevel=0.001, rot_euler=rot_euler,
        ))
    # Rear fan shroud ring
    shroud_off = rmat @ Vector((-sx * 0.55, 0.0, 0.0))
    parts.append(make_roundbox(
        "tmp_shroud", tuple(c_vec + shroud_off), (0.018, sy * 0.92, sz * 0.92),
        dark, piv, bevel=0.005, rot_euler=rot_euler,
    ))
    join_meshes(parts, name, piv)


def _build_cooling_and_fuel(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    dark = _m(mats, "Mat_Black_Trim_Satin")
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    rubber = _m(mats, "Mat_Rubber_Black")

    # 1) Center flow-through radiator (angled forward to vent straight up through ZR1X hood!)
    _build_radiator_unit(
        "ZR1X_Chassis_Radiator_Center",
        center=(1.96, 0.0, 0.335),
        size=(0.055, 0.66, 0.34),
        rot_euler=(0.0, -0.58, 0.0),
        piv=piv, mats=mats, n_fins=14,
    )
    # 2) Front Left & Right outboard radiators visible behind outer front fascia grilles
    for s, tag in ((1.0, "FL"), (-1.0, "FR")):
        _build_radiator_unit(
            f"ZR1X_Chassis_Radiator_{tag}",
            center=(1.98, s * 0.57, 0.278),
            size=(0.048, 0.26, 0.22),
            rot_euler=(0.0, -0.18, s * 0.22),
            piv=piv, mats=mats, n_fins=10,
        )
    # 3) Side-pod heat exchangers tucked behind the wishbone side air intakes
    for s, tag in ((1.0, "SideL"), (-1.0, "SideR")):
        _build_radiator_unit(
            f"ZR1X_Chassis_Radiator_{tag}",
            center=(-0.76, s * 0.785, 0.455),
            size=(0.048, 0.34, 0.28),
            rot_euler=(0.0, 0.10, s * 1.28),
            piv=piv, mats=mats, n_fins=11,
        )

    # 4) Twin C8 saddle fuel tanks behind seats / ahead of rear wheels
    for s, tag in ((1.0, "L"), (-1.0, "R")):
        fparts: List[bpy.types.Object] = []
        # Sculpted saddle bladder contour
        secs = []
        for xx, y_in, y_out, zb, zt in (
            (-0.46, 0.47, 0.67, 0.20, 0.51),
            (-0.56, 0.47, 0.72, 0.18, 0.55),
            (-0.74, 0.48, 0.72, 0.18, 0.54),
            (-0.88, 0.50, 0.68, 0.21, 0.48),
        ):
            secs.append([
                (xx, s * y_in, zb + 0.02), (xx, s * y_out, zb + 0.03),
                (xx, s * (y_out + 0.015), (zb + zt) * 0.5),
                (xx, s * (y_out - 0.02), zt), (xx, s * y_in, zt - 0.02),
                (xx, s * (y_in - 0.01), (zb + zt) * 0.5),
            ])
        fparts.append(make_loft("tmp_tank_body", secs, dark, piv, auto_smooth_deg=42.0))
        # Fuel pump locking ring on top
        fparts.append(make_cylinder(
            "tmp_pump_ring", (-0.66, s * 0.59, 0.535), (-0.66, s * 0.59, 0.558),
            0.062, 0.058, brushed, piv, segments=20,
        ))
        # Aluminum retention straps
        for sx in (-0.58, -0.78):
            fparts.append(make_tube(
                "tmp_fstrap",
                [(sx, s * 0.48, 0.185), (sx, s * 0.71, 0.185), (sx, s * 0.73, 0.48), (sx, s * 0.48, 0.53)],
                0.008, cast, piv, segments=10,
            ))
        # Driver-side (L, +Y) fuel filler neck leading to Pivot_Fuel_Flap at (-0.645, +0.950, +0.830)
        if s > 0:
            fparts.append(make_tube(
                "tmp_filler_neck",
                [(-0.66, 0.68, 0.50), (-0.655, 0.79, 0.64), (-0.648, 0.87, 0.77), (-0.645, 0.905, 0.818)],
                0.024, brushed, piv, segments=16,
            ))
            fparts.append(make_cylinder(
                "tmp_filler_cap", (-0.645, 0.895, 0.812), (-0.645, 0.922, 0.824),
                0.032, 0.030, dark, piv, segments=18,
            ))
            # Lower crossover transfer tube connecting L & R saddle tanks under bulkhead
            fparts.append(make_tube(
                "tmp_crossover",
                [(-0.56, 0.48, 0.24), (-0.50, 0.20, 0.20), (-0.50, -0.20, 0.20), (-0.56, -0.48, 0.24)],
                0.018, rubber, piv, segments=12,
            ))
        join_meshes(fparts, f"ZR1X_Chassis_FuelTank_{tag}", piv)

    # 5) Compact Front Flow-Through Radiator Exit Shroud / Frunk Service Tub
    # Sits cleanly above Front EDU (Z<=0.48) and tucked well below sloping ZR1X front hood!
    tparts: List[bpy.types.Object] = []
    tparts.append(make_roundbox("tmp_shroud_back", (1.58, 0.0, 0.515), (0.022, 0.74, 0.095), dark, piv, bevel=0.005, rot_euler=(0.0, -0.32, 0.0)))
    tparts.append(make_roundbox("tmp_shroud_floor", (1.72, 0.0, 0.475), (0.30, 0.74, 0.016), dark, piv, bevel=0.004, rot_euler=(0.0, -0.16, 0.0)))
    for s in (-1.0, 1.0):
        tparts.append(make_roundbox("tmp_shroud_side", (1.72, s * 0.37, 0.505), (0.34, 0.020, 0.088), dark, piv, bevel=0.005, rot_euler=(0.0, 0.14, 0.0)))
    # Forward strut-tower cowl service tray
    tparts.append(make_roundbox("tmp_cowl_tray", (1.22, 0.0, 0.530), (0.34, 0.80, 0.016), dark, piv, bevel=0.005))
    tparts.append(make_cylinder("tmp_brake_res", (1.16, 0.34, 0.540), (1.16, 0.34, 0.605), 0.034, 0.032, brushed, piv, segments=16))
    join_meshes(tparts, "ZR1X_Chassis_FrunkTub", piv)


# ---------------------------------------------------------------------------
# 6. SLA Control Arms, Coilovers, ARBs & CV Half-Shafts
# ---------------------------------------------------------------------------

def _build_suspension_and_shafts(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    gun = _m(mats, "Mat_Gear_Steel")
    steel = _m(mats, "Mat_Steel_Machined")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    rubber = _m(mats, "Mat_Rubber_Black")
    spring_mat = _m(mats, "Mat_Spring_Red", "Mat_Torch_Red_GKZ")

    for is_rear in (False, True):
        x_axle = AXLE_R_X if is_rear else AXLE_F_X
        z_hub = TIRE_R_R if is_rear else TIRE_R_F
        ax_code = "R" if is_rear else "F"

        for s, side_code in ((1.0, "L"), (-1.0, "R")):
            tag = f"{ax_code}{side_code}"

            # --- Upper SLA Wishbone (ZR1X_Susp_UpperArm_*) ---
            uparts: List[bpy.types.Object] = []
            u_inner, u_outer, u_z, u_span = 0.508, 0.738, 0.474, 0.130
            for fore in (-1.0, 1.0):
                secs = []
                for u, w, d in ((0.0, 0.028, 0.020), (0.15, 0.026, 0.020), (0.55, 0.022, 0.016), (0.85, 0.025, 0.017), (1.0, 0.032, 0.022)):
                    xx = x_axle + (1.0 - u) ** 1.2 * fore * u_span
                    yy = s * ((1.0 - u) * u_inner + u * u_outer)
                    zz = u_z + 0.048 * u
                    secs.append([(xx + w * math.cos(t), yy, zz + d * math.sin(t))
                                 for t in np.linspace(0, 2 * math.pi, 14, endpoint=False)])
                uparts.append(make_loft("tmp_uarm", secs, cast, piv))
                px = x_axle + fore * u_span
                uparts.append(_ellipse_loft(
                    "tmp_ubush", [(px - 0.025, s * u_inner, u_z, 0.028, 0.028), (px + 0.025, s * u_inner, u_z, 0.028, 0.028)],
                    rubber, piv, axis="x", steps=16,
                ))
                uparts.append(_ellipse_loft(
                    "tmp_usleeve", [(px - 0.028, s * u_inner, u_z, 0.011, 0.011), (px + 0.028, s * u_inner, u_z, 0.011, 0.011)],
                    steel, piv, axis="x", steps=12,
                ))
            # Outer ball-joint boss & rubber boot
            uparts.append(make_cylinder("tmp_ubj", (x_axle, s * u_outer, u_z + 0.025), (x_axle, s * u_outer, u_z + 0.068), 0.024, 0.020, cast, piv, segments=16))
            uparts.append(make_cylinder("tmp_uboot", (x_axle, s * u_outer, u_z + 0.010), (x_axle, s * u_outer, u_z + 0.032), 0.014, 0.020, rubber, piv, segments=14))
            join_meshes(uparts, f"ZR1X_Susp_UpperArm_{tag}", piv)

            # --- Lower SLA Webbed Cast A-Arm (ZR1X_Susp_LowerArm_*, Spexx 131/133 photo-matched!) ---
            lparts: List[bpy.types.Object] = []
            l_inner, l_outer, l_z, l_span = 0.448, 0.753, 0.224, 0.202
            for fore in (-1.0, 1.0):
                secs = []
                for u, w, d in ((0.0, 0.034, 0.024), (0.14, 0.034, 0.024), (0.45, 0.028, 0.020), (0.78, 0.030, 0.019), (1.0, 0.038, 0.024)):
                    xx = x_axle + (1.0 - u) ** 1.25 * fore * l_span
                    yy = s * ((1.0 - u) * l_inner + u * l_outer)
                    zz = l_z - 0.012 * math.sin(math.pi * u) + 0.006 * u
                    secs.append([(xx + w * math.cos(t), yy, zz + d * math.sin(t))
                                 for t in np.linspace(0, 2 * math.pi, 16, endpoint=False)])
                lparts.append(make_loft("tmp_larm", secs, cast, piv))
                px = x_axle + fore * l_span
                lparts.append(_ellipse_loft(
                    "tmp_lbush", [(px - 0.028, s * l_inner, l_z, 0.032, 0.032), (px + 0.028, s * l_inner, l_z, 0.032, 0.032)],
                    rubber, piv, axis="x", steps=16,
                ))
                lparts.append(_ellipse_loft(
                    "tmp_lsleeve", [(px - 0.032, s * l_inner, l_z, 0.012, 0.012), (px + 0.032, s * l_inner, l_z, 0.012, 0.012)],
                    steel, piv, axis="x", steps=12,
                ))
            # Characteristic C8 cross-rib webbing framing the triangulated cutout window (Spexx 131)
            lparts.append(make_roundbox(
                "tmp_lweb", (x_axle, s * 0.565, l_z - 0.004), (0.215, 0.056, 0.016), cast, piv, bevel=0.004,
            ))
            # Damper lower clevis bracket on lower arm
            lparts.append(make_roundbox(
                "tmp_lclevis", (x_axle + 0.021, s * 0.678, l_z + 0.016), (0.046, 0.044, 0.032), cast, piv, bevel=0.004,
            ))
            # Outer lower ball-joint boss & boot
            lparts.append(make_cylinder("tmp_lbj", (x_axle, s * l_outer, l_z - 0.016), (x_axle, s * l_outer, l_z + 0.032), 0.026, 0.022, cast, piv, segments=16))
            lparts.append(make_cylinder("tmp_lboot", (x_axle, s * l_outer, l_z + 0.028), (x_axle, s * l_outer, l_z + 0.048), 0.020, 0.014, rubber, piv, segments=14))
            # Rear dedicated forged aluminum toe-link (Spexx 133 shows thick silver toe-link!)
            if is_rear:
                lparts.append(make_cylinder(
                    "tmp_toelink", (x_axle - 0.165, s * 0.455, 0.260), (x_axle - 0.125, s * 0.745, 0.275),
                    0.013, 0.013, brushed, piv, segments=14,
                ))
            join_meshes(lparts, f"ZR1X_Susp_LowerArm_{tag}", piv)

            # --- Magnetic Ride 4.0 Coilover Damper & Spring (ZR1X_Susp_Coilover_*) ---
            cparts: List[bpy.types.Object] = []
            lower = Vector((x_axle + 0.021, s * 0.682, 0.238))
            upper = Vector((x_axle + (0.043 if not is_rear else -0.020), s * 0.537, 0.660 if is_rear else 0.630))
            axis = (upper - lower).normalized()
            unit = axis.cross(Vector((1.0, 0.0, 0.0))).normalized()
            other = axis.cross(unit).normalized()

            def _sleeve(profile: Sequence[Tuple[float, float]], mat: bpy.types.Material) -> bpy.types.Object:
                rings = [
                    [tuple(lower.lerp(upper, t) + (unit * math.cos(q) + other * math.sin(q)) * r)
                     for q in np.linspace(0, 2 * math.pi, 22, endpoint=False)]
                    for t, r in profile
                ]
                return make_loft("tmp_slv", rings, mat, piv, auto_smooth_deg=42.0)

            # Monotube damper body (black anodized) + threaded collar + chrome rod + perches
            cparts.append(_sleeve(((0.0, 0.020), (0.10, 0.027), (0.55, 0.027), (0.59, 0.020), (0.65, 0.019)), dark))
            cparts.append(_sleeve(((0.52, 0.0095), (0.92, 0.0095)), steel))
            cparts.append(_sleeve(((0.17, 0.028), (0.20, 0.053), (0.226, 0.055), (0.242, 0.043)), brushed))
            cparts.append(_sleeve(((0.83, 0.046), (0.855, 0.054), (0.90, 0.053), (0.95, 0.028), (1.0, 0.024)), dark))
            # Helical ZTK road spring (6.0 active coils)
            coil_pts = []
            for t in np.linspace(0.0, 1.0, 125):
                ang = t * 2.0 * math.pi * 5.8
                rr = 0.0445 - 0.0025 * abs(t - 0.5) * 2.0
                p = lower.lerp(upper, 0.222 + t * 0.625) + (unit * math.cos(ang) + other * math.sin(ang)) * rr
                coil_pts.append((p.x, p.y, p.z))
            cparts.append(make_tube("tmp_coil", coil_pts, 0.0074, spring_mat, piv, segments=10))
            join_meshes(cparts, f"ZR1X_Susp_Coilover_{tag}", piv)

            # --- CV Half-Shafts & Convoluted Rubber Boots (ZR1X_Drive_Halfshaft_*) ---
            hparts: List[bpy.types.Object] = []
            y_in_flange = 0.208 if not is_rear else 0.214
            r_shaft = 0.018 if not is_rear else 0.021
            # Inner CV joint housing bolted to EDU (front) or DCT eLSD (rear)
            hparts.append(_ellipse_loft(
                "tmp_in_cv",
                [(s * y, x_axle, z_hub, r, r) for y, r in (
                    (y_in_flange - 0.016, 0.058), (y_in_flange, 0.064), (y_in_flange + 0.032, 0.052), (y_in_flange + 0.046, 0.038),
                )],
                cast, piv, axis="y", steps=24,
            ))
            # Solid machined steel drive shaft
            hparts.append(_ellipse_loft(
                "tmp_shaft",
                [(s * y, x_axle, z_hub, r, r) for y, r in (
                    (y_in_flange + 0.038, r_shaft), (0.725, r_shaft), (0.755, r_shaft + 0.006), (0.790, r_shaft + 0.003),
                )],
                gun, piv, axis="y", steps=20,
            ))
            # Inner & outer 5-convolute rubber CV boots
            for start_y, is_inner_boot in ((y_in_flange + 0.044, True), (0.668, False)):
                b_prof = [(start_y, 0.036)]
                for n in range(5):
                    rr = (0.039 - 0.0022 * n) if is_inner_boot else (0.030 + 0.0024 * n)
                    b_prof.append((start_y + 0.013 * n + 0.003, rr - 0.0055))
                    b_prof.append((start_y + 0.013 * n + 0.008, rr + 0.0055))
                b_prof.append((start_y + 0.072, 0.024 if is_inner_boot else 0.040))
                hparts.append(_ellipse_loft(
                    "tmp_cvboot",
                    [(s * y, x_axle, z_hub, r, r) for y, r in b_prof],
                    rubber, piv, axis="y", steps=22,
                ))
            # Outer CV tulip & hub spline shoulder meeting Pivot_Corner_* upright
            hparts.append(_ellipse_loft(
                "tmp_out_cv",
                [(s * y, x_axle, z_hub, r, r) for y, r in (
                    (0.738, 0.036), (0.758, 0.045), (0.782, 0.045), (0.798, 0.028), (0.822, 0.024),
                )],
                cast, piv, axis="y", steps=22,
            ))
            join_meshes(hparts, f"ZR1X_Drive_Halfshaft_{tag}", piv)

        # --- Front & Rear Tubular Anti-Roll Bars (ZR1X_Susp_ARB_F/R) ---
        arb_parts: List[bpy.types.Object] = []
        dir_sign = -1.0 if not is_rear else 1.0  # Front ARB sits aft of front axle; rear sits fwd of rear axle
        arb_pts = [
            (x_axle + dir_sign * 0.115, -0.665, 0.265),
            (x_axle + dir_sign * 0.255, -0.600, 0.268),
            (x_axle + dir_sign * 0.275, -0.460, 0.282),
            (x_axle + dir_sign * 0.275, 0.460, 0.282),
            (x_axle + dir_sign * 0.255, 0.600, 0.268),
            (x_axle + dir_sign * 0.115, 0.665, 0.265),
        ]
        arb_parts.append(make_tube("tmp_arb", arb_pts, 0.0135, dark, piv, segments=14))
        for s in (-1.0, 1.0):
            # Subframe bushing clamps
            arb_parts.append(make_roundbox(
                "tmp_arb_bush", (x_axle + dir_sign * 0.275, s * 0.41, 0.282), (0.042, 0.046, 0.042),
                rubber, piv, bevel=0.005,
            ))
            # Vertical ball-jointed end-link to lower arm
            arb_parts.append(make_cylinder(
                "tmp_endlink",
                (x_axle + dir_sign * 0.115, s * 0.665, 0.265),
                (x_axle + dir_sign * 0.095, s * 0.655, 0.220),
                0.006, 0.006, steel, piv, segments=10,
            ))
        join_meshes(arb_parts, f"ZR1X_Susp_ARB_{ax_code}", piv)


def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Populate ``Pivot_Drivetrain_Chassis`` with spaceframe, undertray, cooling, fuel & suspension."""
    piv = pivots["Pivot_Drivetrain_Chassis"]
    _build_spaceframe(piv, mats)
    _build_tunnel_spine(piv, mats)
    _build_undertray(piv, mats)
    _build_subframes(piv, mats)
    _build_cooling_and_fuel(piv, mats)
    _build_suspension_and_shafts(piv, mats)
