"""Shared rig, coordinate, parenting, and clean-mesh helpers for ZR1X v2.

Implements the authoritative 23-pivot hierarchy and coordinate conventions
defined in ``v2_rig_spec.md`` (V2 Blender meters: +X forward, +Y left, +Z up,
origin on the ground plane at mid-wheelbase).

Module contract for all builders (``ext_*.py``, ``mech_*.py``, ``cabin_build.py``):
    def build(pivots: dict[str, bpy.types.Object], mats: dict[str, bpy.types.Material]) -> None
"""

from __future__ import annotations

import math
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import bmesh
import bpy
from mathutils import Euler, Matrix, Vector


# ---------------------------------------------------------------------------
# Authoritative V2 Vehicle Dimensions & Rig Specs (v2_rig_spec.md)
# ---------------------------------------------------------------------------

SCALE_1_18: float = 1000.0 / 18.0  # 55.5555555556 (1 viewer unit = 18 mm)

WHEELBASE: float = 2.723
AXLE_F_X: float = 1.3615
AXLE_R_X: float = -1.3615
TRACK_F: float = 1.685
TRACK_R: float = 1.678
TRACK_F_HALF: float = 0.8425
TRACK_R_HALF: float = 0.8390
TIRE_R_F: float = 0.3365
TIRE_R_R: float = 0.3530
OVERALL_LENGTH: float = 4.860
BODY_WIDTH: float = 2.024
MIRROR_WIDTH: float = 2.145
ROOF_HEIGHT: float = 1.234
WING_HEIGHT: float = 1.285

RIG_ROOT_NAME: str = "ZR1X_Interactive_Rig"

# Ordered list of (pivot_name, parent_name, world_pos_blender_meters).
# Matches v2_rig_spec.md Section 3 verbatim (23 Pivot_* empties).
PIVOT_SPECS: Tuple[Tuple[str, str, Tuple[float, float, float]], ...] = (
    ("Pivot_Drivetrain_Chassis", RIG_ROOT_NAME, (0.000, 0.000, 0.000)),
    ("Pivot_Body_Assembly",      RIG_ROOT_NAME, (0.000, 0.000, 0.000)),
    ("Pivot_Door_L",             "Pivot_Body_Assembly", (0.930, 0.840, 0.640)),
    ("Pivot_Door_R",             "Pivot_Body_Assembly", (0.930, -0.840, 0.640)),
    ("Pivot_Front_Hood",         "Pivot_Body_Assembly", (1.055, 0.000, 0.805)),
    ("Pivot_Rear_Hatch",         "Pivot_Body_Assembly", (-0.375, 0.000, 1.205)),
    ("Pivot_Roof_Panel",         "Pivot_Body_Assembly", (0.000, 0.000, 1.190)),
    ("Pivot_Fuel_Flap",          "Pivot_Body_Assembly", (-0.645, 0.950, 0.830)),
    ("Pivot_ZTK_Wing",           "Pivot_Body_Assembly", (-1.900, 0.000, 1.050)),
    ("Pivot_Interior_Cabin",     RIG_ROOT_NAME, (0.000, 0.000, 0.000)),
    ("Pivot_LT7_Engine",         RIG_ROOT_NAME, (-0.820, 0.000, 0.520)),
    ("Pivot_DCT_Transaxle",      RIG_ROOT_NAME, (-1.520, 0.000, 0.410)),
    ("Pivot_Front_EDU",          RIG_ROOT_NAME, (1.3615, 0.000, 0.350)),
    ("Pivot_Hybrid_Battery",     RIG_ROOT_NAME, (0.380, 0.000, 0.280)),
    ("Pivot_Exhaust_System",     RIG_ROOT_NAME, (-1.650, 0.000, 0.320)),
    ("Pivot_Corner_FL",          RIG_ROOT_NAME, (1.3615, 0.8425, 0.3365)),
    ("Pivot_WheelSpin_FL",       "Pivot_Corner_FL", (1.3615, 0.8425, 0.3365)),
    ("Pivot_Corner_FR",          RIG_ROOT_NAME, (1.3615, -0.8425, 0.3365)),
    ("Pivot_WheelSpin_FR",       "Pivot_Corner_FR", (1.3615, -0.8425, 0.3365)),
    ("Pivot_Corner_RL",          RIG_ROOT_NAME, (-1.3615, 0.8390, 0.3530)),
    ("Pivot_WheelSpin_RL",       "Pivot_Corner_RL", (-1.3615, 0.8390, 0.3530)),
    ("Pivot_Corner_RR",          RIG_ROOT_NAME, (-1.3615, -0.8390, 0.3530)),
    ("Pivot_WheelSpin_RR",       "Pivot_Corner_RR", (-1.3615, -0.8390, 0.3530)),
)

PIVOT_WORLD_POS: Dict[str, Tuple[float, float, float]] = {
    name: pos for name, _, pos in PIVOT_SPECS
}
PIVOT_WORLD_POS[RIG_ROOT_NAME] = (0.0, 0.0, 0.0)


# ---------------------------------------------------------------------------
# Coordinate Conversion Helpers
# ---------------------------------------------------------------------------

def legacy_to_v2(pt: Sequence[float]) -> Tuple[float, float, float]:
    """Convert legacy corvette_zr1x_work coords (+X tail, -Y left, +Z up) to V2 (+X fwd, +Y left, +Z up)."""
    return (-float(pt[0]), -float(pt[1]), float(pt[2]))


def ref_to_v2(pt: Sequence[float], z_ground_shift: float = 0.0049) -> Tuple[float, float, float]:
    """Convert 2025 reference GLB coords (0.01x m; +Z fwd, +Y up, +X left) to V2 Blender meters."""
    return (100.0 * float(pt[2]), 100.0 * float(pt[0]), 100.0 * float(pt[1]) + z_ground_shift)


def v2_to_gltf_mm(pt: Sequence[float]) -> Tuple[float, float, float]:
    """Convert V2 Blender meters (+X fwd, +Y left, +Z up) to 1:18-mm glTF (+X fwd, +Y up, +Z right)."""
    return (SCALE_1_18 * float(pt[0]), SCALE_1_18 * float(pt[2]), -SCALE_1_18 * float(pt[1]))


# ---------------------------------------------------------------------------
# Rig Creation & Parenting
# ---------------------------------------------------------------------------

def create_rig(scene: Optional[bpy.types.Scene] = None) -> Dict[str, bpy.types.Object]:
    """Create ``ZR1X_Interactive_Rig`` and all 23 ``Pivot_*`` empties at exact V2 meter coords."""
    sc = scene or bpy.context.scene
    col = sc.collection
    pivots: Dict[str, bpy.types.Object] = {}

    root = bpy.data.objects.new(RIG_ROOT_NAME, None)
    root.empty_display_type = "PLAIN_AXES"
    root.empty_display_size = 0.25
    root.location = (0.0, 0.0, 0.0)
    root.rotation_euler = (0.0, 0.0, 0.0)
    root.scale = (1.0, 1.0, 1.0)
    col.objects.link(root)
    pivots[RIG_ROOT_NAME] = root

    for name, parent_name, world_pos in PIVOT_SPECS:
        parent = pivots[parent_name]
        parent_world = Vector(PIVOT_WORLD_POS[parent_name])
        local_pos = Vector(world_pos) - parent_world

        emp = bpy.data.objects.new(name, None)
        emp.empty_display_type = "PLAIN_AXES"
        emp.empty_display_size = 0.12
        emp.parent = parent
        emp.matrix_parent_inverse.identity()
        emp.location = tuple(local_pos)
        emp.rotation_euler = (0.0, 0.0, 0.0)
        emp.scale = (1.0, 1.0, 1.0)
        col.objects.link(emp)
        pivots[name] = emp

    return pivots


def pivot_world_pos(pivot: Optional[bpy.types.Object]) -> Vector:
    """Return the exact world position of ``pivot`` in V2 Blender meters."""
    if pivot is None:
        return Vector((0.0, 0.0, 0.0))
    if pivot.name in PIVOT_WORLD_POS:
        return Vector(PIVOT_WORLD_POS[pivot.name])
    pos = Vector(pivot.location)
    cur = pivot.parent
    while cur is not None:
        pos += Vector(cur.location)
        cur = cur.parent
    return pos


def world_to_pivot_local(pt: Sequence[float], pivot: Optional[bpy.types.Object]) -> Tuple[float, float, float]:
    """Convert a V2 world point (m) into ``pivot``-local coordinates."""
    origin = pivot_world_pos(pivot)
    return (float(pt[0]) - origin.x, float(pt[1]) - origin.y, float(pt[2]) - origin.z)


def parent_to_pivot(
    obj: bpy.types.Object,
    pivot: bpy.types.Object,
    coords_are_world: bool = False,
    scene: Optional[bpy.types.Scene] = None,
) -> bpy.types.Object:
    """Parent ``obj`` cleanly under ``pivot`` with identity parent inverse."""
    sc = scene or bpy.context.scene
    if obj.name not in sc.collection.objects:
        sc.collection.objects.link(obj)
    obj.parent = pivot
    obj.matrix_parent_inverse.identity()
    if coords_are_world:
        origin = pivot_world_pos(pivot)
        obj.location = (obj.location.x - origin.x, obj.location.y - origin.y, obj.location.z - origin.z)
    return obj


# ---------------------------------------------------------------------------
# Smooth Shading, Normals & UV Helpers
# ---------------------------------------------------------------------------

def set_smooth(obj: bpy.types.Object, auto_smooth_deg: Optional[float] = None) -> bpy.types.Object:
    """Apply smooth shading, optionally preserving sharp creases via EDGE_SPLIT."""
    if obj.type != "MESH" or obj.data is None:
        return obj
    me = obj.data
    n_polys = len(me.polygons)
    if n_polys > 0:
        me.polygons.foreach_set("use_smooth", [True] * n_polys)
    if auto_smooth_deg is not None and 0.0 < auto_smooth_deg < 180.0:
        mod = obj.modifiers.get("AutoSmoothSplit") or obj.modifiers.new("AutoSmoothSplit", "EDGE_SPLIT")
        mod.use_edge_angle = True
        mod.split_angle = math.radians(auto_smooth_deg)
        mod.use_edge_sharp = True
    me.update()
    return obj


def ensure_outward_normals(obj: bpy.types.Object) -> bpy.types.Object:
    """Recalculate consistent outward face normals on a mesh object."""
    if obj.type != "MESH" or obj.data is None or len(obj.data.polygons) == 0:
        return obj
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return obj


def box_project_uv(
    obj: bpy.types.Object,
    scale: float = 6.0,
    layer_name: str = "UVMap",
) -> bpy.types.Object:
    """Assign clean uniform-scale tri-planar box UVs so woven/grain PBR maps tile cleanly."""
    if obj.type != "MESH" or obj.data is None:
        return obj
    me = obj.data
    uv_layer = me.uv_layers.get(layer_name) or me.uv_layers.new(name=layer_name)
    verts = me.vertices
    for poly in me.polygons:
        nx, ny, nz = abs(poly.normal.x), abs(poly.normal.y), abs(poly.normal.z)
        for li in poly.loop_indices:
            co = verts[me.loops[li].vertex_index].co
            if nz >= nx and nz >= ny:
                u, v = co.x * scale, co.y * scale
            elif nx >= ny:
                u, v = co.y * scale, co.z * scale
            else:
                u, v = co.x * scale, co.z * scale
            uv_layer.data[li].uv = (u, v)
    return obj


def apply_modifiers(obj: bpy.types.Object) -> bpy.types.Object:
    """Bake all modifiers onto ``obj.data`` in-place without needing viewport selection."""
    if obj.type != "MESH" or not obj.modifiers:
        return obj
    depsgraph = bpy.context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    new_mesh = bpy.data.meshes.new_from_object(
        eval_obj, preserve_all_data_layers=True, depsgraph=depsgraph
    )
    old_mesh = obj.data
    saved_name = old_mesh.name
    obj.modifiers.clear()
    obj.data = new_mesh
    if old_mesh.users == 0:
        bpy.data.meshes.remove(old_mesh)
    new_mesh.name = saved_name
    return obj


# ---------------------------------------------------------------------------
# Clean Parametric Mesh Builders
# ---------------------------------------------------------------------------

def make_mesh(
    name: str,
    verts: Sequence[Sequence[float]],
    faces: Sequence[Sequence[int]],
    mat: Optional[bpy.types.Material],
    pivot: bpy.types.Object,
    world_coords: bool = True,
    smooth: bool = True,
    auto_smooth_deg: Optional[float] = None,
    uv_scale: Optional[float] = None,
    recalc_normals: bool = False,
) -> bpy.types.Object:
    """Create a mesh object parented to ``pivot`` with vertices stored in pivot-local space."""
    origin = pivot_world_pos(pivot) if world_coords else Vector((0.0, 0.0, 0.0))
    local_verts = [(float(v[0]) - origin.x, float(v[1]) - origin.y, float(v[2]) - origin.z) for v in verts]

    me = bpy.data.meshes.new(name)
    me.from_pydata(local_verts, [], [tuple(f) for f in faces])
    if mat is not None:
        me.materials.append(mat)
    me.update()

    obj = bpy.data.objects.new(name, me)
    parent_to_pivot(obj, pivot, coords_are_world=False)
    if recalc_normals:
        ensure_outward_normals(obj)
    if smooth:
        set_smooth(obj, auto_smooth_deg=auto_smooth_deg)
    if uv_scale is not None:
        box_project_uv(obj, scale=uv_scale)
    return obj


def make_surface_grid(
    name: str,
    rows: Sequence[Sequence[Sequence[float]]],
    mat: Optional[bpy.types.Material],
    pivot: bpy.types.Object,
    world_coords: bool = True,
    smooth: bool = True,
    auto_smooth_deg: Optional[float] = None,
    solidify: float = 0.0,
    solidify_offset: float = 0.0,
    uv_scale: Optional[float] = None,
) -> bpy.types.Object:
    """Create a clean quad grid surface from an (R x C) grid of 3D points."""
    n_rows = len(rows)
    n_cols = len(rows[0])
    verts = [pt for row in rows for pt in row]
    faces = [
        (r * n_cols + c, (r + 1) * n_cols + c, (r + 1) * n_cols + c + 1, r * n_cols + c + 1)
        for r in range(n_rows - 1)
        for c in range(n_cols - 1)
    ]
    obj = make_mesh(
        name, verts, faces, mat, pivot,
        world_coords=world_coords, smooth=smooth,
        auto_smooth_deg=auto_smooth_deg, uv_scale=uv_scale,
    )
    if solidify > 0.0:
        mod = obj.modifiers.new("Solidify", "SOLIDIFY")
        mod.thickness = solidify
        mod.offset = solidify_offset
        mod.use_even_offset = True
    return obj


def make_loft(
    name: str,
    sections: Sequence[Sequence[Sequence[float]]],
    mat: Optional[bpy.types.Material],
    pivot: bpy.types.Object,
    cyclic_u: bool = True,
    cap_ends: bool = True,
    world_coords: bool = True,
    smooth: bool = True,
    auto_smooth_deg: Optional[float] = None,
    uv_scale: Optional[float] = None,
    recalc_normals: bool = True,
) -> bpy.types.Object:
    """Loft a closed or open quad tube across a sequence of equal-length point rings."""
    n_sec = len(sections)
    n_ring = len(sections[0])
    verts = [pt for sec in sections for pt in sec]
    faces: List[Tuple[int, ...]] = []

    span = n_ring if cyclic_u else n_ring - 1
    for j in range(n_sec - 1):
        for i in range(span):
            ni = (i + 1) % n_ring
            faces.append((j * n_ring + i, j * n_ring + ni, (j + 1) * n_ring + ni, (j + 1) * n_ring + i))

    if cap_ends and cyclic_u and n_ring >= 3:
        faces.append(tuple(range(n_ring - 1, -1, -1)))
        faces.append(tuple(range((n_sec - 1) * n_ring, n_sec * n_ring)))

    return make_mesh(
        name, verts, faces, mat, pivot,
        world_coords=world_coords, smooth=smooth,
        auto_smooth_deg=auto_smooth_deg, uv_scale=uv_scale,
        recalc_normals=recalc_normals,
    )


def make_tube(
    name: str,
    points: Sequence[Sequence[float]],
    radius: float,
    mat: Optional[bpy.types.Material],
    pivot: bpy.types.Object,
    segments: int = 12,
    cyclic: bool = False,
    cap_ends: bool = True,
    world_coords: bool = True,
    smooth: bool = True,
    uv_scale: Optional[float] = None,
) -> bpy.types.Object:
    """Sweep a smooth circular mesh tube along a 3D polyline (zero Curve bloat)."""
    pts = [Vector(p) for p in points]
    n_pts = len(pts)
    assert n_pts >= 2, f"make_tube({name}) requires >= 2 points"

    sections: List[List[Tuple[float, float, float]]] = []
    prev_n: Optional[Vector] = None
    for idx, p in enumerate(pts):
        if cyclic:
            tang = pts[(idx + 1) % n_pts] - pts[(idx - 1) % n_pts]
        elif idx == 0:
            tang = pts[1] - pts[0]
        elif idx == n_pts - 1:
            tang = pts[-1] - pts[-2]
        else:
            tang = pts[idx + 1] - pts[idx - 1]
        if tang.length < 1e-9:
            tang = Vector((1.0, 0.0, 0.0))
        else:
            tang.normalize()

        if prev_n is None:
            ref = Vector((0.0, 0.0, 1.0)) if abs(tang.z) < 0.92 else Vector((1.0, 0.0, 0.0))
            n_vec = tang.cross(ref).normalized()
        else:
            # Parallel transport to avoid twist flips
            n_vec = prev_n - tang * prev_n.dot(tang)
            if n_vec.length < 1e-6:
                ref = Vector((0.0, 0.0, 1.0)) if abs(tang.z) < 0.92 else Vector((1.0, 0.0, 0.0))
                n_vec = tang.cross(ref).normalized()
            else:
                n_vec.normalize()
        b_vec = tang.cross(n_vec).normalized()
        prev_n = n_vec

        ring = []
        for s in range(segments):
            a = 2.0 * math.pi * s / segments
            pt = p + (n_vec * math.cos(a) + b_vec * math.sin(a)) * radius
            ring.append((pt.x, pt.y, pt.z))
        sections.append(ring)

    if cyclic:
        sections.append(sections[0])
        cap_ends = False

    return make_loft(
        name, sections, mat, pivot,
        cyclic_u=True, cap_ends=cap_ends,
        world_coords=world_coords, smooth=smooth, uv_scale=uv_scale,
    )


def make_roundbox(
    name: str,
    center: Sequence[float],
    size: Sequence[float],
    mat: Optional[bpy.types.Material],
    pivot: bpy.types.Object,
    bevel: float = 0.008,
    segments: int = 3,
    rot_euler: Sequence[float] = (0.0, 0.0, 0.0),
    world_coords: bool = True,
    smooth: bool = True,
    auto_smooth_deg: Optional[float] = 38.0,
    uv_scale: Optional[float] = None,
) -> bpy.types.Object:
    """Create a beveled box directly in bmesh with vertices baked in pivot-local space."""
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    sx, sy, sz = float(size[0]), float(size[1]), float(size[2])
    bmesh.ops.scale(bm, vec=(sx, sy, sz), verts=bm.verts)

    if bevel > 0.0:
        max_b = 0.45 * min(sx, sy, sz)
        b_w = min(bevel, max_b)
        if b_w > 1e-5:
            bmesh.ops.bevel(
                bm,
                geom=list(bm.edges),
                offset=b_w,
                offset_type="OFFSET",
                segments=segments,
                profile=0.5,
                affect="EDGES",
                clamp_overlap=True,
            )

    rot_mat = Euler(tuple(rot_euler), "XYZ").to_matrix().to_4x4()
    local_center = Vector(world_to_pivot_local(center, pivot)) if world_coords else Vector(center)
    xform = Matrix.Translation(local_center) @ rot_mat
    bmesh.ops.transform(bm, matrix=xform, verts=bm.verts)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    if mat is not None:
        me.materials.append(mat)
    me.update()

    obj = bpy.data.objects.new(name, me)
    parent_to_pivot(obj, pivot, coords_are_world=False)
    if smooth:
        set_smooth(obj, auto_smooth_deg=auto_smooth_deg)
    if uv_scale is not None:
        box_project_uv(obj, scale=uv_scale)
    return obj


def make_cylinder(
    name: str,
    p0: Sequence[float],
    p1: Sequence[float],
    r0: float,
    r1: Optional[float],
    mat: Optional[bpy.types.Material],
    pivot: bpy.types.Object,
    segments: int = 24,
    cap_ends: bool = True,
    world_coords: bool = True,
    smooth: bool = True,
    auto_smooth_deg: Optional[float] = 40.0,
    uv_scale: Optional[float] = None,
) -> bpy.types.Object:
    """Create a tapered or straight cylinder connecting ``p0`` to ``p1``."""
    v0 = Vector(world_to_pivot_local(p0, pivot)) if world_coords else Vector(p0)
    v1 = Vector(world_to_pivot_local(p1, pivot)) if world_coords else Vector(p1)
    axis = v1 - v0
    length = axis.length
    assert length > 1e-7, f"make_cylinder({name}) degenerate zero length"
    r_end = r0 if r1 is None else r1

    bm = bmesh.new()
    bmesh.ops.create_cone(
        bm,
        cap_ends=cap_ends,
        cap_tris=False,
        segments=segments,
        radius1=r0,
        radius2=r_end,
        depth=length,
    )
    mid = (v0 + v1) * 0.5
    quat = Vector((0.0, 0.0, 1.0)).rotation_difference(axis.normalized())
    xform = Matrix.Translation(mid) @ quat.to_matrix().to_4x4()
    bmesh.ops.transform(bm, matrix=xform, verts=bm.verts)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    if mat is not None:
        me.materials.append(mat)
    me.update()

    obj = bpy.data.objects.new(name, me)
    parent_to_pivot(obj, pivot, coords_are_world=False)
    if smooth:
        set_smooth(obj, auto_smooth_deg=auto_smooth_deg)
    if uv_scale is not None:
        box_project_uv(obj, scale=uv_scale)
    return obj


def join_meshes(
    objs: Sequence[bpy.types.Object],
    name: str,
    pivot: Optional[bpy.types.Object] = None,
    auto_smooth_deg: Optional[float] = None,
) -> bpy.types.Object:
    """Merge multiple mesh objects into one single cleanly-named mesh under ``pivot``.

    Preserves per-face material slots, smooth flags, and UVs cleanly via bmesh,
    baking any active modifiers first, and removes the temporary input objects.
    """
    valid = [o for o in objs if o is not None and o.type == "MESH"]
    assert valid, f"join_meshes({name}) received no mesh objects"
    target_pivot = pivot or valid[0].parent
    assert target_pivot is not None, f"join_meshes({name}) requires a target pivot"

    # Ensure depsgraph is current for world transforms / modifiers
    bpy.context.view_layer.update()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    pivot_inv = target_pivot.matrix_world.inverted()

    combined_mats: List[bpy.types.Material] = []
    mat_index_map: Dict[str, int] = {}

    bm_out = bmesh.new()
    uv_out = bm_out.loops.layers.uv.new("UVMap")

    for ob in valid:
        eval_ob = ob.evaluated_get(depsgraph)
        me = bpy.data.meshes.new_from_object(
            eval_ob, preserve_all_data_layers=True, depsgraph=depsgraph
        )
        if me is None or len(me.vertices) == 0:
            if me is not None:
                bpy.data.meshes.remove(me)
            continue

        # Build local -> target_pivot transform
        xform = pivot_inv @ ob.matrix_world

        # Map material slots from this object into combined_mats
        slot_remap: Dict[int, int] = {}
        for slot_i, mat in enumerate(me.materials):
            if mat is None:
                continue
            if mat.name not in mat_index_map:
                mat_index_map[mat.name] = len(combined_mats)
                combined_mats.append(mat)
            slot_remap[slot_i] = mat_index_map[mat.name]

        bm_tmp = bmesh.new()
        bm_tmp.from_mesh(me)
        bpy.data.meshes.remove(me)
        bmesh.ops.transform(bm_tmp, matrix=xform, verts=bm_tmp.verts)
        uv_tmp = bm_tmp.loops.layers.uv.active

        v_map = {v: bm_out.verts.new(v.co) for v in bm_tmp.verts}
        for f in bm_tmp.faces:
            try:
                nf = bm_out.faces.new([v_map[v] for v in f.verts])
            except ValueError:
                continue
            nf.smooth = f.smooth
            nf.material_index = slot_remap.get(f.material_index, 0)
            if uv_tmp is not None:
                for l_src, l_dst in zip(f.loops, nf.loops):
                    l_dst[uv_out].uv = l_src[uv_tmp].uv

        bm_tmp.free()

    # Remove old input objects & orphan meshes
    for ob in valid:
        old_me = ob.data
        bpy.data.objects.remove(ob, do_unlink=True)
        if old_me and old_me.users == 0:
            bpy.data.meshes.remove(old_me)

    if name in bpy.data.meshes:
        old = bpy.data.meshes[name]
        if old.users == 0:
            bpy.data.meshes.remove(old)

    out_me = bpy.data.meshes.new(name)
    bm_out.to_mesh(out_me)
    bm_out.free()
    for m in combined_mats:
        out_me.materials.append(m)
    out_me.update()

    out_obj = bpy.data.objects.new(name, out_me)
    parent_to_pivot(out_obj, target_pivot, coords_are_world=False)
    if auto_smooth_deg is not None:
        set_smooth(out_obj, auto_smooth_deg=auto_smooth_deg)
    return out_obj


if __name__ == "__main__":
    bpy.ops.wm.read_factory_settings(use_empty=True)
    pivs = create_rig()
    pivot_only = [k for k in pivs if k.startswith("Pivot_")]
    assert len(pivot_only) == 23, f"Expected 23 Pivot_* nodes, got {len(pivot_only)}"
    bpy.context.view_layer.update()
    for pname, _, expected in PIVOT_SPECS:
        actual = pivs[pname].matrix_world.translation
        err = (actual - Vector(expected)).length
        assert err < 1e-6, f"Pivot {pname} mismatch: expected {expected}, got {tuple(actual)}"
    print(f"rig_utils.py OK: verified {len(pivot_only)} Pivot_* empties at exact V2 coordinates.")
