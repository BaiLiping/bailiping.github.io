"""2027 Chevrolet Corvette ZR1X 3LZ Jet Black (HTE) 3-Screen Cabin Builder (v2).

Implements ``build(pivots, mats)`` populating ``Pivot_Interior_Cabin`` (plus
the door-mounted brushed-metal switch pods & BOSE speaker grilles on
``Pivot_Door_L`` / ``Pivot_Door_R``) in authoritative V2 Blender meters
(+X forward, +Y left/driver, +Z up, ground Z=0, origin mid-wheelbase).

Benchmarked directly against the 2027 3LZ Jet Black (HTE) cube panoramas and
real 2027 ZR1X interior walkaround photographs:
- Redesigned 2026/2027 curved 3-screen cockpit:
  * 6.6" left aux telemetry screen (ZR1X_Cabin_DisplayAux, clear of A-pillar!)
  * 14" curved driver instrument cluster (ZR1X_Cabin_DisplayCluster)
  * 12.7" angled center touchscreen (ZR1X_Cabin_DisplayCenter)
- Horizontal brushed-aluminum 10-toggle HVAC strip below the 12.7" screen
  (NO old 2025 wall of buttons!)
- Open 2027 center console with P-R-N-D-M shifter island, drive-mode scroll
  selector + front-lift / camera buttons, wireless charger, dual chrome-rimmed
  cupholders, carbon inlay, and stitched passenger grab-handle ridge
- Flat-top / flat-bottom 2x2 carbon-fiber + Napa leather steering wheel with
  red 12-o'clock band, crisp 3D ZR1X 6-o'clock plaque, crossed-flags horn pad,
  spoke switches, carbon shift paddles, and steering column + stalks
- Brushed-aluminum 3-piece sport pedals (dead pedal + brake + organ throttle)
- Brushed-metal door armrest switch pods + BOSE perforated speaker grilles
- GT2 bucket seats split cleanly into ZR1X_Cabin_SeatShell_L/R (carbon halo,
  rails, belts, headrest) and ZR1X_Cabin_SeatCushion_L/R (perforated leather +
  bolsters, lifting +10 u on explode!)
- Sculpted rear bulkhead with center brushed-metal BOSE dome & CORVETTE/ZR1X
  plaque + clear rear bulkhead glass (ZR1X_Glass_CabinBulkhead)
- Frameless interior rearview mirror with pure planar Mat_Cabin_Rearview glass
  (ZR1X_Cabin_RearviewMirror) for mirror-reflection.js
"""

from __future__ import annotations

import math
import sys
from math import cos, pi, sin
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import bpy
import numpy as np

_THIS_DIR = str(Path(__file__).resolve().parent)
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

from rig_utils import (
    box_project_uv,
    join_meshes,
    make_cylinder,
    make_loft,
    make_mesh,
    make_roundbox,
    make_surface_grid,
    make_tube,
    set_smooth,
)


# ---------------------------------------------------------------------------
# Internal Geometry Utilities
# ---------------------------------------------------------------------------

def _catmull_rom_closed(points: Sequence[Sequence[float]], steps: int = 5) -> np.ndarray:
    pts = np.asarray(points, dtype=float)
    n = len(pts)
    out = []
    for k in range(n):
        a = pts[(k - 1) % n]
        b = pts[k]
        c = pts[(k + 1) % n]
        d = pts[(k + 2) % n]
        for s in range(steps):
            t = s / float(steps)
            out.append(
                0.5 * (
                    (2.0 * b)
                    + (-a + c) * t
                    + (2.0 * a - 5.0 * b + 4.0 * c - d) * (t * t)
                    + (-a + 3.0 * b - 3.0 * c + d) * (t * t * t)
                )
            )
    return np.asarray(out, dtype=float)


def _rounded_rect_2d(cx: float, cy: float, lx: float, ly: float, rad: float, segs: int = 6) -> List[Tuple[float, float]]:
    r = min(rad, 0.45 * lx, 0.45 * ly)
    pts: List[Tuple[float, float]] = []
    corners = (
        (lx * 0.5 - r, ly * 0.5 - r, 0.0),
        (-lx * 0.5 + r, ly * 0.5 - r, 90.0),
        (-lx * 0.5 + r, -ly * 0.5 + r, 180.0),
        (lx * 0.5 - r, -ly * 0.5 + r, 270.0),
    )
    for ox, oy, deg0 in corners:
        for i in range(segs + 1):
            a = math.radians(deg0 + 90.0 * i / segs)
            pts.append((cx + ox + r * cos(a), cy + oy + r * sin(a)))
    return pts


def _vector_letter_strokes(char: str) -> List[List[Tuple[float, float]]]:
    """Minimal crisp geometric strokes in [0..1] x [0..1] for embossed ZR1X / CORVETTE lettering."""
    ch = char.upper()
    strokes: Dict[str, List[List[Tuple[float, float]]]] = {
        "Z": [[(0.05, 0.92), (0.95, 0.92), (0.05, 0.08), (0.95, 0.08)]],
        "R": [
            [(0.12, 0.06), (0.12, 0.94), (0.76, 0.94), (0.90, 0.78), (0.90, 0.62), (0.74, 0.48), (0.12, 0.48)],
            [(0.52, 0.48), (0.92, 0.06)],
        ],
        "1": [[(0.28, 0.78), (0.54, 0.94), (0.54, 0.06)], [(0.24, 0.06), (0.82, 0.06)]],
        "X": [[(0.08, 0.94), (0.92, 0.06)], [(0.92, 0.94), (0.08, 0.06)]],
        "P": [[(0.15, 0.08), (0.15, 0.92), (0.76, 0.92), (0.88, 0.76), (0.88, 0.58), (0.74, 0.46), (0.15, 0.46)]],
        "N": [[(0.14, 0.08), (0.14, 0.92), (0.86, 0.08), (0.86, 0.92)]],
        "D": [[(0.14, 0.08), (0.14, 0.92), (0.64, 0.92), (0.88, 0.70), (0.88, 0.30), (0.64, 0.08), (0.14, 0.08)]],
        "M": [[(0.08, 0.08), (0.08, 0.92), (0.50, 0.38), (0.92, 0.92), (0.92, 0.08)]],
        "C": [[(0.88, 0.80), (0.68, 0.94), (0.28, 0.94), (0.12, 0.72), (0.12, 0.28), (0.28, 0.06), (0.68, 0.06), (0.88, 0.20)]],
        "O": [[(0.30, 0.94), (0.70, 0.94), (0.88, 0.72), (0.88, 0.28), (0.70, 0.06), (0.30, 0.06), (0.12, 0.28), (0.12, 0.72), (0.30, 0.94)]],
        "V": [[(0.10, 0.94), (0.50, 0.06), (0.90, 0.94)]],
        "E": [[(0.86, 0.92), (0.16, 0.92), (0.16, 0.08), (0.86, 0.08)], [(0.16, 0.50), (0.72, 0.50)]],
        "T": [[(0.08, 0.92), (0.92, 0.92)], [(0.50, 0.92), (0.50, 0.08)]],
    }
    return strokes.get(ch, [])


def _add_stroke_text(
    parts: List[bpy.types.Object],
    text: str,
    origin_fn,
    char_w: float,
    char_h: float,
    gap: float,
    radius: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    italic: float = 0.0,
) -> None:
    """Create crisp 3D beveled tube lettering mapped onto an arbitrary surface via ``origin_fn(u, v)``."""
    total_w = len(text) * char_w + max(0, len(text) - 1) * gap
    u_start = -total_w * 0.5
    for idx, ch in enumerate(text):
        u0 = u_start + idx * (char_w + gap)
        for stroke in _vector_letter_strokes(ch):
            pts = [
                origin_fn(u0 + (su + italic * sv) * char_w, (sv - 0.5) * char_h)
                for su, sv in stroke
            ]
            if len(pts) >= 2:
                parts.append(make_tube(f"_txt_{ch}_{idx}", pts, radius, mat, pivot, segments=6))


# ---------------------------------------------------------------------------
# 1. Floor Tub & Molded Carpet (ZR1X_Cabin_Tub, ZR1X_Cabin_Carpet)
# ---------------------------------------------------------------------------

# Floor section stations in V2 meters: (x_fwd, half_width, base_z, tunnel_crown_z)
_FLOOR_STATIONS = (
    ( 0.965, 0.600, 0.308, 0.490),
    ( 0.880, 0.645, 0.257, 0.460),
    ( 0.770, 0.664, 0.246, 0.437),
    ( 0.600, 0.677, 0.243, 0.415),
    ( 0.340, 0.686, 0.241, 0.402),
    ( 0.100, 0.688, 0.238, 0.394),
    (-0.120, 0.684, 0.240, 0.387),
    (-0.290, 0.663, 0.251, 0.401),
    (-0.402, 0.617, 0.300, 0.449),
)


def _build_tub_and_carpet(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    cab = pivots["Pivot_Interior_Cabin"]
    tub_parts: List[bpy.types.Object] = []
    carpet_parts: List[bpy.types.Object] = []

    # Structural cockpit floor pan (wraps around the central battery spine cleanly)
    pan_rows = []
    for xx, w, base, crown in _FLOOR_STATIONS:
        half = [
            (0.0, crown), (0.104, crown - 0.003), (0.140, crown - 0.024),
            (0.161, base + 0.091), (0.177, base + 0.035), (0.199, base + 0.009),
            (0.235, base + 0.001), (0.370, base),
            (w - 0.111, base + 0.004), (w - 0.078, base + 0.016),
            (w - 0.052, base + 0.043), (w - 0.034, base + 0.087),
            (w - 0.030, base + 0.128), (w - 0.019, base + 0.140), (w, base + 0.144),
        ]
        cross = [(-y, z) for y, z in reversed(half[1:])] + half
        pan_rows.append([(xx, y, z) for y, z in cross])
    tub_parts.append(
        make_surface_grid("_pan", pan_rows, mats["Mat_Black_Trim_Satin"], cab, solidify=0.011, solidify_offset=-1.0)
    )

    # Sloped toe boards & wheelhouse kick panels (left +Y = driver, right -Y = passenger)
    for sign in (1.0, -1.0):
        rows = []
        for yy, fwd_shift in (
            (0.166, 0.009), (0.190, 0.016), (0.230, 0.023), (0.340, 0.027),
            (0.500, 0.023), (0.554, 0.015), (0.590, -0.004), (0.620, -0.035), (0.647, -0.072),
        ):
            profile = (
                (0.703, 0.269), (0.790, 0.283), (0.836, 0.310), (0.868, 0.357),
                (0.902, 0.430), (0.927, 0.518), (0.933, 0.598), (0.918, 0.627),
            )
            rows.append([(x + fwd_shift, sign * yy, z) for x, z in profile])
        tub_parts.append(
            make_surface_grid(f"_toe_{int(sign)}", rows, mats["Mat_Black_Trim_Satin"], cab, solidify=0.009)
        )

    # Inner rocker sill scuff trim plates (left/right doorway entry lips)
    for sign in (1.0, -1.0):
        tub_parts.append(
            make_roundbox(
                f"_sill_{int(sign)}",
                (0.24, sign * 0.675, 0.378),
                (1.12, 0.048, 0.022),
                mats["Mat_Black_Trim_Satin"],
                cab,
                bevel=0.005,
            )
        )
        # Brushed aluminum Corvette sill kick plate strip
        tub_parts.append(
            make_roundbox(
                f"_sill_plate_{int(sign)}",
                (0.26, sign * 0.678, 0.390),
                (0.62, 0.028, 0.004),
                mats["Mat_Aluminum_Brushed"],
                cab,
                bevel=0.001,
            )
        )

    join_meshes(tub_parts, "ZR1X_Cabin_Tub", cab, auto_smooth_deg=42.0)

    # Molded footwell carpet basins + stitched overmats + retaining posts
    for sign in (1.0, -1.0):
        rows = []
        for xx, w, base, crown in _FLOOR_STATIONS:
            level = 0.288 + max(0.0, xx - 0.79) * 0.31 + max(0.0, -xx - 0.22) * 0.13
            profile = (
                (0.166, level + 0.049), (0.180, level + 0.020), (0.202, level + 0.003),
                (0.250, level), (0.430, level), (w - 0.098, level + 0.001),
                (w - 0.070, level + 0.011), (w - 0.045, level + 0.040), (w - 0.039, level + 0.072),
            )
            rows.append([(xx, sign * y, z) for y, z in profile])
        carpet_parts.append(
            make_surface_grid(f"_carpet_basin_{int(sign)}", rows, mats["Mat_Carpet_Black"], cab, solidify=0.006)
        )

        # Contoured floor overmat with contrast bound edge & dual retaining discs
        mat_outline = (
            (0.770, 0.214), (0.790, 0.475), (0.680, 0.584), (0.440, 0.579),
            (0.146, 0.540), (0.123, 0.280), (0.390, 0.215),
        )
        sec_lo = [(x, sign * y, 0.292) for x, y in mat_outline]
        sec_hi = [(x, sign * y, 0.301) for x, y in mat_outline]
        carpet_parts.append(make_loft(f"_overmat_{int(sign)}", [sec_lo, sec_hi], mats["Mat_Carpet_Black"], cab))
        carpet_parts.append(
            make_tube(f"_overmat_edge_{int(sign)}", sec_hi, 0.0032, mats["Mat_Stitch_Gray"], cab, segments=8, cyclic=True)
        )
        for yy in (0.265, 0.497):
            carpet_parts.append(
                make_cylinder(
                    f"_retainer_{int(sign)}_{yy:.2f}",
                    (0.45, sign * yy, 0.299),
                    (0.45, sign * yy, 0.305),
                    0.015,
                    0.014,
                    mats["Mat_Black_Trim_Satin"],
                    cab,
                    segments=18,
                )
            )

    join_meshes(carpet_parts, "ZR1X_Cabin_Carpet", cab)


# ---------------------------------------------------------------------------
# 2. Rear Bulkhead, Rear Center ZR1X Speaker Plaque & Bulkhead Glass
# ---------------------------------------------------------------------------

def _back_window_pt(y: float, z: float) -> Tuple[float, float, float]:
    # Legacy x = +0.491 + 0.172*(z-0.78) - 0.048*(|y|/0.63)^2 -> V2 x = -x_legacy
    x = -(0.491 + 0.172 * (z - 0.78) - 0.048 * (abs(y) / 0.63) ** 2)
    return (x, y, z)


def _build_bulkhead(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    cab = pivots["Pivot_Interior_Cabin"]
    parts: List[bpy.types.Object] = []

    # Contoured Jet Black rear bulkhead partition below the cabin rear window
    rows = []
    for yy in np.linspace(-0.669, 0.669, 29):
        a = abs(yy) / 0.669
        lower = 0.261 + 0.119 * math.exp(-((yy / 0.19) ** 2))
        shoulder = 0.760 + 0.093 * (a ** 4)
        xx = -(0.452 - 0.094 * (a ** 3))
        rows.append([
            (xx + 0.063, yy, lower),
            (xx + 0.042, yy, lower + 0.066),
            (xx + 0.014, yy, 0.490 + 0.030 * a),
            (xx - 0.014, yy, 0.609 + 0.040 * a),
            (xx - 0.020, yy, shoulder - 0.068),
            (xx - 0.021, yy, shoulder - 0.024),
            (xx - 0.043, yy, shoulder),
            (xx - 0.076, yy, shoulder + 0.011),
        ])
    parts.append(
        make_surface_grid("_bulkhead_wall", rows, mats["Mat_Leather_JetBlack_HTE"], cab, solidify=0.014, uv_scale=4.0)
    )

    # Rear quarter/B-pillar interior surrounds flanking the rear bulkhead window
    for side in (-1.0, 1.0):
        qrows = []
        for t in np.linspace(0.0, 1.0, 13):
            inner = 0.576 + 0.043 * sin(pi * t) - 0.061 * t
            outer = 0.671 - 0.105 * t
            z = 0.788 + 0.265 * t
            qrows.append([
                _back_window_pt(side * y, z - dz)
                for y, dz in (
                    (inner, 0.0), (inner + 0.009, -0.004),
                    ((inner + outer) * 0.5, -0.009), (outer, -0.008), (outer + 0.012, 0.006),
                )
            ])
        parts.append(
            make_surface_grid(f"_bulk_surround_{int(side)}", qrows, mats["Mat_Leather_JetBlack_HTE"], cab, solidify=0.011, uv_scale=4.0)
        )

    # Rear cabin window weatherstrip perimeter
    rim: List[Tuple[float, float, float]] = []
    for y in np.linspace(-0.56, 0.56, 41):
        rim.append(_back_window_pt(y, 0.769 + 0.019 * (y / 0.56) ** 2))
    for t in np.linspace(0.0, 1.0, 9)[1:]:
        rim.append(_back_window_pt(0.56 + 0.043 * sin(pi * t) - 0.061 * t, 0.788 + 0.265 * t))
    for y in np.linspace(0.499, -0.499, 37)[1:]:
        rim.append(_back_window_pt(y, 1.053 + 0.017 * (1.0 - (y / 0.499) ** 2)))
    for t in np.linspace(0.0, 1.0, 9)[1:-1]:
        rim.append(_back_window_pt(-(0.56 + 0.043 * sin(pi * (1.0 - t)) - 0.061 * (1.0 - t)), 1.053 - 0.265 * t))
    parts.append(make_tube("_bulk_weatherstrip", rim, 0.010, mats["Mat_Rubber_Black"], cab, segments=10, cyclic=True))

    # Signature 2027 ZR1X rear center brushed-metal BOSE speaker dome + CORVETTE / ZR1X plaque
    # (visible between the two seatbacks in HTE/03-back.jpg & 110-zr1x-interior-plaque.jpg)
    dome_rows = []
    for v_t in np.linspace(0.0, 1.0, 9):
        z = 0.655 + 0.115 * v_t
        hw = 0.115 - 0.022 * (v_t - 0.45) ** 2 * 4.0
        row = []
        for u_t in np.linspace(-1.0, 1.0, 13):
            y = u_t * hw
            bulge = 0.028 * math.cos(u_t * pi * 0.48) * math.sin(v_t * pi * 0.85 + 0.15)
            x = -0.435 + 0.018 * (1.0 - v_t) + bulge
            row.append((x, y, z))
        dome_rows.append(row)
    parts.append(make_surface_grid("_rear_speaker_dome", dome_rows, mats["Mat_Aluminum_Brushed"], cab, solidify=0.008))

    # Brushed silver trapezoid plaque inset on front lip of the rear speaker dome
    plaque_center = (-0.398, 0.0, 0.688)
    parts.append(
        make_roundbox(
            "_rear_zr1x_bezel",
            plaque_center,
            (0.012, 0.112, 0.036),
            mats["Mat_Aluminum_Brushed"],
            cab,
            bevel=0.004,
            rot_euler=(0.0, -0.35, 0.0),
        )
    )
    parts.append(
        make_roundbox(
            "_rear_corvette_strip",
            (-0.393, 0.0, 0.699),
            (0.008, 0.078, 0.010),
            mats["Mat_Black_Trim_Gloss"],
            cab,
            bevel=0.002,
            rot_euler=(0.0, -0.35, 0.0),
        )
    )
    # Embossed 3D 'ZR1X' lettering on rear bulkhead plaque (facing +X forward; looking aft, +Y is right!)
    _add_stroke_text(
        parts,
        "ZR1X",
        lambda u, v: (-0.390 + v * 0.34, u, 0.682 + v),
        char_w=0.014,
        char_h=0.011,
        gap=0.004,
        radius=0.0012,
        mat=mats["Mat_Badge_DarkChrome"],
        pivot=cab,
        italic=0.18,
    )

    join_meshes(parts, "ZR1X_Cabin_Bulkhead", cab, auto_smooth_deg=42.0)

    # Clear rear bulkhead glass window (ZR1X_Glass_CabinBulkhead)
    center = tuple(np.mean(np.asarray(rim), axis=0))
    n_rim = len(rim)
    g_verts = [center] + rim
    g_faces = [(0, i + 1, (i + 1) % n_rim + 1) for i in range(n_rim)]
    make_mesh(
        "ZR1X_Glass_CabinBulkhead",
        g_verts,
        g_faces,
        mats["Mat_Glass_Bulkhead"],
        cab,
        smooth=True,
        recalc_normals=False,
    )


# ---------------------------------------------------------------------------
# 3. 2027 3-Screen Curved Cockpit Dashboard + Brushed-Aluminum HVAC Strip
# ---------------------------------------------------------------------------

def _dash_station(y: float) -> Tuple[float, float, float]:
    """Return (x_rear_lip, z_top, z_bottom) of the swept dash carrier in V2 meters.
    Note: y > 0 is driver (left), y < 0 is passenger (right).
    """
    # Converted from legacy dash_stations via (-X_old, -Y_old, Z_old), sorted ascending by Y_v2
    stations = np.array([
        (-0.690, 0.720, 0.753, 0.654),
        (-0.610, 0.680, 0.770, 0.642),
        (-0.490, 0.650, 0.783, 0.624),
        (-0.340, 0.632, 0.793, 0.611),
        (-0.240, 0.646, 0.796, 0.604),
        (-0.170, 0.664, 0.799, 0.601),
        ( 0.000, 0.641, 0.810, 0.616),
        ( 0.150, 0.622, 0.815, 0.634),
        ( 0.300, 0.606, 0.820, 0.646),
        ( 0.430, 0.596, 0.824, 0.651),
        ( 0.550, 0.583, 0.816, 0.650),
        ( 0.614, 0.583, 0.809, 0.646),
        ( 0.675, 0.596, 0.784, 0.636),
        ( 0.708, 0.671, 0.747, 0.620),
    ], dtype=float)
    return (
        float(np.interp(y, stations[:, 0], stations[:, 1])),
        float(np.interp(y, stations[:, 0], stations[:, 2])),
        float(np.interp(y, stations[:, 0], stations[:, 3])),
    )


def _build_screen_mesh(
    name: str,
    grid_rows: Sequence[Sequence[Tuple[float, float, float]]],
    screen_mat: bpy.types.Material,
    bezel_mat: bpy.types.Material,
    pivot: bpy.types.Object,
    bezel_depth: float = 0.014,
    bezel_pad: float = 0.0055,
) -> bpy.types.Object:
    """Build a crisp curved or flat display mesh with upright [0..1] UVs + slim gloss bezel backing."""
    n_v = len(grid_rows)
    n_u = len(grid_rows[0])
    # Display front face (grid_rows[row][col] goes row 0=bottom..n_v-1=top, col 0=left..n_u-1=right
    # from the driver's perspective looking forward +X: left = higher +Y, right = lower Y)
    verts = [pt for row in grid_rows for pt in row]
    faces = []
    for r in range(n_v - 1):
        for c in range(n_u - 1):
            # Winding ensures normal points backward (-X) toward the driver's eye
            a = r * n_u + c
            b = r * n_u + c + 1
            d = (r + 1) * n_u + c + 1
            e = (r + 1) * n_u + c
            faces.append((a, e, d, b))

    scr = make_mesh(f"_{name}_face", verts, faces, screen_mat, pivot, smooth=True, recalc_normals=False)
    uv_layer = scr.data.uv_layers.new(name="UVMap")
    for poly in scr.data.polygons:
        for li in poly.loop_indices:
            vi = scr.data.loops[li].vertex_index
            r, c = divmod(vi, n_u)
            u = c / float(n_u - 1)
            v = r / float(n_v - 1)
            uv_layer.data[li].uv = (u, v)

    # Slim sculpted black glass bezel & rear housing behind the active display face
    # Expand outer perimeter slightly and extrude forward (+X) into the dash
    arr = np.asarray(grid_rows, dtype=float)
    center = arr.mean(axis=(0, 1))
    # Build perimeter ring (bottom -> right -> top -> left)
    perim_pts = (
        list(arr[0, :])
        + list(arr[1:, -1])
        + list(arr[-1, -2::-1])
        + list(arr[-2:0:-1, 0])
    )
    outer_front = []
    outer_back = []
    for pt in perim_pts:
        dv = pt - center
        dv_yz = np.array([0.0, dv[1], dv[2]])
        norm_yz = np.linalg.norm(dv_yz)
        expand = (dv_yz / norm_yz * bezel_pad) if norm_yz > 1e-6 else np.zeros(3)
        p_front = pt + expand + np.array([0.0018, 0.0, 0.0])  # 1.8 mm behind active glass
        p_back = p_front + np.array([bezel_depth, 0.0, 0.0])
        outer_front.append(tuple(p_front))
        outer_back.append(tuple(p_back))

    # Open perimeter bezel ring (cap_ends=False so a flat n-gon NEVER slices across a concave display!)
    # plus a matching curved rear backing plate strictly behind the display.
    bezel_ring = make_loft(f"_{name}_bezel", [outer_front, outer_back], bezel_mat, pivot, cap_ends=False, auto_smooth_deg=35.0)
    back_verts = [tuple(pt + np.array([bezel_depth, 0.0, 0.0])) for row in arr for pt in row]
    back_faces = [
        (r * n_u + c, r * n_u + c + 1, (r + 1) * n_u + c + 1, (r + 1) * n_u + c)
        for r in range(n_v - 1)
        for c in range(n_u - 1)
    ]
    back_plate = make_mesh(f"_{name}_back", back_verts, back_faces, bezel_mat, pivot, smooth=True, recalc_normals=False)
    return join_meshes([scr, bezel_ring, back_plate], name, pivot)


def _build_dash_and_screens(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    cab = pivots["Pivot_Interior_Cabin"]
    dash_parts: List[bpy.types.Object] = []

    # 1. Padded Napa leather upper dashboard deck extending to the windshield cowl
    # (converted cleanly from HTE panorama-fitted pad_edge to V2 meters, sorted ascending by Y_v2)
    pad_edge = np.array([
        (-0.690, 0.720, 0.754),
        (-0.615, 0.683, 0.770),
        (-0.510, 0.654, 0.780),
        (-0.390, 0.658, 0.791),
        (-0.280, 0.705, 0.795),
        (-0.019, 0.687, 0.822),
        ( 0.194, 0.672, 0.824),
        ( 0.387, 0.657, 0.826),
        ( 0.574, 0.641, 0.825),
        ( 0.630, 0.636, 0.824),
        ( 0.680, 0.642, 0.806),
        ( 0.708, 0.665, 0.790),
    ], dtype=float)

    upper_rows = []
    for yy in np.linspace(-0.690, 0.708, 72):
        xx = float(np.interp(yy, pad_edge[:, 0], pad_edge[:, 1]))
        # Keep the upper dash rear lip cleanly ABOVE and slightly FORWARD of all 3 screens
        if yy >= 0.520:
            # Left 6.6" aux zone: sweep smoothly above the beveled aux display (no overhang clipping!)
            t_aux = min(1.0, (yy - 0.520) / (0.655 - 0.520))
            xx = max(xx, 0.680 - 0.052 * t_aux)
            topline = 0.858 - 0.030 * t_aux
        elif yy >= 0.185:
            # 14" driver cluster binnacle hood cleanly clears top of cluster (Z_top=0.852)
            t_clu = (yy - 0.185) / (0.520 - 0.185)
            xx = 0.672 + 0.012 * sin(pi * t_clu)
            topline = 0.862 + 0.016 * sin(pi * t_clu)
        elif yy >= -0.095:
            # 12.7" center touchscreen top lip
            t_ctr = (0.185 - yy) / (0.185 - (-0.095))
            xx = max(xx, 0.685 - 0.088 * t_ctr)
            topline = 0.844 - 0.014 * t_ctr
        else:
            topline = float(np.interp(yy, pad_edge[:, 0], pad_edge[:, 2])) + 0.008
        w = abs(yy) / 0.71
        front = 1.295 - 0.175 * (w ** 1.45)
        cowl_z = 0.764 + 0.019 * (w ** 3)
        ridge_z = min(topline - 0.004, 0.820 + max(0.0, topline - 0.820) * 0.65)
        upper_rows.append([
            (front, yy, cowl_z),
            (front - 0.030, yy, cowl_z + 0.010),
            (0.76 * front + 0.24 * xx, yy, (cowl_z + ridge_z) * 0.5 + 0.006),
            (0.52 * front + 0.48 * xx, yy, ridge_z - 0.004),
            (0.26 * front + 0.74 * xx, yy, ridge_z + 0.004),
            (xx + 0.046, yy, topline - 0.003),
            (xx + 0.020, yy, topline + 0.002),
            (xx + 0.006, yy, topline),
            (xx + 0.002, yy, topline - 0.008),
            (xx + 0.006, yy, topline - 0.014),
        ])
    dash_parts.append(
        make_surface_grid("_dash_upper", upper_rows, mats["Mat_Leather_JetBlack_HTE"], cab, solidify=0.007, uv_scale=4.0)
    )

    # Twin passenger-side contrast seams along upper dashboard lip
    for inset in (0.022, 0.029):
        seam_pts = []
        for yy in np.linspace(-0.665, -0.180, 36):
            xx = float(np.interp(yy, pad_edge[:, 0], pad_edge[:, 1]))
            zz = float(np.interp(yy, pad_edge[:, 0], pad_edge[:, 2])) + 0.008
            seam_pts.append((xx + inset, yy, zz + 0.003))
        dash_parts.append(make_tube(f"_dash_seam_{inset:.3f}", seam_pts, 0.0011, mats["Mat_Stitch_Gray"], cab, segments=6))

    # Swept structural lower dashboard carrier & knee bolster — strictly FORWARD (+X) behind all 3 screens!
    carrier_secs = []
    for yy in np.linspace(-0.690, 0.695, 55):
        xx, top_z, bot_z = _dash_station(yy)
        w = abs(yy) / 0.71
        front = 0.960 - 0.115 * (w ** 2)
        # Keep structural backing strictly forward (+X) of Aux, Cluster & Center glass + bezels!
        rear_x = max(xx + 0.045, 0.728 if (-0.11 <= yy <= 0.67) else xx + 0.035)
        carrier_secs.append([
            (rear_x + 0.030, yy, top_z - 0.008),
            (rear_x, yy, top_z - 0.022),
            (rear_x, yy, top_z - 0.068),
            (rear_x + 0.016, yy, bot_z + 0.018),
            (rear_x + 0.052, yy, bot_z),
            (front - 0.068, yy, bot_z + 0.022),
            (front - 0.006, yy, top_z - 0.060),
            (front - 0.006, yy, top_z - 0.042),
        ])
    dash_parts.append(make_loft("_dash_carrier", carrier_secs, mats["Mat_Black_Trim_Satin"], cab, auto_smooth_deg=45.0))

    # Sculpted stitched leather shelf directly under the 3 screens (matching 103 & HTE/01-front)
    shelf_secs = []
    for yy in np.linspace(-0.110, 0.658, 42):
        if yy >= 0.520:
            t = (yy - 0.520) / (0.658 - 0.520)
            sx = 0.662 - 0.052 * t
            sz = 0.726 - 0.010 * t
        elif yy >= 0.190:
            t = (yy - 0.190) / (0.520 - 0.190)
            sx = 0.662 + 0.012 * sin(pi * t)
            sz = 0.726 + 0.004 * sin(pi * t)
        else:
            t = (0.190 - yy) / (0.190 - (-0.110))
            sx = 0.674 - 0.092 * t
            sz = 0.678 - 0.006 * t
        shelf_secs.append([
            (sx + 0.065, yy, sz + 0.002),
            (sx - 0.022, yy, sz + 0.001),
            (sx - 0.030, yy, sz - 0.006),
            (sx - 0.020, yy, sz - 0.021),
            (sx + 0.050, yy, sz - 0.023),
        ])
    dash_parts.append(make_loft("_dash_shelf", shelf_secs, mats["Mat_Leather_JetBlack_HTE"], cab, uv_scale=4.0))

    # Crisp contrast stitching along the driver-side under-screen leather lip (visible in 103)
    lip_stitch = []
    for yy in np.linspace(0.515, 0.650, 16):
        t = (yy - 0.520) / (0.658 - 0.520)
        sx = 0.662 - 0.052 * max(0.0, t)
        sz = 0.726 - 0.010 * max(0.0, t)
        lip_stitch.append((sx - 0.021, yy, sz + 0.0025))
    dash_parts.append(make_tube("_aux_shelf_stitch", lip_stitch, 0.0011, mats["Mat_Stitch_Gray"], cab, segments=6))

    # Exposed 2x2 carbon-fiber binnacle hood & angled divider pillar between 6.6" Aux & 14" Cluster
    binnacle_secs = []
    for yy in np.linspace(0.185, 0.532, 24):
        t = (yy - 0.185) / (0.532 - 0.185)
        bx = 0.664 + 0.014 * sin(pi * t)
        bz = 0.858 + 0.014 * sin(pi * t)
        binnacle_secs.append([
            (bx + 0.055, yy, bz + 0.007),
            (bx - 0.028, yy, bz + 0.004),
            (bx - 0.032, yy, bz - 0.004),
            (bx + 0.052, yy, bz - 0.006),
        ])
    dash_parts.append(make_loft("_binnacle_carbon_brow", binnacle_secs, mats["Mat_Carbon_Twill_2x2"], cab, uv_scale=12.0))

    # Angled glossy carbon divider rib separating Left 6.6" Aux and Center 14" Cluster (103 photo!)
    div_secs = []
    for t in np.linspace(0.0, 1.0, 10):
        zz = 0.728 + 0.128 * t
        yy = 0.526 - 0.010 * t
        xx = 0.660 + 0.012 * t
        div_secs.append([
            (xx + 0.028, yy + 0.008, zz),
            (xx - 0.012, yy + 0.006, zz),
            (xx - 0.014, yy - 0.006, zz),
            (xx + 0.028, yy - 0.008, zz),
        ])
    dash_parts.append(make_loft("_aux_cluster_divider", div_secs, mats["Mat_Carbon_Twill_2x2"], cab, uv_scale=14.0))

    # Brushed-aluminum accent blade under Left 6.6" aux vent (visible in HTE/01-front & 103)
    left_vent_secs = []
    for yy in np.linspace(0.515, 0.662, 14):
        t = (yy - 0.515) / (0.662 - 0.515)
        vx = 0.662 - 0.054 * t
        vz = 0.688 - 0.010 * t
        left_vent_secs.append([
            (vx + 0.030, yy, vz + 0.007),
            (vx - 0.024, yy, vz + 0.005),
            (vx - 0.026, yy, vz - 0.005),
            (vx + 0.026, yy, vz - 0.007),
        ])
    dash_parts.append(make_loft("_left_vent_blade", left_vent_secs, mats["Mat_Aluminum_Brushed"], cab))

    # =========================================================================
    # HORIZONTAL BRUSHED-ALUMINUM HVAC TOGGLE STRIP BELOW 12.7" TOUCHSCREEN
    # (Fixes #10 defect; replaces old 2025 vertical wall of buttons!)
    # =========================================================================
    # Angled along the exact lower edge of the 12.7" center screen:
    # Left end (driver side) at Y=+0.178, X=+0.666; Right end at Y=-0.082, X=+0.580
    def _hvac_pt(s: float, dx: float, dz: float) -> Tuple[float, float, float]:
        # s in [0..1] goes left (+Y) -> right (-Y)
        base_x = 0.666 + (0.580 - 0.666) * s
        base_y = 0.178 + (-0.082 - 0.178) * s
        # Local outward normal pointing backward-and-slightly-left toward driver
        nx, ny = -0.949, 0.314
        return (base_x + nx * dx, base_y + ny * dx, 0.642 + dz)

    # Recessed dark horizontal HVAC air vent directly between 12.7" screen & aluminum toggle blade
    vent_secs = []
    for s in np.linspace(0.0, 1.0, 14):
        vent_secs.append([
            _hvac_pt(s, -0.025, 0.032),
            _hvac_pt(s, 0.008, 0.032),
            _hvac_pt(s, 0.008, 0.012),
            _hvac_pt(s, -0.025, 0.012),
        ])
    dash_parts.append(make_loft("_center_hvac_vent", vent_secs, mats["Mat_Black_Trim_Satin"], cab))

    # Satin brushed-aluminum horizontal climate-control housing blade
    blade_secs = []
    for s in np.linspace(-0.02, 1.02, 18):
        blade_secs.append([
            _hvac_pt(s, -0.018, 0.012),
            _hvac_pt(s, 0.014, 0.011),
            _hvac_pt(s, 0.018, 0.002),
            _hvac_pt(s, 0.015, -0.012),
            _hvac_pt(s, -0.020, -0.013),
        ])
    dash_parts.append(make_loft("_hvac_aluminum_blade", blade_secs, mats["Mat_Aluminum_Brushed"], cab, auto_smooth_deg=35.0))

    # 10 individual beveled physical HVAC toggle keys along the brushed-aluminum strip
    # (Driver Temp, Power, AUTO, Fan -, Fan +, Front Defrost, Rear Defrost, Recirc, A/C, Pass Temp)
    n_toggles = 10
    for k in range(n_toggles):
        s0 = 0.04 + (0.92 * k) / n_toggles
        s1 = s0 + (0.92 / n_toggles) * 0.78
        sm = 0.5 * (s0 + s1)
        is_temp_paddle = k in (0, n_toggles - 1)
        protrude = 0.023 if is_temp_paddle else 0.020
        key_secs = [
            [_hvac_pt(s0, 0.012, -0.008), _hvac_pt(s0, protrude, -0.007), _hvac_pt(s0, protrude, 0.007), _hvac_pt(s0, 0.012, 0.008)],
            [_hvac_pt(s1, 0.012, -0.008), _hvac_pt(s1, protrude, -0.007), _hvac_pt(s1, protrude, 0.007), _hvac_pt(s1, 0.012, 0.008)],
        ]
        dash_parts.append(
            make_loft(
                f"_hvac_toggle_{k}",
                key_secs,
                mats["Mat_Aluminum_Brushed"] if not is_temp_paddle else mats["Mat_Steel_Machined"],
                cab,
                auto_smooth_deg=30.0,
            )
        )
        # Subtle white/red/blue climate legend indicator dot/bar on each toggle
        ind_mat = mats["Mat_Stitch_Red"] if k == 0 else (mats["Mat_LT7_Plenum_Blue"] if k == n_toggles - 1 else mats["Mat_White_Paint"])
        ind_pts = [_hvac_pt(sm - 0.012, protrude + 0.001, 0.0005), _hvac_pt(sm + 0.012, protrude + 0.001, 0.0005)]
        dash_parts.append(make_tube(f"_hvac_icon_{k}", ind_pts, 0.0012, ind_mat, cab, segments=6))

    # Passenger-side swept horizontal air outlet, vanes & bright metallic lower trim blade
    pvent_rows = []
    for yy in np.linspace(-0.665, -0.195, 32):
        xx, z, _ = _dash_station(yy)
        pvent_rows.append([
            (xx + 0.014, yy, z - 0.045),
            (xx - 0.010, yy, z - 0.047),
            (xx - 0.014, yy, z - 0.055),
            (xx - 0.013, yy, z - 0.098),
            (xx - 0.003, yy, z - 0.106),
            (xx + 0.028, yy, z - 0.102),
        ])
    dash_parts.append(make_surface_grid("_pass_vent", pvent_rows, mats["Mat_Black_Trim_Satin"], cab, solidify=0.004))

    for dz in (0.060, 0.076, 0.092):
        vrows = []
        for yy in np.linspace(-0.650, -0.210, 24):
            xx, z, _ = _dash_station(yy)
            vrows.append([(xx - 0.014, yy, z - dz), (xx - 0.021, yy, z - dz - 0.002), (xx - 0.017, yy, z - dz - 0.005)])
        dash_parts.append(make_surface_grid(f"_pass_vane_{dz:.3f}", vrows, mats["Mat_Black_Trim_Gloss"], cab, solidify=0.0015))

    ptrim_rows = []
    for yy in np.linspace(-0.668, -0.185, 32):
        xx, z, _ = _dash_station(yy)
        ptrim_rows.append([
            (xx + 0.001, yy, z - 0.105),
            (xx - 0.016, yy, z - 0.108),
            (xx - 0.012, yy, z - 0.118),
            (xx + 0.014, yy, z - 0.123),
        ])
    dash_parts.append(make_surface_grid("_pass_vent_trim", ptrim_rows, mats["Mat_Aluminum_Brushed"], cab, solidify=0.003))

    # Inner A-pillar trim linings (left +Y and right -Y), cleanly OUTBOARD of the 6.6" left aux screen!
    # At dash height Z=0.79, left A-pillar inner face sits at Y=+0.688 (aux screen ends at Y=+0.648 -> 40mm clearance!)
    for sign in (1.0, -1.0):
        ap_secs = []
        ap_spine = (
            (0.840, 0.708, 0.775, 0.028, 0.026),
            (0.790, 0.696, 0.835, 0.028, 0.026),
            (0.715, 0.675, 0.905, 0.027, 0.025),
            (0.630, 0.646, 0.980, 0.026, 0.024),
            (0.545, 0.614, 1.052, 0.026, 0.023),
            (0.455, 0.580, 1.120, 0.026, 0.023),
            (0.390, 0.558, 1.158, 0.026, 0.022),
        )
        for cx, cy, cz, rx, ry in ap_spine:
            ring = []
            for k in range(16):
                a = 2.0 * pi * k / 16
                ring.append((cx + rx * cos(a), sign * (cy + ry * sin(a)), cz + 0.014 * sin(a)))
            ap_secs.append(ring)
        dash_parts.append(make_loft(f"_apillar_{int(sign)}", ap_secs, mats["Mat_Alcantara_Black"], cab))

    join_meshes(dash_parts, "ZR1X_Cabin_Dash", cab, auto_smooth_deg=42.0)

    # =========================================================================
    # THE THREE 2027 CURVED COCKPIT DISPLAYS (exact separate meshes for explode!)
    # =========================================================================

    # 1. 6.6" Left Auxiliary Telemetry Display (ZR1X_Cabin_DisplayAux)
    # Angled smoothly toward driver, ZERO A-pillar clipping (left edge Y=+0.646 vs A-pillar inboard Y=+0.678!)
    aux_rows = []
    for rv in np.linspace(0.0, 1.0, 4):
        row = []
        for cu in np.linspace(0.0, 1.0, 6):
            # cu=0 -> left outboard (higher +Y), cu=1 -> right inboard beside divider
            # Slight trapezoidal shear matching 103-auxiliary-driver-display.jpg
            y_bot = 0.648 + (0.530 - 0.648) * cu
            y_top = 0.630 + (0.524 - 0.630) * cu
            y = y_bot + (y_top - y_bot) * rv
            x_bot = 0.614 + (0.668 - 0.614) * cu
            x_top = 0.626 + (0.680 - 0.626) * cu
            x = x_bot + (x_top - x_bot) * rv
            z_bot = 0.731 + 0.008 * cu
            z_top = 0.812 + 0.024 * cu
            z = z_bot + (z_top - z_bot) * rv
            row.append((x, y, z))
        aux_rows.append(row)
    _build_screen_mesh("ZR1X_Cabin_DisplayAux", aux_rows, mats["Mat_Screen_Aux"], mats["Mat_Black_Trim_Gloss"], cab)

    # 2. 14" Curved Driver Instrument Cluster (ZR1X_Cabin_DisplayCluster)
    # Centered behind steering wheel (Y=+0.360), gently curved concave toward the driver
    clu_rows = []
    for rv in np.linspace(0.0, 1.0, 4):
        row = []
        for cu in np.linspace(0.0, 1.0, 12):
            y = 0.518 + (0.194 - 0.518) * cu
            # Concave arc toward driver (+X slightly deeper at center)
            arc = 0.014 * sin(pi * cu)
            x = 0.662 + arc + 0.010 * rv
            z_bot = 0.734 + 0.003 * sin(pi * cu)
            z_top = 0.852 + 0.005 * sin(pi * cu)
            z = z_bot + (z_top - z_bot) * rv
            row.append((x, y, z))
        clu_rows.append(row)
    _build_screen_mesh("ZR1X_Cabin_DisplayCluster", clu_rows, mats["Mat_Screen_Cluster"], mats["Mat_Black_Trim_Gloss"], cab)

    # 3. 12.7" Center Infotainment Touchscreen (ZR1X_Cabin_DisplayCenter)
    # Angled ~18° toward driver right above the brushed-aluminum horizontal HVAC toggle strip
    ctr_rows = []
    for rv in np.linspace(0.0, 1.0, 4):
        row = []
        for cu in np.linspace(0.0, 1.0, 8):
            y = 0.184 + (-0.084 - 0.184) * cu
            # Angled toward driver: left side deeper (+X=0.674), right side closer (+X=0.586)
            x_base = 0.674 + (0.586 - 0.674) * cu
            x = x_base + 0.016 * rv  # slight ergonomic upward tilt
            z_bot = 0.683 - 0.006 * cu
            z_top = 0.826 - 0.012 * cu
            z = z_bot + (z_top - z_bot) * rv
            row.append((x, y, z))
        ctr_rows.append(row)
    _build_screen_mesh("ZR1X_Cabin_DisplayCenter", ctr_rows, mats["Mat_Screen_Center"], mats["Mat_Black_Trim_Gloss"], cab)


# ---------------------------------------------------------------------------
# 4. Redesigned Open 2027 Center Console (ZR1X_Cabin_Console)
# ---------------------------------------------------------------------------

def _console_z(x: float) -> float:
    """Sloping center-console top deck height in V2 meters (+X fwd)."""
    # Legacy: zcap(x_old) = 0.555 - 0.101*x_old -> V2: 0.555 + 0.101*x
    return 0.555 + 0.101 * x


def _build_console(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    cab = pivots["Pivot_Interior_Cabin"]
    parts: List[bpy.types.Object] = []

    def raised_plate(pts_2d: Sequence[Tuple[float, float]], z_lo: float, z_hi: float, mat: bpy.types.Material, tag: str) -> None:
        s0 = [(x, y, _console_z(x) + z_lo) for x, y in pts_2d]
        s1 = [(x, y, _console_z(x) + z_hi) for x, y in pts_2d]
        parts.append(make_loft(tag, [s0, s1], mat, cab, auto_smooth_deg=32.0))

    # 1. Sculpted center tunnel structural leather/carpet surround
    # Stations sorted aft -> forward in V2 (+X forward)
    tunnel_stations = (
        (-0.440, 0.167), (-0.380, 0.161), (-0.080, 0.151),
        ( 0.210, 0.157), ( 0.490, 0.173), ( 0.680, 0.186), ( 0.845, 0.188),
    )
    t_secs = []
    for xx, w in tunnel_stations:
        h = _console_z(xx)
        t_secs.append([
            (xx, -w - 0.018, 0.187), (xx, -w - 0.019, 0.290), (xx, -w, 0.413),
            (xx, -w + 0.012, h - 0.039), (xx, -w + 0.023, h - 0.013), (xx, -w + 0.040, h),
            (xx,  w - 0.039, h), (xx,  w - 0.022, h - 0.013), (xx,  w - 0.012, h - 0.036),
            (xx,  w, 0.411), (xx,  w + 0.018, 0.275), (xx,  w + 0.018, 0.187),
        ])
    tunnel_ob = make_loft("_tunnel_body", t_secs, mats["Mat_Leather_JetBlack_HTE"], cab, uv_scale=4.0)
    parts.append(tunnel_ob)

    for side in (-1.0, 1.0):
        pts = [(xx, side * (w - 0.020), _console_z(xx) - 0.020) for xx, w in tunnel_stations]
        parts.append(make_tube(f"_tunnel_stitch_{int(side)}", pts, 0.0014, mats["Mat_Stitch_Gray"], cab, segments=6))

    # 2. Sleek passenger-side swept leather grab-handle ridge (2026/2027 redesign — NO wall of buttons!)
    grab_secs = []
    for t in np.linspace(0.0, 1.0, 14):
        xx = -0.10 + 0.66 * t
        yy = -0.140 - 0.020 * t
        zz = _console_z(xx) + 0.016 + 0.026 * sin(pi * t) ** 0.75
        grab_secs.append([
            (xx, yy - 0.018, zz - 0.026),
            (xx, yy - 0.020, zz + 0.006),
            (xx, yy - 0.006, zz + 0.018),
            (xx, yy + 0.014, zz + 0.016),
            (xx, yy + 0.018, zz - 0.020),
        ])
    parts.append(make_loft("_pass_grab_handle", grab_secs, mats["Mat_Leather_JetBlack_HTE"], cab, uv_scale=4.0))

    # 3. Gloss 2x2 carbon-fiber upper center console inlay deck with real circular cupholder cutouts!
    inlay_pts = [
        ( 0.610,  0.148), ( 0.610, -0.128),
        ( 0.220, -0.126), (-0.110, -0.118),
        (-0.110,  0.126), ( 0.220,  0.140),
    ]
    inlay_lo = [(x, y, _console_z(x) - 0.001) for x, y in inlay_pts]
    inlay_hi = [(x, y, _console_z(x) + 0.0055) for x, y in inlay_pts]
    inlay_ob = make_loft("_console_carbon_deck", [inlay_lo, inlay_hi], mats["Mat_Carbon_Twill_2x2"], cab, auto_smooth_deg=35.0)
    # Cut true circular openings in both the carbon deck and tunnel top for deep recessed cupholders
    cutters = []
    for j, xx in enumerate((0.205, 0.068)):
        cut = make_cylinder(
            f"_cup_cut_{j}",
            (xx, -0.042, _console_z(xx) - 0.056),
            (xx, -0.042, _console_z(xx) + 0.040),
            0.0445,
            0.0445,
            None,
            cab,
            segments=32,
        )
        for target_ob in (inlay_ob, tunnel_ob):
            mod = target_ob.modifiers.new(f"CupCut_{j}", "BOOLEAN")
            mod.operation = "DIFFERENCE"
            mod.object = cut
        cutters.append(cut)
    from rig_utils import apply_modifiers
    apply_modifiers(inlay_ob)
    apply_modifiers(tunnel_ob)
    for cut in cutters:
        c_me = cut.data
        bpy.data.objects.remove(cut, do_unlink=True)
        if c_me and c_me.users == 0:
            bpy.data.meshes.remove(c_me)
    box_project_uv(inlay_ob, scale=14.0)
    parts.append(inlay_ob)

    # 4. Brushed-aluminum driver-side gear selector & drive-mode bridge (HTE/01-front.jpg & 109)
    # Driver side is +Y_b = +0.082!
    raised_plate(_rounded_rect_2d(0.325, 0.084, 0.540, 0.078, 0.032), 0.005, 0.010, mats["Mat_Aluminum_Brushed"], "_selector_bridge")
    raised_plate(_rounded_rect_2d(0.415, 0.084, 0.278, 0.056, 0.024), 0.0101, 0.0115, mats["Mat_Switch_Black"], "_selector_recess")

    # P - R - N - D - M gear selector buttons & brushed pull paddles (R and D pull up; P, N, M push)
    gear_x = (0.515, 0.464, 0.413, 0.362, 0.311)
    for xx, letter in zip(gear_x, "PRNDM"):
        is_m = (letter == "M")
        key_mat = mats["Mat_Aluminum_Brushed"] if is_m else mats["Mat_Black_Trim_Gloss"]
        raised_plate(_rounded_rect_2d(xx, 0.084, 0.041, 0.044, 0.011), 0.0115, 0.0132, key_mat, f"_gear_{letter}")
        if letter in ("R", "D"):
            # Raised silver pull-toggle paddle tab
            raised_plate(_rounded_rect_2d(xx + 0.010, 0.084, 0.012, 0.043, 0.005), 0.0132, 0.0195, mats["Mat_Aluminum_Brushed"], f"_paddle_{letter}")
        # Crisp 3D legend on top of each P/R/N/D/M button (+X is up when driver looks forward, -Y is right!)
        leg_mat = mats["Mat_Stitch_Red"] if letter == "P" else (mats["Mat_Black_Trim_Gloss"] if is_m else mats["Mat_White_Paint"])
        _add_stroke_text(
            parts,
            letter,
            lambda u, v, cx=xx: (cx + v, 0.084 - u, _console_z(cx + v) + 0.0145),
            char_w=0.011,
            char_h=0.012,
            gap=0.002,
            radius=0.0011,
            mat=leg_mat,
            pivot=cab,
        )

    # 5. Drive-Mode Selector Pod + Front-Axle Lift & Camera buttons (rearward of P-R-N-D-M, X ≈ 0.11..0.24)
    raised_plate(_rounded_rect_2d(0.172, 0.084, 0.148, 0.054, 0.022), 0.0101, 0.0120, mats["Mat_Switch_Black"], "_mode_recess")
    # Center knurled drive-mode rotary scroll wheel
    parts.append(
        make_cylinder(
            "_mode_scroll_wheel",
            (0.172, 0.075, _console_z(0.172) + 0.015),
            (0.172, 0.093, _console_z(0.172) + 0.015),
            0.013,
            0.013,
            mats["Mat_Black_Trim_Gloss"],
            cab,
            segments=20,
        )
    )
    # Brushed metal flanking drive-mode bezel & Front-Lift (fwd) + Camera/Traction (aft) buttons
    for bx, tag, accent in ((0.220, "_front_lift_btn", True), (0.124, "_camera_btn", False)):
        raised_plate(_rounded_rect_2d(bx, 0.084, 0.034, 0.036, 0.009), 0.0120, 0.0155, mats["Mat_Black_Trim_Gloss"], tag)
        # Crisp white/silver icon bar indicating Front Lift / Camera
        bar = [(bx, 0.076, _console_z(bx) + 0.0165), (bx, 0.092, _console_z(bx) + 0.0165)]
        parts.append(make_tube(tag + "_icon", bar, 0.0014, mats["Mat_Aluminum_Brushed"] if accent else mats["Mat_White_Paint"], cab, segments=6))

    # 6. Forward wireless phone charging pad (right/passenger side forward of cupholders, 109 photo)
    raised_plate(_rounded_rect_2d(0.450, -0.048, 0.175, 0.098, 0.014), 0.0055, 0.0085, mats["Mat_Rubber_Black"], "_wireless_charger")

    # 7. Twin deep open recessed cupholders with machined bright metallic rims (right of selector bridge)
    for j, xx in enumerate((0.205, 0.068)):
        yy = -0.042
        rr = 0.045
        circ = [(xx + rr * cos(t), yy + rr * sin(t)) for t in np.linspace(0, 2 * pi, 40, endpoint=False)]
        # Open-topped recessed dark cup cylinder + dark rubberized bottom pad
        well_top = [(a, b, _console_z(a) + 0.006) for a, b in circ]
        well_bot = [(xx + (a - xx) * 0.86, yy + (b - yy) * 0.86, _console_z(a) - 0.055) for a, b in circ]
        parts.append(make_loft(f"_cup_well_{j}", [well_top, well_bot], mats["Mat_Switch_Black"], cab, cap_ends=False))
        parts.append(
            make_cylinder(
                f"_cup_floor_{j}",
                (xx, yy, _console_z(xx) - 0.056),
                (xx, yy, _console_z(xx) - 0.051),
                rr * 0.87,
                rr * 0.87,
                mats["Mat_Rubber_Black"],
                cab,
                segments=32,
            )
        )
        # Bright brushed-aluminum upper rim ring
        rim_pts = [(a, b, _console_z(a) + 0.008) for a, b in circ]
        parts.append(make_tube(f"_cup_rim_{j}", rim_pts, 0.0032, mats["Mat_Aluminum_Brushed"], cab, segments=10, cyclic=True))

    # 8. Padded Jet Black leather center armrest console lid behind the cupholders
    arm_secs = []
    for t in np.linspace(0.0, 1.0, 10):
        xx = -0.420 + 0.340 * t
        hw = 0.132 - 0.018 * (t ** 2)
        z0 = _console_z(xx) + 0.002
        z1 = z0 + 0.048 - 0.012 * t
        arm_secs.append([
            (xx, -hw, z0),
            (xx, -hw - 0.004, z0 + 0.020),
            (xx, -hw + 0.014, z1),
            (xx, 0.0, z1 + 0.008),
            (xx, hw - 0.014, z1),
            (xx, hw + 0.004, z0 + 0.020),
            (xx, hw, z0),
        ])
    parts.append(make_loft("_console_armrest", arm_secs, mats["Mat_Leather_JetBlack_HTE"], cab, uv_scale=4.0))

    join_meshes(parts, "ZR1X_Cabin_Console", cab, auto_smooth_deg=40.0)


# ---------------------------------------------------------------------------
# 5. Flat-Top / Flat-Bottom Carbon Steering Wheel w/ ZR1X Plaque & Red 12-o'clock Band
# ---------------------------------------------------------------------------

def _build_steering_wheel(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    cab = pivots["Pivot_Interior_Cabin"]
    parts: List[bpy.types.Object] = []

    # Exact V2 steering wheel center (converted from legacy (-0.493, -0.390, 0.712))
    steer = (0.493, 0.390, 0.712)

    def wp(px: float, py: float, depth: float = 0.0) -> Tuple[float, float, float]:
        """Map 2D front-panorama wheel pixel coords -> V2 3D meters (+X fwd, +Y left, +Z up)."""
        dz = (308.0 - py) * 0.00053
        # Note: legacy was (x_old = -0.493 - 0.26*dz + depth, y_old = -0.390 + (px-334)*0.000544)
        # Converting via (-x_old, -y_old, z_old):
        # px > 334 is RIGHT side of wheel (lower +Y in V2), depth > 0 moves TOWARD driver (-X in V2)!
        return (
            steer[0] + 0.26 * dz - depth,
            steer[1] - (px - 334.0) * 0.000544,
            steer[2] + dz,
        )

    # 1. Flat-top / flat-bottom squircle rim (2x2 gloss carbon top/bottom, Napa leather 9&3 grips, red 12-o'clock band!)
    raw_profile = (
        (334, 49), (445, 53), (518, 73), (561, 105), (592, 159),
        (615, 231), (623, 307), (615, 384), (592, 464), (567, 515),
        (527, 550), (453, 570), (334, 578), (220, 571), (144, 551),
        (102, 523), (77, 481), (54, 418), (38, 345), (36, 272),
        (46, 206), (66, 148), (96, 101), (148, 72), (234, 53),
    )
    profile = _catmull_rom_closed(raw_profile, steps=6)
    sides = 18
    layers = len(profile)
    verts = []
    faces = []
    mat_ids = []

    for i, (px, py) in enumerate(profile):
        before = profile[i - 1]
        after = profile[(i + 1) % layers]
        tang = after - before
        out = np.array([tang[1], -tang[0]]) / max(np.linalg.norm(tang), 1e-8)
        width = 31.5 + 5.0 * math.exp(-((py - 331.0) / 75.0) ** 2)
        for j in range(sides):
            th = 2.0 * pi * j / sides
            qx, qy = np.array((px, py)) + out * width * cos(th)
            verts.append(wp(qx, qy, 0.019 * sin(th)))
        for j in range(sides):
            ni = (i + 1) % layers
            nj = (j + 1) % sides
            faces.append((i * sides + j, i * sides + nj, ni * sides + nj, ni * sides + j))
            # Material IDs: 0=Leather 9&3 grips, 1=2x2 Gloss Carbon top/bottom, 2=Red 12-o'clock band!
            if py < 62.0 and abs(px - 334.0) < 12.0:
                mat_ids.append(2)
            elif py < 125.0 or py > 505.0:
                mat_ids.append(1)
            else:
                mat_ids.append(0)

    rim = make_mesh("_wheel_rim", verts, faces, mats["Mat_Leather_JetBlack_HTE"], cab, smooth=True, recalc_normals=True)
    rim.data.materials.append(mats["Mat_Carbon_Twill_2x2"])
    rim.data.materials.append(mats["Mat_Stitch_Red"])
    uv_rim = rim.data.uv_layers.new(name="UVMap")
    for face, mid in zip(rim.data.polygons, mat_ids):
        face.material_index = mid
        i_idx, j_idx = divmod(face.index, sides)
        for li, coord in zip(face.loop_indices, ((i_idx, j_idx), (i_idx, j_idx + 1), (i_idx + 1, j_idx + 1), (i_idx + 1, j_idx))):
            uv_rim.data[li].uv = (coord[0] * 26.0 / layers, coord[1] * 3.0 / sides)
    parts.append(rim)

    # 2. Crisp 6-o'clock 'ZR1X' bottom spoke plaque (fixes #10 defect!)
    plaque_border = ((288, 562), (380, 562), (388, 576), (376, 591), (292, 591), (280, 576))
    p_loop = _catmull_rom_closed(plaque_border, steps=3)
    p_mid = p_loop.mean(axis=0)
    p_secs = [
        [wp(*(p_mid + (xy - p_mid) * sc), dep) for xy in p_loop]
        for sc, dep in ((1.0, 0.012), (1.02, 0.019), (0.95, 0.023))
    ]
    parts.append(make_loft("_wheel_zr1x_plaque", p_secs, mats["Mat_Aluminum_Brushed"], cab, auto_smooth_deg=35.0))
    # Dark inset field + crisp 3D 'ZR1X' letters on the 6-o'clock wheel plaque
    p_in_secs = [
        [wp(*(p_mid + (xy - p_mid) * sc), dep) for xy in p_loop]
        for sc, dep in ((0.84, 0.0225), (0.82, 0.0242))
    ]
    parts.append(make_loft("_wheel_zr1x_inset", p_in_secs, mats["Mat_Black_Trim_Gloss"], cab))
    _add_stroke_text(
        parts,
        "ZR1X",
        lambda u, v: wp(334.0 + u, 576.0 - v, 0.0252),
        char_w=16.0,
        char_h=14.0,
        gap=4.5,
        radius=0.0010,
        mat=mats["Mat_Aluminum_Brushed"],
        pivot=cab,
        italic=0.18,
    )

    def wheel_panel(tag: str, border: Sequence[Tuple[float, float]], depth: float, mat: bpy.types.Material, smooth_steps: int = 3) -> bpy.types.Object:
        loop = _catmull_rom_closed(border, steps=smooth_steps) if smooth_steps > 1 else np.asarray(border, dtype=float)
        mid = loop.mean(axis=0)
        rings = ((0.96, depth - 0.011), (1.0, depth - 0.005), (0.991, depth - 0.001), (0.965, depth))
        secs = [[wp(*(mid + (xy - mid) * sc), off) for xy in loop] for sc, off in rings]
        ob = make_loft(tag, secs, mat, cab, auto_smooth_deg=38.0)
        if mat == mats["Mat_Carbon_Twill_2x2"]:
            box_project_uv(ob, scale=14.0)
        parts.append(ob)
        return ob

    # 3. Stitched polygonal horn pad + brushed inner bezel + Corvette crossed-flags emblem
    outer = (
        (265, 222), (397, 222), (429, 246), (462, 292), (474, 343),
        (462, 391), (429, 463), (399, 493), (341, 502), (267, 497),
        (238, 478), (213, 438), (196, 380), (193, 324), (211, 281), (238, 243),
    )
    inner = (
        (299, 286), (377, 286), (396, 294), (413, 317), (424, 347),
        (415, 387), (396, 425), (382, 442), (349, 447), (291, 446),
        (274, 438), (262, 416), (247, 364), (246, 340), (261, 308), (277, 291),
    )
    wheel_panel("_horn_pad", outer, 0.038, mats["Mat_Leather_JetBlack_HTE"])
    wheel_panel("_horn_bezel", inner, 0.0405, mats["Mat_Aluminum_Brushed"])
    core = (np.asarray(inner, dtype=float) - [334.0, 365.0]) * 0.943 + [334.0, 365.0]
    wheel_panel("_horn_core", core.tolist(), 0.0418, mats["Mat_Leather_JetBlack_HTE"])

    # Double contrast topstitch loop around horn pad
    for ratio in (0.935, 0.958):
        sloop = _catmull_rom_closed(outer, steps=4)
        base = np.array([334.0, 354.0])
        sloop = base + (sloop - base) * ratio
        parts.append(make_tube(f"_horn_stitch_{ratio:.3f}", [wp(*xy, 0.0388) for xy in sloop], 0.0007, mats["Mat_Stitch_Gray"], cab, segments=5, cyclic=True))

    # Crossed-flags emblem on horn center
    def flag_poly(tag: str, corners: Sequence[Tuple[float, float]], dep: float, mat: bpy.types.Material) -> None:
        vs = [wp(x, y, dep) for x, y in corners]
        parts.append(make_mesh(tag, vs, [tuple(range(len(vs)))], mat, cab, smooth=False, recalc_normals=False))

    badge = ((295, 327), (334, 364), (377, 326), (369, 365), (343, 388), (337, 407), (333, 401), (328, 387), (303, 365))
    flag_poly("_flag_bezel", badge, 0.0436, mats["Mat_Aluminum_Brushed"])
    lf = np.array([(299, 333), (335, 367), (331, 385), (306, 361)], dtype=float)
    rf = np.array([(335, 368), (374, 332), (367, 359), (340, 386)], dtype=float)
    flag_poly("_flag_l", lf.tolist(), 0.0441, mats["Mat_Black_Trim_Gloss"])
    flag_poly("_flag_r", rf.tolist(), 0.0441, mats["Mat_Emblem_Red"])

    def _bilerp(p: np.ndarray, u: float, v: float) -> Tuple[float, float]:
        pt = (1.0 - v) * ((1.0 - u) * p[0] + u * p[1]) + v * ((1.0 - u) * p[3] + u * p[2])
        return (float(pt[0]), float(pt[1]))

    for ii in range(4):
        for jj in range(2):
            if (ii + jj) % 2 == 0:
                quad = [
                    _bilerp(lf, a, b)
                    for a, b in ((ii / 4, jj / 2), ((ii + 1) / 4, jj / 2), ((ii + 1) / 4, (jj + 1) / 2), (ii / 4, (jj + 1) / 2))
                ]
                flag_poly(f"_flag_chk_{ii}_{jj}", quad, 0.0445, mats["Mat_White_Paint"])

    # 4. Swept brushed-aluminum spokes, switch pods, knurled thumb rollers & carbon shift paddles
    for sign in (-1, 1):
        def mir(px: float) -> float:
            return 334.0 + sign * (px - 334.0)

        def outl(coords: Sequence[Tuple[float, float]]) -> List[Tuple[float, float]]:
            return [(mir(x), y) for x, y in coords]

        spoke = ((410, 238), (433, 248), (503, 286), (573, 333), (594, 354), (609, 418), (604, 449), (587, 460), (559, 455), (450, 412), (438, 393), (446, 366))
        inset = ((430, 260), (461, 275), (549, 325), (586, 353), (594, 383), (597, 431), (586, 447), (562, 442), (462, 405), (453, 389), (455, 349))
        cluster = ((508, 357), (566, 357), (584, 369), (588, 397), (578, 405), (516, 405), (506, 395))
        slider = ((533, 375), (554, 375), (555, 395), (533, 395))

        wheel_panel(f"_spoke_{sign}", outl(spoke), 0.0175, mats["Mat_Aluminum_Brushed"])
        wheel_panel(f"_switch_{sign}", outl(inset), 0.0204, mats["Mat_Switch_Black"])
        wheel_panel(f"_rocker_{sign}", outl(cluster), 0.0228, mats["Mat_Black_Trim_Gloss"])
        wheel_panel(f"_roller_{sign}", outl(slider), 0.0258, mats["Mat_Black_Trim_Satin"], smooth_steps=1)

        # Left-spoke Z-mode brushed silver button (visible in HTE/01-front.jpg on left spoke!)
        if sign < 0:
            z_btn = ((436, 318), (468, 304), (474, 354), (444, 370))
            wheel_panel("_zmode_btn", outl(z_btn), 0.0245, mats["Mat_Aluminum_Brushed"], smooth_steps=2)

        # Carbon-fiber shift paddles (- left, + right) behind spokes
        paddle = ((526, 226), (542, 224), (552, 242), (556, 308), (542, 320), (524, 304))
        wheel_panel(f"_paddle_{sign}", outl(paddle), -0.032, mats["Mat_Carbon_Twill_2x2"], smooth_steps=2)
        parts.append(
            make_tube(
                f"_paddle_minus_{sign}",
                [wp(mir(531), 241, -0.030), wp(mir(545), 241, -0.030)],
                0.0010,
                mats["Mat_White_Paint"],
                cab,
                segments=6,
            )
        )
        if sign > 0:
            parts.append(
                make_tube(
                    "_paddle_plus",
                    [wp(mir(538), 234, -0.030), wp(mir(538), 248, -0.030)],
                    0.0010,
                    mats["Mat_White_Paint"],
                    cab,
                    segments=6,
                )
            )

    # 5. Steering column shroud (compact, angled gently DOWNWARD to firewall so 14" cluster stays 100% clear!)
    parts.append(
        make_cylinder(
            "_steer_col",
            (steer[0] + 0.015, steer[1], steer[2] - 0.008),
            (steer[0] + 0.210, steer[1], steer[2] - 0.052),
            0.038,
            0.044,
            mats["Mat_Black_Trim_Satin"],
            cab,
            segments=24,
        )
    )
    for sign in (-1.0, 1.0):
        parts.append(
            make_cylinder(
                f"_stalk_{int(sign)}",
                (steer[0] + 0.060, steer[1] + sign * 0.036, steer[2] + 0.002),
                (steer[0] + 0.054, steer[1] + sign * 0.145, steer[2] + 0.018),
                0.0075,
                0.0105,
                mats["Mat_Black_Trim_Satin"],
                cab,
                segments=12,
            )
        )

    join_meshes(parts, "ZR1X_Cabin_SteeringWheel", cab, auto_smooth_deg=42.0)


# ---------------------------------------------------------------------------
# 6. GT2 Bucket Seats — Separated Shells & Cushions for Exploded View
# ---------------------------------------------------------------------------

def _build_gt2_seats(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    cab = pivots["Pivot_Interior_Cabin"]

    for side_sign, side_tag in ((1.0, "L"), (-1.0, "R")):
        # Driver (L) is +Y_b = +0.383, slightly further forward (+0.182 in V2 +X vs passenger!)
        center_y = side_sign * 0.383
        rail_offset_x = 0.182 if side_sign > 0 else 0.0

        shell_parts: List[bpy.types.Object] = []
        cushion_parts: List[bpy.types.Object] = []

        def s_xyz(x_old_rel: float, y_old_rel: float, z: float) -> Tuple[float, float, float]:
            # Convert legacy seat-local (+x_old aft) to V2 (+X forward, +Y left)
            return (-x_old_rel + rail_offset_x, -y_old_rel + center_y, z)

        def shaped_pad(
            target: List[bpy.types.Object],
            tag: str,
            stations: Sequence[Tuple[float, float, float, float, float]],
            mat: bpy.types.Material,
            horizontal: bool = False,
            exponent: float = 0.72,
            uv_scale: float = 1.0,
            is_perf: bool = False,
        ) -> bpy.types.Object:
            ring = 36
            verts = []
            for axis, low, high, lateral, half in stations:
                mid = (low + high) * 0.5
                for i in range(ring):
                    a = 2.0 * pi * i / ring
                    c, s = cos(a), sin(a)
                    height = mid + (high - low) * 0.5 * math.copysign(abs(c) ** exponent, c)
                    y = lateral + half * math.copysign(abs(s) ** exponent, s)
                    verts.append(s_xyz(axis, y, height) if horizontal else s_xyz(height, y, axis))
            faces = []
            for j in range(len(stations) - 1):
                for i in range(ring):
                    ni = (i + 1) % ring
                    faces.append((j * ring + i, j * ring + ni, (j + 1) * ring + ni, (j + 1) * ring + i))
            faces.append(tuple(reversed(range(ring))))
            faces.append(tuple(range(len(verts) - ring, len(verts))))
            ob = make_mesh(tag, verts, faces, mat, cab, smooth=True, recalc_normals=True)
            if is_perf:
                uv = ob.data.uv_layers.new(name="UVMap")
                for poly in ob.data.polygons:
                    for li in poly.loop_indices:
                        co = ob.data.vertices[ob.data.loops[li].vertex_index].co
                        uv.data[li].uv = (co.y / 0.012, (co.x if horizontal else co.z) / 0.012)
            else:
                box_project_uv(ob, scale=uv_scale)
            target.append(ob)
            return ob

        def front_at_frac(low: float, high: float, frac: float, exponent: float = 0.72) -> float:
            return (low + high) * 0.5 - (high - low) * 0.5 * (1.0 - abs(frac) ** (2.0 / exponent)) ** (exponent * 0.5)

        def cord(target: List[bpy.types.Object], tag: str, coords: Sequence[Tuple[float, float, float]], r: float, mat: bpy.types.Material) -> None:
            target.append(make_tube(tag, [s_xyz(*v) for v in coords], r, mat, cab, segments=6))

        # --- SEAT SHELL PARTS (ZR1X_Cabin_SeatShell_L/R) ---
        # Floor adjuster rails
        for hand in (-1.0, 1.0):
            shell_parts.append(
                make_roundbox(
                    f"_rail_{side_tag}_{int(hand)}",
                    s_xyz(0.026, hand * 0.148, 0.283),
                    (0.470, 0.025, 0.031),
                    mats["Mat_Black_Trim_Satin"],
                    cab,
                    bevel=0.005,
                )
            )
        # Cushion structural pan
        shaped_pad(
            shell_parts,
            f"_pan_{side_tag}",
            (
                (-0.252, 0.330, 0.349, 0.0, 0.145),
                (-0.240, 0.312, 0.364, 0.0, 0.192),
                (-0.168, 0.300, 0.380, 0.0, 0.209),
                ( 0.155, 0.298, 0.365, 0.0, 0.217),
                ( 0.250, 0.318, 0.368, 0.0, 0.185),
            ),
            mats["Mat_Carbon_Matte"],
            horizontal=True,
            uv_scale=6.0,
        )
        # Lower graphite/carbon bucket shell
        shaped_pad(
            shell_parts,
            f"_shell_{side_tag}",
            (
                (0.365, 0.172, 0.263, 0.0, 0.148),
                (0.413, 0.165, 0.277, 0.0, 0.201),
                (0.490, 0.185, 0.299, 0.0, 0.218),
                (0.624, 0.209, 0.323, 0.0, 0.223),
                (0.730, 0.245, 0.337, 0.0, 0.206),
                (0.794, 0.263, 0.346, 0.0, 0.164),
                (0.809, 0.286, 0.340, 0.0, 0.115),
            ),
            mats["Mat_Carbon_Matte"],
            uv_scale=6.0,
        )

        # Exposed glossy 2x2 carbon-fiber shoulder pass-through halo surround (daylight passes through!)
        outer_h = (
            (-0.155, 0.806), (-0.145, 0.850), (-0.128, 0.903), (-0.094, 0.922),
            ( 0.000, 0.934), ( 0.094, 0.922), ( 0.128, 0.903), ( 0.145, 0.850),
            ( 0.155, 0.806), ( 0.127, 0.778), ( 0.080, 0.795), ( 0.000, 0.803),
            (-0.080, 0.795), (-0.127, 0.778),
        )
        inner_h = (
            (-0.134, 0.813), (-0.130, 0.848), (-0.108, 0.886), (-0.078, 0.901),
            ( 0.000, 0.906), ( 0.078, 0.901), ( 0.108, 0.886), ( 0.130, 0.848),
            ( 0.134, 0.813), ( 0.118, 0.808), ( 0.075, 0.818), ( 0.000, 0.824),
            (-0.075, 0.818), (-0.118, 0.808),
        )
        n_h = len(outer_h)
        h_verts = []
        h_faces = []
        for inset, sec in ((0.0, outer_h), (0.0, inner_h), (0.031, inner_h), (0.031, outer_h)):
            h_verts.extend(s_xyz(0.279 + 0.27 * (z - 0.81) + inset, y, z) for y, z in sec)
        for j in range(4):
            nj = (j + 1) % 4
            for i in range(n_h):
                ni = (i + 1) % n_h
                h_faces.append((j * n_h + i, j * n_h + ni, nj * n_h + ni, nj * n_h + i))
        halo = make_mesh(f"_halo_{side_tag}", h_verts, h_faces, mats["Mat_Carbon_Twill_2x2"], cab, smooth=True, recalc_normals=True, uv_scale=12.0)
        shell_parts.append(halo)

        # Integral GT2 head restraint + contrast stitching + subtle crossed-flags deboss
        head = (
            (0.888, 0.274, 0.346, 0.0, 0.063),
            (0.902, 0.264, 0.365, 0.0, 0.082),
            (0.947, 0.254, 0.381, 0.0, 0.099),
            (0.999, 0.254, 0.387, 0.0, 0.097),
            (1.053, 0.269, 0.382, 0.0, 0.084),
            (1.078, 0.292, 0.365, 0.0, 0.070),
            (1.084, 0.315, 0.351, 0.0, 0.055),
        )
        shaped_pad(shell_parts, f"_headrest_{side_tag}", head, mats["Mat_Leather_JetBlack_HTE"], exponent=0.70, uv_scale=4.0)
        for hand in (-1.0, 1.0):
            cord(
                shell_parts,
                f"_hr_stitch_{side_tag}_{int(hand)}",
                [(front_at_frac(a, b, 0.78, 0.70) - 0.001, hand * w * 0.78, z) for z, a, b, _, w in head],
                0.0011,
                mats["Mat_Stitch_Gray"],
            )
            outline = ((0.0, 0.970), (0.009, 0.990), (0.043, 1.014), (0.041, 0.995), (0.016, 0.979), (0.0, 0.970))
            cord(
                shell_parts,
                f"_hr_flag_{side_tag}_{int(hand)}",
                [(0.253 + abs(y) * 0.07, hand * y, z) for y, z in outline],
                0.0012,
                mats["Mat_Black_Trim_Satin"],
            )

        # Parked 3-point seat belt webbing + inboard buckle stalk & red release button
        # Note: outboard flank is -side_sign in legacy y_old_rel (which maps to +side_sign in V2 Y)
        belt_side_old = -side_sign
        belt_coords = (
            (0.340, 0.189, 0.890), (0.333, 0.196, 0.917), (0.316, 0.205, 0.928),
            (0.302, 0.216, 0.919), (0.294, 0.220, 0.902), (0.279, 0.229, 0.853),
            (0.220, 0.238, 0.717), (0.161, 0.237, 0.570), (0.131, 0.223, 0.440), (0.137, 0.207, 0.341),
        )
        strap_rows = []
        bw = 0.043
        for x, y, z in belt_coords:
            strap_rows.append([
                s_xyz(x - bw * 0.43, belt_side_old * (y - bw * 0.20), z),
                s_xyz(x + bw * 0.43, belt_side_old * (y + bw * 0.20), z),
            ])
        shell_parts.append(
            make_surface_grid(f"_belt_{side_tag}", strap_rows, mats["Mat_Alcantara_Black"], cab, solidify=0.0025)
        )
        cord(
            shell_parts,
            f"_buckle_stalk_{side_tag}",
            [(0.059, -belt_side_old * 0.207, 0.315), (0.020, -belt_side_old * 0.214, 0.426)],
            0.011,
            mats["Mat_Black_Trim_Satin"],
        )
        shell_parts.append(
            make_roundbox(
                f"_buckle_body_{side_tag}",
                s_xyz(0.013, -belt_side_old * 0.218, 0.444),
                (0.058, 0.035, 0.060),
                mats["Mat_Black_Trim_Satin"],
                cab,
                bevel=0.007,
                rot_euler=(0.0, -0.20, 0.0),
            )
        )
        shell_parts.append(
            make_roundbox(
                f"_buckle_red_{side_tag}",
                s_xyz(0.008, -belt_side_old * 0.218, 0.473),
                (0.043, 0.026, 0.010),
                mats["Mat_Stitch_Red"],
                cab,
                bevel=0.003,
                rot_euler=(0.0, -0.20, 0.0),
            )
        )

        join_meshes(shell_parts, f"ZR1X_Cabin_SeatShell_{side_tag}", cab, auto_smooth_deg=42.0)

        # --- SEAT CUSHION PARTS (ZR1X_Cabin_SeatCushion_L/R — floats +10 u on explode!) ---
        shaped_pad(
            cushion_parts,
            f"_perf_base_{side_tag}",
            (
                (-0.250, 0.363, 0.413, 0.0, 0.117),
                (-0.230, 0.348, 0.437, 0.0, 0.147),
                (-0.153, 0.344, 0.439, 0.0, 0.156),
                (-0.012, 0.347, 0.417, 0.0, 0.151),
                ( 0.115, 0.347, 0.404, 0.0, 0.145),
                ( 0.219, 0.361, 0.424, 0.0, 0.125),
            ),
            mats["Mat_Leather_Perf_HTE"],
            horizontal=True,
            is_perf=True,
        )
        for hand in (-1.0, 1.0):
            thigh = (
                (-0.239, 0.350, 0.412, 0.151, 0.031),
                (-0.216, 0.340, 0.452, 0.166, 0.049),
                (-0.128, 0.334, 0.474, 0.176, 0.053),
                ( 0.013, 0.331, 0.471, 0.182, 0.050),
                ( 0.150, 0.339, 0.453, 0.171, 0.053),
                ( 0.229, 0.360, 0.445, 0.152, 0.050),
            )
            shaped_pad(
                cushion_parts,
                f"_thigh_{side_tag}_{int(hand)}",
                [(a, b, c, hand * d, e) for a, b, c, d, e in thigh],
                mats["Mat_Leather_JetBlack_HTE"],
                horizontal=True,
                uv_scale=4.0,
            )
            cord(
                cushion_parts,
                f"_thigh_pipe_{side_tag}_{int(hand)}",
                [(a, hand * (d - 0.018), c - 0.005) for a, b, c, d, e in thigh],
                0.0014,
                mats["Mat_Stitch_Gray"],
            )

        back_ins = (
            (0.411, 0.160, 0.235, 0.0, 0.102),
            (0.442, 0.158, 0.255, 0.0, 0.147),
            (0.501, 0.167, 0.266, 0.0, 0.156),
            (0.572, 0.184, 0.282, 0.0, 0.149),
            (0.655, 0.205, 0.304, 0.0, 0.145),
            (0.742, 0.229, 0.319, 0.0, 0.136),
            (0.792, 0.246, 0.323, 0.0, 0.122),
            (0.813, 0.271, 0.316, 0.0, 0.086),
        )
        shaped_pad(cushion_parts, f"_perf_back_{side_tag}", back_ins, mats["Mat_Leather_Perf_HTE"], is_perf=True)
        cord(cushion_parts, f"_back_center_{side_tag}", [(a, 0.0, z) for z, a, _, _, _ in back_ins], 0.0014, mats["Mat_Black_Trim_Satin"])

        for hand in (-1.0, 1.0):
            flank = (
                (0.397, 0.141, 0.257, 0.143, 0.045),
                (0.460, 0.110, 0.279, 0.170, 0.055),
                (0.542, 0.106, 0.293, 0.186, 0.047),
                (0.627, 0.135, 0.313, 0.189, 0.045),
                (0.696, 0.168, 0.327, 0.179, 0.045),
                (0.755, 0.197, 0.336, 0.168, 0.039),
                (0.801, 0.215, 0.338, 0.168, 0.044),
                (0.851, 0.228, 0.341, 0.170, 0.048),
                (0.894, 0.237, 0.344, 0.162, 0.045),
                (0.931, 0.261, 0.343, 0.138, 0.037),
                (0.953, 0.286, 0.334, 0.119, 0.027),
                (0.963, 0.309, 0.326, 0.109, 0.010),
            )
            shaped_pad(
                cushion_parts,
                f"_flank_{side_tag}_{int(hand)}",
                [(z, a, b, hand * y, w) for z, a, b, y, w in flank],
                mats["Mat_Leather_JetBlack_HTE"],
                uv_scale=4.0,
            )
            cord(
                cushion_parts,
                f"_flank_pipe_{side_tag}_{int(hand)}",
                [(front_at_frac(a, b, 0.62) - 0.0013, hand * (y - w * 0.62), z) for z, a, b, y, w in flank],
                0.0014,
                mats["Mat_Stitch_Gray"],
            )

        join_meshes(cushion_parts, f"ZR1X_Cabin_SeatCushion_{side_tag}", cab, auto_smooth_deg=42.0)


# ---------------------------------------------------------------------------
# 7. Bright Brushed-Aluminum 3-Piece Sport Pedals (ZR1X_Cabin_Pedals)
# ---------------------------------------------------------------------------

def _build_pedals(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Build bright brushed-aluminum accelerator, brake, and dead pedal matching photo 112."""
    cab = pivots["Pivot_Interior_Cabin"]
    parts: List[bpy.types.Object] = []

    # 1. Left Footrest / Dead Pedal (mounted along driver toe board left slope, Y ≈ +0.555)
    dp_center = (0.835, 0.552, 0.368)
    dp_rot = (0.0, -0.52, -0.06)
    parts.append(
        make_roundbox("_dead_pedal_base", dp_center, (0.018, 0.088, 0.215), mats["Mat_Black_Trim_Satin"], cab, bevel=0.005, rot_euler=dp_rot)
    )
    parts.append(
        make_roundbox("_dead_pedal_plate", (dp_center[0] - 0.008, dp_center[1] - 0.002, dp_center[2] + 0.004), (0.006, 0.068, 0.192), mats["Mat_Aluminum_Brushed"], cab, bevel=0.002, rot_euler=dp_rot)
    )
    for k in range(11):
        t = (k - 5.0) * 0.0155
        parts.append(
            make_roundbox(
                f"_dp_rib_{k}",
                (dp_center[0] - 0.011 + t * sin(0.52), dp_center[1] - 0.002, dp_center[2] + 0.004 + t * cos(0.52)),
                (0.004, 0.056, 0.0055),
                mats["Mat_Rubber_Black"],
                cab,
                bevel=0.001,
                rot_euler=dp_rot,
            )
        )

    # 2. Wide Horizontal Brake Pedal + Steel Lever Arm (Y ≈ +0.445, visible below steering rim!)
    bk_center = (0.788, 0.445, 0.432)
    bk_rot = (0.0, -0.44, 0.0)
    parts.append(
        make_cylinder("_brake_arm", (0.802, 0.445, 0.438), (0.842, 0.425, 0.590), 0.009, 0.011, mats["Mat_Steel_Machined"], cab, segments=14)
    )
    parts.append(
        make_roundbox("_brake_pad_back", (bk_center[0] + 0.005, bk_center[1], bk_center[2]), (0.014, 0.104, 0.064), mats["Mat_Rubber_Black"], cab, bevel=0.004, rot_euler=bk_rot)
    )
    parts.append(
        make_roundbox("_brake_pad_alu", bk_center, (0.007, 0.094, 0.054), mats["Mat_Aluminum_Brushed"], cab, bevel=0.002, rot_euler=bk_rot)
    )
    for dz in (-0.015, 0.0, 0.015):
        parts.append(
            make_roundbox(
                f"_bk_rib_{dz:.3f}",
                (bk_center[0] - 0.004 + dz * sin(0.44), bk_center[1], bk_center[2] + dz * cos(0.44)),
                (0.004, 0.078, 0.006),
                mats["Mat_Rubber_Black"],
                cab,
                bevel=0.001,
                rot_euler=bk_rot,
            )
        )

    # 3. Floor-Hinged Organ-Style Accelerator Pedal (Y ≈ +0.320, visible right side below wheel!)
    ac_center = (0.815, 0.320, 0.405)
    ac_rot = (0.0, -0.36, 0.0)
    parts.append(
        make_roundbox("_accel_base", (0.815, 0.332, 0.342), (0.042, 0.074, 0.085), mats["Mat_Black_Trim_Satin"], cab, bevel=0.006, rot_euler=ac_rot)
    )
    parts.append(
        make_roundbox("_accel_plate", ac_center, (0.010, 0.048, 0.168), mats["Mat_Aluminum_Brushed"], cab, bevel=0.003, rot_euler=ac_rot)
    )
    for dy in (-0.013, 0.0, 0.013):
        parts.append(
            make_roundbox(
                f"_ac_rib_{dy:.3f}",
                (ac_center[0] - 0.006, ac_center[1] + dy, ac_center[2]),
                (0.004, 0.0055, 0.140),
                mats["Mat_Rubber_Black"],
                cab,
                bevel=0.001,
                rot_euler=ac_rot,
            )
        )

    join_meshes(parts, "ZR1X_Cabin_Pedals", cab, auto_smooth_deg=38.0)


# ---------------------------------------------------------------------------
# 8. Header Trim, Overhead Console, Visors & Planar Rearview Mirror
# ---------------------------------------------------------------------------

def _build_header_and_mirror(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    cab = pivots["Pivot_Interior_Cabin"]
    hdr_parts: List[bpy.types.Object] = []

    # Front windshield roof header & Alcantara headliner transition
    hdr_secs = []
    for yy in np.linspace(-0.560, 0.560, 33):
        arch = -0.028 * (yy / 0.56) ** 2
        z_top = 1.175 + arch
        hdr_secs.append([
            (0.460, yy, z_top - 0.008),
            (0.390, yy, z_top + 0.002),
            (0.388, yy, z_top - 0.026),
            (0.456, yy, z_top - 0.032),
        ])
    hdr_parts.append(make_loft("_front_header", hdr_secs, mats["Mat_Alcantara_Black"], cab))

    # Overhead console pod w/ OnStar / hazard switch strip (HTE/02-right.jpg & 099)
    hdr_parts.append(
        make_roundbox("_overhead_pod", (0.505, 0.0, 1.132), (0.165, 0.135, 0.026), mats["Mat_Black_Trim_Satin"], cab, bevel=0.007, rot_euler=(0.0, 0.24, 0.0))
    )
    # Sun visors tucked cleanly against windshield header (left & right)
    for sign in (-1.0, 1.0):
        hdr_parts.append(
            make_roundbox(
                f"_visor_{int(sign)}",
                (0.470, sign * 0.320, 1.130),
                (0.115, 0.290, 0.016),
                mats["Mat_Alcantara_Black"],
                cab,
                bevel=0.006,
                rot_euler=(0.0, 0.34, 0.0),
            )
        )

    # Interior rearview mirror stalk + sleek frameless dark housing (facing driver slightly)
    # Mirror sits at V2 (+0.558, 0.0, 1.044)
    mirror_pos = np.array([0.558, 0.0, 1.044])
    hdr_parts.append(
        make_tube(
            "_mirror_stalk",
            [(0.625, 0.0, 1.088), (0.592, 0.0, 1.054), (0.568, 0.0, 1.045)],
            0.011,
            mats["Mat_Black_Trim_Satin"],
            cab,
            segments=12,
        )
    )
    # Angled yaw ~7° toward driver (+Y) and pitch ~3° slightly down toward driver eye
    yaw = math.radians(-7.0)
    pitch = math.radians(3.0)
    hdr_parts.append(
        make_roundbox(
            "_mirror_housing",
            tuple(mirror_pos + np.array([0.014, 0.0, 0.0])),
            (0.024, 0.222, 0.058),
            mats["Mat_Black_Trim_Gloss"],
            cab,
            bevel=0.009,
            rot_euler=(0.0, pitch, yaw),
        )
    )
    join_meshes(hdr_parts, "ZR1X_Cabin_HeaderTrim", cab, auto_smooth_deg=40.0)

    # PURE PLANAR REFLECTIVE GLASS MESH (ZR1X_Cabin_RearviewMirror, ONLY Mat_Cabin_Rearview)
    # Normals point strictly backward (-X) + slightly left (+Y) toward driver eye (+0.143, +0.389, +0.868)
    # for mirror-reflection.js fitMirrorSurface()!
    normal = np.array([-math.cos(yaw) * math.cos(pitch), math.sin(-yaw) * math.cos(pitch), -math.sin(pitch)])
    normal /= np.linalg.norm(normal)
    up_hint = np.array([0.0, 0.0, 1.0])
    # Right along mirror surface (from driver's perspective looking forward, right is -Y)
    right = np.cross(up_hint, normal)
    right /= np.linalg.norm(right)
    up = np.cross(normal, right)
    up /= np.linalg.norm(up)

    # Sleek rounded-trapezoid Corvette digital rearview mirror outline (width 0.212m, height 0.050m)
    glass_center = mirror_pos + normal * 0.001
    outline_2d = (
        (-0.102,  0.022), ( 0.102,  0.022),
        ( 0.106,  0.014), ( 0.104, -0.014),
        ( 0.094, -0.024), (-0.094, -0.024),
        (-0.104, -0.014), (-0.106,  0.014),
    )
    m_verts = [tuple(glass_center + right * u + up * v) for u, v in outline_2d]
    # Fan triangulation with front normal aligned strictly with `normal`
    m_center_idx = len(m_verts)
    m_verts.append(tuple(glass_center))
    m_faces = []
    n_p = len(outline_2d)
    for i in range(n_p):
        ni = (i + 1) % n_p
        # Check winding against `normal`: (p[i] - c) x (p[ni] - c)
        a = np.asarray(m_verts[i]) - glass_center
        b = np.asarray(m_verts[ni]) - glass_center
        if np.dot(np.cross(a, b), normal) >= 0:
            m_faces.append((m_center_idx, i, ni))
        else:
            m_faces.append((m_center_idx, ni, i))

    make_mesh(
        "ZR1X_Cabin_RearviewMirror",
        m_verts,
        m_faces,
        mats["Mat_Cabin_Rearview"],
        cab,
        smooth=False,
        recalc_normals=False,
    )


# ---------------------------------------------------------------------------
# 9. Brushed-Metal Door-Switch Control Pods & BOSE Perforated Speaker Grilles
#    (Parented to Pivot_Door_L / Pivot_Door_R so they swing cleanly with doors!)
# ---------------------------------------------------------------------------

def _build_door_switch_pods(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Build driver & passenger brushed-aluminum armrest switch pods & BOSE speaker grilles."""
    def sill_z(x_fwd: float) -> float:
        # Legacy: 0.646 - 0.111*(x_old + 0.46) -> V2: 0.646 - 0.111*(-x_fwd + 0.46)
        return 0.646 + 0.111 * (x_fwd - 0.46)

    for side_sign, side_tag, pivot_name in ((1.0, "L", "Pivot_Door_L"), (-1.0, "R", "Pivot_Door_R")):
        door = pivots[pivot_name]
        parts: List[bpy.types.Object] = []

        def d_plate(pts_2d: Sequence[Tuple[float, float]], z_lo: float, z_hi: float, mat: bpy.types.Material, tag: str) -> None:
            s0 = [(x, side_sign * y, sill_z(x) + z_lo) for x, y in pts_2d]
            s1 = [(x, side_sign * y, sill_z(x) + z_hi) for x, y in pts_2d]
            parts.append(make_loft(tag, [s0, s1], mat, door, auto_smooth_deg=32.0))

        # 1. Sloped brushed-aluminum door armrest control pod (HTE/01-front.jpg & 087)
        if side_sign > 0:
            # Driver (L): wide brushed-aluminum armrest bezel w/ dual window rockers + 4-way mirror dial
            d_plate(_rounded_rect_2d(0.398, 0.643, 0.334, 0.080, 0.029), -0.004, 0.007, mats["Mat_Aluminum_Brushed"], "_drv_pod")
            d_plate(_rounded_rect_2d(0.398, 0.643, 0.195, 0.053, 0.018), 0.0072, 0.0094, mats["Mat_Switch_Black"], "_drv_pocket")
            # Twin chrome-tipped power window switches
            for xx in (0.352, 0.378):
                for yy in (0.631, 0.655):
                    d_plate(_rounded_rect_2d(xx, yy, 0.032, 0.019, 0.005), 0.0094, 0.0142, mats["Mat_Black_Trim_Gloss"], f"_win_{xx:.3f}_{yy:.3f}")
                    d_plate(_rounded_rect_2d(xx + 0.011, yy, 0.006, 0.017, 0.002), 0.0142, 0.0160, mats["Mat_Aluminum_Brushed"], f"_win_tip_{xx:.3f}_{yy:.3f}")
            # Circular 4-way mirror adjustment dial + chrome trim ring + L/R selector pads
            mx, my, mr = 0.447, 0.643, 0.023
            circ = [(mx + mr * cos(t), my + mr * sin(t)) for t in np.linspace(0, 2 * pi, 28, endpoint=False)]
            d_plate(circ, 0.0094, 0.0138, mats["Mat_Black_Trim_Gloss"], "_mirror_dial")
            parts.append(
                make_tube(
                    "_mirror_ring",
                    [(a, side_sign * b, sill_z(a) + 0.0145) for a, b in circ],
                    0.0014,
                    mats["Mat_Aluminum_Brushed"],
                    door,
                    segments=8,
                    cyclic=True,
                )
            )
            for j in range(4):
                ang = 0.5 * pi * j
                dx, dy = mx + 0.014 * cos(ang), my + 0.014 * sin(ang)
                parts.append(
                    make_cylinder(
                        f"_mir_dot_{j}",
                        (dx, side_sign * dy, sill_z(dx) + 0.0138),
                        (dx, side_sign * dy, sill_z(dx) + 0.0156),
                        0.0020,
                        0.0018,
                        mats["Mat_White_Paint"],
                        door,
                        segments=8,
                    )
                )
        else:
            # Passenger (R): matching sloped brushed-aluminum armrest pod w/ single window switch (HTE/02-right)
            d_plate(_rounded_rect_2d(0.398, 0.643, 0.255, 0.072, 0.026), -0.004, 0.007, mats["Mat_Aluminum_Brushed"], "_pas_pod")
            d_plate(_rounded_rect_2d(0.398, 0.643, 0.088, 0.044, 0.014), 0.0072, 0.0094, mats["Mat_Switch_Black"], "_pas_pocket")
            d_plate(_rounded_rect_2d(0.398, 0.643, 0.036, 0.022, 0.005), 0.0094, 0.0142, mats["Mat_Black_Trim_Gloss"], "_pas_win")
            d_plate(_rounded_rect_2d(0.410, 0.643, 0.006, 0.020, 0.002), 0.0142, 0.0160, mats["Mat_Aluminum_Brushed"], "_pas_win_tip")

        # 2. Diagonal brushed-metal BOSE Performance Series door speaker bezel + acoustic grille (HTE/04-left)
        # Sits cleanly OUTBOARD (y=0.692..0.684) and ABOVE (+0.032 Z) the brushed armrest switch pod!
        rim = tuple((x, z + 0.032) for x, z in (
            (0.800, 0.733), (0.768, 0.750), (0.432, 0.721), (0.376, 0.708),
            (0.184, 0.585), (0.176, 0.568), (0.191, 0.550), (0.310, 0.507),
            (0.333, 0.511), (0.776, 0.688), (0.802, 0.711),
        ))
        cx, cz = 0.491, 0.670
        face = [(cx + (x - cx) * 0.935, cz + (z - cz) * 0.860) for x, z in rim]
        parts.append(
            make_loft(
                f"_bose_bezel_{side_tag}",
                [[(x, side_sign * y, z) for x, z in rim] for y in (0.694, 0.686)],
                mats["Mat_Aluminum_Brushed"],
                door,
                auto_smooth_deg=35.0,
            )
        )
        parts.append(
            make_loft(
                f"_bose_grille_{side_tag}",
                [[(x, side_sign * y, z) for x, z in face] for y in (0.6855, 0.6835)],
                mats["Mat_Dark_Mesh"],
                door,
            )
        )

        # Driver seat memory keypad (SET / 1 / 2 / Exit) recessed into rear lower corner of speaker bezel
        if side_sign > 0:
            mem = ((0.287, 0.592), (0.213, 0.616), (0.203, 0.606), (0.278, 0.581))
            parts.append(
                make_loft(
                    "_drv_memory_pad",
                    [[(x, side_sign * y, z) for x, z in mem] for y in (0.683, 0.679)],
                    mats["Mat_Switch_Black"],
                    door,
                )
            )
            for idx in range(4):
                xx = 0.276 - 0.018 * idx
                zz = 0.588 + 0.0055 * idx
                parts.append(
                    make_tube(
                        f"_mem_dot_{idx}",
                        [(xx, side_sign * 0.678, zz), (xx - 0.005, side_sign * 0.678, zz + 0.0017)],
                        0.0009,
                        mats["Mat_White_Paint"],
                        door,
                        segments=5,
                    )
                )

        join_meshes(parts, f"ZR1X_Door_SwitchPod_{side_tag}", door, auto_smooth_deg=38.0)


# ---------------------------------------------------------------------------
# Public Module Entrypoint
# ---------------------------------------------------------------------------

def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Populate ``Pivot_Interior_Cabin`` (and door switch pods on ``Pivot_Door_L/R``)."""
    _build_tub_and_carpet(pivots, mats)
    _build_bulkhead(pivots, mats)
    _build_dash_and_screens(pivots, mats)
    _build_console(pivots, mats)
    _build_steering_wheel(pivots, mats)
    _build_gt2_seats(pivots, mats)
    _build_pedals(pivots, mats)
    _build_header_and_mirror(pivots, mats)
    _build_door_switch_pods(pivots, mats)


if __name__ == "__main__":
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import materials
    import rig_utils

    bpy.ops.wm.read_factory_settings(use_empty=True)
    m = materials.create_materials()
    p = rig_utils.create_rig()
    build(p, m)
    cab_meshes = [o for o in bpy.data.objects if o.type == "MESH"]
    print(f"cabin_build.py OK: built {len(cab_meshes)} clean meshes:")
    for o in sorted(cab_meshes, key=lambda ob: ob.name):
        print(f"  {o.name:30s} parent={o.parent.name:22s} verts={len(o.data.vertices):5d} polys={len(o.data.polygons):5d}")
