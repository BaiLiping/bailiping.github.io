"""Complete continuous twin-turbo quad center-exit exhaust system for ZR1X v2.

Populates ``Pivot_Exhaust_System`` (world pos ``(-1.650, 0.000, +0.320)``).
Photo-matched to Autoweek LT7 rear view and Spexx underbody exhaust shot
(``129-quad-exhaust-from-below.jpg``):
- Starts flush on BOTH LT7 rear turbine outlet flanges at ``X = -1.120, Y = ±0.385, Z = +0.492``.
- Twin swept downpipes clear the rear half-shafts (``X = -1.3615, Z = 0.353``) ->
  twin quilted-heat-shield catalytic converters -> braided flex bellows ->
  compact transverse rear valved titanium muffler with electronic actuators ->
  4 swept tailpipes -> 4 rolled double-wall brushed-titanium tips recessed flush
  inside the rear fascia hexagonal exhaust bezel (NOT protruding like cannons).
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

import bpy
import numpy as np

from rig_utils import (
    join_meshes,
    make_cylinder,
    make_loft,
    make_mesh,
    make_roundbox,
    make_tube,
)


def _m(mats: Dict[str, bpy.types.Material], key: str, fallback: str = "Mat_Titanium_Exhaust") -> bpy.types.Material:
    return mats.get(key) or mats.get(fallback) or next(iter(mats.values()))


def _ellipse_loft(
    name: str,
    stations: Sequence[Tuple[float, float, float, float, float]],
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    steps: int = 32,
) -> bpy.types.Object:
    sections = []
    for ax, yc, zc, ry, rz in stations:
        sections.append([
            (ax, yc + ry * math.cos(t), zc + rz * math.sin(t))
            for t in np.linspace(0, 2 * math.pi, steps, endpoint=False)
        ])
    return make_loft(name, sections, mat, pivot, smooth=True, auto_smooth_deg=48.0)


def _bolt_cluster(
    name: str,
    centers: Sequence[Tuple[float, float, float]],
    radius: float,
    height: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
) -> bpy.types.Object:
    verts, faces = [], []
    for cx, cy, cz in centers:
        base = len(verts)
        for off, r in ((0.0, radius), (height * 0.85, radius), (height, radius * 0.80)):
            for k in range(6):
                a = k * math.pi / 3.0
                verts.append((cx + off, cy + r * math.cos(a), cz + r * math.sin(a)))
        for j in range(2):
            for k in range(6):
                nk = (k + 1) % 6
                faces.append((base + j * 6 + k, base + j * 6 + nk, base + (j + 1) * 6 + nk, base + (j + 1) * 6 + k))
        faces.append(tuple(base + 12 + k for k in range(6)))
    return make_mesh(name, verts, faces, mat, pivot, smooth=False, recalc_normals=True)


def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Populate ``Pivot_Exhaust_System`` with full continuous routing from LT7 turbos to quad tips."""
    piv = pivots["Pivot_Exhaust_System"]

    ti = _m(mats, "Mat_Titanium_Exhaust")
    heat = _m(mats, "Mat_Heat_Shield")
    steel = _m(mats, "Mat_Steel_Machined")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    bore_dark = _m(mats, "Mat_Dark_Mesh", "Mat_Black_Trim_Satin")

    # 1) Twin Swept Turbo Downpipes (ZR1X_Exh_Downpipe_L/R)
    # Mate flush to LT7 turbine exits at X=-1.120, Y=±0.385, Z=+0.492 and clear rear half-shafts!
    for s, tag in ((1.0, "L"), (-1.0, "R")):
        dparts: List[bpy.types.Object] = []
        # 5-bolt stainless turbine mating flange
        dparts.append(_ellipse_loft(
            "tmp_dp_flange",
            ((-1.121, s * 0.385, 0.492, 0.076, 0.073), (-1.132, s * 0.385, 0.492, 0.078, 0.075), (-1.138, s * 0.385, 0.492, 0.052, 0.050)),
            steel, piv, steps=28,
        ))
        dparts.append(_bolt_cluster(
            "tmp_dp_bolts",
            [(-1.132, s * 0.385 + 0.066 * math.cos(t), 0.492 + 0.062 * math.sin(t))
             for t in np.linspace(0.15, 2 * math.pi + 0.15, 5, endpoint=False)],
            0.006, -0.007, steel, piv,
        ))
        # Swept 76 mm mandrel-bent downpipe routing cleanly OVER rear half-shaft (X=-1.3615, Z=0.353)
        dp_pts = [
            (-1.130, s * 0.385, 0.492),
            (-1.205, s * 0.405, 0.496),
            (-1.300, s * 0.415, 0.492),
            (-1.385, s * 0.405, 0.478),
            (-1.445, s * 0.388, 0.456),
        ]
        dparts.append(make_tube("tmp_dp_pipe", dp_pts, 0.038, ti, piv, segments=20))
        # Pre-cat wideband O2 sensor bung + body
        dparts.append(make_cylinder(
            "tmp_o2_pre", (-1.24, s * 0.408, 0.525), (-1.24, s * 0.425, 0.568),
            0.009, 0.008, steel, piv, segments=10,
        ))
        join_meshes(dparts, f"ZR1X_Exh_Downpipe_{tag}", piv)

        # 2) High-Flow Catalytic Converters + Heat Blankets + Braided Flex Bellows (ZR1X_Exh_Cat_L/R)
        cparts: List[bpy.types.Object] = []
        # Tapered conical catalytic converter canister along flanks of DCT (X=-1.445 .. -1.705)
        cat_st = (
            (-1.440, s * 0.388, 0.456, 0.040, 0.040),
            (-1.482, s * 0.380, 0.436, 0.068, 0.064),
            (-1.625, s * 0.365, 0.398, 0.070, 0.066),
            (-1.675, s * 0.358, 0.382, 0.062, 0.058),
            (-1.710, s * 0.352, 0.370, 0.036, 0.036),
        )
        cparts.append(_ellipse_loft("tmp_cat_body", cat_st, heat, piv, steps=28))
        # Retaining heat-shield clamp bands around cat canister
        for cx, cy, cz in ((-1.505, s * 0.377, 0.428), (-1.615, s * 0.366, 0.400)):
            cparts.append(_ellipse_loft(
                "tmp_cat_band",
                ((cx - 0.006, cy, cz, 0.073, 0.069), (cx + 0.006, cy, cz, 0.073, 0.069)),
                steel, piv, steps=28,
            ))
        # Post-cat O2 sensor
        cparts.append(make_cylinder(
            "tmp_o2_post", (-1.68, s * 0.356, 0.415), (-1.68, s * 0.365, 0.458),
            0.008, 0.007, steel, piv, segments=10,
        ))
        # Aft crossover mid-pipe with braided stainless flex-bellows curving around DCT tail into muffler
        mid_pts = [
            (-1.705, s * 0.352, 0.370),
            (-1.785, s * 0.350, 0.342),
            (-1.868, s * 0.335, 0.318),
            (-1.945, s * 0.305, 0.305),
            (-1.995, s * 0.265, 0.305),
        ]
        cparts.append(make_tube("tmp_midpipe", mid_pts, 0.035, ti, piv, segments=18))
        # Ribbed stainless flex-joint sleeve (prominent in Spexx 129!)
        for k in range(6):
            t_f = 0.25 + k * 0.075
            fx = -1.785 - k * 0.015
            fy = s * (0.350 - k * 0.003)
            fz = 0.342 - k * 0.0045
            cparts.append(_ellipse_loft(
                "tmp_flex",
                ((fx - 0.005, fy, fz, 0.043, 0.043), (fx + 0.005, fy, fz, 0.043, 0.043)),
                brushed, piv, steps=20,
            ))
        join_meshes(cparts, f"ZR1X_Exh_Cat_{tag}", piv)

    # 3) Compact Rear Transverse Valved Muffler & Electronic Valve Actuators (ZR1X_Exh_Muffler)
    # Sits cleanly behind DCT tail (X = -1.94) and ahead of rear fascia bezel (X = -2.21)
    mparts: List[bpy.types.Object] = []
    # Sculpted rounded oval transverse acoustic chamber (Y = -0.32 .. +0.32, X = -1.97 .. -2.09, Z = 0.26 .. 0.37)
    muff_secs = []
    for yy in np.linspace(-0.32, 0.32, 13):
        taper = 1.0 - 0.14 * (abs(yy) / 0.32) ** 3
        rx, rz = 0.058 * taper, 0.056 * taper
        muff_secs.append([
            (-2.030 + rx * math.cos(a), float(yy), 0.316 + rz * math.sin(a))
            for a in np.linspace(0, 2 * math.pi, 24, endpoint=False)
        ])
    mparts.append(make_loft("tmp_muff_shell", muff_secs, ti, piv, auto_smooth_deg=45.0))
    # Welded transverse reinforcing seam flanges & rubber exhaust hanger brackets
    for sy in (-0.24, 0.0, 0.24):
        mparts.append(make_roundbox("tmp_mseam", (-2.030, sy, 0.316), (0.122, 0.010, 0.118), brushed, piv, bevel=0.003))
    for s in (-1.0, 1.0):
        # Electronic active exhaust valve actuator box + stamped steel bracket + linkage arm (Spexx 129!)
        mparts.append(make_roundbox("tmp_valv_act", (-2.045, s * 0.115, 0.248), (0.062, 0.068, 0.036), dark, piv, bevel=0.006))
        mparts.append(make_roundbox("tmp_valv_brk", (-2.045, s * 0.155, 0.268), (0.048, 0.042, 0.012), steel, piv, bevel=0.002))
        mparts.append(make_cylinder("tmp_valv_arm", (-2.045, s * 0.135, 0.248), (-2.055, s * 0.174, 0.295), 0.004, 0.004, steel, piv, segments=8))
        # Rear subframe exhaust hanger rods
        mparts.append(make_tube(
            "tmp_hanger",
            [(-2.03, s * 0.30, 0.365), (-2.01, s * 0.34, 0.425), (-1.99, s * 0.34, 0.470)],
            0.0065, steel, piv, segments=8,
        ))
    join_meshes(mparts, "ZR1X_Exh_Muffler", piv)

    # 4) Quad Swept Center-Exit Tailpipes (ZR1X_Exh_Tailpipes)
    tip_specs = (
        # (y_center, x_rear_lip, z_center) — symmetric, recessed cleanly inside rear fascia bezel!
        (0.174, -2.208, 0.336),
        (0.058, -2.220, 0.336),
        (-0.058, -2.220, 0.336),
        (-0.174, -2.208, 0.336),
    )
    pparts: List[bpy.types.Object] = []
    for ty, tx_lip, tz in tip_specs:
        pparts.append(make_tube(
            "tmp_tpipe",
            [(-2.055, ty * 1.04, 0.318), (-2.095, ty * 1.02, 0.328), (tx_lip + 0.072, ty, tz)],
            0.034, ti, piv, segments=18,
        ))
        # Butterfly valve collar on outer pair
        if abs(ty) > 0.10:
            pparts.append(make_cylinder("tmp_vcollar", (-2.110, ty, tz - 0.040), (-2.110, ty, tz + 0.040), 0.008, 0.008, steel, piv, segments=10))
    join_meshes(pparts, "ZR1X_Exh_Tailpipes", piv)

    # 5) 4 Rolled Double-Wall Center-Exit Titanium Tips + Dark Inner Bores (ZR1X_Exh_Tips)
    tip_parts: List[bpy.types.Object] = []
    for ty, tx_lip, tz in tip_specs:
        # Double-wall rolled bezel profile (outer bell -> rolled front bevel -> inner wall back to baffle)
        # Note: -X is rearward, so tip rear lip is at tx_lip and extends forward (+X) by 0.088 m
        profile = (
            (tx_lip + 0.088, 0.045),
            (tx_lip + 0.022, 0.050),
            (tx_lip + 0.006, 0.0525),
            (tx_lip, 0.0510),
            (tx_lip, 0.0465),
            (tx_lip + 0.006, 0.0445),
            (tx_lip + 0.078, 0.0435),
        )
        secs = [
            [(xx, ty + rr * math.cos(a), tz + rr * math.sin(a)) for a in np.linspace(0, 2 * math.pi, 40, endpoint=False)]
            for xx, rr in profile
        ]
        tip_parts.append(make_loft("tmp_tip_wall", secs, brushed, piv, cap_ends=False, auto_smooth_deg=45.0))
        # Deep matte-black exhaust inner bore baffle so tips read hollow & realistic
        tip_parts.append(make_cylinder(
            "tmp_tip_bore", (tx_lip + 0.072, ty, tz), (tx_lip + 0.080, ty, tz),
            0.044, 0.044, bore_dark, piv, segments=32,
        ))
    join_meshes(tip_parts, "ZR1X_Exh_Tips", piv)
