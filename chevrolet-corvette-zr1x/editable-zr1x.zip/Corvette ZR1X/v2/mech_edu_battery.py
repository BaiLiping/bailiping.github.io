"""Front 186 hp e-AWD Electric Drive Unit (EDU) & 1.9 kWh 300V central tunnel battery.

Populates:
- ``Pivot_Front_EDU`` (world pos ``(+1.3615, 0.000, +0.350)``):
  Separable outer casings (``ZR1X_EDU_Case_Motor``, ``ZR1X_EDU_Case_Gearbox``),
  top inverter (``ZR1X_EDU_Inverter``), bright-orange 3-phase HV cables
  (``ZR1X_EDU_HVCables``), plus exposed internal stator/copper windings/rotor
  (``ZR1X_EDU_Int_StatorRotor``), 2-stage helical reduction gearset
  (``ZR1X_EDU_Int_ReductionGears``), and front differential (``ZR1X_EDU_Int_FrontDiff``).
- ``Pivot_Hybrid_Battery`` (world pos ``(+0.380, 0.000, +0.280)``):
  Structural base tray w/ orange perimeter gasket (``ZR1X_Battery_Tray``),
  separable top lid (``ZR1X_Battery_Cover_Top``), louvered front electronics bay
  w/ red & blue keyed connectors (``ZR1X_Battery_Electronics``), 4 cell module
  stacks w/ brass straps & copper busbars (``ZR1X_Battery_Int_Modules``), and
  top orange HV interconnects (``ZR1X_Battery_HVCables``).
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

import bpy
import numpy as np

from rig_utils import (
    AXLE_F_X,
    TIRE_R_F,
    join_meshes,
    make_cylinder,
    make_loft,
    make_mesh,
    make_roundbox,
    make_tube,
)


def _m(mats: Dict[str, bpy.types.Material], key: str, fallback: str = "Mat_Aluminum_Cast") -> bpy.types.Material:
    return mats.get(key) or mats.get(fallback) or next(iter(mats.values()))


def _get_or_make_accent(name: str, rgba_lin: Tuple[float, float, float], metallic: float, rough: float) -> bpy.types.Material:
    existing = bpy.data.materials.get(name)
    if existing is not None:
        return existing
    m = bpy.data.materials.new(name=name)
    m.use_nodes = True
    m.diffuse_color = (*rgba_lin, 1.0)
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*rgba_lin, 1.0)
        bsdf.inputs["Metallic"].default_value = metallic
        bsdf.inputs["Roughness"].default_value = rough
    return m


def _ellipse_case(
    name: str,
    stations: Sequence[Tuple[float, float, float, float, float]],
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "y",
    steps: int = 32,
) -> bpy.types.Object:
    sections = []
    for axial, u0, z0, ru, rz in stations:
        ring = []
        for j in range(steps):
            t = 2.0 * math.pi * j / steps
            u = u0 + ru * math.cos(t)
            z = z0 + rz * math.sin(t)
            ring.append((axial, u, z) if axis == "x" else (u, axial, z))
        sections.append(ring if axis == "x" else ring[::-1])
    return make_loft(name, sections, mat, pivot, smooth=True, auto_smooth_deg=45.0)


def _bolt_cluster(
    name: str,
    centers: Sequence[Tuple[float, float, float]],
    radius: float,
    height: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
    axis: str = "z",
) -> bpy.types.Object:
    verts, faces = [], []
    for cx, cy, cz in centers:
        base = len(verts)
        for off, r in ((0.0, radius), (height * 0.85, radius), (height, radius * 0.80)):
            for k in range(6):
                a = k * math.pi / 3.0
                u, v = r * math.cos(a), r * math.sin(a)
                if axis == "z":
                    verts.append((cx + u, cy + v, cz + off))
                elif axis == "y":
                    verts.append((cx + u, cy + off, cz + v))
                else:
                    verts.append((cx + off, cy + u, cz + v))
        for j in range(2):
            for k in range(6):
                nk = (k + 1) % 6
                faces.append((base + j * 6 + k, base + j * 6 + nk, base + (j + 1) * 6 + nk, base + (j + 1) * 6 + k))
        faces.append(tuple(base + 12 + k for k in range(6)))
    return make_mesh(name, verts, faces, mat, pivot, smooth=False, recalc_normals=True)


def _make_helical_gear_y(
    name: str,
    cx: float,
    cy: float,
    cz: float,
    pitch_r: float,
    width: float,
    n_teeth: int,
    helix_twist: float,
    bore_r: float,
    mat: bpy.types.Material,
    pivot: bpy.types.Object,
) -> bpy.types.Object:
    """Crisp 3D transverse-axis (Y) helical gear for the front EDU reduction drive."""
    addendum = min(0.0038, 0.92 * math.pi * pitch_r / max(n_teeth, 10) * 0.42)
    dedendum = addendum * 1.18
    r_root = max(bore_r + 0.004, pitch_r - dedendum)
    r_tip = pitch_r + addendum
    r_web = max(bore_r + 0.003, r_root - 0.005)
    n_ring = n_teeth * 4
    verts, faces = [], []

    def _pt(ay: float, rad: float, ang: float) -> Tuple[float, float, float]:
        return (cx + rad * math.cos(ang), cy + ay, cz + rad * math.sin(ang))

    layers = (
        (-width * 0.50, 0.97, -helix_twist * 0.50),
        (-width * 0.44, 1.00, -helix_twist * 0.44),
        (width * 0.44, 1.00, helix_twist * 0.44),
        (width * 0.50, 0.97, helix_twist * 0.50),
    )
    for ay, sc, tw in layers:
        for k in range(n_teeth):
            for ph, is_tip in ((0.0, False), (0.20, True), (0.55, True), (0.75, False)):
                ang = 2.0 * math.pi * (k + ph) / n_teeth + tw
                rad = (r_root + (r_tip - r_root) * sc) if is_tip else r_root
                verts.append(_pt(ay, rad, ang))

    for lay in range(3):
        a0, b0 = lay * n_ring, (lay + 1) * n_ring
        for i in range(n_ring):
            ni = (i + 1) % n_ring
            faces.append((a0 + i, a0 + ni, b0 + ni, b0 + i))

    fw = len(verts)
    for i in range(n_ring):
        verts.append(_pt(-width * 0.34, r_web, 2.0 * math.pi * i / n_ring - helix_twist * 0.5))
    fb = len(verts)
    for i in range(n_ring):
        verts.append(_pt(-width * 0.52, bore_r, 2.0 * math.pi * i / n_ring - helix_twist * 0.5))
    rw = len(verts)
    for i in range(n_ring):
        verts.append(_pt(width * 0.34, r_web, 2.0 * math.pi * i / n_ring + helix_twist * 0.5))
    rb = len(verts)
    for i in range(n_ring):
        verts.append(_pt(width * 0.52, bore_r, 2.0 * math.pi * i / n_ring + helix_twist * 0.5))

    for i in range(n_ring):
        ni = (i + 1) % n_ring
        faces.append((0 + ni, 0 + i, fw + i, fw + ni))
        faces.append((fw + ni, fw + i, fb + i, fb + ni))
        faces.append((3 * n_ring + i, 3 * n_ring + ni, rw + ni, rw + i))
        faces.append((rw + i, rw + ni, rb + ni, rb + i))
        faces.append((fb + i, rb + i, rb + ni, fb + ni))

    return make_mesh(name, verts, faces, mat, pivot, smooth=False, recalc_normals=True)


# ---------------------------------------------------------------------------
# 1. Front e-AWD Electric Drive Unit (Pivot_Front_EDU)
# ---------------------------------------------------------------------------

def _build_front_edu(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    gun = _m(mats, "Mat_Gear_Steel")
    steel = _m(mats, "Mat_Steel_Machined")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    hv = _m(mats, "Mat_HV_Orange")
    copper = _m(mats, "Mat_Copper_Busbar", "Mat_Heat_Shield")

    mx, mz = 1.360, 0.365   # Traction motor centerline (coaxial/slightly above front axle)
    ax, az = AXLE_F_X, TIRE_R_F  # Front half-shaft axle centerline (1.3615, 0.3365)

    # A) Separable Traction Motor Housing (ZR1X_EDU_Case_Motor, driver/left +Y side)
    mparts: List[bpy.types.Object] = []
    mparts.append(_ellipse_case(
        "tmp_motor_case",
        (
            (-0.025, mx, mz, 0.124, 0.122),
            (0.015, mx, mz, 0.141, 0.140),
            (0.165, mx, mz, 0.144, 0.143),
            (0.200, mx, mz, 0.136, 0.136),
            (0.220, mx, mz, 0.104, 0.108),
        ),
        cast, piv, axis="y", steps=36,
    ))
    # Circumferential cooling-jacket ribs
    for yy in (0.032, 0.062, 0.092, 0.122, 0.152, 0.180):
        mparts.append(_ellipse_case(
            "tmp_mrib",
            ((yy - 0.004, mx, mz, 0.148, 0.147), (yy + 0.004, mx, mz, 0.148, 0.147)),
            brushed, piv, axis="y", steps=32,
        ))
    # End-cover perimeter hex bolts & structural subframe mounting ears
    mparts.append(_bolt_cluster(
        "tmp_mbolts",
        [(mx + 0.118 * math.cos(t), 0.210, mz + 0.118 * math.sin(t)) for t in np.linspace(0, 2 * math.pi, 10, endpoint=False)],
        0.006, 0.008, steel, piv, axis="y",
    ))
    for ex, ey, ez in ((1.425, 0.136, 0.460), (1.285, 0.132, 0.455)):
        mparts.append(make_roundbox("tmp_mear", (ex, ey, ez), (0.054, 0.042, 0.044), cast, piv, bevel=0.008))
        mparts.append(make_cylinder("tmp_msleeve", (ex, ey, ez - 0.024), (ex, ey, ez + 0.024), 0.014, 0.014, gun, piv, segments=14))
    join_meshes(mparts, "ZR1X_EDU_Case_Motor", piv)

    # B) Separable Reduction Gearbox & Front Diff Housing (ZR1X_EDU_Case_Gearbox, right -Y side)
    gparts: List[bpy.types.Object] = []
    gparts.append(_ellipse_case(
        "tmp_gb_case",
        (
            (-0.010, 1.350, 0.346, 0.132, 0.122),
            (-0.045, 1.350, 0.346, 0.152, 0.134),
            (-0.115, 1.338, 0.348, 0.150, 0.136),
            (-0.165, 1.350, 0.352, 0.128, 0.122),
            (-0.208, 1.356, 0.346, 0.088, 0.094),
        ),
        cast, piv, axis="y", steps=34,
    ))
    # Layshaft stepped upper gear cover boss + radial stiffening ribs
    gparts.append(_ellipse_case(
        "tmp_lay_boss",
        ((-0.148, 1.396, 0.380, 0.078, 0.078), (-0.175, 1.396, 0.380, 0.080, 0.078), (-0.198, 1.396, 0.380, 0.066, 0.066)),
        brushed, piv, axis="y", steps=24,
    ))
    for t in np.linspace(0, 2 * math.pi, 8, endpoint=False):
        gparts.append(make_tube(
            "tmp_gb_rib",
            [(1.396 + 0.068 * math.cos(t), -0.188, 0.380 + 0.060 * math.sin(t)),
             (1.352 + 0.118 * math.cos(t), -0.160, 0.352 + 0.106 * math.sin(t))],
            0.0045, brushed, piv, segments=6,
        ))
    # Bolted center split flange, compact lower EDU sump (mech-edu-front-render.png!) & right mounting ear
    gparts.append(_ellipse_case(
        "tmp_gb_flange",
        ((-0.136, 1.348, 0.348, 0.134, 0.126), (-0.148, 1.348, 0.348, 0.134, 0.126)),
        brushed, piv, axis="y", steps=28,
    ))
    gparts.append(make_roundbox("tmp_edu_sump", (1.365, -0.055, 0.215), (0.115, 0.088, 0.056), cast, piv, bevel=0.012))
    gparts.append(make_roundbox("tmp_gear", (1.436, -0.106, 0.432), (0.054, 0.042, 0.044), cast, piv, bevel=0.008))
    join_meshes(gparts, "ZR1X_EDU_Case_Gearbox", piv)

    # C) Top Power Inverter Module (ZR1X_EDU_Inverter)
    iparts: List[bpy.types.Object] = []
    iparts.append(make_roundbox("tmp_inv_body", (1.265, 0.020, 0.442), (0.145, 0.175, 0.046), cast, piv, bevel=0.010))
    iparts.append(make_roundbox("tmp_inv_cap", (1.245, 0.015, 0.466), (0.115, 0.145, 0.018), dark, piv, bevel=0.006))
    for k in range(6):
        iparts.append(make_roundbox("tmp_inv_fin", (1.208 + k * 0.015, 0.015, 0.476), (0.005, 0.120, 0.006), brushed, piv, bevel=0.001))
    iparts.append(_bolt_cluster(
        "tmp_inv_bolts",
        [(1.245 + dx, 0.015 + dy, 0.474) for dx in (-0.046, 0.046) for dy in (-0.058, 0.058)],
        0.005, 0.004, steel, piv, axis="z",
    ))
    join_meshes(iparts, "ZR1X_EDU_Inverter", piv)

    # D) Bright Orange 3-Phase HV Cables to Tunnel Battery (ZR1X_EDU_HVCables)
    hparts: List[bpy.types.Object] = []
    for i in range(3):
        y0 = -0.038 + i * 0.038
        # Orange terminal plug at EDU inverter aft face
        hparts.append(make_roundbox("tmp_hv_term", (1.200, y0, 0.398), (0.042, 0.030, 0.042), hv, piv, bevel=0.007))
        # Black strain-relief collar
        hparts.append(make_cylinder("tmp_hv_boot", (1.182, y0, 0.394), (1.160, y0, 0.388), 0.015, 0.012, dark, piv, segments=12))
        # Curved bright-orange 3-phase cable landing flush into front of battery electronics bay (X=+0.945)
        hparts.append(make_tube(
            "tmp_hv_lead",
            [(1.185, y0, 0.394), (1.130, y0, 0.372), (1.062, y0, 0.308), (0.945, y0, 0.292)],
            0.0105, hv, piv, segments=12,
        ))
    join_meshes(hparts, "ZR1X_EDU_HVCables", piv)

    # E) Internal Permanent-Magnet Stator, 24 Copper Hairpin Windings & Rotor (ZR1X_EDU_Int_StatorRotor)
    sparts: List[bpy.types.Object] = []
    # Laminated electrical-steel stator core
    sparts.append(make_cylinder("tmp_stator_core", (mx, 0.018, mz), (mx, 0.172, mz), 0.114, 0.114, gun, piv, segments=36))
    # 24 bright copper hairpin stator coil end-turns protruding crisply on both faces!
    for k in range(24):
        ang = 2.0 * math.pi * k / 24.0
        for ey in (0.006, 0.184):
            cx_c = mx + 0.094 * math.cos(ang)
            cz_c = mz + 0.094 * math.sin(ang)
            sparts.append(make_roundbox(
                "tmp_coil_end", (cx_c, ey, cz_c), (0.018, 0.024, 0.012), copper, piv,
                bevel=0.003, rot_euler=(0.0, -ang, 0.0),
            ))
    # Copper 3-phase collector bus ring on inner stator face
    ring_pts = [(mx + 0.100 * math.cos(a), 0.002, mz + 0.100 * math.sin(a)) for a in np.linspace(0, 2 * math.pi, 32, endpoint=False)]
    sparts.append(make_tube("tmp_bus_ring", ring_pts, 0.007, copper, piv, segments=10, cyclic=True))
    # Inner laminated permanent-magnet rotor + stainless hollow rotor shaft
    sparts.append(make_cylinder("tmp_rotor", (mx, 0.012, mz), (mx, 0.178, mz), 0.072, 0.072, brushed, piv, segments=28))
    for k in range(8):
        ang = 2.0 * math.pi * k / 8.0
        sparts.append(make_roundbox(
            "tmp_pm_bar", (mx + 0.068 * math.cos(ang), 0.095, mz + 0.068 * math.sin(ang)),
            (0.010, 0.168, 0.018), dark, piv, bevel=0.002, rot_euler=(0.0, -ang, 0.0),
        ))
    sparts.append(make_cylinder("tmp_rotor_shaft", (mx, -0.055, mz), (mx, 0.205, mz), 0.026, 0.026, steel, piv, segments=22))
    join_meshes(sparts, "ZR1X_EDU_Int_StatorRotor", piv)

    # F) Internal Two-Stage Helical Reduction Gearset (ZR1X_EDU_Int_ReductionGears)
    rparts: List[bpy.types.Object] = []
    # Layshaft offset slightly forward & up so Stage 1 & Stage 2 mesh cleanly inside gearbox case
    lx, lz = 1.320, 0.422
    # Stage 1: Motor input pinion (r=0.022) meshing with layshaft driven helical gear (r=0.048, cd=0.070)
    rparts.append(_make_helical_gear_y("tmp_edu_pin1", mx, -0.042, mz, 0.022, 0.026, 15, 0.16, 0.014, steel, piv))
    rparts.append(_make_helical_gear_y("tmp_edu_g1", lx, -0.042, lz, 0.048, 0.026, 33, -0.16, 0.015, gun, piv))
    # Layshaft & roller bearings
    rparts.append(make_cylinder("tmp_edu_lay", (lx, -0.018, lz), (lx, -0.138, lz), 0.015, 0.015, steel, piv, segments=18))
    # Stage 2: Layshaft output pinion (r=0.025) meshing with large final-drive helical ring gear (r=0.070, cd=0.095)
    rparts.append(_make_helical_gear_y("tmp_edu_pin2", lx, -0.092, lz, 0.025, 0.028, 17, 0.18, 0.015, steel, piv))
    rparts.append(_make_helical_gear_y("tmp_edu_final", ax, -0.092, az, 0.070, 0.028, 46, -0.18, 0.036, gun, piv))
    join_meshes(rparts, "ZR1X_EDU_Int_ReductionGears", piv)

    # G) Internal Front Differential & Twin Axle Output Flanges (ZR1X_EDU_Int_FrontDiff)
    dparts: List[bpy.types.Object] = []
    dparts.append(make_cylinder("tmp_fdiff_cage", (ax, -0.155, az), (ax, -0.058, az), 0.056, 0.056, brushed, piv, segments=26))
    dparts.append(make_cylinder("tmp_fdiff_pin", (ax, -0.110, az - 0.042), (ax, -0.110, az + 0.042), 0.009, 0.009, steel, piv, segments=10))
    # Spider bevel gear faces
    for dz in (-0.026, 0.026):
        dparts.append(make_cylinder("tmp_fspider", (ax, -0.110, az + dz - 0.008), (ax, -0.110, az + dz + 0.008), 0.018, 0.014, copper, piv, segments=14))
    # Through-axle shafts + twin 6-bolt CV output cups at Y = ±0.206 (exact mate to front half-shafts!)
    dparts.append(make_cylinder("tmp_fthru_shaft", (ax, -0.200, az), (ax, 0.200, az), 0.017, 0.017, steel, piv, segments=18))
    for s in (-1.0, 1.0):
        dparts.append(make_cylinder("tmp_fcup", (ax, s * 0.186, az), (ax, s * 0.208, az), 0.058, 0.058, copper, piv, segments=24))
        dparts.append(_bolt_cluster(
            "tmp_fcup_bolts",
            [(ax + 0.044 * math.cos(t), s * 0.208, az + 0.044 * math.sin(t)) for t in np.linspace(0, 2 * math.pi, 6, endpoint=False)],
            0.0055, s * 0.005, steel, piv, axis="y",
        ))
    join_meshes(dparts, "ZR1X_EDU_Int_FrontDiff", piv)


# ---------------------------------------------------------------------------
# 2. Central Tunnel 1.9 kWh 300V Hybrid Battery (Pivot_Hybrid_Battery)
# ---------------------------------------------------------------------------

def _build_hybrid_battery(piv: bpy.types.Object, mats: Dict[str, bpy.types.Material]) -> None:
    cast = _m(mats, "Mat_Aluminum_Cast")
    brushed = _m(mats, "Mat_Aluminum_Brushed")
    gun = _m(mats, "Mat_Gear_Steel")
    steel = _m(mats, "Mat_Steel_Machined")
    dark = _m(mats, "Mat_Black_Trim_Satin")
    hv = _m(mats, "Mat_HV_Orange")
    copper = _m(mats, "Mat_Copper_Busbar", "Mat_Heat_Shield")
    brass = _m(mats, "Mat_Heat_Shield", "Mat_Copper_Busbar")
    mesh_dark = _m(mats, "Mat_Dark_Mesh", "Mat_Black_Trim_Satin")
    key_red = _m(mats, "Mat_Emblem_Red", "Mat_Torch_Red_GKZ")
    key_blue = _m(mats, "Mat_LT7_Plenum_Blue")

    # A) Structural Base Tray + Iconic Bright-Orange Perimeter Gasket (ZR1X_Battery_Tray)
    tparts: List[bpy.types.Object] = []
    tparts.append(make_roundbox("tmp_btray", (0.379, 0.0, 0.188), (1.168, 0.236, 0.024), gun, piv, bevel=0.008))
    tparts.append(make_roundbox("tmp_bgasket", (0.379, 0.0, 0.203), (1.154, 0.224, 0.010), hv, piv, bevel=0.004))
    tparts.append(_bolt_cluster(
        "tmp_btray_bolts",
        [(xx, s * 0.108, 0.205) for xx in np.linspace(-0.175, 0.925, 11) for s in (-1.0, 1.0)],
        0.0045, 0.004, steel, piv, axis="z",
    ))
    join_meshes(tparts, "ZR1X_Battery_Tray", piv)

    # B) Separable Ribbed Top Lid (ZR1X_Battery_Cover_Top — lifts +14 u on explode/X-ray!)
    cparts: List[bpy.types.Object] = []
    cparts.append(make_roundbox("tmp_blid", (0.190, 0.0, 0.382), (0.765, 0.214, 0.022), dark, piv, bevel=0.008))
    # Side vertical skirts hugging the 4 cell modules when assembled
    for s in (-1.0, 1.0):
        cparts.append(make_roundbox("tmp_bskirt", (0.190, s * 0.105, 0.320), (0.755, 0.008, 0.115), dark, piv, bevel=0.003))
    for xx in np.linspace(-0.14, 0.52, 8):
        cparts.append(make_roundbox("tmp_blid_rib", (float(xx), 0.0, 0.394), (0.012, 0.188, 0.006), gun, piv, bevel=0.002))
    join_meshes(cparts, "ZR1X_Battery_Cover_Top", piv)

    # C) Forward Power Electronics / BECM Bay + Louvered Top + Red/Blue Keyed Connectors (ZR1X_Battery_Electronics)
    eparts: List[bpy.types.Object] = []
    eparts.append(make_roundbox("tmp_elec_box", (0.756, 0.0, 0.278), (0.370, 0.188, 0.152), brushed, piv, bevel=0.014))
    eparts.append(make_roundbox("tmp_elec_top", (0.756, 0.0, 0.362), (0.368, 0.196, 0.036), dark, piv, bevel=0.009))
    # 16 twin cooling louvers on top electronics cover (GM TechLink battery cutaway!)
    for j in range(16):
        xx = 0.605 + 0.019 * j
        for s in (-1.0, 1.0):
            eparts.append(make_roundbox("tmp_elouv", (xx, s * 0.044, 0.381), (0.009, 0.050, 0.003), mesh_dark, piv, bevel=0.001))
    # Iconic Red & Blue front keyed HV/LV connectors at X = +0.946 (GM TechLink cutaway!)
    for y0, z0, cmat in ((0.043, 0.312, key_red), (-0.046, 0.285, key_blue)):
        eparts.append(make_roundbox("tmp_kconn", (0.946, y0, z0), (0.022, 0.062, 0.044), cmat, piv, bevel=0.006))
        eparts.append(make_roundbox("tmp_ksock", (0.958, y0, z0), (0.004, 0.042, 0.024), mesh_dark, piv, bevel=0.002))
    eparts.append(_bolt_cluster(
        "tmp_eplate_bolts",
        [(0.944, y, z) for y in (-0.076, 0.076) for z in (0.225, 0.343)],
        0.0055, 0.004, steel, piv, axis="x",
    ))
    join_meshes(eparts, "ZR1X_Battery_Electronics", piv)

    # D) 4 Exposed Prismatic/Pouch Cell Module Stacks + Brass Straps + Copper Busbars (ZR1X_Battery_Int_Modules)
    mparts: List[bpy.types.Object] = []
    mod_xs = (-0.065, 0.115, 0.295, 0.475)
    for idx, xx in enumerate(mod_xs):
        # Dark polymer module end-frames + 8 individual brushed-aluminum pouch cell cooling fins per module!
        mparts.append(make_roundbox("tmp_mframe", (xx, 0.0, 0.282), (0.164, 0.184, 0.148), dark, piv, bevel=0.006))
        for cell_i in range(7):
            cx = xx - 0.060 + cell_i * 0.020
            mparts.append(make_roundbox("tmp_cell", (cx, 0.0, 0.284), (0.011, 0.190, 0.136), brushed, piv, bevel=0.002))
        # Iconic gold/brass retaining strap wrapping over each cell module (GM TechLink cutaway!)
        mparts.append(make_tube(
            "tmp_bstrap",
            [
                (xx + 0.064, -0.100, 0.208), (xx + 0.064, -0.098, 0.356),
                (xx + 0.064, -0.090, 0.364), (xx + 0.064, 0.090, 0.364),
                (xx + 0.064, 0.098, 0.356), (xx + 0.064, 0.100, 0.208),
            ],
            0.006, brass, piv, segments=8,
        ))
        for s in (-1.0, 1.0):
            mparts.append(make_roundbox("tmp_sfoot", (xx + 0.062, s * 0.100, 0.222), (0.040, 0.012, 0.026), brass, piv, bevel=0.003))
        # Top copper cell terminal collector bar + orange sense block
        mparts.append(make_roundbox("tmp_tbus", (xx - 0.010, 0.0, 0.362), (0.125, 0.092, 0.012), copper, piv, bevel=0.003))
        mparts.append(make_roundbox("tmp_tsense", (xx, 0.0, 0.372), (0.048, 0.052, 0.014), hv, piv, bevel=0.003))
        # Series copper busbars bridging adjacent modules
        if idx < len(mod_xs) - 1:
            mid_x = 0.5 * (xx + mod_xs[idx + 1])
            side_y = 0.042 if idx % 2 == 0 else -0.042
            mparts.append(make_roundbox("tmp_cbus_link", (mid_x, side_y, 0.366), (0.075, 0.022, 0.007), copper, piv, bevel=0.002))
    join_meshes(mparts, "ZR1X_Battery_Int_Modules", piv)

    # E) Bright Orange HV Interconnect Harness & Rear Coolant Stubs (ZR1X_Battery_HVCables)
    vparts: List[bpy.types.Object] = []
    for s in (-1.0, 1.0):
        vparts.append(make_tube(
            "tmp_bhv_line",
            [(0.840, s * 0.070, 0.370), (0.640, s * 0.072, 0.374), (0.510, s * 0.068, 0.366), (0.390, s * 0.064, 0.372), (-0.148, s * 0.064, 0.369)],
            0.0055, hv, piv, segments=10,
        ))
        # Rear thermal-management coolant lines heading aft toward engine cooling loop
        vparts.append(make_tube(
            "tmp_bcool",
            [(-0.185, s * 0.048, 0.255), (-0.235, s * 0.062, 0.248), (-0.275, s * 0.085, 0.242)],
            0.010, dark, piv, segments=10,
        ))
    join_meshes(vparts, "ZR1X_Battery_HVCables", piv)


def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Populate ``Pivot_Front_EDU`` and ``Pivot_Hybrid_Battery``."""
    _build_front_edu(pivots["Pivot_Front_EDU"], mats)
    _build_hybrid_battery(pivots["Pivot_Hybrid_Battery"], mats)
