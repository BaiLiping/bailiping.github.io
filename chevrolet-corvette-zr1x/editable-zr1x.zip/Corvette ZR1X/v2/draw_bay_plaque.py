"""Draw the ZR1X bay label artwork. Run using the same Python/Pillow as the dashboard artwork."""
from pathlib import Path
from PIL import Image, ImageDraw
from materials import _font


def _draw_plaque():
    image = Image.new("RGB", (1024, 384), (189, 196, 202))
    draw = ImageDraw.Draw(image)
    draw.polygon([(182,22), (854,22), (955,214), (76,214)], fill="#2079c4")
    # Four independently drawn, italic block glyphs on the upper blue field.
    glyphs = [
        [(0,0), (104,0), (98,11), (30,50), (85,50), (77,64), (-14,64), (-8,51), (59,14), (-6,14)],
        [(17,0), (90,0), (104,9), (94,32), (72,40), (89,64), (64,64), (42,37), (69,29), (77,14), (32,14), (9,64), (-12,64)],
        [(20,0), (57,0), (29,64), (7,64), (28,16), (9,23)],
        [(0,0), (27,0), (53,23), (92,0), (123,0), (66,33), (100,64), (71,64), (46,42), (9,64), (-23,64), (32,31)],
    ]
    for i, glyph in enumerate(glyphs):
        x0 = [247, 382, 515, 618][i]
        draw.polygon([(x0 + 1.30*x, 75 + 1.18*y) for x, y in glyph], fill="#e9edf0")
    for x in (253, 497, 769):
        draw.line((x, 219, x-7, 361), fill="#397db3", width=3)
    columns = [
        (147, "DISPLACEMENT", "5.5L"),
        (375, "HORSEPOWER", "COMBINED 1250"),
        (634, "LBS. FT. TORQUE", "145 FRT / 828 RR"),
        (872, "COMP. RATIO", "9.8:1"),
    ]
    for x, label, value in columns:
        draw.text((x, 257), label, anchor="mm", font=_font(22), fill="#20262b")
        draw.text((x, 319), value, anchor="mm", font=_font(25, bold=True), fill="#11191f")
    return image


if __name__ == "__main__":
    _draw_plaque().save(Path(__file__).parent / "textures" / "bay-specification.png")
