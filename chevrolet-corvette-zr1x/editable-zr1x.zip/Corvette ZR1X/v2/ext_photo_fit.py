"""Fit the recovered rig to the project's own ZR1X turntable reconstruction."""
from pathlib import Path
from math import cos, sin, tau
import bmesh
import bpy
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree
from body_clearance import resolve_tail,windshield_clearance
from fender_finish import fit_openings, fair_paint_reflections, form_door_pressing

PANELS = Path(__file__).with_name("photo_panels.blend")
REPLACED_PIVOTS = {
    "Pivot_Body_Assembly", "Pivot_Door_L", "Pivot_Door_R", "Pivot_Front_Hood",
    "Pivot_Roof_Panel", "Pivot_Rear_Hatch", "Pivot_Fuel_Flap", "Pivot_ZTK_Wing",
}
FINISHES = {
    "Torch Red • reconstructed surface": "Mat_Torch_Red_GKZ",
    "Torch Red molding": "Mat_Torch_Red_GKZ",
    "Studio-fit trim and carbon": "Mat_Black_Trim_Satin",
    "Satin forged graphite": "Mat_Wheel_CarbonFlash_SOJ",
    "Solar absorbing windshield": "Mat_Glass_Windshield",
    "Smoked side glazing": "Mat_Glass_Door",
    "Heat resistant engine glazing": "Mat_Glass_Hatch",
}

def make_filler(shell, outline, pivots, mats):
    # Sample the quarter's curvature along the photographed filler seam.
    bounds = [v.co.copy() for v in outline.data.vertices]
    xs, zs = [p.x for p in bounds], [p.z for p in bounds]
    cx, cz = (max(xs)+min(xs))/2, (max(zs)+min(zs))/2
    rx, rz = (max(xs)-min(xs))/2-.001, (max(zs)-min(zs))/2-.001
    bm = bmesh.new()
    bm.from_mesh(shell.data)
    surface = BVHTree.FromBMesh(bm)
    def point(theta, scale, depth):
        x = cx+scale*rx*cos(theta)
        z = cz+scale*rz*sin(theta)
        loc, _, _, _ = surface.ray_cast(Vector((x,1.3,z)),Vector((0,-1,0)))
        if loc is None: raise ValueError("Fuel aperture misses the quarter panel")
        return (x, loc.y+depth, z)
    count=48
    angles=[i*tau/count for i in range(count)]
    # Limit the cuts to nearby faces, otherwise every tangent plane would split
    # the whole body. Recompute candidates to include faces created by the cut.
    for a in angles:
        normal=Vector((cos(a)/rx,0,sin(a)/rz)).normalized()
        faces=[f for f in bm.faces if f.calc_center_median().y>.85 and
               abs(f.calc_center_median().x-cx)<rx+.055 and abs(f.calc_center_median().z-cz)<rz+.045]
        geom=set(faces)
        for f in faces:
            geom.update(f.edges)
            geom.update(f.verts)
        bmesh.ops.bisect_plane(bm,geom=list(geom),dist=.000005,
                               plane_co=(cx+rx*cos(a),0,cz+rz*sin(a)),plane_no=normal)
    inside=[]
    for f in bm.faces:
        p=f.calc_center_median()
        if p.y>.85 and ((p.x-cx)/rx)**2+((p.z-cz)/rz)**2<1.003:inside.append(f)
    bmesh.ops.delete(bm,geom=inside,context="FACES")
    bm.to_mesh(shell.data)
    bm.free()
    def insert(name, pivot, profile, materials):
        vertices = [point(a,scale,depth) for scale,depth in profile for a in angles]
        faces = [tuple(reversed(range(count)))]
        for row in range(len(profile)-1):
            for i in range(count):
                j=(i+1)%count
                faces.append((row*count+i,row*count+j,(row+1)*count+j,(row+1)*count+i))
        if name=="ZR1X_Fuel_Flap":
            faces.append(tuple(range(len(vertices)-count,len(vertices))))
        mesh=bpy.data.meshes.new(name)
        mesh.from_pydata(vertices, [], faces)
        for material in materials:mesh.materials.append(material)
        for f in mesh.polygons:
            f.use_smooth=True
            if len(materials)>1 and f.index>count:f.material_index=1
        obj=bpy.data.objects.new(name,mesh)
        bpy.context.collection.objects.link(obj)
        obj.parent=pivot
        mesh.transform(Matrix.Translation(-pivot.matrix_world.translation))
    insert("ZR1X_Fuel_Flap",pivots["Pivot_Fuel_Flap"],[(.03,.0025),(.968,.002),(.968,-.003)],
           [mats["Mat_Torch_Red_GKZ"],mats["Mat_Black_Trim_Satin"]])
    insert("ZR1X_Body_Filler_Well",pivots["Pivot_Body_Assembly"],[(.42,-.013),(.44,-.018),(.56,-.019),(.72,-.028),(1.02,-.004)],
           [mats["Mat_Black_Trim_Satin"]])

def build(pivots, mats):
    # Retain the new cabin-side door cards, which carry its switches and trim.
    for obj in list(bpy.context.scene.objects):
        if obj.type!="MESH" or not obj.parent:continue
        parent=obj.parent.name
        if parent in REPLACED_PIVOTS and not obj.name.startswith(("ZR1X_Door_Card", "ZR1X_Door_SwitchPod")):
            bpy.data.objects.remove(obj,do_unlink=True)
        elif parent.startswith("Pivot_WheelSpin_") and obj.name.startswith("ZR1X_Wheel_"):
            bpy.data.objects.remove(obj,do_unlink=True)
    # The rear edge of the inner door card stays inside the sculpted inlet.
    for side in ("L","R"):
        card=bpy.data.objects["ZR1X_Door_Card_"+side]
        for v in card.data.vertices:
            world=card.matrix_world @ v.co
            if world.x<-.18 and abs(world.y)>.75:
                v.co.y-= (1 if side=="L" else -1)*min(.072,max(0.,(-.18-world.x)*.22))
    with bpy.data.libraries.load(str(PANELS)) as (src,dest):
        dest.objects=list(src.objects)
    panel={obj.name:obj for obj in dest.objects}
    bpy.context.view_layer.update()
    for obj in panel.values():
        if obj.name in ("ZR1X_Body_Shell","ZR1X_Front_Fascia","ZR1X_Rear_Fascia"):
            fit_openings(obj.data)
    windshield_clearance(panel,pivots)
    make_filler(panel["ZR1X_Body_Shell"],panel["ZR1X_Fuel_Recess_Outline"],pivots,mats)
    for obj in dest.objects:
        if obj.name=="ZR1X_Fuel_Recess_Outline":
            bpy.data.objects.remove(obj,do_unlink=True)
            continue
        target=pivots[obj["photo_pivot"]]
        bpy.context.collection.objects.link(obj)
        obj.parent=target

        for i,m in enumerate(obj.data.materials):
            if m.name in FINISHES:obj.data.materials[i]=mats[FINISHES[m.name]]
        if obj.name=="ZR1X_Side_Wishbone":
            for i,m in enumerate(obj.data.materials):
                if m.name=="Mat_Black_Trim_Satin":
                    cavity=m.copy();cavity.name="Side intake duct liner"
                    bs=cavity.node_tree.nodes.get("Principled BSDF")
                    bs.inputs["Base Color"].default_value=(.006,.006,.007,1)
                    bs.inputs["Roughness"].default_value=.87
                    bs.inputs["Specular IOR Level"].default_value=.10
                    obj.data.materials[i]=cavity
        fair_paint_reflections(obj.data)
        if obj.name in ("ZR1X_Door_Shell_L","ZR1X_Door_Shell_R"):
            form_door_pressing(obj)
        obj.data.transform(Matrix.Translation(-target.matrix_world.translation))
        for attr in list(obj.data.color_attributes):
            obj.data.color_attributes.remove(attr)

    bpy.context.view_layer.update()
    for obj in bpy.context.scene.objects:
        if obj.name in ("ZR1X_Rear_Diffuser","ZR1X_Rear_Fascia","ZR1X_Chassis_Undertray","ZR1X_Exh_Muffler"):
            resolve_tail(obj)
