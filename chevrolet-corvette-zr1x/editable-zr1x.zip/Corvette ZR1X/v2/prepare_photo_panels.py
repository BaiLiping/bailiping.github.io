"""Bake the project's measured ZR1X exterior from its metre-scale Blender master.

Run in the preceding ZR1X.blend. Only the independently reconstructed Chevrolet
panels and photographed wheel faces are carried forward. The two masters share
the axle datums. A half turn around Z converts the previous axes to this rig.
"""
from collections import defaultdict
from pathlib import Path
import re
import bpy
import bmesh
from mathutils import Matrix
from math import pi

OUTPUT = Path(__file__).with_name("photo_panels.blend")
COMPONENTS = {
    "Body": ("Body_Assembly","Body"), "Underfloor": ("Body_Assembly","Body"),
    "Front_fascia": ("Body_Assembly","Front_Fascia"),
    "Rear_fascia": ("Body_Assembly","Rear_Fascia"),
    "Windshield": ("Body_Assembly","Glass_Windshield"),
    "Roof_panel": ("Roof_Panel","Roof_CarbonPanel"),
    "Front_closure": ("Front_Hood","Front_Hood"),
    "Rear_closure": ("Rear_Hatch","Rear_Hatch"),
    "Carbon_Aero": ("ZTK_Wing","Wing"),
    "Door_L": ("Door_L","Door_Shell_L"), "Door_R": ("Door_R","Door_Shell_R"),
    "Headlamp_L": ("Body_Assembly","Headlight_L"),
    "Headlamp_R": ("Body_Assembly","Headlight_R"),
    "Left_rear_lamp": ("Body_Assembly","Taillight_L"),
    "Right_rear_lamp": ("Body_Assembly","Taillight_R"),
}
def classify(obj):
    name = re.sub(r"\.\d+$", "", obj.name)
    parent = obj.parent.name
    wheel = re.fullmatch(r"Wheel_face_(Front|Rear)_(left|right)", parent)
    if wheel:
        corner = wheel[1][0] + wheel[2][0].upper()
        part = ("Wheel_LugNuts" if "lug nut" in name.lower() else "Wheel_CenterCap"
                if any(t in name for t in ("Center cap", "Crossed flag", "Hub emblem")) else "Wheel_Rim"
                if any(t in name.lower() for t in ("barrel", "rim", "lip")) and "Fork" not in name else "Wheel_Spokes")
        return "WheelSpin_"+corner, part+"_"+corner
    if parent not in COMPONENTS or name.startswith(("Rolled titanium outlet", "Tail pipe inner bore")):
        return None
    pivot, prefix = COMPONENTS[parent]
    if name=="Flush fuel filler door":
        return "Body_Assembly", "Fuel_Recess_Outline"
    if parent in ("Door_L","Door_R"):
        side=parent[-1]
        if "drop glass surface" in name: prefix = "Glass_Door_"+side
        elif "mirror" in name.lower() and not any(t in name for t in ("switch","key")): prefix="Mirror_"+side
        elif name.startswith("Carbon side"):prefix="Side_Wishbone_Door_"+side
        elif not name.startswith(("Left door", "Right door","Triangular")):return None
    elif parent=="Windshield" and name!="Windshield surface":
        prefix="Wiper" if "wiper" in name else "Body_Windshield_Seal"
    elif parent=="Body":
        if "quarter light surface" in name: prefix="Glass_Quarter"
        elif "rocker" in name: prefix="Side_Skirt"
        elif "inlet" in name.lower() or "Wishbone" in name: prefix="Side_Wishbone"
        elif name=="Body surface":prefix="Body_Shell"
    elif parent=="Rear_closure" and name=="Hatch glazing surface":prefix="Glass_Hatch"
    elif parent=="Carbon_Aero":
        prefix = "Wing_Mainplane" if "blade" in name else "Wing_Endplate" if "endplate" in name else "Wing_Stanchion" if "stanchion" in name else "Wing_Strake"
    elif parent=="Front_fascia":
        if "grille" in name.lower() or "radiator" in name.lower():prefix="Front_Grille"
        elif "splitter" in name:prefix="Front_Splitter"
        elif "flic" in name or "corner vane" in name:prefix="Front_DivePlane"
        elif "duct" in name or "inlet" in name:prefix="Front_Intake"
    elif parent=="Rear_fascia" and ("diffuser" in name.lower() or "surround" in name):prefix="Rear_Diffuser"
    return pivot,prefix

def separate_wheelhouse_parts(panel, axle):
    """Move disconnected wheelhouse islands in the top-view hood cut to the body.

    The original cut was projected down onto the outer skin and also picked up
    the liner and its two edge strips directly below it on each side. Select
    connected islands from a point below the lid; never slice through a panel.
    Positions in the baked mesh and the front axle datum are in vehicle metres.
    """
    bpy.ops.object.select_all(action="DESELECT")
    panel.select_set(True)
    bpy.context.view_layer.objects.active=panel
    result=[]
    for side,sign in (("L",1),("R",-1)):
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")
        bpy.ops.mesh.select_all(action="DESELECT")
        bm=bmesh.from_edit_mesh(panel.data)
        # The hub height is also the loaded tyre radius, measured from the ground.
        for vert in bm.verts:
            p=vert.co
            if (abs(p.x-axle.x)<axle.z and sign*p.y>.65*abs(axle.y)
                    and p.z<1.5*axle.z):
                vert.select_set(True)
        bmesh.update_edit_mesh(panel.data)
        bpy.ops.mesh.select_linked(delimit=set())
        selected=[v for v in bm.verts if v.select]
        if not selected or any(sign*v.co.y <= .65*abs(axle.y) for v in selected):
            raise ValueError(f"{panel.name}: cannot isolate the {side} wheelhouse from the hood")
        before=set(bpy.data.objects)
        bpy.ops.mesh.separate(type="SELECTED")
        bpy.ops.object.mode_set(mode="OBJECT")
        piece,=set(bpy.data.objects)-before
        result.append((("Body_Assembly","Body_Front_Wheelhouse_"+side),piece))
        piece.select_set(False)
    return result


def main():
    dg=bpy.context.evaluated_depsgraph_get()
    rotation=Matrix.Rotation(pi,4,'Z')
    axle=rotation @ bpy.data.objects["Front_left"].matrix_world.translation
    groups=defaultdict(list)
    for src in list(bpy.context.scene.objects):
        if src.type not in ('MESH','CURVE','FONT') or not src.parent:continue
        slot=classify(src)
        if slot is None:continue
        geo=bpy.data.meshes.new_from_object(src.evaluated_get(dg),preserve_all_data_layers=True,depsgraph=dg)
        geo.transform(rotation @ src.matrix_world)
        if src.parent.name=="Carbon_Aero":
            # Side views 05/20 and reverse view 13 constrain height, sweep and span.
            for vertex in geo.vertices:
                q=vertex.co;root_weight=min(1,max(0,(q.z-.95)/.15))
                q.x-=.044*root_weight
                q.y*=1-.058*root_weight
                lift=.019+.025*min(1,max(0,(q.z-1.12)/.105)) if "endplate" in src.name else .019
                q.z+=lift*root_weight
        if src.name.startswith(("Roof antenna fin","Engine cover spine louver","Quarter hatch louver")):
            for vertex in geo.vertices:
                vertex.co.z-=.035 if "antenna" in src.name else .020
        if src.name.startswith("Rear diffuser fence"):
            for vertex in geo.vertices:
                vertex.co.x+=.070
                vertex.co.z+=.025
        obj=bpy.data.objects.new("PanelTransfer",geo)
        bpy.context.collection.objects.link(obj)
        if src.parent.name=="Front_closure" and src.name in {
            "Front closure surface", "Front closure applique", "Front closure folded edge"
        }:
            for target,part in separate_wheelhouse_parts(obj,axle):
                groups[target].append(part)
        groups[slot].append(obj)
    kit=set()
    for (pivot,name),parts in groups.items():
        bpy.ops.object.select_all(action="DESELECT")
        for part in parts:part.select_set(True)
        obj=parts[0]
        bpy.context.view_layer.objects.active=obj
        if len(parts)>1:bpy.ops.object.join()
        obj.name="ZR1X_"+name
        obj["photo_pivot"]="Pivot_"+pivot
        kit.add(obj)
    bpy.data.libraries.write(str(OUTPUT),kit,compress=True)
    print(f"Wrote {len(kit)} photo-fitted components to {OUTPUT}")
main()
