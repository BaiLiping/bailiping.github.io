"""Recover the fixed fender paint removed by the old oblique lamp-socket cut.

The survey contains the original photo-fit triangles and normals from Body and
Front fascia, trimmed to the two shoulder regions; the measured XY contours of
those parts after the optical cut; and the actual polycarbonate lens outlines.
All values are in production vehicle metres. Run independently with NumPy,
SciPy and Shapely to regenerate the small fit input used by Blender.
"""
from pathlib import Path
import numpy as np
from scipy.spatial import Delaunay
from shapely.geometry import Polygon
from shapely.ops import unary_union
from shapely import wkb

folder = Path(__file__).resolve().parent
survey = np.load(folder / "front-shoulder-survey.npz")
v = survey["positions"]
n = survey["normals"]
triangles = survey["triangles"]
region = wkb.loads(survey["original_region"].tobytes())
retained = wkb.loads(survey["retained_skin"].tobytes())
lens = wkb.loads(survey["lens"].tobytes())
original = unary_union(
    [Polygon(v[f, :2]) for f in triangles if Polygon(v[f, :2]).area > 1e-12]
)
missing = (
    original.intersection(region)
    .difference(retained.buffer(0.0002))
    .difference(lens.buffer(0.005))
)
# Discard microscopic remnants at existing joints and keep the 5 mm lamp seal.
patch = unary_union(
    [q for q in getattr(missing, "geoms", [missing]) if q.area > 0.000018]
).buffer(0.00035)
positions = []
normals = []
faces = []
vertex_index = {}
for f in triangles:
    points = v[f]
    base = Polygon(points[:, :2])
    if base.area < 1.0e-11:
        continue
    selection = base.intersection(patch)
    if selection.is_empty:
        continue
    barycentric = np.linalg.inv(np.column_stack([points[:, :2], np.ones(3)]))
    for poly in getattr(selection, "geoms", [selection]):
        if poly.geom_type != "Polygon" or poly.area < 1.0e-9:
            continue
        uv = np.asarray(poly.exterior.coords)[:-1]
        if len(uv) < 3:
            continue
        local = [[0, 1, 2]] if len(uv) == 3 else Delaunay(uv).simplices
        output = []
        for x, y in uv:
            weights = np.array([x, y, 1.0]) @ barycentric
            z = weights @ points[:, 2] - 0.00018
            normal = weights @ n[f]
            normal /= max(np.linalg.norm(normal), 1.0e-10)
            key = tuple(round(q, 6) for q in (x, y, z))
            if key not in vertex_index:
                vertex_index[key] = len(positions)
                positions.append((x, y, z))
                normals.append(normal)
            output.append(vertex_index[key])
        for ijk in local:
            sub = Polygon(uv[ijk])
            if sub.area < 1.0e-12 or not poly.covers(sub.representative_point()):
                continue
            if np.cross(uv[ijk[1]] - uv[ijk[0]], uv[ijk[2]] - uv[ijk[0]]) < 0:
                ijk = ijk[::-1]
            faces.append([output[i] for i in ijk])
np.savez_compressed(
    folder / "front-shoulders.npz",
    v=np.asarray(positions, "f"),
    f=np.asarray(faces, "i"),
    n=np.asarray(normals, "f"),
)
print(f"Restored {len(faces)} triangles across the two fixed fender shoulders")
