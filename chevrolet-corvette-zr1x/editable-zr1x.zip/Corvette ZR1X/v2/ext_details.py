"""Crisp 3D exterior emblems, badging, and silver CHEVROLET license plate for the
2027 Chevrolet Corvette ZR1X (v2).

Builds:
- ``Pivot_Body_Assembly``:
  - ``ZR1X_Badge_FrontFlags`` (Corvette crossed-flags nose emblem: checkered dark-chrome + red bowtie wing)
  - ``ZR1X_Badge_CorvetteRear`` (crisp 3D dark-chrome ``CORVETTE`` rear script — strictly outside rear fascia,
    zero reverse-clipping through cabin/windshield!)
  - ``ZR1X_Badge_Side_L/R`` (sharp italic 3D dark-chrome ``ZR1X`` side quarter badges)
  - ``ZR1X_Rear_Plate`` (exact US 305x152 mm silver ``CHEVROLET`` rear license plate w/ dark embossed script)
- ``Pivot_Rear_Hatch``:
  - ``ZR1X_Badge_RearFlags`` (Corvette crossed-flags rear deck emblem lifting cleanly w/ hatch)
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

import bmesh
import bpy
from mathutils import Euler, Matrix, Vector

from ext_body import (
    bm_add_box,
    bm_add_closed_loft,
    body_center_z,
    finalize_bmesh,
    flank_y,
    hatch_surface_point,
    mix,
    nose_surface_pt,
)


# ---------------------------------------------------------------------------
# Clean 3D Vector Stroke Glyph Library (crisp automotive badging with zero text-curve bloat!)
# Each glyph is a list of polylines in normalized [0..1] x [0..1] box coordinates.
# ---------------------------------------------------------------------------

GLYPHS: Dict[str, List[List[Tuple[float, float]]]] = {
    "C": [[(0.92, 0.85), (0.65, 1.00), (0.20, 0.96), (0.04, 0.72), (0.04, 0.28), (0.20, 0.04), (0.65, 0.00), (0.92, 0.15)]],
    "O": [[(0.20, 0.98), (0.80, 0.98), (0.96, 0.74), (0.96, 0.26), (0.80, 0.02), (0.20, 0.02), (0.04, 0.26), (0.04, 0.74), (0.20, 0.98)]],
    "R": [
        [(0.06, 0.00), (0.06, 1.00), (0.76, 1.00), (0.94, 0.84), (0.94, 0.58), (0.76, 0.44), (0.06, 0.44)],
        [(0.58, 0.44), (0.96, 0.00)],
    ],
    "V": [[(0.02, 1.00), (0.50, 0.00), (0.98, 1.00)]],
    "E": [
        [(0.92, 1.00), (0.08, 1.00), (0.08, 0.00), (0.94, 0.00)],
        [(0.08, 0.52), (0.78, 0.52)],
    ],
    "T": [
        [(0.02, 1.00), (0.98, 1.00)],
        [(0.50, 1.00), (0.50, 0.00)],
    ],
    "H": [
        [(0.08, 0.00), (0.08, 1.00)],
        [(0.92, 0.00), (0.92, 1.00)],
        [(0.08, 0.52), (0.92, 0.52)],
    ],
    "L": [[(0.10, 1.00), (0.10, 0.00), (0.92, 0.00)]],
    # Aggressive wide italic Corvette ZR1X badge letterforms!
    "Z": [[(0.06, 0.98), (0.98, 0.98), (0.04, 0.02), (0.98, 0.02)]],
    "1": [
        [(0.22, 0.82), (0.58, 1.00), (0.58, 0.00)],
        [(0.20, 0.02), (0.90, 0.02)],
    ],
    "X": [
        [(0.04, 1.00), (0.96, 0.00)],
        [(0.04, 0.00), (0.96, 1.00)],
    ],
}


def _add_stroke_3d(
    bm: bmesh.types.BMesh,
    pts_3d: Sequence[Vector],
    normal_out: Vector,
    stroke_w: float,
    depth: float,
    mat_index: int = 0,
) -> None:
    """Extrude a crisp 3D beveled rectangular stroke along a 3D surface polyline."""
    n_out = normal_out.normalized()
    for i in range(len(pts_3d) - 1):
        p0 = pts_3d[i]
        p1 = pts_3d[i + 1]
        seg = p1 - p0
        length = seg.length
        if length < 1e-5:
            continue
        tang = seg / length
        perp = n_out.cross(tang)
        if perp.length < 1e-6:
            continue
        perp.normalize()
        # Slightly extend ends by half stroke width so sharp corners miter cleanly with zero gaps!
        q0 = p0 - tang * (stroke_w * 0.42)
        q1 = p1 + tang * (stroke_w * 0.42)
        hw = stroke_w * 0.5
        sec0 = [
            q0 - perp * hw - n_out * 0.001,
            q0 + perp * hw - n_out * 0.001,
            q0 + perp * (hw * 0.85) + n_out * depth,
            q0 - perp * (hw * 0.85) + n_out * depth,
        ]
        sec1 = [
            q1 - perp * hw - n_out * 0.001,
            q1 + perp * hw - n_out * 0.001,
            q1 + perp * (hw * 0.85) + n_out * depth,
            q1 - perp * (hw * 0.85) + n_out * depth,
        ]
        bm_add_closed_loft(bm, [sec0, sec1], mat_index=mat_index, cap_start=True, cap_end=True, smooth=False)


def _add_word(
    bm: bmesh.types.BMesh,
    word: str,
    map_uv_fn,
    normal_out: Vector,
    char_w: float,
    char_h: float,
    spacing: float,
    stroke_w: float,
    depth: float,
    italic_skew: float = 0.0,
    mat_index: int = 0,
) -> None:
    """Place a centered 3D word mapped cleanly onto an arbitrary surface via map_uv_fn(u_m, v_m)."""
    n_chars = len(word)
    total_w = n_chars * char_w + (n_chars - 1) * spacing
    u_start = -0.5 * total_w
    for idx, ch in enumerate(word):
        u0 = u_start + idx * (char_w + spacing)
        for poly in GLYPHS.get(ch, []):
            pts_3d = []
            for gx, gy in poly:
                u = u0 + gx * char_w + gy * italic_skew * char_h
                v = (gy - 0.5) * char_h
                pts_3d.append(map_uv_fn(u, v))
            _add_stroke_3d(bm, pts_3d, normal_out, stroke_w=stroke_w, depth=depth, mat_index=mat_index)


# ---------------------------------------------------------------------------
# 1. Corvette Crossed-Flags Emblem (Front Nose + Rear Hatch Deck)
# ---------------------------------------------------------------------------

def _build_crossed_flags(
    name: str,
    center: Vector,
    forward_vec: Vector,
    up_normal: Vector,
    scale: float,
    piv: bpy.types.Object,
    mats: Dict[str, bpy.types.Material],
) -> None:
    """Build an iconic sculpted 3D C8 Corvette crossed-flags V-emblem."""
    bm = bmesh.new()
    # 0=Dark Chrome V-bezel, 1=Emblem Red right wing, 2=White checker accents, 3=Gloss black backing
    mat_list = [
        mats["Mat_Badge_DarkChrome"],
        mats["Mat_Emblem_Red"],
        mats["Mat_White_Paint"],
        mats["Mat_Black_Trim_Gloss"],
    ]

    n = up_normal.normalized()
    fwd = (forward_vec - n * forward_vec.dot(n)).normalized()
    left = n.cross(fwd).normalized()

    def pt(x_f: float, y_l: float, z_n: float) -> Vector:
        return center + fwd * (x_f * scale) + left * (y_l * scale) + n * (z_n * scale)

    # Left & Right swept V-flag wings (C8 sharp aggressive V shape!)
    for side, wing_mat in ((1.0, 3), (-1.0, 1)):
        # Swept wing body from lower V-apex (x=-0.42, y=0) sweeping up-out to tip (x=+0.52, y=side*0.92)
        w_sec = []
        for k in range(6):
            tk = k / 5.0
            xf_lo = mix(-0.44, 0.16, tk ** 1.1)
            xf_hi = mix(-0.08, 0.56, tk ** 0.95)
            yl = side * mix(0.015, 0.94, tk)
            h_thick = mix(0.095, 0.060, tk)
            w_sec.append([
                pt(xf_lo, yl, 0.0),
                pt(xf_hi, yl, 0.0),
                pt(xf_hi - 0.03, yl, h_thick),
                pt(xf_lo + 0.03, yl, h_thick),
            ])
        bm_add_closed_loft(bm, w_sec, mat_index=0, cap_start=True, cap_end=True, smooth=False)

        # Colored inset face slightly proud on top of each dark-chrome wing
        in_sec = []
        for k in range(5):
            tk = k / 4.0
            xf_lo = mix(-0.34, 0.22, tk)
            xf_hi = mix(-0.14, 0.48, tk)
            yl = side * mix(0.08, 0.84, tk)
            in_sec.append([
                pt(xf_lo, yl, 0.075),
                pt(xf_hi, yl, 0.075),
                pt(xf_hi, yl, 0.105),
                pt(xf_lo, yl, 0.105),
            ])
        bm_add_closed_loft(bm, in_sec, mat_index=wing_mat, cap_start=True, cap_end=True, smooth=False)

    # Checkered white squares on the left (checkered-flag) wing (+Y left side)
    for row_i in range(2):
        for col_i in range(3):
            if (row_i + col_i) % 2 == 0:
                tk = 0.24 + col_i * 0.24
                xf = mix(-0.22, 0.34, tk) + (row_i - 0.5) * 0.12
                yl = mix(0.18, 0.74, tk)
                p_c = pt(xf, yl, 0.112)
                rot_m = Matrix((fwd, left, n)).transposed().to_4x4()
                bm_add_box(bm, p_c, (0.11 * scale, 0.14 * scale, 0.025 * scale), mat_index=2, rot_mat=rot_m, smooth=False)

    # Subtle gold/chrome bowtie accent bar on the right red wing
    p_bow = pt(0.08, -0.45, 0.115)
    rot_m = Matrix((fwd, left, n)).transposed().to_4x4()
    bm_add_box(bm, p_bow, (0.09 * scale, 0.26 * scale, 0.028 * scale), mat_index=0, rot_mat=rot_m, smooth=False)

    finalize_bmesh(name, bm, mat_list, piv, auto_smooth_deg=35.0)


# ---------------------------------------------------------------------------
# 2. Rear CORVETTE Script, ZR1X Side Badges & Silver CHEVROLET Rear Plate
# ---------------------------------------------------------------------------

def _build_badges_and_plate(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    body_piv = pivots["Pivot_Body_Assembly"]
    hatch_piv = pivots["Pivot_Rear_Hatch"]

    # === A. ZR1X_Badge_FrontFlags (Center nose beak flush on exact nose_surface_pt!) ===
    p_nf = nose_surface_pt(0.0, 0.48)
    _build_crossed_flags(
        "ZR1X_Badge_FrontFlags",
        center=Vector((p_nf.x + 0.002, 0.0, p_nf.z + 0.005)),
        forward_vec=Vector((-1.0, 0.0, 0.44)),   # V opens toward windshield!
        up_normal=Vector((0.44, 0.0, 1.0)),
        scale=0.072,
        piv=body_piv,
        mats=mats,
    )

    # === B. ZR1X_Badge_RearFlags (Center rear hatch deck ahead of wing!) ===
    p_rf = hatch_surface_point(-1.790, 0.0)
    _build_crossed_flags(
        "ZR1X_Badge_RearFlags",
        center=Vector((p_rf.x, 0.0, p_rf.z + 0.003)),
        forward_vec=Vector((1.0, 0.0, 0.16)),    # V opens forward along hatch!
        up_normal=Vector((-0.16, 0.0, 1.0)),
        scale=0.064,
        piv=hatch_piv,
        mats=mats,
    )

    # === C. ZR1X_Badge_CorvetteRear (Crisp dark-chrome CORVETTE lettering on outer rear transom!) ===
    # Strictly positioned on the outer face of Rear_Fascia at X = -2.198 (ZERO clipping into cabin!)
    bm_cr = bmesh.new()
    # Looking at rear of car from -X toward +X: left-to-right is +Y to -Y!
    # So increasing u (reading left-to-right from behind car) maps to y = -u!
    def rear_map(u: float, v: float) -> Vector:
        y = -u
        a = abs(y) / 0.90
        x = -2.196 + 0.195 * (a ** 2.15) - 0.003
        return Vector((x, y, 0.842 + v))

    _add_word(
        bm_cr, "CORVETTE", rear_map, normal_out=Vector((-1.0, 0.0, 0.0)),
        char_w=0.036, char_h=0.0165, spacing=0.032, stroke_w=0.0042, depth=0.0045,
        italic_skew=0.14, mat_index=0,
    )
    finalize_bmesh("ZR1X_Badge_CorvetteRear", bm_cr, [mats["Mat_Badge_DarkChrome"]], body_piv, auto_smooth_deg=35.0)

    # === D. ZR1X_Badge_Side_L / R (Crisp dark-chrome ZR1X badges on lower rear quarters!) ===
    # Matches 034-fuel-door-and-side-inlet.jpg, 006.png, 01-front-three-quarter.jpg!
    for side, sfx in ((1.0, "L"), (-1.0, "R")):
        bm_sb = bmesh.new()
        # Looking at L side (+Y) from outside: left-to-right is +X (front) -> -X (rear) -> x = x_c - u!
        # Looking at R side (-Y) from outside: left-to-right is -X (rear) -> +X (front) -> x = x_c + u!
        x_c = -0.685
        z_c = 0.435

        def side_map(u: float, v: float, _side=side) -> Vector:
            x = x_c - _side * u
            z = z_c + v
            y = _side * (flank_y(x, z, include_intake_recess=False) + 0.004)
            return Vector((x, y, z))

        _add_word(
            bm_sb, "ZR1X", side_map, normal_out=Vector((0.0, side, 0.0)),
            char_w=0.044, char_h=0.022, spacing=0.012, stroke_w=0.0052, depth=0.0048,
            italic_skew=0.38, mat_index=0,
        )
        finalize_bmesh(f"ZR1X_Badge_Side_{sfx}", bm_sb, [mats["Mat_Badge_DarkChrome"]], body_piv, auto_smooth_deg=35.0)

    # === E. ZR1X_Rear_Plate (Exact US 305x152 mm Silver CHEVROLET Rear License Plate!) ===
    # Matches 014.png & 03-rear-three-quarter.jpg: crisp brushed silver plate inside rear recess!
    bm_pl = bmesh.new()
    # 0=Silver Plate, 1=Dark Chrome CHEVROLET script & frame border, 2=Stainless corner screws
    mat_pl = [mats["Mat_Plate_Silver"], mats["Mat_Badge_DarkChrome"], mats["Mat_Steel_Machined"]]

    x_pl = -2.138
    z_pl = 0.700
    # Main beveled silver plate body (305 mm wide x 152 mm tall x 6 mm thick)
    bm_add_box(bm_pl, (x_pl, 0.0, z_pl), (0.006, 0.305, 0.152), mat_index=0, bevel=0.0025, segments=2)
    # Subtle dark thin perimeter backing trim frame
    bm_add_box(bm_pl, (x_pl + 0.003, 0.0, z_pl), (0.005, 0.312, 0.159), mat_index=1, bevel=0.002, segments=2)

    # Crisp embossed dark-chrome CHEVROLET lettering centered across the silver plate!
    def plate_map(u: float, v: float) -> Vector:
        return Vector((x_pl - 0.0032, -u, z_pl + v))

    _add_word(
        bm_pl, "CHEVROLET", plate_map, normal_out=Vector((-1.0, 0.0, 0.0)),
        char_w=0.020, char_h=0.024, spacing=0.006, stroke_w=0.0036, depth=0.0022,
        italic_skew=0.0, mat_index=1,
    )

    # 4 neat stainless mounting screws near corners
    for sy in (-0.090, 0.090):
        for sz in (-0.056, 0.056):
            bm_add_box(bm_pl, (x_pl - 0.0035, sy, z_pl + sz), (0.003, 0.007, 0.007), mat_index=2, bevel=0.002)

    finalize_bmesh("ZR1X_Rear_Plate", bm_pl, mat_pl, body_piv, auto_smooth_deg=35.0, uv_scale=8.0)


# ---------------------------------------------------------------------------
# Module Entry Point
# ---------------------------------------------------------------------------

def build(pivots: Dict[str, bpy.types.Object], mats: Dict[str, bpy.types.Material]) -> None:
    """Build front/rear crossed-flags emblems, CORVETTE & ZR1X badges, and silver CHEVROLET plate."""
    _build_badges_and_plate(pivots, mats)
