from pathlib import Path
import os,base64,sys
from playwright.sync_api import sync_playwright
from PIL import Image
root=Path(__file__).parent
out=root/'renders';out.mkdir(exist_ok=True)
site=Path(sys.argv[1])
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/google-chrome',headless=True,args=['--no-sandbox','--use-gl=angle','--use-angle=gl','--enable-webgl','--disable-dev-shm-usage','--ignore-gpu-blocklist'])
 page=b.new_page(viewport=dict(width=1200,height=840));page.on('pageerror',lambda e:print('PAGE ERROR',e,flush=True))
 page.goto(os.environ.get('ZR1X_STUDIO_URL','http://127.0.0.1:8726/chevrolet-corvette-zr1x/')+'?capture=1#model');page.wait_for_function('!!window.carStudio');page.evaluate('window.carStudio.ready')
 def save(file,w,h,transparent):
  data=page.evaluate('([w,h,t])=>window.carStudio.capture(w,h,t)',[w,h,transparent]);file.write_bytes(base64.b64decode(data.split(',')[1]))
 import json
 for view in json.loads((site/'studio.json').read_text())['views']:
  id=view['id'];assert page.evaluate('id=>window.carStudio.match(id)',id)
  save(out/(id+'.png'),*view['imageSize'],True)
 page.evaluate('window.carStudio.reset()');save(out/'home.png',1250,700,False)
 page.locator('#cabin').click();save(out/'cabin.png',1100,650,False)
 page.evaluate('window.carStudio.reset()');page.locator('#controls').click()
 if page.get_by_text('Open doors',exact=True).is_visible():page.get_by_text('Open doors',exact=True).click()
 save(out/'doors.png',1100,650,False)
 b.close()
