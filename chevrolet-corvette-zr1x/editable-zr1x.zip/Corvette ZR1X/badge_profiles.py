"""Reduce the ZR1X and Corvette reference lettering to reusable raised badge profiles."""
from pathlib import Path
import cv2 as cv
import numpy as np
import json
from shapely.geometry import Polygon
from shapely.ops import triangulate
root=Path(__file__).resolve().parent

def polygons(mask,origin=(0,0),scale=1,slant=0,tolerance=.6):
    contours,hier=cv.findContours(mask,cv.RETR_CCOMP,cv.CHAIN_APPROX_SIMPLE)
    shapes=[]
    for j,c in enumerate(contours):
        if hier[0][j,3]!=-1 or cv.contourArea(c)<8:continue
        def ring(contour):
            pts=cv.approxPolyDP(contour,tolerance,True)[:,0,:].astype(float)/scale
            pts+=origin;pts[:,1]+=slant*pts[:,0]
            return pts
        holes=[ring(cc) for jj,cc in enumerate(contours) if hier[0][jj,3]==j and cv.contourArea(cc)>6]
        poly=Polygon(ring(c),[h for h in holes if len(h)>=3]).buffer(0)
        if poly.geom_type=='MultiPolygon':shapes.extend(poly.geoms)
        else:shapes.append(poly)
    polys=[];lines=[]
    for shape in shapes:
        for triangle in triangulate(shape):
            intersection=triangle.intersection(shape)
            if intersection.geom_type=='Polygon' and intersection.area>.08:
                for tri in triangulate(intersection):
                    if intersection.covers(tri.representative_point()):
                        polys.append(np.asarray(tri.exterior.coords)[:-1])
        for path in [shape.exterior,*shape.interiors]:
            lines.append(np.asarray(path.coords)[:-1])
    vertices=np.concatenate(polys);mins=vertices.min(0);span=vertices.max(0)-mins
    return {k:[((p-mins)/span).round(5).tolist() for p in seq] for k,seq in [('triangles',polys),('edges',lines)]}

im=cv.imread(str(next((root/'refs').glob('detail-14.*'))));g=cv.cvtColor(im,cv.COLOR_BGR2GRAY)
ys,xs=np.indices(g.shape)
region=(xs>184)&(xs<902)&(ys+.357*xs>1077)&(ys+.357*xs<1145)
side=polygons(np.uint8(region&(g<78))*255,slant=.357,tolerance=1.35)
im=cv.imread(str(root/'refs/ext-014.png')).astype(float)[313:326,648:832]
chroma=im[:,:,2]-.5*(im[:,:,1]+im[:,:,0])
up=cv.resize(chroma,None,fx=5,fy=5,interpolation=cv.INTER_CUBIC)
rear=polygons(np.uint8(up<36)*255,scale=5,tolerance=1.15)
(root/'badge-profiles.json').write_text(json.dumps({'model':side,'rear':rear},separators=(',',':')))
