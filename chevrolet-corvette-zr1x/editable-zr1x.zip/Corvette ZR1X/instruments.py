"""Original instrument artwork informed by the illuminated Jet Black panoramic reference."""
from PIL import Image,ImageDraw,ImageFont
import math
from pathlib import Path
out=Path(__file__).resolve().parent
ff='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def text(d,pos,s,n,color):d.text(pos,s,font=ImageFont.truetype(ff,n),fill=color)
def panel(name):
 w,h=1000,330;im=Image.new('RGB',(w,h));d=ImageDraw.Draw(im)
 for y in range(h):
  b=(1+math.sin((y/h)*2.9-.7))*7+max(y/h-.58,0)*34
  d.line((0,y,w,y),fill=(int(5+b*.23),int(7+b*.49),int(11+b)))
 pale='#cbdae7';paler='#f3f4f4';muted='#92acbf'
 if name=='Driver display':
  for i in range(9):
   x=130+81*i
   d.polygon([(x,128),(x+58,128),(x+104,63),(x+47,68)],fill=(30+int(i*2),41,55) if i<6 else (75+16*(i-6),39,41));text(d,(x+2,134),str(i+1),15,pale)
  d.line((122,151,805,151),fill='#638497',width=3)
  text(d,(60,54),'72°F',19,pale);text(d,(829,53),'SE',17,pale)
  text(d,(364,167),'0',55,paler);text(d,(407,202),'MPH',13,pale);text(d,(507,150),'P',70,paler)
  for i,(a,b) in enumerate([('175 °F','30 psi'),('140 °F','165 °F')]):
   xx=65+i*130;text(d,(xx,185),a,24,paler);text(d,(xx,242),b,22,pale)
  text(d,(645,177),'0 kW',22,pale);text(d,(642,224),'75 %',22,pale)
  d.rounded_rectangle((825,167,867,250),10,outline=muted,width=3)
  for xx in [776,892]:
   for yy in [167,227]:text(d,(xx,yy),'30',18,pale)
  d.line((142,307,692,307),fill='#1a4056',width=3)
 elif name=='Infotainment':
  labels=['Apps','Vehicle Status','myChevrolet','Google Assistant','Play Store','Camera','Audio','Performance','PDR','Climate','Settings','Wi-Fi Hotspot']
  for i,lab in enumerate(labels):
   col=i%6;row=i//6;x=52+col*151;y=34+row*105
   if col%3==0:d.ellipse((x+26,y+3,x+60,y+30),outline=pale,width=3);d.ellipse((x+39,y+13,x+47,y+21),outline=muted,width=2)
   elif col%3==1:d.rounded_rectangle((x+23,y+7,x+63,y+29),5,outline=pale,width=3);d.line((x+28,y+7,x+35,y,x+49,y,x+55,y+7),fill=pale,width=3)
   else:d.line([(x+27,y+3),(x+63,y+17),(x+27,y+31),(x+27,y+3)],fill=pale,width=3)
   ww=d.textlength(lab,font=ImageFont.truetype(ff,14));text(d,(x+43-ww/2,y+39),lab,14,paler)
  d.line((20,269,979,269),fill='#314251',width=2)
  for i,t in enumerate(['72°','♨','LO','A/C','AUTO','↻','HI','68°']):text(d,(47+i*122,281),t,18,pale)
 else:
  text(d,(115,21),'Hybrid Battery',41,paler)
  text(d,(240,99),'85 %',34,paler);text(d,(288,205),'90 °F',32,paler)
  for y in [157,259]:
   for j in range(18):
    x=112+j*39;col=('#f1a54e' if y==157 and j<2 else '#acd0e7' if j<13 else '#2a506c');d.polygon([(x,y),(x+41,y),(x+37,y+7),(x-5,y+7)],fill=col)
  for j in range(5):
   x=90+j*170;d.rounded_rectangle((x,302,x+47,322),5,outline=muted,width=2)
 im.save(out/(name+'.png'))
for name in ['Driver display','Infotainment','Hybrid readout']:panel(name)
