"""Trim the cabin-side tunnel and the inset controls against Chevrolet's Jet Black panorama."""
carpet=mat('Jet Black needle-pile carpet','191a1d',0,.93)
brushed=mat('Satin selector bridge','888b90',.74,.47)
face_mat=mat('Switch faces','191c20',.03,.42)
white_mark=mat('White switch legends','d1d3d4',.01,.51)
ring_mat=mat('Gloss switch bezel','2b3035',.19,.23)
tunnel_stations=[(-.845,.188,.625),(-.68,.186,.622),(-.49,.173,.594),(-.21,.157,.561),(.08,.151,.545),(.38,.161,.55),(.44,.167,.56)]
def zcap(xx):
 return .555-.101*xx
sections=[]
for xx,w,h in tunnel_stations:
 h=zcap(xx)
 sections.append([(xx,-w-.018,.187),(xx,-w-.019,.29),(xx,-w,.413),(xx,-w+.012,h-.039),(xx,-w+.023,h-.013),(xx,-w+.04,h),(xx,w-.039,h),(xx,w-.022,h-.013),(xx,w-.012,h-.036),(xx,w,.411),(xx,w+.018,.275),(xx,w+.018,.187)])
o=loft('Continuous cabin tunnel trim',sections,carpet,cab)
for f0 in o.data.polygons:f0.use_smooth=True
for side in [-1,1]:
 path('Console side stitch',[(xx,side*(w-.020),zcap(xx)-.022) for xx,w,h in tunnel_stations],.0016,linen,cab)
# Driver-side switch bridge follows the sloping trim and meets the console at each corner.
def profile_points(cx,cy,l,w,r):
 # Rounded rectangle authored in vehicle coordinates.
 pts=[]
 for ox,oy,a in [(l/2-r,w/2-r,0),(-l/2+r,w/2-r,90),(-l/2+r,-w/2+r,180),(l/2-r,-w/2+r,270)]:
  for phi in np.linspace(np.deg2rad(a),np.deg2rad(a+90),8,endpoint=True):pts.append((cx+ox+r*cos(phi),cy+oy+r*sin(phi)))
 return pts
def raised_plate(name,pts,low,hi,m,grp=cab,zfun=zcap,pivot=(0,0,0)):
 xyz=np.asarray(pivot)
 lowsec=[tuple(np.array([x,y,zfun(x)+low])-xyz) for x,y in pts]
 highsec=[tuple(np.array([x,y,zfun(x)+hi])-xyz) for x,y in pts]
 return loft(name,[lowsec,highsec],m,grp)
def label(name,char,xx,yy,zz,size,m,grp=cab,pivot=(0,0,0)):
 cu=bpy.data.curves.new(name,'FONT');cu.body=char;cu.size=size;cu.align_x='CENTER';cu.align_y='CENTER';cu.materials.append(m)
 ob=bpy.data.objects.new(name,cu);sc.collection.objects.link(ob);ob.parent=grp;ob.location=tuple(np.array([xx,yy,zz])-pivot);ob.rotation_euler=(0,0,pi/2);return ob
raised_plate('Brushed selector bridge',profile_points(-.319,-.086,.530,.074,.031),.001,.007,brushed)
raised_plate('Recessed selector opening',profile_points(-.408,-.086,.272,.054,.023),.0071,.0081,face_mat)
gear_x=[-.508,-.458,-.407,-.356,-.306]
for j,(xx,letter) in enumerate(zip(gear_x,'PRNDM')):
 key=profile_points(xx,-.086,.041,.044,.011)
 raised_plate('Flush '+letter+' selector',key,.0081,.009,ring_mat)
 if letter in 'RD':
  raised_plate('Silver selector paddle',profile_points(xx-.010,-.086,.012,.043,.005),.009,.014,brushed)
 label('Selector legend '+letter,letter,xx+.0027,-.086,zcap(xx)+.0114,.012,red if letter=='P' else white_mark)
raised_plate('Drive mode switch inset',profile_points(-.174,-.086,.143,.049,.021),.0071,.0085,face_mat)
for j,xx in enumerate([-.217,-.175,-.134]):
 raised_plate('Mode switch',profile_points(xx,-.086,.033,.034,.009),.0085,.011,ring_mat)
 label('Mode switch marking',['+','◆','−'][j],xx,-.086,zcap(xx)+.0122,.009,white_mark)
for j,xx in enumerate([-.136,-.017]):
 yy=.04;rr=.046
 pts=[(xx+rr*cos(t),yy+rr*sin(t)) for t in np.linspace(0,2*pi,56,endpoint=False)]
 raised_plate('Cupholder dark well',pts,.003,.005,face_mat)
 path('Cupholder metal rim',[(a,b,zcap(a)+.007) for a,b in pts],.0028,metal,cab,True)
 pts=[(xx+.034*cos(t),yy+.034*sin(t),zcap(xx+.034*cos(t))+.0068) for t in np.linspace(0,2*pi,48,endpoint=False)]
 path('Cupholder inner ring',pts,.0017,bk,cab,True)
# Driver's armrest switch plate and mirror selector repeat the finish of the center bridge.
side=-1;par=doors[side];pivot=np.array(par.location)
def sill_height(xx):return .646-.111*(xx+.46)
raised_plate('Driver armrest switch trim',profile_points(-.398,-.643,.332,.080,.029),-.003,.007,brushed,par,sill_height,pivot)
raised_plate('Window switch pocket',profile_points(-.382,-.643,.172,.053,.018),.0072,.0092,face_mat,par,sill_height,pivot)
for xx in [-.378,-.352]:
 for yy in [-.654,-.632]:
  raised_plate('Flush window rocker',profile_points(xx,yy,.034,.019,.005),.0093,.013,ring_mat,par,sill_height,pivot)
yy=-.643;xx=-.447;rr=.023
circ=[(xx+rr*cos(t),yy+rr*sin(t)) for t in np.linspace(0,2*pi,36,endpoint=False)]
raised_plate('Door mirror four-way switch',circ,.009,.013,ring_mat,par,sill_height,pivot)
path('Mirror switch trim ring',[tuple(np.array([a,b,sill_height(a)+.014])-pivot) for a,b in circ],.0013,metal,par,True)
for j in range(4):
 a=2*pi*j/4;aa=xx+.014*cos(a);bb=yy+.014*sin(a);label('Mirror switch direction','•',aa,bb,sill_height(aa)+.015,.006,white_mark,par,pivot)
# Carpet and rubber footwell details visible from the fitted eye point.
floor_carpet=mat('Graphite floor carpet','121417',0,.92)
foot_mat=mat('Anthracite overmat','101115',.02,.94)
make_footwell_carpet(floor_carpet)
for side in [-1,1]:
 sections=[]
 mat_outline=[(-.77,.214),(-.79,.475),(-.68,.584),(-.44,.579),(-.146,.54),(-.123,.28),(-.39,.215)]
 for dz in [-.005,.005]:
  sections.append([(x,side*y,.296+dz) for x,y in mat_outline])
 loft('Contoured cabin overmat',sections,foot_mat,cab)
 path('Bound overmat edge',sections[1],.0035,floor_carpet,cab,True)
 for yy in [.265,.497]:
  xx=-.45;pts=[(xx+.016*cos(t),side*yy+.016*sin(t),.302) for t in np.linspace(0,2*pi,30,endpoint=False)]
  mesh('Overmat retaining disc',pts,[tuple(range(len(pts)))],dark,cab)

# The speaker and memory strip sit inside the sloping leather pull. Both travel
# with the door. The Jet Black side panorama and press-36 locate the metal panel.
speaker_finish = mat('Satin graphite speaker bezel', '63676a', .55, .38)
speaker_face = mat('Perforated dark metal grille', '4b4e51', .34, .48)
slot_finish = mat('Acoustic openings', '25282b', .05, .71)
for hand in (-1, 1):
    door = doors[hand]
    door_pivot = np.asarray(door.location)

    def on_card(x, y, z):
        return tuple(np.asarray([x, hand*y, z])-door_pivot)

    # Trace the long diagonal edge from the forward upper corner back to the armrest.
    rim = [(-.800,.733),(-.768,.750),(-.432,.721),(-.376,.708),
           (-.184,.585),(-.176,.568),(-.191,.550),(-.310,.507),
           (-.333,.511),(-.776,.688),(-.802,.711)]
    center_x, center_z = -.491, .638
    face = [(center_x+(x-center_x)*.938, center_z+(z-center_z)*.863) for x,z in rim]
    loft('Metal inner door speaker bezel',
         [[on_card(x, y, z) for x,z in rim] for y in (.653,.646)],speaker_finish,door)
    loft('Inner door acoustic grille',
         [[on_card(x, y, z) for x,z in face] for y in (.6455,.644)],speaker_face,door)

    # Etched horizontal slots surround two fields of regularly spaced acoustic holes.
    # Keep the complete pattern in one editable mesh per grille.
    vents_v, vents_f = [], []
    def add_grille_face(points):
        start=len(vents_v)
        vents_v.extend(on_card(x,.6434,z) for x,z in points)
        vents_f.append(tuple(range(start,start+len(points))))
    disks=[(-.500,.664,.047),(-.629,.700,.018)]
    for zz in np.arange(.52,.740,.0042):
        crossings=[]
        for (x1,z1),(x2,z2) in zip(face,face[1:]+face[:1]):
            if min(z1,z2)<=zz<max(z1,z2):
                crossings.append(x1+(x2-x1)*(zz-z1)/(z2-z1))
        if len(crossings)!=2:continue
        start,end=sorted(crossings);start+=.003;end-=.003
        if end<=start:continue
        for xx,zc,rad in sorted(disks):
            if abs(zz-zc)>=rad:continue
            span=math.sqrt(rad*rad-(zz-zc)**2)
            a,b=max(start,xx-span),min(end,xx+span)
            if b<=a:continue
            if a-start>.001:
                add_grille_face([(start,zz),(a,zz),(a,zz+.001),(start,zz+.001)])
            for x0 in np.arange(a+.0018,b-.0015,.0042):
                add_grille_face([(x0+.00135*cos(t*pi/3),zz+.00135*sin(t*pi/3)) for t in range(6)])
            start=b
        if end-start>.001:
            add_grille_face([(start,zz),(end,zz),(end,zz+.001),(start,zz+.001)])
    mesh('Door grille slots and driver perforations',vents_v,vents_f,slot_finish,door)

    # The driver memory presets form a slim inset along the lower rear corner.
    if hand<0:
        plate=[(-.287,.560),(-.213,.584),(-.203,.574),(-.278,.549)]
        loft('Door seat memory keypad',
             [[on_card(x,y,z) for x,z in plate] for y in (.643,.640)],face_mat,door)
        for index in range(4):
            xx=-.278+.018*index
            zz=.555+.0055*index
            path('Memory key marker',[on_card(xx,.639,zz),on_card(xx+.005,.639,zz+.0017)],
                 .0008,white_mark,door)

    seams_v, seams_f = [], []
    for index in range(7):
        rise=.009*index
        run=[(.273,.476+rise),(.106,.500+rise),(.030,.511+rise),
             (-.013,.533+rise),(-.059,.557+rise),(-.136,.573+rise)]
        start=len(seams_v)
        for x,z in run:
            seams_v.extend([on_card(x,.651,z),on_card(x,.6505,z+.0015)])
        for j in range(len(run)-1):
            k=start+2*j
            seams_f.append((k,k+1,k+3,k+2))
    mesh('Inner door stitched leather ribs',seams_v,seams_f,linen,door)
