"""Trim the cabin-side tunnel and the inset controls against Chevrolet's Jet Black panorama."""
carpet=mat('Jet Black needle-pile carpet','191a1d',0,.93)
brushed=mat('Satin selector bridge','888b90',.74,.47)
face_mat=mat('Switch faces','191c20',.03,.42)
white_mark=mat('White switch legends','d1d3d4',.01,.51)
ring_mat=mat('Gloss switch bezel','2b3035',.19,.23)
tunnel_stations=[(-.845,.188,.625),(-.68,.186,.622),(-.49,.173,.594),(-.21,.157,.561),(.08,.151,.545),(.38,.161,.55),(.44,.167,.56)]
def zcap(xx):
 return .555-.101*xx
sections=[]
for xx,w,h in tunnel_stations:
 h=zcap(xx)
 sections.append([(xx,-w-.018,.187),(xx,-w-.019,.29),(xx,-w,.413),(xx,-w+.012,h-.039),(xx,-w+.023,h-.013),(xx,-w+.04,h),(xx,w-.039,h),(xx,w-.022,h-.013),(xx,w-.012,h-.036),(xx,w,.411),(xx,w+.018,.275),(xx,w+.018,.187)])
o=loft('Continuous cabin tunnel trim',sections,carpet,cab)
for f0 in o.data.polygons:f0.use_smooth=True
for side in [-1,1]:
 path('Console side stitch',[(xx,side*(w-.020),zcap(xx)-.022) for xx,w,h in tunnel_stations],.0016,linen,cab)
# Driver-side switch bridge follows the sloping trim and meets the console at each corner.
def profile_points(cx,cy,l,w,r):
 # Rounded rectangle authored in vehicle coordinates.
 pts=[]
 for ox,oy,a in [(l/2-r,w/2-r,0),(-l/2+r,w/2-r,90),(-l/2+r,-w/2+r,180),(l/2-r,-w/2+r,270)]:
  for phi in np.linspace(np.deg2rad(a),np.deg2rad(a+90),8,endpoint=True):pts.append((cx+ox+r*cos(phi),cy+oy+r*sin(phi)))
 return pts
def raised_plate(name,pts,low,hi,m,grp=cab,zfun=zcap,pivot=(0,0,0)):
 xyz=np.asarray(pivot)
 lowsec=[tuple(np.array([x,y,zfun(x)+low])-xyz) for x,y in pts]
 highsec=[tuple(np.array([x,y,zfun(x)+hi])-xyz) for x,y in pts]
 return loft(name,[lowsec,highsec],m,grp)
def label(name,char,xx,yy,zz,size,m,grp=cab,pivot=(0,0,0)):
 cu=bpy.data.curves.new(name,'FONT');cu.body=char;cu.size=size;cu.align_x='CENTER';cu.align_y='CENTER';cu.materials.append(m)
 ob=bpy.data.objects.new(name,cu);sc.collection.objects.link(ob);ob.parent=grp;ob.location=tuple(np.array([xx,yy,zz])-pivot);ob.rotation_euler=(0,0,pi/2);return ob
raised_plate('Brushed selector bridge',profile_points(-.319,-.086,.530,.074,.031),.001,.007,brushed)
raised_plate('Recessed selector opening',profile_points(-.408,-.086,.272,.054,.023),.0071,.0081,face_mat)
gear_x=[-.508,-.458,-.407,-.356,-.306]
for j,(xx,letter) in enumerate(zip(gear_x,'PRNDM')):
 key=profile_points(xx,-.086,.041,.044,.011)
 raised_plate('Flush '+letter+' selector',key,.0081,.009,ring_mat)
 if letter in 'RD':
  raised_plate('Silver selector paddle',profile_points(xx-.010,-.086,.012,.043,.005),.009,.014,brushed)
 label('Selector legend '+letter,letter,xx+.0027,-.086,zcap(xx)+.0114,.012,red if letter=='P' else white_mark)
raised_plate('Drive mode switch inset',profile_points(-.174,-.086,.143,.049,.021),.0071,.0085,face_mat)
for j,xx in enumerate([-.217,-.175,-.134]):
 raised_plate('Mode switch',profile_points(xx,-.086,.033,.034,.009),.0085,.011,ring_mat)
 label('Mode switch marking',['+','◆','−'][j],xx,-.086,zcap(xx)+.0122,.009,white_mark)
for j,xx in enumerate([-.136,-.017]):
 yy=.04;rr=.046
 pts=[(xx+rr*cos(t),yy+rr*sin(t)) for t in np.linspace(0,2*pi,56,endpoint=False)]
 raised_plate('Cupholder dark well',pts,.003,.005,face_mat)
 path('Cupholder metal rim',[(a,b,zcap(a)+.007) for a,b in pts],.0028,metal,cab,True)
 pts=[(xx+.034*cos(t),yy+.034*sin(t),zcap(xx+.034*cos(t))+.0068) for t in np.linspace(0,2*pi,48,endpoint=False)]
 path('Cupholder inner ring',pts,.0017,bk,cab,True)
# Driver's armrest switch plate and mirror selector repeat the finish of the center bridge.
side=-1;par=doors[side];pivot=np.array(par.location)
def sill_height(xx):return .646-.111*(xx+.46)
raised_plate('Driver armrest switch trim',profile_points(-.398,-.643,.332,.080,.029),-.003,.007,brushed,par,sill_height,pivot)
raised_plate('Window switch pocket',profile_points(-.382,-.643,.172,.053,.018),.0072,.0092,face_mat,par,sill_height,pivot)
for xx in [-.378,-.352]:
 for yy in [-.654,-.632]:
  raised_plate('Flush window rocker',profile_points(xx,yy,.034,.019,.005),.0093,.013,ring_mat,par,sill_height,pivot)
yy=-.643;xx=-.447;rr=.023
circ=[(xx+rr*cos(t),yy+rr*sin(t)) for t in np.linspace(0,2*pi,36,endpoint=False)]
raised_plate('Door mirror four-way switch',circ,.009,.013,ring_mat,par,sill_height,pivot)
path('Mirror switch trim ring',[tuple(np.array([a,b,sill_height(a)+.014])-pivot) for a,b in circ],.0013,metal,par,True)
for j in range(4):
 a=2*pi*j/4;aa=xx+.014*cos(a);bb=yy+.014*sin(a);label('Mirror switch direction','•',aa,bb,sill_height(aa)+.015,.006,white_mark,par,pivot)
# Carpet and rubber footwell details visible from the fitted eye point.
floor_carpet=mat('Graphite floor carpet','121417',0,.92)
foot_mat=mat('Anthracite overmat','101115',.02,.94)
roundbox('Carpeted driver and passenger floor',(-.368,0,.275),(1.24,1.42,.032),floor_carpet,cab,.014)
for side in [-1,1]:
 sections=[]
 mat_outline=[(-.77,.214),(-.79,.475),(-.68,.584),(-.44,.579),(-.146,.54),(-.123,.28),(-.39,.215)]
 for dz in [-.005,.005]:
  sections.append([(x,side*y,.296+dz) for x,y in mat_outline])
 loft('Contoured cabin overmat',sections,foot_mat,cab)
 path('Bound overmat edge',sections[1],.0035,floor_carpet,cab,True)
 for yy in [.265,.497]:
  xx=-.45;pts=[(xx+.016*cos(t),side*yy+.016*sin(t),.302) for t in np.linspace(0,2*pi,30,endpoint=False)]
  mesh('Overmat retaining disc',pts,[tuple(range(len(pts)))],dark,cab)
