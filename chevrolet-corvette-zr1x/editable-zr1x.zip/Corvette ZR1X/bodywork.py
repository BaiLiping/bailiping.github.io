"""Construct the fitted panels, the glass and the returns of the cooling ducts."""
panel_data = np.load(ROOT/'body-panels.npz')
measured = np.load(ROOT/'finalskin.npz')
v, f = panel_data['guide'], measured['f']  # Continuous guide for subsequent detail registration.
shell_points = panel_data['v']
shell_normals = panel_data['n']
shell_rgb = panel_data['rgb']
panel_faces = panel_data['f']
panel_groups = panel_data['group']
panel_names = panel_data['labels'].tolist()

hood = empty('Front_closure')
hatch = empty('Rear_closure')
bumper = empty('Front_fascia')
tail = empty('Rear_fascia')
windshield = empty('Windshield')
underfloor = empty('Underfloor')

glazing = mat('Solar absorbing windshield','202a2e',.02,.15)
side_glazing = mat('Smoked side glazing','171f23',.025,.17)
hatch_glass = mat('Heat resistant engine glazing','202627',.03,.18)
for material, opacity in [(glazing,.9),(side_glazing,.95),(hatch_glass,.90)]:
    material.use_backface_culling=True
    material.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=opacity
graphite_roof = mat('Visible carbon roof','292c30',.18,.22)
airbox = mat('Duct interior shadow','111317',.0,.89)
return_wall = mat('Injection molded intake liner','1d2023',.05,.56)
bumper_paint = mat('Torch Red molding','c91116',.04,.28)
bumper_paint.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=.36
bumper_paint.node_tree.nodes.get('Principled BSDF').inputs['Coat Roughness'].default_value=.19
skin.node_tree.nodes.get('Principled BSDF').inputs['Coat Weight'].default_value=.36
skin.node_tree.nodes.get('Principled BSDF').inputs['Coat Roughness'].default_value=.19

hosts = {'Side inlet return':body,'Body':body,'Windshield':windshield,'Left side glass':doors[-1],'Right side glass':doors[1],
         'Roof panel':roof,'Front closure':hood,'Rear closure':hatch,'Hatch glazing':hatch,
         'Left door':doors[-1],'Right door':doors[1],'Front fascia':bumper,'Rear fascia':tail,'Underfloor':underfloor}
materials = {'Side inlet return':airbox,'Windshield':glazing,'Left side glass':side_glazing,'Right side glass':side_glazing,
             'Roof panel':graphite_roof,'Underfloor':carbon,'Hatch glazing':hatch_glass}
# GLB keeps each component's panel mesh intact. Duct liners extrude inward from
# the actual contour left by the surrounding fascia and end at a dark plenum.
def panel_surface(name, verts, tris, norms, material, parent, colors=None):
    me=bpy.data.meshes.new(name)
    me.vertices.add(len(verts));me.vertices.foreach_set('co',np.asarray(verts-parent.location,dtype='f').ravel())
    me.loops.add(tris.size);me.loops.foreach_set('vertex_index',tris.astype('i').ravel())
    me.polygons.add(len(tris));me.polygons.foreach_set('loop_start',np.arange(0,tris.size,3,dtype='i'))
    me.materials.append(material)
    if colors is not None:
        me.materials.append(trim)
        dark_face=np.median(colors[tris,0],axis=1)<70
        if name=='Side inlet return surface':
            centers=verts[tris].mean(axis=1)
            edge=.296+.322*np.clip((centers[:,2]-.282)/.416,-.08,1.14)
            relative=centers[:,0]-edge
            dark_face=(relative>-.017)&(relative<.013)&(centers[:,2]>.322)&(centers[:,2]<.721)
        me.polygons.foreach_set('material_index',dark_face.astype('i'))
        attr=me.color_attributes.new(name='Surface tone',type='BYTE_COLOR',domain='POINT')
        tone=np.column_stack([colors/255.,np.ones(len(colors))]).astype('f')
        attr.data.foreach_set('color_srgb',tone.ravel())
    me.polygons.foreach_set('use_smooth',np.ones(len(tris),bool));me.update(calc_edges=True);me.validate(verbose=False,clean_customdata=False)
    norms=norms/np.maximum(np.linalg.norm(norms,axis=1)[:,None],1e-7)
    me.normals_split_custom_set_from_vertices(norms.tolist())
    ob=bpy.data.objects.new(name,me);sc.collection.objects.link(ob);ob.parent=parent
    return ob

def shell_boundary(tris):
    edges=np.concatenate([tris[:,[0,1]],tris[:,[1,2]],tris[:,[2,0]]])
    unique, indices, counts=np.unique(np.sort(edges,axis=1),axis=0,return_index=True,return_counts=True)
    return edges[indices[counts==1]]

for index,label in enumerate(panel_names):
    selected=panel_faces[panel_groups==index]
    selected=selected[(selected[:,0]!=selected[:,1])&(selected[:,1]!=selected[:,2])&(selected[:,0]!=selected[:,2])]
    ids,local=np.unique(selected,return_inverse=True)
    local=local.reshape(-1,3)
    verts=shell_points[ids]
    norms=shell_normals[ids].copy()
    if label in hosts:
        material=materials.get(label,skin)
        col=shell_rgb[ids] if material==skin else None
        if label=='Side inlet return':
            material=skin
            col=shell_rgb[ids]
        if label in ('Left side glass','Right side glass'):
            xside,yside,zside=verts.T
            norms=np.column_stack([.06*xside,np.sign(yside),.57+.38*(zside-.9)])
        if label in ('Windshield','Roof panel','Hatch glazing'):
            # Formed glass reflects in a single uninterrupted band along its
            # double curvature. Its normals follow the cowl/roof longitudinal sections.
            xx,yy,zz=verts.T
            pitch=np.interp(xx,[-1.5,-1.32,-1.2,-.98,-.78,-.61,-.48,-.40,-.30,-.1,.1,.3,.46,.65,1.05,1.6],
                                     [.19,.24,.37,.47,.46,.43,.29,.20,.09,.025,-.015,-.062,-.11,-.16,-.17,-.17])
            crown=(.28+.06*np.clip((xx+1.3),0,1))*yy+np.sign(yy)*1.20*np.maximum(abs(yy)-.51,0)**.80
            norms=np.column_stack([-pitch,crown,np.ones(len(xx))])
        if label in ('Windshield','Roof panel','Hatch glazing','Left side glass','Right side glass'):
            points=verts[local]
            direction=np.cross(points[:,1]-points[:,0],points[:,2]-points[:,0])
            reversed_face=np.einsum('ij,ij->i',direction,norms[local].sum(axis=1))<0
            local[reversed_face]=local[reversed_face][:,[0,2,1]]
        panel_surface(label+' surface',verts,local,norms,material,hosts[label],col)
        borders={'Windshield':(.015,return_wall),'Left side glass':(.006,return_wall),'Right side glass':(.006,return_wall),
                 'Roof panel':(.0035,return_wall),'Hatch glazing':(.010,return_wall),
                 'Left door':(.0028,dark),'Right door':(.0028,dark),'Front closure':(.0030,dark),'Rear closure':(.0025,dark)}
        if label in borders:
            edges=shell_boundary(local)
            if label in ('Left door','Right door'):
                mid=verts[edges].mean(axis=1)
                edge=.296+.322*np.clip((mid[:,2]-.282)/.416,-.08,1.14)
                s=mid[:,0]-edge
                # A densely sampled patch joins the fitted door. Only the
                # photographed hem carries a line at their shared boundary.
                join=((abs(s+.109)<.010)|(abs(s-.068)<.009)|((s>-.12)&(s<.075)&((abs(mid[:,2]-.284)<.009)|(abs(mid[:,2]-.751)<.009))))
                edges=edges[~join]
            ids=np.unique(edges);idx=np.searchsorted(ids,edges)
            original=verts[ids];n=norms[ids];n=n/np.maximum(np.linalg.norm(n,axis=1)[:,None],1e-8)
            toward=verts.mean(0)-original;toward-=np.einsum('ij,ij->i',n,toward)[:,None]*n
            toward/=np.maximum(np.linalg.norm(toward,axis=1)[:,None],1e-6)
            width,finish=borders[label]
            ring=np.vstack([original+n*.0011,original+n*.0014+toward*width])
            faces=np.column_stack([idx[:,0],idx[:,1],idx[:,1]+len(ids),idx[:,0]+len(ids)])
            edge_obj=mesh(label+' applique',list(ring-np.asarray(hosts[label].location)),list(faces),finish,hosts[label])
            for face in edge_obj.data.polygons:face.use_smooth=True
        if label in ['Front closure','Rear closure','Roof panel']:
            boundary=shell_boundary(local); upper=np.unique(boundary); remap=np.searchsorted(upper,boundary)
            edge=verts[upper];width=.012 if label=='Roof panel' else .018
            walls=np.concatenate([edge,edge-[0,0,width]])
            L=len(edge); quads=np.column_stack([remap[:,0],remap[:,1],remap[:,1]+L,remap[:,0]+L])
            mesh(label+' folded edge',walls.tolist(),quads.tolist(),dark,hosts[label])
        continue
    front_duct=label.startswith('Front')
    parent=bumper if front_duct else tail
    inset=.080 if front_duct else (.093 if label=='Diffuser inset' else .052)
    axis=np.array([inset if front_duct else -inset,0,0])
    panel_surface(label+' plenum',verts+axis,local,norms,airbox,parent)
    rim=shell_boundary(local);rimids=np.unique(rim);rimlocal=np.searchsorted(rimids,rim);edge=verts[rimids]
    rings=np.concatenate([edge,edge+axis*.12,edge+axis]);L=len(edge)
    quads=[]
    for j in [0,1]:
        a,b=rimlocal.T
        quads.extend(np.column_stack([a+j*L,b+j*L,b+(j+1)*L,a+(j+1)*L]).tolist())
    duct=mesh(label+' return',rings.tolist(),quads,return_wall,parent)
    for poly in duct.data.polygons:poly.use_smooth=True
