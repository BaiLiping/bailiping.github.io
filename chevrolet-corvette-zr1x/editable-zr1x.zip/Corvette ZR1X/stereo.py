"""Rectify adjacent exterior views and estimate multi-baseline depth for the shell."""
from calibrate import *
cv.setNumThreads(2)
from concurrent.futures import ThreadPoolExecutor
p=json.loads((ROOT/'rig.json').read_text());K,R,C,T=pose(p)
folder=ROOT/'depth';folder.mkdir(exist_ok=True)
frames=[cv.imread(str(ROOT/('refs/ext-%03d.png'%(i+1))),cv.IMREAD_UNCHANGED) for i in range(30)]
def stereo(pair):
 i,step=pair;j=(i+step)%30
 x=C[j]-C[i];B=np.linalg.norm(x);x/=B
 mid=(C[i]+C[j])*.5
 forward=(np.array([-.089,0,.64])-mid);forward-=x*np.dot(forward,x);forward/=np.linalg.norm(forward)
 down=np.cross(forward,x);Rrect=np.stack([x,down,forward])
 f=K[0,0]*.55;w,h=900,470
 ks=[];images=[]
 for k in [i,j]:
  ray=Rrect@(np.array([-.089,0,.64])-C[k]);cx=w/2-f*ray[0]/ray[2];cy=h/2-f*ray[1]/ray[2]
  kk=np.array([[f,0,cx],[0,f,cy],[0,0,1]]);hh=kk@Rrect@R[k].T@np.linalg.inv(K)
  im=frames[k];rgb=np.where(im[:,:,3,None]>=252,im[:,:,:3],220)
  images.append(cv.warpPerspective(rgb,hh,(w,h),borderValue=(220,220,220)));ks.append(kk)
 # Common vertical principal point, since camera centers differ exclusively along rectified x.
 # Rectified x-disparity near the subject is small since the image centers track its center.
 m=64 if step==1 else 128
 sgb=cv.StereoSGBM_create(-m,2*m,5,8*3*25,32*3*25,1,31,9,70,2,cv.STEREO_SGBM_MODE_SGBM_3WAY)
 disp=sgb.compute(*images).astype('f')/16
 true=disp-(ks[0][0,2]-ks[1][0,2])
 depth=f*B/np.maximum(true,.1);depth[(disp<=-m)|(depth<7)|(depth>18)]=0
 np.savez_compressed(folder/('%02d-%d.npz'%(i,step)),depth=np.round(depth*1000).astype('uint16'),R=Rrect,K=ks[0],C=C[i])
with ThreadPoolExecutor(4) as e:list(e.map(stereo,[(i,s) for s in [1,2] for i in range(30)]))
