"""Paired ZR1X headlamps registered to Chevrolet ext-001 and checked in ext-029.

The laminate, perimeter gasket, dark lamp tub, light guides and internal projector
sit at distinct depths. The cover follows a smooth fit to the curved fender.
"""
from mathutils.geometry import tessellate_polygon
lamp_cam=frame_camera(1)
origin,rotation,intrinsics=lamp_cam
cu0,cv0,focal=intrinsics
lamp_outline=np.asarray([(98,285),(117,267),(156,240),(221,208),(300,181),(395,150),
    (448,138),(473,138),(510,143),(543,149),(544,154),(527,176),(491,207),(453,231),
    (404,246),(326,260),(223,271),(150,280)],float)
def lamp_ray(u,w):
    return rotation.T@np.array([(330+.3*u-cu0)/focal,(162+.3*w-cv0)/focal,1])
def inside_lamp(u,w):
    result=np.zeros(np.shape(u),dtype=bool)
    for (a,b),(c,d) in zip(lamp_outline,np.roll(lamp_outline,-1,axis=0)):
        if b==d:continue
        result^=((b>w)!=(d>w))&(u<(c-a)*(w-b)/(d-b)+a)
    return result
def basis(u,w):
    x=(u-324)/225;y=(w-214)/73
    return np.stack([np.ones_like(x),x,y,x*x,x*y,y*y,x*x*x,x*x*y,x*y*y,y*y*y],axis=-1)
samples=[tuple(p) for p in lamp_outline]
for u in np.linspace(100,540,26):
    for w in np.linspace(140,283,17):
        if inside_lamp(u,w):samples.append((u,w))
samples=np.asarray(samples)
target_depth=np.array([rotation[2]@(np.asarray(ray((330+.3*u,162+.3*w),lamp_cam,0))-origin) for u,w in samples])
design=basis(samples[:,0],samples[:,1])
weights=np.ones(len(samples))
for it in range(4):
    depth_coeffs=np.linalg.lstsq(design*weights[:,None],target_depth*weights,rcond=None)[0]
    weights=np.clip(.012/(np.abs(design@depth_coeffs-target_depth)+1.e-6),.12,1.)
def optical_point(u,w,relief):
    return origin+lamp_ray(u,w)*(basis(u,w)@depth_coeffs-relief)

# Cut the lamp sockets through the fitted exterior skin. At the sealing flange
# interpolate the original three-dimensional edge, vertex normal and paint.
def cut_front_socket(panel):
    data=panel.data
    coords=np.empty(len(data.vertices)*3,'f');data.vertices.foreach_get('co',coords);coords=coords.reshape(-1,3)
    faces=np.empty(len(data.loops),'i');data.loops.foreach_get('vertex_index',faces);faces=faces.reshape(-1,3)
    xy=coords.copy();xy[:,1]=-abs(xy[:,1]);camera=(xy-origin)@rotation.T
    projected=(focal*camera[:,:2]/camera[:,2,None]+[cu0-330,cv0-162])/.3
    u,w=projected.T
    candidates=(coords[:,0]<-1.20)&(abs(coords[:,1])>.40)&(coords[:,2]>.32)
    candidates&=(np.abs((basis(u,w)@depth_coeffs)-camera[:,2])<.23)
    boundary=np.full(len(coords),1.e5)
    uv=projected[candidates]
    if not len(uv):return
    available=np.full(len(uv),np.inf)
    for a,b in zip(lamp_outline,np.roll(lamp_outline,-1,axis=0)):
        delta=b-a;fraction=np.clip(((uv-a)@delta)/(delta@delta),0,1)
        available=np.minimum(available,np.linalg.norm(uv-a-fraction[:,None]*delta,axis=1))
    boundary[candidates]=np.where(inside_lamp(uv[:,0],uv[:,1]),-available,available)+.75
    covered=boundary[faces]<0
    if not covered.any():return
    old_normals=np.zeros_like(coords)
    for corner,normal in zip(data.loops,data.corner_normals):
        old_normals[corner.vertex_index]=normal.vector
    layer=data.color_attributes['Surface tone']
    old_colors=np.empty(len(coords)*4,'f');layer.data.foreach_get('color',old_colors);old_colors=old_colors.reshape(-1,4)
    old_material=np.empty(len(faces),'i');data.polygons.foreach_get('material_index',old_material)
    vertices=coords.tolist();normals=old_normals.tolist();colors=old_colors.tolist()
    outside=~covered.any(axis=1);retained=faces[outside].tolist();finishes=old_material[outside].tolist()
    intersections={}
    def crossing(a,b):
        edge=tuple(sorted((a,b)))
        if edge not in intersections:
            t=boundary[a]/(boundary[a]-boundary[b])
            # Convert a distance fraction in image space to the physical edge.
            t=t*camera[a,2]/((1-t)*camera[b,2]+t*camera[a,2])
            intersections[edge]=len(vertices)
            vertices.append(((1-t)*coords[a]+t*coords[b]).tolist())
            normal=(1-t)*old_normals[a]+t*old_normals[b]
            normals.append((normal/max(np.linalg.norm(normal),1e-12)).tolist())
            colors.append(((1-t)*old_colors[a]+t*old_colors[b]).tolist())
        return intersections[edge]
    for fi in np.flatnonzero(~outside&~covered.all(axis=1)):
        polygon=[]
        for a,b in zip(faces[fi],np.roll(faces[fi],-1)):
            if boundary[a]>=0:polygon.append(a)
            if (boundary[a]>=0)!=(boundary[b]>=0):polygon.append(crossing(a,b))
        for j in range(1,len(polygon)-1):
            retained.append([polygon[0],polygon[j],polygon[j+1]]);finishes.append(old_material[fi])
    cut=bpy.data.meshes.new(panel.name+' with open headlamp sockets')
    cut.from_pydata(vertices,[],retained)
    for m in data.materials:cut.materials.append(m)
    cut.polygons.foreach_set('material_index',np.array(finishes,'i'))
    cut.polygons.foreach_set('use_smooth',np.ones(len(retained),'?'))
    paint=cut.color_attributes.new(name=layer.name,type=layer.data_type,domain='POINT')
    paint.data.foreach_set('color',np.asarray(colors,'f').ravel())
    cut.update();cut.normals_split_custom_set_from_vertices(normals);panel.data=cut
    if not data.users:bpy.data.meshes.remove(data)
for panel_name in ['Body surface','Front closure surface','Front fascia surface']:
    cut_front_socket(bpy.data.objects[panel_name])

left_headlamp=empty('Headlamp_L');left_headlamp.parent=bumper
right_headlamp=empty('Headlamp_R');right_headlamp.parent=bumper
def paired_surface(name,verts,faces,material):
    points=np.asarray(verts)
    faces=[list(face) for face in faces]
    for j,face in enumerate(faces):
        a,b,c=points[face[:3]]
        if np.dot(np.cross(b-a,c-a),origin-a)<0:faces[j]=face[::-1]
    obj=mesh(name,points.tolist(),faces,material,left_headlamp)
    for poly in obj.data.polygons:poly.use_smooth=True
    obj2=mesh(name+' right',(points*[1,-1,1]).tolist(),[f[::-1] for f in faces],material,right_headlamp)
    for poly in obj2.data.polygons:poly.use_smooth=True
def shaped_face(name,outline,material,level):
    polygon=np.asarray(outline,dtype=float)
    indices=tessellate_polygon([[Vector((u,w,0)) for u,w in polygon]])
    verts=[];faces=[];seen={}
    def sample(pt):
        u,w=pt;key=tuple(np.round(pt,4))
        if key not in seen:
            seen[key]=len(verts);depth=level(u,w) if callable(level) else level
            verts.append(optical_point(u,w,depth))
        return seen[key]
    for ids in indices:
        tris=[polygon[list(ids)]]
        for _ in range(3):
            pieces=[]
            for a,b,c in tris:
                ab=(a+b)/2;ca=(c+a)/2;bc=(b+c)/2;pieces.extend([[a,ab,ca],[ab,b,bc],[ca,bc,c],[ab,bc,ca]])
            tris=pieces
        faces.extend([[sample(p) for p in tri] for tri in tris])
    paired_surface(name,verts,faces,material)
def formed_ring(name,contours,material):
    verts=[];faces=[];n=len(contours[0][0])
    for j,(loop,z0) in enumerate(contours):
        verts.extend(optical_point(u,w,z0) for u,w in loop)
        if j:
            for k in range(n):faces.append([(j-1)*n+k,(j-1)*n+(k+1)%n,j*n+(k+1)%n,j*n+k])
    paired_surface(name,verts,faces,material)

optic_black=mat('Headlamp graphite cavity','24272a',.22,.39)
optic_gasket=mat('Bonded headlamp seal','202124',.07,.48)
optic_carrier=mat('Molded light guide carrier','565a5d',.59,.29)
guide_glass=mat('Unlit sawtooth light guide','a0a5a3',.24,.25)
prism_high=mat('Bright prism facets','cdd3d0',.49,.23)
optic_shadow=mat('Projector black mask','191c20',.17,.45)
optic_chrome=mat('Reflector metallization','a5afb4',.87,.18)
convex_glass=mat('Projector optic steel blue','46515b',.48,.15)
amber_lens=mat('Amber side marker resin','af6726',.16,.30)
clear_shell=mat('Curved polycarbonate external lens','6e7e89',.02,.105)
clear_shell.use_backface_culling=True
clear_shell.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.045
center=lamp_outline.mean(axis=0)
def shrunk(f):return center+(lamp_outline-center)*f
formed_ring('Black perimeter gasket',[(shrunk(1.024),.005),(shrunk(1.012),.007),(shrunk(.979),.006),(shrunk(.97),-.008)],optic_gasket)
formed_ring('Lamp bucket side wall',[(shrunk(.991),.004),(shrunk(.962),-.006),(shrunk(.91),-.018)],optic_carrier)
formed_ring('Deep reflector housing',[(shrunk(.915),-.016),(shrunk(.915),-.080),
    (shrunk(.91),-.196)],optic_black)
shaped_face('Inset graphite reflector tub',shrunk(.915),optic_black,-.198)
# The long upper guide has a metallic carrier, a narrow pale rib and a shorter
# lower return. The parked reference shows the LEDs unlit.
shaped_face('Upper light guide carrier',[(108,280),(147,250),(221,213),(309,179),(398,151),(454,142),
    (446,151),(411,166),(332,190),(258,220),(177,252),(139,274)],optic_carrier,-.007)
shaped_face('Swept upper light guide',[(119,275),(151,251),(209,223),(286,192),(365,164),(442,144),
    (451,144),(427,154),(357,178),(283,204),(208,234),(158,257)],guide_glass,-.005)
shaped_face('Narrow upper prism lip',[(118,276),(151,250),(209,222),(292,190),(372,163),(443,144),
    (432,148),(370,167),(291,195),(210,226),(152,253)],prism_high,-.003)
shaped_face('Lower corner optical blade',[(118,279),(155,261),(221,238),(249,232),(243,239),
    (201,255),(149,272)],optic_carrier,-.010)
shaped_face('Outboard light guide carrier',[(390,244),(401,214),(425,181),(459,152),(480,151),
    (454,179),(443,194),(447,194),(426,228),(409,240)],optic_carrier,-.007)
shaped_face('Outboard light guide',[(396,241),(408,213),(428,185),(460,156),(472,155),
    (447,179),(436,195),(442,195),(421,229)],guide_glass,-.0045)
shaped_face('Outboard optical bevel',[(402,237),(410,215),(430,187),(447,170),(432,190),(417,222)],prism_high,-.003)
marker=[(445,216),(459,186),(482,164),(500,153),(510,156),(506,168),(482,191)]
# The amber lens faces the side of the vehicle. Its ray-plane intersections
# register its face in 001 and foreshortened edge in 029.
marker_center=np.array([-1.6202,-.8443,.6998])
marker_normal=np.array([-.11,-1.,0.])
def marker_level(u,w):
    depth=np.dot(marker_center-origin,marker_normal)/np.dot(lamp_ray(u,w),marker_normal)
    return basis(u,w)@depth_coeffs-depth
shaped_face('Amber side marker',marker,amber_lens,marker_level)
for j in range(7):
    u=468+j*4.5;w=191-j*4.25
    shaped_face('Amber marker prism',[(u,w),(u+2,w+1),(u+8,w-6),(u+7.8,w-8)],amber,
                lambda u,w:marker_level(u,w)+.0005)

# The low beam points down the car. Two registered native studio views locate
# its optical centre independently of the swept external polycarbonate cover.
projector_center=np.array([-1.7928,-.6945,.6334])
def projector_point(depth,y,z):
    return projector_center+np.array([depth,y*.92,z*.95])
def projector_stations(name,stations,material):
    verts=[];faces=[];count=48
    for j,(depth,width,height) in enumerate(stations):
        for theta in np.linspace(0,2*pi,count,endpoint=False):
            c,s=cos(theta),sin(theta)
            verts.append(projector_point(depth,width*np.sign(c)*abs(c)**.75,
                                         height*np.sign(s)*abs(s)**.72))
        if j:
            for k in range(count):
                k1=(k+1)%count
                faces.append([(j-1)*count+k,(j-1)*count+k1,j*count+k1,j*count+k])
    paired_surface(name,verts,faces,material)
projector_stations('Low beam black shroud',[(.032,.048,.030),(.012,.048,.029),
    (-.002,.044,.026),(-.006,.039,.023)],optic_shadow)
projector_stations('Projector retaining ring',[(.001,.040,.023),(-.005,.037,.022),
    (-.003,.035,.020)],optic_carrier)
projector_stations('Convex projector glass',[(.001,.036,.021),(-.003,.031,.018),
    (-.007,.022,.014),(-.009,.012,.007),(-.010,0.,0.)],convex_glass)
projector_silver=mat('Projector cutoff bright reflector','bfc1bf',.32,.23)
projector_white=mat('Projector upper faceted reflector','e5e8e5',.12,.18)
for finish,glow in [(projector_silver,.20),(projector_white,.45)]:
    shader=finish.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Emission Color'].default_value=(.72,.75,.75,1)
    shader.inputs['Emission Strength'].default_value=glow
def projector_facet(name,depth,outline,material):
    verts=[projector_point(depth,y,z) for y,z in outline]
    faces=tessellate_polygon([[Vector((y,z,0)) for y,z in outline]])
    paired_surface(name,verts,faces,material)
projector_facet('Projector cut-off reflector',-.0105,[(-.031,-.002),(-.023,-.010),
    (.016,-.012),(.029,-.009),(.032,-.002),(.014,-.003)],projector_silver)
projector_facet('Projector upper reflector',-.011,[(-.017,.001),(-.016,.014),
    (.010,.015),(.013,.003),(.006,0)],projector_white)
projector_facet('Projector edge glint',-.0105,[(.025,.012),(.028,.013),(.031,.006),(.027,.005)],guide_glass)
shaped_face('External clear headlamp lens',lamp_outline,clear_shell,.010)
